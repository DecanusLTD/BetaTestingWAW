import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type BookingDetails = {
  id: string;
  status: string;
  service_name: string | null;
  wash_type?: string | null;
  location_address: string | null;
  scheduled_at: string | null;
  created_at: string;
  price: number | null;
  user_id?: string | null;
  customer_name?: string | null;
  customer_review?: string | null;
};

function isMissingColumnErr(err: any) {
  const code = String(err?.code || '');
  const msg = String(err?.message || '').toLowerCase();
  return code === '42703' || msg.includes('does not exist') || msg.includes('column');
}

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

const isPendingStatus = (status: string) =>
  ['pending', 'pending_business_acceptance'].includes(status.toLowerCase());

export default function BusinessBookingDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const [booking, setBooking] = useState<BookingDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  //this is wh

  useEffect(() => {
    if (id) loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const canCancel = useMemo(() => {
    if (!booking) return false;
    const s = booking.status.toLowerCase();
    return s !== 'cancelled' && s !== 'completed';
  }, [booking]);

  const loadBooking = async () => {
    try {
      setLoading(true);

      const baseFields = [
        'id',
        'status',
        'service_name',
        'wash_type',
        'location_address',
        'scheduled_at',
        'created_at',
        'price',
        'user_id',
        'customer_name',
        'customer_review',
      ];

      let fields = [...baseFields];

      for (let i = 0; i < 6; i++) {
        const { data, error } = await supabase
          .from('bookings')
          .select(fields.join(','))
          .eq('id', id)
          .maybeSingle();

        if (!error && data) {
          setBooking({
            id: data.id,
            status: String(data.status ?? 'unknown'),
            service_name: data.service_name ?? null,
            wash_type: data.wash_type ?? null,
            location_address: data.location_address ?? null,
            scheduled_at: data.scheduled_at ?? null,
            created_at: String(data.created_at),
            price: data.price ?? null,
            user_id: data.user_id ?? null,
            customer_name: data.customer_name ?? null,
            customer_review: data.customer_review ?? null,
          });
          return;
        }

        if (isMissingColumnErr(error)) {
          const missing = getMissingColumn(error?.message);
          if (missing && fields.includes(missing)) {
            fields = fields.filter(f => f !== missing);
            continue;
          }
        }

        throw error;
      }

      throw new Error('Failed to load booking');
    } catch (err: any) {
      console.error('[BookingDetails] load error:', err);
      Alert.alert('Error', err?.message || 'Failed to load booking');
    } finally {
      setLoading(false);
    }
  };

  const acceptBooking = async () => {
    if (!booking) return;

    try {
      setActionLoading(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('bookings')
        .update({ status: 'confirmed' })
        .eq('id', booking.id);

      if (error) throw error;

      setBooking({ ...booking, status: 'confirmed' });
      Alert.alert('Accepted', 'Booking has been accepted');
    } catch (err: any) {
      console.error('[BookingDetails] accept error:', err);
      Alert.alert('Error', err?.message || 'Failed to accept booking');
    } finally {
      setActionLoading(false);
    }
  };

  const cancelBooking = async () => {
    if (!booking) return;

    Alert.alert(
      'Cancel booking',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              setActionLoading(true);
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled' })
                .eq('id', booking.id);

              if (error) throw error;

              Alert.alert('Cancelled', 'The booking has been cancelled.');
              router.back();
            } catch (err: any) {
              console.error('[BookingDetails] cancel error:', err);
              Alert.alert('Error', err?.message || 'Failed to cancel booking');
            } finally {
              setActionLoading(false);
            }
          },
        },
      ]
    );
  };

  const speakToCustomer = async () => {
    await hapticFeedback('light');
    Alert.alert('Speak to customer', 'Messaging / calling coming next.');
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Booking Details" accountType="business" />
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading booking…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) return null;

  const serviceDisplay = booking.service_name || booking.wash_type || 'Service';
  const customerDisplay = booking.customer_name || 'Customer';

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Booking Details"
        accountType="business"
        leftAction={
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: HEADER_CONTENT_OFFSET + 16 }, // ✅ HEADER FIX
        ]}
      >
        <GlassCard accountType="business" style={styles.card}>
          <View style={styles.headerRow}>
            <Text style={styles.customerName}>{customerDisplay}</Text>
            <StatusBadge status={booking.status as any} />
          </View>

          <InfoRow icon="briefcase" value={serviceDisplay} />
          {booking.location_address && <InfoRow icon="location" value={booking.location_address} />}
          {booking.scheduled_at && (
            <InfoRow icon="time" value={new Date(booking.scheduled_at).toLocaleString()} />
          )}
          {booking.price !== null && (
            <InfoRow icon="cash" value={`£${Number(booking.price).toFixed(2)}`} />
          )}
        </GlassCard>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionPrimary} onPress={speakToCustomer}>
            <Ionicons name="chatbubble-ellipses" size={18} color="#0A1929" />
            <Text style={styles.actionPrimaryText}>Speak to customer</Text>
          </TouchableOpacity>

          {isPendingStatus(booking.status) && (
            <TouchableOpacity style={styles.actionAccept} onPress={acceptBooking}>
              <Ionicons name="checkmark-circle" size={18} color="#0A1929" />
              <Text style={styles.actionAcceptText}>Accept booking</Text>
            </TouchableOpacity>
          )}

          {canCancel && (
            <TouchableOpacity style={styles.actionDanger} onPress={cancelBooking}>
              <Ionicons name="close-circle" size={18} color="#fff" />
              <Text style={styles.actionDangerText}>Cancel booking</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function InfoRow({ icon, value }: { icon: any; value: string }) {
  return (
    <View style={styles.row}>
      <Ionicons name={icon} size={16} color={SKY} />
      <Text style={styles.text}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY },

  content: { paddingHorizontal: 20, paddingBottom: 40 },

  card: { padding: 16, gap: 10 },

  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },

  customerName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
    marginRight: 10,
  },

  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  text: { color: 'rgba(249,250,251,0.8)', fontSize: 14, flex: 1 },

  actions: { marginTop: 24, gap: 12 },

  actionPrimary: {
    backgroundColor: SKY,
    borderRadius: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionPrimaryText: { color: '#0A1929', fontWeight: '800' },

  actionAccept: {
    backgroundColor: '#22C55E',
    borderRadius: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionAcceptText: { color: '#0A1929', fontWeight: '800' },

  actionDanger: {
    backgroundColor: '#EF4444',
    borderRadius: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionDangerText: { color: '#fff', fontWeight: '800' },
});
