import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import GlassCard from '../../../src/components/booking/GlassCard';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { DVLA_CONFIG } from '../../../src/config/dvla';

const { width } = Dimensions.get('window');
const valeterTheme = getAccountTheme('valeter');

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  tax_status?: string;
  tax_due_date?: string;
  mot_status?: string;
  mot_expiry_date?: string;
}

export default function ValeterVehicleInfo() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLookingUpDVLA, setIsLookingUpDVLA] = useState(false);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);

      const { data } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (data) {
        setProfile(data);
      } else {
        const { data: created } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user!.id, full_name: ' ' })
          .select()
          .single();

        setProfile(created);
      }
    } catch {
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const lookupDVLA = async (registration: string) => {
    if (!DVLA_CONFIG.apiKey) {
      Alert.alert('DVLA not configured', 'Missing DVLA API key');
      return;
    }

    try {
      setIsLookingUpDVLA(true);

      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': DVLA_CONFIG.apiKey,
        },
        body: JSON.stringify({ registrationNumber: registration }),
      });

      if (!res.ok) throw new Error('DVLA lookup failed');

      const data = await res.json();

      setProfile(prev =>
        prev
          ? {
              ...prev,
              vehicle_make: data.make ?? prev.vehicle_make,
              tax_status: data.taxStatus ?? null,
              tax_due_date: data.taxDueDate ?? null,
              mot_status: data.motStatus ?? null,
              mot_expiry_date: data.motExpiryDate ?? null,
            }
          : prev
      );

      await hapticFeedback('success');
    } catch (e: any) {
      Alert.alert('DVLA lookup failed', e.message || 'Unable to fetch vehicle details');
    } finally {
      setIsLookingUpDVLA(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profile || !user?.id) return;

    try {
      setIsSaving(true);

      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          vehicle_make: profile.vehicle_make,
          vehicle_model: profile.vehicle_model,
          vehicle_registration: profile.vehicle_registration,
          tax_status: profile.tax_status,
          tax_due_date: profile.tax_due_date,
          mot_status: profile.mot_status,
          mot_expiry_date: profile.mot_expiry_date,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Saved', 'Vehicle details updated');
      setIsEditing(false);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to save vehicle details');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading || !profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={valeterTheme.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const StatusRow = ({ label, status, date }: any) => {
    const good = status === 'Taxed' || status === 'Valid';
    return (
      <GlassCard style={styles.infoCard} accountType="valeter">
        <Text style={styles.cardLabel}>{label}</Text>
        <Text style={[styles.statusText, good ? styles.good : styles.bad]}>
          {status || 'Unknown'}
        </Text>
        {date && <Text style={styles.subText}>{date}</Text>}
      </GlassCard>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Vehicle Information"
        accountType="valeter"
        rightAction={
          <TouchableOpacity
            onPress={() => setIsEditing(!isEditing)}
            style={styles.editButton}
          >
            <Ionicons name={isEditing ? 'close' : 'create'} size={20} color={valeterTheme.primary} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          paddingHorizontal: 20,
        }}
      >
        <GlassCard style={styles.infoCard} accountType="valeter">
          <Text style={styles.cardLabel}>Registration</Text>
          {isEditing ? (
            <TextInput
              style={styles.cardInput}
              value={profile.vehicle_registration || ''}
              autoCapitalize="characters"
              onChangeText={t =>
                setProfile({
                  ...profile,
                  vehicle_registration: t.replace(/\s/g, '').toUpperCase(),
                })
              }
              onBlur={() =>
                profile.vehicle_registration &&
                lookupDVLA(profile.vehicle_registration)
              }
              placeholder="AB12CDE"
              placeholderTextColor="rgba(255,255,255,0.4)"
            />
          ) : (
            <Text style={styles.cardValue}>{profile.vehicle_registration || '—'}</Text>
          )}
          {isLookingUpDVLA && <ActivityIndicator color={valeterTheme.primary} />}
        </GlassCard>

        <GlassCard style={styles.infoCard} accountType="valeter">
          <Text style={styles.cardLabel}>Make</Text>
          <Text style={styles.cardValue}>{profile.vehicle_make || '—'}</Text>
        </GlassCard>

        <GlassCard style={styles.infoCard} accountType="valeter">
          <Text style={styles.cardLabel}>Model</Text>
          {isEditing ? (
            <TextInput
              style={styles.cardInput}
              value={profile.vehicle_model || ''}
              onChangeText={t => setProfile({ ...profile, vehicle_model: t })}
              placeholder="e.g. Transit Custom"
              placeholderTextColor="rgba(255,255,255,0.4)"
            />
          ) : (
            <Text style={styles.cardValue}>{profile.vehicle_model || '—'}</Text>
          )}
        </GlassCard>

        <StatusRow
          label="Vehicle Tax"
          status={profile.tax_status}
          date={profile.tax_due_date && `Due ${new Date(profile.tax_due_date).toLocaleDateString()}`}
        />

        <StatusRow
          label="MOT"
          status={profile.mot_status}
          date={profile.mot_expiry_date && `Expires ${new Date(profile.mot_expiry_date).toLocaleDateString()}`}
        />

        {isEditing && (
          <TouchableOpacity
            style={styles.saveButton}
            onPress={handleSaveProfile}
            disabled={isSaving}
          >
            <LinearGradient
              colors={[valeterTheme.primary, valeterTheme.primaryAlt]}
              style={styles.saveButtonGradient}
            >
              {isSaving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveText}>Save</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  editButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  infoCard: { padding: 20, marginBottom: 16 },
  cardLabel: { color: 'rgba(255,255,255,0.7)', marginBottom: 6 },
  cardValue: { color: '#fff', fontSize: 18, fontWeight: '700' },

  cardInput: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    backgroundColor: 'rgba(255,255,255,0.08)',
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },

  statusText: { fontSize: 18, fontWeight: '800' },
  good: { color: '#22C55E' },
  bad: { color: '#EF4444' },
  subText: { color: 'rgba(255,255,255,0.6)', marginTop: 4 },

  saveButton: { borderRadius: 16, overflow: 'hidden', marginTop: 10 },
  saveButtonGradient: { padding: 16, alignItems: 'center' },
  saveText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
