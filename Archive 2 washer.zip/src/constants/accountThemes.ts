import { customerTheme } from './customerTheme';
import { colors } from './colors';

export type AccountType = 'customer' | 'valeter' | 'business';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
}

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: '#87CEEB',
    primaryAlt: '#5BA3C7',
    background: customerTheme.backgroundGradient,
    headerBackground: ['rgba(30,58,138,0.35)', 'rgba(30,58,138,0.25)'],
    glassBorder: 'rgba(135,206,235,0.3)',
    accent: '#87CEEB',
    accentAlt: '#5BA3C7',
  },

  valeter: {
    primary: '#3B82F6',
    primaryAlt: '#60A5FA',
    background: ['#0A1929', '#2563EB'],
    headerBackground: ['#0A1929', '#0A1929'],
    glassBorder: 'rgba(59,130,246,0.3)',
    glassBorderAlt: 'rgba(96,165,250,0.3)',
    accent: '#3B82F6',
    accentAlt: '#60A5FA',
  },

  business: {
    primary: '#3B82F6', // Darker blue
    primaryAlt: '#2563EB', // Darker blue for contrast
    background: ['#1E3A8A', '#0F172A'], // Darker blue gradient
    headerBackground: ['rgba(30,58,138,0.45)', 'rgba(15,23,42,0.35)'], // Darker blue header
    glassBorder: 'transparent', // No border for cleaner look
    accent: '#3B82F6', // Darker blue accent
    accentAlt: '#2563EB',
  },
};

export const getAccountTheme = (accountType: AccountType): AccountTheme => {
  return accountThemes[accountType];
};
