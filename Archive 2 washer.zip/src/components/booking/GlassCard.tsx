import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  accountType?: AccountType;
}

export default function GlassCard({ 
  children, 
  onPress, 
  style, 
  intensity = 40,
  tint = 'dark',
  borderColor,
  accountType
}: GlassCardProps) {
  // Use account theme if provided, otherwise try to get from context, otherwise default to customer
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType)
    : contextTheme.theme;
  
  const finalBorderColor = borderColor || theme.glassBorder;

  const content = (
    <BlurView intensity={intensity} tint={tint} style={[styles.blurContainer, style]}>
      <LinearGradient
        colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']}
        style={StyleSheet.absoluteFill}
      />
      {/* Subtle inner glow effect */}
      <View style={[styles.innerGlow, { borderColor: finalBorderColor }]} />
      <View style={[styles.border, { borderColor: finalBorderColor }]} />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0,
    shadowRadius: 12,
  },
  innerGlow: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 0.5,
    opacity: 0.3,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
  },
});

