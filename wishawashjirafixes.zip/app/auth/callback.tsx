import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../src/lib/supabase';

export default function AuthCallbackScreen() {
  const params = useLocalSearchParams();
  const [message, setMessage] = useState('Completing sign in...');

  useEffect(() => {
    let cancelled = false;

    const finish = async () => {
      try {
        const code = typeof params.code === 'string' ? params.code : null;
        const type = typeof params.type === 'string' ? params.type.toLowerCase() : '';
        const isRecovery = type === 'recovery' || type === 'password_recovery';

        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code);
          if (error) throw error;
        }

        if (!cancelled) {
          if (isRecovery) {
            router.replace('/auth/login' as any);
            return;
          }
          router.replace('/');
        }
      } catch (error: any) {
        if (!cancelled) {
          setMessage(error?.message || 'Unable to complete sign in.');
        }
      }
    };

    void finish();
    return () => { cancelled = true; };
  }, [params.code, params.type]);

  return (
    <View style={styles.container}>
      <ActivityIndicator color="#87CEEB" />
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#0A1929',
    gap: 16,
  },
  text: {
    color: '#F9FAFB',
    textAlign: 'center',
    fontSize: 16,
    lineHeight: 22,
  },
});
