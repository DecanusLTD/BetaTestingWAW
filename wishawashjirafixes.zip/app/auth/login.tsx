import React, { useEffect, useState } from 'react';
import { Alert, Platform } from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthLandingShell from '../../src/components/auth/AuthLandingShell';
import AuthEmailSheet from '../../src/components/auth/AuthEmailSheet';
import AuthResetPasswordSheet from '../../src/components/auth/AuthResetPasswordSheet';
import { resolvePostAuthRoute } from '../../src/utils/profileSetupGate';

const SESSION_KEY = 'user_session';

export default function LoginScreen() {
  const { login, loginWithApple, loginWithGoogle, resetPassword, user } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetEmail, setResetEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailSheetVisible, setEmailSheetVisible] = useState(false);
  const [resetSheetVisible, setResetSheetVisible] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  const finishRouting = async () => {
    let sessionUser = user;
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.id) sessionUser = parsed;
      }
    } catch {
      /* keep context user */
    }

    if (!sessionUser?.id) {
      router.replace('/owner/owner-dashboard');
      return;
    }
    const dest = await resolvePostAuthRoute(sessionUser);
    router.replace(dest);
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    await hapticFeedback('medium');
    setIsLoading(true);

    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      setEmailSheetVisible(false);
      // Read latest session user from storage via a short tick — auth context updates async.
      // Prefer resolve after login returns; user state may lag one frame.
      await finishRouting();
    } catch {
      Alert.alert('Login Failed', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const openResetSheet = () => {
    setResetEmail(email.trim());
    setResetError(null);
    setResetSent(false);
    setEmailSheetVisible(false);
    setResetSheetVisible(true);
  };

  const closeResetSheet = () => {
    setResetSheetVisible(false);
    setResetError(null);
    setResetSent(false);
  };

  const backToSignIn = () => {
    closeResetSheet();
    setEmailSheetVisible(true);
  };

  const handleResetPassword = async () => {
    const trimmed = resetEmail.trim();
    if (!trimmed || !trimmed.includes('@')) {
      setResetError('Please enter a valid email address');
      return;
    }

    await hapticFeedback('medium');
    setResetLoading(true);
    setResetError(null);

    try {
      await resetPassword(trimmed);
      setResetSent(true);
      if (!email.trim()) setEmail(trimmed);
    } catch (err: any) {
      setResetError(err?.message || 'Could not send reset email. Please try again.');
    } finally {
      setResetLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);

      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const ok = await loginWithApple(credential);
      if (!ok) {
        Alert.alert('Apple Sign In Failed', 'Please try again.');
        return;
      }

      await finishRouting();
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign In Failed', 'Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);
      const ok = await loginWithGoogle();
      if (!ok) {
        Alert.alert('Google Sign In Failed', 'Please try again.');
        return;
      }
      await finishRouting();
    } catch (error: any) {
      Alert.alert('Google Sign In Failed', error?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AuthLandingShell
        mode="login"
        subcopy="Future Of Vehicle Care"
        switchLabel="Sign up"
        onSwitchAuth={() => router.push('/auth/signup' as any)}
        onContinueEmail={() => setEmailSheetVisible(true)}
        onApple={() => void handleAppleLogin()}
        onGoogle={() => void handleGoogleLogin()}
        isAppleAvailable={isAppleAvailable}
        disabled={isLoading || resetLoading}
      />

      <AuthEmailSheet
        visible={emailSheetVisible}
        onClose={() => setEmailSheetVisible(false)}
        mode="login"
        loading={isLoading}
        email={email}
        password={password}
        onChangeEmail={setEmail}
        onChangePassword={setPassword}
        onSubmit={() => void handleLogin()}
        onSwitchMode={() => {
          setEmailSheetVisible(false);
          router.push('/auth/signup' as any);
        }}
        onForgotPassword={openResetSheet}
      />

      <AuthResetPasswordSheet
        visible={resetSheetVisible}
        onClose={closeResetSheet}
        email={resetEmail}
        onChangeEmail={(v) => {
          setResetEmail(v);
          setResetError(null);
        }}
        onSubmit={() => void handleResetPassword()}
        onBackToSignIn={backToSignIn}
        loading={resetLoading}
        error={resetError}
        sent={resetSent}
      />
    </>
  );
}
