import React, { useEffect, useState } from 'react';
import { Alert, Platform } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthLandingShell from '../../src/components/auth/AuthLandingShell';
import AuthEmailSheet from '../../src/components/auth/AuthEmailSheet';
import { resolvePostAuthRoute } from '../../src/utils/profileSetupGate';

const SESSION_KEY = 'user_session';

export default function SignupScreen() {
  const params = useLocalSearchParams<{ referralCode?: string; code?: string }>();
  const { register, registerWithApple, registerWithGoogle, user } = useAuth();

  const USER_TYPE = 'customer' as const;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    referralCode: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailSheetVisible, setEmailSheetVisible] = useState(false);

  useEffect(() => {
    const incoming =
      (typeof params.referralCode === 'string' && params.referralCode.trim()) ||
      (typeof params.code === 'string' && params.code.trim()) ||
      '';
    if (!incoming) return;
    setFormData((prev) => ({
      ...prev,
      referralCode: incoming.trim().toUpperCase(),
    }));
  }, [params.referralCode, params.code]);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const finishRouting = async () => {
    let sessionUser = user;
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.id) sessionUser = parsed;
      }
    } catch {
      /* keep context user */
    }
    if (!sessionUser?.id) {
      router.replace('/owner/profile-setup');
      return;
    }
    const dest = await resolvePostAuthRoute(sessionUser);
    router.replace(dest);
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const referralCode = formData.referralCode.trim();
      const signupPayload: Parameters<typeof register>[0] = {
        email: formData.email,
        name: formData.name,
        isVerified: false,
        verificationType: 'none',
        totalWashes: 0,
        tier: 'bronze',
        tierPoints: 0,
        password: formData.password,
        userType: USER_TYPE,
      };
      if (referralCode) signupPayload.referralCode = referralCode;

      const success = await register(signupPayload);

      if (success) {
        setEmailSheetVisible(false);
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/auth/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);

      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const referralCode = formData.referralCode.trim();
      type AppleSeed = NonNullable<Parameters<typeof registerWithApple>[1]>;
      const appleSeed: AppleSeed = {
        userType: USER_TYPE,
      };
      if (referralCode) appleSeed.referralCode = referralCode;

      const ok = await registerWithApple(cred, appleSeed);
      if (!ok) {
        Alert.alert('Apple Sign Up Failed', 'Please try again.');
        return;
      }

      await finishRouting();
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign Up Failed', 'Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await hapticFeedback('light');
      setIsLoading(true);
      const referralCode = formData.referralCode.trim();
      const ok = await registerWithGoogle({
        userType: USER_TYPE,
        ...(referralCode ? { referralCode } : {}),
      });
      if (!ok) {
        Alert.alert('Google Sign Up Failed', 'Please try again.');
        return;
      }
      await finishRouting();
    } catch (error: any) {
      Alert.alert('Google Sign Up Failed', error?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AuthLandingShell
        mode="signup"
        subcopy="Create an account and make a Wish"
        switchLabel="Sign in"
        onSwitchAuth={() => router.replace('/auth/login')}
        onContinueEmail={() => setEmailSheetVisible(true)}
        onApple={() => void handleAppleSignup()}
        onGoogle={() => void handleGoogleSignup()}
        isAppleAvailable={isAppleAvailable}
        disabled={isLoading}
      />

      <AuthEmailSheet
        visible={emailSheetVisible}
        onClose={() => setEmailSheetVisible(false)}
        mode="signup"
        loading={isLoading}
        error={error}
        email={formData.email}
        password={formData.password}
        name={formData.name}
        referralCode={formData.referralCode}
        onChangeEmail={(v) => updateFormData('email', v)}
        onChangePassword={(v) => updateFormData('password', v)}
        onChangeName={(v) => updateFormData('name', v)}
        onChangeReferralCode={(v) => updateFormData('referralCode', v)}
        onSubmit={() => void handleSignup()}
        onSwitchMode={() => {
          setEmailSheetVisible(false);
          router.replace('/auth/login');
        }}
      />
    </>
  );
}
