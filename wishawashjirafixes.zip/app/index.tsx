// app/index.tsx – routing only; no full-screen loader (splash shown at root during boot/auth)
import React, { useEffect } from 'react';
import { useRouter, useRootNavigationState } from 'expo-router';
import { View } from 'react-native';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { resolvePostAuthRoute } from '../src/utils/profileSetupGate';

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady } = useAuth();

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;

    let cancelled = false;

    (async () => {
      if (!user) {
        if (!cancelled) router.replace('/auth/login');
        return;
      }

      const dest = await resolvePostAuthRoute(user);
      if (!cancelled) router.replace(dest);
    })().catch(() => {
      if (!cancelled) router.replace('/owner/owner-dashboard');
    });

    return () => {
      cancelled = true;
    };
  }, [navReady, authReady, isLoading, user, router]);

  // Root BootProvider shows splash during auth restore; avoid any full-screen loader here
  return <View style={{ flex: 1 }} />;
}
