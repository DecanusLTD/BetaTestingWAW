import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { AUTO_SELECT_DEFAULT_VEHICLE_KEY } from '../../../../src/constants/userPreferences';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import VehiclePickerSheet from '../../../../src/components/booking/VehiclePickerSheet';
import { toggleBookingVehicleId } from '../../../../src/utils/bookingVehicleSelection';
import BubbleBackground from '../../../../src/components/shared/BubbleBackground';

type Vehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

/**
 * Minimal hub-booking vehicle picker — replaces the full-screen vehicle step.
 */
export default function PhysicalVehicleSelection() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    scheduledAt?: string;
  }>();
  const locationId = params.locationId as string | undefined;
  const serviceId = params.serviceId as string | undefined;
  const scheduledAt = params.scheduledAt as string | undefined;

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicleIds, setSelectedVehicleIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const hasAutoAdvancedRef = useRef(false);

  const toggleSelectedVehicle = (vehicleId: string) => {
    setSelectedVehicleIds((prev) => toggleBookingVehicleId(prev, vehicleId));
  };

  const advanceWithVehicles = async (vehicleIds: string[]) => {
    if (vehicleIds.length === 0) return;
    await hapticFeedback('medium');
    const primaryVehicleId = vehicleIds[0];
    const vehicleIdsParam = vehicleIds.join(',');
    if (locationId) {
      router.replace({
        pathname: '/owner/booking/physical/service',
        params: {
          locationId,
          vehicleId: primaryVehicleId,
          vehicleIds: vehicleIdsParam,
          ...(serviceId ? { serviceId } : {}),
          ...(scheduledAt ? { scheduledAt } : {}),
        },
      });
      return;
    }
    router.replace({
      pathname: '/owner/booking/physical/location',
      params: { vehicleId: primaryVehicleId, vehicleIds: vehicleIdsParam },
    });
  };

  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('customer_vehicles')
          .select('*')
          .eq('user_id', user.id)
          .order('is_default', { ascending: false });
        if (error) throw error;
        const rows = (data || []) as Vehicle[];
        setVehicles(rows);
        const def = rows.length > 0 ? rows.find((v) => v.is_default) || rows[0] : null;
        setSelectedVehicleIds((prev) => {
          if (rows.length === 0) return [];
          if (prev.length > 0 && prev.every((id) => rows.some((v) => v.id === id))) return prev;
          return def ? [def.id] : [];
        });
        if (def && !hasAutoAdvancedRef.current) {
          try {
            const autoSelect = await AsyncStorage.getItem(AUTO_SELECT_DEFAULT_VEHICLE_KEY);
            if (autoSelect === 'true') {
              hasAutoAdvancedRef.current = true;
              await advanceWithVehicles([def.id]);
            }
          } catch {}
        }
      } catch (e) {
        console.error('Failed to load vehicles', e);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id, locationId, serviceId, scheduledAt]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <BubbleBackground accountType="customer" />
      <View style={styles.backdrop} />
      <VehiclePickerSheet
        visible
        onClose={() => router.back()}
        vehicles={vehicles}
        selectedIds={selectedVehicleIds}
        onToggle={toggleSelectedVehicle}
        onContinue={(vehicleIds) => { void advanceWithVehicles(vehicleIds); }}
        loading={loading}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.35)',
  },
});
