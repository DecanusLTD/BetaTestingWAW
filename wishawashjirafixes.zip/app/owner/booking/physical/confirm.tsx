import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Video, ResizeMode } from 'expo-av';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { colors } from '../../../../src/constants/colors';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  fetchCarWashHub,
} from '../../../../src/utils/hubPendingPaymentBooking';
import { BOOKING_FLOW_VIDEO } from '../../../../assets/assetExports';
import { supabase } from '../../../../src/lib/supabase';
import {
  resolveVehicleSizeKey,
  sumPhysicalWashPriceForVehicles,
} from '../../../../src/utils/physicalWashServicePricing';
import {
  formatBookingVehicleInfo,
  parseBookingVehicleIdsParam,
} from '../../../../src/utils/bookingVehicleSelection';

const SKY = colors.SKY;

/**
 * Legacy route: immediately creates a pending-payment booking and sends the user to payment.
 * (Interactive confirm UI was removed from the hub wash flow.)
 */
export default function PhysicalConfirm() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    vehicleIds?: string;
    vehicleInfo?: string;
    washType?: string;
    scheduledAt?: string;
    price?: string;
  }>();

  const didSubmitRef = useRef(false);
  const [hint, setHint] = useState('Preparing payment…');

  useEffect(() => {
    if (didSubmitRef.current) return;
    const {
      locationId,
      serviceId,
      vehicleId,
      vehicleIds,
      vehicleInfo,
      washType,
      scheduledAt,
      price: priceParam,
    } = params;
    const bookingVehicleIds = parseBookingVehicleIdsParam(vehicleIds, vehicleId);

    if (!user?.id) {
      setHint('Sign in required');
      Alert.alert('Sign in required', 'Please sign in to complete your booking.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
      return;
    }
    if (!locationId || !serviceId || bookingVehicleIds.length === 0 || !scheduledAt) {
      setHint('Invalid link');
      Alert.alert('Missing information', 'This booking link is incomplete.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
      return;
    }

    didSubmitRef.current = true;

    void (async () => {
      try {
        const hub = await fetchCarWashHub(locationId);
        const { data: serviceRow } = await supabase
          .from('location_services')
          .select('id, location_id, service_name, is_enabled, price, duration_minutes, price_by_size')
          .eq('id', serviceId)
          .maybeSingle();

        const { data: vehicleRows } = await supabase
          .from('customer_vehicles')
          .select('id, make, model, type, size, registration')
          .in('id', bookingVehicleIds);

        const orderedVehicles = bookingVehicleIds
          .map((id) => (vehicleRows || []).find((row) => row.id === id))
          .filter(Boolean) as Array<{
          id: string;
          make?: string;
          model?: string;
          type?: string;
          size?: string;
          registration?: string;
        }>;

        if (!hub || !serviceRow || serviceRow.location_id !== locationId || serviceRow.is_enabled === false) {
          didSubmitRef.current = false;
          Alert.alert('Error', 'Could not load booking details.', [{ text: 'OK', onPress: () => router.back() }]);
          return;
        }

        const vehicleSizes = orderedVehicles.map((v) => resolveVehicleSizeKey(v.size));
        const displayPrice =
          priceParam != null && !Number.isNaN(Number(priceParam))
            ? Number(priceParam)
            : sumPhysicalWashPriceForVehicles(
                serviceRow as {
                  price_by_size: Record<string, unknown> | null;
                  price: number | string | null;
                },
                vehicleSizes
              ) ?? 0;

        if (displayPrice <= 0) {
          didSubmitRef.current = false;
          Alert.alert('Unavailable', 'This service does not have pricing for your vehicle size yet.', [
            { text: 'OK', onPress: () => router.back() },
          ]);
          return;
        }

        const resolvedVehicleInfo =
          vehicleInfo ||
          formatBookingVehicleInfo(
            orderedVehicles.map((v) => ({
              id: v.id,
              make: v.make ?? 'Vehicle',
              model: v.model ?? '',
              ...(v.registration ? { registration: v.registration } : {}),
            })),
            bookingVehicleIds
          );

        const bookingId = await createHubPendingPaymentBooking({
          userId: user.id,
          vehicleId: bookingVehicleIds[0],
          vehicleIds: bookingVehicleIds,
          vehicleInfo: resolvedVehicleInfo || null,
          vehicleType: orderedVehicles[0]?.type ?? null,
          hub,
          service: { id: serviceRow.id, name: serviceRow.service_name },
          price: displayPrice,
          washType: washType || null,
          scheduledAt,
        });

        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (err: unknown) {
        didSubmitRef.current = false;
        if (err instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
              },
            ]
          );
          return;
        }
        console.error('[PhysicalConfirm] booking error', err);
        const message =
          err && typeof err === 'object' && 'message' in err
            ? String((err as { message: string }).message)
            : 'Unable to create booking';
        Alert.alert('Error', message, [{ text: 'OK', onPress: () => router.back() }]);
      }
    })();
  }, [user?.id, params.locationId, params.serviceId, params.vehicleId, params.vehicleIds, params.scheduledAt, params.price, params.washType, params.vehicleInfo]);

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" />
      <Video
        source={BOOKING_FLOW_VIDEO}
        style={StyleSheet.absoluteFill}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
      />
      <View style={styles.center}>
        <ActivityIndicator size="large" color={SKY} />
        <Text style={styles.hint}>{hint}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  hint: { color: 'rgba(226,232,240,0.9)', fontSize: 15, fontWeight: '600', textAlign: 'center' },
});
