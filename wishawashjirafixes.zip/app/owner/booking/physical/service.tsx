import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { WWSheetCloseButton } from '../../../../src/components/ui';
import { colors } from '../../../../src/constants/colors';
import IndexTrackingCardShell from '../../../../src/components/booking/IndexTrackingCardShell';
import { supabase } from '../../../../src/lib/supabase';
import {
  BOOKING_CARD,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  getCustomerBookingSheetScreenBottom,
  BOOKING_H_CARD_GAP,
  getIndexTrackingCardWidth,
  getIndexTrackingCardSnapInterval,
} from '../../../../src/constants/bookingCardTheme';
import { customerMapTrackingSheetActionStyles } from '../../../../src/components/booking/CustomerMapTrackingSheetShell';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { getVehicleSize } from '../../../../src/pricing/pricingEngine';
import { BOOKING_FLOW_VIDEO } from '../../../../assets/assetExports';
import BusinessSheetBackground from '../../../../src/components/shared/BusinessSheetBackground';
import BookingBottomSheetOverlay from '../../../../src/components/booking/BookingBottomSheetOverlay';
import { BOOKING_INFO_SHEET_ACCENT } from '../../../../src/constants/bookingInfoSheetTheme';
import { CCP } from '../../../../src/constants/carCareProLabels';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import PhysicalBookingHubMapLayer from '../../../../src/components/booking/PhysicalBookingHubMapLayer';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  fetchCarWashHub,
} from '../../../../src/utils/hubPendingPaymentBooking';
import {
  getPhysicalWashAvailableSizes,
  isBronzePhysicalWash,
  resolveVehicleSizeKey,
  sumPhysicalWashPriceForVehicles,
  type PhysicalWashServiceRow,
  type VehicleSizeKey,
} from '../../../../src/utils/physicalWashServicePricing';
import {
  formatBookingVehicleInfo,
  parseBookingVehicleIdsParam,
} from '../../../../src/utils/bookingVehicleSelection';

const SKY = colors.SKY;
const HUB_CARD_W = getIndexTrackingCardWidth(Dimensions.get('window').width);
const HUB_CARD_STEP = getIndexTrackingCardSnapInterval(Dimensions.get('window').width);

function engineSizeToKey(engineSize: ReturnType<typeof getVehicleSize>): VehicleSizeKey {
  if (engineSize === 'SMALL') return 'small';
  if (engineSize === 'XXL') return 'xxl';
  if (engineSize === 'XL') return 'xl';
  if (engineSize === 'LARGE') return 'large';
  return 'medium';
}

export default function PhysicalServiceSelection() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { coords } = useLiveLocation();
  const sheetBottom = getCustomerBookingSheetScreenBottom();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  const vehicleIdsParam = (params.vehicleIds as string) || '';
  const bookingVehicleIds = parseBookingVehicleIdsParam(vehicleIdsParam, vehicleId);
  const scheduledAt = params.scheduledAt as string | undefined;
  const preSelectedServiceId = params.serviceId as string | undefined;

  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [infoModalService, setInfoModalService] = useState<PhysicalWashServiceRow | null>(null);
  const [washTypeModalVisible, setWashTypeModalVisible] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [serviceRows, setServiceRows] = useState<PhysicalWashServiceRow[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [checkoutSubmitting, setCheckoutSubmitting] = useState(false);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  /** Vehicle sizes for pricing (one per selected vehicle) */
  const [vehicleSizeKeys, setVehicleSizeKeys] = useState<VehicleSizeKey[]>(['medium']);
  const [selectedVehicles, setSelectedVehicles] = useState<
    Array<{ id: string; make?: string; model?: string; type?: string; size?: string; registration?: string }>
  >([]);

  const vehicleSizeKey = vehicleSizeKeys[0] ?? 'medium';
  const vehicleCount = Math.max(1, vehicleSizeKeys.length);
  const bookingVehicleInfo = formatBookingVehicleInfo(
    selectedVehicles.map((v) => ({
      id: v.id,
      make: v.make ?? 'Vehicle',
      model: v.model ?? '',
      ...(v.registration ? { registration: v.registration } : {}),
    })),
    bookingVehicleIds
  );

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  useEffect(() => {
    if (!locationId) return;
    loadServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId, vehicleSizeKeys.join('|')]);

  // Load selected vehicles to get sizes for pricing (cards show sum for all selected)
  useEffect(() => {
    if (bookingVehicleIds.length === 0) {
      setVehicleSizeKeys(['medium']);
      setSelectedVehicles([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('id, make, model, type, size, registration')
        .in('id', bookingVehicleIds);
      if (cancelled) return;
      if (error || !data?.length) {
        setVehicleSizeKeys(['medium']);
        setSelectedVehicles([]);
        return;
      }
      const ordered = bookingVehicleIds
        .map((id) => data.find((row) => row.id === id))
        .filter(Boolean) as Array<{
        id: string;
        make?: string;
        model?: string;
        type?: string;
        size?: string;
        registration?: string;
      }>;
      setSelectedVehicles(ordered);
      setVehicleSizeKeys(
        ordered.map((v) => {
          const resolvedSize = resolveVehicleSizeKey(v.size);
          if (resolvedSize) return resolvedSize;
          return engineSizeToKey(
            getVehicleSize({
              ...(v.make ? { make: v.make } : {}),
              ...(v.model ? { model: v.model } : {}),
              ...(v.type ? { type: v.type } : {}),
            })
          );
        })
      );
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingVehicleIds.join(',')]);

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data?.latitude != null && data?.longitude != null) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Car Wash',
          address: data.address || '',
        };
        setHubLocation(hub);
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadServices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('id, location_id, service_name, is_enabled, price, duration_minutes, price_by_size')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as PhysicalWashServiceRow[];
      const built = rows
        .filter((row) => row.location_id === locationId && row.is_enabled !== false)
        .filter((row) => sumPhysicalWashPriceForVehicles(row, vehicleSizeKeys) != null);

      setServiceRows(built);

      if (preSelectedServiceId && built.some((b) => b.id === preSelectedServiceId)) {
        setSelectedService(preSelectedServiceId);
        if (!isBronzePhysicalWash(built.find((b) => b.id === preSelectedServiceId)?.service_name)) setWashType('both');
      } else {
        setSelectedService((prev) => {
          if (!prev) return prev;
          const stillThere = built.some((b) => b.id === prev);
          return stillThere ? prev : null;
        });
      }
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadServices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServiceRows([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    const selected = services.find((s) => s.id === serviceId);
    if (isBronzePhysicalWash(selected?.service_name)) {
      setWashType(null);
      setWashTypeModalVisible(true);
    } else {
      setWashType('both');
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
    setWashTypeModalVisible(false);
  };

  const services = useMemo(
    () =>
      serviceRows.map((row, index) => {
        const price = sumPhysicalWashPriceForVehicles(row, vehicleSizeKeys);
        const duration = typeof row.duration_minutes === 'number' && row.duration_minutes > 0 ? row.duration_minutes : null;
        const accentPalette = ['#CD7F32', '#A8A8A8', '#FFD700', '#E5E4E2', '#22D3EE'];
        const accent = accentPalette[index % accentPalette.length];
        const sizeLabel =
          vehicleCount > 1
            ? `${vehicleCount} vehicles`
            : `${(vehicleSizeKey === 'xxl' ? 'XXL (HGV)' : vehicleSizeKey.toUpperCase())} vehicle`;

        return {
          ...row,
          name: row.service_name,
          desc: price != null
            ? `Set by this location for your ${sizeLabel}.`
            : 'Pricing is not set for your vehicle size.',
          dur: duration != null ? `${duration} min` : 'Duration not set',
          minutes: duration ?? 0,
          price: price ?? 0,
          is_enabled: row.is_enabled !== false && price != null,
          accent,
          priceTiers: getPhysicalWashAvailableSizes(row),
        };
      }).filter((row) => row.is_enabled),
    [serviceRows, vehicleSizeKey, vehicleSizeKeys, vehicleCount]
  );

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  const serviceContinueAccent = selectedServiceData?.accent ?? SKY;
  const serviceContinueReady = !!(
    selectedService &&
    selectedServiceData &&
    Number.isFinite(selectedServiceData.price) &&
    selectedServiceData.price > 0 &&
    (!isBronzePhysicalWash(selectedServiceData.service_name) || !!washType)
  );

  const onPrimaryContinue = async () => {
    if (!locationId || !vehicleId || !selectedService) return;
    const selected = services.find((s) => s.id === selectedService);
    if (!selected) return;

    if (!Number.isFinite(selected.price) || selected.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    if (isBronzePhysicalWash(selected.service_name) && !washType) {
      setWashTypeModalVisible(true);
      return;
    }

    await hapticFeedback('medium');

    const finalPrice = selected.price;
    const effectiveWashType: 'exterior' | 'interior' | 'both' =
      isBronzePhysicalWash(selected.service_name) ? (washType as 'exterior' | 'interior') : 'both';

    const baseParams = {
      serviceId: selectedService,
      vehicleId: bookingVehicleIds[0] || vehicleId,
      vehicleIds: bookingVehicleIds.join(','),
      locationId,
      washType: effectiveWashType,
      price: String(finalPrice),
      ...(bookingVehicleInfo ? { vehicleInfo: bookingVehicleInfo } : {}),
    };

    if (scheduledAt) {
      if (!user?.id) {
        Alert.alert('Sign in required', 'Please sign in to complete your booking.');
        return;
      }
      try {
        setCheckoutSubmitting(true);
        const hub = await fetchCarWashHub(locationId);
        if (!hub) {
          Alert.alert('Error', 'Could not load this location.');
          return;
        }
        const bookingId = await createHubPendingPaymentBooking({
          userId: user.id,
          vehicleId: bookingVehicleIds[0] || vehicleId,
          vehicleIds: bookingVehicleIds,
          vehicleInfo: bookingVehicleInfo || null,
          vehicleType: selectedVehicles[0]?.type ?? null,
          hub,
          service: { id: selected.id, name: selected.service_name },
          price: finalPrice,
          washType: effectiveWashType,
          scheduledAt,
        });
        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (err: unknown) {
        if (err instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
              },
            ]
          );
        } else {
          console.error('[PhysicalService] booking error', err);
          const message = err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : 'Unable to create booking';
          Alert.alert('Error', message);
        }
      } finally {
        setCheckoutSubmitting(false);
      }
    } else {
      router.push({
        pathname: '/owner/booking/physical/schedule',
        params: baseParams,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
            <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadServices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          fullWidth
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {hubLocation && Number.isFinite(hubLocation.latitude) && Number.isFinite(hubLocation.longitude) ? (
        <PhysicalBookingHubMapLayer
          hubLatitude={hubLocation.latitude}
          hubLongitude={hubLocation.longitude}
          userLatitude={coords?.latitude}
          userLongitude={coords?.longitude}
          mapPaddingBottom={sheetBottom + 52}
        />
      ) : (
        <Video
          source={BOOKING_FLOW_VIDEO}
          style={StyleSheet.absoluteFill}
          shouldPlay
          isLooping
          isMuted
          resizeMode={ResizeMode.COVER}
        />
      )}

      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        fullWidth
        onBack={() => router.back()}
        rightAction={
          <WWSheetCloseButton
            size={40}
            iconSize={22}
            onPress={handleExitBooking}
            accessibilityLabel="Exit booking"
          />
        }
      />

      <Animated.View style={[styles.cardsContainer, { opacity: fadeAnim, bottom: sheetBottom }]}>
        <View style={[styles.vehicleBottomSheet, { paddingBottom: Math.max(insets.bottom, 8) }]}>
          <BusinessSheetBackground />
          <View style={styles.locationSheetHandle} />
          <ScrollView
            horizontal
            style={styles.bookingStepHorizontalScroll}
            contentContainerStyle={styles.bookingIndexOptionsListH}
            showsHorizontalScrollIndicator={false}
            snapToInterval={HUB_CARD_STEP}
            decelerationRate="fast"
            snapToAlignment="start"
            keyboardShouldPersistTaps="handled"
          >
            {services.map((service) => {
              const isSelected = selectedService === service.id;
              const tierColor = {
                main: service.accent,
                light: service.accent + '25',
                border: service.accent + '50',
              };
              const leadIcon = service.service_name.toLowerCase().includes('detail')
                ? 'sparkles-outline'
                : service.service_name.toLowerCase().includes('repair')
                  ? 'construct-outline'
                  : 'car-sport-outline';

              return (
                <TouchableOpacity
                  key={service.id}
                  activeOpacity={0.92}
                  onPress={() => void handleServiceSelect(service.id)}
                  style={[styles.physicalListCardWrap, { width: HUB_CARD_W, marginRight: BOOKING_H_CARD_GAP }]}
                >
                  <IndexTrackingCardShell
                    accentColor={tierColor.main}
                    style={[
                      styles.physicalListCard,
                      isSelected ? styles.physicalListCardSelected : undefined,
                    ]}
                  >
                    <View style={styles.physicalCardTopRow}>
                      <View style={[styles.physicalCardIconWrap, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}>
                        <Ionicons name={leadIcon as any} size={20} color={tierColor.main} />
                      </View>
                      <View style={styles.physicalCardTitleMain}>
                        <Text style={styles.physicalCardTitle} numberOfLines={2}>
                          {service.name}
                        </Text>
                        <Text style={styles.physicalCardSubtitle} numberOfLines={2}>
                          {service.dur} · £{service.price.toFixed(0)} for your {vehicleCount > 1 ? 'vehicles' : 'vehicle'}
                        </Text>
                        <Text style={[styles.tierTagline, { color: tierColor.main + 'CC' }]} numberOfLines={2}>
                          Prices are set by this location
                        </Text>
                      </View>
                      <TouchableOpacity
                        style={[styles.physicalInfoBtn, { borderColor: tierColor.main + '40', backgroundColor: tierColor.main + '15' }]}
                        onPress={() => { hapticFeedback('light'); setInfoModalService(service); }}
                        activeOpacity={0.85}
                        accessibilityLabel="Service details"
                        accessibilityRole="button"
                      >
                        <Ionicons name="information-circle-outline" size={22} color={tierColor.main} />
                      </TouchableOpacity>
                    </View>
                    {isSelected && isBronzePhysicalWash(service.service_name) ? (
                      <TouchableOpacity
                        onPress={() => setWashTypeModalVisible(true)}
                        style={[styles.washTypeChip, { backgroundColor: tierColor.main + '22', borderColor: tierColor.main + '44' }]}
                        activeOpacity={0.8}
                      >
                        {washType ? (
                          <>
                            <Ionicons
                              name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                              size={14}
                              color={tierColor.main}
                            />
                            <Text style={[styles.washTypeChipText, { color: tierColor.main }]}>
                              {washType === 'exterior' ? 'Exterior' : 'Interior'}
                            </Text>
                          </>
                        ) : (
                          <Text style={[styles.washTypeChipText, { color: tierColor.main }]}>Set clean area</Text>
                        )}
                      </TouchableOpacity>
                    ) : null}
                  </IndexTrackingCardShell>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
            <TouchableOpacity
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                customerMapTrackingSheetActionStyles.bookingInfoCard,
                styles.bookingSheetTrackingCta,
                {
                  borderColor: serviceContinueAccent + '8A',
                  opacity: serviceContinueReady ? 1 : 0.45,
                },
              ]}
              onPress={() => void onPrimaryContinue()}
              disabled={!serviceContinueReady || checkoutSubmitting}
              activeOpacity={0.85}
            >
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={[serviceContinueAccent + '59', 'rgba(15,23,42,0.65)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <Ionicons name="arrow-forward-circle" size={18} color={serviceContinueAccent} style={{ zIndex: 1 }} />
              <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                <Text style={[styles.bookingSheetCtaLabel, { color: serviceContinueAccent }]}>
                  {checkoutSubmitting ? 'Creating booking…' : `Continue to ${CCP.singularShort}`}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay visible={!!infoModalService} onClose={() => setInfoModalService(null)} maxHeightRatio={0.88}>
        {infoModalService ? (() => {
              const tc = {
                main: BOOKING_INFO_SHEET_ACCENT,
                light: `${BOOKING_INFO_SHEET_ACCENT}33`,
                border: `${BOOKING_INFO_SHEET_ACCENT}66`,
              };
              const priceTiers = getPhysicalWashAvailableSizes(infoModalService);
              const selectedVehiclePrice = sumPhysicalWashPriceForVehicles(infoModalService, vehicleSizeKeys);
              return (
                <>
                  <View style={styles.serviceInfoHero}>
                    <Text style={[styles.infoModalTitle, { color: BOOKING_INFO_SHEET_ACCENT }]} numberOfLines={2}>{infoModalService.service_name}</Text>
                    <View style={[styles.infoModalBadge, { backgroundColor: tc.light, borderColor: tc.border }]}>
                      <Text style={[styles.infoModalBadgeText, { color: tc.main }]}>Set by this location</Text>
                    </View>
                  </View>
                    <ScrollView
                      style={styles.infoModalScroll}
                      contentContainerStyle={styles.infoModalScrollContent}
                      showsVerticalScrollIndicator
                    >
                    <View style={[styles.infoModalPriceRow, { borderLeftColor: tc.main }]}>
                      <Text style={[styles.infoModalPrice, { color: tc.main }]}>
                        {selectedVehiclePrice != null ? `£${selectedVehiclePrice.toFixed(0)}` : 'Unavailable'}
                      </Text>
                      <View style={styles.infoModalDuration}>
                        <Ionicons name="time-outline" size={14} color="#64748B" />
                        <Text style={styles.infoModalDurationText}>
                          {typeof infoModalService.duration_minutes === 'number' && infoModalService.duration_minutes > 0
                            ? `${infoModalService.duration_minutes} min`
                            : 'Duration not set'}
                        </Text>
                      </View>
                    </View>
                    <Text style={styles.infoModalDesc}>
                      Prices and availability are managed by this location for the selected vehicle size.
                    </Text>
                    {selectedVehiclePrice != null ? (
                      <Text style={[styles.infoModalDescTitle, { color: tc.main }]}>
                        Your vehicle size: {vehicleCount > 1 ? `${vehicleCount} vehicles` : vehicleSizeKey === 'xxl' ? 'XXL (HGV)' : vehicleSizeKey.toUpperCase()}
                      </Text>
                    ) : (
                      <Text style={[styles.infoModalDescTitle, { color: tc.main }]}>
                        Not available for your vehicle size
                      </Text>
                    )}
                    {priceTiers.length > 0 && (
                      <View style={styles.infoModalSection}>
                        <View style={styles.infoModalSectionTitleRow}>
                          <Ionicons name="checkmark-done-circle" size={16} color={tc.main} />
                          <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Price matrix</Text>
                        </View>
                        {priceTiers.map((tier) => (
                          <View key={tier.key} style={styles.infoModalFeatureRow}>
                            <Ionicons name="checkmark-circle" size={18} color={tc.main} />
                            <Text style={styles.infoModalFeatureText}>
                              {tier.key.toUpperCase()} {tier.price != null ? `- £${tier.price.toFixed(0)}` : '- unavailable'}
                            </Text>
                          </View>
                        ))}
                      </View>
                    )}
                    <View style={[styles.infoModalSection, { borderTopColor: tc.light + '50' }]}>
                      <View style={styles.infoModalSectionTitleRow}>
                        <Ionicons name="car-sport-outline" size={16} color={tc.main} />
                        <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Price by size</Text>
                      </View>
                      <View style={styles.infoModalTiers}>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>S</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>{priceTiers[0].price != null ? `£${priceTiers[0].price.toFixed(0)}` : '—'}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>M</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>{priceTiers[1].price != null ? `£${priceTiers[1].price.toFixed(0)}` : '—'}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>L</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>{priceTiers[2].price != null ? `£${priceTiers[2].price.toFixed(0)}` : '—'}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>{priceTiers[3].price != null ? `£${priceTiers[3].price.toFixed(0)}` : '—'}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XXL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>{priceTiers[4].price != null ? `£${priceTiers[4].price.toFixed(0)}` : '—'}</Text>
                        </View>
                      </View>
                    </View>
                    </ScrollView>
                  <TouchableOpacity
                    onPress={() => setInfoModalService(null)}
                    style={styles.infoModalDoneWrap}
                    activeOpacity={0.9}
                  >
                    <LinearGradient colors={[BOOKING_INFO_SHEET_ACCENT, `${BOOKING_INFO_SHEET_ACCENT}E6`]} style={styles.infoModalDoneBtn}>
                      <Text style={styles.infoModalDoneText}>Close</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              );
            })() : null}
      </BookingBottomSheetOverlay>

      <BookingBottomSheetOverlay
        visible={washTypeModalVisible}
        onClose={() => setWashTypeModalVisible(false)}
        maxHeightRatio={0.88}
      >
        <View style={styles.washTypeSheetHeader}>
          <View style={[styles.washTypeModalBadge, { backgroundColor: BOOKING_INFO_SHEET_ACCENT }]}>
            <MaterialCommunityIcons name="car-wash" size={18} color="#0F172A" />
            <Text style={styles.washTypeModalBadgeText}>{selectedServiceData?.service_name ?? 'Wash'}</Text>
          </View>
          <Text style={[styles.washTypeModalTitle, { color: BOOKING_INFO_SHEET_ACCENT }]}>What do you want cleaned?</Text>
          <Text style={styles.washTypeModalSubtitle}>
            Exterior or interior — choose the clean area for this booking
          </Text>
        </View>
        <View style={styles.washTypeModalOptions}>
          <TouchableOpacity
            onPress={() => void handleWashTypeSelect('exterior')}
            style={[styles.washTypeModalOption, { borderColor: BOOKING_INFO_SHEET_ACCENT + '50' }]}
            activeOpacity={0.85}
          >
            <View style={[styles.washTypeModalOptionIcon, { backgroundColor: BOOKING_INFO_SHEET_ACCENT + '25' }]}>
              <Ionicons name="car-sport-outline" size={32} color={BOOKING_INFO_SHEET_ACCENT} />
            </View>
            <View style={styles.washTypeModalOptionBody}>
              <Text style={styles.washTypeModalOptionLabel}>Exterior</Text>
              <Text style={styles.washTypeModalOptionDesc}>
                Wheels & arches, snow foam, hand wash, rinse, dry, windows & mirrors
              </Text>
            </View>
            <Text style={[styles.washTypeModalOptionPrice, { color: BOOKING_INFO_SHEET_ACCENT }]}>
              {selectedServiceData?.price != null ? `£${selectedServiceData.price.toFixed(0)}` : '—'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => void handleWashTypeSelect('interior')}
            style={[styles.washTypeModalOption, { borderColor: BOOKING_INFO_SHEET_ACCENT + '50' }]}
            activeOpacity={0.85}
          >
            <View style={[styles.washTypeModalOptionIcon, { backgroundColor: BOOKING_INFO_SHEET_ACCENT + '25' }]}>
              <Ionicons name="layers-outline" size={32} color={BOOKING_INFO_SHEET_ACCENT} />
            </View>
            <View style={styles.washTypeModalOptionBody}>
              <Text style={styles.washTypeModalOptionLabel}>Interior</Text>
              <Text style={styles.washTypeModalOptionDesc}>
                Vacuum, wipe-down, steering wheel, glass & air freshener
              </Text>
            </View>
            <Text style={[styles.washTypeModalOptionPrice, { color: BOOKING_INFO_SHEET_ACCENT }]}>
              {selectedServiceData?.price != null ? `£${selectedServiceData.price.toFixed(0)}` : '—'}
            </Text>
          </TouchableOpacity>
        </View>
      </BookingBottomSheetOverlay>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    width: '100%',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 2,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  locationSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  bookingStepVerticalScroll: {
    flexGrow: 0,
    flexShrink: 1,
    maxHeight: 420,
  },
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    width: '100%',
  },
  bookingIndexOptionsListH: {
    marginTop: 10,
    paddingHorizontal: 14,
    paddingBottom: 4,
    alignItems: 'stretch',
  },
  bookingIndexOptionsList: {
    marginTop: 10,
    paddingHorizontal: 14,
    gap: 10,
  },
  physicalListShell: {
    paddingHorizontal: 14,
    paddingTop: 10,
  },
  physicalListCardWrap: {
    width: '100%',
  },
  physicalListCard: {
    width: '100%',
    minHeight: 116,
  },
  physicalListCardSelected: {
    borderColor: SKY + '90',
    borderWidth: 2,
  },
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 0,
    marginTop: -10,
    paddingBottom: 2,
  },
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 10,
  },
  bookingSheetTrackingCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  bookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },
  physicalCardTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  physicalCardIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  physicalCardTitleMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  physicalCardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 3,
  },
  physicalCardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  physicalInfoBtn: {
    padding: 6,
    borderRadius: 10,
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  serviceCardSelected: {
    elevation: 4,
    shadowOpacity: 0.18,
    shadowRadius: 10,
  },
  badgePill: {
    alignSelf: 'flex-start',
    marginBottom: 6,
    zIndex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 2,
  },
  badgePillIconWrap: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(15,23,42,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgePillText: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.25,
    maxWidth: 110,
  },
  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  washTypeChipSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 5,
    paddingHorizontal: 9,
    borderRadius: 8,
    borderWidth: 1,
    gap: 4,
    maxWidth: 132,
    flexShrink: 1,
  },
  washTypeChipSmallText: {
    fontSize: 11,
    fontWeight: '700',
  },
  serviceCardFooterRow: {
    flexWrap: 'nowrap',
    gap: 8,
    alignItems: 'center',
  },
  serviceCardTaglineSlot: {
    justifyContent: 'flex-start',
  },
  tierTagline: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  washTypeSheetHeader: {
    paddingBottom: 16,
    gap: 10,
  },
  washTypeModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  washTypeModalBadgeText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  washTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  washTypeModalOptions: {
    padding: 20,
    gap: 12,
  },
  washTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    backgroundColor: 'rgba(205,127,50,0.06)',
  },
  washTypeModalOptionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  washTypeModalOptionBody: {
    flex: 1,
    minWidth: 0,
  },
  washTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  washTypeModalOptionPrice: {
    fontSize: 18,
    fontWeight: '800',
    marginLeft: 12,
  },
  ctaWrapper: {
    marginTop: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal – clean, matches app
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  serviceInfoHero: {
    marginBottom: 10,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.1)',
    gap: 8,
  },
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(5,15,30,0.88)',
    justifyContent: 'flex-end',
  },
  infoModalCard: {
    width: '100%',
    height: '90%',
    maxHeight: '90%',
    backgroundColor: '#1E293B',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1.5,
    borderBottomWidth: 0,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    paddingLeft: 24,
    borderBottomWidth: 1,
    position: 'relative',
  },
  infoModalAccent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 2,
    borderBottomLeftRadius: 2,
  },
  infoModalHeaderContent: { flex: 1, marginLeft: 8 },
  infoModalTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
    color: '#F9FAFB',
  },
  infoModalBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
  },
  infoModalBadgeText: { fontSize: 12, fontWeight: '700' },
  infoModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 18,
    paddingBottom: 24,
  },
  infoModalPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingLeft: 14,
    borderLeftWidth: 4,
    borderRadius: 2,
  },
  infoModalPrice: { fontSize: 26, fontWeight: '800' },
  infoModalDuration: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoModalDurationText: { color: '#94A3B8', fontSize: 14, fontWeight: '600' },
  infoModalDescTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 20,
  },
  infoModalSection: {
    marginBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalSectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  infoModalSectionTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  infoModalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  infoModalFeatureText: {
    color: '#E2E8F0',
    fontSize: 14,
    flex: 1,
    lineHeight: 21,
  },
  infoModalTiers: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 6,
  },
  infoModalTierItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  infoModalTierLabel: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoModalTierValue: { fontSize: 16, fontWeight: '800' },
  infoModalDoneWrap: {
    marginTop: 8,
    marginBottom: 8,
    borderRadius: 14,
    overflow: 'hidden',
  },
  infoModalDoneBtn: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
