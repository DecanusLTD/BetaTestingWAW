import React, { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { WWSheetCloseButton } from '../../../../src/components/ui';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../../src/components/booking/IndexTrackingCardShell';
import { customerMapTrackingSheetActionStyles } from '../../../../src/components/booking/CustomerMapTrackingSheetShell';
import { colors } from '../../../../src/constants/colors';
import {
  BOOKING_CARD,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  getCustomerBookingSheetScreenBottom,
  getIndexTrackingCardSnapInterval,
  getIndexTrackingCardWidth,
} from '../../../../src/constants/bookingCardTheme';
import BookingSheetPremiumLayers from '../../../../src/components/booking/BookingSheetPremiumLayers';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { BOOKING_FLOW_VIDEO } from '../../../../assets/assetExports';
import BusinessSheetBackground from '../../../../src/components/shared/BusinessSheetBackground';
import { bookingScheduleWindowDays } from '../../../../src/utils/bookingScheduleCalendar';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import {
  ActiveBookingBlockedError,
  createHubPendingPaymentBooking,
  locationRowToHub,
} from '../../../../src/utils/hubPendingPaymentBooking';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import PhysicalBookingHubMapLayer from '../../../../src/components/booking/PhysicalBookingHubMapLayer';
import {
  resolveVehicleSizeKey,
  sumPhysicalWashPriceForVehicles,
  type VehicleSizeKey,
} from '../../../../src/utils/physicalWashServicePricing';
import {
  formatBookingVehicleInfo,
  parseBookingVehicleIdsParam,
} from '../../../../src/utils/bookingVehicleSelection';

const SKY = colors.SKY;
const { width, height: windowHeight } = Dimensions.get('window');
type SchedulePhase = 'calendar' | 'times';

type LocationRow = {
  id: string;
  name: string | null;
  address: string | null;
};

type OpeningHoursRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null; // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number; // 30
};

type LocationServiceRow = {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
  price_by_size: Record<string, unknown> | null;
};

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

function parseHHMM(raw: string | null): { h: number; m: number } | null {
  const s = String(raw || '').trim();
  if (!s) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return { h: hh, m: mm };
}

// Convert JS getDay (0=Sun..6=Sat) -> our DB day (0=Mon..6=Sun)
function jsDayToDbDay(jsDay: number) {
  // Sun(0)->6, Mon(1)->0, Tue(2)->1 ... Sat(6)->5
  return (jsDay + 6) % 7;
}

function buildSlotsFromHours(hours: OpeningHoursRow[], daysAhead = 7) {
  const now = new Date();
  const slots: string[] = [];

  // map day -> hours row
  const byDay = new Map<number, OpeningHoursRow>();
  for (const r of hours) byDay.set(r.day_of_week, r);

  for (let offset = 0; offset < daysAhead; offset++) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + offset);

    const dbDay = jsDayToDbDay(d.getDay());
    const row = byDay.get(dbDay);
    if (!row?.is_open) continue;

    const open = parseHHMM(row.open_time);
    const close = parseHHMM(row.close_time);
    const step = Number(row.slot_minutes || 30);

    if (!open || !close) continue;
    if (!Number.isFinite(step) || step <= 0) continue;

    const start = new Date(d);
    start.setHours(open.h, open.m, 0, 0);

    const end = new Date(d);
    end.setHours(close.h, close.m, 0, 0);

    // if close <= open, ignore (bad config)
    if (end.getTime() <= start.getTime()) continue;

    // generate slots up to (but not including) end
    for (let t = start.getTime(); t + step * 60_000 <= end.getTime(); t += step * 60_000) {
      const slotDate = new Date(t);

      // don't show past slots for today
      if (slotDate.getTime() < now.getTime() + 2 * 60_000) continue;

      slots.push(slotDate.toISOString());
    }
  }

  // sort ascending
  slots.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  return slots;
}

function startOfLocalDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function localDayKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function slotMatchesDay(iso: string, day: Date): boolean {
  return localDayKey(new Date(iso)) === localDayKey(day);
}

export default function PhysicalSchedule() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { coords } = useLiveLocation();
  const sheetBottom = getCustomerBookingSheetScreenBottom();
  const cardWidth = getIndexTrackingCardWidth(width);
  const snapInterval = getIndexTrackingCardSnapInterval(width);
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    vehicleIds?: string;
    vehicleInfo?: string;
    washType?: string;
    price?: string;
  }>();

  const locationId = params.locationId;
  const serviceId = params.serviceId;
  const vehicleId = params.vehicleId;
  const vehicleIdsParam = params.vehicleIds;
  const vehicleInfoParam = params.vehicleInfo;
  const washType = params.washType;
  const priceFromParams = params.price;

  const [location, setLocation] = useState<LocationRow & { latitude?: number; longitude?: number } | null>(null);
  const [serviceRow, setServiceRow] = useState<LocationServiceRow | null>(null);
  const [vehicleSizeKeys, setVehicleSizeKeys] = useState<VehicleSizeKey[]>(['medium']);
  const [selectedVehicles, setSelectedVehicles] = useState<
    Array<{ id: string; make?: string; model?: string; type?: string; size?: string; registration?: string }>
  >([]);
  const bookingVehicleIds = parseBookingVehicleIdsParam(vehicleIdsParam, vehicleId);
  const bookingVehicleInfo =
    vehicleInfoParam ||
    formatBookingVehicleInfo(
      selectedVehicles.map((v) => ({
        id: v.id,
        make: v.make ?? 'Vehicle',
        model: v.model ?? '',
        ...(v.registration ? { registration: v.registration } : {}),
      })),
      bookingVehicleIds
    );

  const [loading, setLoading] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(true);

  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [bookingSubmitting, setBookingSubmitting] = useState(false);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);
  const [selectedDay, setSelectedDay] = useState<Date>(() => startOfLocalDay(new Date()));
  const [schedulePhase, setSchedulePhase] = useState<SchedulePhase>('calendar');
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const windowDays = useMemo(() => bookingScheduleWindowDays(), []);
  const calGap = 6;
  const calPad = 16;
  const cellW = Math.floor((width - calPad * 2 - calGap * 6) / 7);

  const dayHasSlots = useCallback(
    (day: Date) => timeSlots.some((iso) => slotMatchesDay(iso, day)),
    [timeSlots]
  );

  const serviceLabel = serviceRow?.service_name || 'Wash';

  const slotsForDay = useMemo(
    () => timeSlots.filter((iso) => slotMatchesDay(iso, selectedDay)),
    [timeSlots, selectedDay]
  );

  const durationLabel = useMemo(() => {
    const m = serviceRow?.duration_minutes;
    if (typeof m === 'number' && m > 0) return `${m} min`;
    return null;
  }, [serviceRow?.duration_minutes]);

  // Check if a string is a valid UUID format
  const isValidUUID = (str: string | undefined): boolean => {
    if (!str) return false;
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str);
  };

  useEffect(() => {
    if (!locationId) return;

    const loadAll = async () => {
      try {
        setLoading(true);

        // Only query location_services if serviceId is a valid UUID
        const shouldQueryService = serviceId && isValidUUID(serviceId);

        const [{ data: loc, error: locErr }, svcRes] = await Promise.all([
          supabase
            .from('car_wash_locations')
            .select('id,name,address,latitude,longitude')
            .eq('id', locationId)
            .maybeSingle(),
          shouldQueryService
            ? supabase
                .from('location_services')
                .select('id,location_id,service_name,is_enabled,price,duration_minutes,price_by_size')
                .eq('id', serviceId)
                .maybeSingle()
            : Promise.resolve({ data: null, error: null } as any),
        ]);

        if (locErr) throw locErr;

        const locationData = (loc as LocationRow & { latitude?: number; longitude?: number }) ?? null;
        setLocation(locationData);
        
        // Update map region if location has coordinates
        // Only accept service if it belongs to this location (prevents mismatched IDs)
        if (svcRes?.error) {
          // don’t hard fail, we can still show fallback service from constants
          console.warn('[PhysicalSchedule] service load error:', svcRes.error.message);
          setServiceRow(null);
        } else {
          const svc = (svcRes?.data ?? null) as LocationServiceRow | null;
          if (svc?.location_id === locationId && svc.is_enabled !== false) setServiceRow(svc);
          else setServiceRow(null);
        }
      } catch (e: any) {
        console.error('[PhysicalSchedule] loadAll error:', e);
        Alert.alert('Error', e?.message || 'Failed to load booking info');
        setLocation(null);
        setServiceRow(null);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [locationId, serviceId]);

  useEffect(() => {
    if (bookingVehicleIds.length === 0) {
      setVehicleSizeKeys(['medium']);
      setSelectedVehicles([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('id, make, model, type, size, registration')
        .in('id', bookingVehicleIds);
      if (cancelled) return;
      if (error || !data?.length) {
        setVehicleSizeKeys(['medium']);
        setSelectedVehicles([]);
        return;
      }
      const ordered = bookingVehicleIds
        .map((id) => data.find((row) => row.id === id))
        .filter(Boolean) as Array<{
        id: string;
        make?: string;
        model?: string;
        type?: string;
        size?: string;
        registration?: string;
      }>;
      setSelectedVehicles(ordered);
      setVehicleSizeKeys(
        ordered.map((v) => {
          const resolved = resolveVehicleSizeKey(v.size);
          if (resolved) return resolved;
          return v.size && typeof v.size === 'string' ? (v.size.toLowerCase() as VehicleSizeKey) : 'medium';
        })
      );
    })();
    return () => {
      cancelled = true;
    };
  }, [bookingVehicleIds.join(',')]);

  const loadSlots = async () => {
    if (!locationId) return;

    try {
      setLoadingSlots(true);

      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('id,location_id,day_of_week,is_open,open_time,close_time,slot_minutes')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as OpeningHoursRow[];
      const slots = buildSlotsFromHours(rows, 7);

      setTimeSlots(slots);

      if (slots.length > 0) {
        const firstDay = startOfLocalDay(new Date(slots[0]));
        setSelectedDay((prev) => {
          const stillOk = slots.some((iso) => slotMatchesDay(iso, prev));
          return stillOk ? prev : firstDay;
        });
      }

      setSelectedSlot((prev) => (prev && !slots.includes(prev) ? null : prev));
    } catch (e: any) {
      console.error('[PhysicalSchedule] loadSlots error:', e);

      // If table doesn't exist yet / not migrated in this env, show a helpful empty state
      setTimeSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  useEffect(() => {
    loadSlots();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  useEffect(() => {
    setSchedulePhase('calendar');
    setSelectedSlot(null);
  }, [locationId]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleSelectSlot = async (slotValue: string) => {
    await hapticFeedback('light');
    setSelectedSlot(slotValue);
  };

  const goToPayment = async () => {
    if (!selectedSlot || bookingSubmitting) return;
    const hasArgs = Boolean(serviceId && locationId && vehicleId);
    if (!hasArgs) return;
    if (!user?.id) {
      Alert.alert('Sign in required', 'Please sign in to complete your booking.');
      return;
    }
    const hub = locationRowToHub(location);
    const serviceResolved = serviceRow && serviceRow.location_id === locationId
      ? { id: serviceRow.id, name: serviceRow.service_name }
      : null;
    if (!hub || !serviceResolved || serviceRow?.is_enabled === false) {
      Alert.alert('Error', 'Could not load hub or service for this booking.');
      return;
    }
    const displayPrice = (() => {
      if (priceFromParams && !Number.isNaN(Number(priceFromParams))) return Number(priceFromParams);
      const calculated = serviceRow ? sumPhysicalWashPriceForVehicles(serviceRow, vehicleSizeKeys) : null;
      if (calculated != null) return calculated;
      return 0;
    })();

    if (displayPrice <= 0) {
      Alert.alert('Unavailable', 'This service does not have pricing for your vehicle size yet.');
      return;
    }

    try {
      setBookingSubmitting(true);
      await hapticFeedback('medium');
      const bookingId = await createHubPendingPaymentBooking({
        userId: user.id,
        vehicleId: bookingVehicleIds[0] || vehicleId!,
        vehicleIds: bookingVehicleIds,
        vehicleInfo: bookingVehicleInfo || null,
        vehicleType: selectedVehicles[0]?.type ?? null,
        hub,
        service: serviceResolved,
        price: displayPrice,
        washType: washType || null,
        scheduledAt: selectedSlot,
      });
      router.replace({
        pathname: '/owner/booking/payment',
        params: { bookingId },
      });
    } catch (err: unknown) {
      if (err instanceof ActiveBookingBlockedError) {
        Alert.alert(
          'One booking at a time',
          'You already have an active booking. Please complete or cancel it before starting a new one.',
          [
            { text: 'OK', style: 'cancel' },
            {
              text: 'View my booking',
              onPress: () =>
                router.push({ pathname: '/owner/booking/tracking', params: { bookingId: err.activeBookingId } } as any),
            },
          ]
        );
      } else {
        console.error('[PhysicalSchedule] booking error', err);
        const message = err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : 'Unable to create booking';
        Alert.alert('Error', message);
      }
    } finally {
      setBookingSubmitting(false);
    }
  };

  const hasRequiredParams = Boolean(locationId && serviceId && vehicleId);
  if (!hasRequiredParams) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  function renderSlotCardContent() {
    if (loading) {
      return (
        <IndexTrackingCardShell accentColor={SKY}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading time slots...</Text>
          </View>
        </IndexTrackingCardShell>
      );
    }
    if (loadingSlots) {
      return (
        <IndexTrackingCardShell accentColor={SKY}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading available slots...</Text>
          </View>
        </IndexTrackingCardShell>
      );
    }
    if (timeSlots.length === 0) {
      return (
        <IndexTrackingCardShell accentColor={SKY}>
          <View style={styles.emptySlotsCard}>
            <Ionicons name="time-outline" size={22} color={SKY} style={{ opacity: 0.9 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.emptyTitle}>No slots available</Text>
              <Text style={styles.emptySub}>
                This location hasn't set opening hours yet (or they're closed for the next 7 days).
              </Text>
            </View>
          </View>
        </IndexTrackingCardShell>
      );
    }
    if (schedulePhase === 'calendar') {
      return (
        <>
          <View style={styles.slotHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.slotHeaderTitle}>Pick a date</Text>
              <Text style={styles.slotHeaderSub}>
              Green = slots available · Grey = no openings
            </Text>
            </View>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                loadSlots();
              }}
              activeOpacity={0.85}
              style={styles.refreshBtn}
            >
              {loadingSlots ? (
                <ActivityIndicator size="small" color={SKY} />
              ) : (
                <Ionicons name="refresh" size={18} color={SKY} />
              )}
            </TouchableOpacity>
          </View>

          <View style={styles.calGrid}>
            {windowDays.map((day) => {
              const key = localDayKey(day);
              const has = dayHasSlots(day);
              const isToday = localDayKey(day) === localDayKey(new Date());
              return (
                <TouchableOpacity
                  key={key}
                  disabled={!has}
                  onPress={async () => {
                    if (!has) return;
                    await hapticFeedback('medium');
                    setSelectedDay(day);
                    setSelectedSlot(null);
                    setSchedulePhase('times');
                  }}
                  activeOpacity={0.88}
                  style={[
                    styles.calCell,
                    { width: cellW },
                    has ? styles.calCellAvailable : styles.calCellUnavailable,
                  ]}
                >
                  <Text style={[styles.calDow, !has && styles.calDowMuted]}>
                    {day.toLocaleDateString('en-GB', { weekday: 'short' })}
                  </Text>
                  <Text style={[styles.calDom, !has && styles.calDomMuted]}>{day.getDate()}</Text>
                  {isToday ? <Text style={styles.calTodayLbl}>Today</Text> : null}
                </TouchableOpacity>
              );
            })}
          </View>
        </>
      );
    }

    return (
      <>
        <TouchableOpacity
          style={styles.changeDateRow}
          onPress={async () => {
            await hapticFeedback('light');
            setSchedulePhase('calendar');
            setSelectedSlot(null);
          }}
          activeOpacity={0.85}
        >
          <Ionicons name="chevron-back" size={22} color={SKY} />
          <Text style={styles.changeDateText}>Change date</Text>
        </TouchableOpacity>

        <View style={styles.slotHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.slotHeaderTitle}>Choose a time</Text>
            <Text style={styles.slotHeaderSub}>
              {selectedDay.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
          </View>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadSlots();
            }}
            activeOpacity={0.85}
            style={styles.refreshBtn}
          >
            {loadingSlots ? (
              <ActivityIndicator size="small" color={SKY} />
            ) : (
              <Ionicons name="refresh" size={18} color={SKY} />
            )}
          </TouchableOpacity>
        </View>

        {selectedSlot ? (
          <View style={styles.upcomingCard}>
            <View style={styles.upcomingCardHeader}>
              <Ionicons name="briefcase-outline" size={18} color={SKY} />
              <Text style={styles.upcomingKicker}>Upcoming visit</Text>
            </View>
            <Text style={styles.upcomingHub} numberOfLines={2}>
              {location?.name || 'Car wash'}
            </Text>
            <Text style={styles.upcomingService} numberOfLines={1}>
              {serviceLabel}
              {durationLabel ? ` · ${durationLabel}` : ''}
            </Text>
            <View style={styles.upcomingWhenRow}>
              <View style={styles.upcomingWhenBlock}>
                <Text style={styles.upcomingWhenValue}>
                  {new Date(selectedSlot).toLocaleTimeString('en-GB', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: false,
                  })}
                </Text>
                <Text style={styles.upcomingWhenHint}>Arrive by</Text>
              </View>
              <View style={styles.upcomingWhenDivider} />
              <View style={[styles.upcomingWhenBlock, { flex: 1 }]}>
                <Text style={styles.upcomingWhenDate}>
                  {new Date(selectedSlot).toLocaleDateString('en-GB', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                  })}
                </Text>
                <Text style={styles.upcomingWhenHint}>Hub booking</Text>
              </View>
            </View>
            <View style={styles.calendarHintRow}>
              <Ionicons name="calendar-outline" size={14} color="rgba(148,163,184,0.95)" />
              <Text style={styles.calendarHintText}>
                After you pay, we add this booking to your device calendar with a reminder.
              </Text>
            </View>
          </View>
        ) : null}

        <Text style={styles.timesSectionTitle}>Times for {selectedDay.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}</Text>
        {slotsForDay.length === 0 ? (
          <View style={styles.noTimesForDay}>
            <Ionicons name="moon-outline" size={20} color="#94A3B8" />
            <Text style={styles.noTimesForDayText}>No slots left on this day. Pick another date above.</Text>
          </View>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            snapToInterval={snapInterval}
            decelerationRate="fast"
            contentContainerStyle={styles.slotRow}
          >
            {slotsForDay.map((slot) => {
              const date = new Date(slot);
              const isSelected = selectedSlot === slot;
              const timeStr = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
              const dayPart = date.toLocaleDateString('en-GB', { weekday: 'short' });
              const datePart = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
              return (
                <TouchableOpacity
                  key={slot}
                  activeOpacity={0.92}
                  onPress={() => void handleSelectSlot(slot)}
                  style={[ix.cardWrap, styles.cardWrapper, { width: cardWidth }]}
                >
                  <IndexTrackingCardShell
                    accentColor={SKY}
                    style={isSelected ? { borderColor: SKY + '90', borderWidth: 2 } : undefined}
                  >
                    <View style={styles.slotCardMainRow}>
                      <View style={styles.slotTimeColumn}>
                        <Text style={styles.slotTimeHuge}>{timeStr}</Text>
                        <Text style={styles.slotTimeSub}>{dayPart} · {datePart}</Text>
                      </View>
                      <View style={[styles.slotSelectBadge, isSelected && styles.slotSelectBadgeOn]}>
                        {isSelected ? (
                          <Ionicons name="checkmark-circle" size={26} color={SKY} />
                        ) : (
                          <Ionicons name="ellipse-outline" size={26} color="rgba(148,163,184,0.45)" />
                        )}
                      </View>
                    </View>
                    {durationLabel ? (
                      <Text style={styles.slotDurationCaption}>Estimated duration · {durationLabel}</Text>
                    ) : null}
                    {slotsForDay.length > 1 ? (
                      <View style={styles.swipeHintRow}>
                        <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(148,163,184,0.12)' }]}>
                          <View style={[ix.optionStatusDot, { backgroundColor: '#94A3B8' }]} />
                          <Text style={[ix.optionStatusText, { color: '#94A3B8' }]}>Swipe for more times</Text>
                        </View>
                      </View>
                    ) : null}
                  </IndexTrackingCardShell>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        )}

        {selectedSlot ? (
          <View style={styles.continueBar}>
            <TouchableOpacity
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                customerMapTrackingSheetActionStyles.bookingInfoCard,
                styles.continueCta,
                { borderColor: SKY + '8A' },
              ]}
              onPress={() => void goToPayment()}
              disabled={bookingSubmitting}
              activeOpacity={0.85}
            >
              <BlurView intensity={22} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={[SKY + '59', 'rgba(15,23,42,0.65)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <Ionicons name="arrow-forward-circle" size={18} color={SKY} style={{ zIndex: 1 }} />
              <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                <Text style={styles.continueCtaText}>{bookingSubmitting ? 'Creating booking…' : 'Continue to payment'}</Text>
              </View>
            </TouchableOpacity>
          </View>
        ) : null}
      </>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {location &&
      location.latitude != null &&
      location.longitude != null &&
      Number.isFinite(Number(location.latitude)) &&
      Number.isFinite(Number(location.longitude)) ? (
        <PhysicalBookingHubMapLayer
          hubLatitude={Number(location.latitude)}
          hubLongitude={Number(location.longitude)}
          userLatitude={coords?.latitude}
          userLongitude={coords?.longitude}
          mapPaddingBottom={sheetBottom + 56}
        />
      ) : (
        <Video
          source={BOOKING_FLOW_VIDEO}
          style={StyleSheet.absoluteFill}
          shouldPlay
          isLooping
          isMuted
          resizeMode={ResizeMode.COVER}
        />
      )}

      <AppHeader 
        title="Pick time slot" 
        subtitle={location?.name || 'Select your preferred time'}
        showBack={true}
        fullWidth
        onBack={() => router.back()}
        rightAction={
          <WWSheetCloseButton
            size={40}
            iconSize={22}
            onPress={handleExitBooking}
            accessibilityLabel="Exit booking"
          />
        }
      />

      <View
        style={[
          styles.flowSheet,
          {
            bottom: sheetBottom,
            paddingBottom: Math.max(insets.bottom, 10),
            maxHeight: Math.round(windowHeight * 0.58),
          },
        ]}
      >
        <BusinessSheetBackground />
        <BookingSheetPremiumLayers />
        <View style={styles.flowSheetHandle} />
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.flowSheetScrollContent}
        >
          <Animated.View
            style={[
              styles.cardsContainer,
              {
                opacity: fadeAnim,
              },
            ]}
          >
            {renderSlotCardContent()}
          </Animated.View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  flowSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'column',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  flowSheetHandle: {
    width: 46,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.55)',
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  flowSheetScrollContent: {
    flexGrow: 1,
    paddingBottom: 12,
  },
  calGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  calCell: {
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginBottom: 8,
    minHeight: 72,
  },
  calCellAvailable: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.55)',
  },
  calCellUnavailable: {
    backgroundColor: 'rgba(51,65,85,0.3)',
    borderWidth: 1,
    borderColor: 'rgba(71,85,105,0.4)',
    opacity: 0.5,
  },
  calDow: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  calDowMuted: { color: 'rgba(148,163,184,0.55)' },
  calDom: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    marginTop: 4,
    fontVariant: ['tabular-nums'],
  },
  calDomMuted: { color: 'rgba(148,163,184,0.45)' },
  calTodayLbl: {
    marginTop: 4,
    fontSize: 9,
    fontWeight: '800',
    color: SKY,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  changeDateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 10,
    paddingVertical: 6,
    alignSelf: 'flex-start',
  },
  changeDateText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardsContainer: {
    width: '100%',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slotHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  slotHeaderTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  slotHeaderSub: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 3,
  },
  dateStripSection: {
    marginBottom: 14,
  },
  dateStripLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  dateStripLabel: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  datePickerLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(56,189,248,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.28)',
  },
  datePickerLinkText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  dateChipsRow: {
    gap: 10,
    paddingRight: 8,
  },
  dateChip: {
    minWidth: 72,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.35)',
    alignItems: 'center',
  },
  dateChipSelected: {
    borderColor: SKY + 'AA',
    backgroundColor: SKY + '22',
  },
  dateChipWd: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  dateChipWdSelected: {
    color: SKY,
  },
  dateChipDm: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginTop: 4,
  },
  dateChipDmSelected: {
    color: '#F9FAFB',
  },
  upcomingCard: {
    marginBottom: 16,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.35)',
    backgroundColor: 'rgba(56,189,248,0.1)',
  },
  upcomingCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  upcomingKicker: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.55,
    textTransform: 'uppercase',
  },
  upcomingHub: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  upcomingService: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 14,
  },
  upcomingWhenRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upcomingWhenBlock: {
    minWidth: 88,
  },
  upcomingWhenDivider: {
    width: 1,
    height: 40,
    backgroundColor: 'rgba(148,163,184,0.25)',
    marginHorizontal: 14,
  },
  upcomingWhenValue: {
    color: SKY,
    fontSize: 26,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
  },
  upcomingWhenDate: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  upcomingWhenHint: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 4,
  },
  calendarHintRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.28)',
  },
  calendarHintText: {
    flex: 1,
    color: 'rgba(203,213,225,0.9)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 17,
  },
  timesSectionTitle: {
    color: 'rgba(226,232,240,0.92)',
    fontSize: 13,
    fontWeight: '800',
    marginBottom: 10,
  },
  noTimesForDay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(30,41,59,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    marginBottom: 12,
  },
  noTimesForDayText: {
    flex: 1,
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  },
  slotCardMainRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  slotTimeColumn: {
    flex: 1,
    minWidth: 0,
  },
  slotTimeHuge: {
    color: '#F9FAFB',
    fontSize: 34,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
    letterSpacing: -0.5,
  },
  slotTimeSub: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 6,
  },
  slotSelectBadge: {
    marginLeft: 12,
  },
  slotSelectBadgeOn: {},
  slotDurationCaption: {
    marginTop: 12,
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },
  swipeHintRow: {
    marginTop: 12,
  },
  continueBar: {
    marginTop: 14,
    paddingHorizontal: 0,
  },
  continueCta: {
    flex: 0,
    alignSelf: 'stretch',
    width: '100%',
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
    overflow: 'hidden',
  },
  continueCtaText: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    color: SKY,
    includeFontPadding: false,
  },
  iosPickerRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  iosPickerBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.65)',
  },
  iosPickerSheet: {
    backgroundColor: '#0F172A',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
  },
  iosPickerToolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.2)',
  },
  iosPickerCancel: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '600',
  },
  iosPickerTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  iosPickerDone: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  refreshBtn: {
    width: 38,
    height: 38,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(135,206,235,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotRow: { 
    paddingVertical: 4, 
    paddingRight: 28,
  },
  cardWrapper: {
    marginRight: 12,
  },
  slotCard: {
    width: '100%',
    padding: 16,
    overflow: 'hidden',
    borderRadius: 14,
  },
  slotSelected: {},
  slotCardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  slotCardMain: {
    flex: 1,
    minWidth: 0,
  },
  slotCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  slotDateText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 4,
  },
  slotMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '700',
  },
  slotClockBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  digitalClockFace: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  digitalClockFaceSelected: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderColor: SKY,
  },
  digitalClockDigits: {
    color: SKY,
    fontSize: 18,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
    letterSpacing: 1,
  },
  digitalClockLabel: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 9,
    fontWeight: '600',
    marginTop: 2,
    textTransform: 'uppercase',
  },
  digitalClockBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  digitalClockInner: {
    flex: 1,
  },
  digitalClockTime: {
    color: SKY,
    fontSize: 28,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
    letterSpacing: 2,
  },
  digitalClockDate: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
  },
  emptySlotsCard: {
    padding: 14,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '900' },
  emptySub: { color: 'rgba(249,250,251,0.75)', fontSize: 12, marginTop: 4, lineHeight: 18 },
  ctaWrapper: {
    marginTop: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
});
