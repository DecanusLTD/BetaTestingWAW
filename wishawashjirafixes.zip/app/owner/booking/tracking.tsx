import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  Easing,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { supabase } from '../../../src/lib/supabase';
import { colors } from '../../../src/constants/colors';
import AppHeader from '../../../src/components/shared/AppHeader';
import {
  HEADER_STYLE_CARD_GRADIENT,
} from '../../../src/constants/bookingCardTheme';
import CustomerMapTrackingSheetShell, {
  customerMapTrackingSheetActionStyles,
  trackingInnerLayoutStyles,
} from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { WWSheetCloseButton } from '../../../src/components/ui';
import { setPendingRatingBookingId } from '../../../src/utils/pendingCustomerRating';
import {
  getStatusMessage,
  getStages,
  getStageProgressPercent,
  getRingColorForStep,
  isCustomerDetailingService,
  normalizeStatusForTracking,
} from '../../../src/utils/trackingStatusHelpers';
import { removeBookingFromDeviceCalendar } from '../../../src/services/BookingCalendarSync';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import BookingPaymentSheet from '../../../src/components/booking/BookingPaymentSheet';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { CCP, ccpFallbackName, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { fetchValeterIdentity, resolveValeterDisplayName } from '../../../src/utils/valeterDisplayName';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { getServiceDisplayName, getServiceDescription } from '../../../src/utils/serviceNameMapper';
import { serviceOptions, detailingServiceOptions, repairServiceOptions } from '../../../src/constants/serviceOptions';
import { DONE_STAGE_VIDEO, WASHING_STAGE_VIDEO } from '../../../assets/assetExports';
import FrozenBookingMapStage from '../../../src/components/booking/FrozenBookingMapStage';
import LiveEnRouteFollowMap from '../../../src/components/booking/LiveEnRouteFollowMap';
import { frozenMapViewFromCoords } from '../../../src/utils/frozenBookingMapView';
import { distanceMiles } from '../../../src/utils/mapUtils';

/** Start camera-follow of the Care Pro once they are within this range. */
const EN_ROUTE_FOLLOW_MILES = 2;

const SKY = colors.SKY ?? '#38BDF8';

function moneyGBP(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

/** Price line in details: show em dash when total not stored yet */
function moneyGBPOrDash(value: unknown) {
  if (value == null || value === '') return '—';
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(2);
}

function bookingIdFromSearchParams(params: { bookingId?: string | string[] }): string {
  const v = params.bookingId;
  if (typeof v === 'string' && v.length > 0) return v;
  if (Array.isArray(v) && typeof v[0] === 'string' && v[0].length > 0) return v[0];
  return '';
}

function normalizeBookingRow(raw: Record<string, unknown> | null | undefined): BookingRow | null {
  if (!raw || typeof raw !== 'object') return null;
  const locRaw = raw.location;
  let locLat: number | undefined;
  let locLng: number | undefined;
  let locAddress: string | undefined;
  if (locRaw && typeof locRaw === 'object') {
    const o = locRaw as Record<string, unknown>;
    const la = o.latitude ?? o.lat;
    const lo = o.longitude ?? o.lng;
    if (typeof la === 'number' && Number.isFinite(la)) locLat = la;
    else if (typeof la === 'string') {
      const n = parseFloat(la);
      if (Number.isFinite(n)) locLat = n;
    }
    if (typeof lo === 'number' && Number.isFinite(lo)) locLng = lo;
    else if (typeof lo === 'string') {
      const n = parseFloat(lo);
      if (Number.isFinite(n)) locLng = n;
    }
    if (typeof o.address === 'string' && o.address.trim()) locAddress = o.address.trim();
  }

  const numOrNull = (v: unknown): number | null => {
    if (v == null || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v));
    return Number.isFinite(n) ? n : null;
  };

  const lat = numOrNull(raw.location_lat) ?? (locLat != null ? locLat : null);
  const lng = numOrNull(raw.location_lng) ?? (locLng != null ? locLng : null);
  const flatAddr = typeof raw.location_address === 'string' ? raw.location_address.trim() : '';
  const location_address = flatAddr || locAddress || null;

  return {
    id: String(raw.id ?? ''),
    status: String(raw.status ?? 'pending_valeter_acceptance'),
    service_type:
      raw.service_type != null && String(raw.service_type).trim() ? String(raw.service_type).trim() : null,
    service_name:
      raw.service_name != null && String(raw.service_name).trim() ? String(raw.service_name).trim() : null,
    location_lat: lat,
    location_lng: lng,
    location_address,
    valeter_id: raw.valeter_id != null ? String(raw.valeter_id) : null,
    cancelled_by:
      raw.cancelled_by != null && String(raw.cancelled_by).trim()
        ? String(raw.cancelled_by).trim().toLowerCase()
        : null,
    updated_at: raw.updated_at != null ? String(raw.updated_at) : null,
    price: numOrNull(raw.price),
    add_ons_total: numOrNull(raw.add_ons_total),
    discount_amount: numOrNull(raw.discount_amount),
    platform_fee_amount: numOrNull(raw.platform_fee_amount),
    wash_type: raw.wash_type != null ? String(raw.wash_type) : null,
    vehicle_info:
      raw.vehicle_info != null && String(raw.vehicle_info).trim() ? String(raw.vehicle_info).trim() : null,
    vehicle_type:
      raw.vehicle_type != null && String(raw.vehicle_type).trim() ? String(raw.vehicle_type).trim() : null,
  };
}

function getServiceSummaryLines(serviceType: string | null, serviceName: string | null): string[] {
  const display = getServiceDisplayName(serviceType, serviceName);
  const isDetailing =
    (serviceType || '').toLowerCase().includes('detail') ||
    display.toLowerCase().includes('detail');
  const allPackages = [...serviceOptions, ...detailingServiceOptions, ...repairServiceOptions];
  const opts = isDetailing ? [...detailingServiceOptions, ...repairServiceOptions] : serviceOptions;
  let opt = serviceType ? allPackages.find((o) => o.id === serviceType) : undefined;
  if (!opt && serviceType) opt = opts.find((o) => o.id === serviceType);
  if (!opt) opt = allPackages.find((o) => o.name === display);
  if (opt?.confirmationSummary?.length) return opt.confirmationSummary;
  if (opt?.bulletPoints?.length) return opt.bulletPoints.slice(0, 8);
  return [getServiceDescription(display)];
}

type BookingRow = {
  id: string;
  status: string;
  service_type: string | null;
  service_name: string | null;
  location_lat: number | null;
  location_lng: number | null;
  location_address: string | null;
  valeter_id: string | null;
  cancelled_by?: string | null;
  updated_at?: string | null;
  price?: number | null;
  add_ons_total?: number | null;
  discount_amount?: number | null;
  platform_fee_amount?: number | null;
  wash_type?: string | null;
  vehicle_info?: string | null;
  vehicle_type?: string | null;
};

type ValeterInfo = {
  fullName: string;
  photoUrl: string | null;
  totalJobs: number;
  reviews: number;
  rating: number;
  experienceMonths: number;
  onTimePercentage: number;
};

function statusTitle(status: string): string {
  if (status === 'pending_valeter_acceptance') return `Connecting to your ${CCP.singularShort}`;
  if (status === 'pending_payment') return 'Awaiting payment';
  if (status === 'scheduled') return 'Accepted';
  if (status === 'confirmed' || status === 'valeter_assigned') return 'Accepted';
  if (status === 'en_route') return 'On the way';
  if (status === 'arrived') return 'Arrived';
  if (status === 'in_progress') return 'In progress';
  if (status === 'completed') return 'Completed';
  if (status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout') {
    return 'Booking cancelled';
  }
  return 'Tracking';
}

function isCustomerInitiatedCancel(cancelledBy?: string | null): boolean {
  const v = (cancelledBy || '').toLowerCase();
  return v === 'customer' || v === 'user' || v === 'owner';
}

function isTerminalCancelStatus(status: string): boolean {
  return status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout';
}

function cancelExitCopy(
  status: string,
  cancelledBy?: string | null,
): { title: string; message: string } {
  const s = (status || '').toLowerCase();
  const by = (cancelledBy || '').toLowerCase();
  if (s === 'valeter_declined') {
    return {
      title: 'Pro declined',
      message: `Your ${ccpSingularLower()} declined this booking. You can book again anytime.`,
    };
  }
  if (s === 'valeter_timeout') {
    return {
      title: 'Pro timed out',
      message: `Your ${ccpSingularLower()} didn’t respond in time. This booking was cancelled.`,
    };
  }
  if (by.includes('valeter') || by === 'pro') {
    return {
      title: 'Pro cancelled',
      message: `Your ${ccpSingularLower()} cancelled this booking. You can book again anytime.`,
    };
  }
  if (by === 'system') {
    return {
      title: 'Booking cancelled',
      message: 'This booking was cancelled automatically. You can book again anytime.',
    };
  }
  return {
    title: 'Booking cancelled',
    message: 'This booking was cancelled. You can book again anytime.',
  };
}

const TRACK_STEPS = [
  { key: 'confirmed', label: 'Accepted', icon: 'checkmark-circle-outline' as const },
  { key: 'en_route', label: 'On the way', icon: 'car-outline' as const },
  { key: 'arrived', label: 'Arrived', icon: 'location-outline' as const },
  { key: 'in_progress', label: 'Washing', icon: 'water-outline' as const },
  { key: 'completed', label: 'Done', icon: 'sparkles-outline' as const },
];

const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';

const TRACKING_PAGE_SHEET_SCALE = 1;

export default function BookingTrackingRedesigned() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = bookingIdFromSearchParams(params as { bookingId?: string | string[] });
  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterLoc, setValeterLoc] = useState<{ latitude: number; longitude: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWasherSheet, setShowWasherSheet] = useState(false);
  const [washerLoading, setWasherLoading] = useState(false);
  const [washerInfo, setWasherInfo] = useState<ValeterInfo | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [valeterName, setValeterName] = useState<string>(ccpFallbackName());
  const [secondsLeft, setSecondsLeft] = useState(10 * 60);
  const [paymentSecondsLeft, setPaymentSecondsLeft] = useState(5 * 60);
  const [openingChat, setOpeningChat] = useState(false);
  const [showPaymentSheet, setShowPaymentSheet] = useState(false);
  const stepPulse = useRef(new Animated.Value(0)).current;
  const stageGlow = useRef(new Animated.Value(0)).current;
  const ctaPulse = useRef(new Animated.Value(0)).current;
  const hasAutoCancelledRef = useRef(false);
  const hasPaymentTimedOutRef = useRef(false);
  const userCancelledRef = useRef(false);
  /** Prevents double navigation when cancel / timeout / Pro cancel fire together. */
  const leftTrackingRef = useRef(false);
  /** Ensures we only auto-navigate to rate & tip once when the job completes. */
  const hasNavigatedToCompletionRef = useRef(false);
  /** 2s Done-stage delay before opening the rating screen. */
  const completionNavTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** True while the delayed navigation is scheduled but has not run yet. */
  const completionNavScheduledRef = useRef(false);

  const loadBooking = useCallback(async () => {
    if (!bookingId) return;
    let q = supabase.from('bookings').select('*').eq('id', bookingId);
    if (user?.id) {
      q = q.eq('user_id', user.id);
    }
    const { data, error } = await q.maybeSingle();
    if (error) {
      if (__DEV__) console.warn('[tracking] loadBooking', error.message);
      setBooking(null);
      setLoading(false);
      return;
    }
    const row = normalizeBookingRow(data as Record<string, unknown>);
    if (!row || !row.id) {
      setBooking(null);
      setLoading(false);
      return;
    }
    setBooking(row);
    if (row.valeter_id) {
      const identity = await fetchValeterIdentity(row.valeter_id);
      setValeterName(identity.name);
      const { data: p } = await supabase
        .from('valeter_presence')
        .select('last_lat,last_lng')
        .eq('user_id', row.valeter_id)
        .maybeSingle();
      if (p?.last_lat != null && p?.last_lng != null) {
        setValeterLoc({ latitude: Number(p.last_lat), longitude: Number(p.last_lng) });
      } else {
        setValeterLoc(null);
      }
    } else {
      setValeterName(ccpFallbackName());
      setValeterLoc(null);
    }
    setLoading(false);
  }, [bookingId, user?.id]);

  useEffect(() => {
    if (!bookingId) {
      router.replace('/owner/owner-dashboard' as any);
      return;
    }
    void loadBooking();
    const timer = setInterval(() => {
      void loadBooking();
    }, 15000);
    return () => clearInterval(timer);
  }, [bookingId, loadBooking]);

  useEffect(() => {
    if (!bookingId) return;
    const channel = supabase
      .channel(`tracking-booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        () => {
          void loadBooking();
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, loadBooking]);

  useEffect(() => {
    hasNavigatedToCompletionRef.current = false;
    userCancelledRef.current = false;
    leftTrackingRef.current = false;
    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }
    completionNavScheduledRef.current = false;
  }, [bookingId]);

  const exitTrackingToDashboard = useCallback((title: string, message: string) => {
    if (leftTrackingRef.current) return;
    leftTrackingRef.current = true;
    setShowWasherSheet(false);
    setShowPaymentSheet(false);
    router.replace('/owner/owner-dashboard');
    setTimeout(() => {
      Alert.alert(title, message);
    }, 400);
  }, []);

  useEffect(() => {
    if (!booking?.id || loading) return;
    if (!isTerminalCancelStatus(booking.status)) return;
    if (userCancelledRef.current || isCustomerInitiatedCancel(booking.cancelled_by)) return;
    if (leftTrackingRef.current) return;
    const copy = cancelExitCopy(booking.status, booking.cancelled_by);
    void removeBookingFromDeviceCalendar(booking.id);
    exitTrackingToDashboard(copy.title, copy.message);
  }, [booking?.id, booking?.status, booking?.cancelled_by, loading, exitTrackingToDashboard]);

  const bookingStatus = booking?.status;
  const bookingIdRef = useRef(bookingId);
  bookingIdRef.current = bookingId;

  useEffect(() => {
    if (!bookingId || loading) return;
    if (bookingStatus !== 'completed') return;
    if (hasNavigatedToCompletionRef.current) return;

    if (completionNavTimerRef.current) {
      clearTimeout(completionNavTimerRef.current);
      completionNavTimerRef.current = null;
    }

    completionNavScheduledRef.current = true;
    completionNavTimerRef.current = setTimeout(() => {
      completionNavTimerRef.current = null;
      completionNavScheduledRef.current = false;
      hasNavigatedToCompletionRef.current = true;
      void hapticFeedback('success');
      router.replace({
        pathname: '/owner/booking/completion',
        params: { bookingId, celebrated: '1' },
      } as any);
    }, 2000);

    return () => {
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, [bookingStatus, bookingId, loading]);

  useEffect(() => {
    return () => {
      if (completionNavScheduledRef.current) {
        void setPendingRatingBookingId(bookingIdRef.current);
      }
      if (completionNavTimerRef.current) {
        clearTimeout(completionNavTimerRef.current);
        completionNavTimerRef.current = null;
      }
      completionNavScheduledRef.current = false;
    };
  }, []);

  useEffect(() => {
    const vid = booking?.valeter_id;
    if (!vid) return;
    const channel = supabase
      .channel(`tracking-presence-${vid}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${vid}`,
        },
        (payload) => {
          const n = payload.new as { last_lat?: number; last_lng?: number };
          if (n?.last_lat != null && n?.last_lng != null) {
            setValeterLoc({ latitude: Number(n.last_lat), longitude: Number(n.last_lng) });
          }
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [booking?.valeter_id]);

  const loadWasherInfo = useCallback(async () => {
    const valeterId = booking?.valeter_id;
    if (!valeterId) {
      setWasherInfo(null);
      return;
    }
    setWasherLoading(true);
    try {
      const [profileRes, fallbackRes, stats] = await Promise.all([
        supabase
          .from('valeter_profiles')
          .select('full_name, profile_photo_url')
          .eq('user_id', valeterId)
          .maybeSingle(),
        supabase
          .from('profiles')
          .select('full_name, profile_picture')
          .eq('id', valeterId)
          .maybeSingle(),
        ValeterStatsService.getValeterStats(valeterId),
      ]);
      const profile = profileRes.data as { full_name?: string | null; profile_photo_url?: string | null } | null;
      const fallback = fallbackRes.data as { full_name?: string | null; profile_picture?: string | null } | null;
      setWasherInfo({
        fullName: resolveValeterDisplayName(profile?.full_name, fallback?.full_name, valeterName),
        photoUrl: profile?.profile_photo_url || fallback?.profile_picture || null,
        totalJobs: stats.totalJobs || 0,
        reviews: stats.customerReviews || 0,
        rating: stats.averageRating || 0,
        experienceMonths: stats.experienceMonths || 1,
        onTimePercentage: stats.onTimePercentage || 0,
      });
    } catch {
      setWasherInfo({
        fullName: valeterName || ccpFallbackName(),
        photoUrl: null,
        totalJobs: 0,
        reviews: 0,
        rating: 0,
        experienceMonths: 1,
        onTimePercentage: 0,
      });
    } finally {
      setWasherLoading(false);
    }
  }, [booking?.valeter_id, valeterName]);

  const cancelBooking = useCallback(async () => {
    if (!booking?.id || cancelling) return;
    const uid = user?.id;
    if (!uid) {
      Alert.alert('Sign in required', 'Please sign in again to cancel this booking.');
      return;
    }
    setCancelling(true);
    userCancelledRef.current = true;
    leftTrackingRef.current = true;
    const cancelledBookingId = booking.id;
    try {
      const { data: updatedRow, error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer from tracking',
        })
        .eq('id', cancelledBookingId)
        .eq('user_id', uid)
        .select('id')
        .maybeSingle();
      if (error) throw error;
      if (!updatedRow) {
        userCancelledRef.current = false;
        leftTrackingRef.current = false;
        Alert.alert(
          'Could not cancel',
          'Your account may not own this booking, or it was already updated. Pull to refresh or open the booking from My washes.',
        );
        return;
      }
      void removeBookingFromDeviceCalendar(cancelledBookingId);
      setShowWasherSheet(false);
      setShowPaymentSheet(false);
      router.replace('/owner/owner-dashboard');
    } catch (e: unknown) {
      userCancelledRef.current = false;
      leftTrackingRef.current = false;
      const msg = e && typeof e === 'object' && 'message' in e ? String((e as { message?: string }).message) : '';
      Alert.alert(
        'Could not cancel',
        msg
          ? `${msg}\n\nIf this keeps happening, check that you own this booking and it can still be cancelled.`
          : 'Please try again in a moment.',
      );
    } finally {
      setCancelling(false);
    }
  }, [booking?.id, cancelling, user?.id]);

  const autoCancelBookingOnTimeout = useCallback(async () => {
    if (!booking?.id || leftTrackingRef.current) return;
    leftTrackingRef.current = true;
    try {
      await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'system',
          cancellation_reason: 'No Pro accepted within the matching window',
        })
        .eq('id', booking.id)
        .eq('status', 'pending_valeter_acceptance');
      void removeBookingFromDeviceCalendar(booking.id);
    } catch {
      // Still leave tracking so the customer is not stuck on a dead matching screen.
    }
    setShowWasherSheet(false);
    setShowPaymentSheet(false);
    router.replace('/owner/owner-dashboard');
    setTimeout(() => {
      Alert.alert(
        'Matching timed out',
        `No ${ccpSingularLower()} accepted in time. This booking was cancelled — you can book again anytime.`,
      );
    }, 400);
  }, [booking?.id]);

  const autoCancelUnpaidBooking = useCallback(async () => {
    if (!booking?.id || hasPaymentTimedOutRef.current || leftTrackingRef.current) return;
    hasPaymentTimedOutRef.current = true;
    leftTrackingRef.current = true;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_by: 'system',
          cancellation_reason: 'Payment window expired',
        })
        .eq('id', booking.id)
        .eq('status', 'pending_payment');
      if (error) throw error;
      void removeBookingFromDeviceCalendar(booking.id);
      setShowPaymentSheet(false);
      router.replace('/owner/owner-dashboard');
      setTimeout(() => {
        Alert.alert(
          'Payment timed out',
          'You have 5 minutes to pay after a Pro accepts. This booking was cancelled — you can book again anytime.',
        );
      }, 400);
    } catch {
      hasPaymentTimedOutRef.current = false;
      leftTrackingRef.current = false;
      Alert.alert('Payment window ended', 'Please check your booking status or try booking again.');
    }
  }, [booking?.id]);

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(stepPulse, {
          toValue: 1,
          duration: 620,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(stepPulse, {
          toValue: 0,
          duration: 620,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ]),
    );
    pulseLoop.start();
    return () => {
      pulseLoop.stop();
    };
  }, [stepPulse]);

  useEffect(() => {
    // Stage transition flash on card whenever status or payment state changes.
    stageGlow.setValue(0);
    Animated.sequence([
      Animated.timing(stageGlow, { toValue: 1, duration: 260, useNativeDriver: true }),
      Animated.timing(stageGlow, { toValue: 0, duration: 520, useNativeDriver: true }),
    ]).start();
  }, [booking?.status, stageGlow]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(ctaPulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(ctaPulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [ctaPulse]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') {
      hasAutoCancelledRef.current = false;
      setSecondsLeft(10 * 60);
      return;
    }
    const id = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(id);
  }, [booking?.status]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_valeter_acceptance') return;
    if (secondsLeft > 0) return;
    if (hasAutoCancelledRef.current) return;
    hasAutoCancelledRef.current = true;
    void autoCancelBookingOnTimeout();
  }, [secondsLeft, booking?.status, autoCancelBookingOnTimeout]);

  const PAYMENT_WINDOW_SEC = 5 * 60;

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_payment') {
      hasPaymentTimedOutRef.current = false;
      setPaymentSecondsLeft(PAYMENT_WINDOW_SEC);
      return;
    }
    const startedMs = booking?.updated_at ? Date.parse(booking.updated_at) : NaN;
    const base = Number.isFinite(startedMs) ? startedMs : Date.now();
    const tick = () => {
      const elapsed = Math.floor((Date.now() - base) / 1000);
      setPaymentSecondsLeft(Math.max(0, PAYMENT_WINDOW_SEC - elapsed));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [booking?.status, booking?.updated_at]);

  useEffect(() => {
    if ((booking?.status || '') !== 'pending_payment') return;
    if (paymentSecondsLeft > 0) return;
    if (hasPaymentTimedOutRef.current) return;
    void autoCancelUnpaidBooking();
  }, [paymentSecondsLeft, booking?.status, autoCancelUnpaidBooking]);

  const isDetailingJob = useMemo(
    () => isCustomerDetailingService(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const stages = useMemo(
    () => getStages((booking?.status as any) || 'pending_valeter_acceptance', isDetailingJob, false),
    [booking?.status, isDetailingJob],
  );
  const stageProgressPercent = useMemo(
    () => getStageProgressPercent((booking?.status as any) || 'pending_valeter_acceptance', isDetailingJob, false),
    [booking?.status, isDetailingJob],
  );
  const statusRingColor = useMemo(
    () => getRingColorForStep((booking?.status as any) || 'pending_valeter_acceptance') || ECO_GREEN,
    [booking?.status],
  );
  const currentStepScale = stepPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.1],
  });
  const currentStepOpacity = stepPulse.interpolate({
    inputRange: [0, 1],
    outputRange: [0.92, 1],
  });
  const paymentCompleted = (booking?.status || '') !== 'pending_payment';
  const chatLocked =
    !paymentCompleted ||
    (booking?.status || '') === 'pending_valeter_acceptance' ||
    (booking?.status || '') === 'pending' ||
    (booking?.status || '') === 'pending_business_acceptance';
  const chatLockReason = !paymentCompleted
    ? { title: 'Payment needed', message: 'Finish payment first, then you can message your Care Pro.' }
    : {
        title: 'Still connecting',
        message: `Chat unlocks once your ${ccpSingularLower()} accepts the booking.`,
      };
  const primarySheetAction = useMemo(() => {
    const s = booking?.status || '';
    if (s === 'pending_payment') {
      const mins = Math.floor(paymentSecondsLeft / 60);
      const secs = paymentSecondsLeft % 60;
      const clock = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      return {
        kind: 'pay' as const,
        label: paymentSecondsLeft > 0 ? `Pay now · ${clock}` : 'Pay now',
        icon: 'wallet-outline' as keyof typeof Ionicons.glyphMap,
        accent: paymentSecondsLeft <= 60 ? '#EF4444' : ECO_GREEN,
      };
    }
    return {
      kind: 'details' as const,
      label: 'Your Wish',
      icon: 'sparkles-outline' as keyof typeof Ionicons.glyphMap,
      accent: SKY,
    };
  }, [booking?.status, paymentSecondsLeft]);
  const ctaScale = ctaPulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.01] });
  const ctaGlowOpacity = ctaPulse.interpolate({ inputRange: [0, 1], outputRange: [0.2, 0.5] });
  const stageGlowOpacity = stageGlow.interpolate({ inputRange: [0, 1], outputRange: [0.02, 0.38] });
  const timerLabel = useMemo(() => {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [secondsLeft]);
  const timerAccent = useMemo(() => {
    if (secondsLeft <= 60) return '#EF4444';
    if (secondsLeft <= 180) return ECO_GREEN;
    return SKY;
  }, [secondsLeft]);
  const connectProgressPercent = useMemo(() => {
    const total = 10 * 60;
    return Math.max(0, Math.min(100, Math.round(((total - secondsLeft) / total) * 100)));
  }, [secondsLeft]);
  const timerHint = useMemo(() => {
    if (secondsLeft <= 60) return 'Final minute to match';
    if (secondsLeft <= 180) return 'Matching soon';
    return `Connecting to your ${CCP.singularShort}`;
  }, [secondsLeft]);
  const isAwaitingPro = (booking?.status || '') === 'pending_valeter_acceptance';
  const normalizedStatus = normalizeStatusForTracking(String(booking?.status ?? ''));
  const customerCoord = useMemo(() => {
    const lat = booking?.location_lat;
    const lng = booking?.location_lng;
    if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
      return null;
    }
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [booking?.location_lat, booking?.location_lng]);
  const frozenMapView = useMemo(() => {
    if (!customerCoord) return null;
    return frozenMapViewFromCoords(customerCoord.latitude, customerCoord.longitude, insets.bottom);
  }, [customerCoord, insets.bottom]);

  const bookingServiceDisplay = useMemo(
    () => getServiceDisplayName(booking?.service_type, booking?.service_name),
    [booking?.service_type, booking?.service_name],
  );
  const serviceSummaryLines = useMemo(
    () => getServiceSummaryLines(booking?.service_type ?? null, booking?.service_name ?? null),
    [booking?.service_type, booking?.service_name],
  );
  const currentStatusTitle = statusTitle(booking?.status || 'tracking');
  const currentStatusMessage = getStatusMessage(
    (booking?.status as any) || 'pending_valeter_acceptance',
    null,
    isDetailingJob,
  );

  const isEnRouteOrArrived = normalizedStatus === 'en_route' || normalizedStatus === 'arrived';
  const milesToCustomer = useMemo(() => {
    if (!customerCoord || !valeterLoc) return null;
    return distanceMiles(valeterLoc, customerCoord);
  }, [customerCoord, valeterLoc]);
  const followValeterOnMap =
    isEnRouteOrArrived && milesToCustomer != null && milesToCustomer <= EN_ROUTE_FOLLOW_MILES;
  /** Live map (Pro + car) during On the way / Arrived when we have both coords. */
  const showLiveEnRouteMap = Boolean(isEnRouteOrArrived && customerCoord && valeterLoc);
  /** Parked car map until On the way, or when Pro location is not available yet. */
  const showFrozenParkedMap = Boolean(
    frozenMapView &&
      (normalizedStatus === 'pending_valeter_acceptance' ||
        normalizedStatus === 'pending_payment' ||
        normalizedStatus === 'confirmed' ||
        normalizedStatus === 'valeter_assigned' ||
        (isEnRouteOrArrived && !valeterLoc)),
  );
  const showMapStage = showLiveEnRouteMap || showFrozenParkedMap;

  /** Stage videos only for washing/detailing and done — earlier steps use the map. */
  const trackingStageVideoSource = useMemo(() => {
    if (normalizedStatus === 'in_progress') return WASHING_STAGE_VIDEO;
    if (normalizedStatus === 'completed') return DONE_STAGE_VIDEO;
    return null;
  }, [normalizedStatus]);

  const showStatusSubtext =
    currentStatusMessage.trim().toLowerCase() !== currentStatusTitle.trim().toLowerCase();

  useEffect(() => {
    if (!booking?.valeter_id) return;
    void loadWasherInfo();
  }, [booking?.valeter_id, loadWasherInfo]);

  const liveProName = useMemo(() => {
    const raw = washerInfo?.fullName || valeterName || '';
    const trimmed = formatDisplayName(raw) || raw.trim();
    if (!trimmed || trimmed === ccpFallbackName()) return null;
    return trimmed;
  }, [washerInfo?.fullName, valeterName]);

  const liveCardAccent = isAwaitingPro ? timerAccent : statusRingColor;
  const connectingCardInner = (
    <Animated.View
      style={[
        styles.gamifiedCardWrap,
        styles.gamifiedCardLower,
        styles.liveCardShell,
        { borderColor: liveCardAccent + '8A', shadowColor: liveCardAccent },
      ]}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          StyleSheet.absoluteFillObject,
          styles.gamifiedStageOverlay,
          { backgroundColor: liveCardAccent, opacity: stageGlowOpacity },
        ]}
      />
      <View style={trackingInnerLayoutStyles.row}>
        <View style={[trackingInnerLayoutStyles.body, styles.liveCardBody]}>
          <Text style={trackingInnerLayoutStyles.kicker} numberOfLines={1}>
            {bookingServiceDisplay || CCP.singularShort}
          </Text>
          <Text style={[trackingInnerLayoutStyles.status, { color: liveCardAccent }]} numberOfLines={2}>
            {`Connecting to your ${CCP.singularShort}`}
          </Text>
          <Text style={styles.liveStatusSubtext} numberOfLines={2}>
            {liveProName
              ? 'Waiting for them to accept'
              : `Matching a nearby ${CCP.singularShort.toLowerCase()}`}
          </Text>
        </View>
        <Animated.View style={[styles.liveRingAside, { transform: [{ scale: ctaScale }] }]}>
          <AnimatedProgress
            progress={connectProgressPercent}
            size={64}
            strokeWidth={3.5}
            showPercentage={false}
            color={liveCardAccent}
            light
            centerContent={
              <View style={styles.liveRingCenter}>
                <Text style={[styles.liveTimerCompact, { color: liveCardAccent }]}>{timerLabel}</Text>
                <Text style={[styles.liveTimerMini, { color: liveCardAccent }]} numberOfLines={1}>
                  {secondsLeft <= 60 ? 'Hurry' : secondsLeft <= 180 ? 'Soon' : 'Live'}
                </Text>
              </View>
            }
          />
        </Animated.View>
      </View>
      <View style={styles.liveProRow}>
        {washerInfo?.photoUrl ? (
          <Image source={{ uri: washerInfo.photoUrl }} style={styles.liveAvatarSm} />
        ) : (
          <View style={[styles.liveAvatarSmFallback, { backgroundColor: liveCardAccent + '28' }]}>
            <Ionicons name={liveProName ? 'person' : 'search-outline'} size={14} color={liveCardAccent} />
          </View>
        )}
        <Text style={styles.liveProName} numberOfLines={2}>
          {liveProName || `Finding your ${CCP.singularShort}`}
          {liveProName ? ' · sent' : ''}
        </Text>
      </View>
      <View style={styles.liveChipRow}>
        {['Verified', 'Insured', 'Auto-cancel'].map((label) => (
          <View key={label} style={styles.liveChip}>
            <Text style={styles.liveChipText}>{label}</Text>
          </View>
        ))}
      </View>
    </Animated.View>
  );

  const trackingCardInner = (
    <Animated.View
      style={[
        styles.gamifiedCardWrap,
        styles.gamifiedCardLower,
        styles.liveCardShell,
        { borderColor: liveCardAccent + '8A', shadowColor: liveCardAccent },
      ]}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          StyleSheet.absoluteFillObject,
          styles.gamifiedStageOverlay,
          { backgroundColor: liveCardAccent, opacity: stageGlowOpacity },
        ]}
      />
      <View style={trackingInnerLayoutStyles.row}>
        <View style={[trackingInnerLayoutStyles.body, styles.liveCardBody]}>
          <Text style={trackingInnerLayoutStyles.kicker} numberOfLines={1}>
            {bookingServiceDisplay || CCP.singularShort}
          </Text>
          <Text style={[trackingInnerLayoutStyles.status, { color: liveCardAccent }]} numberOfLines={2}>
            {currentStatusTitle}
          </Text>
          {showStatusSubtext ? (
            <Text style={styles.liveStatusSubtext} numberOfLines={2}>
              {currentStatusMessage}
            </Text>
          ) : null}
        </View>
        <Animated.View style={[styles.liveRingAside, { transform: [{ scale: ctaScale }] }]}>
          {(booking?.status || '') === 'pending_payment' ? (
            <View style={[styles.liveTimerRing, { borderColor: liveCardAccent + '90', backgroundColor: liveCardAccent + '18' }]}>
              <Text style={[styles.liveTimerCompact, { color: liveCardAccent }]}>
                {`${String(Math.floor(paymentSecondsLeft / 60)).padStart(2, '0')}:${String(paymentSecondsLeft % 60).padStart(2, '0')}`}
              </Text>
              <Text style={[styles.liveTimerMini, { color: liveCardAccent }]} numberOfLines={1}>
                {paymentSecondsLeft <= 60 ? 'Pay now' : 'To pay'}
              </Text>
            </View>
          ) : (
            <AnimatedProgress
              progress={stageProgressPercent}
              size={64}
              strokeWidth={3.5}
              showPercentage
              percentageFontSize={14}
              color={liveCardAccent}
              light
            />
          )}
        </Animated.View>
      </View>
      <View style={styles.liveProRow}>
        {washerInfo?.photoUrl ? (
          <Image source={{ uri: washerInfo.photoUrl }} style={styles.liveAvatarSm} />
        ) : (
          <View style={[styles.liveAvatarSmFallback, { backgroundColor: liveCardAccent + '28' }]}>
            <Ionicons name="person" size={14} color={liveCardAccent} />
          </View>
        )}
        <Text style={styles.liveProName} numberOfLines={2}>
          {liveProName || valeterName || CCP.singularShort}
        </Text>
      </View>
      <View style={styles.liveProgressTrack}>
        <View style={[styles.liveProgressFill, { width: `${stageProgressPercent}%`, backgroundColor: liveCardAccent }]} />
      </View>
      <View style={styles.liveStepRow}>
        {stages.map((step) => {
          const done = step.done;
          const current = step.current;
          const fallback = TRACK_STEPS.find((s) => s.label.toLowerCase() === String(step.label).toLowerCase());
          const iconName = fallback?.icon || 'ellipse-outline';
          return (
            <View
              key={step.label}
              style={[
                styles.liveStepChip,
                done && styles.liveStepChipDone,
                current && { borderColor: liveCardAccent + 'AA', backgroundColor: liveCardAccent + '22' },
              ]}
            >
              <Animated.View
                style={
                  current
                    ? { transform: [{ scale: currentStepScale }], opacity: currentStepOpacity }
                    : undefined
                }
              >
                <Ionicons
                  name={iconName}
                  size={11}
                  color={done || current ? liveCardAccent : 'rgba(148,163,184,0.85)'}
                />
              </Animated.View>
              <Text
                style={[
                  styles.liveStepChipText,
                  (done || current) && { color: liveCardAccent },
                ]}
                numberOfLines={1}
              >
                {step.label}
              </Text>
            </View>
          );
        })}
      </View>
    </Animated.View>
  );

  const cardInner = isAwaitingPro ? connectingCardInner : trackingCardInner;

  const openPrimarySheetAction = () => {
    void hapticFeedback('light');
    if (primarySheetAction.kind === 'pay') {
      if (!bookingId) return;
      setShowPaymentSheet(true);
      return;
    }
    setShowWasherSheet(true);
    void loadWasherInfo();
  };

  const openTrackingChat = useCallback(() => {
    if (!bookingId || openingChat) return;
    if (chatLocked) {
      Alert.alert(chatLockReason.title, chatLockReason.message);
      return;
    }
    setOpeningChat(true);
    void hapticFeedback('light');
    router.push({ pathname: '/owner/booking/chat', params: { bookingId } });
    setTimeout(() => setOpeningChat(false), 900);
  }, [bookingId, openingChat, chatLocked, chatLockReason.message, chatLockReason.title]);

  const cancelBookingButton = (
    <WWSheetCloseButton
      variant="bordered"
      size={46}
      iconSize={18}
      iconColor="#EF4444"
      borderColor="rgba(239,68,68,0.55)"
      loading={cancelling}
      onPress={() => {
        Alert.alert(
          'Cancel booking?',
          'This will cancel your active booking.',
          [
            { text: 'Keep booking', style: 'cancel' },
            { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
          ],
        );
      }}
      accessibilityLabel="Cancel booking"
    />
  );

  const chatActionButton = (
    <TouchableOpacity
      style={[styles.trackActionIconBtn, (chatLocked || openingChat) && styles.trackActionIconBtnDisabled]}
      onPress={openTrackingChat}
      activeOpacity={0.85}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      accessibilityRole="button"
      accessibilityLabel={chatLocked ? 'Chat locked' : 'Open chat'}
      disabled={openingChat}
    >
      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={[
          !chatLocked ? 'rgba(56,189,248,0.34)' : 'rgba(148,163,184,0.24)',
          'rgba(15,23,42,0.65)',
        ]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <Ionicons
        name={chatLocked ? 'lock-closed' : 'chatbubble-ellipses-outline'}
        size={18}
        color={!chatLocked ? SKY : 'rgba(148,163,184,0.85)'}
        style={{ zIndex: 1 }}
      />
    </TouchableOpacity>
  );

  const actionRow = (
    <View style={[customerMapTrackingSheetActionStyles.bookingInfoRow, styles.actionRowLower]}>
      {cancelBookingButton}
      <Animated.View style={[styles.bookingDetailsCtaWrap, { transform: [{ scale: ctaScale }] }]}>
        <TouchableOpacity
          style={[
            customerMapTrackingSheetActionStyles.bookingInfoActionCard,
            customerMapTrackingSheetActionStyles.bookingInfoCard,
            styles.bookingDetailsBtn,
            { borderColor: primarySheetAction.accent + '8A' },
          ]}
          onPress={openPrimarySheetAction}
          activeOpacity={0.85}
        >
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[primarySheetAction.accent + '59', 'rgba(15,23,42,0.65)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Animated.View
            pointerEvents="none"
            style={[StyleSheet.absoluteFillObject, { opacity: ctaGlowOpacity, backgroundColor: primarySheetAction.accent + '45' }]}
          />
          <Ionicons name={primarySheetAction.icon} size={20} color={primarySheetAction.accent} style={{ zIndex: 1 }} />
          <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
            <Text
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoCardText,
                styles.bookingDetailsTextFix,
                { color: primarySheetAction.accent },
              ]}
            >
              {primarySheetAction.label}
            </Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
      {chatActionButton}
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={StyleSheet.absoluteFill}>
        {showLiveEnRouteMap && customerCoord && valeterLoc ? (
          <LiveEnRouteFollowMap
            customer={customerCoord}
            valeter={valeterLoc}
            followValeter={followValeterOnMap}
          />
        ) : showFrozenParkedMap && frozenMapView ? (
          <FrozenBookingMapStage mapView={frozenMapView} />
        ) : trackingStageVideoSource ? (
          <Video
            key={normalizedStatus}
            source={trackingStageVideoSource}
            style={StyleSheet.absoluteFill}
            resizeMode={ResizeMode.COVER}
            shouldPlay
            isLooping
            isMuted
          />
        ) : (
          <LinearGradient
            colors={['#0c1929', '#020617', '#0f172a']}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        )}
      </View>
      <AppHeader
        title="Live tracking"
        subtitle={booking?.location_address?.trim() || undefined}
        showBack
        fullWidth
        accountType="customer"
        bookingSheetHeaderChrome
        onBack={() => router.back()}
      />
      <CustomerMapTrackingSheetShell
        accentColor={SKY}
        showInfoButton={false}
        showChatButton={false}
        onDragDismiss={() => router.back()}
        bottomOffset={0}
        fitContent
        sheetHeightScale={TRACKING_PAGE_SHEET_SCALE}
        cardInner={cardInner}
        actionRow={actionRow}
        panelFooter={null}
      />
      <BookingPaymentSheet
        visible={showPaymentSheet}
        bookingId={bookingId}
        onClose={() => setShowPaymentSheet(false)}
        onPaid={() => {
          setShowPaymentSheet(false);
          void loadBooking();
        }}
      />
      <Modal visible={showWasherSheet} transparent animationType="fade" onRequestClose={() => setShowWasherSheet(false)}>
        <Pressable style={styles.washerSheetBackdrop} onPress={() => setShowWasherSheet(false)}>
          <Pressable
            style={[styles.washerSheetWrap, { borderColor: liveCardAccent + '55', paddingBottom: Math.max(insets.bottom, 12) }]}
            onPress={(e) => e.stopPropagation()}
          >
            <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={HEADER_STYLE_CARD_GRADIENT}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={[liveCardAccent + '33', 'transparent', 'rgba(2,6,23,0.35)']}
              locations={[0, 0.35, 1]}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={['rgba(255,255,255,0.18)', 'rgba(255,255,255,0.02)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.washerSheetSheen}
              pointerEvents="none"
            />
            <View style={styles.washerHandle} />
            {washerLoading ? (
              <View style={styles.washerLoadingWrap}>
                <ActivityIndicator size="small" color={liveCardAccent} />
                <Text style={styles.washerLoadingText}>Loading your Wish…</Text>
              </View>
            ) : (
              <ScrollView contentContainerStyle={styles.washerSheetContent} showsVerticalScrollIndicator={false}>
                <View style={styles.washerSheetHeaderRow}>
                  <View style={[styles.wishLivePill, { borderColor: liveCardAccent + '66', backgroundColor: liveCardAccent + '22' }]}>
                    <View style={[styles.wishLiveDot, { backgroundColor: liveCardAccent }]} />
                    <Text style={[styles.wishLivePillText, { color: liveCardAccent }]} numberOfLines={1}>
                      {currentStatusTitle}
                    </Text>
                  </View>
                  <WWSheetCloseButton
                    variant="bordered"
                    size={40}
                    iconSize={22}
                    iconColor="rgba(226,232,240,0.9)"
                    onPress={() => setShowWasherSheet(false)}
                    accessibilityLabel="Close"
                  />
                </View>

                <View style={styles.wishHeroRow}>
                  {washerInfo?.photoUrl ? (
                    <Image source={{ uri: washerInfo.photoUrl }} style={[styles.washerAvatar, { borderColor: liveCardAccent + '88' }]} />
                  ) : (
                    <View style={[styles.washerAvatarFallback, { borderColor: liveCardAccent + '55', backgroundColor: liveCardAccent + '18' }]}>
                      <Ionicons name="person" size={28} color={liveCardAccent} />
                    </View>
                  )}
                  <View style={styles.washerHeaderText}>
                    <Text style={styles.washerName} numberOfLines={1}>
                      {liveProName || washerInfo?.fullName || ccpFallbackName()}
                    </Text>
                    <Text style={styles.washerSub} numberOfLines={1}>
                      {CCP.singularShort}
                      {washerInfo?.rating != null && washerInfo.rating > 0
                        ? ` · ${washerInfo.rating.toFixed(1)}★`
                        : ''}
                      {washerInfo?.totalJobs != null ? ` · ${washerInfo.totalJobs} jobs` : ''}
                    </Text>
                    <View style={styles.wishTrustRow}>
                      {['Verified', 'Insured', 'Checked'].map((label) => (
                        <View key={label} style={styles.wishTrustChip}>
                          <Ionicons name="shield-checkmark" size={11} color={ECO_GREEN} />
                          <Text style={styles.wishTrustChipText}>{label}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>

                <View style={[styles.wishBriefCard, { borderColor: liveCardAccent + '40' }]}>
                  <View style={styles.wishBriefTop}>
                    <View style={styles.wishBriefCopy}>
                      <Text style={styles.wishBriefKicker}>YOUR WISH</Text>
                      <Text style={styles.wishBriefTitle} numberOfLines={2}>
                        {bookingServiceDisplay || 'Service'}
                      </Text>
                      {booking?.wash_type ? (
                        <View style={styles.wishTypeChip}>
                          <Ionicons name="water-outline" size={12} color={SKY} />
                          <Text style={styles.wishTypeChipText}>
                            {booking.wash_type === 'exterior'
                              ? 'Exterior'
                              : booking.wash_type === 'interior'
                                ? 'Interior'
                                : String(booking.wash_type)}
                          </Text>
                        </View>
                      ) : null}
                      {booking?.vehicle_info ? (
                        <View style={[styles.wishTypeChip, { marginTop: 6 }]}>
                          <Ionicons name="car-sport-outline" size={12} color={SKY} />
                          <Text style={styles.wishTypeChipText} numberOfLines={3}>
                            {booking.vehicle_info}
                          </Text>
                        </View>
                      ) : booking?.vehicle_type ? (
                        <View style={[styles.wishTypeChip, { marginTop: 6 }]}>
                          <Ionicons name="car-sport-outline" size={12} color={SKY} />
                          <Text style={styles.wishTypeChipText}>{booking.vehicle_type}</Text>
                        </View>
                      ) : null}
                    </View>
                    <View style={styles.wishScoreBlock}>
                      <Text style={styles.wishScoreLabel}>TOTAL</Text>
                      <Text style={[styles.wishScoreValue, { color: liveCardAccent }]}>
                        £{moneyGBPOrDash(booking?.price)}
                      </Text>
                    </View>
                  </View>
                  {(Number(booking?.platform_fee_amount) > 0 ||
                    (Number(booking?.add_ons_total) || 0) > 0 ||
                    Number(booking?.discount_amount) > 0) && (
                    <View style={styles.wishMetaRow}>
                      {Number(booking?.platform_fee_amount) > 0 ? (
                        <Text style={styles.wishMetaText}>Fee £{moneyGBP(booking?.platform_fee_amount)}</Text>
                      ) : null}
                      {(Number(booking?.add_ons_total) || 0) > 0 ? (
                        <Text style={styles.wishMetaText}>Add-ons £{moneyGBP(booking?.add_ons_total)}</Text>
                      ) : null}
                      {Number(booking?.discount_amount) > 0 ? (
                        <Text style={[styles.wishMetaText, { color: ECO_GREEN }]}>
                          −£{moneyGBP(booking?.discount_amount)}
                        </Text>
                      ) : null}
                    </View>
                  )}
                </View>

                {serviceSummaryLines.length > 0 ? (
                  <View style={styles.wishLoadoutBlock}>
                    <Text style={styles.wishLoadoutKicker}>INCLUDES</Text>
                    <View style={styles.wishChipWrap}>
                      {serviceSummaryLines.slice(0, 8).map((item, idx) => (
                        <View key={`${idx}-${item.slice(0, 20)}`} style={styles.wishIncludeChip}>
                          <Ionicons name="checkmark-circle" size={12} color={liveCardAccent} />
                          <Text style={styles.wishIncludeChipText} numberOfLines={1}>
                            {item}
                          </Text>
                        </View>
                      ))}
                    </View>
                  </View>
                ) : null}

                <View style={styles.wishDropRow}>
                  <View style={[styles.wishDropIcon, { backgroundColor: liveCardAccent + '22', borderColor: liveCardAccent + '55' }]}>
                    <Ionicons name="location" size={16} color={liveCardAccent} />
                  </View>
                  <Text style={styles.wishDropText} numberOfLines={2}>
                    {booking?.location_address || 'Location saving…'}
                  </Text>
                </View>

                <View style={styles.wishActionRow}>
                  <TouchableOpacity
                    style={[
                      styles.wishMessageBtn,
                      chatLocked && styles.wishMessageBtnLocked,
                      { borderColor: chatLocked ? 'rgba(148,163,184,0.35)' : liveCardAccent + '66' },
                    ]}
                    onPress={() => {
                      if (!bookingId || openingChat) return;
                      openTrackingChat();
                    }}
                    activeOpacity={openingChat ? 1 : 0.85}
                  >
                    <Ionicons
                      name={chatLocked ? 'lock-closed' : 'chatbubble-ellipses'}
                      size={17}
                      color={chatLocked ? 'rgba(148,163,184,0.9)' : liveCardAccent}
                    />
                    <Text
                      style={[
                        styles.wishMessageBtnText,
                        { color: chatLocked ? 'rgba(148,163,184,0.9)' : liveCardAccent },
                      ]}
                    >
                      {openingChat ? 'Opening…' : chatLocked ? 'Chat locked' : 'Message'}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.wishDoneBtn}
                    onPress={() => setShowWasherSheet(false)}
                    activeOpacity={0.85}
                  >
                    <Text style={styles.wishDoneBtnText}>Done</Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity
                  style={styles.washerCancelInModalBtn}
                  onPress={() => {
                    void hapticFeedback('light');
                    setShowWasherSheet(false);
                    Alert.alert(
                      'Cancel booking?',
                      'This will cancel your active booking.',
                      [
                        { text: 'Keep booking', style: 'cancel' },
                        { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
                      ],
                    );
                  }}
                  activeOpacity={0.85}
                >
                  <Text style={styles.washerCancelInModalText}>Cancel Wish</Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  liveCardShell: {
    paddingBottom: 2,
  },
  liveCardBody: {
    gap: 0,
  },
  liveProRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
    minWidth: 0,
  },
  liveAvatarSm: {
    width: 22,
    height: 22,
    borderRadius: 7,
  },
  liveAvatarSmFallback: {
    width: 22,
    height: 22,
    borderRadius: 7,
    alignItems: 'center',
    justifyContent: 'center',
  },
  liveProName: {
    flex: 1,
    minWidth: 0,
    color: 'rgba(248,250,252,0.96)',
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 18,
  },
  liveRingAside: {
    marginLeft: 8,
  },
  liveRingCenter: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  liveTimerCompact: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.3,
    fontVariant: ['tabular-nums'],
  },
  liveTimerMini: {
    marginTop: 1,
    fontSize: 9,
    fontWeight: '700',
    textAlign: 'center',
  },
  liveStatusSubtext: {
    marginTop: 2,
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 15,
  },
  liveProgressTrack: {
    height: 3,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginTop: 8,
  },
  liveProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  liveChipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    gap: 6,
    marginTop: 8,
  },
  /** Slight nudge right to align with wash-name text. */
  liveStepRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    alignItems: 'center',
    gap: 4,
    marginTop: 8,
    paddingLeft: 10,
  },
  liveChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  liveChipText: {
    color: 'rgba(226,232,240,0.82)',
    fontSize: 10,
    fontWeight: '700',
  },
  liveStepChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    backgroundColor: 'rgba(148,163,184,0.1)',
  },
  liveStepChipDone: {
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(148,163,184,0.16)',
  },
  liveStepChipText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '700',
    maxWidth: 86,
  },
  gamifiedCardWrap: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 0,
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  gamifiedCardLower: {
    marginTop: 0,
  },
  gamifiedStageOverlay: {
    borderRadius: 24,
  },
  trackActionIconBtn: {
    width: 46,
    height: 46,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: SKY + '8A',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  trackActionIconBtnDisabled: {
    borderColor: 'rgba(148,163,184,0.5)',
  },
  bookingDetailsCtaWrap: {
    flex: 1,
  },
  actionRowLower: {
    marginTop: 0,
    paddingBottom: 0,
  },
  bookingDetailsBtn: {
    borderColor: 'rgba(56,189,248,0.55)',
    borderRadius: 24,
    minHeight: 48,
    paddingVertical: 10,
  },
  bookingDetailsTextFix: {
    lineHeight: 20,
    paddingBottom: 1,
    includeFontPadding: false,
  },
  washerSheetBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.52)',
    justifyContent: 'flex-end',
  },
  washerSheetWrap: {
    width: '100%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
    minHeight: '48%',
    maxHeight: '82%',
  },
  washerSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  washerHandle: {
    width: 42,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(226,232,240,0.4)',
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 6,
  },
  washerLoadingWrap: {
    paddingVertical: 40,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  washerLoadingText: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 13,
    fontWeight: '600',
  },
  washerSheetHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 10,
  },
  wishLivePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    maxWidth: '72%',
  },
  wishLiveDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  wishLivePillText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washerSheetContent: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  wishHeroRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  washerAvatar: {
    width: 64,
    height: 64,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  washerAvatarFallback: {
    width: 64,
    height: 64,
    borderRadius: 20,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  washerHeaderText: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  washerName: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  washerSub: {
    color: 'rgba(186,198,214,0.92)',
    fontSize: 12,
    fontWeight: '600',
  },
  wishTrustRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 5,
    marginTop: 4,
  },
  wishTrustChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.28)',
  },
  wishTrustChipText: {
    color: 'rgba(167,243,208,0.95)',
    fontSize: 10,
    fontWeight: '700',
  },
  wishBriefCard: {
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(2,6,23,0.42)',
    padding: 14,
    marginBottom: 12,
    gap: 10,
  },
  wishBriefTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  wishBriefCopy: {
    flex: 1,
    minWidth: 0,
    gap: 6,
  },
  wishBriefKicker: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
  },
  wishBriefTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
    lineHeight: 24,
  },
  wishTypeChip: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.35)',
  },
  wishTypeChipText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  wishScoreBlock: {
    alignItems: 'flex-end',
    minWidth: 84,
  },
  wishScoreLabel: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  wishScoreValue: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.6,
    marginTop: 2,
  },
  wishMetaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(148,163,184,0.22)',
    paddingTop: 8,
  },
  wishMetaText: {
    color: 'rgba(203,213,225,0.9)',
    fontSize: 11,
    fontWeight: '600',
  },
  wishLoadoutBlock: {
    marginBottom: 12,
    gap: 8,
  },
  wishLoadoutKicker: {
    color: 'rgba(148,163,184,0.88)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
  },
  wishChipWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  wishIncludeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    maxWidth: '100%',
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  wishIncludeChipText: {
    color: 'rgba(241,245,249,0.92)',
    fontSize: 11,
    fontWeight: '600',
    maxWidth: 160,
  },
  wishDropRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  wishDropIcon: {
    width: 32,
    height: 32,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  wishDropText: {
    flex: 1,
    minWidth: 0,
    color: 'rgba(226,232,240,0.92)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 17,
  },
  wishActionRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 10,
  },
  wishMessageBtn: {
    flex: 1,
    minHeight: 46,
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  wishMessageBtnLocked: {
    opacity: 0.85,
  },
  wishMessageBtnText: {
    fontSize: 14,
    fontWeight: '800',
  },
  wishDoneBtn: {
    minWidth: 88,
    minHeight: 46,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  wishDoneBtnText: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '800',
  },
  washerCancelInModalBtn: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.4)',
    backgroundColor: 'rgba(127,29,29,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
  },
  washerCancelInModalText: {
    color: '#FECACA',
    fontSize: 13,
    fontWeight: '700',
  },
});
