import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Alert,
  ActivityIndicator,
  Modal,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  PanResponder,
  Dimensions,
  Keyboard,
  type KeyboardEvent,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  serviceOptions,
  detailingServiceOptions,
  repairServiceOptions,
  REPAIR_PACKAGE_IDS,
  addOnOptions,
  ADD_ON_SECTION_TITLE,
  ADD_ON_SECTION_SUBTITLE,
  getAvailableAddOnIdsForService,
  LEGACY_ECO_SERVICE_ID_MAP,
} from '../../../src/constants/serviceOptions';
import AppHeader from '../../../src/components/shared/AppHeader';
import BookingMapLocationFullHeader from '../../../src/components/booking/BookingMapLocationFullHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { AUTO_SELECT_DEFAULT_VEHICLE_KEY } from '../../../src/constants/userPreferences';

import {
  BOOKING_CARD,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
  BOOKING_H_CARD_GAP,
  getBookingIndexOptionCardWidth,
  getBookingIndexOptionSnapInterval,
} from '../../../src/constants/bookingCardTheme';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import { useMapChromeColors } from '../../../src/hooks/useMapChromeColors';
import { useThemeOptional } from '../../../src/contexts/ThemeContext';
import { WWPrimaryButton } from '../../../src/components/ui';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../src/components/booking/IndexTrackingCardShell';
import ServiceTierSpongeIcon, { getServiceTierLeadIconName } from '../../../src/components/booking/ServiceTierSpongeIcon';
import BookingBottomSheetOverlay from '../../../src/components/booking/BookingBottomSheetOverlay';
import { customerMapTrackingSheetActionStyles } from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import { VehiclePickerInline } from '../../../src/components/booking/VehiclePickerSheet';
import {
  formatBookingVehicleInfo,
  sumServiceBaseForVehicles,
  toggleBookingVehicleId,
} from '../../../src/utils/bookingVehicleSelection';
import { VehicleInfoOverlay } from '../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../src/utils/vehicleStats';
import {
  DEFAULT_MAP_REGION,
  LOCATION_PICKER_MAP_STYLE,
  LOCATION_PICKER_ZOOM_DELTA,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
} from '../../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../../src/components/maps/MapMarkerViews';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../src/constants/launchCustomerScope';
import { CCP } from '../../../src/constants/carCareProLabels';
import { createMobileValeterBookingPendingPayment } from '../../../src/utils/createMobileValeterBookingPendingPayment';
import { ActiveBookingBlockedError } from '../../../src/utils/hubPendingPaymentBooking';
import { addVehicleByRegistration, cleanVehicleReg } from '../../../src/utils/vehicleQuickAdd';
import {
  BOOKING_FROZEN_MAP_SHEET_PADDING,
  buildFrozenBookingMapView,
  type FrozenBookingMapView,
} from '../../../src/utils/frozenBookingMapView';
import FrozenBookingMapStage from '../../../src/components/booking/FrozenBookingMapStage';
import BookingAddressPill from '../../../src/components/booking/BookingAddressPill';
import BookingWashTypeMapPill from '../../../src/components/booking/BookingWashTypeMapPill';

const SKY = colors.SKY;
const LOCATION_CARD_GREEN = colors.ECO_GREEN;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const REPAIR_ACCENT = colors.ECO_GREEN;
/** Active Repair tab — green (distinct from wash sky / detail yellow). */
const REPAIR_TAB_ACCENT = colors.ECO_GREEN;
const LOCATION_SHEET_MAP_PADDING = BOOKING_FROZEN_MAP_SHEET_PADDING;
const SCREEN_W = Dimensions.get('window').width;
const SCREEN_H = Dimensions.get('window').height;
/** Uber-style wish carousel — one card + peek of the next. */
const WISH_CARD_W = getBookingIndexOptionCardWidth(SCREEN_W);
const WISH_CARD_STEP = getBookingIndexOptionSnapInterval(SCREEN_W);
const WISH_CAROUSEL_H = 134;
const CONDITION_BANNER_DISMISS_MS = 4600;
const CONDITION_BANNER_ADDRESS_OFFSET = 54;

const SERVICE_MODE_TAB_BASE = [
  {
    id: 'wash' as const,
    label: 'Wash',
    icon: 'water-outline' as const,
    accent: SKY,
    activeBorder: 'rgba(125,211,252,0.45)',
    activeIcon: '#E0F2FE',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
  {
    id: 'detailing' as const,
    label: 'Detail',
    icon: 'diamond-outline' as const,
    accent: DETAILING_YELLOW,
    activeBorder: 'rgba(234,179,8,0.45)',
    activeIcon: '#FDE047',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
  {
    id: 'repair' as const,
    label: 'Repair',
    icon: 'construct-outline' as const,
    accent: REPAIR_TAB_ACCENT,
    activeBorder: 'rgba(16,185,129,0.45)',
    activeIcon: '#6EE7B7',
    idleIcon: 'rgba(148,163,184,0.55)',
  },
];

const SAVED_LOCATIONS_KEY = 'customer_saved_locations';

type SavedLocationItem = {
  id: string;
  label: string;
  address: string;
  latitude: number;
  longitude: number;
};

/** Forward-geocode result row for address search (device geocoding via Expo, no Google API). */
type AddressGeocodeSuggestion = {
  id: string;
  description: string;
  latitude: number;
  longitude: number;
};

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: string;
  image_url?: string | null;
  photo?: string | null;
};


/** Strip color for service card side border: wash tiers, or yellow for all detailing services. */
function getServiceStripColor(serviceId: string, fallback: string): string {
  const id = serviceId.toLowerCase();
  const washKey = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const washMap: Record<string, string> = {
    'bronze-wash': '#92400E',
    'silver-wash': '#C0C0C0',
    'gold-wash': '#EAB308',
    'platinum-wash': '#334155',
    'emerald-wash': '#22D3EE',
  };
  if (washMap[washKey]) return washMap[washKey];
  if (REPAIR_PACKAGE_IDS.includes(id)) return REPAIR_ACCENT;
  const detailingIds = ['ceramic-coating', 'machine-polishing', 'soft-top-restoration', 'mould-removal'];
  if (detailingIds.includes(id)) return DETAILING_YELLOW;
  return fallback;
}

type BookingStep = 'location' | 'service';

type ServiceMode = 'wash' | 'detailing' | 'repair';

function getServiceModeTabAccent(mode: ServiceMode): string {
  if (mode === 'detailing') return DETAILING_YELLOW;
  if (mode === 'repair') return REPAIR_TAB_ACCENT;
  return SKY;
}

function getBookingHeaderConfig(step: BookingStep): { title: string; subtitle: string } {
  switch (step) {
    case 'location':
      return { title: 'Set location', subtitle: 'Set where your washer will arrive' };
    default:
      return { title: 'Make a wish', subtitle: 'Tap a card to make your wish come true' };
  }
}

/** Short tier explainer on service cards (mobile wash tiers). */
function getWashPackageTagline(serviceId: string): string | null {
  const id = serviceId.toLowerCase();
  const tierId = LEGACY_ECO_SERVICE_ID_MAP[id] ?? id;
  const map: Record<string, string> = {
    'bronze-wash': 'Interior OR exterior',
    'silver-wash': 'Interior + Exterior',
    'gold-wash': 'Interior Deep Clean',
    'platinum-wash': 'Full Valet',
    'emerald-wash': 'Premium Full Detail',
    'headlight-restoration': 'Lens clarity restore',
    'scratch-removal': 'Light scratch & swirl care',
    'paint-chip-repair': 'Chip touch-in & protection',
    'trim-restoration': 'Faded plastic revived',
    'leather-repair': 'Scuffs, wear & small tears',
    'maintenance-pack': 'Fluids, levels & quick checks',
  };
  return map[tierId] ?? null;
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- multi-step booking flow; logic split via getBookingHeaderConfig and step renderers
export default function BookingCreate() {
  const params = useLocalSearchParams<{
    serviceMode?: string;
    customerOffersWater?: string;
    customerOffersElectricity?: string;
    preferredValeterId?: string;
    latitude?: string;
    longitude?: string;
    address?: string;
    startAtVehicle?: string;
    openAddressOverlay?: string;
  }>();
  const offersWater = false;
  const offersElectricity = false;
  const [infoService, setInfoService] = useState<{ id?: string; name?: string; icon?: string; desc?: string; bulletPoints?: string[]; descriptionTitle?: string } | null>(null);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState<AddressGeocodeSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [showInlineSuggestions, setShowInlineSuggestions] = useState(false);
  const [locationKeyboardHeight, setLocationKeyboardHeight] = useState(0);
  const suggestDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suggestRequestRef = useRef(0);
  const insets = useSafeAreaInsets();
  const chrome = useMapChromeColors();
  const isDark = useThemeOptional()?.isDark === true;
  const sheetRimColor = isDark ? chrome.border : undefined;
  const serviceModeTabs = SERVICE_MODE_TAB_BASE;
  const { user } = useAuth();
  const { setTheme } = useBookingFlowTheme();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [skippedLocationStep, setSkippedLocationStep] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicleIds, setSelectedVehicleIds] = useState<string[]>([]);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [serviceMode, setServiceMode] = useState<ServiceMode>(() => {
    const m = (params.serviceMode as string | undefined)?.toLowerCase();
    if (m === 'repair') return 'repair';
    if (m === 'detailing') return 'detailing';
    return 'wash';
  });
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [showAddOnsModal, setShowAddOnsModal] = useState(false);
  const [showBronzeWashTypeOverlay, setShowBronzeWashTypeOverlay] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const adaptive = useAdaptiveLayout();
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [frozenServiceMapView, setFrozenServiceMapView] = useState<FrozenBookingMapView | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [pickerGpsReady, setPickerGpsReady] = useState(false);
  const [savedLocations, setSavedLocations] = useState<SavedLocationItem[]>([]);
  const [showVehicleRegInput, setShowVehicleRegInput] = useState(false);
  const [vehicleRegInput, setVehicleRegInput] = useState('');
  const [vehicleRegSaving, setVehicleRegSaving] = useState(false);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const sheetDragY = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const conditionBannerOpacity = useRef(new Animated.Value(0)).current;
  const conditionBannerSlide = useRef(new Animated.Value(-16)).current;
  const conditionBannerScale = useRef(new Animated.Value(0.94)).current;
  const addressPillShift = useRef(new Animated.Value(0)).current;
  const [conditionBannerMounted, setConditionBannerMounted] = useState(false);
  const pickerGeocodeDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pickerGeocodeRequestRef = useRef(0);
  const suppressPickerGeocodeRef = useRef(false);
  const hasInitializedPickerAtUserLocationRef = useRef(false);

  const centerPickerOnCoords = useCallback(
    async (coords: { latitude: number; longitude: number }, opts?: { animate?: boolean }) => {
      const nextRegion: Region = {
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: region?.latitudeDelta ?? LOCATION_PICKER_ZOOM_DELTA,
        longitudeDelta: region?.longitudeDelta ?? LOCATION_PICKER_ZOOM_DELTA,
      };
      suppressPickerGeocodeRef.current = true;
      setRegion(nextRegion);
      try {
        const [result] = await Location.reverseGeocodeAsync(coords);
        const addr = result
          ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location'
          : 'Current Location';
        setSelectedLocation({ ...coords, address: addr });
      } catch {
        setSelectedLocation({ ...coords, address: 'Current Location' });
      }
      if (opts?.animate !== false) {
        mapRef.current?.animateToRegion(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
      }
    },
    [region]
  );

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
    void AsyncStorage.removeItem('booking_create_draft_v1').catch(() => {});
  }, [user?.id]);

  useEffect(() => {
    setTheme(serviceMode === 'wash' ? 'wash' : 'detailing');
  }, [serviceMode, setTheme]);

  useEffect(() => {
    setSelectedService(null);
    setWashType(null);
    setSelectedAddOns([]);
    setShowBronzeWashTypeOverlay(false);
    setShowAddOnsModal(false);
  }, [serviceMode]);

  useEffect(() => {
    if (!showAddOnsModal && !showBronzeWashTypeOverlay) return;
    sheetDragY.setValue(0);
  }, [showAddOnsModal, showBronzeWashTypeOverlay, sheetDragY]);

  useEffect(() => {
    if (currentStep !== 'service' || serviceMode !== 'detailing') {
      setConditionBannerMounted(false);
      conditionBannerOpacity.setValue(0);
      conditionBannerSlide.setValue(-16);
      conditionBannerScale.setValue(0.94);
      addressPillShift.setValue(0);
      return;
    }

    setConditionBannerMounted(true);
    conditionBannerOpacity.setValue(0);
    conditionBannerSlide.setValue(-16);
    conditionBannerScale.setValue(0.94);
    addressPillShift.setValue(0);

    const enterAnim = Animated.parallel([
      Animated.spring(conditionBannerSlide, {
        toValue: 0,
        damping: 16,
        stiffness: 210,
        mass: 0.85,
        useNativeDriver: true,
      }),
      Animated.spring(conditionBannerScale, {
        toValue: 1,
        damping: 16,
        stiffness: 210,
        mass: 0.85,
        useNativeDriver: true,
      }),
      Animated.timing(conditionBannerOpacity, {
        toValue: 1,
        duration: 340,
        useNativeDriver: true,
      }),
      Animated.spring(addressPillShift, {
        toValue: CONDITION_BANNER_ADDRESS_OFFSET - 8,
        damping: 18,
        stiffness: 220,
        useNativeDriver: true,
      }),
    ]);

    let dismissTimer: ReturnType<typeof setTimeout> | undefined;
    enterAnim.start(() => {
      dismissTimer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(conditionBannerOpacity, {
            toValue: 0,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.timing(conditionBannerSlide, {
            toValue: -22,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.timing(conditionBannerScale, {
            toValue: 0.9,
            duration: 520,
            useNativeDriver: true,
          }),
          Animated.spring(addressPillShift, {
            toValue: 0,
            damping: 20,
            stiffness: 240,
            useNativeDriver: true,
          }),
        ]).start(({ finished }) => {
          if (finished) setConditionBannerMounted(false);
        });
      }, CONDITION_BANNER_DISMISS_MS);
    });

    return () => {
      if (dismissTimer) clearTimeout(dismissTimer);
      enterAnim.stop();
    };
  }, [
    currentStep,
    serviceMode,
    conditionBannerOpacity,
    conditionBannerSlide,
    conditionBannerScale,
    addressPillShift,
  ]);

  const exitBookingFlow = () => {
    router.replace('/owner/owner-dashboard' as any);
  };

  const sheetPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, g) => g.dy > 4 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderMove: (_, g) => {
        const y = Math.max(0, Math.min(g.dy, 220));
        sheetDragY.setValue(y);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > 90) {
          Animated.timing(sheetDragY, { toValue: 220, duration: 160, useNativeDriver: true }).start(() => {
            exitBookingFlow();
          });
          return;
        }
        Animated.spring(sheetDragY, {
          toValue: 0,
          useNativeDriver: true,
          damping: 24,
          stiffness: 260,
        }).start();
      },
    })
  ).current;

  useEffect(() => {
    const lat = params.latitude ? Number(params.latitude) : NaN;
    const lng = params.longitude ? Number(params.longitude) : NaN;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    const addr = (params.address as string) || 'Selected Location';
    const coords = { latitude: lat, longitude: lng };
    setSelectedLocation({ ...coords, address: addr });
    const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_ZOOM_DELTA };
    setRegion(nextRegion);
    setFrozenServiceMapView(buildFrozenBookingMapView(coords, insets.bottom, nextRegion));
    setSkippedLocationStep(true);
    setCurrentStep('service');
    if (params.openAddressOverlay === 'true') {
      setShowAddressOverlay(false);
      setShowInlineSuggestions(true);
    }
  }, [params.latitude, params.longitude, params.address, params.startAtVehicle, params.openAddressOverlay, insets.bottom]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Default the centred car marker to the user's exact GPS on first load.
  useEffect(() => {
    const bootstrapUserLocation = async () => {
      if (currentStep !== 'location' || selectedLocation !== null || hasInitializedPickerAtUserLocationRef.current) {
        setPickerGpsReady(true);
        return;
      }

      let coords: { latitude: number; longitude: number } | null = null;
      try {
        if (liveCoords) {
          coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
        } else {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
          coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
        }

        if (!coords) return;
        setUserLocation(coords);
        hasInitializedPickerAtUserLocationRef.current = true;
        await centerPickerOnCoords(coords);
      } catch (error) {
        console.warn('Error getting location:', error);
      } finally {
        setPickerGpsReady(true);
      }
    };

    void bootstrapUserLocation();
  }, [liveCoords, currentStep, selectedLocation, centerPickerOnCoords]);

  // Keep userLocation in sync when live GPS updates (without moving the picker once set).
  useEffect(() => {
    if (!liveCoords) return;
    setUserLocation({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
  }, [liveCoords]);

  useEffect(() => {
    if (currentStep !== 'service' || !selectedLocation || frozenServiceMapView) return;
    setFrozenServiceMapView(buildFrozenBookingMapView(selectedLocation, insets.bottom, region));
  }, [currentStep, selectedLocation, region, frozenServiceMapView, insets.bottom]);

  // Load saved locations for the dropdown (same list as Settings > Saved locations)
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(`${SAVED_LOCATIONS_KEY}_${user.id}`);
        if (!raw) {
          setSavedLocations([]);
          return;
        }
        const parsed = JSON.parse(raw);
        const list = Array.isArray(parsed) ? parsed : [];
        const labels: Record<string, string> = { home: 'Home', work: 'Work', gym: 'Gym', other: 'Other' };
        setSavedLocations(
          list.map((item: { id: string; label: string; customLabel?: string; address: string; latitude: number; longitude: number }) => ({
            id: item.id,
            label: item.customLabel || labels[item.label] || item.label,
            address: item.address,
            latitude: item.latitude,
            longitude: item.longitude,
          }))
        );
      } catch {
        setSavedLocations([]);
      }
    })();
  }, [user?.id]);

  // When service or wash type changes, drop any selected add-ons that are no longer allowed
  useEffect(() => {
    const isNonWash = serviceMode === 'detailing' || serviceMode === 'repair';
    const allowed = selectedService
      ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isNonWash)
      : [];
    setSelectedAddOns((prev) => prev.filter((id) => allowed.includes(id)));
  }, [selectedService, washType, serviceMode]);

  const resolvePickerAddress = async (coords: { latitude: number; longitude: number }) => {
    const requestId = Date.now();
    pickerGeocodeRequestRef.current = requestId;
    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (pickerGeocodeRequestRef.current !== requestId) return;
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location'
        : 'Selected Location';
      setSelectedLocation({ ...coords, address: addr });
    } catch (e) {
      if (pickerGeocodeRequestRef.current === requestId) {
        setSelectedLocation({ ...coords, address: 'Selected Location' });
      }
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    const nextRegion = {
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: region?.latitudeDelta ?? LOCATION_PICKER_ZOOM_DELTA,
      longitudeDelta: region?.longitudeDelta ?? LOCATION_PICKER_ZOOM_DELTA,
    };
    setRegion(nextRegion);
    mapRef.current?.animateToRegion(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
    await resolvePickerAddress(coords);
    await hapticFeedback('light');
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (!userLocation) return;
    hasInitializedPickerAtUserLocationRef.current = true;
    await centerPickerOnCoords(userLocation);
  };

  const handlePickSavedLocation = (item: SavedLocationItem) => {
    hapticFeedback('light');
    const coords = { latitude: item.latitude, longitude: item.longitude };
    suppressPickerGeocodeRef.current = true;
    setRegion({ ...coords, latitudeDelta: LOCATION_PICKER_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_ZOOM_DELTA });
    setSelectedLocation({ ...coords, address: item.address });
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const closeAddressOverlayWithoutSaving = () => {
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  useEffect(() => {
    if (currentStep !== 'location') {
      setLocationKeyboardHeight(0);
      return;
    }
    const showEvent = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const hideEvent = Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide';
    const onShow = (e: KeyboardEvent) => setLocationKeyboardHeight(e.endCoordinates.height);
    const onHide = () => setLocationKeyboardHeight(0);
    const subShow = Keyboard.addListener(showEvent, onShow);
    const subHide = Keyboard.addListener(hideEvent, onHide);
    return () => {
      subShow.remove();
      subHide.remove();
    };
  }, [currentStep]);

  useEffect(() => {
    const allowSuggest = showAddressOverlay || currentStep === 'location';
    if (!allowSuggest) {
      setAddressSuggestions([]);
      return;
    }
    const q = addressSearchInput.trim();
    if (q.length < 2) {
      setAddressSuggestions([]);
      return;
    }
    if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    suggestDebounceRef.current = setTimeout(async () => {
      const reqId = ++suggestRequestRef.current;
      setLoadingSuggestions(true);
      try {
        const results = await Location.geocodeAsync(q);
        if (suggestRequestRef.current !== reqId) return;
        if (!results?.length) {
          setAddressSuggestions([]);
          return;
        }
        const max = Math.min(results.length, 8);
        const items: AddressGeocodeSuggestion[] = [];
        for (let i = 0; i < max; i++) {
          const r = results[i];
          let description = q;
          try {
            const [rev] = await Location.reverseGeocodeAsync({ latitude: r.latitude, longitude: r.longitude });
            if (rev) {
              const line = `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim();
              if (line) description = line;
            }
          } catch {
            /* keep query as label */
          }
          items.push({
            id: `${r.latitude.toFixed(5)}-${r.longitude.toFixed(5)}-${i}`,
            description,
            latitude: r.latitude,
            longitude: r.longitude,
          });
        }
        if (suggestRequestRef.current === reqId) setAddressSuggestions(items);
      } catch {
        if (suggestRequestRef.current === reqId) setAddressSuggestions([]);
      } finally {
        if (suggestRequestRef.current === reqId) setLoadingSuggestions(false);
      }
    }, 320);
    return () => {
      if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    };
  }, [showAddressOverlay, currentStep, addressSearchInput]);

  const handleSelectSuggestion = async (suggestion: AddressGeocodeSuggestion) => {
    setAddressSearching(true);
    setAddressSuggestions([]);
    try {
      const coords = { latitude: suggestion.latitude, longitude: suggestion.longitude };
      const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_ZOOM_DELTA };
      suppressPickerGeocodeRef.current = true;
      setRegion(nextRegion);
      mapRef.current?.animateToRegion(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
      setSelectedLocation({ ...coords, address: suggestion.description });
      setShowAddressOverlay(false);
      setAddressSearchInput('');
      await hapticFeedback('medium');
    } finally {
      setAddressSearching(false);
    }
  };

  const handleAddressSearch = async () => {
    const q = addressSearchInput.trim();
    if (!q) return;
    setAddressSearching(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        const coords = { latitude, longitude };
        const nextRegion = { ...coords, latitudeDelta: LOCATION_PICKER_ZOOM_DELTA, longitudeDelta: LOCATION_PICKER_ZOOM_DELTA };
        suppressPickerGeocodeRef.current = true;
        setRegion(nextRegion);
        mapRef.current?.animateToRegion(nextRegion, MAP_CAMERA_ANIMATION_DURATION);
        const [rev] = await Location.reverseGeocodeAsync(coords);
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) {
        const defaultVehicle = rows.find((v: Vehicle) => v.is_default) || rows[0];
        setSelectedVehicleIds((prev) => (prev.length > 0 ? prev : [defaultVehicle.id]));
        try {
          const autoSelect = await AsyncStorage.getItem(AUTO_SELECT_DEFAULT_VEHICLE_KEY);
          if (autoSelect === 'true') {
            setCurrentStep((prev) => (prev === 'location' ? 'service' : prev));
          }
        } catch {}
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationAndVehicleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    if (selectedVehicleIds.length === 0) {
      Alert.alert('Vehicle Required', 'Please choose at least one vehicle for this booking.');
      return;
    }
    await hapticFeedback('medium');
    setFrozenServiceMapView(buildFrozenBookingMapView(selectedLocation, insets.bottom, region));
    setCurrentStep('service');
  };

  const toggleSelectedVehicle = (vehicleId: string) => {
    setSelectedVehicleIds((prev) => toggleBookingVehicleId(prev, vehicleId));
  };

  const openVehicleRegInput = () => {
    setShowVehicleRegInput(true);
    setVehicleRegInput('');
    setShowInlineSuggestions(false);
    setAddressSuggestions([]);
  };

  const closeVehicleRegInput = () => {
    setShowVehicleRegInput(false);
    setVehicleRegInput('');
    setVehicleRegSaving(false);
  };

  const handleVehicleRegSubmit = async () => {
    if (!user?.id) return;
    const reg = cleanVehicleReg(vehicleRegInput);
    if (!reg) {
      Alert.alert('Registration required', 'Enter your vehicle registration to continue.');
      return;
    }

    setVehicleRegSaving(true);
    try {
      await hapticFeedback('light');
      const result = await addVehicleByRegistration({
        userId: user.id,
        registration: reg,
        isFirstVehicle: vehicles.length === 0,
      });

      if (!result.ok) {
        Alert.alert('Could not add vehicle', result.message);
        return;
      }

      await loadVehicles();
      setSelectedVehicleIds((prev) =>
        prev.includes(result.vehicleId) ? prev : [...prev, result.vehicleId]
      );
      closeVehicleRegInput();
      await hapticFeedback('medium');
    } catch (error: unknown) {
      Alert.alert('Could not add vehicle', (error as Error)?.message || 'Something went wrong. Try again.');
    } finally {
      setVehicleRegSaving(false);
    }
  };

  type ServicePickOutcome = 'bronze-overlay' | 'addons-modal' | 'ready';

  const isDetailingOrRepairPackage = serviceMode === 'detailing' || serviceMode === 'repair';

  const currentServiceOptions =
    serviceMode === 'wash'
      ? serviceOptions
      : serviceMode === 'repair'
        ? repairServiceOptions
        : detailingServiceOptions;

  const handleServiceSelect = async (serviceId: string): Promise<ServicePickOutcome> => {
    await hapticFeedback('light');
    const nextOption = currentServiceOptions.find((s) => s.id === serviceId);
    setSelectedAddOns((prev) => prev.filter((id) => !nextOption?.includedAddOnIds?.includes(id)));
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setShowBronzeWashTypeOverlay(true);
      return 'bronze-overlay';
    }
    setWashType(null);
    const allowed = getAvailableAddOnIdsForService(serviceId, '', isDetailingOrRepairPackage);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !nextOption?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
      return 'addons-modal';
    }
    return 'ready';
  };

  /** Build valeter params from explicit ids so we can navigate in the same tap as selection (no stale state). */
  const navigateToValeterSelection = async (args: {
    serviceId: string;
    vehicleIds: string[];
    location: { latitude: number; longitude: number; address: string };
    washType: string;
  }) => {
    const primaryVehicleId = args.vehicleIds[0];
    if (!primaryVehicleId) return;
    const nextOption = currentServiceOptions.find((s) => s.id === args.serviceId);
    const washKeyForAddOns: '' | 'exterior' | 'interior' | 'both' =
      args.serviceId !== 'bronze-wash'
        ? ''
        : args.washType === 'exterior' || args.washType === 'interior' || args.washType === 'both'
          ? args.washType
          : '';
    const allowed = getAvailableAddOnIdsForService(
      args.serviceId,
      washKeyForAddOns,
      serviceMode === 'detailing' || serviceMode === 'repair'
    );
    const filteredAddOns = selectedAddOns.filter((id) => !nextOption?.includedAddOnIds?.includes(id));
    const effective = filteredAddOns.filter((id) => allowed.includes(id));
    const extrasTotal = effective.reduce((sum, id) => {
      const addOn = addOnOptions.find((a) => a.id === id);
      return sum + (addOn?.price ?? 0);
    }, 0);
    await hapticFeedback('medium');
    const discountAmount = 0;
    const vehicleInfo = formatBookingVehicleInfo(vehicles, args.vehicleIds);
    const computedServiceBase = sumServiceBaseForVehicles(
      args.serviceId,
      vehicles,
      args.vehicleIds,
      nextOption?.price ?? 25
    );
    const valeterParams: Record<string, string> = {
      serviceId: args.serviceId,
      vehicleId: primaryVehicleId,
      vehicleIds: args.vehicleIds.join(','),
      vehicleInfo,
      latitude: args.location.latitude.toString(),
      longitude: args.location.longitude.toString(),
      address: args.location.address,
      washType: args.washType,
      serviceMode: serviceMode,
      addOnIds: effective.length ? effective.join(',') : '',
      addOnsTotal: extrasTotal.toString(),
      customerOffersWater: 'false',
      customerOffersElectricity: 'false',
      discountAmount: discountAmount.toString(),
      serviceBasePriceGBP: computedServiceBase.toFixed(2),
    };
    if (params.preferredValeterId) valeterParams.preferredValeterId = params.preferredValeterId;
    if (frozenServiceMapView) {
      valeterParams.mapLat = frozenServiceMapView.region.latitude.toString();
      valeterParams.mapLng = frozenServiceMapView.region.longitude.toString();
      valeterParams.mapLatDelta = frozenServiceMapView.region.latitudeDelta.toString();
      valeterParams.mapLngDelta = frozenServiceMapView.region.longitudeDelta.toString();
    }
    if (params.preferredValeterId && user?.id) {
      try {
        const bookingId = await createMobileValeterBookingPendingPayment({
          userId: user.id,
          valeterId: params.preferredValeterId,
          vehicleId: primaryVehicleId,
          vehicleIds: args.vehicleIds,
          vehicleInfo,
          serviceId: args.serviceId,
          location: args.location,
          washType: args.washType,
          ...(effective.length ? { addOnIds: effective.join(',') } : {}),
          addOnsTotal: extrasTotal,
          discountAmount,
          serviceBasePriceGBP: computedServiceBase,
          customerOffersWater: false,
          customerOffersElectricity: false,
        });
        router.replace({
          pathname: '/owner/booking/payment',
          params: { bookingId },
        });
      } catch (error) {
        if (error instanceof ActiveBookingBlockedError) {
          Alert.alert(
            'One booking at a time',
            'You already have an active booking. Please complete or cancel it before starting a new one.',
            [
              { text: 'OK', style: 'cancel' },
              {
                text: 'View my booking',
                onPress: () =>
                  router.push({ pathname: '/owner/booking/tracking', params: { bookingId: error.activeBookingId } } as any),
              },
            ]
          );
          return;
        }
        Alert.alert('Error', error instanceof Error ? error.message : 'Failed to create booking');
      }
      return;
    }

    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: valeterParams,
    });
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
    setShowBronzeWashTypeOverlay(false);
    const bronze = serviceOptions.find((s) => s.id === 'bronze-wash');
    const allowed = getAvailableAddOnIdsForService('bronze-wash', type, false);
    const opts = addOnOptions.filter(
      (a) => allowed.includes(a.id) && !bronze?.includedAddOnIds?.includes(a.id)
    );
    if (opts.length > 0) {
      setShowAddOnsModal(true);
      return;
    }
  };

  const handleServiceContinue = async () => {
    if (!selectedService || selectedVehicleIds.length === 0 || !selectedLocation) return;
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await navigateToValeterSelection({
      serviceId: selectedService,
      vehicleIds: selectedVehicleIds,
      location: selectedLocation,
      washType: washType || '',
    });
  };
  const selectedServiceData = currentServiceOptions.find(s => s.id === selectedService);

  const allowedAddOnIds = selectedService
    ? getAvailableAddOnIdsForService(selectedService, washType ?? '', isDetailingOrRepairPackage)
    : [];
  const availableAddOnOptions = addOnOptions.filter(
    (a) => allowedAddOnIds.includes(a.id) && !selectedServiceData?.includedAddOnIds?.includes(a.id)
  );

  const effectiveSelectedAddOns = selectedAddOns.filter((id) => allowedAddOnIds.includes(id));
  const addOnsTotal = effectiveSelectedAddOns.reduce((sum, id) => {
    const addOn = addOnOptions.find(a => a.id === id);
    return sum + (addOn?.price ?? 0);
  }, 0);

  const wishCarouselHeight = WISH_CAROUSEL_H;

  const serviceContinueReady =
    Boolean(selectedService && selectedVehicleIds.length > 0 && selectedLocation) &&
    !(serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType);

  const serviceContinueAccent = selectedServiceData?.colors[0] ?? getServiceModeTabAccent(serviceMode);

  const infoSheetAccent = useMemo(() => {
    if (!infoService?.id) return getServiceModeTabAccent(serviceMode);
    if (serviceMode === 'repair') return REPAIR_TAB_ACCENT;
    if (serviceMode === 'detailing') return DETAILING_YELLOW;
    return currentServiceOptions.find((s) => s.id === infoService.id)?.colors[0] ?? SKY;
  }, [infoService?.id, serviceMode, currentServiceOptions]);

  const addOnsSheetAccent = useMemo(() => {
    if (serviceMode === 'repair') return REPAIR_TAB_ACCENT;
    if (serviceMode === 'detailing') return DETAILING_YELLOW;
    return selectedServiceData?.colors[0] ?? SKY;
  }, [serviceMode, selectedServiceData]);

  const bronzeWashSheetAccent = selectedServiceData?.colors[0] ?? '#92400E';

  const toggleAddOn = (id: string) => {
    hapticFeedback('light');
    setSelectedAddOns((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const headerConfig = getBookingHeaderConfig(currentStep);
  const headerTitle = headerConfig.title;
  const headerSubtitle = headerConfig.subtitle;
  const headerOnBack = (() => {
    if (currentStep === 'location') return () => router.back();
    if (currentStep === 'service' && MOBILE_SERVICE_ONLY_LAUNCH && !skippedLocationStep) {
      return () => setCurrentStep('location');
    }
    return () => router.back();
  })();

  const handleLocationRecenter = async () => {
    hapticFeedback('light');
    await handleUseCurrentLocation();
  };

  const addOnsPopupScrollMaxHeight = Math.min(SCREEN_H * 0.38, 340);

  const renderUberPopupRow = ({
    accent,
    selected,
    onPress,
    icon,
    title,
    meta,
    trailing = 'check',
    trailingLabel,
  }: {
    accent: string;
    selected: boolean;
    onPress: () => void;
    icon: keyof typeof Ionicons.glyphMap;
    title: string;
    meta?: string;
    trailing?: 'check' | 'chevron' | 'price';
    trailingLabel?: string;
  }) => (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={onPress}
      style={[
        styles.uberPopupRow,
        {
          borderColor: selected ? accent + '70' : 'rgba(148,163,184,0.18)',
          backgroundColor: selected ? accent + '12' : 'rgba(255,255,255,0.04)',
        },
      ]}
    >
      <View
        style={[
          styles.uberPopupIcon,
          {
            borderColor: selected ? accent + '40' : 'rgba(148,163,184,0.16)',
            backgroundColor: selected ? accent + '16' : 'rgba(255,255,255,0.05)',
          },
        ]}
      >
        <Ionicons name={icon} size={18} color={selected ? accent : '#94A3B8'} />
      </View>
      <View style={styles.uberPopupCopy}>
        <Text style={styles.uberPopupTitle} numberOfLines={1}>
          {title}
        </Text>
        {meta ? (
          <Text style={styles.uberPopupMeta} numberOfLines={1}>
            {meta}
          </Text>
        ) : null}
      </View>
      {trailing === 'chevron' ? (
        <Ionicons name="chevron-forward" size={16} color={accent} />
      ) : trailing === 'price' && trailingLabel ? (
        <Text style={[styles.uberPopupPrice, { color: selected ? accent : '#CBD5E1' }]}>{trailingLabel}</Text>
      ) : (
        <View
          style={[
            styles.uberPopupCheck,
            selected
              ? { backgroundColor: accent, borderColor: accent }
              : { borderColor: 'rgba(148,163,184,0.28)' },
          ]}
        >
          {selected ? <Ionicons name="checkmark" size={12} color="#FFFFFF" /> : null}
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {currentStep === 'location' ? (
        <BookingMapLocationFullHeader
          topInset={insets.top}
          onBack={headerOnBack}
          onRecenter={() => { void handleLocationRecenter(); }}
          accentColor={SKY}
        />
      ) : (
        <AppHeader
          title={headerTitle}
          subtitle={headerSubtitle}
          showBack
          fullWidth
          onBack={headerOnBack}
        />
      )}

      {/* Location step: interactive picker. Service step: frozen tinted map from location step. */}
      <View style={styles.mapStageWrap} pointerEvents={currentStep === 'service' ? 'box-none' : 'auto'}>
        {currentStep === 'location' ? (
          <MapView
            ref={mapRef}
            style={StyleSheet.absoluteFill}
            region={region ?? DEFAULT_MAP_REGION}
            onPress={(e) => { void handleMapPress(e); }}
            onRegionChangeComplete={(nextRegion) => {
              setRegion(nextRegion);
              if (!pickerGpsReady) return;
              if (suppressPickerGeocodeRef.current) {
                suppressPickerGeocodeRef.current = false;
                return;
              }
              const coords = { latitude: nextRegion.latitude, longitude: nextRegion.longitude };
              if (pickerGeocodeDebounceRef.current) clearTimeout(pickerGeocodeDebounceRef.current);
              pickerGeocodeDebounceRef.current = setTimeout(() => {
                void resolvePickerAddress(coords);
              }, 280);
            }}
            scrollEnabled
            zoomEnabled
            rotateEnabled={false}
            pitchEnabled={false}
            showsUserLocation
            showsMyLocationButton={false}
            toolbarEnabled={false}
            customMapStyle={LOCATION_PICKER_MAP_STYLE}
            userInterfaceStyle={MAP_LOCKED_DARK}
            mapPadding={{
              top: 12,
              right: 12,
              bottom: LOCATION_SHEET_MAP_PADDING + Math.max(insets.bottom, 14),
              left: 12,
            }}
            legalLabelInsets={{
              top: 0,
              right: 10,
              bottom: 148 + Math.max(insets.bottom, 14),
              left: 10,
            }}
          />
        ) : frozenServiceMapView && selectedLocation ? (
          <FrozenBookingMapStage mapView={frozenServiceMapView} />
        ) : null}
        {currentStep === 'location' && (
          <View pointerEvents="none" style={styles.centerPickerWrap}>
            <Animated.View style={[styles.centerPickerPin, { transform: [{ scale: markerPulse }] }]}>
              <MapMarkerCustomerVehicle size={44} variant="car" />
            </Animated.View>
          </View>
        )}

        {currentStep === 'service' && serviceMode === 'detailing' && conditionBannerMounted ? (
          <Animated.View
            pointerEvents="none"
            style={[
              styles.conditionMapBannerWrap,
              {
                opacity: conditionBannerOpacity,
                transform: [
                  { translateY: conditionBannerSlide },
                  { scale: conditionBannerScale },
                ],
              },
            ]}
          >
            <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={[`${DETAILING_YELLOW}24`, 'rgba(15,23,42,0.78)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0.6 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.conditionMapBannerInner}>
              <View
                style={[
                  styles.conditionMapBannerIcon,
                  {
                    backgroundColor: DETAILING_YELLOW + '20',
                    borderColor: DETAILING_YELLOW + '42',
                  },
                ]}
              >
                <Ionicons name="information-circle-outline" size={18} color={DETAILING_YELLOW} />
              </View>
              <Text style={styles.conditionMapBannerText}>
                Detailing is condition-based. Results vary by vehicle condition.
              </Text>
            </View>
          </Animated.View>
        ) : null}

        {currentStep === 'service' && selectedLocation ? (
        <Animated.View style={{ transform: [{ translateY: addressPillShift }] }}>
          {selectedService === 'bronze-wash' && washType ? (
            <BookingWashTypeMapPill
              washType={washType}
              accentColor={bronzeWashSheetAccent}
              onPress={() => {
                hapticFeedback('light');
                setShowBronzeWashTypeOverlay(true);
              }}
              style={[styles.washTypeMapPillWrap, { top: 8 }]}
            />
          ) : null}
          <BookingAddressPill
            address={selectedLocation.address}
            style={[
              styles.bookingAddressPillWrap,
              { top: selectedService === 'bronze-wash' && washType ? 44 : 8 },
            ]}
            onPress={() => {
              hapticFeedback('light');
              if (MOBILE_SERVICE_ONLY_LAUNCH && !skippedLocationStep) {
                setCurrentStep('location');
              }
            }}
          />
        </Animated.View>
        ) : null}
      </View>

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: Animated.add(slideAnim, sheetDragY) }],
            paddingBottom:
              currentStep === 'service'
                ? 0
                : Math.max(insets.bottom, 4) + 22,
            paddingHorizontal: currentStep === 'service' ? 0 : adaptive.horizontalPadding,
          },
        ]}
        pointerEvents={currentStep === 'location' ? 'none' : 'auto'}
        {...(currentStep === 'service' && !showAddOnsModal && !showBronzeWashTypeOverlay ? sheetPanResponder.panHandlers : {})}
      >
        <Animated.View style={{ width: '100%', flex: 1, transform: [{ translateX: stepSlideAnim }] }}>
        {/* Step 1: Location only */}
        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={styles.vehicleSheetScreen}>
            <View
              style={[
                styles.vehicleBottomSheet,
                { paddingBottom: Math.max(insets.bottom, 6) },
                sheetRimColor ? { borderColor: sheetRimColor } : null,
              ]}
            >
              <BusinessSheetBackground />
              <View style={styles.vehicleSheetHandle} />
            <View style={styles.serviceModeToggle}>
              {serviceModeTabs.map((tab) => {
                const isActive = serviceMode === tab.id;
                return (
                  <TouchableOpacity
                    key={tab.id}
                    onPress={() => {
                      hapticFeedback('light');
                      setServiceMode(tab.id);
                    }}
                    style={[
                      styles.serviceModeTab,
                      isActive ? { borderBottomColor: tab.accent } : null,
                    ]}
                    activeOpacity={0.7}
                    accessibilityRole="tab"
                    accessibilityState={{ selected: isActive }}
                    accessibilityLabel={tab.label}
                  >
                    <Text
                      style={[
                        styles.serviceModeTabLabel,
                        isActive
                          ? { color: tab.accent }
                          : styles.serviceModeTabLabelIdle,
                      ]}
                      numberOfLines={1}
                    >
                      {tab.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={[styles.vehicleSheetScrollH, styles.vehicleSheetScrollHService, { height: wishCarouselHeight }]}
                contentContainerStyle={styles.choiceCardsHScrollContentService}
                snapToInterval={WISH_CARD_STEP}
                decelerationRate="fast"
                snapToAlignment="start"
                keyboardShouldPersistTaps="handled"
              >
                {currentServiceOptions.map((service) => {
                  const isSelected = selectedService === service.id;
                  const serviceColor = service.colors[0];
                  const packageTagline =
                    getWashPackageTagline(service.id) ?? service.descriptionTitle ?? '';
                  const cardSubtitle = packageTagline || service.desc || '';

                  return (
                    <TouchableOpacity
                      key={service.id}
                      activeOpacity={0.92}
                      onPress={() => {
                        void (async () => {
                          hapticFeedback('light');
                          await handleServiceSelect(service.id);
                        })();
                      }}
                      style={[styles.wishOptionCardOuter, { width: WISH_CARD_W }]}
                    >
                      <IndexTrackingCardShell
                        accentColor={serviceColor}
                        compact
                        style={[
                          styles.wishPackageCard,
                          {
                            borderColor: isSelected ? serviceColor + 'B3' : 'rgba(148,163,184,0.22)',
                            borderWidth: isSelected ? 2 : 1,
                          },
                        ]}
                      >
                        <View style={ix.optionCardTopRow}>
                          <ServiceTierSpongeIcon
                            accentColor={serviceColor}
                            iconName={getServiceTierLeadIconName(service.id)}
                            boxSize={48}
                          />
                          <View style={ix.optionTitleMain}>
                            <Text style={ix.optionTitle} numberOfLines={1}>
                              {service.name}
                            </Text>
                            {cardSubtitle ? (
                              <Text style={ix.optionSubtitle} numberOfLines={2}>
                                {cardSubtitle}
                              </Text>
                            ) : null}
                          </View>
                          <TouchableOpacity
                            style={[
                              ix.optionInfoBtn,
                              { borderColor: serviceColor + '35', backgroundColor: serviceColor + '12' },
                            ]}
                            onPress={(e) => {
                              e.stopPropagation?.();
                              hapticFeedback('light');
                              setInfoService(service);
                            }}
                            activeOpacity={0.85}
                            accessibilityLabel="Service details"
                            accessibilityRole="button"
                          >
                            <Ionicons name="information-circle-outline" size={22} color={serviceColor} />
                          </TouchableOpacity>
                        </View>
                        <View style={[ix.optionFooterRow, styles.wishCardFooterRow]}>
                          <View style={ix.optionFooterLeft}>
                            <View
                              style={[
                                ix.optionStatusPill,
                                {
                                  backgroundColor: serviceColor + '14',
                                  borderColor: serviceColor + '30',
                                },
                              ]}
                            >
                              <Ionicons name="time-outline" size={13} color={serviceColor} />
                              <Text style={[ix.optionStatusText, { color: serviceColor }]} numberOfLines={1}>
                                {service.dur}
                              </Text>
                            </View>
                            <View
                              style={[
                                ix.optionStatusPill,
                                { backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(148,163,184,0.2)' },
                              ]}
                            >
                              <Ionicons name="pricetag-outline" size={13} color={serviceColor} />
                              <Text style={ix.optionStatusText} numberOfLines={1}>
                                Prices vary
                              </Text>
                            </View>
                            {isSelected && effectiveSelectedAddOns.length > 0 ? (
                              <TouchableOpacity
                                onPress={(e) => {
                                  e.stopPropagation?.();
                                  hapticFeedback('light');
                                  setShowAddOnsModal(true);
                                }}
                                activeOpacity={0.85}
                                style={[
                                  ix.optionStatusPill,
                                  styles.addOnsCountPillInline,
                                  {
                                    backgroundColor: serviceColor + '14',
                                    borderColor: serviceColor + '55',
                                  },
                                ]}
                                hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
                                accessibilityRole="button"
                                accessibilityLabel={`${effectiveSelectedAddOns.length} add-on${effectiveSelectedAddOns.length === 1 ? '' : 's'} selected`}
                              >
                                <Text style={[styles.addOnsCountPlus, { color: serviceColor }]}>+</Text>
                                <Text style={[styles.addOnsCountNumber, { color: serviceColor }]}>
                                  {effectiveSelectedAddOns.length}
                                </Text>
                              </TouchableOpacity>
                            ) : null}
                          </View>
                        </View>
                      </IndexTrackingCardShell>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
              <View style={[styles.sheetPrimaryCtaRow, styles.sheetPrimaryCtaRowVehicleStep]}>
                <View style={styles.wishCtaActionRow}>
                  <TouchableOpacity
                    style={[
                      customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                      customerMapTrackingSheetActionStyles.bookingInfoCard,
                      styles.bookingSheetTrackingCta,
                      {
                        borderColor: serviceContinueAccent + '8A',
                        opacity: serviceContinueReady ? 1 : 0.45,
                      },
                    ]}
                    onPress={() => void handleServiceContinue()}
                    disabled={!serviceContinueReady}
                    activeOpacity={0.85}
                  >
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient
                      colors={[serviceContinueAccent + '59', 'rgba(15,23,42,0.65)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <Ionicons name="arrow-forward-circle" size={18} color={serviceContinueAccent} style={{ zIndex: 1 }} />
                    <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                      <Text style={[styles.bookingSheetCtaLabel, { color: serviceContinueAccent }]}>Continue to {CCP.singularShort}</Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                      customerMapTrackingSheetActionStyles.bookingInfoCard,
                      styles.bookingSheetTrackingCta,
                      styles.ctaVehicleCompanionCta,
                      {
                        borderColor: serviceContinueAccent + '8A',
                        opacity: serviceContinueReady ? 1 : 0.45,
                      },
                    ]}
                    onPress={() => {
                      hapticFeedback('light');
                      setCurrentStep('location');
                    }}
                    activeOpacity={0.85}
                    accessibilityRole="button"
                    accessibilityLabel={`${selectedVehicleIds.length} vehicle${selectedVehicleIds.length === 1 ? '' : 's'} selected. Tap to change.`}
                  >
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient
                      colors={[serviceContinueAccent + '59', 'rgba(15,23,42,0.65)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <Ionicons name="car-sport" size={18} color={serviceContinueAccent} style={{ zIndex: 1 }} />
                    <Text style={[styles.ctaVehicleCountText, { color: serviceContinueAccent }]}>
                      {selectedVehicleIds.length}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        )}
        </Animated.View>

        <BookingBottomSheetOverlay visible={!!infoService} onClose={() => setInfoService(null)} maxHeightRatio={0.9}>
          {infoService ? (
            <>
              <View style={styles.serviceInfoSheetHero}>
                <Text style={[styles.serviceInfoSheetName, { color: infoSheetAccent }]} numberOfLines={2}>
                  {infoService.name}
                  {infoService.id === 'bronze-wash' && washType
                    ? ` · ${washType === 'exterior' ? 'Exterior' : 'Interior'}`
                    : ''}
                </Text>
              </View>
              <ScrollView
                style={styles.serviceInfoScroll}
                contentContainerStyle={styles.infoModalScrollContent}
                showsVerticalScrollIndicator
              >
                {infoService.descriptionTitle ? (
                  <Text style={[styles.infoModalDescTitle, { color: infoSheetAccent }]}>{infoService.descriptionTitle}</Text>
                ) : null}
                <Text style={styles.infoModalDesc}>
                  {(() => {
                    if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                      return 'A quick exterior refresh to keep your vehicle looking clean and presentable.';
                    }
                    if (infoService.id === 'bronze-wash' && washType === 'interior') {
                      return "A light interior refresh designed to tidy and freshen your vehicle's cabin.";
                    }
                    return infoService.desc ?? '';
                  })()}
                </Text>
                {(() => {
                  let bulletPoints: string[];
                  if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                    bulletPoints = [
                      'Wheels and wheel arches cleaned',
                      'Snow foam pre-wash applied',
                      'Safe exterior hand wash',
                      'Vehicle fully rinsed',
                      'Exterior hand dried',
                      'Windows and mirrors cleaned',
                      'Ideal for regular maintenance washes and light dirt removal',
                    ];
                  } else if (infoService.id === 'bronze-wash' && washType === 'interior') {
                    bulletPoints = [
                      'Rubbish removed',
                      'Interior vacuum (seats, carpets, and mats)',
                      'Dashboard and main surfaces wiped down',
                      'Steering wheel cleaned',
                      'Interior glass cleaned',
                      'Air freshener applied',
                      'Perfect for maintaining a clean and comfortable interior between deeper cleans',
                    ];
                  } else {
                    bulletPoints = infoService.bulletPoints ?? [];
                  }
                  return bulletPoints.length > 0 ? (
                    <View style={styles.infoModalBullets}>
                      {bulletPoints.map((point: string) => (
                        <View key={point} style={styles.infoModalBulletRow}>
                          <View style={[styles.infoModalBulletDot, { backgroundColor: infoSheetAccent }]} />
                          <Text style={styles.infoModalBulletText}>{point}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null;
                })()}
                {effectiveSelectedAddOns.length > 0 ? (
                  <View style={styles.infoModalAddOns}>
                    <Text style={styles.infoModalAddOnsTitle}>Selected add-ons</Text>
                    {effectiveSelectedAddOns.map((id) => {
                      const addOn = addOnOptions.find((a) => a.id === id);
                      if (!addOn) return null;
                      return (
                        <View key={addOn.id} style={styles.infoModalAddOnRow}>
                          <Ionicons name={addOn.icon as any} size={18} color={infoSheetAccent} />
                          <Text style={styles.infoModalAddOnName}>{addOn.name}</Text>
                          <Text style={styles.infoModalAddOnPrice}>+£{addOn.price}</Text>
                        </View>
                      );
                    })}
                    <View style={styles.infoModalAddOnTotal}>
                      <Text style={styles.infoModalAddOnTotalLabel}>Total</Text>
                      <Text style={styles.infoModalAddOnTotalValue}>+£{addOnsTotal}</Text>
                    </View>
                  </View>
                ) : null}
              </ScrollView>
              <TouchableOpacity onPress={() => setInfoService(null)} style={styles.infoModalDoneWrap} activeOpacity={0.9}>
                <LinearGradient colors={[infoSheetAccent, infoSheetAccent + 'E6']} style={styles.infoModalDoneBtn}>
                  <Text style={styles.infoModalDoneText}>Done</Text>
                </LinearGradient>
              </TouchableOpacity>
            </>
          ) : null}
        </BookingBottomSheetOverlay>

        <VehicleInfoOverlay
          visible={!!infoVehicle}
          vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: (infoVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoVehicle as any).mot_expiry_date ?? null, mileage: (infoVehicle as any).mileage ?? null, tax_status: (infoVehicle as any).tax_status ?? null, tax_due_date: (infoVehicle as any).tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
          stats={vehicleStats}
          accentColor={SKY}
          onClose={() => setInfoVehicle(null)}
        />

        {/* Address search bottom sheet */}
        <BookingBottomSheetOverlay visible={showAddressOverlay} onClose={closeAddressOverlayWithoutSaving} maxHeightRatio={0.92}>
          <KeyboardAvoidingView
            style={styles.addressOverlayKeyboardWrap}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <View style={styles.addressOverlayContent}>
              <View style={styles.addressOverlayContentInner}>
                <Text style={styles.addressOverlayTitle}>Change location</Text>
                <Text style={styles.addressOverlaySubtitle}>Current location is default. Pick a saved place or search.</Text>
                <TouchableOpacity
                  style={styles.addressOverlayUseCurrent}
                  onPress={async () => {
                    await handleUseCurrentLocation();
                    closeAddressOverlayWithoutSaving();
                  }}
                  activeOpacity={0.8}
                >
                  <Ionicons name="locate" size={18} color={SKY} />
                  <Text style={styles.addressOverlayUseCurrentText}>Use current location</Text>
                </TouchableOpacity>
                {savedLocations.length > 0 && (
                  <>
                    <Text style={styles.addressOverlaySavedLabel}>Saved locations</Text>
                    <ScrollView style={styles.addressOverlaySavedList} keyboardShouldPersistTaps="handled" nestedScrollEnabled>
                      {savedLocations.map((item) => (
                        <TouchableOpacity
                          key={item.id}
                          style={styles.addressOverlaySavedItem}
                          onPress={() => handlePickSavedLocation(item)}
                          activeOpacity={0.8}
                        >
                          <Ionicons name="location" size={18} color={SKY} />
                          <View style={styles.addressOverlaySavedItemText}>
                            <Text style={styles.addressOverlaySavedItemLabel}>{item.label}</Text>
                            <Text style={styles.addressOverlaySavedItemAddress} numberOfLines={1}>{item.address}</Text>
                          </View>
                          <Ionicons name="chevron-forward" size={18} color="#64748B" />
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  </>
                )}
                <Text style={styles.addressOverlaySearchLabel}>Or search for an address</Text>
                <TextInput
                  style={styles.addressOverlayInput}
                  placeholder="Find your postcode..."
                  placeholderTextColor="#64748B"
                  value={addressSearchInput}
                  onChangeText={setAddressSearchInput}
                  onFocus={() => {
                    setAddressSearchInput('');
                    setAddressSuggestions([]);
                    setLoadingSuggestions(false);
                  }}
                  onSubmitEditing={handleAddressSearch}
                  returnKeyType="search"
                  autoCapitalize="none"
                />
                {loadingSuggestions && (
                  <View style={styles.addressSuggestionsLoading}>
                    <ActivityIndicator size="small" color={SKY} />
                  </View>
                )}
                {!loadingSuggestions && addressSuggestions.length > 0 && (
                  <ScrollView
                    style={styles.addressSuggestionsList}
                    keyboardShouldPersistTaps="handled"
                    nestedScrollEnabled
                  >
                    {addressSuggestions.map((s) => (
                      <TouchableOpacity
                        key={s.id}
                        style={styles.addressSuggestionItem}
                        onPress={() => handleSelectSuggestion(s)}
                        activeOpacity={0.7}
                      >
                        <Ionicons name="location-outline" size={18} color={SKY} />
                        <Text style={styles.addressSuggestionText} numberOfLines={2}>{s.description}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                )}
                <View style={styles.addressOverlayButtons}>
                  <TouchableOpacity style={styles.addressOverlayCancel} onPress={closeAddressOverlayWithoutSaving} activeOpacity={0.8}>
                    <Text style={styles.addressOverlayCancelText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.addressOverlaySearch, addressSearching && { opacity: 0.7 }]}
                    onPress={handleAddressSearch}
                    disabled={addressSearching}
                    activeOpacity={0.8}
                  >
                    {addressSearching ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="search" size={18} color="#fff" />
                        <Text style={styles.addressOverlaySearchText}>Search</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </KeyboardAvoidingView>
        </BookingBottomSheetOverlay>
      </Animated.View>

      {currentStep === 'location' ? (
        <View
          style={[
            styles.locationBottomPanel,
            {
              bottom: locationKeyboardHeight,
              paddingBottom: locationKeyboardHeight > 0 ? 12 : Math.max(insets.bottom, 14) + 10,
            },
            sheetRimColor ? { borderColor: sheetRimColor } : null,
          ]}
        >
          <BusinessSheetBackground />
          <View style={styles.locationSheetHandle} />
          <View style={styles.locationSheetSearchWrap}>
            {showVehicleRegInput ? (
              <View style={styles.inlineSearchRow}>
                <TouchableOpacity
                  onPress={closeVehicleRegInput}
                  style={styles.inlineRegBackBtn}
                  activeOpacity={0.8}
                  accessibilityLabel="Back to address search"
                >
                  <Ionicons name="chevron-back" size={18} color={SKY} />
                </TouchableOpacity>
                <Ionicons name="car-sport-outline" size={18} color={SKY} />
                <TextInput
                  style={styles.inlineSearchInput}
                  placeholder="Enter registration (e.g. AB12 CDE)"
                  placeholderTextColor="#94A3B8"
                  value={vehicleRegInput}
                  onChangeText={(text) => setVehicleRegInput(text.toUpperCase())}
                  onSubmitEditing={() => { void handleVehicleRegSubmit(); }}
                  returnKeyType="done"
                  autoCapitalize="characters"
                  autoCorrect={false}
                  editable={!vehicleRegSaving}
                />
                <TouchableOpacity
                  onPress={() => { void handleVehicleRegSubmit(); }}
                  style={[styles.inlineSearchGo, vehicleRegSaving && { opacity: 0.6 }]}
                  activeOpacity={0.8}
                  disabled={vehicleRegSaving}
                >
                  {vehicleRegSaving ? (
                    <ActivityIndicator size="small" color="#FFFFFF" />
                  ) : (
                    <Ionicons name="add" size={18} color="#FFFFFF" />
                  )}
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <View style={styles.inlineSearchRow}>
                  <Ionicons name="search" size={18} color={SKY} />
                  <TextInput
                    style={styles.inlineSearchInput}
                    placeholder="Search address or postcode"
                    placeholderTextColor="#94A3B8"
                    value={addressSearchInput}
                    onChangeText={(text) => {
                      setAddressSearchInput(text);
                      setShowInlineSuggestions(true);
                    }}
                    onSubmitEditing={() => { void handleAddressSearch(); }}
                    returnKeyType="search"
                  />
                  <TouchableOpacity
                    onPress={() => { void handleAddressSearch(); }}
                    style={styles.inlineSearchGo}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
                  </TouchableOpacity>
                </View>
                {showInlineSuggestions && addressSuggestions.length > 0 ? (
                  <ScrollView
                    style={[
                      styles.inlineSuggestionsList,
                      locationKeyboardHeight > 0 ? styles.inlineSuggestionsListKeyboard : null,
                    ]}
                    keyboardShouldPersistTaps="handled"
                    nestedScrollEnabled
                  >
                    {addressSuggestions.map((s) => (
                      <TouchableOpacity
                        key={s.id}
                        style={styles.inlineSuggestionItem}
                        onPress={() => { void handleSelectSuggestion(s); setShowInlineSuggestions(false); }}
                        activeOpacity={0.8}
                      >
                        <Ionicons name="location-outline" size={16} color={SKY} />
                        <Text style={styles.inlineSuggestionText} numberOfLines={1}>{s.description}</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                ) : null}
              </>
            )}
          </View>
          <View style={styles.locationBottomCard}>
            <View style={styles.locationBottomCardTopRow}>
              <Ionicons name="location-outline" size={15} color={SKY} />
              <Text style={styles.locationLocationLabel}>Selected location</Text>
            </View>
            <Text style={styles.locationAddressText} numberOfLines={2}>
              {selectedLocation?.address || 'Move the map to choose your wash location'}
            </Text>
            <VehiclePickerInline
              vehicles={vehicles}
              selectedIds={selectedVehicleIds}
              onToggle={toggleSelectedVehicle}
              loading={loading}
              compact
              onAddVehicle={openVehicleRegInput}
            />
            <WWPrimaryButton
              title="Continue"
              onPress={() => { void handleLocationAndVehicleContinue(); }}
              disabled={!selectedLocation || selectedVehicleIds.length === 0}
              leftIconName="arrow-forward"
              leftIconSize={18}
              style={{ marginTop: 4, width: '100%' }}
            />
          </View>
        </View>
      ) : null}

      {/* Add-ons bottom sheet — root level so layout is not clipped by the animated service sheet */}
      <BookingBottomSheetOverlay
        visible={showAddOnsModal}
        onClose={() => setShowAddOnsModal(false)}
        maxHeightRatio={0.68}
        compact
        sheetStyle={styles.uberPopupSheet}
      >
        <View style={styles.uberPopupWrap}>
          <Text style={[styles.uberPopupTitleBar, { color: addOnsSheetAccent }]}>{ADD_ON_SECTION_TITLE}</Text>
          <Text style={styles.uberPopupSubtitleBar} numberOfLines={1}>
            {ADD_ON_SECTION_SUBTITLE}
          </Text>

          {availableAddOnOptions.length > 0 ? (
            <ScrollView
              style={[styles.uberPopupScroll, { maxHeight: addOnsPopupScrollMaxHeight }]}
              contentContainerStyle={styles.uberPopupScrollContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              {availableAddOnOptions.map((addOn) => {
                const isSelected = selectedAddOns.includes(addOn.id);
                return (
                  <View key={addOn.id}>
                    {renderUberPopupRow({
                      accent: addOnsSheetAccent,
                      selected: isSelected,
                      onPress: () => toggleAddOn(addOn.id),
                      icon: (addOn.icon ?? 'add') as keyof typeof Ionicons.glyphMap,
                      title: addOn.name,
                      meta: addOn.desc,
                      trailing: isSelected ? 'check' : 'price',
                      trailingLabel: isSelected ? undefined : `+£${addOn.price}`,
                    })}
                  </View>
                );
              })}
            </ScrollView>
          ) : (
            <View style={styles.uberPopupEmpty}>
              <Text style={styles.uberPopupEmptyText}>No add-ons available for this service.</Text>
            </View>
          )}

          <View style={styles.uberPopupFooter}>
            {effectiveSelectedAddOns.length > 0 ? (
              <View style={styles.uberPopupTotalInline}>
                <Text style={styles.uberPopupTotalLabel}>Total</Text>
                <Text style={[styles.uberPopupTotalValue, { color: addOnsSheetAccent }]}>
                  +£{addOnsTotal.toFixed(2)}
                </Text>
              </View>
            ) : null}
            <TouchableOpacity
              onPress={() => {
                hapticFeedback('light');
                setShowAddOnsModal(false);
              }}
              style={[
                customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                customerMapTrackingSheetActionStyles.bookingInfoCard,
                styles.uberPopupPrimaryCta,
                { borderColor: addOnsSheetAccent + '8A' },
              ]}
              activeOpacity={0.85}
            >
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={[addOnsSheetAccent + '59', 'rgba(15,23,42,0.65)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <Text style={[styles.uberPopupPrimaryCtaText, { color: addOnsSheetAccent, zIndex: 1 }]}>
                {effectiveSelectedAddOns.length > 0 ? 'Done' : 'Not today thanks'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </BookingBottomSheetOverlay>

      {/* Bronze wash: exterior / interior bottom sheet */}
      <BookingBottomSheetOverlay
        visible={showBronzeWashTypeOverlay}
        onClose={() => setShowBronzeWashTypeOverlay(false)}
        maxHeightRatio={0.34}
        compact
        sheetStyle={styles.uberPopupSheet}
      >
        <View style={styles.uberPopupWrap}>
          <Text style={[styles.uberPopupTitleBar, { color: bronzeWashSheetAccent }]}>Inside or outside?</Text>

          <View style={styles.uberPopupChoiceStack}>
            {renderUberPopupRow({
              accent: bronzeWashSheetAccent,
              selected: washType === 'exterior',
              onPress: () => { void handleWashTypeSelect('exterior'); },
              icon: 'car-sport-outline',
              title: 'Exterior',
              meta: 'Snow foam, hand wash & wheels',
              trailing: 'chevron',
            })}
            {renderUberPopupRow({
              accent: bronzeWashSheetAccent,
              selected: washType === 'interior',
              onPress: () => { void handleWashTypeSelect('interior'); },
              icon: 'layers-outline',
              title: 'Interior',
              meta: 'Vacuum, wipe-down & glass',
              trailing: 'chevron',
            })}
          </View>
        </View>
      </BookingBottomSheetOverlay>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  videoLoadingSkeleton: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.BG ?? '#0A1929',
    zIndex: 9999,
    elevation: 999,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1.5,
    borderColor: 'rgba(126,184,212,0.5)',
    backgroundColor: 'rgba(2,6,23,0.36)',
    shadowColor: '#38BDF8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 7,
  },
  userMarker: {
    width: 42,
    height: 42,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  selectedLocationMarkerCar: {
    width: 48,
    height: 48,
  },
  centerPickerWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerPin: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.22)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.45)',
  },
  centerPickerCar: {
    width: 42,
    height: 42,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 50,
    height: 50,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '8A',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  locationSheetShell: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: 300,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(2,6,23,0.08)',
    overflow: 'hidden',
  },
  locationSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  locationSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 8,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  mapStageWrap: {
    flex: 1,
    overflow: 'hidden',
  },
  serviceMapTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.28)',
  },
  serviceMapTintGradient: {
    ...StyleSheet.absoluteFillObject,
  },
  locationSheetSearchWrap: {
    marginBottom: 10,
  },
  locationBottomPanel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 0,
    zIndex: 7,
    overflow: 'hidden',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  locationBottomCard: {
    paddingHorizontal: 0,
    paddingTop: 4,
    paddingBottom: 0,
    backgroundColor: 'transparent',
  },
  locationBottomCardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  locationLocationLabel: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
    color: 'rgba(148,163,184,0.9)',
  },
  locationAddressText: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '800',
    lineHeight: 22,
    marginBottom: 10,
  },
  stepDots: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 100,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(148,163,184,0.4)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  modernCard: {
    padding: 12,
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    minHeight: 142,
  },
  locationPremiumCardWrap: {
    marginVertical: 2,
  },
  locationPremiumCard: {
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 7,
  },
  locationPremiumDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.2)',
  },
  locationPremiumGlowOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 14,
    elevation: 4,
  },
  locationPremiumContent: {
    padding: 14,
  },
  locationV2Card: {
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 10,
  },
  locationV2Header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  locationV2Icon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: SKY + '55',
    backgroundColor: SKY + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  locationV2TitleWrap: { flex: 1 },
  locationV2Kicker: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  locationV2Title: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    marginTop: 1,
  },
  locationV2Address: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
  },
  locationV2AddressMuted: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  locationV2Hint: {
    marginTop: 8,
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  resourcesV2Card: {
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 6,
  },
  locationSectionKicker: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.4,
    marginBottom: 6,
  },
  modernCardEmpty: {
    alignItems: 'center',
  },
  modernCardSelected: {
    borderColor: SKY + '90',
    shadowColor: SKY,
    shadowOpacity: 0.28,
    shadowRadius: 12,
    elevation: 6,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  titleAndBadge: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  serviceTitleActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexShrink: 0,
  },
  addOnsCountPillInline: {
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  addOnsCountPlus: {
    fontSize: 14,
    fontWeight: '800',
    marginTop: -1,
  },
  addOnsCountNumber: {
    fontSize: 13,
    fontWeight: '800',
    minWidth: 14,
    textAlign: 'center',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 12,
    fontWeight: '600',
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  locationMicrocopy: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '600',
    color: SKY,
  },
  locationFooter: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.12)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  locationFooterText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  washTypeQuestion: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  titleRowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  changeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  changeBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  changeBtnFullWidth: {
    marginTop: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  changeBtnSeparate: {
    marginTop: 10,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 12,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 6,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.28)',
    backgroundColor: 'rgba(30,41,59,0.45)',
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '700',
  },
  createVehicleMetaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 0,
  },
  createVehicleMetaPillText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10B981',
  },
  washTypeChipSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 5,
    paddingHorizontal: 9,
    borderRadius: 8,
    borderWidth: 1,
    gap: 4,
    maxWidth: 132,
    flexShrink: 1,
  },
  washTypeChipSmallText: {
    fontSize: 11,
    fontWeight: '700',
  },
  serviceCardFooterRow: {
    flexWrap: 'nowrap',
    gap: 8,
    alignItems: 'center',
  },
  serviceCardTaglineSlot: {
    marginTop: 0,
    justifyContent: 'flex-start',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  conditionMapBannerWrap: {
    position: 'absolute',
    top: 10,
    left: 16,
    right: 16,
    zIndex: 130,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: `${DETAILING_YELLOW}40`,
    backgroundColor: 'rgba(2,6,23,0.72)',
    shadowColor: DETAILING_YELLOW,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 10,
  },
  conditionMapBannerInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 11,
    paddingHorizontal: 12,
    zIndex: 1,
  },
  conditionMapBannerIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  conditionMapBannerText: {
    flex: 1,
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  vehicleStepWrap: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  locationRowAboveCards: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  locationRowValue: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  /** Mobile service/package steps: extra top inset so cards sit lower in the sheet. */
  bookingIndexOptionsScroll: {
    marginTop: 24,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  /** Mobile choose-your-vehicle step: cards sit slightly higher. */
  bookingIndexOptionsScrollVehicle: {
    marginTop: 18,
    paddingLeft: 14,
    paddingRight: 12,
    gap: 10,
  },
  vehicleCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  locationCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  /* Vehicle cards – compact, below location row */
  vehicleCard: {
    padding: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  vehicleCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  vehicleCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  vehicleCardCarIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 36,
  },
  vehicleCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  vehicleCardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  vehicleCardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  vehicleCardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 4,
  },
  vehicleCardDefaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  vehicleCardDefaultText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FBBF24',
  },
  vehicleCardPhotoBox: {
    width: 44,
    height: 44,
    borderRadius: 10,
    overflow: 'hidden',
    marginLeft: 8,
  },
  vehicleCardPhotoSmall: {
    width: 44,
    height: 44,
  },
  vehicleCardPhotoPlaceholder: {
    width: 44,
    height: 44,
    backgroundColor: 'rgba(135,206,235,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardDivider: {
    height: 1,
    marginTop: 10,
    marginBottom: 8,
    borderRadius: 1,
    opacity: 0.6,
  },
  /* Combined location + vehicle single card */
  combinedCardScroll: {
    maxHeight: 340,
  },
  locationVehicleDivider: {
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.25)',
    marginHorizontal: 14,
    marginVertical: 4,
  },
  combinedVehicleSection: {
    paddingHorizontal: 14,
    paddingBottom: 14,
  },
  combinedVehicleSectionTitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  combinedVehicleLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
  },
  combinedVehicleLoadingText: {
    color: '#94A3B8',
    fontSize: 14,
  },
  combinedVehicleEmpty: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  combinedVehicleEmptyText: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 10,
  },
  combinedVehicleList: {
    paddingRight: 8,
    flexDirection: 'row',
  },
  vehicleRowInCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.25)',
    backgroundColor: 'rgba(15,23,42,0.4)',
    minWidth: 160,
    maxWidth: 200,
    marginRight: 10,
  },
  vehicleRowInCardSelected: {
    borderColor: SKY + '66',
    backgroundColor: SKY + '12',
  },
  vehicleRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  vehicleRowContent: {
    flex: 1,
    minWidth: 0,
  },
  vehicleRowTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  vehicleRowSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
  },
  vehicleRowInfoBtn: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  vehicleCardCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  vehicleCardCtaText: {
    fontSize: 14,
    fontWeight: '600',
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  washTypePillClean: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  washTypePillTextClean: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  bronzeWashTypeOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  bronzeWashTypeModalContent: {
    width: '100%',
    minHeight: 280,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 6,
  },
  bronzeWashTypeModalContentInner: {
    minHeight: 260,
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 20,
  },
  bronzeWashTypeModalAccent: {
    height: 4,
    width: '100%',
  },
  bronzeWashTypeModalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: 14,
  },
  bronzeWashTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 2,
  },
  bronzeWashTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  bronzeWashTypeModalClose: {
    padding: 4,
  },
  bronzeWashTypeModalOptions: {
    gap: 10,
  },
  bronzeWashTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bronzeWashTypeModalOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bronzeWashTypeModalOptionText: {
    flex: 1,
  },
  bronzeWashTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  bronzeWashTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  serviceStepWrap: {
    width: '100%',
  },
  mobileChoiceScreen: {
    flex: 1,
    width: '100%',
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  mobileChoiceCardsArea: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-start',
  },
  mobileChoiceFooterArea: {
    width: '100%',
  },
  vehicleSheetScreen: {
    flex: 1,
    width: '100%',
    justifyContent: 'flex-end',
  },
  vehicleBottomSheet: {
    width: '100%',
    paddingTop: 0,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  vehicleSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  vehicleSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  vehicleSheetScroll: {
    flexGrow: 0,
    flexShrink: 1,
    maxHeight: 420,
    width: '100%',
  },
  vehicleSheetScrollH: {
    flexGrow: 0,
    width: '100%',
  },
  vehicleSheetScrollHService: {
    marginTop: 6,
  },
  choiceCardsHScrollContent: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    alignItems: 'stretch',
  },
  choiceCardsHScrollContentService: {
    paddingLeft: 14,
    paddingRight: 20,
    paddingTop: 2,
    paddingBottom: 4,
    alignItems: 'flex-start',
  },
  wishOptionCardOuter: {
    marginRight: BOOKING_H_CARD_GAP,
    alignSelf: 'flex-start',
  },
  choiceCardH: {
    marginRight: BOOKING_H_CARD_GAP,
  },
  /** Explicit heights stop the horizontal scroll from collapsing inside the flex column. */
  choiceScrollHVehicle: {
    height: 144,
  },
  physicalListCardWrap: {
    width: '100%',
  },
  physicalListCard: {
    flex: 1,
    width: '100%',
    minHeight: 132,
  },
  wishPackageCard: {
    alignSelf: 'stretch',
  },
  wishCardFooterRow: {
    marginTop: 8,
    paddingTop: 6,
    minHeight: 0,
    marginBottom: 0,
  },
  physicalListCardSelected: {
    borderColor: SKY + '90',
    borderWidth: 2,
  },
  physicalCardTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  physicalIconBadge: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceCardSpongeSlot: {
    marginRight: 12,
  },
  physicalCardTitleMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 8,
  },
  physicalCardKicker: {
    color: '#38BDF8',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    marginBottom: 3,
  },
  physicalCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  physicalCardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  physicalInfoBtn: {
    padding: 6,
    borderRadius: 10,
  },
  tierTagline: {
    marginTop: 4,
    fontSize: 11,
    fontWeight: '700',
    lineHeight: 14,
    letterSpacing: 0.2,
  },
  packageCardBio: {
    marginTop: 4,
    fontSize: 11,
    fontWeight: '500',
    lineHeight: 15,
    color: 'rgba(148,163,184,0.92)',
  },
  physicalCardDesc: {
    flex: 1,
    width: '100%',
  },
  vehicleChoiceListContent: {
    paddingTop: 8,
    paddingBottom: 12,
    paddingHorizontal: 14,
    gap: 10,
    alignItems: 'stretch',
  },
  vehicleChoiceCard: {
    width: '100%',
    maxWidth: 520,
    alignSelf: 'center',
  },
  vehicleChoiceCardSelected: {
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 10,
    elevation: 4,
  },
  vehicleChoiceCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  vehicleCardInner: {
    flex: 1,
    justifyContent: 'center',
  },
  serviceCardInner: {
    flex: 1,
    justifyContent: 'center',
  },
  vehicleChoiceLoadingCard: {
    minHeight: 84,
  },
  /** Stops the row from stretching in the column so the Continue bar sits tight under the cards. */
  bookingStepHorizontalScroll: {
    flexGrow: 0,
    flexShrink: 0,
  },
  sheetPrimaryCtaRow: {
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 4,
    marginTop: 0,
    paddingBottom: 0,
  },
  /** Make a wish: CTA sits tight under the carousel. */
  sheetPrimaryCtaRowVehicleStep: {
    marginTop: 0,
  },
  /** Continue + vehicle count sit side-by-side under wish cards. */
  wishCtaActionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    width: '100%',
  },
  /** Mirrors `tracking.tsx` `bookingDetailsBtn` — compact vs default `bookingInfoCard`. */
  bookingSheetTrackingCta: {
    flex: 1,
    minWidth: 0,
    minHeight: 54,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 24,
    gap: 10,
  },
  ctaVehicleCompanionCta: {
    flex: 0,
    flexGrow: 0,
    width: 76,
    paddingHorizontal: 12,
    justifyContent: 'center',
  },
  ctaVehicleCountText: {
    fontSize: 13,
    fontWeight: '800',
    includeFontPadding: false,
    minWidth: 10,
    textAlign: 'center',
  },
  bookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  /** Compact Uber-style sheets for add-ons + bronze wash. */
  uberPopupSheet: {
    alignSelf: 'stretch',
  },
  uberPopupWrap: {
    width: '100%',
    paddingBottom: 2,
  },
  uberPopupTitleBar: {
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.2,
    marginBottom: 2,
  },
  uberPopupSubtitleBar: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  uberPopupScroll: {
    width: '100%',
  },
  uberPopupScrollContent: {
    gap: 6,
    paddingBottom: 4,
  },
  uberPopupChoiceStack: {
    gap: 6,
    paddingTop: 2,
  },
  uberPopupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 1,
  },
  uberPopupIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  uberPopupCopy: {
    flex: 1,
    minWidth: 0,
  },
  uberPopupTitle: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 18,
  },
  uberPopupMeta: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 1,
    lineHeight: 14,
  },
  uberPopupPrice: {
    fontSize: 13,
    fontWeight: '800',
    flexShrink: 0,
  },
  uberPopupCheck: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  uberPopupEmpty: {
    minHeight: 72,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  uberPopupEmptyText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  uberPopupFooter: {
    paddingTop: 12,
    paddingBottom: 6,
    gap: 8,
    marginTop: 8,
  },
  uberPopupTotalInline: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  uberPopupTotalLabel: {
    color: 'rgba(226,232,240,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  uberPopupTotalValue: {
    fontSize: 14,
    fontWeight: '800',
  },
  uberPopupPrimaryCta: {
    width: '100%',
    minHeight: 48,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
  },
  uberPopupPrimaryCtaText: {
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  vehicleSheetHeaderRow: {
    paddingHorizontal: 14,
    paddingTop: 6,
    paddingBottom: 6,
  },
  vehicleSheetTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  vehicleSheetKicker: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 3,
  },
  vehicleSheetSubtitle: {
    marginTop: 3,
    color: 'rgba(226,232,240,0.85)',
    fontSize: 11,
    fontWeight: '600',
  },
  vehiclePricingHint: {
    marginTop: 6,
    fontSize: 11,
    color: 'rgba(148,163,184,0.95)',
    fontWeight: '600',
    lineHeight: 15,
  },
  servicePackageTagline: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
  },
  vehicleSelectedBanner: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.45)',
    backgroundColor: 'rgba(56,189,248,0.12)',
    alignSelf: 'flex-start',
  },
  vehicleSelectedBannerText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  resourcesToggleFixed: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 10,
  },
  inlineSearchWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 120,
  },
  bookingAddressPillWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 120,
  },
  washTypeMapPillWrap: {
    left: 16,
  },
  bookingAddressPillPressable: {
    borderRadius: 999,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: `${SKY}45`,
    backgroundColor: 'rgba(2,6,23,0.72)',
  },
  bookingAddressPillInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  bookingAddressPillText: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  inlineSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(2,6,23,0.78)',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  inlineSearchInput: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  inlineRegBackBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  inlineSearchGo: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inlineSuggestionsList: {
    marginTop: 8,
    maxHeight: 180,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: 'rgba(2,6,23,0.88)',
    overflow: 'hidden',
  },
  inlineSuggestionsListKeyboard: {
    maxHeight: 120,
  },
  inlineSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  inlineSuggestionText: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '600',
  },
  resourcesHelperText: {
    marginTop: 8,
    paddingHorizontal: 8,
    color: 'rgba(241,245,249,0.85)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  serviceModeToggle: {
    flexDirection: 'row',
    alignItems: 'stretch',
    paddingHorizontal: 14,
    marginBottom: 8,
    marginTop: 0,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.14)',
  },
  serviceModeTab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
    marginBottom: -StyleSheet.hairlineWidth,
  },
  serviceModeTabLabel: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  serviceModeTabLabelIdle: {
    color: 'rgba(148,163,184,0.65)',
  },
  modalAddOnsSection: {
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '20',
  },
  modalAddOnsTitle: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  modalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  modalAddOnName: {
    color: colors.headerText,
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  modalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  modalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '18',
  },
  modalAddOnTotalLabel: {
    color: colors.headerSubtext,
    fontSize: 13,
    fontWeight: '600',
  },
  modalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 15,
    fontWeight: '800',
  },
  addOnsModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  addOnsModalContent: {
    width: '100%',
    height: '85%',
    maxHeight: 560,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    overflow: 'hidden',
  },
  addOnsModalContentInner: {
    flex: 1,
    minHeight: 0,
    padding: 20,
  },
  addOnsSheetRoot: {
    flex: 1,
    minHeight: 0,
  },
  addOnsOverlaySheet: {
    height: '86%',
  },
  addOnsModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  addOnsModalTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  addOnsModalTitleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  addOnsModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },
  addOnsModalList: {
    flex: 1,
    minHeight: 200,
  },
  addOnsModalListContent: {
    paddingBottom: 16,
  },
  addOnsModalEmptyState: {
    flex: 1,
    minHeight: 140,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
  },
  addOnsModalEmptyText: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  addOnsModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    marginBottom: 10,
  },
  addOnsModalRowSelected: {
    backgroundColor: SKY + '12',
    borderColor: SKY + '35',
  },
  addOnsModalRowIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  addOnsModalRowIconSelected: {
    backgroundColor: SKY + '25',
  },
  addOnsModalRowBody: {
    flex: 1,
    minWidth: 0,
  },
  addOnsModalRowName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  addOnsModalRowDesc: {
    color: '#94A3B8',
    fontSize: 12,
    lineHeight: 17,
    marginBottom: 4,
  },
  addOnsModalRowPriceInline: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '800',
  },
  addOnsModalRowPriceSelected: {
    color: SKY,
  },
  addOnsModalCheck: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: 'rgba(148,163,184,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  addOnsModalCheckSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  addOnsModalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    marginTop: 12,
    marginBottom: 12,
  },
  addOnsModalFooterWrap: {
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  addOnsModalFooterLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '700',
  },
  addOnsModalFooterValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  addOnsModalDoneWrap: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  addOnsModalDone: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalDoneText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceCardRight: {
    alignItems: 'flex-end',
    gap: 6,
  },
  servicePriceClean: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtnInCard: {
    padding: 4,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceBadgeBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  serviceBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeSection: {
    marginTop: 4,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  continueBtn: {
    height: 54,
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    width: '100%',
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Modal styles
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  infoModalCard: {
    width: '100%',
    height: '90%',
    maxHeight: '90%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(126,184,212,0.5)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.4,
    shadowRadius: 28,
    elevation: 16,
  },
  infoModalHeaderBar: {
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 20,
    position: 'relative',
  },
  infoModalHeaderLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 4,
  },
  infoModalHeaderTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.2,
    paddingRight: 44,
  },
  infoModalHeaderSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    fontWeight: '600',
  },
  infoModalHeaderPrice: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 15,
    fontWeight: '700',
    marginTop: 4,
  },
  infoModalCloseBtn: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalDescTitle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 4,
    paddingBottom: 24,
  },
  vehicleSelectedBannerWrap: {
    paddingHorizontal: 14,
    paddingTop: 2,
    paddingBottom: 10,
  },
  serviceInfoSheetHero: {
    marginBottom: 10,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  serviceInfoSheetName: {
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.2,
    color: '#F8FAFC',
  },
  serviceInfoScroll: {
    maxHeight: 440,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 16,
  },
  infoModalBullets: {
    gap: 10,
    marginBottom: 16,
  },
  infoModalBulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalBulletDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  infoModalBulletText: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  infoModalAddOns: {
    marginTop: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  infoModalAddOnsTitle: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  infoModalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  infoModalAddOnName: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  infoModalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 14,
    fontWeight: '700',
  },
  infoModalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalAddOnTotalLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  infoModalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDoneWrap: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    borderRadius: 14,
    overflow: 'hidden',
  },
  infoModalDoneBtn: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoModalDoneText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  infoModalVehiclePhotoWrap: {
    height: 140,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  infoModalVehiclePhoto: {
    width: '100%',
    height: '100%',
  },
  infoModalVehiclePhotoPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: customerTheme.primary + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalVehicleTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 18,
    letterSpacing: -0.2,
  },
  infoModalVehicleRows: {
    gap: 12,
  },
  infoModalVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalVehicleRowText: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  addressOverlayKeyboardWrap: {
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 40,
  },
  addressOverlayContent: {
    width: '100%',
    borderRadius: 26,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayContentInner: {
    padding: 24,
  },
  addressOverlayTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  addressOverlaySubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    marginBottom: 12,
    lineHeight: 20,
  },
  addressOverlayUseCurrent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    marginBottom: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: SKY + '18',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  addressOverlayUseCurrentText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlaySavedList: {
    maxHeight: 160,
    marginBottom: 16,
  },
  addressOverlaySavedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    gap: 10,
  },
  addressOverlaySavedItemText: {
    flex: 1,
  },
  addressOverlaySavedItemLabel: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedItemAddress: {
    color: '#94A3B8',
    fontSize: 13,
    marginTop: 2,
  },
  addressOverlaySearchLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlayInput: {
    backgroundColor: '#0F172A',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: SKY + '30',
  },
  addressSuggestionsLoading: { paddingVertical: 12, alignItems: 'center' },
  addressSuggestionsList: { maxHeight: 200, marginTop: 8 },
  addressSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(15,23,42,0.8)',
    borderRadius: 12,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: SKY + '20',
  },
  addressSuggestionText: { color: '#F1F5F9', fontSize: 14, flex: 1 },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    alignItems: 'center',
  },
  addressOverlayCancelText: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlaySearchWrap: {
    flex: 1,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  addressOverlaySearch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  modalContent: {
    backgroundColor: 'transparent',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 24,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '35',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  modalContentTouch: {
    width: '100%',
    maxWidth: 320,
    maxHeight: '82%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '30',
  },
  modalContentBlur: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingBottom: 16,
  },
  modalHeaderHubStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitleHubStyle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScrollContent: {
    maxHeight: 360,
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  modalIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: customerTheme.primary + '25',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    color: colors.headerText,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  modalPrice: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  modalDescription: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 12,
    opacity: 0.95,
  },
  bulletPointsContainer: {
    gap: 8,
    marginBottom: 14,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  bulletPointText: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 18,
    flex: 1,
    opacity: 0.92,
  },
  modalCloseButton: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    shadowColor: customerTheme.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3,
  },
  modalCloseButtonGradient: {
    padding: 12,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 0.3,
  },
});
