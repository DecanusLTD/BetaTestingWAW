import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Alert,
  ScrollView,
  Modal,
  Pressable,
  ActivityIndicator,
  Dimensions,
  TextInput,
  Keyboard,
  Platform,
  type KeyboardEvent,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import AppHeader from '../../../src/components/shared/AppHeader';
import BookingMapLocationFullHeader from '../../../src/components/booking/BookingMapLocationFullHeader';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import {
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../../src/constants/bookingCardTheme';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../src/components/booking/IndexTrackingCardShell';
import BookingSheetPremiumLayers from '../../../src/components/booking/BookingSheetPremiumLayers';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import { customerMapTrackingSheetActionStyles } from '../../../src/components/booking/CustomerMapTrackingSheetShell';
import { ACTIVE_CUSTOMER_BOOKING_STATUSES } from '../../../src/utils/activeBookingGuard';
import {
  BOOKING_MAP_STYLE,
  DEFAULT_MAP_REGION,
  LOCATION_PICKER_MAP_STYLE,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
} from '../../../src/constants/mapConstants';
import {
  MapMarkerWashHub,
  MapMarkerDetailingHub,
  MapMarkerCustomerVehicle,
  MapMarkerValeterAvatar,
  MapMarkerLocationAvatar,
} from '../../../src/components/maps/MapMarkerViews';
import { distanceKm } from '../../../src/utils/mapUtils';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';
import { WWPrimaryButton, WWSheetCloseButton } from '../../../src/components/ui';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../src/constants/launchCustomerScope';
import { CCP, ccpFallbackName, ccpPluralLower, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { fetchValeterIdentitiesByIds } from '../../../src/utils/valeterDisplayName';

const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');
/** Compact horizontally-scrolling "Book a Service" option card width (peek of next card). */
const INDEX_OPTION_CARD_W = Math.round(Math.min(300, SCREEN_W * 0.78));

const NEARBY_MAP_FIT_PADDING = { top: 72, right: 24, bottom: 100, left: 24 } as const;

/** Index only chooses delivery mode; wash vs detailing is chosen on the service sheets. */
const bookingIndexOptions = [
  {
    id: 'come-to-you',
    title: 'Come To You',
    subtitle: 'We come to your location',
    description:
      'A vetted professional brings the service to you with live tracking and updates. Choose wash or detailing when you pick your package.',
    trustLine: 'Vetted professionals',
    eta: '10–30 mins',
    icon: 'car-sport',
    route: '/owner/booking/create',
    params: {} as Record<string, string>,
  },
  {
    id: 'come-to-us',
    title: 'Come To Us',
    subtitle: 'Book at a verified wash or studio nearby',
    description:
      'Book a slot at a verified location nearby. Choose car wash or detail studio when you browse hubs.',
    trustLine: 'Verified locations',
    eta: "Today's slots",
    icon: 'business',
    route: '/owner/booking/physical/location',
    params: {} as Record<string, string>,
  },
] as const;

const visibleBookingIndexOptions = MOBILE_SERVICE_ONLY_LAUNCH
  ? bookingIndexOptions.filter((option) => option.id === 'come-to-you')
  : bookingIndexOptions;

type ActiveBooking = { id: string; status: string };
type ProviderLocation = {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  detailing_offered?: boolean | null;
  rating?: number | null;
  status?: string | null;
};
type ValeterPin = {
  id: string;
  name: string;
  rating: number;
  isOnline: boolean;
  photoUri: string | null;
  latitude: number;
  longitude: number;
};
type PickerLocation = { latitude: number; longitude: number; address: string };

/** Default zoom for the index background map — wide enough to show nearby pros / hubs. */
const INDEX_MAP_DELTA = 0.05;

/**
 * Marker that self-tracks briefly so dynamic pill content rasterizes on iOS,
 * then freezes (`tracksViewChanges=false`) to keep the map performant.
 */
function AutoTrackMarker({
  coordinate,
  children,
}: {
  coordinate: { latitude: number; longitude: number };
  children: React.ReactNode;
}) {
  const [track, setTrack] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setTrack(false), 1000);
    return () => clearTimeout(t);
  }, []);
  return (
    <Marker coordinate={coordinate} tracksViewChanges={track} anchor={{ x: 0.5, y: 1 }}>
      {children}
    </Marker>
  );
}

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { setTheme } = useBookingFlowTheme();

  const [indexFocusedOptionId, setIndexFocusedOptionId] = useState<
    (typeof visibleBookingIndexOptions)[number]['id']
  >(visibleBookingIndexOptions[0].id);

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);
  const [bookingStep, setBookingStep] = useState<'index' | 'pickup'>('index');
  const [pendingOption, setPendingOption] = useState<(typeof visibleBookingIndexOptions)[number] | null>(null);
  const [pickerLocation, setPickerLocation] = useState<PickerLocation | null>(null);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerMapRegion, setPickerMapRegion] = useState<Region | null>(null);
  const [pickupSearchQuery, setPickupSearchQuery] = useState('');
  const [pickupSearching, setPickupSearching] = useState(false);
  const [pickupKeyboardHeight, setPickupKeyboardHeight] = useState(0);
  const [providerLocations, setProviderLocations] = useState<ProviderLocation[]>([]);
  const [valeters, setValeters] = useState<ValeterPin[]>([]);
  /** Nearby hubs / studios on a map — opened from header tracking icon (video stays full-screen). */
  const [showNearbyMapSheet, setShowNearbyMapSheet] = useState(false);
  const [nearbyMapFocusId, setNearbyMapFocusId] = useState<string | null>(null);
  const pickerMapGeocodeDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(40)).current;
  const stepAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    setTheme('wash');
  }, [setTheme]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, slideAnim]);

  useEffect(() => {
    Animated.timing(stepAnim, {
      toValue: bookingStep === 'index' ? 0 : 1,
      duration: 340,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [bookingStep, stepAnim]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [markerPulse]);

  useEffect(() => {
    if (liveCoords) {
      const c = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(c);
      setRegion({ ...c, latitudeDelta: INDEX_MAP_DELTA, longitudeDelta: INDEX_MAP_DELTA });
      return;
    }
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const c = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setUserLocation(c);
        setRegion({ ...c, latitudeDelta: INDEX_MAP_DELTA, longitudeDelta: INDEX_MAP_DELTA });
      } catch {}
    })();
  }, [liveCoords]);

  useEffect(() => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) return;
    const loadProviders = async () => {
      try {
        const { data, error } = await supabase
          .from('car_wash_locations')
          .select('id,name,latitude,longitude,detailing_offered,rating,status');
        if (error) return;
        const normalized = (data || [])
          .map((row: any) => ({
            id: String(row.id),
            name: row.name || 'Service Provider',
            latitude: Number(row.latitude),
            longitude: Number(row.longitude),
            detailing_offered: row.detailing_offered ?? null,
            rating: row.rating != null ? Number(row.rating) : null,
            status: row.status ?? null,
          }))
          .filter((p: ProviderLocation) => Number.isFinite(p.latitude) && Number.isFinite(p.longitude));
        setProviderLocations(normalized);
      } catch {}
    };
    loadProviders();
  }, []);

  useEffect(() => {
    const loadValeters = async () => {
      try {
        const { data: presence, error } = await supabase
          .from('valeter_presence')
          .select('user_id, is_online, last_lat, last_lng');
        if (error) return;
        const online = (presence || []).filter(
          (p: any) => p.is_online && p.last_lat != null && p.last_lng != null,
        );
        if (!online.length) {
          setValeters([]);
          return;
        }
        const userIds = online.map((p: any) => String(p.user_id));
        const [identityMap, statsBatchRaw] = await Promise.all([
          fetchValeterIdentitiesByIds(userIds),
          ValeterStatsService.getValeterStatsBatch(userIds).catch(() => new Map()),
        ]);
        const statsBatch = statsBatchRaw as Map<string, { averageRating?: number }>;
        const list: ValeterPin[] = online.map((p: any) => {
          const uid = String(p.user_id);
          const identity = identityMap.get(uid);
          return {
            id: uid,
            name: identity?.name || ccpFallbackName(),
            rating: statsBatch.get(uid)?.averageRating ?? 0,
            isOnline: Boolean(p.is_online),
            photoUri: identity?.photoUrl ?? null,
            latitude: Number(p.last_lat),
            longitude: Number(p.last_lng),
          };
        });
        setValeters(list);
      } catch {}
    };
    loadValeters();
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    const loadActiveBooking = async () => {
      try {
        setCheckingActive(true);
        const { data, error } = await supabase
          .from('bookings')
          .select('id,status')
          .eq('user_id', user.id)
          .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES])
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (error || !data) {
          setActiveBooking(null);
          return;
        }
        setActiveBooking({ id: data.id, status: data.status });
      } finally {
        setCheckingActive(false);
      }
    };
    loadActiveBooking();
    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({ pathname: '/owner/booking/tracking', params: { bookingId: activeBooking.id } } as any);
  };

  const handleSelect = async (option: (typeof visibleBookingIndexOptions)[number]) => {
    if (checkingActive) return;
    if (activeBooking?.id) {
      Alert.alert(
        'One booking at a time',
        'You already have an active booking. Please complete or cancel it before starting a new one.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View my booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }
    await hapticFeedback('medium');
    if (option.route === '/owner/booking/create') {
      setPendingOption(option);
      setPickerLoading(true);
      setBookingStep('pickup');
      try {
        let coords = userLocation;
        if (!coords) {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status === 'granted') {
            const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
            coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
            setUserLocation(coords);
            setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
          }
        }
                if (coords) {
          try {
            const [result] = await Location.reverseGeocodeAsync(coords);
            const addr = result
              ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current location'
              : 'Current location';
            setPickerLocation({ ...coords, address: addr });
            setPickerMapRegion({
              latitude: coords.latitude,
              longitude: coords.longitude,
              latitudeDelta: 0.0012,
              longitudeDelta: 0.0012,
            });
          } catch {
            setPickerLocation({ ...coords, address: 'Current location' });
            setPickerMapRegion({
              latitude: coords.latitude,
              longitude: coords.longitude,
              latitudeDelta: 0.0012,
              longitudeDelta: 0.0012,
            });
          }
        }
      } finally {
        setPickerLoading(false);
      }
      return;
    }
    if (Object.keys(option.params).length > 0) {
      router.push({ pathname: option.route as any, params: option.params });
    } else {
      router.push(option.route as any);
    }
  };

  const handleConfirmPickerLocation = async () => {
    if (!pendingOption || !pickerLocation) return;
    await hapticFeedback('medium');
    router.push({
      pathname: pendingOption.route as any,
      params: {
        ...pendingOption.params,
        latitude: String(pickerLocation.latitude),
        longitude: String(pickerLocation.longitude),
        address: pickerLocation.address,
        startAtVehicle: 'true',
      },
    });
  };

  const resolvePickerMapAddress = async (coords: { latitude: number; longitude: number }) => {
    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected location'
        : 'Selected location';
      setPickerLocation({ ...coords, address: addr });
    } catch {
      setPickerLocation({ ...coords, address: 'Selected location' });
    }
  };

  /** Geocode the typed postcode / street / area and fly the picker map there. */
  const handlePickupSearch = useCallback(async () => {
    const term = pickupSearchQuery.trim();
    if (!term) return;
    try {
      setPickupSearching(true);
      const results = await Location.geocodeAsync(term);
      const hit = results?.[0];
      if (!hit) {
        Alert.alert('No match', `Couldn't find “${term}”. Try a postcode, street or area name.`);
        return;
      }
      const next = {
        latitude: hit.latitude,
        longitude: hit.longitude,
        latitudeDelta: 0.0012,
        longitudeDelta: 0.0012,
      };
      setPickerMapRegion(next);
      mapRef.current?.animateToRegion(next, MAP_CAMERA_ANIMATION_DURATION * 0.6);
      void resolvePickerMapAddress({ latitude: hit.latitude, longitude: hit.longitude });
    } catch {
      Alert.alert('Search failed', 'Could not look up that location. Check your connection and try again.');
    } finally {
      setPickupSearching(false);
    }
  }, [pickupSearchQuery]);

  const handlePickupRecenter = useCallback(async () => {
    await hapticFeedback('light');
    if (!userLocation) return;
    const next = {
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      latitudeDelta: 0.0012,
      longitudeDelta: 0.0012,
    };
    setPickerMapRegion(next);
    mapRef.current?.animateToRegion(next, MAP_CAMERA_ANIMATION_DURATION * 0.6);
    void resolvePickerMapAddress(userLocation);
  }, [userLocation]);

  useEffect(() => {
    if (bookingStep !== 'pickup') {
      setPickupKeyboardHeight(0);
      return;
    }
    const showEvent = Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow';
    const hideEvent = Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide';
    const onShow = (e: KeyboardEvent) => setPickupKeyboardHeight(e.endCoordinates.height);
    const onHide = () => setPickupKeyboardHeight(0);
    const subShow = Keyboard.addListener(showEvent, onShow);
    const subHide = Keyboard.addListener(hideEvent, onHide);
    return () => {
      subShow.remove();
      subHide.remove();
    };
  }, [bookingStep]);

  useEffect(() => {
    if (bookingStep !== 'pickup' || !pickerLocation) return;
    setPickerMapRegion({
      latitude: pickerLocation.latitude,
      longitude: pickerLocation.longitude,
      latitudeDelta: 0.0012,
      longitudeDelta: 0.0012,
    });
  }, [bookingStep, pickerLocation]);

  useEffect(() => {
    if (bookingStep !== 'pickup' || pickerLocation || !userLocation) return;
    setPickerLocation({
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      address: 'Current location',
    });
    setPickerMapRegion({
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      latitudeDelta: 0.0012,
      longitudeDelta: 0.0012,
    });
  }, [bookingStep, pickerLocation, userLocation]);

  const visibleProviders = useMemo(() => providerLocations, [providerLocations]);
  const sheetProviders = visibleProviders;
  const primaryColor = SKY;

  useEffect(() => {
    if (!showNearbyMapSheet) {
      setNearbyMapFocusId(null);
      return;
    }
    const coords: { latitude: number; longitude: number }[] = [];
    if (userLocation) coords.push(userLocation);
    sheetProviders.forEach((p) => coords.push({ latitude: p.latitude, longitude: p.longitude }));
    const id = requestAnimationFrame(() => {
      if (!mapRef.current) return;
      if (coords.length >= 2) {
        mapRef.current.fitToCoordinates(coords, {
          edgePadding: { ...NEARBY_MAP_FIT_PADDING },
          animated: true,
        });
      } else if (coords.length === 1) {
        mapRef.current.animateToRegion(
          { ...coords[0], latitudeDelta: 0.06, longitudeDelta: 0.06 },
          MAP_CAMERA_ANIMATION_DURATION,
        );
      } else {
        mapRef.current.animateToRegion(
          {
            latitude: DEFAULT_MAP_REGION.latitude,
            longitude: DEFAULT_MAP_REGION.longitude,
            latitudeDelta: 0.12,
            longitudeDelta: 0.12,
          },
          MAP_CAMERA_ANIMATION_DURATION,
        );
      }
    });
    return () => cancelAnimationFrame(id);
  }, [showNearbyMapSheet, sheetProviders, userLocation]);

  const handleNearbyProviderChip = useCallback(
    (p: ProviderLocation) => {
      void hapticFeedback('light');
      setNearbyMapFocusId(p.id);
      mapRef.current?.animateToRegion(
        {
          latitude: p.latitude,
          longitude: p.longitude,
          latitudeDelta: 0.035,
          longitudeDelta: 0.035,
        },
        MAP_CAMERA_ANIMATION_DURATION,
      );
    },
    [],
  );

  const indexSelectedOption = useMemo(
    () => visibleBookingIndexOptions.find((o) => o.id === indexFocusedOptionId) ?? visibleBookingIndexOptions[0],
    [indexFocusedOptionId],
  );

  const isComeToYou = MOBILE_SERVICE_ONLY_LAUNCH || indexFocusedOptionId === 'come-to-you';

  const mapOrigin = useMemo(
    () =>
      userLocation ??
      (liveCoords ? { latitude: liveCoords.latitude, longitude: liveCoords.longitude } : null),
    [userLocation, liveCoords],
  );

  /** Online mobile pros with a straight-line ETA estimate (~22 km/h urban average). */
  const onlineValeters = useMemo(() => {
    return valeters
      .filter((v) => v.isOnline && Number.isFinite(v.latitude) && Number.isFinite(v.longitude))
      .map((v) => {
        const km = mapOrigin ? distanceKm(mapOrigin, { latitude: v.latitude, longitude: v.longitude }) : null;
        const etaMins = km != null ? Math.max(3, Math.round((km / 22) * 60)) : null;
        return { ...v, etaMins, km };
      })
      .sort((a, b) => (a.km ?? Infinity) - (b.km ?? Infinity))
      .slice(0, 14);
  }, [valeters, mapOrigin]);

  /** Nearby car washes / studios with distance for the "Come To Us" map. */
  const nearbyHubs = useMemo(() => {
    return providerLocations
      .map((loc) => {
        const km = mapOrigin
          ? distanceKm(mapOrigin, { latitude: loc.latitude, longitude: loc.longitude })
          : null;
        const miles = km != null ? km * 0.621371 : null;
        const isOpen = !['closed', 'inactive', 'disabled', 'paused', 'suspended'].includes(
          String(loc.status ?? '').toLowerCase(),
        );
        return { ...loc, miles, km, isOpen };
      })
      .sort((a, b) => (a.km ?? Infinity) - (b.km ?? Infinity))
      .slice(0, 20);
  }, [providerLocations, mapOrigin]);

  const onlineProsCount = onlineValeters.length;
  const openHubsCount = useMemo(() => nearbyHubs.filter((h) => h.isOpen).length, [nearbyHubs]);
  const mapCountLabel = isComeToYou
    ? `${onlineProsCount} ${CCP.pluralShort} online`
    : `${openHubsCount} ${openHubsCount === 1 ? 'Location' : 'Locations'} open nearby`;
  const mapCountActive = isComeToYou ? onlineProsCount > 0 : openHubsCount > 0;

  useEffect(() => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) {
      router.replace('/owner/booking/create');
    }
  }, []);

  if (MOBILE_SERVICE_ONLY_LAUNCH) return null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? {
            latitude: userLocation?.latitude ?? liveCoords?.latitude ?? DEFAULT_MAP_REGION.latitude,
            longitude: userLocation?.longitude ?? liveCoords?.longitude ?? DEFAULT_MAP_REGION.longitude,
            latitudeDelta: 0.085,
            longitudeDelta: 0.085,
          }}
          scrollEnabled={false}
          zoomEnabled={false}
          rotateEnabled={false}
          pitchEnabled={false}
          toolbarEnabled={false}
          showsUserLocation
          showsMyLocationButton={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {isComeToYou
            ? onlineValeters.map((v) => (
                <AutoTrackMarker key={`val-${v.id}`} coordinate={{ latitude: v.latitude, longitude: v.longitude }}>
                  <View style={styles.mapPinWrap}>
                    <View style={styles.mapPinPill}>
                      <Ionicons name="time-outline" size={10} color={SKY} />
                      <Text style={styles.mapPinPillText}>
                        {v.etaMins != null ? `${v.etaMins} min` : 'Online'}
                      </Text>
                    </View>
                    <MapMarkerValeterAvatar photoUri={v.photoUri} rating={v.rating} isOnline size={46} />
                  </View>
                </AutoTrackMarker>
              ))
            : nearbyHubs.map((loc) => (
                <AutoTrackMarker key={`hub-${loc.id}`} coordinate={{ latitude: loc.latitude, longitude: loc.longitude }}>
                  <View style={styles.mapPinWrap}>
                    <View style={styles.mapPinPill}>
                      {loc.isOpen ? <View style={styles.mapPinOpenDot} /> : null}
                      <Text style={styles.mapPinPillText}>
                        {loc.miles != null ? `${loc.miles.toFixed(1)} mi` : loc.isOpen ? 'Open' : 'Closed'}
                      </Text>
                    </View>
                    <MapMarkerLocationAvatar
                      rating={loc.rating}
                      isOpen={loc.isOpen}
                      detailing={!!loc.detailing_offered}
                      size={46}
                    />
                  </View>
                </AutoTrackMarker>
              ))}
        </MapView>
        <LinearGradient
          colors={['rgba(10,25,41,0.12)', 'rgba(10,25,41,0.5)', 'rgba(10,25,41,0.78)']}
          style={StyleSheet.absoluteFill}
        />
      </View>

      {bookingStep === 'index' ? (
        <View style={[styles.mapCountPillWrap, { top: insets.top + 70 }]} pointerEvents="none">
          <View style={styles.mapCountPill}>
            <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View
              style={[
                styles.mapCountDot,
                { backgroundColor: mapCountActive ? '#34D399' : '#64748B' },
              ]}
            />
            <Text style={styles.mapCountText}>{mapCountLabel}</Text>
          </View>
        </View>
      ) : null}

      {bookingStep === 'pickup' ? (
        <BookingMapLocationFullHeader
          topInset={insets.top}
          onBack={() => { void hapticFeedback('light'); setBookingStep('index'); }}
          onRecenter={() => { void handlePickupRecenter(); }}
          accentColor={primaryColor}
        />
      ) : (
        <AppHeader
          title="Book a Service"
          subtitle={MOBILE_SERVICE_ONLY_LAUNCH ? 'Mobile service at your location' : 'Choose how you want to book'}
          showBack
          fullWidth
          onBack={() => router.back()}
        />
      )}

      <Animated.View
        style={[
          styles.sheetContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: 0,
          },
        ]}
      >
        <View
          style={[
            styles.sheetPanel,
            {
              height:
                bookingStep === 'pickup'
                  ? Math.min(SCREEN_H * 0.82, 700)
                  : Math.min(SCREEN_H * 0.46, Math.max(insets.bottom, 16) + 268),
              minHeight: 0,
              paddingBottom: 0,
              backgroundColor: 'transparent',
              borderColor: 'transparent',
              borderWidth: 0,
              shadowOpacity: 0,
              shadowRadius: 0,
              elevation: 0,
              paddingHorizontal: 0,
              paddingTop: 0,
              paddingVertical: 0,
            },
          ]}
        >
          <View style={styles.bookingStageViewport}>
            <Animated.View
              pointerEvents={bookingStep === 'index' ? 'auto' : 'none'}
              style={[
                styles.bookingStageScreen,
                {
                  transform: [
                    {
                      translateX: stepAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0, -SCREEN_W],
                      }),
                    },
                  ],
                },
              ]}
            >
              <BusinessSheetBackground />
              <BookingSheetPremiumLayers />
              <ScrollView
                style={styles.bookingStageScroll}
                contentContainerStyle={[
                  styles.bookingStageContent,
                  { paddingBottom: Math.max(insets.bottom, 16) + 20 },
                ]}
                showsVerticalScrollIndicator={false}
                bounces={false}
              >
                <View style={styles.handle} />
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.indexCardsScrollContent}
                  snapToInterval={INDEX_OPTION_CARD_W + 12}
                  decelerationRate="fast"
                  snapToAlignment="start"
                >
                  {visibleBookingIndexOptions.map((option) => {
                    const isMobile = option.id === 'come-to-you';
                    const hubIcon = 'business';
                    const isFocused = indexFocusedOptionId === option.id;
                    return (
                      <TouchableOpacity
                        key={option.id}
                        activeOpacity={0.92}
                        onPress={() => {
                          void hapticFeedback('light');
                          setIndexFocusedOptionId(option.id);
                        }}
                        style={[styles.indexOptionCardOuter, { width: INDEX_OPTION_CARD_W }]}
                        accessibilityRole="button"
                        accessibilityLabel={`${option.title}. ${isFocused ? 'Selected.' : ''}`}
                      >
                        <IndexTrackingCardShell
                          accentColor={primaryColor}
                          style={[
                            styles.choiceCardShell,
                            {
                              borderWidth: 2,
                              borderColor: isFocused ? primaryColor + 'AA' : 'rgba(148,163,184,0.35)',
                            },
                          ]}
                        >
                          <View style={ix.optionCardTopRow}>
                            <GradientIconBox
                              icon={isMobile ? 'car-sport' : hubIcon}
                              colors={accentToGradient(primaryColor)}
                              boxSize={46}
                              borderRadius={16}
                              elevated
                              size={22}
                            />
                            <View style={ix.optionTitleMain}>
                              <Text style={ix.optionKicker}>{isMobile ? 'MOBILE' : 'VISIT US'}</Text>
                              <Text style={ix.optionTitle} numberOfLines={2} ellipsizeMode="tail">
                                {option.title}
                              </Text>
                              <Text style={ix.optionSubtitle} numberOfLines={2} ellipsizeMode="tail">
                                {option.subtitle}
                              </Text>
                            </View>
                          </View>
                          <View style={ix.optionFooterRow}>
                            <View style={ix.optionFooterLeft}>
                              <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(16,185,129,0.18)', borderColor: 'rgba(52,211,153,0.25)' }]}>
                                <View style={ix.optionStatusDot} />
                                <Text style={ix.optionStatusText} numberOfLines={1}>
                                  {option.trustLine}
                                </Text>
                              </View>
                            </View>
                            <View style={[ix.optionStatusPill, { backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(148,163,184,0.2)' }]}>
                              <Ionicons name="time-outline" size={13} color={primaryColor} />
                              <Text style={ix.optionStatusText} numberOfLines={1}>
                                {option.eta}
                              </Text>
                            </View>
                          </View>
                        </IndexTrackingCardShell>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>

                <View style={styles.indexSheetCtaRow}>
                  <TouchableOpacity
                    style={[
                      customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                      customerMapTrackingSheetActionStyles.bookingInfoCard,
                      styles.indexBookingSheetTrackingCta,
                      {
                        borderColor: primaryColor + '8A',
                        opacity: checkingActive ? 0.45 : 1,
                      },
                    ]}
                    onPress={() => void handleSelect(indexSelectedOption)}
                    disabled={checkingActive}
                    activeOpacity={0.85}
                    accessibilityRole="button"
                    accessibilityLabel="Continue with selected booking type"
                  >
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient
                      colors={[primaryColor + '59', 'rgba(15,23,42,0.65)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={{ zIndex: 1 }}>
                      <GradientIconBox
                        icon="arrow-forward-circle"
                        colors={accentToGradient(primaryColor)}
                        boxSize={36}
                        borderRadius={12}
                        elevated
                        size={18}
                      />
                    </View>
                    <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                      <Text style={[styles.indexBookingSheetCtaLabel, { color: primaryColor }]}>Continue</Text>
                    </View>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </Animated.View>

            <Animated.View
              pointerEvents={bookingStep === 'pickup' ? 'auto' : 'none'}
              style={[
                styles.bookingStageScreen,
                {
                  transform: [
                    {
                      translateX: stepAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [SCREEN_W, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <View style={styles.pickupFullScreenWrap}>
                <MapView
                  ref={mapRef}
                  style={StyleSheet.absoluteFill}
                  region={pickerMapRegion ?? {
                    latitude: pickerLocation?.latitude ?? userLocation?.latitude ?? DEFAULT_MAP_REGION.latitude,
                    longitude: pickerLocation?.longitude ?? userLocation?.longitude ?? DEFAULT_MAP_REGION.longitude,
                    latitudeDelta: 0.0012,
                    longitudeDelta: 0.0012,
                  }}
                  onRegionChangeComplete={(r) => {
                    setPickerMapRegion(r);
                    const coords = { latitude: r.latitude, longitude: r.longitude };
                    if (pickerMapGeocodeDebounceRef.current) clearTimeout(pickerMapGeocodeDebounceRef.current);
                    pickerMapGeocodeDebounceRef.current = setTimeout(() => {
                      void resolvePickerMapAddress(coords);
                    }, 240);
                  }}
                  scrollEnabled
                  zoomEnabled
                  rotateEnabled={false}
                  pitchEnabled={false}
                  toolbarEnabled={false}
                  showsUserLocation
                  showsMyLocationButton={false}
                  customMapStyle={LOCATION_PICKER_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                  mapPadding={{
                    top: 12,
                    right: 12,
                    bottom: 172 + Math.max(insets.bottom, 14),
                    left: 12,
                  }}
                  legalLabelInsets={{
                    top: 0,
                    right: 10,
                    bottom: 128 + Math.max(insets.bottom, 14),
                    left: 10,
                  }}
                />

                <View pointerEvents="none" style={styles.centerPickerWrap}>
                  <Animated.View style={[styles.centerPickerPin, { transform: [{ scale: markerPulse }] }]}>
                    <MapMarkerCustomerVehicle size={44} variant="pin" />
                  </Animated.View>
                </View>

                <View
                  style={[
                    styles.pickupBottomPanel,
                    {
                      bottom: pickupKeyboardHeight,
                      paddingBottom: pickupKeyboardHeight > 0 ? 12 : Math.max(insets.bottom, 14) + 10,
                    },
                  ]}
                >
                  <BusinessSheetBackground />
                  <BookingSheetPremiumLayers />
                  <View style={styles.sheetHandle} />
                  <View style={styles.pickupSheetSearchWrap}>
                    <View style={styles.pickupSheetSearchRow}>
                      {pickupSearching ? (
                        <ActivityIndicator size="small" color={primaryColor} />
                      ) : (
                        <Ionicons name="search" size={18} color={primaryColor} />
                      )}
                      <TextInput
                        style={styles.pickupSearchInput}
                        placeholder="Search postcode, street or area"
                        placeholderTextColor="rgba(148,163,184,0.75)"
                        value={pickupSearchQuery}
                        onChangeText={setPickupSearchQuery}
                        returnKeyType="search"
                        onSubmitEditing={() => void handlePickupSearch()}
                      />
                      {pickupSearchQuery.length > 0 ? (
                        <TouchableOpacity onPress={() => setPickupSearchQuery('')} hitSlop={8} accessibilityLabel="Clear search">
                          <Ionicons name="close-circle" size={20} color="rgba(148,163,184,0.65)" />
                        </TouchableOpacity>
                      ) : null}
                    </View>
                  </View>
                  <View style={styles.pickupBottomCard}>
                    <View style={styles.pickupBottomCardTopRow}>
                      <View style={[styles.pickupLocationPill, { borderColor: `${primaryColor}40`, backgroundColor: `${primaryColor}14` }]}>
                        <Ionicons name="location-outline" size={16} color={primaryColor} />
                        <Text style={[styles.pickupLocationPillText, { color: primaryColor }]}>Selected location</Text>
                      </View>
                      {pickerLoading ? <ActivityIndicator size="small" color={primaryColor} /> : null}
                    </View>
                    <Text style={styles.pickupAddressText} numberOfLines={2}>
                      {pickerLocation?.address || 'Move the map to choose your wash location'}
                    </Text>
                    <WWPrimaryButton
                      title="Confirm location"
                      onPress={handleConfirmPickerLocation}
                      disabled={!pickerLocation}
                      leftIconName="checkmark"
                      leftIconSize={18}
                      style={{ marginTop: 14, width: '100%' }}
                    />
                  </View>
                </View>
              </View>
            </Animated.View>
          </View>
        </View>
      </Animated.View>

      <Modal
        visible={showNearbyMapSheet}
        transparent
        animationType="slide"
        onRequestClose={() => setShowNearbyMapSheet(false)}
        statusBarTranslucent
      >
        <View style={styles.nearbyMapBackdrop}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => setShowNearbyMapSheet(false)}
            accessibilityRole="button"
            accessibilityLabel="Dismiss nearby map"
          />
          <View
            style={[
              styles.nearbyMapSheet,
              {
                height: Math.min(SCREEN_H * 0.72, SCREEN_H - insets.top - 12),
                paddingBottom: Math.max(insets.bottom, 10),
              },
            ]}
          >
            <BusinessSheetBackground />
            <View style={styles.nearbyMapSheetBody}>
              <View style={styles.nearbyMapHandle} />
              <View style={styles.nearbyMapHeader}>
                <View style={styles.nearbyMapTitleBlock}>
                  <Text style={styles.nearbyMapTitle}>Locations nearby</Text>
                  <Text style={styles.nearbyMapSubtitle}>
                    {sheetProviders.length
                      ? 'Tap a pin or chip to focus the map'
                      : 'No locations to show yet'}
                  </Text>
                </View>
                <View style={styles.nearbyMapHeaderActions}>
                  <View style={styles.nearbyMapIconBtn}>
                    <WWSheetCloseButton
                      variant="bordered"
                      size={40}
                      iconSize={20}
                      onPress={() => setShowNearbyMapSheet(false)}
                      accessibilityLabel="Close map"
                    />
                  </View>
                </View>
              </View>
              <View style={styles.nearbyMapMapFrame}>
                <MapView
                  ref={mapRef}
                  style={StyleSheet.absoluteFill}
                  initialRegion={
                    region ?? {
                      latitude: DEFAULT_MAP_REGION.latitude,
                      longitude: DEFAULT_MAP_REGION.longitude,
                      latitudeDelta: 0.08,
                      longitudeDelta: 0.08,
                    }
                  }
                  customMapStyle={BOOKING_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                  showsUserLocation={!!userLocation}
                  showsMyLocationButton={false}
                  showsCompass={false}
                  mapType="standard"
                  scrollEnabled
                  zoomEnabled
                  rotateEnabled
                  pitchEnabled
                  mapPadding={{ top: 10, right: 10, bottom: 12, left: 10 }}
                  legalLabelInsets={{ top: 0, right: 8, bottom: 8, left: 8 }}
                >
                  {sheetProviders.map((p) => {
                    const isDetailHub = p.detailing_offered === true;
                    return (
                      <Marker
                        key={p.id}
                        coordinate={{ latitude: p.latitude, longitude: p.longitude }}
                        title={p.name}
                        onPress={() => handleNearbyProviderChip(p)}
                      >
                        {isDetailHub ? (
                          <MapMarkerDetailingHub size={44} isSelected={nearbyMapFocusId === p.id} />
                        ) : (
                          <MapMarkerWashHub size={44} isSelected={nearbyMapFocusId === p.id} />
                        )}
                      </Marker>
                    );
                  })}
                </MapView>
              </View>
              {sheetProviders.length > 0 ? (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={styles.nearbyMapChipsScroll}
                  contentContainerStyle={styles.nearbyMapChipsContent}
                >
                  {sheetProviders.map((p) => {
                    const active = nearbyMapFocusId === p.id;
                    const isDetailHub = p.detailing_offered === true;
                    const hubAccent = isDetailHub ? DETAILING_YELLOW : SKY;
                    return (
                      <TouchableOpacity
                        key={`chip-${p.id}`}
                        style={[
                          styles.nearbyMapChip,
                          active &&
                            (isDetailHub ? styles.nearbyMapChipActiveDetail : styles.nearbyMapChipActive),
                        ]}
                        onPress={() => handleNearbyProviderChip(p)}
                        activeOpacity={0.88}
                        accessibilityRole="button"
                        accessibilityLabel={p.name}
                      >
                        <Ionicons
                          name={isDetailHub ? 'sparkles' : 'location'}
                          size={14}
                          color={active ? '#0f172a' : hubAccent}
                        />
                        <Text style={[styles.nearbyMapChipLabel, active && styles.nearbyMapChipLabelActive]} numberOfLines={1}>
                          {p.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              ) : null}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  nearbyMapBackdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.58)',
  },
  nearbyMapSheet: {
    width: '100%',
    position: 'relative',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  nearbyMapSheetBody: {
    flex: 1,
    zIndex: 2,
    paddingHorizontal: 4,
  },
  nearbyMapHandle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(135,206,235,0.65)',
    marginTop: 10,
    marginBottom: 8,
  },
  nearbyMapHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingBottom: 6,
  },
  nearbyMapTitleBlock: {
    flex: 1,
    marginRight: 8,
    gap: 4,
  },
  nearbyMapTitle: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  nearbyMapSubtitle: {
    color: 'rgba(248,250,252,0.62)',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.15,
  },
  nearbyMapHeaderActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  nearbyMapIconBtn: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nearbyMapMapFrame: {
    flex: 1,
    minHeight: 220,
    marginHorizontal: 10,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  nearbyMapChipActiveDetail: {
    backgroundColor: 'rgba(234,179,8,0.32)',
    borderColor: 'rgba(234,179,8,0.88)',
  },
  nearbyMapChipsScroll: {
    flexGrow: 0,
    maxHeight: 56,
    marginTop: 4,
  },
  nearbyMapChipsContent: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
    alignItems: 'center',
  },
  nearbyMapChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: 200,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  nearbyMapChipActive: {
    backgroundColor: 'rgba(135,206,235,0.35)',
    borderColor: 'rgba(135,206,235,0.85)',
  },
  nearbyMapChipLabel: {
    flexShrink: 1,
    color: 'rgba(248,250,252,0.92)',
    fontSize: 13,
    fontWeight: '700',
  },
  nearbyMapChipLabelActive: {
    color: '#0f172a',
  },
  providerMarkerWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  providerMarker: { width: 34, height: 34 },
  mapPinWrap: {
    alignItems: 'center',
  },
  mapPinPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 10,
    marginBottom: 3,
    backgroundColor: 'rgba(11,18,34,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  mapPinPillText: {
    color: '#F8FAFC',
    fontSize: 10,
    fontWeight: '800',
  },
  mapPinPillTextGap: {
    marginLeft: 4,
  },
  mapPinOpenDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#34D399',
  },
  mapCountPillWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 50,
  },
  mapCountPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(11,18,34,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  mapCountDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  mapCountText: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  sheetContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 40,
  },
  sheetPanel: {
    minHeight: 520,
    padding: 16,
    paddingBottom: 16,
    justifyContent: 'space-between',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  bookingStageViewport: {
    flex: 1,
    width: '100%',
    position: 'relative',
    overflow: 'hidden',
  },
  bookingStageScreen: {
    ...StyleSheet.absoluteFillObject,
  },
  bookingStageScroll: {
    flex: 1,
    width: '100%',
  },
  bookingStageContent: {
    flexGrow: 1,
    width: '100%',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  pickupStageContent: {
    gap: 8,
    justifyContent: 'flex-start',
    alignItems: 'center',
    alignSelf: 'center',
    paddingTop: 0,
  },
  pickupFullScreenWrap: {
    flex: 1,
    width: '100%',
    overflow: 'hidden',
    borderRadius: 0,
    backgroundColor: '#020617',
  },
  pickupSheetSearchWrap: {
    marginBottom: 10,
  },
  pickupSearchInput: { flex: 1, color: '#F9FAFB', fontSize: 14, fontWeight: '600', paddingVertical: 0 },
  pickupSheetSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.35)',
    backgroundColor: 'rgba(8,20,38,0.55)',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  centerPickerWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: '44%',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 6,
    pointerEvents: 'none',
  },
  centerPickerPin: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22,
    shadowRadius: 18,
    elevation: 10,
  },
  pickupBottomPanel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 0,
    zIndex: 7,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  pickupBottomCard: {
    paddingHorizontal: 0,
    paddingTop: 4,
    paddingBottom: 0,
    backgroundColor: 'transparent',
  },
  pickupBottomCardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 10,
  },
  pickupLocationPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
  },
  pickupLocationPillText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  pickupAddressText: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    lineHeight: 24,
    marginBottom: 14,
  },
  bookingStageKeyboardWrap: {
    flex: 1,
  },
  sheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  handle: {
    alignSelf: 'center',
    width: 38,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(135,206,235,0.65)',
    marginBottom: 10,
  },
  sheetHandle: {
    width: 46,
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.55)',
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  indexOptionCardOuter: {
    marginRight: 12,
  },
  indexCardsScrollContent: {
    paddingRight: 16,
    paddingVertical: 4,
  },
  choiceCardsGroup: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    gap: 12,
  },
  choiceCardShell: {
    minHeight: 150,
  },
  indexSheetCtaRow: {
    marginTop: 14,
    alignItems: 'center',
  },
  pickupConfirmCtaWrap: {
    width: '100%',
    maxWidth: 520,
    alignSelf: 'center',
  },
  indexBookingSheetTrackingCta: {
    alignSelf: 'center',
    width: '100%',
    maxWidth: 520,
    minHeight: 50,
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderRadius: 24,
    gap: 8,
  },
  indexBookingSheetCtaLabel: {
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.15,
    includeFontPadding: false,
  },
  compactToggleWrap: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 2,
    marginBottom: 6,
    borderRadius: 24,
    padding: 6,
    backgroundColor: 'rgba(2,6,23,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  compactModePill: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
  },
  compactModePillActive: {
    backgroundColor: 'rgba(56,189,248,0.26)',
    borderColor: 'rgba(56,189,248,0.82)',
  },
  compactModePillActiveDetail: {
    backgroundColor: 'rgba(234,179,8,0.26)',
    borderColor: 'rgba(234,179,8,0.84)',
  },
  compactModeIconWrap: {
    width: 22,
    height: 22,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  compactModeIconWrapActive: {
    borderColor: 'rgba(56,189,248,0.95)',
    backgroundColor: 'rgba(56,189,248,0.45)',
  },
  compactModeIconWrapActiveDetail: {
    borderColor: 'rgba(234,179,8,0.95)',
    backgroundColor: 'rgba(234,179,8,0.45)',
  },
  compactModeText: {
    color: 'rgba(255,255,255,0.82)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  compactModeTextActive: {
    color: '#FFFFFF',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '78%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
  },
  modalInner: { padding: 18, paddingBottom: 14, maxHeight: 520 },
  modalScroll: { maxHeight: 400 },
  modalScrollContent: { paddingBottom: 20 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 6,
  },
  modalTitle: { fontSize: 20, fontWeight: '800', marginBottom: 6 },
  infoSheetScrollContent: { paddingBottom: 28 },
  modalSub: { color: '#94A3B8', fontSize: 13, marginBottom: 12, fontWeight: '600' },
  modalSectionLabel: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  modalDesc: { color: '#E2E8F0', fontSize: 14, lineHeight: 21, marginBottom: 16 },
  modalDetailCard: {
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 14,
    marginBottom: 14,
  },
  modalDetailRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  modalDetailTextCol: { flex: 1, minWidth: 0 },
  modalDetailLabel: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  modalDetailValue: { color: '#F1F5F9', fontSize: 14, fontWeight: '700', lineHeight: 20 },
  modalDetailDivider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(148,163,184,0.25)',
    marginVertical: 12,
  },
  locationPickerSheet: {
    width: '100%',
    maxWidth: undefined,
    maxHeight: '82%',
    minHeight: 430,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    overflow: 'hidden',
    padding: 14,
    paddingBottom: 20,
    alignSelf: 'stretch',
    marginTop: 0,
  },
  locationPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
    justifyContent: 'flex-end',
    alignItems: 'stretch',
  },
  locationPickerKeyboardWrap: {
    flex: 1,
  },
  pickerMiniMapWrap: {
    width: '100%',
    maxWidth: 520,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    marginBottom: 10,
  },
  pickerMiniMap: {
    width: '100%',
  },
  pickerMiniMapMarker: {
    width: 26,
    height: 26,
  },
  locationPickerLoading: {
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    width: '100%',
    maxWidth: 520,
  },
  locationPickerLoadingText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '600',
  },
  locationPreviewCard: {
    width: '100%',
    maxWidth: 520,
    flexDirection: 'column',
    gap: 8,
    alignItems: 'stretch',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    backgroundColor: 'rgba(15,23,42,0.5)',
    padding: 12,
    marginBottom: 6,
  },
  locationPreviewCardRow: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  locationPreviewText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  locationPickerSecondaryBtn: {
    borderRadius: 18,
    minHeight: 46,
    paddingVertical: 12,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  locationPickerSecondaryText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});
