// app/owner/settings/vehicle-management.tsx

import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  Alert,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import dvlaService from '../../../src/services/DVLAService';
import AppHeader from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import ShowroomGarageSection, { type GarageVehicle } from '../../../src/components/garage/ShowroomGarageSection';
import AddVehicleSheet, { type AddMode, type VehicleFormData } from '../../../src/components/garage/AddVehicleSheet';
import { BORDER_RADIUS } from '../../../src/constants/designTokens';

const SKY = colors.SKY;

type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
type Vehicle = GarageVehicle;

function pickFirstString(obj: any, keys: string[]) {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }
  return '';
}

function normaliseToDateOnly(input: any) {
  if (!input) return '';
  const s = String(input).trim();
  if (!s) return '';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function formatDatePretty(dateOnly: string | null | undefined) {
  if (!dateOnly) return '—';
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function cleanReg(input: string) {
  return input.replaceAll(/\s/g, '').toUpperCase();
}

function toTitleCase(s: string): string {
  return s
    .toLowerCase()
    .replaceAll(/(?:^|\s|[-/])\w/g, (c) => c.toUpperCase())
    .trim();
}

function base64ToUint8Array(base64: string) {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = (binary.codePointAt(i) ?? 0) & 0xff;
  return bytes;
}

function isMissingColumnError(err: any, column: string): boolean {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('column') && msg.includes(column.toLowerCase());
}

const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  if (anyPicker?.MediaType?.Image) return [anyPicker.MediaType.Image];
  if (anyPicker?.MediaType?.Images) return anyPicker.MediaType.Images;
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return ['images'];
};

function getImageMeta(
  uri: string,
  fileName?: string | null,
  mimeType?: string | null
): { contentType: string; ext: string } {
  const mime = String(mimeType || '').toLowerCase().trim();
  if (mime === 'image/png') return { contentType: 'image/png', ext: 'png' };
  if (mime === 'image/webp') return { contentType: 'image/webp', ext: 'webp' };
  if (mime === 'image/heic' || mime === 'image/heif') return { contentType: 'image/heic', ext: 'heic' };
  if (mime === 'image/jpeg' || mime === 'image/jpg') return { contentType: 'image/jpeg', ext: 'jpg' };

  const fromName = String(fileName || uri || '')
    .split('?')[0]
    .split('.')
    .pop()
    ?.toLowerCase();

  if (fromName === 'png') return { contentType: 'image/png', ext: 'png' };
  if (fromName === 'webp') return { contentType: 'image/webp', ext: 'webp' };
  if (fromName === 'heic' || fromName === 'heif') return { contentType: 'image/heic', ext: 'heic' };
  return { contentType: 'image/jpeg', ext: 'jpg' };
}

async function readImageBytes(uri: string): Promise<Uint8Array> {
  const normalized = String(uri || '').replace(/^file:\/\/localhost\//, 'file:///');
  const candidates = [normalized];

  // iOS can surface file:///private/... and file:///... variants interchangeably
  if (normalized.startsWith('file:///private/')) {
    candidates.push(normalized.replace('file:///private/', 'file:///'));
  } else if (normalized.startsWith('file:///')) {
    candidates.push(normalized.replace('file:///', 'file:///private/'));
  }

  for (const candidate of Array.from(new Set(candidates))) {
    try {
      const info = await FileSystem.getInfoAsync(candidate);
      if (!info.exists) continue;
      const b64 = await FileSystem.readAsStringAsync(candidate, {
        encoding: ((FileSystem as any).EncodingType?.Base64 ?? 'base64') as any,
      });
      const bytes = base64ToUint8Array(b64);
      if (bytes.length > 0) return bytes;
    } catch {
      // try next candidate
    }
  }

  throw new Error('Could not read selected image file.');
}

// Detect vehicle size from DVLA data
function detectVehicleSize(data: any): VehicleSize {
  const make = String(data?.make || '').toLowerCase();
  const model = String(data?.model || '').toLowerCase();
  const type = String(data?.vehicleType || data?.typeOfVehicle || '').toLowerCase();
  const combined = `${make} ${model} ${type}`;

  // HGV / XXL — trucks, lorries, artic, rigid
  const hgvHints = [
    'hgv',
    'truck',
    'lorry',
    'artic',
    'articulated',
    'rigid',
    'tipper',
    'curtain',
    'flatbed',
    'tractor unit',
  ];
  if (hgvHints.some((s) => combined.includes(s))) {
    return 'xxl';
  }

  // XL vehicles (standard vans, commercial)
  const xlModels = ['transit', 'sprinter', 'vivaro', 'master', 'crafter', 'boxer', 'movano', 'ducato'];
  const xlTypes = ['van'];
  if (make.includes('ldv') || xlModels.some((s) => model.includes(s)) || xlTypes.some((s) => type.includes(s))) {
    return 'xl';
  }

  // Check for explicit size indicators in model name (xl/maxi/grand -> large, not XL)
  if (model.includes('maxi') || model.includes('grand')) {
    return 'large';
  }
  if (model.includes('xl')) {
    return 'large';
  }

  // Small vehicles
  const smallMakes = ['smart', 'fiat 500', 'mini'];
  const smallModels = ['aygo', 'up!', 'up', 'picanto', 'i10', '500', 'ka', 'twingo', 'forfour', 'fortwo'];
  if (smallMakes.some((s) => make.includes(s)) || smallModels.some((s) => model.includes(s))) {
    return 'small';
  }

  // Large vehicles (SUVs, large cars)
  const largeMakes = ['range rover', 'land rover', 'bmw x5', 'bmw x7'];
  const largeModels = [
    'range rover', 'discovery', 'defender', 'q7', 'x5', 'x7', 'touareg',
    'cayenne', 'navigator', 'escalade', 'suburban', 'tahoe', 'yukon',
    'expedition',
  ];
  if (largeMakes.some((s) => make.includes(s)) || largeModels.some((s) => model.includes(s))) {
    return 'large';
  }

  return 'medium';
}

function getVehicleSubtitle(count: number): string {
  if (count === 0) return 'Park your first ride';
  return count === 1 ? '1 vehicle in your garage' : `${count} vehicles in your garage`;
}

function getSizeLabel(size?: VehicleSize): string {
  switch (size) {
    case 'small': return 'Small';
    case 'medium': return 'Medium';
    case 'large': return 'Large';
    case 'xl': return 'XL';
    case 'xxl': return 'XXL (HGV)';
    default: return 'Medium';
  }
}

function getSizeIcon(size?: VehicleSize): string {
  switch (size) {
    case 'small': return 'contract-outline';
    case 'large': return 'expand-outline';
    case 'xl': return 'bus-outline';
    case 'xxl': return 'train-outline';
    default: return 'resize-outline';
  }
}

async function performVehicleDelete(
  vehicle: Vehicle,
  ctx: {
    userId: string;
    vehicles: Vehicle[];
    setBusyId: (id: string | null) => void;
    setVehicles: React.Dispatch<React.SetStateAction<Vehicle[]>>;
    setDefaultVehicle: (id: string) => Promise<void>;
  }
) {
  const isOnlyVehicle = ctx.vehicles.length === 1;
  const isDefault = Boolean(vehicle.is_default);
  ctx.setBusyId(vehicle.id);
  try {
    await hapticFeedback('medium');
    const { error } = await supabase.from('customer_vehicles').delete().eq('user_id', ctx.userId).eq('id', vehicle.id);
    if (error) throw error;
    ctx.setVehicles((prev) => prev.filter((v) => v.id !== vehicle.id));
    if (isDefault && !isOnlyVehicle) {
      const next = ctx.vehicles.find((v) => v.id !== vehicle.id);
      if (next) {
        setTimeout(() => {
          void ctx.setDefaultVehicle(next.id);
        }, 0);
      }
    }
  } catch (e: unknown) {
    console.error('[VehicleManagement] delete failed', e);
    Alert.alert('Error', e instanceof Error ? e.message : 'Failed to delete vehicle');
  } finally {
    ctx.setBusyId(null);
  }
}

type DvlaFormUpdate = {
  registration: string;
  make: string;
  model: string;
  color: string;
  type: string;
  size: VehicleSize;
  mot_status: string;
  mot_expiry_date: string;
  tax_status: string;
  tax_due_date: string;
};

function buildDvlaFormUpdate(
  data: Record<string, unknown>,
  reg: string,
  prev: DvlaFormUpdate
): Partial<DvlaFormUpdate> {
  // Full car spec in one string (e.g. "MERCEDES-BENZ CLA" or "FORD FIESTA") — no split, no separate model.
  const make = pickFirstString(data, ['make']) || prev.make;
  const colour = pickFirstString(data, ['colour', 'color']) || prev.color;
  const apiModel = pickFirstString(data, ['model', 'modelName']);
  const vehicleType = dvlaService.inferVehicleType(make, apiModel || '');
  const vehicleSize = detectVehicleSize(data);
  const motStatus = pickFirstString(data, ['motStatus', 'mot_status']);
  const taxStatus = pickFirstString(data, ['taxStatus', 'tax_status']);
  const motExpiry = normaliseToDateOnly(
    pickFirstString(data, ['motExpiryDate', 'motExpiry', 'mot_expiry_date', 'motExpiryDateString'])
  );
  const taxDue = normaliseToDateOnly(
    pickFirstString(data, ['taxDueDate', 'taxDue', 'tax_due_date', 'taxDueDateString'])
  );
  const registration = data.registrationNumber ? cleanReg(data.registrationNumber as string) : reg;
  return {
    registration,
    make: toTitleCase(make),
    model: '', // not shown; full spec is in make
    color: colour,
    type: vehicleType || prev.type || 'Car',
    size: vehicleSize || prev.size,
    mot_status: motStatus || prev.mot_status,
    mot_expiry_date: motExpiry || prev.mot_expiry_date,
    tax_status: taxStatus || prev.tax_status,
    tax_due_date: taxDue || prev.tax_due_date,
  };
}

// Cognitive complexity is driven by modal form state and many handlers; showroom list lives in ShowroomGarageSection.
// eslint-disable-next-line sonarjs/cognitive-complexity -- form modal and handlers kept in main component for clarity of data flow
export default function VehicleManagement() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  const [showModal, setShowModal] = useState(false);
  const [addMode, setAddMode] = useState<AddMode>('reg');

  const [editingVehicleId, setEditingVehicleId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    type: '',
    make: '',
    model: '',
    color: '',
    registration: '',
    size: 'medium' as VehicleSize,

    mot_status: '',
    mot_expiry_date: '',
    tax_status: '',
    tax_due_date: '',

    image_url: '',
    image_path: '',
  });

  const [dvlaLoading, setDvlaLoading] = useState(false);
  const [dvlaTouched, setDvlaTouched] = useState(false);

  const [busyId, setBusyId] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const lookupTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 400,
      useNativeDriver: true,
    }).start();
  }, []);

  const resetForm = () => {
    setFormData({
      type: '',
      make: '',
      model: '',
      color: '',
      registration: '',
      size: 'medium',

      mot_status: '',
      mot_expiry_date: '',
      tax_status: '',
      tax_due_date: '',

      image_url: '',
      image_path: '',
    });
    setDvlaLoading(false);
    setDvlaTouched(false);
    setAddMode('reg');
    setEditingVehicleId(null);
    setUploadingImage(false);

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }
  };

  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };

  const openEditModal = async (vehicle: Vehicle) => {
    if (busyId) return;
    await hapticFeedback('light');
    setEditingVehicleId(vehicle.id);

    setFormData({
      type: vehicle.type || 'Car',
      make: [vehicle.make, vehicle.model].filter(Boolean).join(' ').trim() || '',
      model: '',
      color: vehicle.color || '',
      registration: vehicle.registration || '',
      size: vehicle.size || 'medium',

      mot_status: vehicle.mot_status || '',
      mot_expiry_date: vehicle.mot_expiry_date || '',
      tax_status: vehicle.tax_status || '',
      tax_due_date: vehicle.tax_due_date || '',

      image_url: vehicle.image_url || vehicle.photo || '',
      image_path: vehicle.image_path || '',
    });

    setAddMode('manual');
    setDvlaTouched(false);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    resetForm();
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((row: any) => ({
        ...row,
        image_url: row.image_url ?? row.photo ?? null,
      }));
      setVehicles(rows as Vehicle[]);
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    return () => {
      if (lookupTimeoutRef.current) clearTimeout(lookupTimeoutRef.current);
    };
  }, []);

  const doDvlaLookup = async (registration: string) => {
    const reg = cleanReg(registration);
    const validation = dvlaService.validateRegistration(reg);
    if (!validation.isValid) return;

    setDvlaLoading(true);
    try {
      const result = await dvlaService.getVehicleDetails(reg);

      if (result?.success && result?.data) {
        const data = result.data as unknown as Record<string, unknown>;
        setFormData((current) => ({
          ...current,
          ...buildDvlaFormUpdate(data, reg, current),
        }));
        setDvlaTouched(true);
      } else if (result?.error && !String(result.error).toLowerCase().includes('mock')) {
        console.warn('[VehicleManagement] DVLA lookup failed:', result.error);
      }
    } catch (error: unknown) {
      console.error('[VehicleManagement] DVLA lookup error:', error);
    } finally {
      setDvlaLoading(false);
    }
  };

  const handleRegistrationChange = async (registration: string) => {
    const reg = cleanReg(registration);

    setFormData((prev) => ({
      ...prev,
      registration: reg,
    }));

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }

    if (addMode !== 'reg') return;

    lookupTimeoutRef.current = setTimeout(async () => {
      await doDvlaLookup(reg);
    }, 900);
  };

  const uploadVehicleImage = async (asset: any) => {
    if (!user?.id) throw new Error('Not signed in');
    const uri = String(asset?.uri || '');
    if (!uri) throw new Error('No image selected');

    const bucket = 'vehicle-images';
    const bytes = await readImageBytes(uri);
    if (!bytes.length) throw new Error('Selected image is empty (0 bytes).');
    const { contentType, ext } = getImageMeta(uri, asset?.fileName, asset?.mimeType);

    const fileName = `${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`;
    const path = `${user.id}/${fileName}`;

    const { error: upErr } = await supabase.storage.from(bucket).upload(path, bytes, {
      contentType,
      upsert: false,
    });
    if (upErr) throw upErr;

    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    const publicUrl = data?.publicUrl || '';
    if (!publicUrl) throw new Error('Failed to resolve uploaded image URL.');

    return { publicUrl, path };
  };

  const pickAndUploadImage = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo access to upload a car picture.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        quality: 0.9,
        allowsEditing: true,
        aspect: [4, 3],
      } as any);

      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (!asset?.uri) return;

      setUploadingImage(true);
      const { publicUrl, path } = await uploadVehicleImage(asset);

      setFormData((p) => ({
        ...p,
        image_url: publicUrl,
        image_path: path,
      }));
    } catch (e: any) {
      console.error('[VehicleManagement] image upload failed', e);
      Alert.alert('Upload failed', e?.message || 'Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const removeImageFromForm = async () => {
    Alert.alert('Remove picture?', 'This will remove the picture from this vehicle.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          setFormData((p) => ({ ...p, image_url: '', image_path: '' }));
        },
      },
    ]);
  };

  const handleSaveVehicle = async () => {
    if (!user?.id) return;

    const reg = cleanReg(formData.registration);
    if (!reg) {
      Alert.alert('Error', 'Registration is required (or switch to Manual entry and add details).');
      return;
    }

    const make = (formData.make || '').trim();
    if (!make) {
      Alert.alert('Error', 'Please fill in Make (full vehicle spec).');
      return;
    }

    try {
      await hapticFeedback('medium');

      const payload: any = {
        type: formData.type || 'Car',
        make,
        model: (formData.model || '').trim() || null,
        color: (formData.color || '').trim(),
        registration: reg,
        size: formData.size || 'medium',

        mot_status: formData.mot_status || null,
        mot_expiry_date: formData.mot_expiry_date || null,
        tax_status: formData.tax_status || null,
        tax_due_date: formData.tax_due_date || null,
        dvla_last_checked_at: dvlaTouched ? new Date().toISOString() : null,

        image_url: formData.image_url || null,
        image_path: formData.image_path || null,
        photo: formData.image_url || null,
      };

      if (editingVehicleId) {
        let { error } = await supabase
          .from('customer_vehicles')
          .update(payload)
          .eq('user_id', user.id)
          .eq('id', editingVehicleId);

        if (error && (isMissingColumnError(error, 'image_path') || isMissingColumnError(error, 'image_url'))) {
          const retry = await supabase
            .from('customer_vehicles')
            .update({
              ...payload,
              image_url: undefined,
              image_path: undefined,
              photo: formData.image_url || null,
            })
            .eq('user_id', user.id)
            .eq('id', editingVehicleId);
          error = retry.error;
        }

        if (error) throw error;
      } else {
        let { error } = await supabase.from('customer_vehicles').insert({
          user_id: user.id,
          ...payload,
          is_default: vehicles.length === 0,
        });

        if (error && (isMissingColumnError(error, 'image_path') || isMissingColumnError(error, 'image_url'))) {
          const retry = await supabase.from('customer_vehicles').insert({
            user_id: user.id,
            ...payload,
            image_url: undefined,
            image_path: undefined,
            photo: formData.image_url || null,
            is_default: vehicles.length === 0,
          });
          error = retry.error;
        }

        if (error) throw error;
      }

      setShowModal(false);
      resetForm();
      await loadVehicles();
    } catch (error: any) {
      console.error('[VehicleManagement] save failed', error);
      Alert.alert('Error', error?.message || 'Failed to save vehicle');
    }
  };

  const setDefaultVehicle = async (vehicleId: string) => {
    if (!user?.id) return;
    if (busyId) return;

    setBusyId(vehicleId);
    try {
      await hapticFeedback('light');

      const { error: clearErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: false })
        .eq('user_id', user.id)
        .eq('is_default', true);

      if (clearErr) throw clearErr;

      const { error: setErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: true })
        .eq('user_id', user.id)
        .eq('id', vehicleId);

      if (setErr) throw setErr;

      setVehicles((prev) => prev.map((v) => ({ ...v, is_default: v.id === vehicleId })));
    } catch (e: any) {
      console.error('[VehicleManagement] set default failed', e);
      Alert.alert('Error', e?.message || 'Failed to set default vehicle');
    } finally {
      setBusyId(null);
    }
  };

  const deleteVehicle = (vehicle: Vehicle) => {
    if (!user?.id) return;
    if (busyId) return;
    Alert.alert('Delete vehicle?', `This will remove ${vehicle.registration} from your account.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          void performVehicleDelete(vehicle, {
            userId: user.id,
            vehicles,
            setBusyId,
            setVehicles,
            setDefaultVehicle,
          });
        },
      },
    ]);
  };

  return (
    <>
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Your garage"
        subtitle={getVehicleSubtitle(vehicles.length)}
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        rightAction={
          <TouchableOpacity onPress={openAddModal} style={styles.addButton}>
            <Ionicons name="add" size={22} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ShowroomGarageSection
          loading={loading}
          vehicles={vehicles}
          insets={insets}
          busyId={busyId}
          onAddVehicle={openAddModal}
          onEditVehicle={openEditModal}
          onSetDefault={setDefaultVehicle}
          onDelete={deleteVehicle}
        />
      </Animated.View>
    </SafeAreaView>

      <AddVehicleSheet
        visible={showModal}
        onClose={closeModal}
        editingVehicleId={editingVehicleId}
        addMode={addMode}
        setAddMode={setAddMode}
        formData={formData as VehicleFormData}
        setFormData={setFormData}
        dvlaLoading={dvlaLoading}
        dvlaTouched={dvlaTouched}
        uploadingImage={uploadingImage}
        onRegistrationChange={handleRegistrationChange}
        onDvlaRefresh={async () => {
          const reg = cleanReg(formData.registration);
          if (!reg) {
            Alert.alert('Missing reg', 'Enter a registration first.');
            return;
          }
          await hapticFeedback('light');
          await doDvlaLookup(reg);
        }}
        onPickImage={pickAndUploadImage}
        onRemoveImage={removeImageFromForm}
        onSave={handleSaveVehicle}
        formatDatePretty={formatDatePretty}
        getSizeLabel={getSizeLabel}
        getSizeIcon={getSizeIcon}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  content: { flex: 1 },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: BORDER_RADIUS.full,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
