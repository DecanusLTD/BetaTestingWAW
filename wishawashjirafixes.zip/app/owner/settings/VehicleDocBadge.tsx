import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  getComplianceAccent,
  getComplianceExpiryHint,
  getDaysUntilExpiry,
  getVehicleDocComplianceState,
  type VehicleDocComplianceState,
} from '../../../src/utils/vehicleComplianceStatus';

function formatDatePretty(dateOnly: string | null | undefined) {
  if (!dateOnly) return '—';
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function badgeStyleForState(state: VehicleDocComplianceState) {
  if (state === 'good') return styles.statusBadgeGood;
  if (state === 'warning') return styles.statusBadgeWarning;
  if (state === 'expired') return styles.statusBadgeExpired;
  return styles.statusBadgeNeutral;
}

function labelStyleForState(state: VehicleDocComplianceState) {
  if (state === 'good') return styles.statusBadgeLabelGood;
  if (state === 'warning') return styles.statusBadgeLabelWarning;
  if (state === 'expired') return styles.statusBadgeLabelExpired;
  return null;
}

export type VehicleDocBadgeProps = Readonly<{
  label: string;
  status?: string | null;
  expiryDate?: string | null;
  icon: string;
}>;

export default function VehicleDocBadge({ label, status, expiryDate, icon }: VehicleDocBadgeProps) {
  const state = getVehicleDocComplianceState(status, expiryDate);
  const daysUntil = getDaysUntilExpiry(expiryDate);
  const accent = getComplianceAccent(state);
  const expiryHint = getComplianceExpiryHint(state, daysUntil);

  return (
    <View style={[styles.statusBadge, badgeStyleForState(state)]}>
      <Ionicons name={icon as never} size={14} color={accent} />
      <View style={styles.statusBadgeContent}>
        <Text style={[styles.statusBadgeLabel, labelStyleForState(state)]}>{label}</Text>
        <Text style={styles.statusBadgeValue}>
          {status || '—'}
          {expiryDate ? ` • ${formatDatePretty(expiryDate)}` : ''}
          {expiryHint ? (
            <Text style={[styles.statusBadgeHint, { color: accent }]}> · {expiryHint}</Text>
          ) : null}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  statusBadge: {
    flex: 1,
    minWidth: 120,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#334155',
    borderWidth: 1,
    borderColor: '#475569',
  },
  statusBadgeGood: {
    backgroundColor: '#064E3B',
    borderColor: '#34D399',
  },
  statusBadgeWarning: {
    backgroundColor: '#78350F',
    borderColor: '#F59E0B',
  },
  statusBadgeExpired: {
    backgroundColor: '#7F1D1D',
    borderColor: '#EF4444',
  },
  statusBadgeNeutral: {},
  statusBadgeContent: {
    flex: 1,
  },
  statusBadgeLabel: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  statusBadgeLabelGood: {
    color: '#34D399',
  },
  statusBadgeLabelWarning: {
    color: '#F59E0B',
  },
  statusBadgeLabelExpired: {
    color: '#EF4444',
  },
  statusBadgeValue: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '500',
  },
  statusBadgeHint: {
    fontWeight: '700',
  },
});
