import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  Alert,
  Animated as   RNAnimated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import EmptyState from '../../src/components/shared/EmptyState';
import AppHeader from '../../src/components/shared/AppHeader';
import { SkeletonList } from '../../src/components/shared/SkeletonLoader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import Animated, { FadeInDown } from 'react-native-reanimated';
import MapView, { Marker } from 'react-native-maps';
import { HISTORY_SNAPSHOT_MAP_STYLE, MAP_LOCKED_DARK } from '../../src/constants/mapConstants';
import { MapMarkerCustomerVehicle } from '../../src/components/maps/MapMarkerViews';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import { markBookingManuallyStarted } from '../../src/utils/activeBookingGuard';
import { removeBookingFromDeviceCalendar } from '../../src/services/BookingCalendarSync';

const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const RATING_GOLD = '#FBBF24';
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'closed',
  'archived',
  'complete',
]);

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

type HistoryTab = 'upcoming' | 'completed';

function getRelativeDate(dateLike: Date | string | number | undefined | null): string {
  if (!dateLike) return '';
  const d = new Date(dateLike);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 14) return 'Last week';
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  if (diffDays < 60) return 'Last month';
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
  const years = Math.floor(diffDays / 365);
  return years > 1 ? `${years} years ago` : '1 year ago';
}

function getSectionLabel(key: string): string {
  switch (key) {
    case 'this_month':
      return 'This month';
    case 'last_month':
      return 'Last month';
    case 'older':
      return 'Older';
    default:
      return key;
  }
}

function getSectionKey(completion: NormalizedCompletion): string {
  const d = new Date((completion.completedAt ?? completion.createdAt ?? 0) as any);
  const now = new Date();
  const thisMonth = now.getFullYear() * 12 + now.getMonth();
  const thatMonth = d.getFullYear() * 12 + d.getMonth();
  const diff = thisMonth - thatMonth;
  if (diff === 0) return 'this_month';
  if (diff === 1) return 'last_month';
  return 'older';
}

function getServiceAccent(completion: NormalizedCompletion): string {
  const t = (completion.service_type ?? completion.serviceName ?? '').toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

function getServiceIconName(accent: string): 'leaf' | 'sparkles' | 'water' {
  if (accent === ECO_GREEN) return 'leaf';
  if (accent === DETAILING_YELLOW) return 'sparkles';
  return 'water';
}

export default function WashHistory() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();
  const scrollPad = useOwnerScrollContentPadding(true);

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const [upcomingBookings, setUpcomingBookings] = useState<NormalizedCompletion[]>([]);
  const [historyTab, setHistoryTab] = useState<HistoryTab>('completed');
  const scrollY = useRef(new RNAnimated.Value(0)).current;

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null,
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null,
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const groupedBySection = useMemo(() => {
    const sorted = [...washCompletions].sort(sortByCompletedAtDesc);
    const map = new Map<string, NormalizedCompletion[]>();
    sorted.forEach((c) => {
      const key = getSectionKey(c);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(c);
    });
    const order = ['this_month', 'last_month', 'older'];
    return order.map((key) => ({ key, items: map.get(key) ?? [] })).filter((g) => g.items.length > 0);
  }, [washCompletions]);

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data: bookingRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `id, user_id, status, service_name, service_type, wash_type, price, scheduled_at, created_at, completed_at, valeter_name, location_address, location_lat, location_lng, rating, customer_review, tip_amount, special_instructions, cancelled_at`
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .order('scheduled_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const normalized = normalizeFromBookings(bookingRows || []);
      const completedList = normalized
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);
      const nowTs = Date.now();
      const upcomingList = normalized
        .filter((b) => {
          if (isCompleted(b)) return false;
          if (!b.scheduledAt) return false;
          const startTs = new Date(b.scheduledAt).getTime();
          if (!Number.isFinite(startTs)) return false;
          return startTs > nowTs;
        })
        .sort((a, b) => {
          const ta = new Date((a.scheduledAt ?? a.createdAt ?? 0) as any).getTime();
          const tb = new Date((b.scheduledAt ?? b.createdAt ?? 0) as any).getTime();
          return ta - tb;
        });

      setWashCompletions(completedList);
      setUpcomingBookings(upcomingList);
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load activity');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const performDeleteOne = useCallback(async (completion: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .eq('id', completion.id)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions((prev) => prev.filter((c) => c.id !== completion.id));
    } catch (e) {
      console.error('[wash-history] Delete error:', e);
      Alert.alert('Error', 'Could not remove from activity');
    }
  }, [user?.id]);

  const handleDeleteOne = useCallback((completion: NormalizedCompletion) => {
    Alert.alert(
      'Remove from activity',
      `Remove "${getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'this booking'}" from your activity?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => void performDeleteOne(completion) },
      ]
    );
  }, [performDeleteOne]);

  const performCancelUpcoming = useCallback(async (booking: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { data: updatedRow, error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer from activity',
        })
        .eq('id', booking.id)
        .eq('user_id', user.id)
        .select('id')
        .maybeSingle();
      if (error) throw error;
      if (!updatedRow) {
        Alert.alert('Could not cancel', 'This booking may have already been updated.');
        return;
      }
      await removeBookingFromDeviceCalendar(booking.id);
      setUpcomingBookings((prev) => prev.filter((b) => b.id !== booking.id));
    } catch (e) {
      console.error('[wash-history] Cancel upcoming error:', e);
      Alert.alert('Error', 'Could not cancel this booking');
    }
  }, [user?.id]);

  const handleCancelUpcoming = useCallback((booking: NormalizedCompletion) => {
    const label =
      getServiceDisplayName(booking.service_type, booking.serviceName) ??
      booking.serviceName ??
      'this booking';
    Alert.alert(
      'Cancel booking?',
      `Cancel "${label}" scheduled for ${formatDate(booking.scheduledAt ?? booking.createdAt)}?`,
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: () => void performCancelUpcoming(booking) },
      ]
    );
  }, [performCancelUpcoming]);

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    hapticFeedback('light');
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();
    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/explore',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/explore',
        params: {
          tab: 'valeters',
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/explore',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Activity"
        subtitle="Your past and upcoming washes"
        variant="dashboard"
        accountType="customer"
        fullWidth
      />
      <RNAnimated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: CONTENT_PADDING_H, paddingTop: (scrollPad.paddingTop ?? 0) + 16, paddingBottom: scrollPad.paddingBottom },
        ]}
        showsVerticalScrollIndicator={false}
        onScroll={RNAnimated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {!loading ? (
          <View style={styles.tabRow}>
            <TouchableOpacity
              onPress={() => setHistoryTab('upcoming')}
              style={[styles.tabPill, historyTab === 'upcoming' && styles.tabPillActive]}
              activeOpacity={0.85}
            >
              <Text style={[styles.tabPillText, historyTab === 'upcoming' && styles.tabPillTextActive]}>Upcoming</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setHistoryTab('completed')}
              style={[styles.tabPill, historyTab === 'completed' && styles.tabPillActive]}
              activeOpacity={0.85}
            >
              <Text style={[styles.tabPillText, historyTab === 'completed' && styles.tabPillTextActive]}>Completed</Text>
            </TouchableOpacity>
          </View>
        ) : null}
        {loading ? (
          <SkeletonList count={6} />
        ) : historyTab === 'completed' && washCompletions.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyWrap}>
            <EmptyState
              icon="time-outline"
              title="No activity yet"
              subtitle="Completed washes and details will show here"
              actionLabel="Book a service"
              onAction={() => router.push('/owner/explore')}
              iconColor={SKY}
              style={styles.emptyState}
            />
          </Animated.View>
        ) : historyTab === 'upcoming' && upcomingBookings.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyWrap}>
            <EmptyState
              icon="calendar-outline"
              title="No upcoming bookings"
              subtitle="Future bookings will appear here with countdowns"
              actionLabel="Book a service"
              onAction={() => router.push('/owner/explore')}
              iconColor={SKY}
              style={styles.emptyState}
            />
          </Animated.View>
        ) : historyTab === 'upcoming' ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Upcoming</Text>
            {upcomingBookings.map((booking, index) => {
              const accent = getServiceAccent(booking);
              const displayName =
                getServiceDisplayName(booking.service_type, booking.serviceName) ??
                booking.serviceName ??
                'Car Wash';
              const startsAt = booking.scheduledAt ? new Date(booking.scheduledAt) : null;
              const now = new Date();
              const diffMs = startsAt ? startsAt.getTime() - now.getTime() : 0;
              const days = Math.max(0, Math.floor(diffMs / (24 * 60 * 60 * 1000)));
              const hours = Math.max(0, Math.floor((diffMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000)));
              const mins = Math.max(0, Math.floor((diffMs % (60 * 60 * 1000)) / (60 * 1000)));
              const countdown = days > 0 ? `${days}d ${hours}h` : `${hours}h ${mins}m`;

              return (
                <Animated.View key={booking.id} entering={FadeInDown.delay(index * 50)} style={styles.cardWrap}>
                  <View style={styles.upcomingCard}>
                    <View style={[styles.cardAccent, { backgroundColor: accent }]} />
                    <View style={styles.cardContent}>
                      <View style={styles.upcomingCardBody}>
                        <View style={styles.cardTopRow}>
                          <View style={styles.cardIconWrap}>
                            <GradientIconBox
                              icon={getServiceIconName(accent)}
                              colors={accentToGradient(accent)}
                              boxSize={44}
                              size={22}
                              elevated
                            />
                          </View>
                          <View style={styles.cardMain}>
                            <Text style={styles.cardService} numberOfLines={1}>
                              {displayName}
                            </Text>
                            <Text style={styles.cardFullDate} numberOfLines={1}>
                              {formatDate(booking.scheduledAt ?? booking.createdAt)}
                            </Text>
                          </View>
                          <View style={styles.cardRight}>
                            <View style={styles.upcomingCountdownPill}>
                              <Ionicons name="time-outline" size={12} color={SKY} />
                              <Text style={styles.upcomingCountdownText}>{countdown}</Text>
                            </View>
                            <TouchableOpacity
                              onPress={async () => {
                                await hapticFeedback('light');
                                handleCancelUpcoming(booking);
                              }}
                              style={styles.deleteBtn}
                              hitSlop={12}
                              accessibilityLabel="Cancel booking"
                            >
                              <Ionicons name="trash-outline" size={18} color="#94A3B8" />
                            </TouchableOpacity>
                          </View>
                        </View>
                        <View style={styles.upcomingActionsRow}>
                          <TouchableOpacity
                            onPress={async () => {
                              await hapticFeedback('light');
                              await markBookingManuallyStarted(booking.id);
                              router.push({
                                pathname: '/owner/booking/tracking',
                                params: { bookingId: booking.id },
                              } as any);
                            }}
                            style={styles.upcomingStartBtn}
                            activeOpacity={0.85}
                          >
                            <Ionicons name="navigate-outline" size={14} color={SKY} />
                            <Text style={styles.upcomingStartBtnText}>Start journey</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() =>
                              router.push({
                                pathname: '/owner/booking/tracking',
                                params: { bookingId: booking.id },
                              } as any)
                            }
                            style={styles.upcomingOpenBtn}
                            activeOpacity={0.85}
                          >
                            <Text style={styles.upcomingOpenBtnText}>Open</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </Animated.View>
              );
            })}
          </View>
        ) : (
          <>
            {groupedBySection.map(({ key, items }) => (
              <View key={key} style={styles.section}>
                <Text style={styles.sectionTitle}>{getSectionLabel(key)}</Text>
                {items.map((completion, index) => {
                  const isHighlighted = highlightId === completion.id;
                  const accent = getServiceAccent(completion);
                  const displayName = getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'Car Wash';
                  const relativeDate = getRelativeDate(completion.completedAt ?? completion.createdAt);
                  const fullDate = formatDate(completion.completedAt ?? completion.createdAt);

                  return (
                    <Animated.View
                      key={completion.id}
                      entering={FadeInDown.delay(index * 60)}
                      style={styles.cardWrap}
                    >
                      <View style={[styles.card, isHighlighted && styles.cardHighlight]}>
                        <View style={[styles.cardAccent, { backgroundColor: accent }]} />
                        <View style={styles.cardContent}>
                          {completion.location?.latitude != null && completion.location?.longitude != null && (
                            <View style={styles.cardMapWrap}>
                              <MapView
                                style={styles.cardMap}
                                region={{
                                  latitude: completion.location.latitude,
                                  longitude: completion.location.longitude,
                                  latitudeDelta: 0.002,
                                  longitudeDelta: 0.002,
                                }}
                                scrollEnabled={false}
                                zoomEnabled={false}
                                pitchEnabled={false}
                                rotateEnabled={false}
                                customMapStyle={HISTORY_SNAPSHOT_MAP_STYLE}
                                userInterfaceStyle={MAP_LOCKED_DARK}
                              >
                                <Marker
                                  coordinate={{
                                    latitude: completion.location.latitude,
                                    longitude: completion.location.longitude,
                                  }}
                                  anchor={{ x: 0.5, y: 0.5 }}
                                >
                                  <View style={styles.cardMapMarkerWrap}>
                                    <MapMarkerCustomerVehicle size={36} variant="car" />
                                  </View>
                                </Marker>
                              </MapView>
                              <LinearGradient
                                colors={['transparent', 'rgba(30,41,59,0.85)']}
                                style={styles.cardMapGradient}
                              />
                            </View>
                          )}
                          <View style={styles.cardBody}>
                          <View style={styles.cardTopRow}>
                            <View style={styles.cardIconWrap}>
                              <GradientIconBox
                                icon={getServiceIconName(accent)}
                                colors={accentToGradient(accent)}
                                boxSize={44}
                                size={22}
                                elevated
                              />
                            </View>
                            <View style={styles.cardMain}>
                              <Text style={styles.cardService} numberOfLines={1}>{displayName}</Text>
                              <Text style={styles.cardRelative}>{relativeDate}</Text>
                              <Text style={styles.cardFullDate} numberOfLines={1}>{fullDate}</Text>
                            </View>
                            <View style={styles.cardRight}>
                              <Text style={styles.cardPrice}>{formatCurrency(completion.price)}</Text>
                              {completion.rating != null && (
                                <View style={styles.ratingPill}>
                                  <Ionicons name="star" size={12} color={RATING_GOLD} />
                                  <Text style={styles.ratingNum}>{completion.rating}</Text>
                                </View>
                              )}
                              <TouchableOpacity
                                onPress={() => handleDeleteOne(completion)}
                                style={styles.deleteBtn}
                                hitSlop={12}
                              >
                                <Ionicons name="trash-outline" size={18} color="#94A3B8" />
                              </TouchableOpacity>
                            </View>
                          </View>

                          {(completion.valeterName || completion.address) && (
                            <View style={styles.cardMeta}>
                              {completion.valeterName && (
                                <View style={styles.metaRow}>
                                  <Ionicons name="person-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>{completion.valeterName}</Text>
                                </View>
                              )}
                              {completion.address && (
                                <View style={styles.metaRow}>
                                  <Ionicons name="location-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>{completion.address}</Text>
                                </View>
                              )}
                            </View>
                          )}

                          <TouchableOpacity
                            onPress={() => handleRepeatBooking(completion)}
                            style={[styles.repeatBtn, { backgroundColor: accent + '28', borderColor: accent + '50' }]}
                            activeOpacity={0.85}
                          >
                            <Ionicons name="repeat" size={18} color={accent} />
                            <Text style={[styles.repeatLabel, { color: accent }]}>Book again</Text>
                          </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    </Animated.View>
                  );
                })}
              </View>
            ))}
          </>
        )}
      </RNAnimated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {},

  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerClearBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBookBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },

  emptyWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyState: { minHeight: 260 },
  tabRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 14,
  },
  tabPill: {
    flex: 1,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.4)',
    paddingVertical: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabPillActive: {
    borderColor: 'rgba(125,211,252,0.52)',
    backgroundColor: 'rgba(56,189,248,0.2)',
  },
  tabPillText: {
    color: 'rgba(226,232,240,0.8)',
    fontSize: 12,
    fontWeight: '700',
  },
  tabPillTextActive: {
    color: '#E0F2FE',
  },

  section: { marginBottom: 28 },
  sectionTitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.6,
    marginBottom: 12,
    textTransform: 'uppercase',
  },

  cardWrap: { marginBottom: 12 },
  upcomingCard: {
    flexDirection: 'row',
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  upcomingCardBody: {
    padding: 16,
    paddingLeft: 14,
  },
  card: {
    flexDirection: 'row',
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  cardHighlight: {
    borderColor: SKY + '60',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  upcomingCountdownPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.45)',
    backgroundColor: 'rgba(8,20,38,0.64)',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  upcomingCountdownText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
  },
  upcomingActionsRow: {
    marginTop: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  upcomingStartBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.42)',
    backgroundColor: 'rgba(8,20,38,0.66)',
    paddingVertical: 9,
  },
  upcomingStartBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '800',
  },
  upcomingOpenBtn: {
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.5)',
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  upcomingOpenBtnText: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '700',
  },
  cardAccent: {
    width: 4,
    borderRadius: 2,
  },
  cardContent: { flex: 1, minWidth: 0 },
  cardMapWrap: {
    height: 100,
    width: '100%',
    overflow: 'hidden',
    position: 'relative',
  },
  cardMap: {
    ...StyleSheet.absoluteFillObject,
  },
  cardMapGradient: {
    ...StyleSheet.absoluteFillObject,
    pointerEvents: 'none',
  },
  cardMapMarkerWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardMapMarker: {
    width: 36,
    height: 36,
  },
  cardBody: { flex: 1, padding: 16, paddingLeft: 14 },
  cardTopRow: { flexDirection: 'row', alignItems: 'flex-start' },
  cardIconWrap: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardMain: { flex: 1, minWidth: 0 },
  cardService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  cardRelative: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  cardFullDate: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '500',
  },
  cardRight: { alignItems: 'flex-end', gap: 4 },
  cardPrice: {
    color: LIGHT_SKY,
    fontSize: 17,
    fontWeight: '800',
  },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: RATING_GOLD + '22',
  },
  ratingNum: {
    color: RATING_GOLD,
    fontSize: 12,
    fontWeight: '700',
  },
  deleteBtn: { padding: 4, marginTop: 2 },

  cardMeta: { marginTop: 12, gap: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metaText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
  },

  repeatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 14,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  repeatLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
});
