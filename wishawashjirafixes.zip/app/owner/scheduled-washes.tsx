import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Dimensions,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import { useOwnerScrollContentPadding } from '../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import DigitalMonthCalendar, {
  toDayKey,
  type CalendarMarkedDay,
} from '../../src/components/calendar/DigitalMonthCalendar';
import ExploreValeterTripCard from '../../src/components/explore/ExploreValeterTripCard';
import { useNearbyValeters } from '../../src/hooks/useNearbyValeters';
import { useMapChromeColors } from '../../src/hooks/useMapChromeColors';
import { SkeletonList } from '../../src/components/shared/SkeletonLoader';
import ValeterProfileBottomSheet, {
  type ValeterProfileSheetSeed,
} from '../../src/components/valeter/ValeterProfileBottomSheet';
import { CCP, ccpPluralLower } from '../../src/constants/carCareProLabels';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const CARD_WIDTH = width - 44;
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';

type RadiusOption = 5 | 10 | 20 | null;

type UpcomingRow = {
  id: string;
  scheduledAt: string;
  service_type?: string | null;
  serviceName?: string | null;
};

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function bookingAccent(row: UpcomingRow): string {
  const t = (row.service_type ?? row.serviceName ?? '').toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

export default function ScheduledWashes() {
  const { user } = useAuth();
  const scrollPad = useOwnerScrollContentPadding(true);
  const chrome = useMapChromeColors();
  const [radiusMiles, setRadiusMiles] = useState<RadiusOption>(10);
  const [refreshing, setRefreshing] = useState(false);
  const [upcomingRows, setUpcomingRows] = useState<UpcomingRow[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(true);
  const [valeterProfileSheet, setValeterProfileSheet] = useState<ValeterProfileSheetSeed | null>(null);

  const today = useMemo(() => startOfDay(new Date()), []);
  const [visibleMonth, setVisibleMonth] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDay, setSelectedDay] = useState<Date | null>(today);

  const { userCoords, valetersInRadius, loading: loadingValeters, refresh, toggleFavourite } =
    useNearbyValeters(radiusMiles, user?.id);

  const loadUpcoming = useCallback(async () => {
    if (!user?.id) {
      setUpcomingRows([]);
      setLoadingBookings(false);
      return;
    }
    setLoadingBookings(true);
    try {
      const now = new Date().toISOString();
      const { data, error } = await supabase
        .from('bookings')
        .select('id, scheduled_at, service_type, service_name, status, completed_at, cancelled_at')
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .gt('scheduled_at', now)
        .order('scheduled_at', { ascending: true })
        .limit(100);
      if (error) throw error;
      const rows = (data || []).filter((r) => !r.completed_at && r.scheduled_at);
      setUpcomingRows(
        rows.map((r) => ({
          id: String(r.id),
          scheduledAt: String(r.scheduled_at),
          service_type: r.service_type,
          serviceName: r.service_name,
        }))
      );
    } catch {
      setUpcomingRows([]);
    } finally {
      setLoadingBookings(false);
    }
  }, [user?.id]);

  useEffect(() => {
    void loadUpcoming();
  }, [loadUpcoming]);

  const markedDays = useMemo(() => {
    const map = new Map<string, CalendarMarkedDay>();
    for (const row of upcomingRows) {
      const key = toDayKey(new Date(row.scheduledAt));
      const cur = map.get(key) ?? { count: 0, accent: bookingAccent(row) };
      cur.count += 1;
      map.set(key, cur);
    }
    return map;
  }, [upcomingRows]);

  const monthBookingCount = useMemo(() => {
    let n = 0;
    const y = visibleMonth.getFullYear();
    const m = visibleMonth.getMonth();
    for (const row of upcomingRows) {
      const d = new Date(row.scheduledAt);
      if (d.getFullYear() === y && d.getMonth() === m) n += 1;
    }
    return n;
  }, [upcomingRows, visibleMonth]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([loadUpcoming(), refresh()]);
    setRefreshing(false);
  }, [loadUpcoming, refresh]);

  const handleBookValeter = useCallback(
    async (valeterId: string) => {
      hapticFeedback('light');
      if (user?.id) {
        const active = await getActiveBookingForCustomer(user.id);
        if (active) {
          Alert.alert('One booking at a time', 'Finish or cancel your current booking first.', [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'View booking',
              onPress: () =>
                router.push({ pathname: '/owner/track', params: { bookingId: active.id } } as any),
            },
          ]);
          return;
        }
      }
      const params: Record<string, string> = { preferredValeterId: valeterId };
      if (selectedDay) {
        const slot = new Date(selectedDay);
        slot.setHours(10, 0, 0, 0);
        params.scheduleDay = slot.toISOString();
      }
      if (userCoords) {
        params.latitude = String(userCoords.latitude);
        params.longitude = String(userCoords.longitude);
        params.address = 'Current location';
      }
      router.push({ pathname: '/owner/booking/create', params });
    },
    [selectedDay, userCoords, user?.id]
  );

  const openProfile = useCallback((v: (typeof valetersInRadius)[0]) => {
    hapticFeedback('light');
    setValeterProfileSheet({
      id: v.id,
      name: v.name,
      rating: v.rating,
      totalJobs: v.totalJobs,
      profilePicture: v.profilePicture ?? null,
      isOnline: v.isOnline,
      distanceMiles: v.distance ?? null,
      etaMins: v.etaMins ?? null,
    });
  }, []);

  const selectedLabel = selectedDay
    ? selectedDay.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })
    : null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Schedule"
        subtitle="Pick a date & book a pro near you"
        variant="dashboard"
        accountType="customer"
        fullWidth
      />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingHorizontal: CONTENT_PADDING_H,
            paddingTop: (scrollPad.paddingTop ?? 0) + 12,
            paddingBottom: scrollPad.paddingBottom,
          },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        <LinearGradient
          colors={['rgba(56,189,248,0.06)', 'transparent', 'rgba(8,20,38,0.2)']}
          style={styles.meshBg}
          pointerEvents="none"
        />

        <DigitalMonthCalendar
          visibleMonth={visibleMonth}
          onShiftMonth={(delta) =>
            setVisibleMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1))
          }
          selectedDay={selectedDay}
          onSelectDay={(day) => setSelectedDay(day)}
          markedDays={markedDays}
          monthKicker="SCHEDULE"
          minSelectableDay={today}
          monthMeta={
            monthBookingCount > 0
              ? `${monthBookingCount} scheduled this month`
              : 'Tap a date to see nearby pros'
          }
        />

        {selectedDay ? (
          <Animated.View entering={FadeInDown.duration(300)} style={styles.prosSection}>
            <View style={styles.prosHeader}>
              <View style={styles.prosHeaderText}>
                <Text style={styles.prosKicker}>{CCP.pluralShort.toUpperCase()} NEARBY</Text>
                <Text style={styles.prosTitle} numberOfLines={2}>
                  {selectedLabel}
                </Text>
                <Text style={styles.prosSubtitle}>
                  {valetersInRadius.length > 0
                    ? `${valetersInRadius.length} ${ccpPluralLower()} within ${radiusMiles == null ? 'any distance' : `${radiusMiles} mi`}`
                    : `No ${ccpPluralLower()} in range — try a wider radius`}
                </Text>
              </View>
            </View>

            <View style={styles.radiusRow}>
              {([5, 10, 20, null] as const).map((r) => {
                const active = radiusMiles === r;
                return (
                  <TouchableOpacity
                    key={r ?? 'any'}
                    onPress={() => {
                      hapticFeedback('light');
                      setRadiusMiles(r);
                    }}
                    style={[styles.radiusPill, active && { borderColor: chrome.border, backgroundColor: `${chrome.accent}1A` }]}
                    activeOpacity={0.85}
                  >
                    <Text style={[styles.radiusPillText, active && { color: chrome.icon }]}>
                      {r == null ? 'Any' : `${r} mi`}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {loadingValeters ? (
              <SkeletonList count={2} />
            ) : valetersInRadius.length === 0 ? (
              <View style={styles.emptyPros}>
                <Ionicons name="navigate-outline" size={28} color="rgba(125,211,252,0.5)" />
                <Text style={styles.emptyProsTitle}>No pros in this radius</Text>
                <Text style={styles.emptyProsSub}>Widen the radius or pick another day</Text>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.cardStrip}
                decelerationRate="fast"
                snapToInterval={CARD_WIDTH + 12}
              >
                {valetersInRadius.map((v, index) => (
                  <Animated.View key={v.id} entering={FadeInDown.delay(index * 50)}>
                    <ExploreValeterTripCard
                      valeter={v}
                      width={CARD_WIDTH}
                      accent={chrome.accent}
                      borderColor={chrome.border}
                      onPress={() => openProfile(v)}
                      onBook={() => handleBookValeter(v.id)}
                      onToggleFavourite={user?.id ? () => void toggleFavourite(v.id) : undefined}
                    />
                  </Animated.View>
                ))}
              </ScrollView>
            )}
          </Animated.View>
        ) : (
          <View style={styles.pickDayHint}>
            <Ionicons name="calendar-outline" size={18} color="rgba(125,211,252,0.65)" />
            <Text style={styles.pickDayHintText}>Select a date to browse available {ccpPluralLower()}</Text>
          </View>
        )}

        {loadingBookings ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator size="small" color={SKY} />
          </View>
        ) : null}
      </ScrollView>

      <ValeterProfileBottomSheet
        visible={valeterProfileSheet != null}
        onClose={() => setValeterProfileSheet(null)}
        valeterId={valeterProfileSheet?.id ?? null}
        seed={valeterProfileSheet}
        onRequestBook={async () => {
          const id = valeterProfileSheet?.id;
          if (!id) return;
          setValeterProfileSheet(null);
          handleBookValeter(id);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scroll: { flex: 1 },
  scrollContent: { gap: 16 },
  meshBg: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  prosSection: {
    gap: 12,
  },
  prosHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  prosHeaderText: {
    flex: 1,
    gap: 2,
  },
  prosKicker: {
    color: 'rgba(186,230,253,0.88)',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  prosTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: -0.2,
  },
  prosSubtitle: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  radiusRow: {
    flexDirection: 'row',
    gap: 8,
  },
  radiusPill: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    backgroundColor: 'rgba(8,20,38,0.35)',
  },
  radiusPillText: {
    color: 'rgba(226,232,240,0.82)',
    fontSize: 11,
    fontWeight: '800',
  },
  cardStrip: {
    paddingVertical: 4,
    paddingRight: 8,
  },
  emptyPros: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 32,
    gap: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    backgroundColor: 'rgba(8,20,38,0.28)',
  },
  emptyProsTitle: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '800',
  },
  emptyProsSub: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  pickDayHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  pickDayHintText: {
    color: 'rgba(148,163,184,0.88)',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  loadingRow: {
    alignItems: 'center',
    paddingVertical: 8,
  },
});
