import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Share,
  Alert,
  RefreshControl,
  Clipboard,
  Platform,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../../src/constants/colors';
import { passFlow } from '../../../src/constants/passFlowStyles';
import { SPACING } from '../../../src/constants/designTokens';
import {
  getReferralSummary,
  generateReferralCode,
  applyReferralCodeToUser,
  REFERRAL_BONUS_POINTS,
} from '../../../src/services/LoyaltyService';
import {
  buildReferralJoinLink,
  buildReferralShareMessage,
} from '../../../src/utils/referralLinks';
import { getNextReferralBadge } from '../../../src/utils/referralTier';
import ReferralPassportHero from '../../../src/components/referrals/ReferralPassportHero';
import ReferralInviteTicket from '../../../src/components/referrals/ReferralInviteTicket';
import ReferralSquadLadder from '../../../src/components/referrals/ReferralSquadLadder';
import ReferralSquadRoster, { type ReferralRosterItem } from '../../../src/components/referrals/ReferralSquadRoster';
import ReferralEnterCode from '../../../src/components/referrals/ReferralEnterCode';
import ReferralHowItWorksStrip from '../../../src/components/referrals/ReferralHowItWorksStrip';

const SKY = colors.SKY;

export default function ReferralSystem() {
  const params = useLocalSearchParams<{ enterCode?: string }>();
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [referralCode, setReferralCode] = useState(user?.id ? generateReferralCode(user.id) : 'WAW-00000000');
  const [hasAppliedReferral, setHasAppliedReferral] = useState(false);
  const [entryCode, setEntryCode] = useState('');
  const [enterCodeExpanded, setEnterCodeExpanded] = useState(false);
  const [applyingEntryCode, setApplyingEntryCode] = useState(false);
  const [referrals, setReferrals] = useState<ReferralRosterItem[]>([]);

  const rewardedReferralCount = useMemo(
    () => referrals.filter((referral) => referral.status === 'rewarded').length,
    [referrals],
  );
  const pendingCount = useMemo(
    () => referrals.filter((referral) => referral.status !== 'rewarded').length,
    [referrals],
  );
  const pointsEarned = rewardedReferralCount * REFERRAL_BONUS_POINTS;

  const nextBadgeHint = useMemo(() => {
    const next = getNextReferralBadge(rewardedReferralCount);
    if (!next) return 'All owner badges unlocked';
    const remaining = next.count - rewardedReferralCount;
    return `${remaining} more owner${remaining === 1 ? '' : 's'} to unlock ${next.label}`;
  }, [rewardedReferralCount]);

  const loadReferrals = useCallback(async () => {
    if (!user?.id) {
      setReferrals([]);
      setLoading(false);
      setRefreshing(false);
      setReferralCode('WAW-00000000');
      setHasAppliedReferral(false);
      return;
    }

    try {
      if (!refreshing) setLoading(true);
      const summary = await getReferralSummary(user.id);
      setReferralCode(summary.referralCode);
      setHasAppliedReferral(summary.referredBy);
      setReferrals(
        summary.referrals.map((row) => ({
          id: row.id,
          name: row.refereeName,
          date: row.createdAt,
          status: row.status,
          rewardAmount: row.rewardAmount,
        })),
      );
    } catch (err) {
      console.warn('[Referral] load failed:', err);
      setReferrals([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [refreshing, user?.id]);

  useEffect(() => {
    void loadReferrals();
  }, [loadReferrals]);

  useEffect(() => {
    const incoming = typeof params.enterCode === 'string' ? params.enterCode.trim().toUpperCase() : '';
    if (incoming) {
      setEntryCode(incoming);
      setEnterCodeExpanded(true);
    }
  }, [params.enterCode]);

  const onRefresh = () => {
    setRefreshing(true);
    void loadReferrals();
  };

  const referralLink = buildReferralJoinLink(referralCode);

  const handleShare = async () => {
    try {
      await hapticFeedback('light');
      const message = buildReferralShareMessage(referralCode);
      const link = buildReferralJoinLink(referralCode);
      await Share.share(
        Platform.OS === 'ios'
          ? { message, url: link }
          : { message, title: 'Join Wish a Wash' },
      );
    } catch (err) {
      console.warn('[Referral] Share failed:', err);
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    const link = buildReferralJoinLink(referralCode);
    Clipboard.setString(`${referralCode}\n${link}`);
    hapticFeedback('light');
    Alert.alert('Copied', 'Your referral code and invite link are on the clipboard.');
  };

  const handleApplyEntryCode = async () => {
    if (!user?.id) {
      router.push({ pathname: '/auth/signup', params: { referralCode: entryCode.trim() } });
      return;
    }
    const normalized = entryCode.trim().toUpperCase();
    if (!normalized) {
      Alert.alert('Enter a code', "Paste or type your friend's referral code.");
      return;
    }
    if (normalized === referralCode.trim().toUpperCase()) {
      Alert.alert("That's your code", "Enter a friend's referral code, not your own.");
      return;
    }
    if (hasAppliedReferral) {
      Alert.alert('Already applied', "You've already used a referral code on this account.");
      return;
    }

    try {
      setApplyingEntryCode(true);
      await hapticFeedback('light');
      const applied = await applyReferralCodeToUser(user.id, normalized);
      if (applied) {
        setHasAppliedReferral(true);
        setEntryCode('');
        Alert.alert('Code applied', 'Your referral code is saved. Complete your first booking to unlock rewards.');
        void loadReferrals();
      } else {
        Alert.alert('Invalid code', "We couldn't find that referral code. Check it and try again.");
      }
    } catch (err) {
      console.warn('[Referral] apply entry failed:', err);
      Alert.alert('Error', 'Unable to apply referral code right now.');
    } finally {
      setApplyingEntryCode(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Invite Pass"
        subtitle="Share · earn · rank up"
        showBack
        fullWidth
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        <ReferralPassportHero
          rewardedCount={rewardedReferralCount}
          totalCount={referrals.length}
          pendingCount={pendingCount}
          pointsEarned={pointsEarned}
          loading={loading}
        />

        {!loading ? (
          <Text style={[passFlow.hint, { color: 'rgba(245,158,11,0.85)' }]}>{nextBadgeHint}</Text>
        ) : null}

        <ReferralInviteTicket
          referralCode={referralCode}
          inviteLink={referralLink}
          onCopy={handleCopy}
          onShare={() => void handleShare()}
        />

        <ReferralHowItWorksStrip />

        <ReferralSquadLadder rewardedCount={rewardedReferralCount} />

        <ReferralEnterCode
          entryCode={entryCode}
          onChangeCode={setEntryCode}
          hasApplied={hasAppliedReferral}
          applying={applyingEntryCode}
          onApply={() => void handleApplyEntryCode()}
          initialExpanded={enterCodeExpanded}
        />

        <ReferralSquadRoster items={referrals} loading={loading} onShare={() => void handleShare()} />

        <View style={styles.disclaimer}>
          <Ionicons name="information-circle-outline" size={18} color="#9CA3AF" />
          <Text style={styles.disclaimerText}>
            Friends get £5 off their first booking. You earn {REFERRAL_BONUS_POINTS} Wash Pass points when a referred owner completes it.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {
    paddingBottom: 120,
    paddingHorizontal: SPACING.xl,
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  disclaimerText: {
    color: '#9CA3AF',
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },
});
