import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { colors } from '../../../src/constants/colors';
import { passFlow } from '../../../src/constants/passFlowStyles';
import { SPACING } from '../../../src/constants/designTokens';
import {
  getLoyaltyBalance,
  getLoyaltyActivity,
  redeemRewardPoints,
} from '../../../src/services/LoyaltyService';
import LoyaltyPassportHero from '../../../src/components/rewards/LoyaltyPassportHero';
import LoyaltyMilestoneTrack from '../../../src/components/rewards/LoyaltyMilestoneTrack';
import LoyaltyEarnStrip from '../../../src/components/rewards/LoyaltyEarnStrip';
import LoyaltyActivityFeed, { type LoyaltyActivityItem } from '../../../src/components/rewards/LoyaltyActivityFeed';
import LoyaltyClaimSheet from '../../../src/components/rewards/LoyaltyClaimSheet';
import { getNextMilestone, type RewardMilestone } from '../../../src/utils/loyaltyTier';

const SKY = colors.SKY;

export default function Rewards() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const { user, updateUser } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [activityLoading, setActivityLoading] = useState(false);
  const [claimedReward, setClaimedReward] = useState<RewardMilestone | null>(null);

  const [completedCount, setCompletedCount] = useState(0);
  const [points, setPoints] = useState(0);
  const [activity, setActivity] = useState<LoyaltyActivityItem[]>([]);

  const nextMilestoneLabel = useMemo(() => {
    const next = getNextMilestone(points);
    if (!next) return 'All milestone rewards unlocked';
    const remaining = next.points - points;
    return `${remaining.toLocaleString()} pts to unlock ${next.title}`;
  }, [points]);

  const loadPoints = useCallback(async () => {
    if (!user?.id) {
      setCompletedCount(0);
      setPoints(0);
      setActivity([]);
      setLoading(false);
      setRefreshing(false);
      setActivityLoading(false);
      return;
    }

    try {
      if (!refreshing) setLoading(true);
      setActivityLoading(true);
      const [balance, activityRows] = await Promise.all([
        getLoyaltyBalance(user.id),
        getLoyaltyActivity(user.id),
      ]);
      setCompletedCount(balance.completedBookings);
      setPoints(balance.effectivePoints);
      setActivity(
        activityRows.map((row) => ({
          id: row.id,
          label: row.label,
          pointsLabel: row.pointsLabel,
          date: row.date,
          icon: row.kind === 'redeem' ? 'gift-outline' : 'water-outline',
          accent: row.kind === 'redeem' ? '#A78BFA' : '#38BDF8',
        }))
      );
    } catch (e: unknown) {
      console.warn('[Rewards] Could not load loyalty.', e);
      setCompletedCount(0);
      setPoints(0);
      setActivity([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
      setActivityLoading(false);
    }
  }, [user?.id, refreshing]);

  useEffect(() => {
    void loadPoints();
  }, [loadPoints]);

  const onRefresh = () => {
    setRefreshing(true);
    void loadPoints();
  };

  const handleRedeem = (reward: RewardMilestone) => {
    if (!user?.id || redeemingId || points < reward.points) return;
    Alert.alert(
      'Claim reward',
      `Spend ${reward.points.toLocaleString()} points to unlock "${reward.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Claim',
          onPress: () => {
            void (async () => {
              try {
                setRedeemingId(reward.id);
                const nextBalance = await redeemRewardPoints(user.id, {
                  id: reward.id,
                  title: reward.title,
                  points: reward.points,
                });
                await updateUser({ tierPoints: nextBalance });
                setPoints(nextBalance);
                setClaimedReward(reward);
                void hapticFeedback('medium');
                const activityRows = await getLoyaltyActivity(user.id);
                setActivity(
                  activityRows.map((row) => ({
                    id: row.id,
                    label: row.label,
                    pointsLabel: row.pointsLabel,
                    date: row.date,
                    icon: row.kind === 'redeem' ? 'gift-outline' : 'water-outline',
                    accent: row.kind === 'redeem' ? '#A78BFA' : '#38BDF8',
                  }))
                );
              } catch (err: unknown) {
                const message = err instanceof Error ? err.message : 'Unable to redeem this reward right now.';
                Alert.alert('Claim failed', message);
              } finally {
                setRedeemingId(null);
              }
            })();
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Wash Pass"
        subtitle="Earn · unlock · redeem"
        showBack
        fullWidth
        points={loading ? undefined : points}
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, scrollPad]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        <LoyaltyPassportHero points={points} completedBookings={completedCount} loading={loading} />

        {!loading ? (
          <Text style={[passFlow.hint, { color: 'rgba(186,230,253,0.8)' }]}>{nextMilestoneLabel}</Text>
        ) : null}

        <LoyaltyEarnStrip />

        <LoyaltyMilestoneTrack points={points} redeemingId={redeemingId} onRedeem={handleRedeem} />

        <LoyaltyActivityFeed items={activity} loading={activityLoading} />

        <View style={styles.disclaimer}>
          <Ionicons name="information-circle-outline" size={18} color="#9CA3AF" />
          <Text style={styles.disclaimerText}>Rewards do not apply to detailing services.</Text>
        </View>
      </ScrollView>

      <LoyaltyClaimSheet
        visible={claimedReward != null}
        reward={claimedReward}
        onClose={() => setClaimedReward(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {
    paddingBottom: 120,
    paddingHorizontal: SPACING.xl,
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  disclaimerText: {
    color: '#9CA3AF',
    fontSize: 13,
    flex: 1,
  },
});
