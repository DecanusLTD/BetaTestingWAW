import React from 'react';
import { View, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import WashRatingAndTip from '../../src/components/wash/WashRatingAndTip';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { customerTheme } from '../../src/constants/customerTheme';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

export default function WashRatingScreen() {
  const { washCompletionId } = useLocalSearchParams<{ washCompletionId: string }>();

  if (!washCompletionId) {
    return null;
  }

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <AppHeader
        title="Rate Your Wash"
        showBack
        fullWidth
        onBack={handleBack}
      />
      <View style={styles.content}>
        <WashRatingAndTip
          washCompletionId={washCompletionId}
          hideHeader
          onComplete={() => router.back()}
          onClose={handleBack}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingTop: HEADER_CONTENT_OFFSET },
});
