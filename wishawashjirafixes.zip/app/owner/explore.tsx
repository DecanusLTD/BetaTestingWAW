/**
 * Explore — full-screen map + draggable-style bottom sheet (matches business Locations UX).
 * Tabs: Car Washes, mobile valeters, favourites. Horizontal cards sync with map markers.
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ScrollView,
  Alert,
  TextInput,
  Image,
  Platform,
  ActivityIndicator,
  Modal,
  Pressable,
  useWindowDimensions,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from 'react-native';
import { BlurView } from 'expo-blur';
import MapView, { Marker, PROVIDER_DEFAULT, type Region } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Slider from '@react-native-community/slider';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';
import EmptyState from '../../src/components/shared/EmptyState';
import { WWSheetCloseButton } from '../../src/components/ui';
import { distanceKm, etaMinutes } from '../../src/utils/mapUtils';
import {
  BOOKING_MAP_STYLE,
  MAP_LOCKED_DARK,
  MAP_CAMERA_ANIMATION_DURATION,
  DEFAULT_MAP_REGION,
} from '../../src/constants/mapConstants';
import BusinessSheetBackground from '../../src/components/shared/BusinessSheetBackground';
import BookingMapChromeHeader from '../../src/components/booking/BookingMapChromeHeader';
import ValeterProfileBottomSheet, {
  type ValeterProfileSheetSeed,
} from '../../src/components/valeter/ValeterProfileBottomSheet';
import HubLocationProfileBottomSheet, {
  type HubLocationSheetSeed,
} from '../../src/components/hub/HubLocationProfileBottomSheet';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import OpeningHoursSheet, { type OpeningHourRow } from '../../src/components/shared/OpeningHoursSheet';
import { customerMapTrackingSheetActionStyles } from '../../src/components/booking/CustomerMapTrackingSheetShell';
import {
  BOOKING_CARD,
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
  HEADER_STYLE_CARD_GRADIENT,
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
  BOOKING_SHEET_BLUR_INTENSITY,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../src/constants/bookingCardTheme';
import { useMapChromeColors } from '../../src/hooks/useMapChromeColors';
import { useKeyboardHeight } from '../../src/hooks/useKeyboardHeight';
import { TAB_BAR_TOTAL_HEIGHT } from '../../src/constants/layoutConstants';
import { MapMarkerValeterCandidate } from '../../src/components/maps/MapMarkerViews';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import TopCareProCard from '../../src/components/shared/TopCareProCard';
import { accentToGradient } from '../../src/utils/accentGradient';
import { fetchValeterIdentitiesByIds, resolveValeterDisplayName } from '../../src/utils/valeterDisplayName';
import {
  CUSTOMER_EXPLORE_TABS,
  MOBILE_SERVICE_ONLY_LAUNCH,
} from '../../src/constants/launchCustomerScope';
import { CCP, ccpFallbackName, ccpPluralLower, ccpSingularLower } from '../../src/constants/carCareProLabels';
import {
  TOP_CARE_PRO_CARD_ZOOM,
  getTopCareProCardWidth,
} from '../../src/constants/topCareProCardLayout';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const BG = colors.BG ?? '#0A1929';

type TabId = 'hubs' | 'valeters' | 'favourites';
type RadiusOption = 5 | 10 | 20 | 100 | null;
type ExploreSortOption = 'nearest' | 'rating';

const EXPLORE_STORAGE_RADIUS = 'wishawash:explore:radius';
const EXPLORE_STORAGE_SORT = 'wishawash:explore:sort';

/** Match dashboard Top Care Pros carousel tile width. */
const EXPLORE_TRACK_CARD_WIDTH = getTopCareProCardWidth(width);
const EXPLORE_TRACK_CARD_GAP = 12;
/** Align card strip with sheet header text + footer profile icon. */
const EXPLORE_SHEET_H_INSET = 14;

/** Explore map camera — neighbourhood / area height (not city-wide). */
const EXPLORE_MAP_DELTA = 0.028;
const EXPLORE_MAP_DELTA_SINGLE = 0.024;
const EXPLORE_MAP_DELTA_HUB = 0.016;
const EXPLORE_MAP_DELTA_VALETER = 0.028;
const EXPLORE_MAP_DELTA_VALETER_LNG = 0.022;
const CCP_ACCENT_GRADIENT = ['rgba(234,179,8,0.72)', 'rgba(120,83,14,0.58)'] as const;
const CCP_ACCENT_LABEL = '#1C1917';
const RADIUS_SLIDER_STOPS = [0, 5, 10, 20, 100] as const;

function radiusToSliderValue(radius: RadiusOption): number {
  return radius ?? 0;
}

function sliderValueToRadius(value: number): RadiusOption {
  const snapped = RADIUS_SLIDER_STOPS.reduce((closest, stop) =>
    Math.abs(stop - value) < Math.abs(closest - value) ? stop : closest
  , RADIUS_SLIDER_STOPS[0]);
  return snapped === 0 ? null : (snapped as Exclude<RadiusOption, null>);
}

function normalizeOpeningHours(
  rows: { day_of_week: number; is_open: boolean; open_time?: string | null; close_time?: string | null }[]
): OpeningHourRow[] {
  return (rows || [])
    .map((r) => ({
      day_of_week: r.day_of_week,
      is_open: !!r.is_open,
      open_time: r.open_time ?? null,
      close_time: r.close_time ?? null,
    }))
    .sort((a, b) => a.day_of_week - b.day_of_week);
}

function formatReviewWhen(iso?: string | null): string {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    const ms = Date.now() - d.getTime();
    if (!Number.isFinite(ms) || ms < 0) return 'Just now';
    const mins = Math.floor(ms / 60000);
    if (mins < 60) return `${Math.max(1, mins)}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    const weeks = Math.floor(days / 7);
    if (weeks < 5) return `${weeks}w ago`;
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch {
    return '';
  }
}

type HubRow = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  rating?: number | null;
  total_reviews?: number | null;
  base_price?: number | null;
  priority_price?: number | null;
  operating_hours?: unknown;
  services_offered?: string[] | null;
  phone?: string | null;
  openingHours?: OpeningHourRow[];
  offers_mobile?: boolean | null;
  distanceMiles?: number | null;
  etaMins?: number | null;
};

type ValeterRow = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number | null;
  etaMins: number | null;
  isOnline: boolean;
  profilePicture?: string | null;
  isFavourite: boolean;
  specializations?: string[];
  lastLat?: number | null;
  lastLng?: number | null;
};

type FavouriteRow = {
  id: string;
  valeter_id: string;
  valeter_profiles?: {
    user_id: string;
    full_name?: string | null;
    profile_photo_url?: string | null;
    specializations?: string[];
  } | null;
  rating?: number;
  totalJobs?: number;
  specializations?: string[];
};

type ExploreSheetItem = { kind: 'hub'; hub: HubRow } | { kind: 'valeter'; valeter: ValeterRow };
type TeamReview = { id: string; author: string; rating: number; text: string; when: string; avatarUrl?: string | null };
type TeamGalleryPlaceholder = { id: string; label: string };

function entryCoord(entry: ExploreSheetItem): { lat: number; lng: number } | null {
  if (entry.kind === 'hub') {
    if (entry.hub.latitude == null || entry.hub.longitude == null) return null;
    return { lat: entry.hub.latitude, lng: entry.hub.longitude };
  }
  if (entry.valeter.lastLat == null || entry.valeter.lastLng == null) return null;
  return { lat: entry.valeter.lastLat, lng: entry.valeter.lastLng };
}

export default function Explore() {
  const insets = useSafeAreaInsets();
  const { height: windowH } = useWindowDimensions();
  const params = useLocalSearchParams<{ q?: string; tab?: string; hubFilter?: string }>();
  const { user } = useAuth();
  const { theme: accountTheme } = useAccountTheme();
  const chrome = useMapChromeColors();
  const chromePillStyle = useMemo(
    () => ({
      borderColor: chrome.border,
      shadowColor: chrome.shadow,
    }),
    [chrome]
  );

  /** Lift sheet above keyboard when search is focused. */
  const sheetKeyboardHeight = useKeyboardHeight(true);
  const exploreSheetBottomOffset = sheetKeyboardHeight;

  const exploreSheetHeight = useMemo(() => {
    const bottomPad = Math.max(10, insets.bottom);
    const handleBlock = 18;
    const searchBlock = 56;
    const headerBlock = 24;
    const cardStrip = 128;
    const footerBlock = 56;
    const needed = bottomPad + handleBlock + searchBlock + headerBlock + cardStrip + footerBlock + 12;
    const maxH = windowH * 0.48;
    const minH = windowH * 0.36;
    return Math.round(Math.min(maxH, Math.max(minH, needed)));
  }, [insets.bottom, windowH]);

  const mapBottomPad = exploreSheetHeight + exploreSheetBottomOffset;

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const userPulseScale = useRef(new Animated.Value(0.9)).current;
  const userPulseOpacity = useRef(new Animated.Value(0.7)).current;
  const onlineLivePulseScale = useRef(new Animated.Value(1)).current;
  const onlineLivePulseOpacity = useRef(new Animated.Value(0.5)).current;
  const selectedPulseScale = useRef(new Animated.Value(1)).current;
  const selectedPulseOpacity = useRef(new Animated.Value(0.95)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<ScrollView>(null);

  const [tab, setTab] = useState<TabId>(MOBILE_SERVICE_ONLY_LAUNCH ? 'valeters' : 'hubs');
  /** When opened from Book a Service — detail studios only vs all Car Washes. */
  const [hubBookingFilter, setHubBookingFilter] = useState<'all' | 'detail'>('all');
  const [radiusMiles, setRadiusMiles] = useState<RadiusOption>(100);
  const [sortOption, setSortOption] = useState<ExploreSortOption>('nearest');
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [valeters, setValeters] = useState<ValeterRow[]>([]);
  const [favourites, setFavourites] = useState<FavouriteRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [favouriteIds, setFavouriteIds] = useState<Set<string>>(new Set());
  const [favouriteHubIds, setFavouriteHubIds] = useState<Set<string>>(new Set());
  const [favouriteHubs, setFavouriteHubs] = useState<HubRow[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [userCoords, setUserCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [searchPin, setSearchPin] = useState<{ latitude: number; longitude: number; label: string } | null>(null);
  const [searching, setSearching] = useState(false);
  const [selectedSheetIndex, setSelectedSheetIndex] = useState(0);
  const [markerOverlayEntry, setMarkerOverlayEntry] = useState<ExploreSheetItem | null>(null);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [exploreHoursHub, setExploreHoursHub] = useState<HubRow | null>(null);
  const [teamSheetHub, setTeamSheetHub] = useState<HubRow | null>(null);
  const [teamReviews, setTeamReviews] = useState<TeamReview[]>([]);
  const [teamReviewsLoading, setTeamReviewsLoading] = useState(false);
  const [galleryPreview, setGalleryPreview] = useState<TeamGalleryPlaceholder | null>(null);
  const [valeterProfileSheet, setValeterProfileSheet] = useState<ValeterProfileSheetSeed | null>(null);
  const [hubLocationSheet, setHubLocationSheet] = useState<HubLocationSheetSeed | null>(null);
  const [headerVehicleLabel, setHeaderVehicleLabel] = useState<string | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: DEFAULT_MAP_REGION.latitude,
    longitude: DEFAULT_MAP_REGION.longitude,
    latitudeDelta: EXPLORE_MAP_DELTA,
    longitudeDelta: EXPLORE_MAP_DELTA,
  });

  const qParam = (() => {
    const p = params?.q;
    if (typeof p === 'string') return p;
    if (Array.isArray(p) && p[0]) return String(p[0]);
    return '';
  })();

  useEffect(() => {
    if (qParam) setSearchQuery(qParam);
  }, [qParam]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [r, s] = await Promise.all([
          AsyncStorage.getItem(EXPLORE_STORAGE_RADIUS),
          AsyncStorage.getItem(EXPLORE_STORAGE_SORT),
        ]);
        if (cancelled) return;
        if (r === '5' || r === '10' || r === '20' || r === '100') setRadiusMiles(Number(r) as RadiusOption);
        else if (r === 'any') setRadiusMiles(null);
        if (s === 'rating' || s === 'nearest') setSortOption(s);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const v = radiusMiles == null ? 'any' : String(radiusMiles);
    AsyncStorage.setItem(EXPLORE_STORAGE_RADIUS, v).catch(() => {});
  }, [radiusMiles]);

  useEffect(() => {
    AsyncStorage.setItem(EXPLORE_STORAGE_SORT, sortOption).catch(() => {});
  }, [sortOption]);

  useEffect(() => {
    if (!user?.id) {
      setHeaderVehicleLabel(null);
      return;
    }
    let cancelled = false;
    void (async () => {
      const { data } = await supabase
        .from('customer_vehicles')
        .select('make, model, registration, is_default')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false })
        .limit(8);
      if (cancelled) return;
      const rows = (data || []) as Array<{
        make?: string | null;
        model?: string | null;
        registration?: string | null;
        is_default?: boolean | null;
      }>;
      const primary = rows.find((v) => v.is_default) ?? rows[0];
      if (!primary) {
        setHeaderVehicleLabel(null);
        return;
      }
      const name = [primary.make, primary.model].filter(Boolean).join(' ').trim();
      const reg = (primary.registration || '').trim().toUpperCase();
      setHeaderVehicleLabel([name || 'Your vehicle', reg].filter(Boolean).join(' · '));
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  useFocusEffect(
    useCallback(() => () => {
      setSearchQuery('');
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      const pTab = typeof params.tab === 'string' ? params.tab : Array.isArray(params.tab) ? params.tab[0] : '';
      if (pTab === 'hubs' || pTab === 'valeters' || pTab === 'favourites') {
        if (MOBILE_SERVICE_ONLY_LAUNCH && pTab === 'hubs') setTab('valeters');
        else setTab(pTab as TabId);
      }
      const hf = typeof params.hubFilter === 'string' ? params.hubFilter : Array.isArray(params.hubFilter) ? params.hubFilter[0] : '';
      if (hf === 'detail') setHubBookingFilter('detail');
      else if (hf === 'wash') setHubBookingFilter('all');
    }, [params.tab, params.hubFilter])
  );

  useEffect(() => {
    setSelectedSheetIndex(0);
  }, [tab]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, [fadeAnim]);

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(userPulseScale, {
            toValue: 1.55,
            duration: 1200,
            useNativeDriver: true,
          }),
          Animated.timing(userPulseScale, {
            toValue: 0.9,
            duration: 0,
            useNativeDriver: true,
          }),
        ]),
        Animated.sequence([
          Animated.timing(userPulseOpacity, {
            toValue: 0.05,
            duration: 1200,
            useNativeDriver: true,
          }),
          Animated.timing(userPulseOpacity, {
            toValue: 0.7,
            duration: 0,
            useNativeDriver: true,
          }),
        ]),
      ])
    );
    pulseLoop.start();
    return () => pulseLoop.stop();
  }, [userPulseOpacity, userPulseScale]);

  useEffect(() => {
    const selectedLoop = Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(selectedPulseScale, {
            toValue: 1.16,
            duration: 900,
            useNativeDriver: true,
          }),
          Animated.timing(selectedPulseScale, {
            toValue: 1,
            duration: 900,
            useNativeDriver: true,
          }),
        ]),
        Animated.sequence([
          Animated.timing(selectedPulseOpacity, {
            toValue: 0.6,
            duration: 900,
            useNativeDriver: true,
          }),
          Animated.timing(selectedPulseOpacity, {
            toValue: 0.95,
            duration: 900,
            useNativeDriver: true,
          }),
        ]),
      ])
    );
    selectedLoop.start();
    return () => selectedLoop.stop();
  }, [selectedPulseOpacity, selectedPulseScale]);

  const loadHubs = useCallback(async () => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) {
      setHubs([]);
      return;
    }
    const minimalSelect = 'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating';
    const fullSelect =
      'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating,total_reviews,base_price,priority_price,operating_hours,services_offered,phone,is_active';
    let rows: (HubRow & { is_active?: boolean })[] = [];
    try {
      const { data, error } = await supabase.from('car_wash_locations').select(fullSelect);
      if (error) throw error;
      rows = (data || []) as (HubRow & { is_active?: boolean })[];
      if (rows.length > 0 && rows[0].is_active !== undefined) {
        rows = rows.filter((h) => h.is_active !== false);
      }
    } catch {
      try {
        const { data, error } = await supabase.from('car_wash_locations').select(minimalSelect);
        if (error) throw error;
        rows = (data || []) as (HubRow & { is_active?: boolean })[];
      } catch {
        setHubs([]);
        return;
      }
    }
    const ids = rows.map((r) => r.id);
    let hoursByLocation: Record<string, OpeningHourRow[]> = {};
    if (ids.length > 0) {
      try {
        const { data: hoursData } = await supabase
          .from('location_opening_hours')
          .select('location_id,day_of_week,is_open,open_time,close_time')
          .in('location_id', ids);
        const byLocation: Record<string, any[]> = {};
        (hoursData || []).forEach((h: { location_id: string }) => {
          if (!byLocation[h.location_id]) byLocation[h.location_id] = [];
          byLocation[h.location_id].push(h);
        });
        ids.forEach((id) => {
          hoursByLocation[id] = normalizeOpeningHours(byLocation[id] || []);
        });
      } catch {
        // ignore
      }
    }
    setHubs(rows.map((h) => ({ ...h, openingHours: hoursByLocation[h.id] ?? [] })));
  }, []);

  const loadFavourites = useCallback(async (): Promise<FavouriteRow[]> => {
    if (!user?.id) return [];
    try {
      const { data, error } = await supabase
        .from('favourites')
        .select('id, valeter_id, valeter_profiles(user_id, full_name, profile_photo_url)')
        .eq('user_id', user.id);
      if (error && error.code !== 'PGRST116') throw error;
      const raw = (data || []) as unknown as FavouriteRow[];
      const ids = raw.map((f) => f.valeter_id).filter(Boolean);
      const [statsBatch, identityMap] = await Promise.all([
        ValeterStatsService.getValeterStatsBatch(ids),
        fetchValeterIdentitiesByIds(ids),
      ]);
      const enriched: FavouriteRow[] = raw.map((f) => {
        const specs = f.valeter_profiles?.specializations;
        const stats = statsBatch.get(f.valeter_id);
        const identity = identityMap.get(f.valeter_id);
        const resolvedName = identity?.name || resolveValeterDisplayName(f.valeter_profiles?.full_name);
        return {
          ...f,
          rating: stats?.averageRating ?? f.rating ?? 0,
          totalJobs: stats?.totalJobs ?? f.totalJobs ?? 0,
          specializations: Array.isArray(specs) ? specs : f.specializations ?? [],
          valeter_profiles: {
            user_id: f.valeter_id,
            full_name: resolvedName,
            profile_photo_url: identity?.photoUrl ?? f.valeter_profiles?.profile_photo_url ?? null,
          },
        };
      });
      setFavourites(enriched);
      setFavouriteIds(new Set(enriched.map((f) => f.valeter_id)));
      return enriched;
    } catch {
      setFavourites([]);
      setFavouriteIds(new Set());
      return [];
    }
  }, [user?.id]);

  const loadHubFavourites = useCallback(async (): Promise<HubRow[]> => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) {
      setFavouriteHubIds(new Set());
      setFavouriteHubs([]);
      return [];
    }
    if (!user?.id) return [];
    try {
      const { data: favData, error: favError } = await supabase
        .from('hub_favourites')
        .select('location_id')
        .eq('user_id', user.id);
      if (favError) {
        if (favError.code === '42P01') return [];
        throw favError;
      }
      const locationIds = (favData || []).map((r: { location_id: string }) => r.location_id).filter(Boolean);
      if (locationIds.length === 0) {
        setFavouriteHubIds(new Set());
        setFavouriteHubs([]);
        return [];
      }
      const fullSelect =
        'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating,total_reviews,base_price,priority_price,operating_hours,services_offered,phone,is_active';
      const { data: hubData, error: hubError } = await supabase
        .from('car_wash_locations')
        .select(fullSelect)
        .in('id', locationIds);
      if (hubError) throw hubError;
      const rows = (hubData || []) as (HubRow & { is_active?: boolean })[];
      const ids = rows.map((r) => r.id);
      let hoursByLocation: Record<string, OpeningHourRow[]> = {};
      if (ids.length > 0) {
        try {
          const { data: hoursData } = await supabase
            .from('location_opening_hours')
            .select('location_id,day_of_week,is_open,open_time,close_time')
            .in('location_id', ids);
          const byLocation: Record<string, any[]> = {};
          (hoursData || []).forEach((h: { location_id: string }) => {
            if (!byLocation[h.location_id]) byLocation[h.location_id] = [];
            byLocation[h.location_id].push(h);
          });
          ids.forEach((id) => {
            hoursByLocation[id] = normalizeOpeningHours(byLocation[id] || []);
          });
        } catch {
          // ignore
        }
      }
      const hubRows: HubRow[] = rows.map((h) => ({ ...h, openingHours: hoursByLocation[h.id] ?? [] }));
      setFavouriteHubIds(new Set(hubRows.map((h) => h.id)));
      setFavouriteHubs(hubRows);
      return hubRows;
    } catch {
      setFavouriteHubIds(new Set());
      setFavouriteHubs([]);
      return [];
    }
  }, [user?.id]);

  const loadValeters = useCallback(
    async (favIds?: Set<string>) => {
      const favSet = favIds ?? favouriteIds;
      try {
        const { data: presenceData, error: presenceError } = await supabase
          .from('valeter_presence')
          .select('user_id, is_online, last_lat, last_lng');
        if (presenceError) throw presenceError;
        const withLocation = (presenceData || []).filter(
          (p: { last_lat?: unknown; last_lng?: unknown }) => p.last_lat != null && p.last_lng != null
        );
        if (!withLocation.length) {
          setValeters([]);
          return;
        }
        const userIds = withLocation.map((p: { user_id: string }) => p.user_id);
        const [identityMap, statsBatch] = await Promise.all([
          fetchValeterIdentitiesByIds(userIds),
          ValeterStatsService.getValeterStatsBatch(userIds),
        ]);
        const list: ValeterRow[] = withLocation.map((p: Record<string, unknown>) => {
          const uid = p.user_id as string;
          const identity = identityMap.get(uid);
          const stats = statsBatch.get(uid);
          const lat = p.last_lat != null ? Number(p.last_lat) : null;
          const lng = p.last_lng != null ? Number(p.last_lng) : null;
          return {
            id: uid,
            name: identity?.name || ccpFallbackName(),
            rating: stats?.averageRating ?? 0,
            totalJobs: stats?.totalJobs ?? 0,
            distance: null,
            etaMins: null,
            isOnline: Boolean(p.is_online),
            profilePicture: identity?.photoUrl ?? null,
            isFavourite: favSet.has(uid),
            specializations: [],
            lastLat: lat,
            lastLng: lng,
          };
        });
        setValeters(list);
      } catch {
        setValeters([]);
      }
    },
    [favouriteIds]
  );

  const refreshQuiet = useCallback(async () => {
    await loadValeters();
    if (!MOBILE_SERVICE_ONLY_LAUNCH) await loadHubs();
  }, [loadValeters, loadHubs]);

  useEffect(() => {
    if (loading) return;
    const id = setInterval(() => {
      void refreshQuiet();
    }, 5000);
    return () => clearInterval(id);
  }, [loading, refreshQuiet]);

  /** Geocode the typed postcode / street / area, drop a pin and re-centre to see what's nearby. */
  const handleSearchSubmit = useCallback(async () => {
    const term = searchQuery.trim();
    if (!term) {
      setSearchPin(null);
      return;
    }
    try {
      setSearching(true);
      const results = await Location.geocodeAsync(term);
      const hit = results?.[0];
      if (!hit) {
        Alert.alert('No match', `Couldn't find “${term}”. Try a postcode, street or area name.`);
        return;
      }
      setSearchPin({ latitude: hit.latitude, longitude: hit.longitude, label: term });
      mapRef.current?.animateToRegion(
        { latitude: hit.latitude, longitude: hit.longitude, latitudeDelta: EXPLORE_MAP_DELTA_SINGLE, longitudeDelta: EXPLORE_MAP_DELTA_SINGLE },
        MAP_CAMERA_ANIMATION_DURATION * 0.6
      );
    } catch {
      Alert.alert('Search failed', 'Could not look up that location. Check your connection and try again.');
    } finally {
      setSearching(false);
    }
  }, [searchQuery]);

  const clearSearch = useCallback(() => {
    setSearchQuery('');
    setSearchPin(null);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const [favList] = await Promise.all([loadFavourites(), loadHubFavourites()]);
      if (cancelled) return;
      const favSet = new Set(favList.map((f) => f.valeter_id));
      await loadHubs();
      if (cancelled) return;
      await loadValeters(favSet);
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') {
          const { status: req } = await Location.requestForegroundPermissionsAsync();
          if (req !== 'granted' || cancelled) return;
        }
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!cancelled) setUserCoords({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!loading) loadValeters();
  }, [favouriteIds, loading, loadValeters]);

  const toggleFavourite = useCallback(
    async (valeterId: string) => {
      if (!user?.id) return;
      await hapticFeedback('light');
      const isFav = favouriteIds.has(valeterId);
      try {
        if (isFav) {
          await supabase.from('favourites').delete().eq('user_id', user.id).eq('valeter_id', valeterId);
          setFavouriteIds((prev) => {
            const next = new Set(prev);
            next.delete(valeterId);
            return next;
          });
          setFavourites((prev) => prev.filter((f) => f.valeter_id !== valeterId));
          setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: false } : v)));
          setValeterProfileSheet((prev) =>
            prev?.id === valeterId ? { ...prev, isFavourite: false } : prev
          );
        } else {
          await supabase.from('favourites').insert({ user_id: user.id, valeter_id: valeterId });
          setFavouriteIds((prev) => new Set([...prev, valeterId]));
          setFavourites((prev) => {
            const name = valeters.find((v) => v.id === valeterId)?.name;
            return [
              ...prev,
              {
                id: '',
                valeter_id: valeterId,
                valeter_profiles: { user_id: valeterId, full_name: name || null, profile_photo_url: null },
              },
            ];
          });
          setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: true } : v)));
          setValeterProfileSheet((prev) =>
            prev?.id === valeterId ? { ...prev, isFavourite: true } : prev
          );
        }
      } catch {
        Alert.alert('Error', 'Could not update favourite.');
      }
    },
    [user?.id, favouriteIds, valeters]
  );

  const toggleHubFavourite = useCallback(
    async (hubId: string) => {
      if (!user?.id) return;
      await hapticFeedback('light');
      const isFav = favouriteHubIds.has(hubId);
      try {
        if (isFav) {
          await supabase.from('hub_favourites').delete().eq('user_id', user.id).eq('location_id', hubId);
          setFavouriteHubIds((prev) => {
            const next = new Set(prev);
            next.delete(hubId);
            return next;
          });
          setFavouriteHubs((prev) => prev.filter((h) => h.id !== hubId));
        } else {
          await supabase.from('hub_favourites').insert({ user_id: user.id, location_id: hubId });
          setFavouriteHubIds((prev) => new Set([...prev, hubId]));
          const hub = hubs.find((h) => h.id === hubId);
          if (hub) setFavouriteHubs((prev) => (prev.some((h) => h.id === hubId) ? prev : [...prev, hub]));
        }
      } catch {
        Alert.alert('Error', 'Could not update favourite.');
      }
    },
    [user?.id, favouriteHubIds, hubs]
  );

  const handleHubPress = useCallback((hub: HubRow) => {
    hapticFeedback('light');
    setHubLocationSheet({
      id: hub.id,
      name: hub.name,
      rating: hub.rating != null ? Number(hub.rating) : undefined,
    });
  }, []);

  const handleDirectHubBooking = useCallback(async (hub: HubRow) => {
    await hapticFeedback('light');
    router.push({
      pathname: '/owner/booking/physical/vehicle',
      params: { locationId: hub.id },
    });
  }, []);

  const handleDirectValeterBooking = useCallback(
    async (valeterId: string) => {
      await hapticFeedback('light');
      const params: Record<string, string> = {
        preferredValeterId: valeterId,
      };
      if (userCoords) {
        params.latitude = String(userCoords.latitude);
        params.longitude = String(userCoords.longitude);
        params.address = 'Current location';
      }
      router.push({
        pathname: '/owner/booking/create',
        params,
      });
    },
    [userCoords]
  );

  const openValeterProfileSheet = useCallback((v: ValeterRow) => {
    hapticFeedback('light');
    setValeterProfileSheet({
      id: v.id,
      name: v.name,
      rating: v.rating,
      totalJobs: v.totalJobs,
      profilePicture: v.profilePicture ?? null,
      isOnline: v.isOnline,
      distanceMiles: v.distance ?? null,
      etaMins: v.etaMins ?? null,
      isFavourite: v.isFavourite,
      ...(v.specializations?.length ? { specializations: v.specializations } : {}),
    });
  }, []);

  const q = searchQuery.trim().toLowerCase();

  /** When a place has been searched, distances/nearby are measured from that pin; otherwise from the user. */
  const focusCoords = useMemo(
    () => (searchPin ? { latitude: searchPin.latitude, longitude: searchPin.longitude } : userCoords),
    [searchPin, userCoords]
  );

  const valetersWithDistance = useMemo(() => {
    if (!focusCoords) return valeters;
    return valeters.map((v) => {
      if (v.lastLat == null || v.lastLng == null) return v;
      const km = distanceKm(focusCoords, { latitude: v.lastLat, longitude: v.lastLng });
      const miles = km * 0.621371;
      return { ...v, distance: miles, etaMins: etaMinutes(km) };
    });
  }, [valeters, focusCoords]);

  const hubsWithDistance = useMemo(() => {
    if (!focusCoords) return hubs;
    return hubs.map((h) => {
      if (h.latitude == null || h.longitude == null) return { ...h, distanceMiles: null as number | null, etaMins: null as number | null };
      const km = distanceKm(focusCoords, { latitude: h.latitude, longitude: h.longitude });
      return { ...h, distanceMiles: km * 0.621371, etaMins: etaMinutes(km) };
    });
  }, [hubs, focusCoords]);

  const filteredHubsBySearch = useMemo(() => {
    // Searching a place re-centres by proximity (below), so don't also name-filter.
    if (searchPin || !q) return hubsWithDistance;
    return hubsWithDistance.filter(
      (h) =>
        (h.name && h.name.toLowerCase().includes(q)) || (h.address && h.address.toLowerCase().includes(q))
    );
  }, [hubsWithDistance, q, searchPin]);

  const filteredValetersBySearch = useMemo(() => {
    if (searchPin || !q) return valetersWithDistance;
    return valetersWithDistance.filter((v) => v.name && v.name.toLowerCase().includes(q));
  }, [valetersWithDistance, q, searchPin]);

  const hubsInRadius = useMemo(() => {
    let list = filteredHubsBySearch;
    if (radiusMiles != null) {
      list = list.filter((h) => (h.distanceMiles ?? 999) <= radiusMiles);
    }
    return list;
  }, [filteredHubsBySearch, radiusMiles]);

  const valetersInRadius = useMemo(() => {
    let list = filteredValetersBySearch;
    if (radiusMiles != null) {
      list = list.filter((v) => (v.distance ?? 999) <= radiusMiles);
    }
    return list;
  }, [filteredValetersBySearch, radiusMiles]);

  const onlineProsCount = useMemo(
    () => valetersInRadius.filter((v) => v.isOnline).length,
    [valetersInRadius]
  );

  const nearestProEtaMins = useMemo(() => {
    const etas = valetersInRadius
      .filter((v) => v.isOnline && v.etaMins != null && Number.isFinite(v.etaMins))
      .map((v) => Number(v.etaMins));
    if (etas.length === 0) {
      const any = valetersInRadius
        .filter((v) => v.etaMins != null && Number.isFinite(v.etaMins))
        .map((v) => Number(v.etaMins));
      if (any.length === 0) return null;
      return Math.min(...any);
    }
    return Math.min(...etas);
  }, [valetersInRadius]);

  const nearestProEtaLabel = useMemo(() => {
    if (nearestProEtaMins == null) return 'ETA —';
    return `~${Math.max(1, Math.round(nearestProEtaMins))} min`;
  }, [nearestProEtaMins]);

  useEffect(() => {
    if (onlineProsCount <= 0) {
      onlineLivePulseScale.setValue(1);
      onlineLivePulseOpacity.setValue(0);
      return;
    }
    const liveLoop = Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(onlineLivePulseScale, { toValue: 1.9, duration: 1100, useNativeDriver: true }),
          Animated.timing(onlineLivePulseScale, { toValue: 1, duration: 0, useNativeDriver: true }),
        ]),
        Animated.sequence([
          Animated.timing(onlineLivePulseOpacity, { toValue: 0, duration: 1100, useNativeDriver: true }),
          Animated.timing(onlineLivePulseOpacity, { toValue: 0.55, duration: 0, useNativeDriver: true }),
        ]),
      ])
    );
    liveLoop.start();
    return () => liveLoop.stop();
  }, [onlineProsCount, onlineLivePulseOpacity, onlineLivePulseScale]);

  const displayHubs = useMemo(() => {
    const list = [...hubsInRadius];
    if (sortOption === 'rating') {
      list.sort((a, b) => {
        const ra = a.rating != null ? Number(a.rating) : 0;
        const rb = b.rating != null ? Number(b.rating) : 0;
        if (rb !== ra) return rb - ra;
        const ja = a.total_reviews != null ? Number(a.total_reviews) : 0;
        const jb = b.total_reviews != null ? Number(b.total_reviews) : 0;
        return jb - ja;
      });
      return list;
    }
    if (!focusCoords) return list;
    list.sort((a, b) => {
      const da = a.distanceMiles ?? 1e9;
      const db = b.distanceMiles ?? 1e9;
      return da - db;
    });
    return list;
  }, [hubsInRadius, sortOption, focusCoords]);

  const hubsForBookingList = useMemo(() => {
    if (hubBookingFilter === 'detail') {
      return displayHubs.filter((h) => h.detailing_offered);
    }
    return displayHubs;
  }, [displayHubs, hubBookingFilter]);

  const displayValeters = useMemo(() => {
    const list = [...valetersInRadius];
    if (sortOption === 'rating') {
      list.sort((a, b) => {
        if (b.rating !== a.rating) return b.rating - a.rating;
        return b.totalJobs - a.totalJobs;
      });
      return list;
    }
    if (!focusCoords) return list;
    list.sort((a, b) => {
      const da = a.distance ?? 1e9;
      const db = b.distance ?? 1e9;
      return da - db;
    });
    return list;
  }, [valetersInRadius, sortOption, focusCoords]);
  const teamSlides = useMemo(() => displayValeters.slice(0, 10), [displayValeters]);
  const teamMembers = useMemo((): ValeterRow[] => teamSlides, [teamSlides]);
  const hasTeamMembers = teamMembers.length > 0;
  const teamGalleryPlaceholders = useMemo(
    (): TeamGalleryPlaceholder[] =>
      Array.from({ length: 8 }, (_, idx) => ({ id: `gallery-slot-${idx + 1}`, label: `Photo ${idx + 1}` })),
    []
  );
  const displayedTeamReviews = teamReviews;

  useEffect(() => {
    let cancelled = false;
    const loadTeamReviews = async () => {
      if (!teamSheetHub?.id) {
        setTeamReviews([]);
        setTeamReviewsLoading(false);
        return;
      }
      setTeamReviewsLoading(true);
      try {
        const { data: reviewRows, error: reviewErr } = await supabase
          .from('bookings')
          .select('id, user_id, rating, review, completed_at')
          .eq('location_id', teamSheetHub.id)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(20);
        if (reviewErr) throw reviewErr;
        const rows =
          ((reviewRows || []) as { id: string; user_id: string; rating: number; review?: string | null; completed_at?: string | null }[]) || [];
        if (!rows.length) {
          if (!cancelled) setTeamReviews([]);
          return;
        }
        const userIds = [...new Set(rows.map((r) => r.user_id).filter(Boolean))];
        let profileMap = new Map<string, { full_name: string; profile_picture: string | null }>();
        if (userIds.length > 0) {
          const { data: profileRows } = await supabase
            .from('profiles')
            .select('id, full_name, profile_picture')
            .in('id', userIds);
          profileMap = new Map(
            ((profileRows || []) as { id: string; full_name?: string | null; profile_picture?: string | null }[]).map((p) => [
              p.id,
              { full_name: (p.full_name || 'Customer').trim() || 'Customer', profile_picture: p.profile_picture ?? null },
            ])
          );
        }
        const mapped: TeamReview[] = rows.map((row) => {
          const profile = profileMap.get(row.user_id);
          return {
            id: row.id,
            author: profile?.full_name || 'Customer',
            rating: Number(row.rating) || 0,
            text: (row.review || '').trim() || 'Great service.',
            when: formatReviewWhen(row.completed_at) || 'Recent',
            avatarUrl: profile?.profile_picture ?? null,
          };
        });
        if (!cancelled) setTeamReviews(mapped);
      } catch {
        if (!cancelled) setTeamReviews([]);
      } finally {
        if (!cancelled) setTeamReviewsLoading(false);
      }
    };
    loadTeamReviews();
    return () => {
      cancelled = true;
    };
  }, [teamSheetHub?.id]);

  const filteredFavouriteHubs = useMemo(() => {
    if (searchPin || !q) return favouriteHubs;
    return favouriteHubs.filter(
      (h) =>
        (h.name && h.name.toLowerCase().includes(q)) || (h.address && h.address.toLowerCase().includes(q))
    );
  }, [favouriteHubs, q, searchPin]);

  const filteredFavourites = useMemo(() => {
    if (searchPin || !q) return favourites;
    return favourites.filter((f) => {
      const name = f.valeter_profiles?.full_name || '';
      return name.toLowerCase().includes(q);
    });
  }, [favourites, q, searchPin]);

  const favouriteHubsWithDistance = useMemo(() => {
    if (!focusCoords) return filteredFavouriteHubs;
    return filteredFavouriteHubs.map((h) => {
      if (h.latitude == null || h.longitude == null) return { ...h, distanceMiles: null as number | null, etaMins: null as number | null };
      const km = distanceKm(focusCoords, { latitude: h.latitude, longitude: h.longitude });
      return { ...h, distanceMiles: km * 0.621371, etaMins: etaMinutes(km) };
    });
  }, [filteredFavouriteHubs, focusCoords]);

  const favouriteSheetEntries = useMemo((): ExploreSheetItem[] => {
    const hubItems: ExploreSheetItem[] = MOBILE_SERVICE_ONLY_LAUNCH
      ? []
      : favouriteHubsWithDistance.map((hub) => ({ kind: 'hub', hub }));
    const valItems: ExploreSheetItem[] = filteredFavourites.map((f) => {
      const v = valetersWithDistance.find((x) => x.id === f.valeter_id);
      if (v) return { kind: 'valeter', valeter: { ...v, isFavourite: true } };
      return {
        kind: 'valeter',
        valeter: {
          id: f.valeter_id,
          name: resolveValeterDisplayName(f.valeter_profiles?.full_name),
          rating: f.rating ?? 0,
          totalJobs: f.totalJobs ?? 0,
          distance: null,
          etaMins: null,
          isOnline: false,
          profilePicture: f.valeter_profiles?.profile_photo_url ?? null,
          isFavourite: true,
          specializations: f.specializations ?? [],
          lastLat: null,
          lastLng: null,
        },
      };
    });
    return [...hubItems, ...valItems];
  }, [favouriteHubsWithDistance, filteredFavourites, valetersWithDistance]);

  const sheetEntries = useMemo((): ExploreSheetItem[] => {
    if (tab === 'hubs') return hubsForBookingList.map((hub) => ({ kind: 'hub', hub }));
    if (tab === 'valeters') return displayValeters.map((valeter) => ({ kind: 'valeter', valeter }));
    return favouriteSheetEntries;
  }, [tab, hubsForBookingList, displayValeters, favouriteSheetEntries]);

  const sheetEntriesRef = useRef(sheetEntries);
  sheetEntriesRef.current = sheetEntries;

  const cardWidth = EXPLORE_TRACK_CARD_WIDTH;
  const cardSpacing = EXPLORE_TRACK_CARD_GAP;
  const snapInterval = cardWidth + cardSpacing;

  const selectedEntry = sheetEntries[selectedSheetIndex] ?? null;
  const singleSheetCard = sheetEntries.length === 1;

  const selectedProEtaLabel = useMemo(() => {
    if (selectedEntry?.kind === 'valeter') {
      const eta = selectedEntry.valeter.etaMins;
      if (eta != null && Number.isFinite(eta)) {
        return `~${Math.max(1, Math.round(Number(eta)))} min`;
      }
    }
    if (selectedEntry?.kind === 'hub') {
      const eta = selectedEntry.hub.etaMins;
      if (eta != null && Number.isFinite(eta)) {
        return `~${Math.max(1, Math.round(Number(eta)))} min`;
      }
    }
    return nearestProEtaLabel;
  }, [selectedEntry, nearestProEtaLabel]);

  useEffect(() => {
    if (selectedSheetIndex >= sheetEntries.length && sheetEntries.length > 0) {
      setSelectedSheetIndex(sheetEntries.length - 1);
    }
    if (sheetEntries.length === 0 && selectedSheetIndex !== 0) setSelectedSheetIndex(0);
  }, [sheetEntries.length, selectedSheetIndex, sheetEntries]);

  useEffect(() => {
    if (!scrollViewRef.current || sheetEntries.length === 0) return;
    const x = selectedSheetIndex * snapInterval;
    scrollViewRef.current.scrollTo({ x, animated: true });
  }, [selectedSheetIndex, sheetEntries.length, snapInterval]);

  useEffect(() => {
    const e = sheetEntriesRef.current[selectedSheetIndex];
    if (!e || !mapRef.current) return;
    const c = entryCoord(e);
    if (!c) return;
    const isValeter = e.kind === 'valeter';
    const latitudeDelta = isValeter ? EXPLORE_MAP_DELTA_VALETER : EXPLORE_MAP_DELTA_HUB;
    const longitudeDelta = isValeter ? EXPLORE_MAP_DELTA_VALETER_LNG : EXPLORE_MAP_DELTA_HUB;
    mapRef.current.animateToRegion(
      { latitude: c.lat, longitude: c.lng, latitudeDelta, longitudeDelta },
      MAP_CAMERA_ANIMATION_DURATION * 0.5
    );
  }, [selectedSheetIndex]);

  useEffect(() => {
    if (loading || !mapRef.current) return;
    const anchor = userCoords
      ? userCoords
      : (() => {
          const first = sheetEntriesRef.current.map(entryCoord).find(Boolean);
          return first ? { latitude: first.lat, longitude: first.lng } : null;
        })();
    if (!anchor) return;
    const t = setTimeout(() => {
      // Stay at area height — do not fit city-wide to every Pro.
      mapRef.current?.animateToRegion(
        {
          latitude: anchor.latitude,
          longitude: anchor.longitude,
          latitudeDelta: EXPLORE_MAP_DELTA,
          longitudeDelta: EXPLORE_MAP_DELTA,
        },
        500
      );
    }, 450);
    return () => clearTimeout(t);
  }, [loading, tab, userCoords]);

  const handleScrollHorizontal = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = event.nativeEvent.contentOffset.x;
    const idx = Math.round(x / snapInterval);
    if (idx >= 0 && idx < sheetEntries.length && idx !== selectedSheetIndex) {
      setSelectedSheetIndex(idx);
    }
  };

  const onMarkerPress = (index: number) => {
    hapticFeedback('light');
    setSelectedSheetIndex(index);
    const entry = sheetEntriesRef.current[index] ?? null;
    if (entry) setMarkerOverlayEntry(entry);
  };

  const glassBorder = accountTheme.glassBorder ?? 'rgba(125,211,252,0.28)';

  const sheetHeadline = useMemo(() => {
    if (tab === 'hubs') {
      if (hubBookingFilter === 'detail') return 'Detail studios';
      return 'Car Washes';
    }
    if (tab === 'valeters') return '';
    return 'Favourites';
  }, [tab, hubBookingFilter]);
  const sheetTagline = useMemo(() => {
    if (tab === 'favourites') return '';
    if (tab === 'hubs') {
      return hubBookingFilter === 'detail' ? 'Studios with detailing — open hours, then book on the hub.' : '';
    }
    return '';
  }, [tab, hubBookingFilter]);
  const showSheetTitle = sheetHeadline.length > 0;
  const showSheetTagline = sheetTagline.length > 0;
  const showSheetPagerDots = sheetEntries.length > 1;
  const showSheetHeader = showSheetTitle || showSheetTagline || showSheetPagerDots;

  const renderMap = () => {
    if (loading) {
      return (
        <View style={[styles.mapContainer, styles.mapLoading]}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.mapLoadingTitle}>Almost there</Text>
          <Text style={styles.mapLoadingText}>
            {MOBILE_SERVICE_ONLY_LAUNCH
              ? `Plotting ${ccpPluralLower()} on your map…`
              : `Plotting Car Washes & ${ccpPluralLower()} on your map…`}
          </Text>
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          onRegionChangeComplete={setRegion}
          provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          showsUserLocation={false}
          showsMyLocationButton={false}
          showsCompass={false}
          scrollEnabled={false}
          zoomEnabled={false}
          zoomTapEnabled={false}
          zoomControlEnabled={false}
          pitchEnabled={false}
          rotateEnabled={false}
          moveOnMarkerPress={false}
          mapType="standard"
          mapPadding={{ top: 52, bottom: mapBottomPad, left: 0, right: 0 }}
        >
          {userCoords ? (
            <Marker coordinate={userCoords} anchor={{ x: 0.5, y: 0.5 }}>
              <View style={styles.userLocationMarkerWrap}>
                <Animated.View
                  style={[
                    styles.userLocationPulseRing,
                    { transform: [{ scale: userPulseScale }], opacity: userPulseOpacity },
                  ]}
                />
                <View style={styles.userLocationCoreDot} />
                <View style={styles.userLocationInnerDot} />
              </View>
            </Marker>
          ) : null}
          {searchPin ? (
            <Marker
              coordinate={{ latitude: searchPin.latitude, longitude: searchPin.longitude }}
              anchor={{ x: 0.5, y: 1 }}
              zIndex={999}
            >
              <View style={styles.searchPinWrap}>
                <View style={styles.searchPinBubble}>
                  <Ionicons name="location" size={18} color="#fff" />
                </View>
                <View style={styles.searchPinStem} />
              </View>
            </Marker>
          ) : null}
          {sheetEntries.map((entry, index) => {
            const c = entryCoord(entry);
            if (!c) return null;
            const isSel = index === selectedSheetIndex;
            const isValeter = entry.kind === 'valeter';
            return (
              <Marker
                key={entry.kind === 'hub' ? `hub-${entry.hub.id}` : `v-${entry.valeter.id}`}
                coordinate={{ latitude: c.lat, longitude: c.lng }}
                anchor={{ x: 0.5, y: 0.5 }}
                onPress={() => onMarkerPress(index)}
              >
                {isValeter ? (
                  <View
                    style={[
                      { opacity: isSel ? 1 : 0.72 },
                      isSel && styles.valeterMarkerSelectedGlow,
                    ]}
                  >
                    <Animated.View
                      style={
                        isSel
                          ? {
                              transform: [{ scale: selectedPulseScale }],
                            }
                          : undefined
                      }
                    >
                      <MapMarkerValeterCandidate
                        size={66}
                        isSelected={isSel}
                        isOnline={entry.valeter.isOnline}
                        photoUri={entry.valeter.profilePicture}
                        rating={entry.valeter.rating}
                      />
                    </Animated.View>
                  </View>
                ) : (
                  <View style={[styles.markerOuter, isSel && styles.markerOuterSelected]}>
                    <Animated.View
                      style={[
                        styles.markerGlow,
                        isSel && styles.markerGlowActive,
                        isSel
                          ? {
                              transform: [{ scale: selectedPulseScale }],
                              opacity: selectedPulseOpacity,
                            }
                          : null,
                      ]}
                    />
                    <View style={[styles.markerCore, isSel && styles.markerCoreSelected]}>
                      <Ionicons name="location" size={20} color={isSel ? '#0f172a' : SKY} />
                    </View>
                  </View>
                )}
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  const renderExploreFullHeader = () => (
    <BookingMapChromeHeader
      topInset={insets.top}
      onBack={() => {
        hapticFeedback('light');
        router.back();
      }}
      centerContent={
        <View style={[styles.exploreHeaderMetaPill, chromePillStyle]}>
          {renderExploreMapGlassLayers()}
          <View style={styles.exploreHeaderMetaInner}>
            <View style={styles.exploreHeaderMetaTopRow}>
              <Text style={styles.exploreHeaderMetaPrimary} numberOfLines={1}>
                {headerVehicleLabel || 'Add a vehicle in Garage'}
              </Text>
              <Text style={styles.exploreHeaderMetaEta} numberOfLines={1}>
                {selectedProEtaLabel}
              </Text>
            </View>
          </View>
        </View>
      }
    />
  );

  const renderSheetSearchBar = () => (
    <View style={[styles.exploreSheetSearchPill, styles.exploreSheetSearchPillCool]}>
      <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(56,189,248,0.10)', 'rgba(8,20,38,0.72)', 'rgba(148,163,184,0.06)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.10)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.exploreMapGlassSheen}
        pointerEvents="none"
      />
      <View style={styles.exploreSearchPillInner}>
        {searching ? (
          <ActivityIndicator size="small" color={SKY} />
        ) : (
          <Ionicons name={searchPin ? 'navigate' : 'search'} size={18} color={SKY} />
        )}
        <TextInput
          style={styles.exploreSearchInput}
          placeholder="Search postcode, street or area"
          placeholderTextColor="rgba(148,163,184,0.75)"
          value={searchQuery}
          onChangeText={(t) => {
            setSearchQuery(t);
            if (searchPin) setSearchPin(null);
          }}
          returnKeyType="search"
          onSubmitEditing={() => void handleSearchSubmit()}
        />
        {searchQuery.length > 0 ? (
          <TouchableOpacity onPress={clearSearch} hitSlop={8} accessibilityLabel="Clear search">
            <Ionicons name="close-circle" size={20} color="rgba(148,163,184,0.65)" />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );

  const renderOnlineProsMapBadge = () => (
    <View style={styles.onlineProsMapBadgeWrap} pointerEvents="none">
      <View style={styles.onlineProsMapBadge}>
        <BlurView intensity={22} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <View style={styles.onlineProsMapBadgeInner}>
          <View style={styles.onlineProsMapIconWrap}>
            <Ionicons name="car-sport" size={14} color="#E2E8F0" />
            {onlineProsCount > 0 ? (
              <Animated.View
                style={[
                  styles.onlineProsMapPulse,
                  {
                    transform: [{ scale: onlineLivePulseScale }],
                    opacity: onlineLivePulseOpacity,
                  },
                ]}
              />
            ) : null}
            <View
              style={[
                styles.onlineProsMapLiveDot,
                { backgroundColor: onlineProsCount > 0 ? '#34D399' : '#64748B' },
              ]}
            />
          </View>
          <Text style={styles.onlineProsMapCount}>{onlineProsCount}</Text>
        </View>
      </View>
    </View>
  );

  const renderCardGlossSheen = () => (
    <LinearGradient
      colors={[...BOOKING_GLASS_TOP_SHEEN]}
      locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0.85 }}
      style={StyleSheet.absoluteFill}
      pointerEvents="none"
    />
  );

  const renderSheetCard = (entry: ExploreSheetItem) => {
    if (entry.kind === 'hub') {
      const hub = entry.hub;
      const rating = hub.rating != null ? Number(hub.rating) : null;
      const isOpen = (hub.status || '').toLowerCase() === 'open';
      const distMiles = hub.distanceMiles ?? null;
      const accent = hub.detailing_offered ? DETAILING_YELLOW : SKY;
      const kicker = hub.detailing_offered ? 'DETAIL STUDIO' : 'CAR WASH';
      const statusColor = isOpen ? '#10B981' : '#EF4444';
      return (
        <View style={styles.exploreTrackTripCard}>
          <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[accent + '18', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          {renderCardGlossSheen()}
          <View style={styles.exploreTrackTripCardPad}>
            <View style={[styles.exploreTrackAccentRail, { backgroundColor: accent }]} />
            <View style={styles.exploreTrackCardTop}>
              <View style={[styles.exploreTrackIconWrap, { backgroundColor: accent + '25' }]}>
                <GradientIconBox
                  icon={hub.detailing_offered ? 'diamond' : 'camera-outline'}
                  colors={accentToGradient(accent)}
                  boxSize={40}
                  borderRadius={11}
                  elevated
                  size={22}
                />
              </View>
              <View style={styles.exploreTrackCardMain}>
                <View style={styles.exploreTrackTopMetaRow}>
                  <Text style={styles.exploreTrackKicker}>{kicker}</Text>
                  <TouchableOpacity
                    onPress={() => toggleHubFavourite(hub.id)}
                    hitSlop={10}
                    style={styles.exploreTrackHeartInline}
                    accessibilityLabel={favouriteHubIds.has(hub.id) ? 'Remove hub from favourites' : 'Save hub to favourites'}
                  >
                    <Ionicons
                      name={favouriteHubIds.has(hub.id) ? 'heart' : 'heart-outline'}
                      size={20}
                      color={favouriteHubIds.has(hub.id) ? '#EF4444' : 'rgba(248,250,252,0.88)'}
                    />
                  </TouchableOpacity>
                </View>
                <Text style={styles.exploreTrackTitle} numberOfLines={1}>
                  {hub.name}
                </Text>
                {hub.address ? (
                  <Text style={styles.exploreTrackSubtitle} numberOfLines={1}>
                    {hub.address}
                  </Text>
                ) : null}
                <View style={[styles.exploreTrackStatusPill, { backgroundColor: statusColor + '30' }]}>
                  <View style={[styles.exploreTrackStatusDot, { backgroundColor: statusColor }]} />
                  <Text style={[styles.exploreTrackStatusPillText, { color: statusColor }]}>{isOpen ? 'Open' : 'Closed'}</Text>
                </View>
              </View>
            </View>
            <View style={styles.exploreTrackCardBottom}>
              <View style={styles.exploreTrackBottomMeta}>
                {rating != null ? (
                  <View style={styles.exploreTrackEtaWrap}>
                    <Ionicons name="star" size={14} color="#FBBF24" />
                    <Text style={styles.exploreTrackEtaText}>{rating.toFixed(1)}</Text>
                  </View>
                ) : null}
                {distMiles != null ? (
                  <View style={styles.exploreTrackEtaWrap}>
                    <Ionicons name="navigate-outline" size={14} color={SKY} />
                    <Text style={styles.exploreTrackEtaText}>{distMiles.toFixed(1)} mi</Text>
                  </View>
                ) : null}
              </View>
              {hub.openingHours && hub.openingHours.length > 0 ? (
                <TouchableOpacity
                  onPress={() => {
                    hapticFeedback('light');
                    setExploreHoursHub(hub);
                  }}
                  style={styles.exploreTrackHoursBtn}
                  hitSlop={8}
                  accessibilityLabel="View weekly opening hours"
                >
                  <Ionicons name="time-outline" size={20} color={SKY} />
                </TouchableOpacity>
              ) : null}
            </View>
          </View>
        </View>
      );
    }

    const v = entry.valeter;
    return (
      <TopCareProCard
        width={cardWidth}
        zoom={TOP_CARE_PRO_CARD_ZOOM}
        pro={{
          id: v.id,
          name: v.name,
          rating: v.rating,
          totalJobs: v.totalJobs,
          distance: v.distance,
          isOnline: v.isOnline,
          profilePicture: v.profilePicture ?? null,
          isFavourite: v.isFavourite,
        }}
        accent={chrome.accent}
        borderColor={chrome.border}
        onPress={() => {
          hapticFeedback('light');
          openValeterProfileSheet(v);
        }}
        onToggleFavourite={() => toggleFavourite(v.id)}
      />
    );
  };

  const renderExploreMapGlassLayers = () => (
    <>
      <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={[...chrome.gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.exploreMapGlassSheen}
        pointerEvents="none"
      />
    </>
  );

  const renderSheetFilterBtn = () => (
    <TouchableOpacity
      onPress={() => {
        hapticFeedback('light');
        setFilterPanelOpen(true);
      }}
      style={styles.sheetFiltersBtn}
      activeOpacity={0.85}
      accessibilityLabel="Filters · map view, radius, sort"
    >
      <Ionicons name="options-outline" size={22} color={SKY} />
      {radiusMiles != null || sortOption !== 'nearest' ? <View style={styles.sheetFiltersBtnDot} /> : null}
    </TouchableOpacity>
  );

  const renderSelectedActions = () => {
    if (!selectedEntry) return null;
    if (selectedEntry.kind === 'hub') {
      const hub = selectedEntry.hub;
      return (
        <View style={[customerMapTrackingSheetActionStyles.bookingInfoRow, styles.selectedActionsRow]}>
          <TouchableOpacity
            onPress={() => {
              hapticFeedback('light');
              setTeamSheetHub(hub);
            }}
            style={styles.exploreSheetIconAction}
            activeOpacity={0.85}
            accessibilityLabel="Hub profile · washes and reviews"
          >
            <Ionicons name="person-outline" size={22} color={SKY} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => void handleDirectHubBooking(hub)}
            style={[
              customerMapTrackingSheetActionStyles.bookingInfoActionCard,
              customerMapTrackingSheetActionStyles.bookingInfoCard,
              styles.selectedPrimaryActionCard,
              { borderColor: SKY + '55' },
            ]}
            activeOpacity={0.85}
          >
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={['rgba(74,122,142,0.55)', 'rgba(21,34,56,0.5)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <Ionicons name="calendar-outline" size={22} color={SKY} style={{ zIndex: 1 }} />
            <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
              <Text style={[customerMapTrackingSheetActionStyles.bookingInfoCardText, { color: SKY }]}>Book this hub</Text>
            </View>
          </TouchableOpacity>
          {renderSheetFilterBtn()}
        </View>
      );
    }
    const v = selectedEntry.valeter;
    return (
      <View style={[customerMapTrackingSheetActionStyles.bookingInfoRow, styles.selectedActionsRow]}>
        <TouchableOpacity
          onPress={() => openValeterProfileSheet(v)}
          style={[styles.exploreSheetIconAction, styles.exploreSheetIconActionCcp, chromePillStyle]}
          activeOpacity={0.85}
        >
          <Ionicons name="person-outline" size={22} color={chrome.icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => void handleDirectValeterBooking(v.id)}
          style={[
            customerMapTrackingSheetActionStyles.bookingInfoActionCard,
            customerMapTrackingSheetActionStyles.bookingInfoCard,
            styles.selectedPrimaryActionCard,
            { borderColor: chrome.border },
          ]}
          activeOpacity={0.85}
        >
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[...CCP_ACCENT_GRADIENT]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Ionicons name="flash-outline" size={22} color={CCP_ACCENT_LABEL} style={{ zIndex: 1 }} />
          <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
            <Text style={[customerMapTrackingSheetActionStyles.bookingInfoCardText, { color: CCP_ACCENT_LABEL }]}>
              {CCP.requestButton}
            </Text>
          </View>
        </TouchableOpacity>
        {renderSheetFilterBtn()}
      </View>
    );
  };

  return (
    <View style={styles.root}>
      {renderExploreFullHeader()}
      <Animated.View style={[styles.flex, { opacity: fadeAnim }]}>
        {renderMap()}
        {renderOnlineProsMapBadge()}

        <Modal
          visible={filterPanelOpen}
          transparent
          animationType="slide"
          onRequestClose={() => setFilterPanelOpen(false)}
        >
          <View style={styles.filterSheetRoot}>
            <Pressable
              style={StyleSheet.absoluteFill}
              onPress={() => setFilterPanelOpen(false)}
              accessibilityRole="button"
              accessibilityLabel="Dismiss filters"
            />
            <View style={styles.filterSheetInner}>
              <View
                style={[
                  styles.locationBottomSheet,
                  {
                    borderColor: glassBorder,
                    flex: 0,
                    maxHeight: height * 0.62,
                    paddingBottom: Math.max(10, insets.bottom),
                  },
                ]}
              >
                <BusinessSheetBackground />
                <View style={styles.sheetHandle} />
                <View style={styles.filterSheetTitleRow}>
                  <View style={styles.filterSheetTitleText}>
                    <Text style={styles.sheetHeaderTitle}>Map & filters</Text>
                    <Text style={[styles.sheetHeaderSubtitle, styles.filterSheetSubtitleTight]}>
                      Choose view, then radius & sort
                    </Text>
                  </View>
                  <WWSheetCloseButton
                    onPress={() => setFilterPanelOpen(false)}
                    hitSlop={12}
                    accessibilityLabel="Close filters"
                  />
                </View>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={styles.filterSheetScrollContent}
                  bounces
                >
                  <Text style={styles.filterModalSectionLabel}>Map view</Text>
                  <View style={styles.filterModeRow}>
                    {CUSTOMER_EXPLORE_TABS.map((t) => {
                      const labels: Record<TabId, string> = { hubs: 'Car Washes', valeters: CCP.exploreTab, favourites: 'Favourites' };
                      const icons: Record<TabId, keyof typeof Ionicons.glyphMap> = {
                        hubs: 'business',
                        valeters: 'car-sport',
                        favourites: 'heart',
                      };
                      const active = tab === t;
                      return (
                        <TouchableOpacity
                          key={t}
                          onPress={() => {
                            hapticFeedback('light');
                            setTab(t);
                          }}
                          style={[styles.filterModeIconBtn, active && styles.filterModeIconBtnActive]}
                          activeOpacity={0.88}
                        >
                          <Ionicons name={icons[t]} size={24} color={active ? '#E0F2FE' : SKY} />
                          <Text style={[styles.filterModeIconLabel, active && styles.filterModeIconLabelActive]}>{labels[t]}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                  {tab !== 'favourites' ? (
                    <>
                      <Text style={styles.filterModalSectionLabel}>Radius</Text>
                      <View style={styles.radiusSliderWrap}>
                        <View style={styles.radiusSliderLabelsRow}>
                          <Text style={styles.radiusSliderValue}>
                            {radiusMiles == null ? 'Any distance' : `${radiusMiles} mi`}
                          </Text>
                          <Text style={styles.radiusSliderHint}>Drag to adjust</Text>
                        </View>
                        <Slider
                          minimumValue={0}
                          maximumValue={100}
                          step={1}
                          value={radiusToSliderValue(radiusMiles)}
                          onSlidingComplete={(value) => {
                            hapticFeedback('light');
                            setRadiusMiles(sliderValueToRadius(value));
                          }}
                          minimumTrackTintColor={SKY}
                          maximumTrackTintColor="rgba(148,163,184,0.4)"
                          thumbTintColor="#E0F2FE"
                        />
                        <View style={styles.radiusSliderStopsRow}>
                          {RADIUS_SLIDER_STOPS.map((stop) => (
                            <TouchableOpacity
                              key={`radius-stop-${stop}`}
                              onPress={() => {
                                hapticFeedback('light');
                                setRadiusMiles(stop === 0 ? null : (stop as Exclude<RadiusOption, null>));
                              }}
                              style={styles.radiusSliderStopBtn}
                              activeOpacity={0.8}
                            >
                              <Text style={styles.radiusSliderStopText}>{stop === 0 ? 'Any' : `${stop} mi`}</Text>
                            </TouchableOpacity>
                          ))}
                        </View>
                      </View>
                      <View style={styles.filterModalRow}>
                        {([null, 5, 10, 20, 100] as RadiusOption[]).map((r) => {
                          const label = r == null ? 'Any' : `${r} mi`;
                          const active = radiusMiles === r;
                          return (
                            <TouchableOpacity
                              key={label}
                              onPress={() => {
                                hapticFeedback('light');
                                setRadiusMiles(r);
                              }}
                              style={[styles.filterChip, active && styles.filterChipActive]}
                            >
                              <Text style={[styles.filterChipText, active && styles.filterChipTextActive]}>{label}</Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>
                      <Text style={styles.filterModalSectionLabel}>Sort</Text>
                      <View style={[styles.filterModalRow, { marginBottom: 6 }]}>
                        {(['nearest', 'rating'] as ExploreSortOption[]).map((opt) => {
                          const active = sortOption === opt;
                          const label = opt === 'nearest' ? 'Nearest' : 'Rated';
                          return (
                            <TouchableOpacity
                              key={opt}
                              onPress={() => {
                                hapticFeedback('light');
                                setSortOption(opt);
                              }}
                              style={[styles.filterChip, active && styles.filterChipActive]}
                            >
                              <Text style={[styles.filterChipText, active && styles.filterChipTextActive]}>{label}</Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>
                    </>
                  ) : (
                    <Text style={styles.filterModalFavouritesHint}>
                      Radius and sort apply to Car Washes and {CCP.pluralShort}. Switch map view above to use them.
                    </Text>
                  )}
                </ScrollView>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          visible={markerOverlayEntry != null}
          transparent
          animationType="slide"
          onRequestClose={() => setMarkerOverlayEntry(null)}
        >
          <View style={styles.markerOverlayRoot}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setMarkerOverlayEntry(null)} />
            <View style={styles.markerOverlaySheet}>
              <View style={styles.markerOverlayHandle} />
              <View style={styles.markerOverlayGalleryPlaceholder}>
                <LinearGradient
                  colors={['rgba(56,189,248,0.18)', 'rgba(15,23,42,0.58)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                <GradientIconBox icon="camera-outline" preset="sky" boxSize={48} borderRadius={14} muted borderless size={26} />
                <Text style={styles.markerOverlayGalleryText}>Image placeholder</Text>
              </View>

              {markerOverlayEntry ? (
                <View style={styles.markerOverlayProfileCard}>
                  <View style={styles.markerOverlayProfileTop}>
                    <Text style={styles.markerOverlayType}>
                      {markerOverlayEntry.kind === 'hub'
                        ? markerOverlayEntry.hub.detailing_offered
                          ? 'Detailing Studio'
                          : 'Car Wash'
                        : CCP.singularShort}
                    </Text>
                    <Text style={styles.markerOverlayTitle} numberOfLines={1}>
                      {markerOverlayEntry.kind === 'hub'
                        ? markerOverlayEntry.hub.name
                        : formatDisplayName(markerOverlayEntry.valeter.name) || markerOverlayEntry.valeter.name}
                    </Text>
                    <Text style={styles.markerOverlayMeta} numberOfLines={1}>
                      {markerOverlayEntry.kind === 'hub'
                        ? markerOverlayEntry.hub.address || 'Nearby'
                        : markerOverlayEntry.valeter.isOnline
                          ? 'Available now'
                          : 'Offline'}
                    </Text>
                  </View>

                  <View style={[customerMapTrackingSheetActionStyles.bookingInfoRow, styles.markerOverlayActions]}>
                    <TouchableOpacity
                      onPress={() => {
                        if (markerOverlayEntry.kind === 'hub') {
                          setTeamSheetHub(markerOverlayEntry.hub);
                        } else {
                          openValeterProfileSheet(markerOverlayEntry.valeter);
                        }
                      }}
                      style={[
                        styles.exploreSheetIconAction,
                        markerOverlayEntry.kind === 'valeter' && [styles.exploreSheetIconActionCcp, chromePillStyle],
                      ]}
                      activeOpacity={0.86}
                    >
                      {markerOverlayEntry.kind === 'hub' ? (
                        <GradientIconBox icon="person-outline" preset="sky" boxSize={40} borderRadius={12} elevated size={20} />
                      ) : (
                        <GradientIconBox
                          icon="person-outline"
                          colors={accentToGradient(chrome.accent)}
                          boxSize={40}
                          borderRadius={12}
                          elevated
                          size={20}
                        />
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        if (markerOverlayEntry.kind === 'hub') {
                          void handleDirectHubBooking(markerOverlayEntry.hub);
                        } else {
                          void handleDirectValeterBooking(markerOverlayEntry.valeter.id);
                        }
                        setMarkerOverlayEntry(null);
                      }}
                      style={[
                        customerMapTrackingSheetActionStyles.bookingInfoActionCard,
                        customerMapTrackingSheetActionStyles.bookingInfoCard,
                        styles.selectedPrimaryActionCard,
                        markerOverlayEntry.kind === 'hub'
                          ? { borderColor: SKY + '55' }
                          : { borderColor: chrome.border },
                      ]}
                      activeOpacity={0.88}
                    >
                      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                      <LinearGradient
                        colors={
                          markerOverlayEntry.kind === 'hub'
                            ? ['rgba(74,122,142,0.55)', 'rgba(21,34,56,0.5)']
                            : [...CCP_ACCENT_GRADIENT]
                        }
                        start={{ x: 0, y: 0 }}
                        end={{ x: 0, y: 1 }}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                      <View style={{ zIndex: 1 }}>
                        {markerOverlayEntry.kind === 'hub' ? (
                          <GradientIconBox icon="calendar-outline" preset="sky" boxSize={36} borderRadius={11} elevated size={20} />
                        ) : (
                          <GradientIconBox
                            icon="flash-outline"
                            colors={accentToGradient(chrome.accent)}
                            boxSize={36}
                            borderRadius={11}
                            elevated
                            size={20}
                          />
                        )}
                      </View>
                      <View style={customerMapTrackingSheetActionStyles.bookingInfoCardTextWrap}>
                        <Text
                          style={[
                            customerMapTrackingSheetActionStyles.bookingInfoCardText,
                            { color: markerOverlayEntry.kind === 'hub' ? SKY : CCP_ACCENT_LABEL },
                          ]}
                        >
                          {markerOverlayEntry.kind === 'hub' ? 'Book this hub' : CCP.requestButton}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : null}
            </View>
          </View>
        </Modal>

        <Modal
          visible={teamSheetHub != null}
          transparent
          animationType="slide"
          onRequestClose={() => setTeamSheetHub(null)}
        >
          <View style={styles.teamSheetRoot}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setTeamSheetHub(null)} />
            <View style={[styles.teamSheetPanel, { borderColor: HEADER_STYLE_CARD_BORDER }]}>
              <BlurView intensity={24} tint="dark" style={styles.teamSheetBlur} pointerEvents="none" />
              <LinearGradient
                colors={HEADER_STYLE_CARD_GRADIENT}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={styles.teamSheetDarkOverlay} pointerEvents="none" />
              <View style={[styles.teamSheetGlow, { backgroundColor: SKY + '88', shadowColor: SKY }]} pointerEvents="none" />
              <View style={styles.teamSheetHandle} />
              <Text style={styles.teamSheetKicker}>TEAM</Text>
              <Text style={styles.teamSheetTitle} numberOfLines={1}>
                {teamSheetHub ? `Team at ${teamSheetHub.name}` : 'Team'}
              </Text>
              <Text style={styles.teamSheetSubtitle}>Swipe to pick a pro</Text>
              <View style={styles.teamTrustRow}>
                <View style={styles.teamTrustPill}>
                  <Ionicons name="checkmark-circle-outline" size={12} color={SKY} />
                  <Text style={styles.teamTrustText}>Verified Partner</Text>
                </View>
                <View style={styles.teamTrustPill}>
                  <Ionicons name="shield-checkmark-outline" size={12} color={SKY} />
                  <Text style={styles.teamTrustText}>Vetted & Tested</Text>
                </View>
              </View>

              {hasTeamMembers ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.teamSheetCards}>
                  {teamMembers.map((member) => (
                    <TouchableOpacity
                      key={`team-slide-${member.id}`}
                      style={styles.teamCard}
                      onPress={() => openValeterProfileSheet(member)}
                      activeOpacity={0.86}
                    >
                      <View style={styles.teamAvatar}>
                        {member.profilePicture ? (
                          <Image source={{ uri: member.profilePicture }} style={styles.teamAvatarImg} />
                        ) : (
                          <Ionicons name="person" size={24} color={SKY} />
                        )}
                      </View>
                      <Text style={styles.teamName} numberOfLines={1}>{formatDisplayName(member.name) || member.name}</Text>
                      <Text style={styles.teamMeta} numberOfLines={1}>
                        {member.isOnline ? 'Available now' : 'Offline'} · {member.totalJobs} jobs
                      </Text>
                      <View style={styles.teamCardStatsRow}>
                        <View style={styles.teamCardPill}>
                          <Ionicons name="star" size={12} color="#FBBF24" />
                          <Text style={styles.teamCardPillText}>{member.rating > 0 ? member.rating.toFixed(1) : 'New'}</Text>
                        </View>
                        {member.distance != null ? (
                          <View style={styles.teamCardPill}>
                            <Ionicons name="navigate-outline" size={12} color={SKY} />
                            <Text style={styles.teamCardPillText}>{member.distance.toFixed(1)} mi</Text>
                          </View>
                        ) : null}
                      </View>
                      {member.specializations && member.specializations.length > 0 ? (
                        <Text style={styles.teamSpecs} numberOfLines={2}>{member.specializations.join(' • ')}</Text>
                      ) : null}
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              ) : null}

              <Text style={styles.teamGalleryTitle}>Gallery · Instagram / Uploads</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.teamGalleryRow}>
                {teamGalleryPlaceholders.map((slot) => (
                  <TouchableOpacity
                    key={slot.id}
                    style={styles.teamGalleryPlaceholder}
                    activeOpacity={0.86}
                    onPress={() => setGalleryPreview(slot)}
                  >
                    <GradientIconBox icon="camera-outline" preset="sky" boxSize={44} borderRadius={12} elevated size={18} />
                    <Text style={styles.teamGalleryPlaceholderText}>{slot.label}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <View style={styles.teamReviewsHeader}>
                <Text style={styles.teamGalleryTitle}>Reviews</Text>
                <Text style={styles.teamReviewsCount}>
                  {teamSheetHub?.total_reviews ? `${teamSheetHub.total_reviews}+` : displayedTeamReviews.length} reviews
                </Text>
              </View>
              {teamReviewsLoading && teamReviews.length === 0 ? (
                <View style={styles.teamEmptyCard}>
                  <ActivityIndicator size="small" color={SKY} />
                  <Text style={styles.teamEmptyText}>Loading reviews...</Text>
                </View>
              ) : displayedTeamReviews.length > 0 ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.teamReviewsRow}>
                  {displayedTeamReviews.map((review) => (
                    <View key={review.id} style={styles.teamReviewCard}>
                      <View style={styles.teamReviewHeadRow}>
                        <View style={styles.teamReviewAvatar}>
                          {review.avatarUrl ? (
                            <Image source={{ uri: review.avatarUrl }} style={styles.teamReviewAvatarImg} />
                          ) : (
                            <Text style={styles.teamReviewAvatarFallback}>
                              {review.author.trim().charAt(0).toUpperCase() || 'C'}
                            </Text>
                          )}
                        </View>
                        <View style={styles.teamReviewMetaWrap}>
                          <View style={styles.teamReviewTopRow}>
                            <Text style={styles.teamReviewAuthor} numberOfLines={1}>{review.author}</Text>
                            <Text style={styles.teamReviewWhen}>{review.when}</Text>
                          </View>
                          <View style={styles.teamReviewRatingRow}>
                            <Ionicons name="star" size={12} color="#FBBF24" />
                            <Text style={styles.teamReviewRatingText}>{review.rating.toFixed(1)}</Text>
                          </View>
                        </View>
                      </View>
                      <Text style={styles.teamReviewText} numberOfLines={4}>{review.text}</Text>
                    </View>
                  ))}
                </ScrollView>
              ) : (
                <View style={styles.teamEmptyCard}>
                  <GradientIconBox icon="chatbubbles-outline" preset="sky" boxSize={36} borderRadius={11} muted size={18} />
                  <Text style={styles.teamEmptyText}>Reviews will appear here</Text>
                </View>
              )}
            </View>
          </View>
        </Modal>

        <Modal
          visible={galleryPreview != null}
          transparent
          animationType="fade"
          onRequestClose={() => setGalleryPreview(null)}
        >
          <View style={styles.galleryPreviewRoot}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setGalleryPreview(null)} />
            <View style={styles.galleryPreviewCard}>
              <GradientIconBox icon="camera-outline" preset="sky" boxSize={56} borderRadius={16} elevated size={30} />
              <Text style={styles.galleryPreviewTitle}>{galleryPreview?.label ?? 'Photo slot'}</Text>
              <Text style={styles.galleryPreviewSubtitle}>Placeholder - tap outside to close</Text>
            </View>
          </View>
        </Modal>

        <View style={styles.sheetKeyboardAvoid}>
          <View style={[styles.sheetOuter, { height: exploreSheetHeight, bottom: exploreSheetBottomOffset }]}>
            <View
              style={[
                styles.exploreVehicleBottomSheet,
                { paddingBottom: sheetKeyboardHeight > 0 ? 12 : Math.max(insets.bottom, 8) },
              ]}
            >
            <BusinessSheetBackground />
            <View style={styles.exploreSheetHandle} />
            <View style={styles.exploreSheetSearchWrap}>{renderSheetSearchBar()}</View>

            {showSheetHeader ? (
              <View
                style={[
                  styles.exploreMapSheetHeaderRow,
                  !showSheetTitle && !showSheetTagline && styles.exploreMapSheetHeaderCompact,
                ]}
              >
                {showSheetTitle || showSheetTagline ? (
                  <View style={styles.exploreMapSheetHeaderText}>
                    {showSheetTitle ? (
                      <View style={styles.exploreMapSheetTitleRow}>
                        <Text style={styles.exploreMapSheetTitle}>{sheetHeadline}</Text>
                        {showSheetPagerDots ? (
                          <View style={styles.exploreMapSheetTitleIndicators}>
                            {sheetEntries.map((e, i) => (
                              <View
                                key={`title-ind-${e.kind === 'hub' ? e.hub.id : e.valeter.id}`}
                                style={[styles.indicatorDot, i === selectedSheetIndex && styles.indicatorDotActive]}
                              />
                            ))}
                          </View>
                        ) : null}
                      </View>
                    ) : null}
                    {showSheetTagline ? (
                      <Text style={styles.exploreMapSheetHook} numberOfLines={2}>
                        {sheetTagline}
                      </Text>
                    ) : null}
                  </View>
                ) : showSheetPagerDots ? (
                  <View style={styles.exploreMapSheetDotsOnly}>
                    {sheetEntries.map((e, i) => (
                      <View
                        key={`title-ind-${e.kind === 'hub' ? e.hub.id : e.valeter.id}`}
                        style={[styles.indicatorDot, i === selectedSheetIndex && styles.indicatorDotActive]}
                      />
                    ))}
                  </View>
                ) : null}
              </View>
            ) : null}

            <View style={styles.exploreMapSheetBody}>
            {!loading && sheetEntries.length === 0 ? (
              <View style={styles.emptySheetBody}>
                <EmptyState
                  icon={tab === 'hubs' ? 'business-outline' : tab === 'valeters' ? 'car-outline' : 'heart-outline'}
                  title={
                    q
                      ? 'No matches for that search'
                      : tab === 'favourites'
                        ? 'Nothing saved yet'
                        : tab === 'hubs'
                          ? hubBookingFilter === 'detail'
                            ? 'No detail studios in range'
                            : 'No Car Washes in this view'
                          : `No ${ccpPluralLower()} on the map`
                  }
                  subtitle={
                    q
                      ? `Try another postcode, street or hub name — or clear search.`
                      : tab === 'favourites'
                        ? MOBILE_SERVICE_ONLY_LAUNCH
                          ? `Heart a ${ccpSingularLower()} from their profile — they’ll land here for one-tap booking.`
                          : `Heart a hub or ${ccpSingularLower()} from their profile — they’ll land here for one-tap booking.`
                        : tab === 'hubs'
                          ? hubBookingFilter === 'detail'
                            ? 'Widen filters or switch to all Car Washes — detailing isn’t at every site.'
                            : 'Zoom out, clear radius, or check back — new sites join often.'
                          : MOBILE_SERVICE_ONLY_LAUNCH
                            ? `When ${ccpPluralLower()} go online nearby, they’ll appear here.`
                            : `When ${ccpPluralLower()} go online nearby, they’ll appear here. Try Car Washes meanwhile.`
                  }
                  iconColor={SKY}
                  style={styles.emptySheetState}
                />
                <View style={styles.sheetFooter}>
                  <View style={styles.emptySheetFilterRow}>{renderSheetFilterBtn()}</View>
                </View>
              </View>
            ) : !loading ? (
              <View style={styles.sheetContentWrap}>
                <View style={[styles.sheetCardsScrollWrap, singleSheetCard && styles.sheetCardsScrollWrapSingle]}>
                  <ScrollView
                    ref={scrollViewRef}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    onScroll={handleScrollHorizontal}
                    scrollEventThrottle={16}
                    contentContainerStyle={[
                      styles.sheetCardsScrollContent,
                      singleSheetCard && styles.sheetCardsScrollContentSingle,
                      tab === 'valeters' && styles.sheetCardsScrollContentTight,
                    ]}
                    snapToInterval={singleSheetCard ? undefined : snapInterval}
                    decelerationRate="fast"
                    snapToAlignment="start"
                    nestedScrollEnabled
                    scrollEnabled={!singleSheetCard}
                    style={styles.sheetHorizontalScroll}
                  >
                    {sheetEntries.map((entry) => (
                      <View
                        key={entry.kind === 'hub' ? entry.hub.id : entry.valeter.id}
                        style={[
                          styles.cardScrollItem,
                          singleSheetCard && styles.cardScrollItemSingle,
                          { width: cardWidth },
                        ]}
                      >
                        {renderSheetCard(entry)}
                      </View>
                    ))}
                  </ScrollView>
                </View>
                <View style={styles.sheetFooter}>
                  {renderSelectedActions()}
                </View>
              </View>
            ) : null}
            </View>
          </View>
          </View>
        </View>
      </Animated.View>

      <OpeningHoursSheet
        visible={exploreHoursHub != null}
        onClose={() => setExploreHoursHub(null)}
        hours={exploreHoursHub?.openingHours ?? []}
        accentColor={exploreHoursHub?.detailing_offered ? DETAILING_YELLOW : SKY}
      />

      <ValeterProfileBottomSheet
        visible={valeterProfileSheet != null}
        onClose={() => setValeterProfileSheet(null)}
        valeterId={valeterProfileSheet?.id ?? null}
        seed={valeterProfileSheet}
        {...(valeterProfileSheet?.id
          ? { onToggleFavourite: () => toggleFavourite(valeterProfileSheet.id) }
          : {})}
        onRequestBook={async () => {
          const id = valeterProfileSheet?.id;
          if (!id) return;
          if (user?.id) {
            const active = await getActiveBookingForCustomer(user.id);
            if (active) {
              Alert.alert('One booking at a time', 'Finish or cancel your current booking first.', [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'View booking',
                  onPress: () =>
                    router.push({ pathname: '/owner/track', params: { bookingId: active.id } } as any),
                },
              ]);
              return;
            }
          }
          await handleDirectValeterBooking(id);
          setValeterProfileSheet(null);
        }}
      />

      {!MOBILE_SERVICE_ONLY_LAUNCH ? (
      <HubLocationProfileBottomSheet
        visible={hubLocationSheet != null}
        onClose={() => setHubLocationSheet(null)}
        locationId={hubLocationSheet?.id ?? null}
        seed={hubLocationSheet}
        onRequestBook={async (hubId) => {
          setHubLocationSheet(null);
          const hub = hubs.find((h) => h.id === hubId);
          if (hub) await handleDirectHubBooking(hub);
          else
            router.push({ pathname: '/owner/booking/physical/vehicle', params: { locationId: hubId } } as any);
        }}
      />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: BG },
  flex: { flex: 1 },
  mapContainer: { flex: 1, overflow: 'hidden' },
  map: { ...StyleSheet.absoluteFillObject },
  mapLoading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.35)',
    gap: 12,
  },
  mapLoadingTitle: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginTop: 4,
  },
  mapLoadingText: { color: 'rgba(148,163,184,0.95)', fontSize: 13, fontWeight: '600', textAlign: 'center', paddingHorizontal: 40 },
  exploreHeaderRightRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  exploreHeaderIconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  exploreFullHeader: {
    overflow: 'hidden',
    borderBottomWidth: 1,
    borderBottomColor: HEADER_STYLE_CARD_BORDER,
    backgroundColor: BG,
    zIndex: 920,
  },
  exploreFullHeaderContent: {
    paddingHorizontal: 14,
    paddingBottom: 8,
    zIndex: 1,
  },
  exploreSearchHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  exploreHeaderMetaPill: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    minHeight: 40,
  },
  exploreHeaderMetaInner: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    zIndex: 1,
  },
  exploreHeaderMetaTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  exploreHeaderMetaPrimary: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: -0.1,
    flexShrink: 1,
    minWidth: 0,
  },
  exploreHeaderMetaEta: {
    color: SKY,
    fontSize: 12,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  onlineProsMapBadgeWrap: {
    position: 'absolute',
    top: 12,
    right: 14,
    zIndex: 900,
  },
  onlineProsMapBadge: {
    borderRadius: 999,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(8,20,38,0.62)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.22,
    shadowRadius: 6,
    elevation: 6,
  },
  onlineProsMapBadgeInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingLeft: 8,
    paddingRight: 10,
    paddingVertical: 6,
    zIndex: 1,
  },
  onlineProsMapIconWrap: {
    width: 22,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  onlineProsMapPulse: {
    position: 'absolute',
    right: -1,
    top: -1,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#34D399',
  },
  onlineProsMapLiveDot: {
    position: 'absolute',
    right: 0,
    top: 0,
    width: 8,
    height: 8,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(8,20,38,0.95)',
    zIndex: 1,
  },
  onlineProsMapCount: {
    color: '#F8FAFC',
    fontSize: 13,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    minWidth: 12,
    textAlign: 'center',
  },
  exploreSheetSearchWrap: {
    flexShrink: 0,
    paddingHorizontal: EXPLORE_SHEET_H_INSET,
    paddingTop: 10,
    paddingBottom: 10,
    zIndex: 4,
  },
  exploreSheetSearchPill: {
    minHeight: 46,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.62)',
  },
  exploreSheetSearchPillCool: {
    borderColor: 'rgba(125,211,252,0.28)',
  },
  exploreMapGlassSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.85,
  },
  exploreSearchPill: {
    flex: 1,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  exploreSearchPillInner: {
    minHeight: 46,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    zIndex: 1,
  },
  exploreSearchInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: Platform.OS === 'ios' ? 0 : 2,
    minHeight: 22,
  },
  searchPinWrap: { alignItems: 'center', justifyContent: 'center' },
  searchPinBubble: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    elevation: 6,
  },
  searchPinStem: {
    width: 3,
    height: 8,
    marginTop: -1,
    backgroundColor: '#fff',
    borderRadius: 2,
  },
  mapDialBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 899,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  mapExploreFabAnchor: {
    position: 'absolute',
    right: 16,
    zIndex: 910,
    minHeight: 44,
  },
  mapDialSatelliteWrap: {
    position: 'absolute',
    left: 0,
    zIndex: 2,
  },
  mapFabBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    zIndex: 3,
  },
  mapFabPairBtn: { position: 'relative' },
  mapFiltersFab: {
    width: 44,
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.58)',
    backgroundColor: 'rgba(8,20,38,0.68)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.24,
    shadowRadius: 8,
    elevation: 6,
  },
  mapDialFabActive: {
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.75)',
    backgroundColor: 'rgba(135,206,235,0.18)',
  },
  mapFilterFabDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.9)',
  },
  filterSheetRoot: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  filterSheetInner: {
    width: '100%',
  },
  filterSheetTitleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 6,
    zIndex: 1,
  },
  filterSheetTitleText: { flex: 1, minWidth: 0 },
  filterSheetSubtitleTight: { marginBottom: 0 },
  filterSheetScrollContent: { paddingBottom: 12, flexGrow: 1 },
  filterModeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 14,
    justifyContent: 'space-between',
  },
  filterModeIconBtn: {
    flex: 1,
    minWidth: 96,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 6,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  filterModeIconBtnActive: {
    borderColor: 'rgba(135,206,235,0.55)',
    backgroundColor: 'rgba(135,206,235,0.16)',
  },
  filterModeIconLabel: {
    marginTop: 6,
    fontSize: 10,
    fontWeight: '800',
    color: 'rgba(226,232,240,0.75)',
    textAlign: 'center',
  },
  filterModeIconLabelActive: { color: '#E0F2FE' },
  filterModalFavouritesHint: {
    fontSize: 13,
    lineHeight: 19,
    color: 'rgba(148,163,184,0.92)',
    marginBottom: 12,
  },
  filterModalSectionLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: 'rgba(249,250,251,0.55)',
    marginBottom: 8,
    marginTop: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  filterModalRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  sheetOuter: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  sheetKeyboardAvoid: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
  },
  /** Filters modal + legacy — aligned with tracking sheet padding. */
  locationBottomSheet: {
    flex: 1,
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    overflow: 'hidden',
    paddingHorizontal: 20,
    borderWidth: 1,
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  /** Main explore sheet — same glass stack as booking vehicle step. */
  exploreVehicleBottomSheet: {
    flex: 1,
    width: '100%',
    paddingTop: 4,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  exploreSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 1,
  },
  exploreSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  /** Filter modal drag affordance */
  sheetHandle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
    backgroundColor: 'rgba(125,211,252,0.55)',
  },
  exploreMapSheetHeader: { marginBottom: 4 },
  exploreMapSheetHeaderRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 2,
    paddingHorizontal: 14,
    zIndex: 1,
  },
  exploreMapSheetHeaderCompact: {
    marginBottom: 0,
    paddingTop: 0,
    justifyContent: 'center',
  },
  exploreMapSheetDotsOnly: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingBottom: 2,
  },
  exploreMapSheetHeaderText: { flex: 1, minWidth: 0 },
  sheetFiltersBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.58)',
    backgroundColor: 'rgba(8,20,38,0.68)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    flexShrink: 0,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.24,
    shadowRadius: 8,
    elevation: 6,
  },
  sheetFiltersBtnDot: {
    position: 'absolute',
    top: 7,
    right: 7,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.9)',
  },
  exploreMapSheetKicker: {
    fontSize: 10,
    fontWeight: '800',
    color: 'rgba(148,163,184,0.95)',
    letterSpacing: 1.6,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  exploreMapSheetTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: -0.5,
  },
  exploreMapSheetTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    marginBottom: 4,
  },
  exploreMapSheetTitleIndicators: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginLeft: 8,
  },
  exploreMapSheetHook: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(226,232,240,0.78)',
    lineHeight: 16,
  },
  exploreMapSearchOuter: {
    borderRadius: 16,
    marginTop: -10,
    marginBottom: 6,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.34)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 3,
  },
  exploreMapSearchInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 11,
    backgroundColor: 'rgba(10,16,28,0.55)',
  },
  exploreMapSearchInput: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600', paddingVertical: 0 },
  exploreMapSheetBody: { flex: 1, minHeight: 0, zIndex: 1, justifyContent: 'flex-end' },
  sheetHeaderTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', letterSpacing: -0.4 },
  sheetHeaderSubtitle: { fontSize: 11, color: 'rgba(249,250,251,0.58)', marginBottom: 8, letterSpacing: 0.15 },
  filterChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(8,20,38,0.5)',
  },
  filterChipActive: { borderColor: 'rgba(135,206,235,0.4)', backgroundColor: 'rgba(135,206,235,0.16)' },
  filterChipText: { fontSize: 11, fontWeight: '700', color: 'rgba(255,255,255,0.65)' },
  filterChipTextActive: { color: '#E0F2FE' },
  radiusSliderWrap: {
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.52)',
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 8,
    marginBottom: 10,
  },
  radiusSliderLabelsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  radiusSliderValue: {
    fontSize: 12,
    fontWeight: '800',
    color: '#E0F2FE',
  },
  radiusSliderHint: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(148,163,184,0.9)',
  },
  radiusSliderStopsRow: {
    marginTop: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  radiusSliderStopBtn: {
    paddingVertical: 4,
    paddingHorizontal: 6,
  },
  radiusSliderStopText: {
    fontSize: 10,
    fontWeight: '700',
    color: 'rgba(226,232,240,0.78)',
  },
  sheetContentWrap: { flexShrink: 0, marginTop: 0, paddingBottom: 2 },
  sheetCardsScrollWrap: { flexShrink: 0, justifyContent: 'flex-start', overflow: 'visible' },
  sheetCardsScrollWrapSingle: { justifyContent: 'center' },
  sheetHorizontalScroll: { flexGrow: 0, flexShrink: 0 },
  /** Same rhythm as `track.tsx` horizontal trip strip. */
  sheetCardsScrollContent: {
    paddingLeft: EXPLORE_SHEET_H_INSET,
    paddingRight: EXPLORE_SHEET_H_INSET,
    paddingTop: 8,
    paddingBottom: 4,
    alignItems: 'flex-start',
  },
  sheetCardsScrollContentTight: {
    paddingTop: 4,
  },
  sheetCardsScrollContentSingle: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingRight: 0,
  },
  cardScrollItem: { marginRight: EXPLORE_TRACK_CARD_GAP },
  cardScrollItemSingle: { marginRight: 0 },
  sheetFooter: { flexShrink: 0, marginTop: 10, paddingTop: 0, paddingHorizontal: 14, paddingBottom: 2 },
  selectedActionsRow: { marginTop: 0 },
  selectedPrimaryActionCard: {
    minHeight: 44,
    paddingVertical: 8,
    flex: 1.55,
    minWidth: 168,
  },
  indicatorDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.22)' },
  indicatorDotActive: { backgroundColor: SKY, width: 14 },
  /** Matches `track.tsx` `horizontalCard` — size, radius, shadow. */
  exploreTrackTripCard: {
    minHeight: 112,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(8,20,38,0.22)',
    alignSelf: 'stretch',
    shadowColor: 'rgba(56,189,248,0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.4)',
  },
  exploreTrackTripCardPad: { padding: 14, position: 'relative' },
  exploreTrackAccentRail: {
    position: 'absolute',
    left: 0,
    top: 12,
    bottom: 12,
    width: 3,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
    opacity: 0.95,
  },
  exploreTrackCardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  exploreTrackIconWrap: {
    width: 46,
    height: 46,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
  },
  exploreTrackIconOrb: {
    width: 34,
    height: 34,
    borderRadius: 11,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  exploreTrackAvatarImg: { width: 46, height: 46, borderRadius: 13 },
  exploreTrackCardMain: { flex: 1, minWidth: 0 },
  exploreTrackTopMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 3,
    gap: 8,
  },
  exploreTrackTopMetaRowEnd: {
    justifyContent: 'flex-end',
  },
  exploreTrackHeartInline: { zIndex: 2, padding: 2 },
  exploreTrackKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: 'rgba(186,230,253,0.92)',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  exploreTrackTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '900',
    marginBottom: 2,
    letterSpacing: 0.1,
  },
  exploreTrackSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 5,
  },
  exploreTrackStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  exploreTrackStatusDot: { width: 7, height: 7, borderRadius: 4 },
  exploreTrackStatusPillText: { fontSize: 12, fontWeight: '800' },
  exploreTrackCardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingTop: 8,
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  exploreTrackBottomMeta: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 },
  exploreTrackEtaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.56)',
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  exploreTrackEtaText: { color: SKY, fontSize: 11, fontWeight: '800' },
  exploreTrackHoursBtn: { padding: 4 },
  exploreSheetIconAction: {
    width: 40,
    height: 40,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(8,20,38,0.62)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.16,
    shadowRadius: 5,
    elevation: 3,
  },
  exploreSheetIconActionCcp: {
    shadowOpacity: 0.28,
  },
  markerOverlayRoot: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.42)',
  },
  markerOverlaySheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.34)',
    backgroundColor: 'rgba(8,20,38,0.9)',
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 16,
    gap: 10,
  },
  markerOverlayHandle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(125,211,252,0.55)',
    alignSelf: 'center',
    marginBottom: 2,
  },
  markerOverlayGalleryPlaceholder: {
    height: 120,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    gap: 4,
  },
  markerOverlayGalleryText: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 12,
    fontWeight: '700',
  },
  markerOverlayProfileCard: {
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    backgroundColor: 'rgba(15,23,42,0.6)',
    padding: 12,
    gap: 10,
  },
  markerOverlayProfileTop: { gap: 3 },
  markerOverlayType: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
  },
  markerOverlayTitle: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '900',
  },
  markerOverlayMeta: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },
  markerOverlayActions: { marginTop: 2 },
  teamSheetRoot: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.42)',
  },
  teamSheetPanel: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    borderBottomWidth: 0,
    backgroundColor: 'transparent',
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 18,
    minHeight: 460,
    overflow: 'hidden',
  },
  teamSheetBlur: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  teamSheetDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.2)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  teamSheetGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 8,
    elevation: 4,
  },
  teamSheetHandle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 8,
    backgroundColor: 'rgba(125,211,252,0.55)',
  },
  teamSheetKicker: {
    color: 'rgba(186,230,253,0.9)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  teamSheetTitle: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '900',
    marginTop: 2,
  },
  teamSheetSubtitle: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
    marginBottom: 8,
  },
  teamTrustRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 10,
  },
  teamTrustPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
    borderRadius: 999,
    backgroundColor: 'rgba(8,20,38,0.58)',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  teamTrustText: {
    color: '#E0F2FE',
    fontSize: 10,
    fontWeight: '700',
  },
  teamSheetCards: {
    gap: 10,
    paddingRight: 14,
    paddingBottom: 8,
  },
  teamCard: {
    width: 238,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(15,23,42,0.56)',
    padding: 12,
    alignItems: 'center',
    gap: 6,
    minHeight: 220,
  },
  teamAvatar: {
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.42)',
    backgroundColor: 'rgba(2,6,23,0.62)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  teamAvatarImg: { width: 56, height: 56, borderRadius: 18 },
  teamName: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '800',
  },
  teamMeta: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '600',
  },
  teamCardStatsRow: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  teamCardPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.35)',
    borderRadius: 999,
    backgroundColor: 'rgba(8,20,38,0.6)',
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  teamCardPillText: {
    color: '#E2E8F0',
    fontSize: 11,
    fontWeight: '700',
  },
  teamSpecs: {
    marginTop: 4,
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    textAlign: 'center',
  },
  teamEmptyCard: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(15,23,42,0.5)',
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  teamEmptyText: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 12,
    fontWeight: '600',
  },
  teamGalleryTitle: {
    marginTop: 10,
    color: 'rgba(186,230,253,0.9)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  teamGalleryRow: {
    gap: 8,
    paddingTop: 8,
    paddingBottom: 4,
  },
  teamGalleryImage: {
    width: 76,
    height: 76,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
  },
  teamGalleryPlaceholder: {
    width: 76,
    height: 76,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
    backgroundColor: 'rgba(8,20,38,0.58)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  teamGalleryPlaceholderText: {
    color: 'rgba(226,232,240,0.84)',
    fontSize: 10,
    fontWeight: '700',
    textAlign: 'center',
  },
  galleryPreviewRoot: {
    flex: 1,
    backgroundColor: 'rgba(2,6,23,0.62)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  galleryPreviewCard: {
    width: '100%',
    maxWidth: 320,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.35)',
    backgroundColor: 'rgba(8,20,38,0.92)',
    paddingVertical: 26,
    paddingHorizontal: 16,
    alignItems: 'center',
    gap: 8,
  },
  galleryPreviewTitle: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '800',
  },
  galleryPreviewSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },
  teamReviewsHeader: {
    marginTop: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  teamReviewsCount: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 11,
    fontWeight: '700',
  },
  teamReviewsRow: {
    gap: 10,
    paddingTop: 8,
    paddingBottom: 6,
    paddingRight: 14,
  },
  teamReviewCard: {
    width: 230,
    minHeight: 116,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.5)',
    padding: 10,
    gap: 6,
  },
  teamReviewTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  teamReviewHeadRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  teamReviewAvatar: {
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
    backgroundColor: 'rgba(2,6,23,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  teamReviewAvatarImg: {
    width: 30,
    height: 30,
    borderRadius: 15,
  },
  teamReviewAvatarFallback: {
    color: '#E0F2FE',
    fontSize: 11,
    fontWeight: '800',
  },
  teamReviewMetaWrap: {
    flex: 1,
    gap: 2,
  },
  teamReviewAuthor: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 12,
    fontWeight: '800',
  },
  teamReviewWhen: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '700',
  },
  teamReviewRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  teamReviewRatingText: {
    color: '#E2E8F0',
    fontSize: 11,
    fontWeight: '800',
  },
  teamReviewText: {
    color: 'rgba(226,232,240,0.9)',
    fontSize: 11,
    fontWeight: '600',
    lineHeight: 16,
  },
  emptySheetBody: { flexShrink: 0, minHeight: 0, paddingTop: 8, paddingBottom: 4 },
  emptySheetFilterRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  emptySheetState: {
    minHeight: 220,
    justifyContent: 'flex-start',
    paddingTop: 8,
    paddingBottom: 8,
  },
  markerOuter: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerOuterSelected: {},
  markerGlow: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(125,211,252,0.22)',
    borderWidth: 2,
    borderColor: 'rgba(125,211,252,0.45)',
  },
  markerGlowActive: {
    backgroundColor: 'rgba(125,211,252,0.45)',
    borderColor: SKY,
    borderWidth: 3,
  },
  valeterMarkerSelectedGlow: {
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 15,
    shadowOpacity: 0.6,
    elevation: 8,
  },
  userLocationMarkerWrap: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userLocationPulseRing: {
    position: 'absolute',
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(56,189,248,0.35)',
    borderWidth: 1.5,
    borderColor: 'rgba(125,211,252,0.9)',
  },
  userLocationCoreDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#38BDF8',
    borderWidth: 2,
    borderColor: '#E0F2FE',
  },
  userLocationInnerDot: {
    position: 'absolute',
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#FFFFFF',
  },
  markerCore: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(15,23,42,0.92)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerCoreSelected: { backgroundColor: SKY, borderColor: '#fff' },
});
