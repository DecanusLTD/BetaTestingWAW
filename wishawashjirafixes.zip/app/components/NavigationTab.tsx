import React, { useLayoutEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
  Image,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { WWSheetCloseButton } from '../../src/components/ui';
import GradientIconBox from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import BookingMapGlassBackground, {
  BOOKING_MAP_GLASS_SHELL_BG,
} from '../../src/components/booking/BookingMapGlassBackground';
import { HEADER_STYLE_CARD_BORDER } from '../../src/constants/bookingCardTheme';
import { useMapChromeColors } from '../../src/hooks/useMapChromeColors';
import { useTabBarInsetSetter } from '../../src/contexts/TabBarInsetContext';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';

const TAB_BAR_HEIGHT = 58;
/** barWrapper vertical padding (6+6) + pill row minHeight 52 — matches tab cluster height. */
const TAB_BAR_ROW_BODY_HEIGHT = 64;
// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT;
export { TAB_BAR_TOTAL_HEIGHT };

/** Bottom inset for the main Stack so scroll content is clipped above the floating tab (see RootLayout). */
export function computeTabBarBottomReserve(insetsBottom: number, tabVisible: boolean): number {
  if (!tabVisible) return 0;
  const bottomPad = Math.max(insetsBottom, 10) + 8;
  return bottomPad + TAB_BAR_ROW_BODY_HEIGHT;
}

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

/** Set to true when live tracking should appear in the bottom tab bar again. */
const TRACKING_TAB_IN_TAB_BAR = false;

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      ...(TRACKING_TAB_IN_TAB_BAR
        ? ([{ name: 'Track', icon: 'navigate' as const, route: '/valeter/jobs/tracking' }] satisfies Tab[])
        : []),
      { name: 'Earnings', icon: 'wallet', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Inbox', icon: 'chatbubbles', route: '/owner/inbox' },
    ...(TRACKING_TAB_IN_TAB_BAR
      ? ([{ name: 'Track', icon: 'navigate' as const, route: '/owner/track' }] satisfies Tab[])
      : []),
    { name: 'Activity', icon: 'time', route: '/owner/wash-history' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

function findTabIndex(tabs: Tab[], predicate: (t: Tab) => boolean): number {
  const idx = tabs.findIndex(predicate);
  return Math.max(0, idx);
}

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    return findTabIndex(tabs, (t) => t.route.includes('/booking'));
  }
  if (pathname.includes('/owner/inbox')) {
    return findTabIndex(tabs, (t) => t.route === '/owner/inbox');
  }
  if (pathname.includes('/track')) {
    const trackIdx = tabs.findIndex((t) => t.route === '/owner/track' || t.route === '/valeter/jobs/tracking');
    if (trackIdx >= 0) return trackIdx;
    if (pathname.includes('/valeter/')) {
      return findTabIndex(tabs, (t) => t.route === '/valeter/jobs/queue');
    }
    return findTabIndex(tabs, (t) => t.route === '/owner/owner-dashboard');
  }
  if (pathname.includes('/rewards')) {
    return findTabIndex(tabs, (t) => t.route === '/rewards' || t.route.includes('rewards'));
  }
  if (pathname.includes('/valeter/jobs/')) {
    const isJobTracking =
      pathname.includes('/valeter/jobs/tracking') ||
      pathname.includes('/valeter/jobs/accept') ||
      pathname.includes('/valeter/jobs/complete');
    if (isJobTracking) {
      const ti = tabs.findIndex((t) => t.route === '/valeter/jobs/tracking');
      if (ti >= 0) return ti;
    }
    return findTabIndex(tabs, (t) => t.route === '/valeter/jobs/queue');
  }
  if (pathname.includes('/valeter/valeter-wash-history')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/valeter-wash-history');
  }
  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/profile/valeter-profile');
  }
  const businessRoutes = ['/business/dashboard', '/business/locations', '/business/bookings', '/business/team', '/business/profile'] as const;
  for (const route of businessRoutes) {
    if (pathname.includes(route)) return findTabIndex(tabs, (t) => t.route === route);
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }
  return 0;
};

// Separate component for tab items to allow hooks inside
function TabItem({
  tab,
  isActive,
  glowAnim,
  onPress,
  profilePictureUri,
}: Readonly<{
  tab: Tab;
  isActive: boolean;
  glowAnim: SharedValue<number>;
  onPress: () => void;
  profilePictureUri?: string | null;
}>) {
  const chrome = useMapChromeColors();
  const showProfileImage = false;
  const iconName = isActive ? tab.icon : (`${tab.icon}-outline` as keyof typeof Ionicons.glyphMap);

  const glowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: 1 + glowAnim.value * 0.06 }],
  }));

  return (
    <TouchableOpacity
      style={styles.tab}
      onPress={onPress}
      activeOpacity={isActive ? 1 : 0.7}
      disabled={isActive}
      accessibilityRole="tab"
      accessibilityLabel={isActive ? `${tab.name}, selected` : tab.name}
      accessibilityState={{ selected: isActive }}
      accessibilityHint={isActive ? undefined : `Switch to ${tab.name}`}
    >
      <Animated.View style={glowStyle}>
        {showProfileImage && profilePictureUri ? (
          <Image
            source={{ uri: profilePictureUri }}
            style={styles.profileTabImage}
            resizeMode="cover"
          />
        ) : (
          <View
            style={[
              styles.tabIconChrome,
              isActive
                ? {
                    borderColor: chrome.border,
                    shadowColor: chrome.shadow,
                  }
                : styles.tabIconChromeIdle,
            ]}
          >
            {isActive ? (
              <>
                <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                <LinearGradient
                  colors={[...chrome.gradient]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
                <LinearGradient
                  colors={['rgba(255,255,255,0.14)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={styles.tabIconSheen}
                  pointerEvents="none"
                />
              </>
            ) : null}
            <Ionicons
              name={iconName as never}
              size={22}
              color={isActive ? chrome.icon : 'rgba(148,163,184,0.55)'}
              style={styles.icon}
            />
          </View>
        )}
      </Animated.View>
    </TouchableOpacity>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const defaultAccent = theme.primary || colors.navActive || colors.SKY;

  // Store glow animations for each tab - initialize with max 5 tabs
  const glowAnim0 = useSharedValue(0);
  const glowAnim1 = useSharedValue(0);
  const glowAnim2 = useSharedValue(0);
  const glowAnim3 = useSharedValue(0);
  const glowAnim4 = useSharedValue(0);
  const glowAnimations = [glowAnim0, glowAnim1, glowAnim2, glowAnim3, glowAnim4];

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
      '/owner/booking',
      '/owner/explore',
      '/owner/booking-confirm',
      '/owner/track',
      '/valeter/jobs/accept',
      '/valeter/jobs/tracking',
      '/valeter/jobs/complete',
    ];
    return hideRoutes.some((route) => pathname.includes(route));
  }, [pathname]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';

  const setTabBarReserve = useTabBarInsetSetter();
  const tabBottomReserve = computeTabBarBottomReserve(insets.bottom, !shouldHideTab);
  useLayoutEffect(() => {
    setTabBarReserve(tabBottomReserve);
  }, [tabBottomReserve, setTabBarReserve]);

  if (shouldHideTab) {
    return <View style={styles.hidden} />;
  }

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View style={styles.barContainer}>
        <View
          style={[
            styles.barWrapper,
            { paddingBottom: Math.max(insets.bottom, 10) },
          ]}
        >
          <BookingMapGlassBackground />
          {tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const isProfile = isProfileTab(tab);
            const glowAnim = glowAnimations[index] || glowAnim0;

            const handleTabPress = async () => {
              if (isActive) return;
              glowAnim.value = withTiming(1, { duration: 200 }, () => {
                glowAnim.value = withTiming(0, { duration: 300 });
              });
              if (isProfile && isBusinessRoute) {
                await hapticFeedback('light');
                setShowProfileActions(true);
              } else {
                await hapticFeedback('light');
                router.push(tab.route as any);
              }
            };

            return (
              <View key={tab.route} style={styles.individualPill}>
                <TabItem
                  tab={tab}
                  isActive={isActive}
                  glowAnim={glowAnim}
                  onPress={handleTabPress}
                  profilePictureUri={
                    isProfileTab(tab) ? (user?.profilePicture ?? null) : null
                  }
                />
              </View>
            );
          })}
        </View>
      </View>

      <Modal
        visible={showProfileActions}
        transparent
        animationType="fade"
        onRequestClose={() => setShowProfileActions(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={[
              styles.actionSheet,
              isBusinessRoute && {
                backgroundColor: theme.background?.[0] || 'rgba(15, 23, 42, 0.95)',
                borderColor: `${theme.primary}55`,
              },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.actionSheetHeader}>
              <Text style={[styles.actionSheetTitle, isBusinessRoute && { color: theme.primary }]}>
                Profile Options
              </Text>
              <WWSheetCloseButton
                size={34}
                iconSize={22}
                iconColor={defaultAccent}
                onPress={() => setShowProfileActions(false)}
                accessibilityLabel="Close profile options"
              />
            </View>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/profile' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={styles.actionSheetIconWrapper}>
                <GradientIconBox
                  icon="person"
                  colors={accentToGradient(String(defaultAccent))}
                  boxSize={38}
                  size={20}
                  elevated
                />
              </View>
              <Text style={styles.actionSheetItemText}>Business Profile</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/settings' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={styles.actionSheetIconWrapper}>
                <GradientIconBox
                  icon="settings"
                  colors={accentToGradient(String(defaultAccent))}
                  boxSize={38}
                  size={20}
                  elevated
                />
              </View>
              <Text style={styles.actionSheetItemText}>Settings</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'stretch',
    justifyContent: 'flex-end',
    zIndex: 9999,
    elevation: 0,
  },
  barContainer: {
    width: '100%',
    alignSelf: 'stretch',
    alignItems: 'stretch',
    justifyContent: 'center',
    zIndex: 1,
    position: 'relative',
  },
  barWrapper: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    alignSelf: 'stretch',
    paddingHorizontal: 10,
    paddingTop: 8,
    borderRadius: 0,
    overflow: 'hidden',
    gap: 6,
    backgroundColor: BOOKING_MAP_GLASS_SHELL_BG,
    borderTopWidth: 1,
    borderTopColor: HEADER_STYLE_CARD_BORDER,
    shadowColor: 'rgba(8,20,38,0.9)',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.38,
    shadowRadius: 18,
    elevation: 14,
  },
  individualPill: {
    flex: 1,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },

  tabIconChrome: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  tabIconChromeIdle: {
    borderColor: 'rgba(148,196,220,0.22)',
    backgroundColor: 'rgba(8,20,38,0.42)',
    shadowOpacity: 0,
    elevation: 0,
  },
  tabIconSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.85,
  },

  icon: {
    zIndex: 1,
  },

  profileTabImage: {
    width: 42,
    height: 42,
    borderRadius: 21,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 16,
    paddingBottom: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    marginBottom: 8,
  },

  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
  },

  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    gap: 14,
  },

  actionSheetIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },

  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
  },
  hidden: {
    position: 'absolute',
    width: 0,
    height: 0,
  },
});
