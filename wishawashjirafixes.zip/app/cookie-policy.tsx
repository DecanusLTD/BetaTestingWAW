import React from 'react';
import { View, Text } from 'react-native';
import { useAuth } from '../src/providers/enhanced-auth-context';
import PolicyScreen, { policyScreenStyles } from '../src/components/shared/PolicyScreen';
import type { PolicySection } from '../src/components/shared/PolicyScreen';
import { INFO_EMAIL } from '../src/constants/contactEmails';

function getAccountType(userType: string | undefined): 'customer' | 'valeter' | 'business' {
  if (userType === 'valeter') return 'valeter';
  if (userType === 'organization') return 'business';
  return 'customer';
}

export default function CookiePolicy() {
  const { user } = useAuth();
  const accountType = getAccountType(user?.userType);

  const sections: PolicySection[] = [
    {
      title: '1. What Are Cookies?',
      icon: 'information-circle',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          Cookies are small text files that are placed on your device when you visit our app. They help us provide you with a better experience by remembering your preferences and understanding how you use our services.
        </Text>
      ),
    },
    {
      title: '2. Types of Cookies We Use',
      icon: 'list',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>We use the following types of cookies:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Essential Cookies:</Text> Required for the app to function properly, including authentication and security features</Text>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Functional Cookies:</Text> Remember your preferences and settings to enhance your experience</Text>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Analytics Cookies:</Text> Help us understand how users interact with our app to improve performance</Text>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Performance Cookies:</Text> Monitor app performance and identify technical issues</Text>
          </View>
        </>
      ),
    },
    {
      title: '3. How We Use Cookies',
      icon: 'settings',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>We use cookies to:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Keep you signed in and maintain your session</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Remember your location preferences and vehicle information</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Store your booking history and preferences</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Analyse app usage to improve our services</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Ensure app security and prevent fraud</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Personalise your experience based on your usage patterns</Text>
          </View>
        </>
      ),
    },
    {
      title: '4. Cookie Duration',
      icon: 'time-outline',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>Cookies may be either "session" cookies or "persistent" cookies:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Session Cookies:</Text> Temporary cookies that expire when you close the app</Text>
            <Text style={policyScreenStyles.bulletPoint}>• <Text style={policyScreenStyles.bulletBold}>Persistent Cookies:</Text> Remain on your device for a set period or until you delete them</Text>
          </View>
        </>
      ),
    },
    {
      title: '5. Third-Party Cookies',
      icon: 'shield-checkmark',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>We may use third-party services that set their own cookies, including:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Payment processors (Stripe) for secure payment handling</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Analytics services to understand app performance</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Location services for accurate service delivery</Text>
          </View>
          <Text style={[policyScreenStyles.sectionText, { marginTop: 12 }]}>
            These third parties have their own privacy policies and cookie practices.
          </Text>
        </>
      ),
    },
    {
      title: '6. Managing Cookies',
      icon: 'options',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>You can control and manage cookies through:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Your device settings to clear or block cookies</Text>
            <Text style={policyScreenStyles.bulletPoint}>• App settings within your account preferences</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Browser settings if accessing via web</Text>
          </View>
          <Text style={[policyScreenStyles.sectionText, { marginTop: 12 }]}>
            Please note that disabling certain cookies may affect app functionality and your user experience.
          </Text>
        </>
      ),
    },
    {
      title: '7. UK GDPR Compliance',
      icon: 'globe-outline',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          We comply with UK GDPR and the Privacy and Electronic Communications Regulations (PECR). We only use cookies that are necessary for the app to function or where we have your consent for non-essential cookies.
        </Text>
      ),
    },
    {
      title: '8. Contact Us',
      icon: 'mail-outline',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          If you have questions about our use of cookies, please contact us through the app's support section or email {INFO_EMAIL}.
        </Text>
      ),
    },
  ];

  return (
    <PolicyScreen
      title="Cookie Policy"
      headerIcon="document-text-outline"
      accountType={accountType}
      sections={sections}
    />
  );
}
