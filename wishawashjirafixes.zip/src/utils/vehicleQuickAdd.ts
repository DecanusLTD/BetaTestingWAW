import { supabase } from '../lib/supabase';
import dvlaService from '../services/DVLAService';
import { getVehicleSize } from '../pricing/pricingEngine';

export function cleanVehicleReg(input: string): string {
  return input.replace(/\s/g, '').toUpperCase();
}

type QuickAddResult =
  | { ok: true; vehicleId: string }
  | { ok: false; message: string };

function toStoredVehicleSize(size: ReturnType<typeof getVehicleSize>): 'small' | 'medium' | 'large' | 'xl' | 'xxl' {
  switch (size) {
    case 'SMALL':
      return 'small';
    case 'LARGE':
      return 'large';
    case 'XL':
      return 'xl';
    case 'XXL':
      return 'xxl';
    default:
      return 'medium';
  }
}

/**
 * DVLA lookup + insert into `customer_vehicles` for inline booking flow.
 */
export async function addVehicleByRegistration(params: {
  userId: string;
  registration: string;
  isFirstVehicle: boolean;
}): Promise<QuickAddResult> {
  const reg = cleanVehicleReg(params.registration);
  const validation = dvlaService.validateRegistration(reg);
  if (!validation.isValid) {
    return { ok: false, message: validation.error ?? 'Invalid registration number' };
  }

  const result = await dvlaService.getVehicleDetails(reg);
  if (!result.success || !result.data) {
    return { ok: false, message: result.error ?? 'Could not find that vehicle. Check the registration and try again.' };
  }

  const data = result.data;
  const make = (data.make || '').trim();
  if (!make) {
    return { ok: false, message: 'Vehicle details were incomplete. Try again or add from Settings.' };
  }

  const model = (data.model || '').trim();
  const color = (data.colour || '').trim();
  const type = dvlaService.inferVehicleType(make, model);
  const size = toStoredVehicleSize(getVehicleSize({ make, model, type }));

  const payload = {
    user_id: params.userId,
    type: type || 'Car',
    make,
    model: model || null,
    color,
    registration: data.registrationNumber ? cleanVehicleReg(data.registrationNumber) : reg,
    size,
    mot_status: data.motStatus ?? null,
    mot_expiry_date: data.motExpiryDate ?? null,
    tax_status: data.taxStatus ?? null,
    tax_due_date: data.taxDueDate ?? null,
    dvla_last_checked_at: new Date().toISOString(),
    is_default: params.isFirstVehicle,
  };

  const { data: inserted, error } = await supabase
    .from('customer_vehicles')
    .insert(payload)
    .select('id')
    .single();

  if (error) {
    return { ok: false, message: error.message || 'Failed to save vehicle' };
  }

  return { ok: true, vehicleId: inserted.id as string };
}
