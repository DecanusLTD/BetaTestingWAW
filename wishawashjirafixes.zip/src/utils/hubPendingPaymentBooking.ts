import { supabase } from '../lib/supabase';
import { syncBookingToDeviceCalendar } from '../services/BookingCalendarSync';
import type { Hub } from '../types/booking';
import { getActiveBookingForCustomer } from './activeBookingGuard';

const BOOKING_CUSTOMER_COL = 'user_id';

export class ActiveBookingBlockedError extends Error {
  readonly activeBookingId: string;

  constructor(activeBookingId: string) {
    super('ACTIVE_BOOKING');
    this.name = 'ActiveBookingBlockedError';
    this.activeBookingId = activeBookingId;
  }
}

export type HubBookingService = { id: string; name: string };

type LocationServiceNameRow = { id: string; service_name: string };

function isServiceUuid(serviceId: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(serviceId);
}

/** Resolve wash/detail service for insert: catalog slug first, then `location_services` row by UUID. */
export async function resolveHubServiceForBookingInsert(
  serviceId: string | undefined,
  catalog: ReadonlyArray<{ id: string; name: string }>
): Promise<HubBookingService | null> {
  if (!serviceId) return null;
  const catalogHit = catalog.find((o) => o.id === serviceId);
  if (catalogHit) return { id: catalogHit.id, name: catalogHit.name };
  if (!isServiceUuid(serviceId)) return null;

  const { data, error } = await supabase
    .from('location_services')
    .select('id, service_name')
    .eq('id', serviceId)
    .maybeSingle();

  if (error || !data) return null;
  const row = data as LocationServiceNameRow;
  return { id: row.id, name: row.service_name };
}

/** When `serviceRow` is already loaded (schedule screens), avoid an extra query. */
export function resolveHubServiceFromParams(
  serviceId: string | undefined,
  serviceRow: LocationServiceNameRow | null | undefined,
  catalog: ReadonlyArray<{ id: string; name: string }>
): HubBookingService | null {
  if (!serviceId) return null;
  const catalogHit = catalog.find((o) => o.id === serviceId);
  if (catalogHit) return { id: catalogHit.id, name: catalogHit.name };
  if (serviceRow && serviceRow.id === serviceId) {
    return { id: serviceRow.id, name: serviceRow.service_name };
  }
  return null;
}

export async function fetchCarWashHub(locationId: string): Promise<Hub | null> {
  const { data, error } = await supabase
    .from('car_wash_locations')
    .select('id,name,address,latitude,longitude')
    .eq('id', locationId)
    .maybeSingle();

  if (error || !data) return null;
  const row = data as {
    id: string;
    name: string | null;
    address: string | null;
    latitude: number | null;
    longitude: number | null;
  };
  return {
    id: row.id,
    name: row.name ?? '',
    address: row.address,
    latitude: row.latitude,
    longitude: row.longitude,
  };
}

export function locationRowToHub(
  loc: { id: string; name: string | null; address: string | null; latitude?: number; longitude?: number } | null
): Hub | null {
  if (!loc) return null;
  return {
    id: loc.id,
    name: loc.name ?? '',
    address: loc.address,
    latitude: loc.latitude ?? null,
    longitude: loc.longitude ?? null,
  };
}

export async function createHubPendingPaymentBooking(args: {
  userId: string;
  vehicleId: string;
  vehicleIds?: string[];
  vehicleInfo?: string | null;
  vehicleType?: string | null;
  hub: Hub;
  service: HubBookingService;
  price: number;
  washType: string | null | undefined;
  scheduledAt: string;
}): Promise<string> {
  const active = await getActiveBookingForCustomer(args.userId);
  if (active) {
    throw new ActiveBookingBlockedError(active.id);
  }

  const insertPayload: Record<string, unknown> = {
    [BOOKING_CUSTOMER_COL]: args.userId,
    vehicle_id: args.vehicleId,
    location_id: args.hub.id,
    service_type: args.service.id,
    service_name: args.service.name,
    price: args.price,
    wash_type: args.washType ?? null,
    status: 'pending_payment',
    scheduled_at: args.scheduledAt,
    location_address: args.hub.address,
    location_lat: args.hub.latitude,
    location_lng: args.hub.longitude,
  };

  if (args.vehicleInfo) insertPayload.vehicle_info = args.vehicleInfo;
  if (args.vehicleType) insertPayload.vehicle_type = args.vehicleType;

  const { data, error } = await supabase.from('bookings').insert(insertPayload).select('id').single();

  if (error) throw error;

  void syncBookingToDeviceCalendar({
    id: data.id,
    serviceName: args.service.name,
    serviceType: args.service.id,
    address: args.hub.address ?? null,
    scheduledAt: args.scheduledAt,
  });

  return data.id as string;
}
