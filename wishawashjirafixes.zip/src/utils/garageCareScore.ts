import type { VehicleStats } from './vehicleStats';
import {
  getVehicleDocComplianceState,
  getWorstVehicleComplianceState,
  COMPLIANCE_EXPIRED,
  COMPLIANCE_WARNING,
  COMPLIANCE_GOOD,
  type VehicleDocComplianceState,
} from './vehicleComplianceStatus';

type VehicleCompliance = {
  mot_status?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
};

function scoreFromComplianceState(state: VehicleDocComplianceState): number {
  if (state === 'good') return 34;
  if (state === 'warning') return 18;
  if (state === 'expired') return 4;
  return 18;
}

function washScore(stats?: VehicleStats | null): number {
  if (!stats) return 12;
  let score = 8;
  if (stats.washCount > 0) score += Math.min(12, stats.washCount * 2);
  if (stats.lastCleanedAt) {
    const days = Math.floor(
      (Date.now() - new Date(stats.lastCleanedAt).getTime()) / (1000 * 60 * 60 * 24)
    );
    if (days <= 14) score += 18;
    else if (days <= 30) score += 12;
    else if (days <= 60) score += 6;
  }
  return Math.min(32, score);
}

export function computeGarageCareScore(vehicle: VehicleCompliance, stats?: VehicleStats | null): number {
  const mot = scoreFromComplianceState(
    getVehicleDocComplianceState(vehicle.mot_status, vehicle.mot_expiry_date)
  );
  const tax = scoreFromComplianceState(
    getVehicleDocComplianceState(vehicle.tax_status, vehicle.tax_due_date)
  );
  const wash = washScore(stats);
  return Math.min(100, Math.max(0, Math.round(mot + tax + wash)));
}

/** Ring colour reflects worst MOT/tax state, then wash score. */
export function careScoreColor(score: number, vehicle?: VehicleCompliance): string {
  if (vehicle) {
    const worst = getWorstVehicleComplianceState(vehicle);
    if (worst === 'expired') return COMPLIANCE_EXPIRED;
    if (worst === 'warning') return COMPLIANCE_WARNING;
    if (worst === 'good') return COMPLIANCE_GOOD;
  }
  if (score >= 80) return COMPLIANCE_GOOD;
  if (score >= 55) return '#38BDF8';
  if (score >= 35) return COMPLIANCE_WARNING;
  return COMPLIANCE_EXPIRED;
}

export function formatLastWashLabel(stats?: VehicleStats | null): string {
  if (!stats?.lastCleanedAt) {
    return stats?.washCount ? `${stats.washCount} washes logged` : 'No washes yet';
  }
  const days = Math.floor(
    (Date.now() - new Date(stats.lastCleanedAt).getTime()) / (1000 * 60 * 60 * 24)
  );
  if (days <= 0) return 'Washed today';
  if (days === 1) return 'Washed yesterday';
  return `Last wash ${days}d ago`;
}
