/** MOT / road tax compliance — green valid, orange expiring soon, red expired. */
export type VehicleDocComplianceState = 'good' | 'warning' | 'expired' | 'unknown';

export const COMPLIANCE_GOOD = '#34D399';
export const COMPLIANCE_WARNING = '#F59E0B';
export const COMPLIANCE_EXPIRED = '#EF4444';

/** Days before expiry to show orange “running out” state. */
export const COMPLIANCE_WARNING_DAYS = 30;

export function getDaysUntilExpiry(dateOnly: string | null | undefined): number | null {
  if (!dateOnly) return null;
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  return Math.ceil((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

function statusIndicatesExpired(status: string): boolean {
  if (!status) return false;
  const s = status.toLowerCase();
  if (s.includes('expired') || s.includes('untaxed') || s.includes('sorn')) return true;
  if (s.includes('not valid') || s.includes('not taxed') || s.includes('no mot')) return true;
  if (s === 'untaxed') return true;
  return false;
}

function statusIndicatesValid(status: string): boolean {
  if (!status) return false;
  const s = status.toLowerCase();
  if (statusIndicatesExpired(status)) return false;
  if (s.includes('valid') || s.includes('taxed') || s.includes('in force')) return true;
  return false;
}

export function getVehicleDocComplianceState(
  status?: string | null,
  expiryDate?: string | null
): VehicleDocComplianceState {
  const s = String(status ?? '').trim();
  const daysUntil = getDaysUntilExpiry(expiryDate);

  if (statusIndicatesExpired(s)) return 'expired';
  if (daysUntil !== null && daysUntil < 0) return 'expired';

  if (daysUntil !== null && daysUntil <= COMPLIANCE_WARNING_DAYS) return 'warning';

  if (statusIndicatesValid(s)) return 'good';

  return 'unknown';
}

export function getComplianceAccent(state: VehicleDocComplianceState): string {
  if (state === 'good') return COMPLIANCE_GOOD;
  if (state === 'warning') return COMPLIANCE_WARNING;
  if (state === 'expired') return COMPLIANCE_EXPIRED;
  return '#94A3B8';
}

export function getComplianceExpiryHint(
  state: VehicleDocComplianceState,
  daysUntil: number | null
): string | null {
  if (daysUntil === null) return null;
  if (state === 'expired') {
    const overdue = Math.abs(daysUntil);
    return overdue === 0 ? 'Expired today' : `Expired ${overdue}d ago`;
  }
  if (state === 'warning') {
    return daysUntil === 0 ? 'Expires today' : `${daysUntil}d left`;
  }
  return null;
}

export type VehicleComplianceFields = {
  mot_status?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
};

export function getWorstVehicleComplianceState(vehicle: VehicleComplianceFields): VehicleDocComplianceState {
  const mot = getVehicleDocComplianceState(vehicle.mot_status, vehicle.mot_expiry_date);
  const tax = getVehicleDocComplianceState(vehicle.tax_status, vehicle.tax_due_date);
  if (mot === 'expired' || tax === 'expired') return 'expired';
  if (mot === 'warning' || tax === 'warning') return 'warning';
  if (mot === 'good' && tax === 'good') return 'good';
  return 'unknown';
}
