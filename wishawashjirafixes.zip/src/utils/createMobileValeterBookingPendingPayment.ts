import { findServiceOptionById } from '../constants/serviceOptions';
import { supabase } from '../lib/supabase';
import {
  getActivePlatformFeePercent,
  sumValeterBookingPriceForVehicles,
  type ValeterServiceSettingsRow,
} from '../services/ValeterPricingService';
import { syncBookingToDeviceCalendar } from '../services/BookingCalendarSync';
import { getActiveBookingForCustomer } from './activeBookingGuard';
import { formatBookingVehicleInfo } from './bookingVehicleSelection';
import { ActiveBookingBlockedError } from './hubPendingPaymentBooking';

export type CreateMobileValeterBookingInput = {
  userId: string;
  valeterId: string;
  vehicleId: string;
  vehicleIds?: string[];
  vehicleInfo?: string;
  serviceId: string;
  location: { latitude: number; longitude: number; address: string };
  washType?: string;
  addOnIds?: string;
  addOnsTotal?: number;
  discountAmount?: number;
  serviceBasePriceGBP?: number;
  customerOffersWater?: boolean;
  customerOffersElectricity?: boolean;
  scheduledAt?: string;
};

export async function createMobileValeterBookingPendingPayment(
  input: CreateMobileValeterBookingInput
): Promise<string> {
  const active = await getActiveBookingForCustomer(input.userId);
  if (active) {
    throw new ActiveBookingBlockedError(active.id);
  }

  const serviceOption = findServiceOptionById(input.serviceId);
  const serviceName = serviceOption?.name || input.serviceId;
  const bookingVehicleIds =
    input.vehicleIds && input.vehicleIds.length > 0
      ? input.vehicleIds
      : input.vehicleId
        ? [input.vehicleId]
        : [];
  const primaryVehicleId = bookingVehicleIds[0] || input.vehicleId;

  const [{ data: vehicleRows }, { data: settingsRow }, platformFeePercent] = await Promise.all([
    bookingVehicleIds.length > 0
      ? supabase
          .from('customer_vehicles')
          .select('id, type, make, model, size, registration')
          .in('id', bookingVehicleIds)
      : Promise.resolve({ data: [] as Array<{ id: string; type?: string; make?: string; model?: string; size?: string; registration?: string }> }),
    supabase
      .from('valeter_service_settings')
      .select('valeter_id, eco_washing, detailing_offered, detailing_menu, tier_pricing, repairs_offered, repair_menu')
      .eq('valeter_id', input.valeterId)
      .maybeSingle(),
    getActivePlatformFeePercent(),
  ]);

  const orderedVehicles = bookingVehicleIds
    .map((id) => (vehicleRows || []).find((row) => row.id === id))
    .filter(Boolean) as Array<{
    id: string;
    type?: string;
    make?: string;
    model?: string;
    size?: string;
    registration?: string;
  }>;

  const unitCatalogue = serviceOption?.price ?? 0;
  const totalCatalogueFallback =
    Number.isFinite(input.serviceBasePriceGBP) && (input.serviceBasePriceGBP ?? 0) > 0
      ? (input.serviceBasePriceGBP as number)
      : unitCatalogue * Math.max(1, orderedVehicles.length || 1);

  const settings = settingsRow as ValeterServiceSettingsRow | null;
  const resolvedPricing = sumValeterBookingPriceForVehicles({
    serviceId: input.serviceId,
    vehicles: orderedVehicles,
    washType: input.washType,
    fallbackUnitBasePrice: unitCatalogue,
    fallbackTotalBasePrice: totalCatalogueFallback,
    settings,
    platformFeePercent,
  });

  if (!resolvedPricing.available) {
    throw new Error('This valeter does not currently offer the selected service.');
  }

  const discountAmount = input.discountAmount ?? 0;
  const addOnsTotal = input.addOnsTotal ?? 0;
  const serviceTotal = resolvedPricing.basePrice + resolvedPricing.platformFeeAmount - discountAmount;
  const finalPrice = serviceTotal + addOnsTotal;
  const scheduledAt = input.scheduledAt ?? new Date().toISOString();
  const vehicleInfo =
    input.vehicleInfo ||
    formatBookingVehicleInfo(
      orderedVehicles.map((v) => ({
        id: v.id,
        make: v.make ?? 'Vehicle',
        model: v.model ?? '',
        ...(v.registration ? { registration: v.registration } : {}),
      })),
      bookingVehicleIds
    );

  const insertRow: Record<string, unknown> = {
    user_id: input.userId,
    valeter_id: input.valeterId,
    vehicle_id: primaryVehicleId,
    service_type: input.serviceId,
    service_name: serviceName,
    status: 'pending_payment',
    price: finalPrice,
    location_address: input.location.address,
    location_lat: input.location.latitude,
    location_lng: input.location.longitude,
    customer_offers_water: input.customerOffersWater ?? false,
    customer_offers_electricity: input.customerOffersElectricity ?? false,
    discount_amount: discountAmount,
    wash_type: input.washType ?? null,
    platform_fee_percent: resolvedPricing.platformFeePercent * 100,
    platform_fee_amount: resolvedPricing.platformFeeAmount,
    scheduled_at: scheduledAt,
  };

  if (vehicleInfo) insertRow.vehicle_info = vehicleInfo;
  if (orderedVehicles[0]?.type) insertRow.vehicle_type = orderedVehicles[0].type;

  if (input.addOnIds) insertRow.add_on_ids = input.addOnIds;
  if (addOnsTotal > 0) insertRow.add_ons_total = addOnsTotal;

  let result = await supabase.from('bookings').insert(insertRow).select('id').single();
  if (result.error && (result.error.message?.includes('add_on') || result.error.message?.includes('add_ons'))) {
    delete insertRow.add_on_ids;
    delete insertRow.add_ons_total;
    result = await supabase.from('bookings').insert(insertRow).select('id').single();
  }
  if (result.error) {
    throw new Error(result.error.message || 'Failed to create booking');
  }

  const bookingId = (result.data as { id: string }).id;

  void syncBookingToDeviceCalendar({
    id: bookingId,
    serviceName,
    serviceType: input.serviceId,
    address: input.location.address,
    scheduledAt,
  });

  return bookingId;
}
