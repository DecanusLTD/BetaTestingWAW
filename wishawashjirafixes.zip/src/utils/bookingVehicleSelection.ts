import {
  calculateDisplayPrice,
  getVehicleSize,
  mapServiceIdToWashId,
} from '../pricing/pricingEngine';

export type BookingVehicleRow = {
  id: string;
  make: string;
  model: string;
  registration?: string;
  color?: string;
  size?: string;
  type?: string;
};

export function parseBookingVehicleIdsParam(
  vehicleIdsParam?: string | null,
  vehicleId?: string | null
): string[] {
  const fromCsv = String(vehicleIdsParam || '')
    .split(',')
    .map((id) => id.trim())
    .filter(Boolean);
  if (fromCsv.length > 0) return fromCsv;
  if (vehicleId) return [vehicleId];
  return [];
}

export function toggleBookingVehicleId(current: string[], id: string): string[] {
  if (current.includes(id)) {
    if (current.length === 1) return current;
    return current.filter((x) => x !== id);
  }
  return [...current, id];
}

export function formatBookingVehicleInfo(
  vehicles: BookingVehicleRow[],
  vehicleIds: string[]
): string {
  return vehicleIds
    .map((id) => {
      const v = vehicles.find((row) => row.id === id);
      if (!v) return null;
      const reg = v.registration ? ` (${v.registration})` : '';
      return `${v.make} ${v.model}${reg}`.trim();
    })
    .filter(Boolean)
    .join(' · ');
}

export function formatBookingVehicleBanner(
  vehicles: BookingVehicleRow[],
  vehicleIds: string[]
): string {
  const selected = vehicles.filter((v) => vehicleIds.includes(v.id));
  if (selected.length === 0) return '';
  if (selected.length === 1) {
    const v = selected[0];
    return `${v.make} ${v.model}${v.registration ? ` · ${v.registration}` : ''}`;
  }
  return `${selected.length} vehicles selected`;
}

export function sumServiceBaseForVehicles(
  serviceId: string,
  vehicles: BookingVehicleRow[],
  vehicleIds: string[],
  fallbackUnitPrice = 25
): number {
  if (vehicleIds.length === 0) return 0;
  const washId = mapServiceIdToWashId(serviceId);
  if (!washId) return fallbackUnitPrice * vehicleIds.length;

  return vehicleIds.reduce((sum, id) => {
    const row = vehicles.find((v) => v.id === id);
    if (!row) return sum + fallbackUnitPrice;
    const breakdown = calculateDisplayPrice({
      washId,
      vehicleSize: getVehicleSize(row),
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(),
    });
    const unit = breakdown.finalDisplayPriceGBP > 0 ? breakdown.finalDisplayPriceGBP : fallbackUnitPrice;
    return sum + unit;
  }, 0);
}
