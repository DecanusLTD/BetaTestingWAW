export type ReferralTierName = 'Parked' | 'Solo Owner' | 'Driveway Crew' | 'Fleet Captain' | 'Garage Legend';

export type ReferralTierConfig = {
  name: ReferralTierName;
  min: number;
  icon: string;
  color: string;
  subtitle: string;
};

export type ReferralBadge = {
  id: string;
  count: number;
  label: string;
  icon: string;
};

export const REFERRAL_TIERS: ReferralTierConfig[] = [
  { name: 'Parked', min: 0, icon: 'car-outline', color: '#94A3B8', subtitle: 'Invite vehicle owners' },
  { name: 'Solo Owner', min: 1, icon: 'car-sport-outline', color: '#FCD34D', subtitle: '1 owner on board' },
  { name: 'Driveway Crew', min: 3, icon: 'car-sport', color: '#F59E0B', subtitle: '3 owners referred' },
  { name: 'Fleet Captain', min: 7, icon: 'bus', color: '#8B5CF6', subtitle: '7 owners in your network' },
  { name: 'Garage Legend', min: 10, icon: 'trophy', color: '#06B6D4', subtitle: '10 owners — top referrer' },
];

export const REFERRAL_BADGES: ReferralBadge[] = [
  { id: 'first', count: 1, label: 'First Owner', icon: 'car' },
  { id: 'driveway', count: 3, label: 'Driveway Crew', icon: 'car-sport' },
  { id: 'street', count: 5, label: 'Street Fleet', icon: 'home' },
  { id: 'captain', count: 7, label: 'Fleet Captain', icon: 'speedometer' },
  { id: 'legend', count: 10, label: 'Garage Legend', icon: 'trophy' },
];

export function getReferralTier(rewardedCount: number): ReferralTierConfig {
  let current = REFERRAL_TIERS[0]!;
  for (const tier of REFERRAL_TIERS) {
    if (rewardedCount >= tier.min) current = tier;
  }
  return current;
}

export function getReferralTierProgress(rewardedCount: number): {
  tier: ReferralTierConfig;
  progress: number;
  ownersToNext: number;
  nextTier: ReferralTierConfig | null;
} {
  const tier = getReferralTier(rewardedCount);
  const tierIndex = REFERRAL_TIERS.indexOf(tier);
  const nextTier = tierIndex < REFERRAL_TIERS.length - 1 ? REFERRAL_TIERS[tierIndex + 1]! : null;

  if (!nextTier) {
    return { tier, progress: 100, ownersToNext: 0, nextTier: null };
  }

  const span = nextTier.min - tier.min;
  const earned = Math.max(0, rewardedCount - tier.min);
  const progress = Math.min(100, Math.max(0, (earned / span) * 100));
  const ownersToNext = Math.max(0, nextTier.min - rewardedCount);

  return { tier, progress, ownersToNext, nextTier };
}

export function getNextReferralBadge(rewardedCount: number): ReferralBadge | null {
  return REFERRAL_BADGES.find((badge) => rewardedCount < badge.count) ?? null;
}

export function getReferralBadgeForCount(count: number): ReferralBadge | undefined {
  return REFERRAL_BADGES.find((badge) => badge.count === count);
}

export function formatOwnerCount(count: number): string {
  if (count === 0) return 'Start inviting';
  return count === 1 ? '1 owner' : `${count} owners`;
}
