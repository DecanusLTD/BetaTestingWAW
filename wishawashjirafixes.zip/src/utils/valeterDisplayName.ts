import { supabase } from '../lib/supabase';
import { ccpFallbackName } from '../constants/carCareProLabels';
import { formatDisplayName } from './formatDisplayName';

export type ValeterIdentity = {
  name: string;
  photoUrl: string | null;
};

/** Prefer valeter_profiles.full_name, then profiles.full_name, then fallback. */
export function resolveValeterDisplayName(
  valeterProfileName?: string | null,
  accountProfileName?: string | null,
  bookingValeterName?: string | null,
): string {
  const raw =
    (valeterProfileName && String(valeterProfileName).trim()) ||
    (accountProfileName && String(accountProfileName).trim()) ||
    (bookingValeterName && String(bookingValeterName).trim()) ||
    '';
  const formatted = formatDisplayName(raw) || raw;
  return formatted || ccpFallbackName();
}

/**
 * Batch-load Pro display names + photos for many user ids.
 * Source order: valeter_profiles → profiles → fallback.
 */
export async function fetchValeterIdentitiesByIds(
  userIds: string[],
): Promise<Map<string, ValeterIdentity>> {
  const unique = [...new Set(userIds.filter(Boolean))];
  const out = new Map<string, ValeterIdentity>();
  if (unique.length === 0) return out;

  const [vpRes, profRes] = await Promise.all([
    supabase.from('valeter_profiles').select('user_id, full_name, profile_photo_url').in('user_id', unique),
    supabase.from('profiles').select('id, full_name, profile_picture').in('id', unique),
  ]);

  const vpById = new Map<string, { full_name?: string | null; profile_photo_url?: string | null }>();
  for (const row of vpRes.data || []) {
    vpById.set(String((row as { user_id: string }).user_id), row as {
      full_name?: string | null;
      profile_photo_url?: string | null;
    });
  }

  const profById = new Map<string, { full_name?: string | null; profile_picture?: string | null }>();
  for (const row of profRes.data || []) {
    profById.set(String((row as { id: string }).id), row as {
      full_name?: string | null;
      profile_picture?: string | null;
    });
  }

  for (const id of unique) {
    const vp = vpById.get(id);
    const prof = profById.get(id);
    out.set(id, {
      name: resolveValeterDisplayName(vp?.full_name, prof?.full_name),
      photoUrl: vp?.profile_photo_url || prof?.profile_picture || null,
    });
  }

  return out;
}

/** Single Pro identity (name + photo). */
export async function fetchValeterIdentity(userId: string): Promise<ValeterIdentity> {
  const map = await fetchValeterIdentitiesByIds([userId]);
  return map.get(userId) || { name: ccpFallbackName(), photoUrl: null };
}
