import { supabase } from '../lib/supabase';

const BUCKET = 'uploads';
const PROFILE_FILE_NAME = 'profile_picture.jpg';
const PROFILE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'] as const;

const userStorageFolders = (userId: string) => [`${userId}`, `users/${userId}`] as const;

export function profilePictureStoragePath(userId: string): string {
  return `${userId}/${PROFILE_FILE_NAME}`;
}

/** Extract `uploads` object path from a public or relative storage URL. */
export function profilePicturePathFromUrl(value?: string | null): string | null {
  const raw = String(value || '').trim();
  if (!raw) return null;

  if (!/^https?:\/\//i.test(raw)) {
    const relative = raw.replace(/^\/+/, '');
    return relative || null;
  }

  const markers = ['/object/public/uploads/', '/storage/v1/object/public/uploads/'];
  for (const marker of markers) {
    const idx = raw.indexOf(marker);
    if (idx === -1) continue;
    const path = raw.slice(idx + marker.length).split('?')[0]?.split('#')[0];
    if (path) return decodeURIComponent(path);
  }

  return null;
}

function candidateProfilePicturePaths(userId: string): string[] {
  const paths = new Set<string>();
  for (const folder of userStorageFolders(userId)) {
    paths.add(`${folder}/${PROFILE_FILE_NAME}`);
    for (const ext of PROFILE_EXTENSIONS) {
      paths.add(`${folder}/profile_picture.${ext}`);
    }
  }
  return [...paths];
}

async function listStoredProfilePicturePaths(userId: string): Promise<string[]> {
  const paths: string[] = [];
  for (const folder of userStorageFolders(userId)) {
    try {
      const { data: files, error } = await supabase.storage.from(BUCKET).list(folder, { limit: 100 });
      if (error) continue;
      for (const file of files ?? []) {
        const name = String(file?.name || '');
        if (!name || name === '.emptyFolderPlaceholder') continue;
        if (name.toLowerCase().startsWith('profile_picture')) {
          paths.push(`${folder}/${name}`);
        }
      }
    } catch {
      // ignore list failures (RLS)
    }
  }
  return paths;
}

async function removePathsSafe(paths: string[]): Promise<void> {
  const unique = [...new Set(paths.map((p) => p.replace(/^\/+/, '')).filter(Boolean))];
  if (unique.length === 0) return;

  try {
    const { error } = await supabase.storage.from(BUCKET).remove(unique);
    if (error) {
      console.warn('[profilePictureStorage] remove failed:', error.message);
    }
  } catch (err) {
    console.warn('[profilePictureStorage] remove threw:', err);
  }
}

/**
 * Deletes prior profile picture objects for a user, keeping only `keepPath` if provided.
 * Never throws — storage delete policies may be missing.
 */
export async function removeStaleProfilePictures(
  userId: string,
  options?: { keepPath?: string | null; previousUrl?: string | null },
): Promise<void> {
  try {
    const keepPath = options?.keepPath?.replace(/^\/+/, '') ?? null;
    const paths = new Set([
      ...candidateProfilePicturePaths(userId),
      ...(await listStoredProfilePicturePaths(userId)),
    ]);

    const previousPath = profilePicturePathFromUrl(options?.previousUrl);
    if (previousPath) paths.add(previousPath);

    const toRemove = [...paths].filter((path) => path && path !== keepPath);
    await removePathsSafe(toRemove);
  } catch (err) {
    console.warn('[profilePictureStorage] cleanup failed:', err);
  }
}

/**
 * Upload profile picture bytes. Uses a fixed JPEG path and remove-then-upload
 * so buckets with INSERT-only policies still work on replacement.
 */
export async function uploadProfilePictureBytes(
  userId: string,
  bytes: Uint8Array,
  options?: { previousUrl?: string | null },
): Promise<string> {
  if (!bytes.length) {
    throw new Error('Photo read failed (0 bytes). Please pick another image.');
  }

  const filePath = profilePictureStoragePath(userId);

  // Clear old variants first (best-effort; ignore policy errors).
  await removeStaleProfilePictures(userId, { previousUrl: options?.previousUrl });

  const upload = () =>
    supabase.storage.from(BUCKET).upload(filePath, bytes, {
      contentType: 'image/jpeg',
      upsert: false,
      cacheControl: '3600',
    });

  let { error: uploadError } = await upload();

  if (uploadError) {
    const message = uploadError.message?.toLowerCase() ?? '';
    const isDuplicate =
      message.includes('already exists') ||
      message.includes('duplicate') ||
      message.includes('resource already exists');

    if (isDuplicate) {
      await removePathsSafe([filePath]);
      ({ error: uploadError } = await upload());
    }
  }

  let finalPath = filePath;

  if (uploadError) {
    // INSERT-only buckets: upload under a fresh name if replace is blocked.
    finalPath = `${userId}/profile_picture_${Date.now()}.jpg`;
    const fallback = await supabase.storage.from(BUCKET).upload(finalPath, bytes, {
      contentType: 'image/jpeg',
      upsert: false,
      cacheControl: '3600',
    });
    uploadError = fallback.error;
  }

  if (uploadError) {
    throw new Error(uploadError.message || 'Failed to upload profile picture');
  }

  await removeStaleProfilePictures(userId, {
    keepPath: finalPath,
    previousUrl: options?.previousUrl,
  });

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(finalPath);
  if (!data?.publicUrl) throw new Error('Failed to get public URL');

  return data.publicUrl;
}
