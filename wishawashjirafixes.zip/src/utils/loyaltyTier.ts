export type LoyaltyTier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export type RewardCategory = 'wash' | 'perk' | 'status' | 'chaos';

export type RewardMilestone = {
  id: string;
  title: string;
  description: string;
  points: number;
  icon: string;
  tier: 'rare' | 'epic' | 'legendary';
  category: RewardCategory;
};

export const LOYALTY_TIER_THRESHOLDS: Record<LoyaltyTier, { min: number; max: number | null; perk: string; color: string }> = {
  Bronze: { min: 0, max: 500, perk: '5% off washes', color: '#D97706' },
  Silver: { min: 501, max: 1500, perk: '10% off washes', color: '#CBD5E1' },
  Gold: { min: 1501, max: 3000, perk: '15% off + priority booking', color: '#FBBF24' },
  Platinum: { min: 3001, max: null, perk: '20% off + exclusive perks', color: '#67E8F9' },
};

export const WASH_REWARD_MILESTONES: RewardMilestone[] = [
  {
    id: 'reward-driveway-honk',
    title: 'Driveway Horn Salute',
    description: 'Your Care Pro gives a friendly horn hello on arrival.',
    points: 250,
    icon: 'car-outline',
    tier: 'rare',
    category: 'chaos',
  },
  {
    id: 'reward-dash-duck',
    title: 'Dashboard Duck',
    description: 'Classic rubber duck placed on your dash after the wash.',
    points: 400,
    icon: 'car-sport-outline',
    tier: 'rare',
    category: 'perk',
  },
  {
    id: 'reward-alloy-formula',
    title: 'Alloy Wash Formula',
    description: 'Name the foam mix used on your alloys for the day.',
    points: 600,
    icon: 'disc',
    tier: 'rare',
    category: 'chaos',
  },
  {
    id: 'reward-10',
    title: '10% Off Vehicle Washes',
    description: 'Ten percent off your next car wash booking.',
    points: 750,
    icon: 'pricetag',
    tier: 'rare',
    category: 'wash',
  },
  {
    id: 'reward-plate-polish',
    title: 'Reg Plate Polish',
    description: 'Extra registration plate clean and shine pass.',
    points: 900,
    icon: 'card',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-windscreen-note',
    title: 'Windscreen Compliment',
    description: 'A handwritten note about your car left on the receipt.',
    points: 1100,
    icon: 'document-text',
    tier: 'rare',
    category: 'perk',
  },
  {
    id: 'reward-25',
    title: '25% Off Vehicle Washes',
    description: 'Redeem for 25% off washes on any registered vehicle.',
    points: 1250,
    icon: 'pricetag',
    tier: 'rare',
    category: 'wash',
  },
  {
    id: 'reward-driveway-vip',
    title: 'Driveway VIP Lane',
    description: 'Skip the queue for one mobile wash at home.',
    points: 1450,
    icon: 'home',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-tyre-shine',
    title: 'Deep Tyre Shine',
    description: 'Extra slow tyre dressing pass on all four wheels.',
    points: 1650,
    icon: 'ellipse-outline',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-mot-badge',
    title: 'MOT Week Badge',
    description: 'Digital good-luck charm for MOT week on your garage.',
    points: 1850,
    icon: 'shield-checkmark',
    tier: 'rare',
    category: 'status',
  },
  {
    id: 'reward-cabin-scent',
    title: 'New Car Scent Reset',
    description: 'Interior spritz to bring back that fresh cabin smell.',
    points: 2100,
    icon: 'leaf',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-showroom-badge',
    title: 'Showroom Finish Badge',
    description: 'Gold vehicle badge on your profile for 30 days.',
    points: 2350,
    icon: 'star',
    tier: 'epic',
    category: 'status',
  },
  {
    id: 'reward-basic',
    title: 'Free Basic Wash',
    description: 'Complimentary basic wash for one vehicle.',
    points: 2500,
    icon: 'car',
    tier: 'epic',
    category: 'wash',
  },
  {
    id: 'reward-wheel-salute',
    title: 'Four-Wheel Salute',
    description: 'Your pro acknowledges each wheel before the wash begins.',
    points: 2850,
    icon: 'car-sport',
    tier: 'legendary',
    category: 'chaos',
  },
  {
    id: 'reward-garage-reel',
    title: 'Garage Reveal Reel',
    description: 'Slow-mo before/after clip of your car for socials.',
    points: 3100,
    icon: 'videocam',
    tier: 'legendary',
    category: 'perk',
  },
  {
    id: 'reward-parked-midnight',
    title: 'Parked Car Midnight Wash',
    description: 'Priority late-night slot while your car sleeps on the drive.',
    points: 3400,
    icon: 'moon',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-v5c-clean',
    title: 'V5C of Cleanliness',
    description: 'Official digital certificate for your spotless vehicle.',
    points: 3750,
    icon: 'document',
    tier: 'rare',
    category: 'status',
  },
  {
    id: 'reward-freshener-trio',
    title: 'Mirror Freshener Trio',
    description: 'Three car air fresheners hung on your rear-view mirror.',
    points: 4100,
    icon: 'flower',
    tier: 'epic',
    category: 'perk',
  },
  {
    id: 'reward-driveway-star',
    title: 'Driveway Star Feature',
    description: 'Your vehicle featured in the app banner for 7 days.',
    points: 4500,
    icon: 'images',
    tier: 'legendary',
    category: 'status',
  },
  {
    id: 'reward-gold',
    title: 'Free Gold Wash',
    description: 'Complimentary Gold wash — full showroom finish.',
    points: 5000,
    icon: 'diamond',
    tier: 'legendary',
    category: 'wash',
  },
  {
    id: 'reward-platinum-garage',
    title: 'Platinum Garage Pass',
    description: '14-day Platinum vehicle perks on your account.',
    points: 6200,
    icon: 'key',
    tier: 'legendary',
    category: 'status',
  },
  {
    id: 'reward-hall-of-fame',
    title: 'Clean Car Hall of Fame',
    description: 'Your vehicle listed on the owner wall of legends.',
    points: 7500,
    icon: 'trophy',
    tier: 'legendary',
    category: 'status',
  },
  {
    id: 'reward-annual-valet',
    title: 'Annual Valet Pass',
    description: 'One bonus vehicle perk wash every month for a year.',
    points: 10000,
    icon: 'calendar',
    tier: 'legendary',
    category: 'chaos',
  },
];

const TIER_ORDER: LoyaltyTier[] = ['Bronze', 'Silver', 'Gold', 'Platinum'];

export function getLoyaltyTier(points: number): LoyaltyTier {
  if (points >= 3001) return 'Platinum';
  if (points >= 1501) return 'Gold';
  if (points >= 501) return 'Silver';
  return 'Bronze';
}

export function getTierProgress(points: number): {
  tier: LoyaltyTier;
  progress: number;
  pointsToNextTier: number;
  nextTier: LoyaltyTier | null;
  perk: string;
  color: string;
} {
  const tier = getLoyaltyTier(points);
  const config = LOYALTY_TIER_THRESHOLDS[tier];
  const tierIndex = TIER_ORDER.indexOf(tier);
  const nextTier = tierIndex < TIER_ORDER.length - 1 ? TIER_ORDER[tierIndex + 1]! : null;

  if (!nextTier || config.max == null) {
    return {
      tier,
      progress: 100,
      pointsToNextTier: 0,
      nextTier: null,
      perk: config.perk,
      color: config.color,
    };
  }

  const nextMin = LOYALTY_TIER_THRESHOLDS[nextTier].min;
  const span = nextMin - config.min;
  const earned = Math.max(0, points - config.min);
  const progress = Math.min(100, Math.max(0, (earned / span) * 100));
  const pointsToNextTier = Math.max(0, nextMin - points);

  return {
    tier,
    progress,
    pointsToNextTier,
    nextTier,
    perk: config.perk,
    color: config.color,
  };
}

export function getNextMilestone(points: number): RewardMilestone | null {
  return WASH_REWARD_MILESTONES.find((m) => points < m.points) ?? null;
}

export function getMilestoneTrackProgress(points: number): number {
  const next = getNextMilestone(points);
  if (!next) return 100;
  const prev = WASH_REWARD_MILESTONES[WASH_REWARD_MILESTONES.indexOf(next) - 1]?.points ?? 0;
  return Math.min(100, Math.max(0, ((points - prev) / (next.points - prev)) * 100));
}

export function getMilestoneTierColor(tier: RewardMilestone['tier']): string {
  if (tier === 'legendary') return '#FFD700';
  if (tier === 'epic') return '#A78BFA';
  return '#60A5FA';
}

export function getRewardCategoryColor(category: RewardMilestone['category']): string {
  if (category === 'chaos') return '#FB7185';
  if (category === 'status') return '#67E8F9';
  if (category === 'perk') return '#4ADE80';
  return '#FBBF24';
}

export function getRewardCategoryLabel(category: RewardMilestone['category']): string {
  if (category === 'wash') return 'vehicle wash';
  if (category === 'perk') return 'car perk';
  if (category === 'status') return 'garage status';
  return 'garage flex';
}

export function getRewardClaimCopy(reward: RewardMilestone): {
  walletLine: string;
  primaryCta: string;
  showBookingCta: boolean;
} {
  switch (reward.category) {
    case 'wash':
      return {
        walletLine: 'Saved to your vehicle rewards wallet',
        primaryCta: 'Book a wash',
        showBookingCta: true,
      };
    case 'perk':
      return {
        walletLine: 'Queued for your next vehicle visit',
        primaryCta: 'Book to activate',
        showBookingCta: true,
      };
    case 'status':
      return {
        walletLine: 'Added to your garage profile',
        primaryCta: 'View in garage',
        showBookingCta: false,
      };
    case 'chaos':
      return {
        walletLine: 'Unleashed on your driveway. No refunds.',
        primaryCta: 'My car deserves this',
        showBookingCta: false,
      };
    default:
      return {
        walletLine: 'Added to your rewards wallet',
        primaryCta: 'Done',
        showBookingCta: false,
      };
  }
}

export function formatRelativeLoyaltyDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const days = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  if (days <= 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}
