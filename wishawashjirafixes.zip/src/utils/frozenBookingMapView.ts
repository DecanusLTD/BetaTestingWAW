import type { Region } from 'react-native-maps';
import { LOCATION_PICKER_ZOOM_DELTA } from '../constants/mapConstants';

/** Bottom map padding used on Make a wish / frozen booking map stages. */
export const BOOKING_FROZEN_MAP_SHEET_PADDING = 320;

export type FrozenBookingMapView = {
  region: Region;
  mapPadding: { top: number; right: number; bottom: number; left: number };
  legalLabelInsets: { top: number; right: number; bottom: number; left: number };
};

export function buildFrozenBookingMapView(
  location: { latitude: number; longitude: number },
  bottomInset: number,
  region?: Region | null
): FrozenBookingMapView {
  const safeBottom = Math.max(bottomInset, 14);
  return {
    region: region ?? {
      latitude: location.latitude,
      longitude: location.longitude,
      latitudeDelta: LOCATION_PICKER_ZOOM_DELTA,
      longitudeDelta: LOCATION_PICKER_ZOOM_DELTA,
    },
    mapPadding: {
      top: 12,
      right: 12,
      bottom: BOOKING_FROZEN_MAP_SHEET_PADDING + safeBottom,
      left: 12,
    },
    legalLabelInsets: {
      top: 0,
      right: 10,
      bottom: 148 + safeBottom,
      left: 10,
    },
  };
}

export function frozenMapViewFromCoords(
  latitude: number,
  longitude: number,
  bottomInset: number,
  latDelta?: number | null,
  lngDelta?: number | null
): FrozenBookingMapView {
  const deltaLat = latDelta != null && Number.isFinite(latDelta) ? latDelta : LOCATION_PICKER_ZOOM_DELTA;
  const deltaLng = lngDelta != null && Number.isFinite(lngDelta) ? lngDelta : LOCATION_PICKER_ZOOM_DELTA;
  return buildFrozenBookingMapView(
    { latitude, longitude },
    bottomInset,
    { latitude, longitude, latitudeDelta: deltaLat, longitudeDelta: deltaLng }
  );
}
