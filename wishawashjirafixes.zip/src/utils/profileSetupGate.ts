import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabase';

export type AppleFullNameLike = {
  givenName?: string | null;
  familyName?: string | null;
  middleName?: string | null;
} | null | undefined;

/** Build display name from Apple credential.fullName (only provided on first authorize). */
export function nameFromAppleFullName(fullName: AppleFullNameLike): string {
  if (!fullName) return '';
  return [fullName.givenName, fullName.middleName, fullName.familyName]
    .map((p) => (typeof p === 'string' ? p.trim() : ''))
    .filter(Boolean)
    .join(' ')
    .trim();
}

export function hasUsableDisplayName(name?: string | null): boolean {
  const trimmed = (name || '').trim();
  if (trimmed.length < 2) return false;
  // Ignore placeholder-looking values
  if (trimmed.toLowerCase() === 'owner' || trimmed.toLowerCase() === 'customer') return false;
  if (trimmed.includes('@')) return false;
  return true;
}

export async function customerHasVehicle(userId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('customer_vehicles')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId);
  if (error) {
    console.warn('[profileSetup] vehicle count failed:', error.message);
    return false;
  }
  return (count ?? 0) > 0;
}

/** True when name or first vehicle is still missing. */
export async function needsCustomerProfileSetup(
  userId: string,
  name?: string | null
): Promise<boolean> {
  if (!hasUsableDisplayName(name)) return true;
  const hasVehicle = await customerHasVehicle(userId);
  return !hasVehicle;
}

function isCustomerOnboarded(user: any, seen: string | null) {
  const flags = {
    generic: Boolean(user?.onboarded || user?.isOnboarded),
    customer: Boolean(user?.customerOnboarded || user?.isCustomerOnboarded),
  };
  const seenGeneric = seen === 'true' || seen === '1';
  const seenCustomer = seen === 'customer' || seenGeneric;
  return flags.generic || flags.customer || seenCustomer;
}

/**
 * Shared post-auth destination for login / Apple / cold start.
 * Profile setup (name + vehicle) → welcome onboarding → dashboard.
 */
export async function resolvePostAuthRoute(user: {
  id: string;
  name?: string | null;
  onboarded?: boolean;
  isOnboarded?: boolean;
  customerOnboarded?: boolean;
  isCustomerOnboarded?: boolean;
}): Promise<
  '/owner/profile-setup' | '/owner/customer-onboarding' | '/owner/owner-dashboard'
> {
  if (await needsCustomerProfileSetup(user.id, user.name)) {
    return '/owner/profile-setup';
  }

  let seen: string | null = null;
  try {
    seen = await AsyncStorage.getItem('onboarding_seen');
  } catch {
    seen = null;
  }

  if (!isCustomerOnboarded(user, seen)) {
    return '/owner/customer-onboarding';
  }

  return '/owner/owner-dashboard';
}
