/**
 * Launch v1 — owner customer journey
 *
 * Supported path (mobile-only launch):
 * - Discover: dashboard / explore / valeter profiles
 * - Book mobile: `/owner/booking/create` (location) → vehicle → package → valeter → … → pay → track → complete
 *
 * Hidden until a later release:
 * - Come To Us / hub booking (`/owner/booking/physical/*`)
 * - Car wash & detail studio discovery tabs
 *
 * Intentionally not shipped as separate route trees (removed from repo):
 * - `/owner/booking/eco/*` (parallel eco-only flow)
 * - `/owner/booking/detailing/*` (hub detailing studio branch; mobile detailing remains on `create` if offered there)
 * - Orphan screens: navigate, standalone favourites/promotions, owner analytics, duplicate waiting-acceptance
 */

/** When true, customer UI exposes mobile valeter booking only. */
export const MOBILE_SERVICE_ONLY_LAUNCH = true;

export const LAUNCH_CUSTOMER_SCOPE = MOBILE_SERVICE_ONLY_LAUNCH
  ? 'v1-mobile-only'
  : 'v1-explore-mobile-or-hub';

/** Explore bottom-sheet / filter tabs shown to customers. */
export const CUSTOMER_EXPLORE_TABS = MOBILE_SERVICE_ONLY_LAUNCH
  ? (['valeters', 'favourites'] as const)
  : (['hubs', 'valeters', 'favourites'] as const);

export type CustomerExploreTabId = (typeof CUSTOMER_EXPLORE_TABS)[number];
