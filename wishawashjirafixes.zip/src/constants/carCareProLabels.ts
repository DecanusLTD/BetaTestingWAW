/**
 * Customer-facing brand name for mobile valeters (UI copy only).
 * Database fields and internal types remain `valeter_*`.
 */
export const CCP = {
  /** Headlines / first mention — e.g. help articles, terms */
  plural: "Car Care Pros (CCP's)",
  singular: "Car Care Pro (CCP)",
  /** Tabs, chips, pills, status lines — keep tight */
  pluralShort: 'Pros',
  singularShort: 'Pro',
  abbrevPlural: "CCP's",
  abbrevSingular: 'CCP',
  /** When a pro's display name is missing */
  fallbackName: 'Pro',
  /** Explore map filter tab */
  exploreTab: 'Pros',
  /** Primary CTA on explore / profile request buttons */
  requestButton: 'Request Pro',
} as const;

export function ccpFallbackName(): string {
  return CCP.fallbackName;
}

/** Lowercase for mid-sentence copy — "nearby pros" */
export function ccpPluralLower(): string {
  return CCP.pluralShort.toLowerCase();
}

export function ccpSingularLower(): string {
  return CCP.singularShort.toLowerCase();
}

/** "1 Pro" / "3 Pros" */
export function ccpCount(count: number, short = true): string {
  if (count === 1) return short ? CCP.singularShort : CCP.singular;
  return short ? CCP.pluralShort : CCP.plural;
}

/** "2 Pros" with leading count */
export function ccpCountLabel(count: number, short = true): string {
  return `${count} ${ccpCount(count, short)}`;
}
