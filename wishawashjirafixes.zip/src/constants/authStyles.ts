/** Gradient overlay colors for auth video background (shared by landing shell). */
export const AUTH_GRADIENT_COLORS = [
  'rgba(2,10,24,0.28)',
  'rgba(2,10,24,0.55)',
  'rgba(2,10,24,0.88)',
] as const;

/** @deprecated Prefer AuthLandingShell dock — kept for any residual imports. */
export const AUTH_CONTENT_OVERLAY_COLORS = [
  'rgba(10,25,41,0.5)',
  'rgba(10,25,41,0.75)',
  'rgba(10,25,41,0.95)',
] as const;

/** Legacy shared style bag — prefer AuthLandingShell / AuthEmailSheet styles. */
export const sharedAuthStyleDefs = {
  root: { flex: 1, backgroundColor: '#020A18' as const },
};
