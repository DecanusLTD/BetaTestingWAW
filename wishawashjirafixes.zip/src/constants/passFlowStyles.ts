import { StyleSheet } from 'react-native';

export const passFlow = StyleSheet.create({
  section: {
    marginBottom: 28,
  },
  sectionHead: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 12,
  },
  sectionTitle: {
    color: 'rgba(226,232,240,0.62)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  sectionMeta: {
    color: 'rgba(148,163,184,0.75)',
    fontSize: 11,
    fontWeight: '600',
  },
  hairline: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(148,163,184,0.14)',
  },
  flowRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.12)',
  },
  flowRowLast: {
    borderBottomWidth: 0,
  },
  borderedList: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
    backgroundColor: 'rgba(15,23,42,0.32)',
    overflow: 'hidden',
    paddingHorizontal: 12,
  },
  borderedListAmber: {
    borderColor: 'rgba(245,158,11,0.24)',
  },
  hint: {
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 17,
    marginTop: -6,
    marginBottom: 20,
  },
});

export const passHero = StyleSheet.create({
  wrap: {
    marginBottom: 16,
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    backgroundColor: 'rgba(15,23,42,0.38)',
    overflow: 'hidden',
  },
  wrapGold: {
    borderColor: 'rgba(251,191,36,0.28)',
  },
  wrapAmber: {
    borderColor: 'rgba(245,158,11,0.28)',
  },
  content: {
    gap: 16,
  },
  topRow: {
    gap: 5,
  },
  tierLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  tierText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  perk: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  mainRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
  },
  ringCol: {
    width: 88,
    height: 88,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsCol: {
    flex: 1,
    minWidth: 0,
    gap: 4,
  },
  headline: {
    color: '#F8FAFC',
    fontSize: 36,
    fontWeight: '900',
    letterSpacing: -1,
    lineHeight: 40,
  },
  headlineLabel: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  metaLine: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 17,
  },
  nextLine: {
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
});
