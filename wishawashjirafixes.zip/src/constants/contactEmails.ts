/** Official Wish a Wash contact addresses — only these may appear in the app. */
export const SUPPORT_EMAIL = 'support@wishawashapp.com';
export const INFO_EMAIL = 'info@wishawashapp.com';
