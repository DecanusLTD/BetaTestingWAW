import { useMemo } from 'react';
import { getMapChromeColors, type MapChromeColors } from '../constants/bookingCardTheme';
import { useThemeOptional } from '../contexts/ThemeContext';

/** Theme-aware map chrome — yellow (dark) or sky blue (light). */
export function useMapChromeColors(): MapChromeColors {
  const theme = useThemeOptional();
  const isLight = theme?.isDark !== true;
  return useMemo(() => getMapChromeColors(isLight), [isLight]);
}
