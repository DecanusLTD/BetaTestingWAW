import {
  detailingServiceOptions,
  findServiceOptionById,
  repairServiceOptions,
  serviceOptions,
} from '../constants/serviceOptions';
import { supabase } from '../lib/supabase';
import { getVehicleSize, type VehicleSize } from '../pricing/pricingEngine';

export type ValeterPriceTier = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

export type ValeterServicePricingValue =
  | number
  | {
      price?: number;
      basePrice?: number;
      enabled?: boolean;
      minutes?: number | null;
      small?: number;
      medium?: number;
      large?: number;
      xl?: number;
      xxl?: number;
      prices?: Partial<Record<ValeterPriceTier, number | null>>;
    };

export type ValeterServicePricingMap = Record<string, ValeterServicePricingValue>;

export interface ValeterServiceSettingsRow {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  detailing_menu?: ValeterServicePricingMap | unknown | null;
  tier_pricing?: ValeterServicePricingMap | unknown | null;
  repairs_offered?: boolean | null;
  repair_menu?: ValeterServicePricingMap | unknown | null;
}

export interface ResolvedValeterBookingPrice {
  available: boolean;
  serviceId: string;
  serviceName: string;
  basePrice: number;
  customerPrice: number;
  customerTotalPrice: number;
  pricingSource: 'valeter' | 'catalogue';
  platformFeePercent: number;
  platformFeeAmount: number;
}

const DEFAULT_PLATFORM_FEE_PERCENT = 0.2;

const cachedPlatformFeePercentByContext = new Map<string, number>();
const cachedPlatformFeeFetchedAtByContext = new Map<string, number>();

function toNumber(value: unknown): number | null {
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''));
  return Number.isFinite(n) ? n : null;
}

function normalizePlatformFeePercent(rawValue: unknown): number {
  const raw = toNumber(rawValue);
  if (raw == null) return DEFAULT_PLATFORM_FEE_PERCENT;
  if (raw > 1) return raw / 100;
  return Math.max(0, raw);
}

function toTierKey(size: VehicleSize | undefined | null): ValeterPriceTier {
  switch (size) {
    case 'MEDIUM':
      return 'medium';
    case 'LARGE':
      return 'large';
    case 'XL':
      return 'xl';
    case 'XXL':
      return 'xxl';
    default:
      return 'small';
  }
}

function resolvePriceFromEntry(
  entry: ValeterServicePricingValue | undefined,
  vehicleSize: VehicleSize | undefined | null,
  washType?: 'exterior' | 'interior' | 'both' | string | null,
): number | null {
  if (entry == null) return null;
  if (typeof entry === 'number') {
    return Number.isFinite(entry) ? entry : null;
  }

  const tierKey = toTierKey(vehicleSize);
  const entryObj = entry as ValeterServicePricingValue & {
    pricesExterior?: Partial<Record<ValeterPriceTier, number | null>>;
    pricesInterior?: Partial<Record<ValeterPriceTier, number | null>>;
    prices_exterior?: Partial<Record<ValeterPriceTier, number | null>>;
    prices_interior?: Partial<Record<ValeterPriceTier, number | null>>;
  };

  const scopedMap =
    washType === 'exterior'
      ? entryObj.pricesExterior ?? entryObj.prices_exterior
      : washType === 'interior'
        ? entryObj.pricesInterior ?? entryObj.prices_interior
        : null;

  if (scopedMap && typeof scopedMap === 'object') {
    const scopedValue = toNumber(scopedMap[tierKey]);
    if (scopedValue != null) return scopedValue;
    const scopedSmall = toNumber(scopedMap.small);
    if (scopedSmall != null) return scopedSmall;
  }

  if (entry.prices && typeof entry.prices === 'object') {
    const tierValue = toNumber(entry.prices[tierKey]);
    if (tierValue != null) return tierValue;
    const tierSmall = toNumber(entry.prices.small);
    if (tierSmall != null) return tierSmall;
  }

  const tierValue = toNumber(entry[tierKey]);
  if (tierValue != null) return tierValue;

  const preferredFallback = toNumber(entry.price ?? entry.basePrice);
  if (preferredFallback != null) return preferredFallback;

  const smallFallback = toNumber(entry.small);
  if (smallFallback != null) return smallFallback;

  return null;
}

const WASH_SERVICE_IDS = new Set(serviceOptions.map((o) => o.id));
const DETAILING_SERVICE_IDS = new Set(detailingServiceOptions.map((o) => o.id));
const REPAIR_SERVICE_IDS = new Set(repairServiceOptions.map((o) => o.id));

function getServiceCategory(serviceId: string): 'wash' | 'detailing' | 'repair' | 'other' {
  const resolved = findServiceOptionById(serviceId);
  const normalizedId = resolved?.id ?? serviceId;
  if (WASH_SERVICE_IDS.has(normalizedId)) return 'wash';
  if (DETAILING_SERVICE_IDS.has(normalizedId)) return 'detailing';
  if (REPAIR_SERVICE_IDS.has(normalizedId)) return 'repair';
  return 'other';
}

/** Pro app saves detailing/repair menus as `{ items: [...] }`. */
function unwrapMenuItems(menu: unknown): unknown {
  if (!menu || typeof menu !== 'object' || Array.isArray(menu)) return menu;
  const items = (menu as { items?: unknown }).items;
  return Array.isArray(items) ? items : menu;
}

function normalizePricingMenu(menu: unknown): ValeterServicePricingMap {
  const unwrapped = unwrapMenuItems(menu);
  if (!unwrapped || typeof unwrapped !== 'object') return {};
  if (Array.isArray(unwrapped)) {
    return unwrapped.reduce<ValeterServicePricingMap>((acc, item) => {
      if (!item || typeof item !== 'object') return acc;
      const row = item as Record<string, unknown>;
      const keyRaw = String(
        row.key ?? row.service_id ?? row.serviceId ?? row.id ?? row.slug ?? row.code ?? '',
      ).trim();
      if (!keyRaw) return acc;
      const key = keyRaw === 'ceramic' ? 'ceramic-coating' : keyRaw === 'maintenance-check' ? 'maintenance-pack' : keyRaw;
      // Keep full row so `enabled` / `prices` survive for availability checks.
      acc[key] = row as ValeterServicePricingValue;
      if (key !== keyRaw) acc[keyRaw] = row as ValeterServicePricingValue;
      return acc;
    }, {});
  }
  return unwrapped as ValeterServicePricingMap;
}

function getWashTierKey(serviceId: string): string | null {
  const normalized = findServiceOptionById(serviceId)?.id ?? serviceId;
  const washMap: Record<string, string> = {
    'bronze-wash': 'bronze',
    'silver-wash': 'silver',
    'gold-wash': 'gold',
    'platinum-wash': 'platinum',
    'emerald-wash': 'emerald',
  };
  return washMap[normalized] ?? null;
}

const SERVICE_ID_ALIASES: Record<string, string[]> = {
  'maintenance-pack': ['maintenance-check'],
  'maintenance-check': ['maintenance-pack'],
  'ceramic-coating': ['ceramic'],
  ceramic: ['ceramic-coating'],
};

function extractPricingEntry(map: ValeterServicePricingMap, serviceId: string): ValeterServicePricingValue | undefined {
  if (map[serviceId] != null) return map[serviceId];
  const resolved = findServiceOptionById(serviceId);
  if (resolved && map[resolved.id] != null) return map[resolved.id];
  for (const alias of SERVICE_ID_ALIASES[serviceId] ?? SERVICE_ID_ALIASES[resolved?.id ?? ''] ?? []) {
    if (map[alias] != null) return map[alias];
  }
  const washTierKey = getWashTierKey(serviceId);
  if (washTierKey && map[washTierKey] != null) return map[washTierKey];
  const normalizedKey = serviceId.toLowerCase();
  const matchingKey = Object.keys(map).find((key) => key.toLowerCase() === normalizedKey);
  return matchingKey ? map[matchingKey] : undefined;
}

function hasAnyPricedSize(entry: ValeterServicePricingValue | undefined): boolean {
  if (entry == null) return false;
  if (typeof entry === 'number') return Number.isFinite(entry);
  const entryObj = entry as ValeterServicePricingValue & {
    pricesExterior?: Partial<Record<ValeterPriceTier, number | null>>;
    pricesInterior?: Partial<Record<ValeterPriceTier, number | null>>;
  };
  const maps = [entry.prices, entryObj.pricesExterior, entryObj.pricesInterior];
  for (const prices of maps) {
    if (prices && typeof prices === 'object') {
      if (Object.values(prices).some((v) => toNumber(v) != null)) return true;
    }
  }
  return (
    toNumber(entry.price ?? entry.basePrice ?? entry.small ?? entry.medium ?? entry.large ?? entry.xl ?? entry.xxl) !=
    null
  );
}

function isEntryEnabled(entry: ValeterServicePricingValue | undefined): boolean {
  if (entry == null) return false;
  if (typeof entry === 'number') return Number.isFinite(entry);
  // Match Pro UI: missing `enabled` counts as on; only explicit false is off.
  return entry.enabled !== false;
}

function isWashTierAvailable(
  serviceId: string,
  settings?: ValeterServiceSettingsRow | null,
  pricingMap?: ValeterServicePricingMap,
): boolean {
  if (!settings) return false;
  const washTierKey = getWashTierKey(serviceId);
  if (!washTierKey) return false;
  const entry = pricingMap?.[washTierKey] ?? extractPricingEntry(pricingMap ?? {}, serviceId);
  // Do not require eco_washing — Pro services UI historically omitted it.
  // Availability = this wash tier is enabled (missing counts as on) and has at least one size price.
  return isEntryEnabled(entry) && hasAnyPricedSize(entry);
}

function isMenuServiceAvailable(
  serviceId: string,
  categoryOffered: boolean | null | undefined,
  pricingMap?: ValeterServicePricingMap,
): boolean {
  if (categoryOffered !== true) return false;
  const hasExplicitPricing = pricingMap != null && Object.keys(pricingMap).length > 0;
  if (!hasExplicitPricing) return true;
  const entry = extractPricingEntry(pricingMap, serviceId);
  if (entry == null) return false;
  return isEntryEnabled(entry);
}

function isServiceAvailableFromSettings(
  serviceId: string,
  settings?: ValeterServiceSettingsRow | null,
  pricingMap?: ValeterServicePricingMap,
): boolean {
  if (!settings) return false;
  const category = getServiceCategory(serviceId);
  if (category === 'wash') return isWashTierAvailable(serviceId, settings, pricingMap);
  if (category === 'detailing') return isMenuServiceAvailable(serviceId, settings.detailing_offered, pricingMap);
  if (category === 'repair') return isMenuServiceAvailable(serviceId, settings.repairs_offered, pricingMap);
  return true;
}

function getSettingsPricingMap(serviceId: string, settings?: ValeterServiceSettingsRow | null): ValeterServicePricingMap {
  if (!settings) return {};
  const category = getServiceCategory(serviceId);
  if (category === 'wash') return normalizePricingMenu(settings.tier_pricing);
  if (category === 'detailing') return normalizePricingMenu(settings.detailing_menu);
  if (category === 'repair') return normalizePricingMenu(settings.repair_menu);
  return {};
}

export async function getActivePlatformFeePercent(
  context: 'valeter' | 'physical' = 'valeter',
  forceRefresh = false,
): Promise<number> {
  const cacheKey = context;
  const now = Date.now();
  const cachedPercent = cachedPlatformFeePercentByContext.get(cacheKey);
  const cachedFetchedAt = cachedPlatformFeeFetchedAtByContext.get(cacheKey) ?? 0;
  if (!forceRefresh && cachedPercent != null && now - cachedFetchedAt < 5 * 60 * 1000) {
    return cachedPercent;
  }

  try {
    const { data, error } = await supabase
      .from('waw_platform_fees')
      .select('context, percent, updated_at')
      .eq('context', context)
      .maybeSingle();

    if (error) throw error;

    const row = data as { context?: string; percent?: number | string } | null;
    const percent = normalizePlatformFeePercent(row?.percent);

    cachedPlatformFeePercentByContext.set(cacheKey, percent);
    cachedPlatformFeeFetchedAtByContext.set(cacheKey, now);
    return percent;
  } catch (error) {
    console.warn(`[ValeterPricing] using fallback platform fee (${context})`, error);
    const fallback = cachedPercent ?? DEFAULT_PLATFORM_FEE_PERCENT;
    cachedPlatformFeePercentByContext.set(cacheKey, fallback);
    cachedPlatformFeeFetchedAtByContext.set(cacheKey, now);
    return fallback;
  }
}

export function resolveValeterBookingPrice(args: {
  serviceId: string;
  vehicleSize?: VehicleSize | null | undefined;
  /** Bronze wash: exterior vs interior use different valeter prices. */
  washType?: 'exterior' | 'interior' | 'both' | string | null | undefined;
  fallbackBasePrice?: number | null | undefined;
  settings?: ValeterServiceSettingsRow | null | undefined;
  platformFeePercent?: number | null | undefined;
}): ResolvedValeterBookingPrice {
  const serviceOption = findServiceOptionById(args.serviceId);
  const serviceName = serviceOption?.name ?? args.serviceId;
  const pricingMap = getSettingsPricingMap(args.serviceId, args.settings);
  const pricingEntry = extractPricingEntry(pricingMap, args.serviceId);
  const offered = isServiceAvailableFromSettings(args.serviceId, args.settings, pricingMap);

  const basePrice =
    resolvePriceFromEntry(pricingEntry, args.vehicleSize, args.washType) ??
    (Number.isFinite(args.fallbackBasePrice ?? NaN) ? Number(args.fallbackBasePrice) : null) ??
    Number(serviceOption?.price ?? 0);

  const platformFeePercent = args.platformFeePercent != null ? args.platformFeePercent : DEFAULT_PLATFORM_FEE_PERCENT;
  const platformFeeAmount = Number((basePrice * platformFeePercent).toFixed(2));
  const customerTotalPrice = Number((basePrice + platformFeeAmount).toFixed(2));

  return {
    available: offered,
    serviceId: args.serviceId,
    serviceName,
    basePrice: Number(basePrice.toFixed(2)),
    customerPrice: customerTotalPrice,
    customerTotalPrice,
    pricingSource: pricingEntry != null && offered ? 'valeter' : 'catalogue',
    platformFeePercent,
    platformFeeAmount,
  };
}

export type VehicleSizeSource = {
  make?: string | null;
  model?: string | null;
  type?: string | null;
  size?: string | null;
};

/**
 * Charge every selected vehicle: size-tier (or catalogue) price per car, then one platform fee on the combined base.
 * When the Pro has no size tiers, `fallbackTotalBasePrice` (already summed on create) is preferred over N × unit catalogue.
 */
export function sumValeterBookingPriceForVehicles(args: {
  serviceId: string;
  vehicles: VehicleSizeSource[];
  washType?: 'exterior' | 'interior' | 'both' | string | null | undefined;
  /** Per-vehicle catalogue fallback when Pro price for that size is missing. */
  fallbackUnitBasePrice?: number | null | undefined;
  /** Pre-summed catalogue total from create (used only when Pro has no size-tier pricing). */
  fallbackTotalBasePrice?: number | null | undefined;
  settings?: ValeterServiceSettingsRow | null | undefined;
  platformFeePercent?: number | null | undefined;
}): ResolvedValeterBookingPrice & { vehicleCount: number } {
  const vehicles = args.vehicles.length > 0 ? args.vehicles : [{}];
  const pricingMap = getSettingsPricingMap(args.serviceId, args.settings);
  const pricingEntry = extractPricingEntry(pricingMap, args.serviceId);
  const hasValeterSizePricing = hasAnyPricedSize(pricingEntry);
  const offered = isServiceAvailableFromSettings(args.serviceId, args.settings, pricingMap);
  const platformFeePercent =
    args.platformFeePercent != null ? args.platformFeePercent : DEFAULT_PLATFORM_FEE_PERCENT;
  const serviceOption = findServiceOptionById(args.serviceId);
  const serviceName = serviceOption?.name ?? args.serviceId;
  const unitFallback =
    Number.isFinite(args.fallbackUnitBasePrice ?? NaN) && (args.fallbackUnitBasePrice as number) > 0
      ? Number(args.fallbackUnitBasePrice)
      : Number(serviceOption?.price ?? 0);

  if (!hasValeterSizePricing) {
    const totalBase =
      Number.isFinite(args.fallbackTotalBasePrice ?? NaN) && (args.fallbackTotalBasePrice as number) > 0
        ? Number(args.fallbackTotalBasePrice)
        : unitFallback * vehicles.length;
    const platformFeeAmount = Number((totalBase * platformFeePercent).toFixed(2));
    const customerTotalPrice = Number((totalBase + platformFeeAmount).toFixed(2));
    return {
      available: offered,
      serviceId: args.serviceId,
      serviceName,
      basePrice: Number(totalBase.toFixed(2)),
      customerPrice: customerTotalPrice,
      customerTotalPrice,
      pricingSource: 'catalogue',
      platformFeePercent,
      platformFeeAmount,
      vehicleCount: vehicles.length,
    };
  }

  let baseSum = 0;
  for (const vehicle of vehicles) {
    const size = getVehicleSize({
      ...(vehicle.make ? { make: vehicle.make } : {}),
      ...(vehicle.model ? { model: vehicle.model } : {}),
      ...(vehicle.type ? { type: vehicle.type } : {}),
      ...(vehicle.size ? { size: vehicle.size } : {}),
    });
    const unit = resolveValeterBookingPrice({
      serviceId: args.serviceId,
      vehicleSize: size,
      washType: args.washType,
      fallbackBasePrice: unitFallback,
      settings: args.settings,
      platformFeePercent,
    });
    baseSum += unit.basePrice;
  }

  const platformFeeAmount = Number((baseSum * platformFeePercent).toFixed(2));
  const customerTotalPrice = Number((baseSum + platformFeeAmount).toFixed(2));
  return {
    available: offered,
    serviceId: args.serviceId,
    serviceName,
    basePrice: Number(baseSum.toFixed(2)),
    customerPrice: customerTotalPrice,
    customerTotalPrice,
    pricingSource: 'valeter',
    platformFeePercent,
    platformFeeAmount,
    vehicleCount: vehicles.length,
  };
}
