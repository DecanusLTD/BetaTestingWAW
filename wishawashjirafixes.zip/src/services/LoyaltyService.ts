import { supabase } from '../lib/supabase';

export const REWARD_POINTS_PER_BOOKING = 50;
export const REFERRAL_BONUS_POINTS = 5;

type ProfileRow = {
  id: string;
  full_name?: string | null;
  email?: string | null;
  referral_code?: string | null;
  referred_by?: string | null;
  tier_points?: number | null;
};

type ReferralRow = {
  id: string;
  referrer_id: string;
  referee_id: string;
  referral_code: string;
  status?: 'pending' | 'completed' | 'rewarded' | null;
  reward_amount?: number | null;
  reward_granted_at?: string | null;
  created_at?: string | null;
  completed_at?: string | null;
};

export type LoyaltyReward = {
  id: string;
  title: string;
  points: number;
};

export type ReferralSummaryRow = {
  id: string;
  refereeId: string;
  refereeName: string;
  refereeEmail?: string | null;
  referralCode: string;
  status: 'pending' | 'completed' | 'rewarded';
  rewardAmount: number;
  createdAt: string;
  completedAt?: string | null;
};

const REFERRAL_CODE_PREFIX = 'WAW-';

function normalizeReferralCode(code: string): string {
  return code.trim().toUpperCase().replace(/\s+/g, '');
}

export function generateReferralCode(userId: string): string {
  const compact = userId.replace(/-/g, '').slice(0, 8).toUpperCase();
  return `${REFERRAL_CODE_PREFIX}${compact || '00000000'}`;
}

async function fetchProfile(userId: string): Promise<ProfileRow | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, email, referral_code, referred_by, tier_points')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.warn('[Loyalty] fetchProfile failed:', error.message);
    return null;
  }

  return (data as ProfileRow | null) ?? null;
}

export async function ensureReferralCode(userId: string): Promise<string> {
  const profile = await fetchProfile(userId);
  if (profile?.referral_code) {
    return normalizeReferralCode(profile.referral_code);
  }

  const referralCode = generateReferralCode(userId);
  const { error } = await supabase
    .from('profiles')
    .update({ referral_code: referralCode })
    .eq('id', userId);

  if (error) {
    console.warn('[Loyalty] ensureReferralCode failed:', error.message);
  }

  return referralCode;
}

export async function applyReferralCodeToUser(userId: string, referralCode: string): Promise<boolean> {
  const normalized = normalizeReferralCode(referralCode);
  if (!normalized) return false;

  const profile = await fetchProfile(userId);
  if (!profile) return false;
  if (profile.referred_by) return true;

  const { data: referrer, error: referrerError } = await supabase
    .from('profiles')
    .select('id, referral_code')
    .eq('referral_code', normalized)
    .maybeSingle();

  if (referrerError || !referrer?.id || referrer.id === userId) {
    if (referrerError) {
      console.warn('[Loyalty] applyReferralCodeToUser lookup failed:', referrerError.message);
    }
    return false;
  }

  const { error: updateError } = await supabase
    .from('profiles')
    .update({ referred_by: referrer.id })
    .eq('id', userId);

  if (updateError) {
    console.warn('[Loyalty] applyReferralCodeToUser update failed:', updateError.message);
    return false;
  }

  const { error: insertError } = await supabase
    .from('referrals')
    .upsert(
      {
        referrer_id: referrer.id,
        referee_id: userId,
        referral_code: normalized,
        status: 'pending',
        reward_amount: REFERRAL_BONUS_POINTS,
      },
      { onConflict: 'referee_id', ignoreDuplicates: true },
    );

  if (insertError) {
    console.warn('[Loyalty] applyReferralCodeToUser insert failed:', insertError.message);
  }

  return true;
}

export async function getReferralSummary(userId: string): Promise<{
  referralCode: string;
  referredBy: boolean;
  totalReferrals: number;
  rewardedReferrals: number;
  referrals: ReferralSummaryRow[];
}> {
  const profile = await fetchProfile(userId);
  const referralCode = profile?.referral_code
    ? normalizeReferralCode(profile.referral_code)
    : await ensureReferralCode(userId);
  const referredBy = !!profile?.referred_by;

  const { data: referralRows, error: referralError } = await supabase
    .from('referrals')
    .select('id, referrer_id, referee_id, referral_code, status, reward_amount, reward_granted_at, created_at, completed_at')
    .eq('referrer_id', userId)
    .order('created_at', { ascending: false });

  if (referralError) {
    console.warn('[Loyalty] getReferralSummary referral query failed:', referralError.message);
    return {
      referralCode,
      referredBy,
      totalReferrals: 0,
      rewardedReferrals: 0,
      referrals: [],
    };
  }

  const rows = (referralRows ?? []) as ReferralRow[];
  const refereeIds = rows.map((row) => row.referee_id);
  const nameMap = new Map<string, { full_name?: string | null; email?: string | null }>();

  if (refereeIds.length > 0) {
    const { data: profiles, error: profileError } = await supabase
      .from('profiles')
      .select('id, full_name, email')
      .in('id', refereeIds);

    if (profileError) {
      console.warn('[Loyalty] getReferralSummary profile lookup failed:', profileError.message);
    } else {
      (profiles ?? []).forEach((profile: any) => {
        nameMap.set(profile.id, {
          full_name: profile.full_name ?? profile.name ?? null,
          email: profile.email ?? null,
        });
      });
    }
  }

  const referrals = rows.map((row) => {
    const referee = nameMap.get(row.referee_id);
    const status = (row.status ?? 'pending') as ReferralSummaryRow['status'];
    return {
      id: row.id,
      refereeId: row.referee_id,
      refereeName: referee?.full_name || referee?.email || 'Wish a Wash member',
      refereeEmail: referee?.email ?? null,
      referralCode: row.referral_code,
      status,
      rewardAmount: Number(row.reward_amount ?? REFERRAL_BONUS_POINTS),
      createdAt: row.created_at ?? new Date().toISOString(),
      completedAt: row.completed_at ?? null,
    };
  });

  return {
    referralCode,
    referredBy,
    totalReferrals: referrals.length,
    rewardedReferrals: referrals.filter((row) => row.status === 'rewarded').length,
    referrals,
  };
}

export async function getLoyaltyBalance(userId: string): Promise<{
  profilePoints: number;
  bookingPoints: number;
  effectivePoints: number;
  completedBookings: number;
}> {
  const [profileResult, bookingResult] = await Promise.all([
    fetchProfile(userId),
    supabase
      .from('bookings')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('status', 'completed'),
  ]);

  if (bookingResult.error) {
    console.warn('[Loyalty] booking count failed:', bookingResult.error.message);
  }

  const completedBookings = bookingResult.count ?? 0;
  const bookingPoints = completedBookings * REWARD_POINTS_PER_BOOKING;
  const profilePoints = Number(profileResult?.tier_points ?? 0);
  const { count: redemptionCount, error: redemptionError } = await supabase
    .from('reward_redemptions')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId);

  if (redemptionError) {
    console.warn('[Loyalty] redemption count failed:', redemptionError.message);
  }

  const hasRedemptions = (redemptionCount ?? 0) > 0;
  const effectivePoints = profilePoints > 0 || hasRedemptions ? profilePoints : bookingPoints;

  if (profilePoints === 0 && !hasRedemptions && bookingPoints > 0) {
    const { error } = await supabase
      .from('profiles')
      .update({ tier_points: bookingPoints })
      .eq('id', userId);

    if (error) {
      console.warn('[Loyalty] backfill tier_points failed:', error.message);
    }
  }

  return {
    profilePoints,
    bookingPoints,
    effectivePoints,
    completedBookings,
  };
}

export async function redeemRewardPoints(userId: string, reward: LoyaltyReward): Promise<number> {
  const profile = await fetchProfile(userId);
  const currentPoints = Number(profile?.tier_points ?? 0);
  if (currentPoints < reward.points) {
    throw new Error('Insufficient points to redeem this reward.');
  }

  const nextPoints = currentPoints - reward.points;

  const { error: profileError } = await supabase
    .from('profiles')
    .update({ tier_points: nextPoints })
    .eq('id', userId);

  if (profileError) {
    throw profileError;
  }

  const { error: insertError } = await supabase
    .from('reward_redemptions')
    .insert({
      user_id: userId,
      reward_id: reward.id,
      reward_title: reward.title,
      points_spent: reward.points,
      status: 'redeemed',
    });

  if (insertError) {
    console.warn('[Loyalty] reward_redemptions insert failed:', insertError.message);
  }

  return nextPoints;
}

export async function getLoyaltyActivity(userId: string): Promise<
  Array<{
    id: string;
    label: string;
    pointsLabel: string;
    date: string;
    kind: 'earn' | 'redeem';
  }>
> {
  const [bookingsRes, redemptionsRes] = await Promise.all([
    supabase
      .from('bookings')
      .select('id, service_name, service_type, loyalty_reward_processed_at, completed_at')
      .eq('user_id', userId)
      .not('loyalty_reward_processed_at', 'is', null)
      .order('loyalty_reward_processed_at', { ascending: false })
      .limit(6),
    supabase
      .from('reward_redemptions')
      .select('id, reward_title, points_spent, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(4),
  ]);

  const earned = (bookingsRes.data ?? []).map((row: {
    id: string;
    service_name?: string | null;
    service_type?: string | null;
    loyalty_reward_processed_at?: string | null;
    completed_at?: string | null;
  }) => ({
    id: `earn-${row.id}`,
    label: row.service_name || row.service_type || 'Wash completed',
    pointsLabel: `+${REWARD_POINTS_PER_BOOKING}`,
    date: row.loyalty_reward_processed_at || row.completed_at || new Date().toISOString(),
    kind: 'earn' as const,
  }));

  const redeemed = (redemptionsRes.data ?? []).map((row: {
    id: string;
    reward_title?: string | null;
    points_spent?: number | null;
    created_at?: string | null;
  }) => ({
    id: `redeem-${row.id}`,
    label: row.reward_title || 'Reward redeemed',
    pointsLabel: `-${Number(row.points_spent ?? 0)}`,
    date: row.created_at || new Date().toISOString(),
    kind: 'redeem' as const,
  }));

  return [...earned, ...redeemed]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 8);
}

export async function grantCompletedBookingLoyalty(userId: string, bookingId: string): Promise<{
  customerPointsAwarded: number;
  customerBalance: number;
  referralBonusAwarded: number;
}> {
  const [bookingResult, profileResult] = await Promise.all([
    supabase
      .from('bookings')
      .select('id, loyalty_reward_processed_at')
      .eq('id', bookingId)
      .maybeSingle(),
    fetchProfile(userId),
  ]);

  if (bookingResult.error) {
    throw bookingResult.error;
  }

  const booking = bookingResult.data as { id: string; loyalty_reward_processed_at?: string | null } | null;
  if (!booking) {
    return {
      customerPointsAwarded: 0,
      customerBalance: Number(profileResult?.tier_points ?? 0),
      referralBonusAwarded: 0,
    };
  }

  const currentPoints = Number(profileResult?.tier_points ?? 0);
  let customerPointsAwarded = 0;
  let customerBalance = currentPoints;

  if (!booking.loyalty_reward_processed_at) {
    customerPointsAwarded = REWARD_POINTS_PER_BOOKING;
    customerBalance = currentPoints + customerPointsAwarded;

    const [bookingUpdate, profileUpdate] = await Promise.all([
      supabase
        .from('bookings')
        .update({
          loyalty_reward_processed_at: new Date().toISOString(),
        })
        .eq('id', bookingId),
      supabase
        .from('profiles')
        .update({ tier_points: customerBalance })
        .eq('id', userId),
    ]);

    if (bookingUpdate.error) throw bookingUpdate.error;
    if (profileUpdate.error) throw profileUpdate.error;
  }

  let referralBonusAwarded = 0;
  if (profileResult?.referred_by) {
    const { data: referralRow, error: referralError } = await supabase
      .from('referrals')
      .select('id, referrer_id, referee_id, status, reward_amount, completed_at, reward_granted_at')
      .eq('referee_id', userId)
      .maybeSingle();

    if (referralError) {
      console.warn('[Loyalty] referral lookup failed:', referralError.message);
    } else {
      const existingReferral = referralRow as ReferralRow | null;
      if (existingReferral?.status !== 'rewarded') {
        const bonus = Number(existingReferral?.reward_amount ?? REFERRAL_BONUS_POINTS);
        const { data: referrerProfile, error: referrerError } = await supabase
          .from('profiles')
          .select('id, tier_points')
          .eq('id', profileResult.referred_by)
          .maybeSingle();

        if (referrerError) {
          console.warn('[Loyalty] referrer lookup failed:', referrerError.message);
        } else {
          const referrerPoints = Number((referrerProfile as ProfileRow | null)?.tier_points ?? 0);
          const referrerBalance = referrerPoints + bonus;
          const [referrerUpdate, referralUpdate] = await Promise.all([
            supabase
              .from('profiles')
              .update({ tier_points: referrerBalance })
              .eq('id', profileResult.referred_by),
            existingReferral
              ? supabase
                  .from('referrals')
                  .update({
                    status: 'rewarded',
                    completed_at: existingReferral.completed_at ?? new Date().toISOString(),
                    reward_granted_at: new Date().toISOString(),
                  })
                  .eq('id', existingReferral.id)
              : (async () => {
                  const { data: referrerLookup } = await supabase
                    .from('profiles')
                    .select('id, referral_code')
                    .eq('id', profileResult.referred_by)
                    .maybeSingle();
                  return supabase
                    .from('referrals')
                    .insert({
                      referrer_id: profileResult.referred_by,
                      referee_id: userId,
                      referral_code: (referrerLookup as ProfileRow | null)?.referral_code ?? generateReferralCode(profileResult.referred_by ?? userId),
                      status: 'rewarded',
                      reward_amount: bonus,
                      completed_at: new Date().toISOString(),
                      reward_granted_at: new Date().toISOString(),
                    });
                })(),
          ]);

          if (referrerUpdate.error) {
            console.warn('[Loyalty] referrer points update failed:', referrerUpdate.error.message);
          } else {
            referralBonusAwarded = bonus;
          }

          if (referralUpdate.error) {
            console.warn('[Loyalty] referral reward update failed:', referralUpdate.error.message);
          }
        }
      }
    }
  }

  return {
    customerPointsAwarded,
    customerBalance,
    referralBonusAwarded,
  };
}
