import { supabase } from '../lib/supabase';

export type BookingChatSenderRole = 'customer' | 'valeter';
export type BookingChatMessageType = 'text' | 'image' | 'voice' | 'payment_request';

export type BookingPaymentRequestStatus = 'pending' | 'paid' | 'failed';

export type BookingPaymentRequestPayload = {
  kind?: 'booking_payment_request';
  amount?: number;
  currency?: string;
  reason?: string;
  note?: string | null;
  platformFee?: number;
  valeterShare?: number;
  status?: BookingPaymentRequestStatus;
  paymentIntentId?: string | null;
  paymentIntentClientSecret?: string | null;
  requestedAt?: string | null;
  paidAt?: string | null;
  requestedBy?: string | null;
  requestedByRole?: BookingChatSenderRole | string | null;
};

export type BookingChatMessageRow = {
  id: string;
  booking_id: string;
  sender_id: string;
  sender_role: BookingChatSenderRole;
  message_type: BookingChatMessageType;
  content?: string | null;
  media_url?: string | null;
  voice_duration_seconds?: number | null;
  read_at?: string | null;
  created_at: string;
};

export type BookingChatNotificationThread = {
  bookingId: string;
  unreadCount: number;
  latestMessageAt: string;
  latestMessagePreview: string;
  bookingStatus?: string | null;
  serviceName?: string | null;
  serviceType?: string | null;
  scheduledAt?: string | null;
  timeSlot?: string | null;
  locationAddress?: string | null;
  address?: string | null;
  valeterName?: string | null;
};

export function parseBookingChatPaymentRequest(content?: string | null): BookingPaymentRequestPayload | null {
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as BookingPaymentRequestPayload;
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed.kind === 'booking_payment_request' ? parsed : null;
  } catch {
    return null;
  }
}

type SendBookingChatMessageInput = {
  bookingId: string;
  senderId: string;
  senderRole: BookingChatSenderRole;
  content: string;
  mediaUrl?: string | null;
  voiceDurationSeconds?: number | null;
  messageType?: BookingChatMessageType;
};

export async function loadBookingChatMessages(bookingId: string): Promise<BookingChatMessageRow[]> {
  const { data, error } = await supabase
    .from('booking_messages')
    .select('*')
    .eq('booking_id', bookingId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return (data ?? []) as BookingChatMessageRow[];
}

export async function sendBookingChatMessage(input: SendBookingChatMessageInput): Promise<BookingChatMessageRow> {
  const row = {
    booking_id: input.bookingId,
    sender_id: input.senderId,
    sender_role: input.senderRole,
    message_type: input.messageType ?? (input.mediaUrl ? 'image' : 'text'),
    content: input.content.trim() || null,
    media_url: input.mediaUrl ?? null,
    voice_duration_seconds: input.voiceDurationSeconds ?? null,
  };

  const { data, error } = await supabase
    .from('booking_messages')
    .insert(row)
    .select('*')
    .single();

  if (error) throw error;

  const now = new Date().toISOString();
  await supabase.from('bookings').update({ updated_at: now }).eq('id', input.bookingId);

  return data as BookingChatMessageRow;
}

function buildUnreadChatPreview(message: BookingChatMessageRow): string {
  const content = message.content?.trim();

  if (message.message_type === 'payment_request') {
    return 'New payment request';
  }

  if (message.message_type === 'image') {
    return content || 'Sent a photo';
  }

  if (message.message_type === 'voice') {
    return 'Sent a voice note';
  }

  return content || 'New message';
}

export async function fetchUnreadBookingChatThreads(userId: string): Promise<BookingChatNotificationThread[]> {
  const { data: unreadMessages, error } = await supabase
    .from('booking_messages')
    .select('id,booking_id,sender_role,message_type,content,created_at')
    .eq('sender_role', 'valeter')
    .is('read_at', null)
    .order('created_at', { ascending: false })
    .limit(200);

  if (error || !unreadMessages?.length) return [];

  const bookingIds = Array.from(new Set(unreadMessages.map((message) => message.booking_id)));
  const { data: bookings, error: bookingsError } = await supabase
    .from('bookings')
    .select(
      'id,status,service_name,service_type,scheduled_at,time_slot,location_address,address,valeter_name,user_id'
    )
    .eq('user_id', userId)
    .in('id', bookingIds);

  if (bookingsError || !bookings?.length) return [];

  const bookingMap = new Map<string, (typeof bookings)[number]>();
  bookings.forEach((booking) => {
    bookingMap.set(String(booking.id), booking);
  });

  const grouped = new Map<string, BookingChatNotificationThread>();

  unreadMessages.forEach((message) => {
    const booking = bookingMap.get(String(message.booking_id));
    if (!booking) return;

    const existing = grouped.get(String(message.booking_id));
    const latestMessageAt = message.created_at;
    const nextPreview = buildUnreadChatPreview(message as BookingChatMessageRow);

    if (!existing) {
      grouped.set(String(message.booking_id), {
        bookingId: String(message.booking_id),
        unreadCount: 1,
        latestMessageAt,
        latestMessagePreview: nextPreview,
        bookingStatus: booking.status ?? null,
        serviceName: booking.service_name ?? null,
        serviceType: booking.service_type ?? null,
        scheduledAt: booking.scheduled_at ?? null,
        timeSlot: booking.time_slot ?? null,
        locationAddress: booking.location_address ?? null,
        address: booking.address ?? null,
        valeterName: booking.valeter_name ?? null,
      });
      return;
    }

    existing.unreadCount += 1;
    if (new Date(latestMessageAt).getTime() >= new Date(existing.latestMessageAt).getTime()) {
      existing.latestMessageAt = latestMessageAt;
      existing.latestMessagePreview = nextPreview;
    }
  });

  return Array.from(grouped.values()).sort(
    (a, b) => new Date(b.latestMessageAt).getTime() - new Date(a.latestMessageAt).getTime()
  );
}

export async function markBookingChatMessagesAsRead(bookingId: string, recipientRole: BookingChatSenderRole) {
  const senderRole: BookingChatSenderRole = recipientRole === 'customer' ? 'valeter' : 'customer';

  const { error } = await supabase
    .from('booking_messages')
    .update({ read_at: new Date().toISOString() })
    .eq('booking_id', bookingId)
    .eq('sender_role', senderRole)
    .is('read_at', null);

  if (error) throw error;
}

export function subscribeToBookingChatMessages(
  bookingId: string,
  onInsert: (message: BookingChatMessageRow) => void,
) {
  const handler = (payload: { new?: BookingChatMessageRow | null; old?: BookingChatMessageRow | null }) => {
    const row = (payload.new ?? payload.old) as BookingChatMessageRow | undefined;
    if (row) onInsert(row);
  };

  return supabase
    .channel(`booking-chat-${bookingId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'booking_messages',
        filter: `booking_id=eq.${bookingId}`,
      },
      handler,
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'booking_messages',
        filter: `booking_id=eq.${bookingId}`,
      },
      handler,
    )
    .subscribe();
}
