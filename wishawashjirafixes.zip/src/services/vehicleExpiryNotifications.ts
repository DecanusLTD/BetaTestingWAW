import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabase';

type ExpiryKind = 'tax' | 'mot';

type CustomerVehicleExpiry = {
  id: string;
  make?: string | null;
  model?: string | null;
  registration?: string | null;
  tax_expiry?: string | null;
  mot_expiry?: string | null;
};

const NOTIFICATION_ID_PREFIX = 'vehicle-expiry';
const NOTIFIED_STORAGE_PREFIX = 'waw:vehicle-expiry-notified:v1';

function buildVehicleLabel(vehicle: CustomerVehicleExpiry): string {
  const registration = vehicle.registration?.trim();
  if (registration) return registration;

  const parts = [vehicle.make?.trim(), vehicle.model?.trim()].filter(Boolean);
  if (parts.length > 0) return parts.join(' ');

  return 'your vehicle';
}

function notificationId(vehicleId: string, kind: ExpiryKind): string {
  return `${NOTIFICATION_ID_PREFIX}:${kind}:${vehicleId}`;
}

function notifiedStorageKey(userId: string): string {
  return `${NOTIFIED_STORAGE_PREFIX}:${userId}`;
}

function buildContent(vehicle: CustomerVehicleExpiry, kind: ExpiryKind) {
  const label = buildVehicleLabel(vehicle);
  const title = kind === 'tax' ? 'Tax expired' : 'MOT expired';

  return {
    title,
    body: `One of your vehicles, ${label}, has expired.`,
    data: {
      screen: '/owner/settings/vehicle-management',
      vehicleId: vehicle.id,
      expiryKind: kind,
      vehicleLabel: label,
    },
  } as const;
}

async function scheduleForExpiry(
  id: string,
  content: ReturnType<typeof buildContent>,
  expiryDate: Date
): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined);
  await Notifications.scheduleNotificationAsync({
    identifier: id,
    content,
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: expiryDate },
  });
}

async function sendImmediateNotification(id: string, content: ReturnType<typeof buildContent>): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined);
  await Notifications.scheduleNotificationAsync({
    identifier: id,
    content,
    trigger: null,
  });
}

/**
 * Keeps MOT/tax reminders in sync for the signed-in customer.
 * Future dates are scheduled locally; expired items fire immediately once per expiry date.
 */
export async function syncCustomerVehicleExpiryNotifications(userId: string): Promise<void> {
  if (!userId || Platform.OS === 'web') return;

  try {
    const { data: vehicles, error } = await supabase
      .from('customer_vehicles')
      .select('id,make,model,registration,tax_expiry,mot_expiry')
      .eq('user_id', userId);

    if (error) {
      if (__DEV__) console.warn('[vehicleExpiryNotifications] vehicle fetch failed', error.message);
      return;
    }

    if (!vehicles?.length) {
      const scheduled = await Notifications.getAllScheduledNotificationsAsync().catch(() => []);
      await Promise.all(
        scheduled
          .filter((request) => String(request.identifier ?? '').startsWith(`${NOTIFICATION_ID_PREFIX}:`))
          .map((request) => Notifications.cancelScheduledNotificationAsync(String(request.identifier)).catch(() => undefined))
      );
      await AsyncStorage.removeItem(notifiedStorageKey(userId));
      return;
    }

    const now = Date.now();
    const activeIds = new Set<string>();

    let notifiedRaw = await AsyncStorage.getItem(notifiedStorageKey(userId));
    let notified: Record<string, string> = {};
    if (notifiedRaw) {
      try {
        notified = JSON.parse(notifiedRaw) as Record<string, string>;
      } catch {
        notified = {};
      }
    }

    for (const vehicle of vehicles as CustomerVehicleExpiry[]) {
      for (const kind of ['tax', 'mot'] as const) {
        const expiryValue = kind === 'tax' ? vehicle.tax_expiry : vehicle.mot_expiry;
        const id = notificationId(vehicle.id, kind);

        if (!expiryValue) {
          await Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined);
          delete notified[id];
          continue;
        }

        const expiryDate = new Date(expiryValue);
        if (Number.isNaN(expiryDate.getTime())) {
          await Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined);
          delete notified[id];
          continue;
        }

        activeIds.add(id);
        const content = buildContent(vehicle, kind);

        if (expiryDate.getTime() <= now) {
          if (notified[id] !== expiryValue) {
            await sendImmediateNotification(id, content);
            notified[id] = expiryValue;
          } else {
            await Notifications.cancelScheduledNotificationAsync(id).catch(() => undefined);
          }
          continue;
        }

        await scheduleForExpiry(id, content, expiryDate);
        notified[id] = expiryValue;
      }
    }

    const scheduled = await Notifications.getAllScheduledNotificationsAsync().catch(() => []);
    await Promise.all(
      scheduled
        .map((request) => String(request.identifier ?? ''))
        .filter((identifier) => identifier.startsWith(`${NOTIFICATION_ID_PREFIX}:`) && !activeIds.has(identifier))
        .map((identifier) => Notifications.cancelScheduledNotificationAsync(identifier).catch(() => undefined))
    );

    await AsyncStorage.setItem(notifiedStorageKey(userId), JSON.stringify(notified));
  } catch (error) {
    if (__DEV__) console.warn('[vehicleExpiryNotifications] sync failed', error);
  }
}
