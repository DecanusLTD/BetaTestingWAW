import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, BOOKING_GLASS_TOP_SHEEN, BOOKING_GLASS_TOP_SHEEN_LOCATIONS } from '../../constants/bookingCardTheme';
import { formatDisplayName } from '../../utils/formatDisplayName';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { CCP } from '../../constants/carCareProLabels';
import SearchingProState from './SearchingProState';

const SKY = colors.SKY;

export type TopCareProCardData = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  reviewCount?: number;
  distance?: number | null;
  isOnline: boolean;
  profilePicture?: string | null;
  isFavourite?: boolean;
  /** Customer total for the selected service (incl. fee), when known. */
  price?: number | null;
};

type Props = {
  pro?: TopCareProCardData | null;
  width?: number;
  accent?: string;
  borderColor?: string;
  rank?: number;
  variant?: 'default' | 'compact';
  /** Scales the default card layout (1 = full size). */
  zoom?: number;
  /** Same card chrome as Pros, used while matching / loading nearby Pros. */
  searching?: boolean;
  searchingTitle?: string;
  searchingSubtitle?: string;
  searchingBusy?: boolean;
  onPress?: () => void;
  onToggleFavourite?: () => void;
  onBook?: () => void;
  style?: StyleProp<ViewStyle>;
};

const RANK_COLORS: Record<number, string> = {
  1: '#FBBF24',
  2: '#CBD5E1',
  3: '#D97706',
};

function StatChip({
  icon,
  label,
  iconColor = SKY,
  iconSize = 12,
  fontSize = 12,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  iconColor?: string;
  iconSize?: number;
  fontSize?: number;
}) {
  return (
    <View style={styles.statChip}>
      <Ionicons name={icon} size={iconSize} color={iconColor} />
      <Text style={[styles.statChipText, { fontSize }]} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

function buildCompactMeta(pro: TopCareProCardData): string {
  const parts: string[] = [];
  parts.push(pro.rating > 0 ? `${pro.rating.toFixed(1)} ★` : 'New');
  parts.push(`${pro.totalJobs} jobs`);
  if (pro.distance != null) parts.push(`${pro.distance.toFixed(1)} mi`);
  else if (pro.reviewCount != null && pro.reviewCount > 0) {
    parts.push(`${pro.reviewCount} reviews`);
  }
  if (pro.price != null && Number.isFinite(pro.price)) {
    parts.push(`£${Number(pro.price).toFixed(2)}`);
  }
  parts.push(pro.isOnline ? 'Available' : 'Offline');
  return parts.join(' · ');
}

export default function TopCareProCard({
  pro,
  width,
  accent = SKY,
  borderColor = 'rgba(125,211,252,0.38)',
  rank,
  variant = 'default',
  zoom = 1,
  searching = false,
  searchingTitle,
  searchingSubtitle,
  searchingBusy = false,
  onPress,
  onToggleFavourite,
  onBook,
  style,
}: Props) {
  const displayName = formatDisplayName(pro?.name) || pro?.name || CCP.fallbackName;
  const onlineColor = pro?.isOnline ? '#34D399' : '#94A3B8';
  const rankColor = rank != null ? RANK_COLORS[rank] ?? accent : null;
  const isCompact = variant === 'compact';
  const z = (n: number) => Math.round(n * zoom);

  if (searching) {
    return (
      <View style={[styles.wrap, width != null && { width }, styles.searchingWrap, style]}>
        <SearchingProState
          accent={accent}
          title={searchingTitle}
          subtitle={searchingSubtitle}
          busy={searchingBusy}
          zoom={zoom}
        />
      </View>
    );
  }

  if (!pro) return null;

  if (isCompact) {
    return (
      <View style={[styles.wrap, width != null && { width }, style]}>
        <TouchableOpacity
          onPress={onPress ?? (() => {})}
          activeOpacity={0.88}
          style={[styles.cardCompact, { borderColor: borderColor.replace('0.38', '0.22').replace('0.4', '0.22') }]}
        >
          <BlurView intensity={22} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={[accent + '12', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />

          <View style={styles.padCompact}>
            <View style={styles.compactAvatarCol}>
              <View style={[styles.avatarRingCompact, { borderColor: pro.isOnline ? onlineColor + '99' : 'rgba(148,163,184,0.35)' }]}>
                {pro.profilePicture ? (
                  <Image source={{ uri: pro.profilePicture }} style={styles.avatarImgCompact} />
                ) : (
                  <GradientIconBox
                    icon="car-sport-outline"
                    colors={accentToGradient(accent)}
                    boxSize={34}
                    borderRadius={10}
                    size={17}
                  />
                )}
              </View>
              {rank != null && rank <= 3 ? (
                <View style={[styles.rankBadgeCompact, { backgroundColor: rankColor + 'E6', borderColor: rankColor }]}>
                  <Text style={styles.rankBadgeTextCompact}>#{rank}</Text>
                </View>
              ) : null}
            </View>

            <View style={styles.compactMain}>
              <Text style={styles.compactName} numberOfLines={1}>
                {displayName}
              </Text>
              <Text style={styles.compactMeta} numberOfLines={1}>
                {buildCompactMeta(pro)}
              </Text>
            </View>

            {onToggleFavourite ? (
              <TouchableOpacity onPress={onToggleFavourite} hitSlop={8} style={styles.compactHeart}>
                <Ionicons
                  name={pro.isFavourite ? 'heart' : 'heart-outline'}
                  size={16}
                  color={pro.isFavourite ? '#F87171' : 'rgba(148,163,184,0.65)'}
                />
              </TouchableOpacity>
            ) : (
              <Ionicons name="chevron-forward" size={16} color="rgba(148,163,184,0.45)" />
            )}
          </View>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, width != null && { width }, style]}>
      <TouchableOpacity
        onPress={onPress ?? (() => {})}
        activeOpacity={0.9}
        style={[
          styles.card,
          {
            borderColor,
            minHeight: z(132),
            borderRadius: z(BOOKING_CARD.BORDER_RADIUS),
          },
        ]}
      >
        <BlurView intensity={42} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={[accent + '22', accent + '08', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={[...BOOKING_GLASS_TOP_SHEEN]}
          locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0.85 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={[styles.topAccent, { backgroundColor: accent }]} pointerEvents="none" />

        <View style={[styles.pad, { padding: z(14), gap: z(12) }]}>
          <View style={[styles.heroRow, { gap: z(12) }]}>
            <View style={styles.avatarCol}>
              <View
                style={[
                  styles.avatarRing,
                  {
                    borderColor: pro.isOnline ? onlineColor + 'CC' : 'rgba(148,163,184,0.45)',
                    width: z(56),
                    height: z(56),
                    borderRadius: z(18),
                  },
                ]}
              >
                <View style={[styles.avatarInner, { backgroundColor: accent + '20', borderRadius: z(14) }]}>
                  {pro.profilePicture ? (
                    <Image
                      source={{ uri: pro.profilePicture }}
                      style={[styles.avatarImg, { width: z(48), height: z(48), borderRadius: z(14) }]}
                    />
                  ) : (
                    <GradientIconBox
                      icon="car-sport-outline"
                      colors={accentToGradient(accent)}
                      boxSize={z(48)}
                      borderRadius={z(14)}
                      elevated
                      size={z(24)}
                    />
                  )}
                </View>
                <View
                  style={[
                    styles.onlineDot,
                    {
                      backgroundColor: onlineColor,
                      width: z(14),
                      height: z(14),
                      borderRadius: z(7),
                    },
                  ]}
                />
              </View>
              {rank != null && rank <= 3 ? (
                <View
                  style={[
                    styles.rankBadge,
                    {
                      backgroundColor: rankColor + 'E6',
                      borderColor: rankColor,
                      minWidth: z(22),
                      height: z(22),
                      borderRadius: z(11),
                    },
                  ]}
                >
                  <Text style={[styles.rankBadgeText, { fontSize: z(10) }]}>#{rank}</Text>
                </View>
              ) : null}
            </View>

            <View style={[styles.mainCol, { gap: z(6) }]}>
              <View style={styles.titleRow}>
                <View style={[styles.titleBlock, { gap: z(2) }]}>
                  <Text style={[styles.kicker, { color: accent, fontSize: z(9) }]}>{CCP.singularShort.toUpperCase()}</Text>
                  <Text style={[styles.name, { fontSize: z(17) }]} numberOfLines={1}>
                    {displayName}
                  </Text>
                </View>
                {onToggleFavourite ? (
                  <TouchableOpacity
                    onPress={onToggleFavourite}
                    hitSlop={10}
                    style={styles.heartBtn}
                    accessibilityLabel={
                      pro.isFavourite ? `Remove ${displayName} from favourites` : `Save ${displayName} to favourites`
                    }
                  >
                    <Ionicons
                      name={pro.isFavourite ? 'heart' : 'heart-outline'}
                      size={z(20)}
                      color={pro.isFavourite ? '#F87171' : 'rgba(248,250,252,0.75)'}
                    />
                  </TouchableOpacity>
                ) : null}
              </View>

              <View style={styles.statusRow}>
                <View
                  style={[
                    styles.statusPill,
                    {
                      backgroundColor: onlineColor + '22',
                      borderColor: onlineColor + '55',
                      paddingHorizontal: z(8),
                      paddingVertical: z(4),
                    },
                  ]}
                >
                  <View style={[styles.statusDot, { backgroundColor: onlineColor, width: z(6), height: z(6), borderRadius: z(3) }]} />
                  <Text style={[styles.statusText, { color: onlineColor, fontSize: z(11) }]}>
                    {pro.isOnline ? 'Available now' : 'Offline'}
                  </Text>
                </View>
              </View>
            </View>
          </View>

          <View
            style={[
              styles.statsRow,
              {
                gap: z(6),
                paddingTop: z(10),
              },
            ]}
          >
            <StatChip
              icon="star"
              label={pro.rating > 0 ? pro.rating.toFixed(1) : 'New'}
              iconColor="#FBBF24"
              iconSize={z(12)}
              fontSize={z(12)}
            />
            <View style={[styles.statDivider, { height: z(12) }]} />
            <StatChip icon="checkmark-done-outline" label={`${pro.totalJobs} jobs`} iconSize={z(12)} fontSize={z(12)} />
            {pro.distance != null ? (
              <>
                <View style={[styles.statDivider, { height: z(12) }]} />
                <StatChip icon="navigate-outline" label={`${pro.distance.toFixed(1)} mi`} iconSize={z(12)} fontSize={z(12)} />
              </>
            ) : pro.reviewCount != null ? (
              <>
                <View style={[styles.statDivider, { height: z(12) }]} />
                <StatChip
                  icon="chatbubble-outline"
                  label={
                    pro.reviewCount > 0
                      ? `${pro.reviewCount} ${pro.reviewCount === 1 ? 'review' : 'reviews'}`
                      : 'No reviews'
                  }
                  iconSize={z(12)}
                  fontSize={z(12)}
                />
              </>
            ) : null}
            {pro.price != null && Number.isFinite(pro.price) ? (
              <>
                <View style={[styles.statDivider, { height: z(12) }]} />
                <StatChip
                  icon="pricetag-outline"
                  label={`£${Number(pro.price).toFixed(2)}`}
                  iconColor={accent}
                  iconSize={z(12)}
                  fontSize={z(12)}
                />
              </>
            ) : null}
          </View>

          {onBook ? (
            <TouchableOpacity
              onPress={onBook}
              style={[
                styles.bookBtn,
                {
                  borderColor: accent + '66',
                  backgroundColor: accent + '18',
                  borderRadius: z(12),
                  paddingVertical: z(10),
                  paddingHorizontal: z(18),
                  alignSelf: 'stretch',
                  width: '100%',
                },
              ]}
              activeOpacity={0.88}
            >
              <Ionicons name="flash" size={z(15)} color={accent} />
              <Text style={[styles.bookBtnText, { color: accent, fontSize: z(13) }]}>{CCP.requestButton}</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignSelf: 'stretch',
  },
  searchingWrap: {
    backgroundColor: 'transparent',
  },
  cardCompact: {
    minHeight: 72,
    overflow: 'hidden',
    borderRadius: 14,
    backgroundColor: 'rgba(8,20,38,0.38)',
    borderWidth: StyleSheet.hairlineWidth * 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 2,
  },
  padCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  compactAvatarCol: {
    position: 'relative',
  },
  avatarRingCompact: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1.5,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarImgCompact: {
    width: 40,
    height: 40,
    borderRadius: 12,
  },
  rankBadgeCompact: {
    position: 'absolute',
    top: -5,
    left: -5,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  rankBadgeTextCompact: {
    color: '#0F172A',
    fontSize: 8,
    fontWeight: '900',
  },
  compactMain: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  compactName: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.1,
  },
  compactMeta: {
    color: 'rgba(148,163,184,0.92)',
    fontSize: 11,
    fontWeight: '600',
  },
  compactHeart: {
    padding: 2,
  },
  card: {
    minHeight: 132,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(6,16,32,0.55)',
    borderWidth: 1,
    shadowColor: 'rgba(56,189,248,0.18)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.32,
    shadowRadius: 14,
    elevation: 6,
  },
  topAccent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
  },
  pad: {
    padding: 14,
    gap: 12,
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  avatarCol: {
    position: 'relative',
  },
  avatarRing: {
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 2,
    padding: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarInner: {
    width: '100%',
    height: '100%',
    borderRadius: 14,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarImg: {
    width: 48,
    height: 48,
    borderRadius: 14,
  },
  onlineDot: {
    position: 'absolute',
    bottom: -1,
    right: -1,
    width: 14,
    height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: 'rgba(8,20,38,0.95)',
  },
  rankBadge: {
    position: 'absolute',
    top: -6,
    left: -6,
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  rankBadgeText: {
    color: '#0F172A',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: -0.2,
  },
  mainCol: {
    flex: 1,
    minWidth: 0,
    gap: 6,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  titleBlock: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  kicker: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  name: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.1,
  },
  heartBtn: {
    padding: 2,
    marginTop: 2,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.14)',
  },
  statChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statChipText: {
    color: 'rgba(226,232,240,0.92)',
    fontSize: 12,
    fontWeight: '700',
  },
  statDivider: {
    width: 1,
    height: 12,
    backgroundColor: 'rgba(148,163,184,0.28)',
  },
  bookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 10,
  },
  bookBtnText: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});
