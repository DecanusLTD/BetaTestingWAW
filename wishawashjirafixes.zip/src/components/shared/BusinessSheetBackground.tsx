/**
 * Shared fill for map bottom sheets — matches “Where’s the ride?” header glass.
 */
import React from 'react';
import BookingMapGlassBackground from '../booking/BookingMapGlassBackground';

export default function BusinessSheetBackground() {
  return <BookingMapGlassBackground />;
}
