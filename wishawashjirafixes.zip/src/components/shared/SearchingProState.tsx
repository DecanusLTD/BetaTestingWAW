import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { CCP } from '../../constants/carCareProLabels';

const SKY = colors.SKY;

type Props = {
  accent?: string;
  title?: string;
  subtitle?: string;
  busy?: boolean;
  zoom?: number;
};

export default function SearchingProState({
  accent = SKY,
  title,
  busy = true,
  zoom = 1,
}: Props) {
  const z = (n: number) => Math.round(n * zoom);
  const pulse = useRef(new Animated.Value(0)).current;

  const resolvedTitle =
    title ||
    (busy ? `Searching for ${CCP.pluralShort}…` : `Searching for a ${CCP.singularShort}`);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1200,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  const ringStyle = {
    opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.42, 0] }),
    transform: [
      {
        scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.82, 1.55] }),
      },
    ],
  };

  return (
    <View style={[styles.wrap, { padding: z(16), gap: z(14) }]}>
      <Text style={[styles.title, { color: accent, fontSize: z(13) }]} numberOfLines={1}>
        {resolvedTitle}
      </Text>

      <View style={[styles.iconShell, { width: z(82), height: z(82) }]}>
        <Animated.View
          pointerEvents="none"
          style={[
            styles.pulseRing,
            {
              borderColor: accent + '66',
              width: z(82),
              height: z(82),
              borderRadius: z(41),
            },
            ringStyle,
          ]}
        />
        <View
          style={[
            styles.iconCore,
            {
              width: z(62),
              height: z(62),
              borderRadius: z(22),
              borderColor: accent + '66',
              backgroundColor: accent + '1A',
            },
          ]}
        >
          <Ionicons name="search" size={z(24)} color={accent} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: '#F8FAFC',
    fontWeight: '800',
    letterSpacing: -0.2,
    textAlign: 'center',
  },
  iconShell: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseRing: {
    position: 'absolute',
    borderWidth: 1.5,
  },
  iconCore: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth * 2,
    overflow: 'hidden',
  },
});
