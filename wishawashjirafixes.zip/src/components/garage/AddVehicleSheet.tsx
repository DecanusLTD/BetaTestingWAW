import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  ActivityIndicator,
  Pressable,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BookingBottomSheetOverlay from '../booking/BookingBottomSheetOverlay';
import { colors } from '../../constants/colors';
import { BOOKING_CARD } from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  getComplianceAccent,
  getComplianceExpiryHint,
  getDaysUntilExpiry,
  getVehicleDocComplianceState,
} from '../../utils/vehicleComplianceStatus';

const SKY = colors.SKY;
const WINDOW_H = Dimensions.get('window').height;

export type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';
export type AddMode = 'reg' | 'manual';

export type VehicleFormData = {
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  size: VehicleSize;
  mot_status: string;
  mot_expiry_date: string;
  tax_status: string;
  tax_due_date: string;
  image_url: string;
  image_path: string;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  editingVehicleId: string | null;
  addMode: AddMode;
  setAddMode: (mode: AddMode) => void;
  formData: VehicleFormData;
  setFormData: React.Dispatch<React.SetStateAction<VehicleFormData>>;
  dvlaLoading: boolean;
  dvlaTouched: boolean;
  uploadingImage: boolean;
  onRegistrationChange: (registration: string) => void;
  onDvlaRefresh: () => Promise<void>;
  onPickImage: () => void;
  onRemoveImage: () => void;
  onSave: () => void;
  formatDatePretty: (dateOnly: string | null | undefined) => string;
  getSizeLabel: (size?: VehicleSize) => string;
  getSizeIcon: (size?: VehicleSize) => string;
};

function UkRegInput({ value, onChangeText, loading }: { value: string; onChangeText: (t: string) => void; loading: boolean }) {
  return (
    <View style={styles.regHero}>
      <LinearGradient
        colors={['rgba(56,189,248,0.14)', 'rgba(2,6,23,0.55)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <Text style={styles.regHeroKicker}>UK REGISTRATION</Text>
      <View style={styles.regPlateInputWrap}>
        <View style={styles.regPlateBand}>
          <Text style={styles.regPlateBandText}>GB</Text>
        </View>
        <TextInput
          style={styles.regPlateInput}
          value={value}
          onChangeText={onChangeText}
          placeholder="AB12 CDE"
          placeholderTextColor="rgba(15,23,42,0.35)"
          autoCapitalize="characters"
          editable={!loading}
          autoCorrect={false}
        />
      </View>
      {loading ? (
        <View style={styles.regLookupRow}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={styles.regLookupText}>Fetching DVLA details…</Text>
        </View>
      ) : (
        <Text style={styles.regHint}>We'll pull make, colour, size, MOT & tax automatically</Text>
      )}
    </View>
  );
}

function DvlaComplianceRow({
  label,
  status,
  expiryDate,
  formatDatePretty,
}: {
  label: string;
  status: string;
  expiryDate: string;
  formatDatePretty: (dateOnly: string | null | undefined) => string;
}) {
  const state = getVehicleDocComplianceState(status || null, expiryDate || null);
  const accent = getComplianceAccent(state);
  const daysUntil = getDaysUntilExpiry(expiryDate || null);
  const hint = getComplianceExpiryHint(state, daysUntil);
  return (
    <View style={[styles.dvlaItem, state !== 'unknown' && { borderLeftWidth: 3, borderLeftColor: accent, paddingLeft: 10 }]}>
      <Text style={[styles.dvlaItemLabel, { color: accent }]}>{label}</Text>
      <Text style={styles.dvlaItemValue}>
        {status || '—'}
        {expiryDate ? ` · ${formatDatePretty(expiryDate)}` : ''}
        {hint ? <Text style={{ color: accent, fontWeight: '700' }}> · {hint}</Text> : null}
      </Text>
    </View>
  );
}

export default function AddVehicleSheet({
  visible,
  onClose,
  editingVehicleId,
  addMode,
  setAddMode,
  formData,
  setFormData,
  dvlaLoading,
  dvlaTouched,
  uploadingImage,
  onRegistrationChange,
  onDvlaRefresh,
  onPickImage,
  onRemoveImage,
  onSave,
  formatDatePretty,
  getSizeLabel,
  getSizeIcon,
}: Props) {
  const insets = useSafeAreaInsets();
  const isEdit = Boolean(editingVehicleId);

  const sheetMinHeight = useMemo(() => Math.min(WINDOW_H * 0.68, 620), []);
  const scrollMaxHeight = useMemo(() => Math.min(WINDOW_H * 0.46, 380), []);

  return (
    <BookingBottomSheetOverlay
      visible={visible}
      onClose={onClose}
      maxHeightRatio={0.9}
      sheetStyle={{ minHeight: sheetMinHeight }}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? insets.top + 8 : 0}
      >
        <View style={styles.shell}>
          <View style={styles.sheetHeader}>
            <Text style={styles.sheetKicker}>{isEdit ? 'EDIT VEHICLE' : 'ADD TO GARAGE'}</Text>
            <Text style={styles.sheetTitle}>{isEdit ? 'Update your ride' : 'Park a new vehicle'}</Text>
            <Text style={styles.sheetSubtitle}>
              {isEdit
                ? 'Refresh photo, size or DVLA compliance details'
                : 'Lookup by reg for the fastest setup — or enter manually'}
            </Text>
          </View>

          {!isEdit ? (
            <View style={styles.modeRow}>
              <Pressable
                onPress={() => {
                  void hapticFeedback('light');
                  setAddMode('reg');
                }}
                style={[styles.modePill, addMode === 'reg' && styles.modePillActive]}
              >
                <Ionicons name="search" size={16} color={addMode === 'reg' ? '#0F172A' : SKY} />
                <Text style={[styles.modeText, addMode === 'reg' && styles.modeTextActive]}>Reg lookup</Text>
              </Pressable>
              <Pressable
                onPress={() => {
                  void hapticFeedback('light');
                  setAddMode('manual');
                }}
                style={[styles.modePill, addMode === 'manual' && styles.modePillActive]}
              >
                <Ionicons name="create-outline" size={16} color={addMode === 'manual' ? '#0F172A' : SKY} />
                <Text style={[styles.modeText, addMode === 'manual' && styles.modeTextActive]}>Manual</Text>
              </Pressable>
            </View>
          ) : null}

          <ScrollView
            style={[styles.scroll, { maxHeight: scrollMaxHeight }]}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
            nestedScrollEnabled
          >
            {!isEdit && addMode === 'reg' ? (
              <UkRegInput value={formData.registration} onChangeText={onRegistrationChange} loading={dvlaLoading} />
            ) : (
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Registration *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.registration}
                  onChangeText={onRegistrationChange}
                  placeholder="AB12CDE"
                  placeholderTextColor="rgba(148,163,184,0.55)"
                  autoCapitalize="characters"
                  editable={!dvlaLoading}
                />
              </View>
            )}

            <View style={styles.photoSection}>
              <Text style={styles.sectionLabel}>Vehicle photo</Text>
              <View style={styles.photoRow}>
                <View style={styles.photoPreview}>
                  {formData.image_url ? (
                    <Image source={{ uri: formData.image_url }} style={styles.photoImage} />
                  ) : (
                    <LinearGradient colors={[SKY + '22', SKY + '08']} style={styles.photoPlaceholder}>
                      <Ionicons name="camera-outline" size={28} color={SKY} />
                    </LinearGradient>
                  )}
                </View>
                <View style={styles.photoActions}>
                  <TouchableOpacity
                    style={styles.photoBtn}
                    onPress={onPickImage}
                    disabled={uploadingImage}
                    activeOpacity={0.88}
                  >
                    {uploadingImage ? (
                      <ActivityIndicator size="small" color={SKY} />
                    ) : (
                      <>
                        <Ionicons name="cloud-upload-outline" size={16} color={SKY} />
                        <Text style={styles.photoBtnText}>{formData.image_url ? 'Change' : 'Upload'}</Text>
                      </>
                    )}
                  </TouchableOpacity>
                  {formData.image_url ? (
                    <TouchableOpacity style={styles.photoBtnDanger} onPress={onRemoveImage} activeOpacity={0.88}>
                      <Ionicons name="trash-outline" size={16} color="#F87171" />
                      <Text style={styles.photoBtnDangerText}>Remove</Text>
                    </TouchableOpacity>
                  ) : null}
                </View>
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Make / model *</Text>
              <TextInput
                style={styles.input}
                value={formData.make}
                onChangeText={(text) => setFormData((p) => ({ ...p, make: text }))}
                placeholder={addMode === 'reg' && !isEdit ? 'Auto-filled from DVLA' : 'e.g. Ford Fiesta'}
                placeholderTextColor="rgba(148,163,184,0.55)"
                editable={addMode === 'manual' || isEdit ? true : !dvlaLoading}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Colour</Text>
              <TextInput
                style={styles.input}
                value={formData.color}
                onChangeText={(text) => setFormData((p) => ({ ...p, color: text }))}
                placeholder={addMode === 'reg' && !isEdit ? 'Auto-filled from DVLA' : 'e.g. Blue'}
                placeholderTextColor="rgba(148,163,184,0.55)"
                editable={addMode === 'manual' || isEdit ? true : !dvlaLoading}
              />
            </View>

            <View style={[styles.inputGroup, dvlaTouched && styles.sizeLocked]}>
              <Text style={styles.inputLabel}>Vehicle size *</Text>
              <View style={styles.sizeRow} pointerEvents={dvlaTouched ? 'none' : 'auto'}>
                {(['small', 'medium', 'large', 'xl', 'xxl'] as VehicleSize[]).map((size) => (
                  <Pressable
                    key={size}
                    onPress={() => {
                      if (dvlaTouched) return;
                      void hapticFeedback('light');
                      setFormData((p) => ({ ...p, size }));
                    }}
                    style={[styles.sizePill, formData.size === size && styles.sizePillActive]}
                  >
                    <Ionicons
                      name={getSizeIcon(size) as keyof typeof Ionicons.glyphMap}
                      size={16}
                      color={formData.size === size ? '#0F172A' : SKY}
                    />
                    <Text style={[styles.sizeText, formData.size === size && styles.sizeTextActive]}>
                      {getSizeLabel(size)}
                    </Text>
                  </Pressable>
                ))}
              </View>
              <Text style={styles.inputHint}>
                {dvlaTouched
                  ? 'Set from DVLA'
                  : addMode === 'reg' && !isEdit
                    ? 'Auto-detected after lookup'
                    : 'Affects mobile pricing tiers'}
              </Text>
            </View>

            <View style={styles.dvlaCard}>
              <View style={styles.dvlaHeader}>
                <View style={styles.dvlaBadge}>
                  <Ionicons name="shield-checkmark" size={14} color={SKY} />
                  <Text style={styles.dvlaBadgeText}>DVLA compliance</Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    if (!formData.registration.trim()) {
                      Alert.alert('Missing reg', 'Enter a registration first.');
                      return;
                    }
                    void onDvlaRefresh();
                  }}
                  style={styles.refreshBtn}
                  activeOpacity={0.88}
                  disabled={dvlaLoading}
                >
                  {dvlaLoading ? (
                    <ActivityIndicator size="small" color={SKY} />
                  ) : (
                    <>
                      <Ionicons name="refresh" size={14} color={SKY} />
                      <Text style={styles.refreshText}>Refresh</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
              <View style={styles.dvlaGrid}>
                <DvlaComplianceRow
                  label="MOT"
                  status={formData.mot_status}
                  expiryDate={formData.mot_expiry_date}
                  formatDatePretty={formatDatePretty}
                />
                <DvlaComplianceRow
                  label="TAX"
                  status={formData.tax_status}
                  expiryDate={formData.tax_due_date}
                  formatDatePretty={formatDatePretty}
                />
              </View>
            </View>
          </ScrollView>

          <TouchableOpacity style={styles.saveBtn} onPress={onSave} activeOpacity={0.9} disabled={uploadingImage}>
            <LinearGradient colors={[SKY, '#0EA5E9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.saveBtnGradient}>
              <Text style={styles.saveBtnText}>{isEdit ? 'Save changes' : 'Add to garage'}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  shell: {
    width: '100%',
    paddingBottom: 4,
  },
  sheetHeader: { gap: 4, marginBottom: 12 },
  sheetKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: 'rgba(186,230,253,0.92)',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  sheetTitle: { color: '#F8FAFC', fontSize: 22, fontWeight: '900' },
  sheetSubtitle: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '600', lineHeight: 17 },
  modeRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  modePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  modePillActive: { backgroundColor: SKY, borderColor: SKY },
  modeText: { color: 'rgba(226,232,240,0.85)', fontSize: 13, fontWeight: '700' },
  modeTextActive: { color: '#0F172A' },
  scroll: {
    width: '100%',
  },
  scrollContent: {
    paddingBottom: 8,
    gap: 2,
  },
  regHero: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    padding: 14,
    marginBottom: 12,
    gap: 8,
  },
  regHeroKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: SKY,
    letterSpacing: 1.1,
  },
  regPlateInputWrap: {
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#0F172A',
    backgroundColor: '#F8D70C',
  },
  regPlateBand: {
    width: 32,
    backgroundColor: '#003399',
    alignItems: 'center',
    justifyContent: 'center',
  },
  regPlateBandText: { color: '#FFF', fontSize: 10, fontWeight: '900' },
  regPlateInput: {
    flex: 1,
    color: '#0F172A',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 2,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontVariant: ['tabular-nums'],
  },
  regLookupRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  regLookupText: { color: SKY, fontSize: 12, fontWeight: '700' },
  regHint: { color: 'rgba(148,163,184,0.9)', fontSize: 11, fontWeight: '600' },
  photoSection: { marginBottom: 12 },
  sectionLabel: { color: '#E2E8F0', fontSize: 13, fontWeight: '700', marginBottom: 8 },
  photoRow: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  photoPreview: {
    width: 96,
    height: 72,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.25)',
  },
  photoImage: { width: '100%', height: '100%' },
  photoPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoActions: { flex: 1, gap: 8 },
  photoBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  photoBtnText: { color: SKY, fontSize: 13, fontWeight: '700' },
  photoBtnDanger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.35)',
    backgroundColor: 'rgba(248,113,113,0.1)',
  },
  photoBtnDangerText: { color: '#F87171', fontSize: 13, fontWeight: '700' },
  inputGroup: { marginBottom: 12 },
  inputLabel: { color: 'rgba(226,232,240,0.9)', fontSize: 12, fontWeight: '700', marginBottom: 6 },
  input: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.25)',
    backgroundColor: 'rgba(8,20,38,0.5)',
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  inputHint: { color: 'rgba(148,163,184,0.85)', fontSize: 11, fontWeight: '600', marginTop: 6 },
  sizeLocked: { opacity: 0.92 },
  sizeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  sizePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.25)',
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  sizePillActive: { backgroundColor: SKY, borderColor: SKY },
  sizeText: { color: SKY, fontSize: 12, fontWeight: '800' },
  sizeTextActive: { color: '#0F172A' },
  dvlaCard: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.22)',
    backgroundColor: 'rgba(8,20,38,0.42)',
    padding: 12,
    marginBottom: 4,
    gap: 10,
  },
  dvlaHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dvlaBadge: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dvlaBadgeText: { color: SKY, fontSize: 12, fontWeight: '800' },
  refreshBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  refreshText: { color: SKY, fontSize: 11, fontWeight: '700' },
  dvlaGrid: { gap: 8 },
  dvlaItem: { gap: 2 },
  dvlaItemLabel: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  dvlaItemValue: { color: '#E2E8F0', fontSize: 13, fontWeight: '600' },
  saveBtn: { borderRadius: 14, overflow: 'hidden', marginTop: 10 },
  saveBtnGradient: { alignItems: 'center', paddingVertical: 14 },
  saveBtnText: { color: '#0F172A', fontSize: 15, fontWeight: '900' },
});
