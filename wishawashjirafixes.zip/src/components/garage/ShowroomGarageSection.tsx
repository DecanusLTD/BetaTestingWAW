import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Pressable,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, BOOKING_GLASS_TOP_SHEEN, BOOKING_GLASS_TOP_SHEEN_LOCATIONS } from '../../constants/bookingCardTheme';
import { getDashboardHeaderTopOffset, TAB_BAR_TOTAL_HEIGHT } from '../../constants/layoutConstants';
import EmptyState from '../shared/EmptyState';
import AnimatedProgress from '../booking/AnimatedProgress';
import VehicleDocBadge from '../../../app/owner/settings/VehicleDocBadge';
import { fetchVehicleStats, type VehicleStats } from '../../utils/vehicleStats';
import {
  careScoreColor,
  computeGarageCareScore,
  formatLastWashLabel,
} from '../../utils/garageCareScore';
import { getWorstVehicleComplianceState } from '../../utils/vehicleComplianceStatus';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const { width: SCREEN_W } = Dimensions.get('window');
const COMPACT_CARD_W = Math.min(268, SCREEN_W - 80);

export type GarageVehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

export type GarageVehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: GarageVehicleSize;
  mot_status?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  dvla_last_checked_at?: string | null;
  image_url?: string | null;
  image_path?: string | null;
  photo?: string | null;
};

function getSizeLabel(size?: GarageVehicleSize): string {
  switch (size) {
    case 'small':
      return 'Small';
    case 'large':
      return 'Large';
    case 'xl':
      return 'XL';
    case 'xxl':
      return 'XXL (HGV)';
    default:
      return 'Medium';
  }
}

function formatRegPlate(reg: string): string {
  const clean = reg.replace(/\s/g, '').toUpperCase();
  if (clean.length <= 4) return clean;
  if (clean.length <= 7) return `${clean.slice(0, 4)} ${clean.slice(4)}`;
  return `${clean.slice(0, 4)} ${clean.slice(4, 7)}`;
}

function UkPlate({ registration }: { registration: string }) {
  return (
    <View style={styles.ukPlate}>
      <View style={styles.ukPlateBand}>
        <Text style={styles.ukPlateBandText}>GB</Text>
      </View>
      <Text style={styles.ukPlateText}>{formatRegPlate(registration)}</Text>
    </View>
  );
}

type VehicleActionsProps = {
  vehicle: GarageVehicle;
  isBusy: boolean;
  busyId: string | null;
  onEdit: (v: GarageVehicle) => void;
  onSetDefault: (id: string) => void;
  onDelete: (v: GarageVehicle) => void;
  compact?: boolean;
};

function VehicleActions({ vehicle, isBusy, busyId, onEdit, onSetDefault, onDelete, compact }: VehicleActionsProps) {
  return (
    <View style={[styles.actionsRow, compact && styles.actionsRowCompact]}>
      <TouchableOpacity
        style={styles.actionChip}
        onPress={() => onEdit(vehicle)}
        disabled={Boolean(busyId)}
        activeOpacity={0.85}
      >
        <Ionicons name="create-outline" size={15} color={SKY} />
        {!compact ? <Text style={styles.actionChipText}>Edit</Text> : null}
      </TouchableOpacity>
      {!vehicle.is_default ? (
        <TouchableOpacity
          style={styles.actionChip}
          onPress={() => onSetDefault(vehicle.id)}
          disabled={Boolean(busyId)}
          activeOpacity={0.85}
        >
          {isBusy ? (
            <ActivityIndicator size="small" color="#34D399" />
          ) : (
            <>
              <Ionicons name="star-outline" size={15} color="#34D399" />
              {!compact ? <Text style={[styles.actionChipText, { color: '#34D399' }]}>Default</Text> : null}
            </>
          )}
        </TouchableOpacity>
      ) : null}
      <TouchableOpacity
        style={[styles.actionChip, styles.actionChipDanger]}
        onPress={() => onDelete(vehicle)}
        disabled={Boolean(busyId)}
        activeOpacity={0.85}
      >
        {isBusy ? (
          <ActivityIndicator size="small" color="#F87171" />
        ) : (
          <Ionicons name="trash-outline" size={15} color="#F87171" />
        )}
      </TouchableOpacity>
    </View>
  );
}

function HeroVehicleCard({
  vehicle,
  stats,
  isBusy,
  busyId,
  onEdit,
  onSetDefault,
  onDelete,
}: {
  vehicle: GarageVehicle;
  stats?: VehicleStats;
  isBusy: boolean;
  busyId: string | null;
  onEdit: (v: GarageVehicle) => void;
  onSetDefault: (id: string) => void;
  onDelete: (v: GarageVehicle) => void;
}) {
  const careScore = computeGarageCareScore(vehicle, stats);
  const ringColor = careScoreColor(careScore, vehicle);
  const displayName = [vehicle.make, vehicle.model].filter(Boolean).join(' ').trim() || 'Your vehicle';
  const imageUri = vehicle.image_url || vehicle.photo || null;

  return (
    <View style={styles.heroCard}>
      <BlurView intensity={38} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(56,189,248,0.16)', 'rgba(2,6,23,0.55)', 'rgba(2,6,23,0.82)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={[...BOOKING_GLASS_TOP_SHEEN]}
        locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.85 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.heroTopAccent, { backgroundColor: ringColor }]} pointerEvents="none" />

      <View style={styles.heroPad}>
        <View style={styles.heroKickerRow}>
          <Text style={styles.heroKicker}>{vehicle.is_default ? 'PRIMARY RIDE' : 'IN YOUR GARAGE'}</Text>
          {vehicle.is_default ? (
            <View style={styles.primaryPill}>
              <Ionicons name="star" size={11} color="#34D399" />
              <Text style={styles.primaryPillText}>Default</Text>
            </View>
          ) : null}
        </View>

        <View style={styles.heroImageStage}>
          {imageUri ? (
            <Image source={{ uri: imageUri }} style={styles.heroImage} resizeMode="cover" />
          ) : (
            <View style={styles.heroImagePlaceholder}>
              <Ionicons name="car-sport" size={56} color="rgba(148,163,184,0.55)" />
            </View>
          )}
          <LinearGradient
            colors={['transparent', 'rgba(2,6,23,0.72)']}
            style={styles.heroImageFade}
            pointerEvents="none"
          />
          <View style={styles.heroScoreWrap} pointerEvents="none">
            <AnimatedProgress
              progress={careScore}
              size={72}
              strokeWidth={5}
              showPercentage
              percentageFontSize={13}
              color={ringColor}
            />
            <Text style={styles.heroScoreLabel}>Care score</Text>
          </View>
        </View>

        <UkPlate registration={vehicle.registration} />
        <Text style={styles.heroName} numberOfLines={2}>
          {displayName}
        </Text>
        <Text style={styles.heroMeta}>
          {vehicle.type}
          {vehicle.color ? ` · ${vehicle.color}` : ''}
          {vehicle.size ? ` · Size ${getSizeLabel(vehicle.size)}` : ''}
        </Text>

        <View style={styles.heroStatsRow}>
          <View style={styles.heroStatChip}>
            <Ionicons name="water-outline" size={13} color={SKY} />
            <Text style={styles.heroStatText}>{formatLastWashLabel(stats)}</Text>
          </View>
          {stats?.washCount ? (
            <View style={styles.heroStatChip}>
              <Ionicons name="checkmark-done-outline" size={13} color={SKY} />
              <Text style={styles.heroStatText}>{stats.washCount} washes</Text>
            </View>
          ) : null}
        </View>

        <View style={styles.docBadgeRow}>
          <VehicleDocBadge label="MOT" status={vehicle.mot_status ?? null} expiryDate={vehicle.mot_expiry_date ?? null} icon="shield-checkmark-outline" />
          <VehicleDocBadge label="TAX" status={vehicle.tax_status ?? null} expiryDate={vehicle.tax_due_date ?? null} icon="receipt-outline" />
        </View>

        <TouchableOpacity
          style={styles.bookBtn}
          activeOpacity={0.88}
          onPress={() => {
            void hapticFeedback('medium');
            router.push('/owner/booking/create');
          }}
        >
          <LinearGradient colors={[SKY, '#0EA5E9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.bookBtnGradient}>
            <Ionicons name="flash" size={16} color="#0F172A" />
            <Text style={styles.bookBtnText}>Book a wash</Text>
          </LinearGradient>
        </TouchableOpacity>

        <VehicleActions
          vehicle={vehicle}
          isBusy={isBusy}
          busyId={busyId}
          onEdit={onEdit}
          onSetDefault={onSetDefault}
          onDelete={onDelete}
        />
      </View>
    </View>
  );
}

function CompactVehicleCard({
  vehicle,
  stats,
  isBusy,
  busyId,
  onEdit,
  onSetDefault,
  onDelete,
}: {
  vehicle: GarageVehicle;
  stats?: VehicleStats;
  isBusy: boolean;
  busyId: string | null;
  onEdit: (v: GarageVehicle) => void;
  onSetDefault: (id: string) => void;
  onDelete: (v: GarageVehicle) => void;
}) {
  const careScore = computeGarageCareScore(vehicle, stats);
  const ringColor = careScoreColor(careScore, vehicle);
  const displayName = [vehicle.make, vehicle.model].filter(Boolean).join(' ').trim() || 'Vehicle';
  const imageUri = vehicle.image_url || vehicle.photo || null;

  return (
    <View style={[styles.compactCard, { width: COMPACT_CARD_W }]}>
      <BlurView intensity={32} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(56,189,248,0.1)', 'rgba(2,6,23,0.7)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={styles.compactPad}>
        <View style={styles.compactTop}>
          <View style={styles.compactThumb}>
            {imageUri ? (
              <Image source={{ uri: imageUri }} style={styles.compactThumbImg} />
            ) : (
              <Ionicons name="car-outline" size={22} color="rgba(148,163,184,0.7)" />
            )}
          </View>
          <View style={styles.compactMain}>
            <Text style={styles.compactName} numberOfLines={1}>
              {displayName}
            </Text>
            <Text style={styles.compactReg}>{formatRegPlate(vehicle.registration)}</Text>
          </View>
          <View style={[styles.compactScore, { borderColor: ringColor + '88' }]}>
            <Text style={[styles.compactScoreText, { color: ringColor }]}>{careScore}</Text>
          </View>
        </View>
        <VehicleActions
          vehicle={vehicle}
          isBusy={isBusy}
          busyId={busyId}
          onEdit={onEdit}
          onSetDefault={onSetDefault}
          onDelete={onDelete}
          compact
        />
      </View>
    </View>
  );
}

function AddBayCard({ onPress }: { onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.addBay, pressed && { opacity: 0.92 }]}>
      <View style={styles.addBayInner}>
        <View style={styles.addBayIcon}>
          <Ionicons name="add" size={28} color={SKY} />
        </View>
        <Text style={styles.addBayTitle}>Park another vehicle</Text>
        <Text style={styles.addBaySubtitle}>Reg lookup or manual entry</Text>
      </View>
    </Pressable>
  );
}

type Props = {
  loading: boolean;
  vehicles: GarageVehicle[];
  insets: { top?: number; bottom?: number };
  busyId: string | null;
  onAddVehicle: () => void;
  onEditVehicle: (v: GarageVehicle) => void;
  onSetDefault: (id: string) => Promise<void>;
  onDelete: (v: GarageVehicle) => void;
};

export default function ShowroomGarageSection({
  loading,
  vehicles,
  insets,
  busyId,
  onAddVehicle,
  onEditVehicle,
  onSetDefault,
  onDelete,
}: Props) {
  const [statsById, setStatsById] = useState<Record<string, VehicleStats>>({});

  useEffect(() => {
    if (!vehicles.length) {
      setStatsById({});
      return;
    }
    let cancelled = false;
    void (async () => {
      const pairs = await Promise.all(
        vehicles.map(async (v) => [v.id, await fetchVehicleStats(v.id)] as const)
      );
      if (!cancelled) setStatsById(Object.fromEntries(pairs));
    })();
    return () => {
      cancelled = true;
    };
  }, [vehicles]);

  const { primary, secondary } = useMemo(() => {
    if (!vehicles.length) return { primary: null, secondary: [] as GarageVehicle[] };
    const primaryVehicle = vehicles.find((v) => v.is_default) ?? vehicles[0];
    const rest = vehicles.filter((v) => v.id !== primaryVehicle.id);
    return { primary: primaryVehicle, secondary: rest };
  }, [vehicles]);

  const headerSubtitle = useMemo(() => {
    if (!vehicles.length) return 'Add your first ride to start booking';
    const worst = primary ? getWorstVehicleComplianceState(primary) : 'unknown';
    const ready = worst === 'good' || worst === 'unknown';
    const countLabel = vehicles.length === 1 ? '1 vehicle' : `${vehicles.length} vehicles`;
    if (worst === 'expired') return `${countLabel} · MOT or tax expired`;
    if (worst === 'warning') return `${countLabel} · MOT or tax expiring soon`;
    return ready ? `${countLabel} · Ready to book` : `${countLabel} · Check MOT & tax`;
  }, [vehicles, primary]);

  const bottomPad = Math.max(insets.bottom ?? 0, 12) + TAB_BAR_TOTAL_HEIGHT + 16;

  if (loading) {
    return (
      <View style={[styles.screen, { paddingTop: getDashboardHeaderTopOffset(insets), paddingBottom: bottomPad }]}>
        <GarageHeader subtitle="Loading your garage…" />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="small" color={SKY} />
        </View>
      </View>
    );
  }

  if (!vehicles.length) {
    return (
      <View style={[styles.screen, { paddingTop: getDashboardHeaderTopOffset(insets), paddingBottom: bottomPad }]}>
        <GarageHeader subtitle="No vehicles parked yet" />
        <View style={styles.emptyBay}>
          <LinearGradient
            colors={['rgba(56,189,248,0.08)', 'rgba(2,6,23,0.45)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <EmptyState
            icon="car-outline"
            title="Empty bay"
            subtitle="Add your first vehicle with a UK reg lookup — we'll pull MOT, tax and size automatically."
            actionLabel="Add your first vehicle"
            onAction={onAddVehicle}
            iconColor={SKY}
          />
        </View>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{
        paddingTop: getDashboardHeaderTopOffset(insets),
        paddingBottom: bottomPad,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <GarageHeader subtitle={headerSubtitle} />

      {primary ? (
        <HeroVehicleCard
          vehicle={primary}
          stats={statsById[primary.id]}
          isBusy={busyId === primary.id}
          busyId={busyId}
          onEdit={onEditVehicle}
          onSetDefault={onSetDefault}
          onDelete={onDelete}
        />
      ) : null}

      {secondary.length > 0 ? (
        <View style={styles.secondarySection}>
          <Text style={styles.secondaryKicker}>ALSO PARKED HERE</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.secondaryScroll}>
            {secondary.map((vehicle) => (
              <CompactVehicleCard
                key={vehicle.id}
                vehicle={vehicle}
                stats={statsById[vehicle.id]}
                isBusy={busyId === vehicle.id}
                busyId={busyId}
                onEdit={onEditVehicle}
                onSetDefault={onSetDefault}
                onDelete={onDelete}
              />
            ))}
          </ScrollView>
        </View>
      ) : null}

      <AddBayCard onPress={onAddVehicle} />
    </ScrollView>
  );
}

function GarageHeader({ subtitle }: { subtitle: string }) {
  return (
    <View style={styles.garageHeader}>
      <Text style={styles.garageKicker}>YOUR GARAGE</Text>
      <Text style={styles.garageSubtitle} numberOfLines={2}>
        {subtitle}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 200 },
  garageHeader: { marginBottom: 14, gap: 2 },
  garageKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: 'rgba(186,230,253,0.92)',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  garageSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '600',
    lineHeight: 16,
  },
  emptyBay: {
    flex: 1,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.22)',
    minHeight: 320,
    justifyContent: 'center',
  },
  heroCard: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.35)',
    marginBottom: 16,
    shadowColor: 'rgba(56,189,248,0.2)',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 8,
  },
  heroTopAccent: { position: 'absolute', top: 0, left: 0, right: 0, height: 2, opacity: 0.9 },
  heroPad: { padding: 16, gap: 12 },
  heroKickerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: SKY,
    letterSpacing: 1.3,
  },
  primaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(52,211,153,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(52,211,153,0.45)',
  },
  primaryPillText: { color: '#34D399', fontSize: 10, fontWeight: '800' },
  heroImageStage: {
    height: 168,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.65)',
    position: 'relative',
  },
  heroImage: { width: '100%', height: '100%' },
  heroImagePlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  heroImageFade: { ...StyleSheet.absoluteFillObject },
  heroScoreWrap: {
    position: 'absolute',
    right: 10,
    bottom: 10,
    alignItems: 'center',
    gap: 2,
  },
  heroScoreLabel: { color: 'rgba(226,232,240,0.85)', fontSize: 9, fontWeight: '700' },
  ukPlate: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#0F172A',
    backgroundColor: '#F8D70C',
  },
  ukPlateBand: {
    width: 28,
    backgroundColor: '#003399',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
  },
  ukPlateBandText: { color: '#FFFFFF', fontSize: 9, fontWeight: '900' },
  ukPlateText: {
    color: '#0F172A',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 2,
    paddingHorizontal: 12,
    paddingVertical: 6,
    fontVariant: ['tabular-nums'],
  },
  heroName: { color: '#F8FAFC', fontSize: 22, fontWeight: '900', letterSpacing: 0.1 },
  heroMeta: { color: 'rgba(148,163,184,0.95)', fontSize: 12, fontWeight: '600' },
  heroStatsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  heroStatChip: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  heroStatText: { color: 'rgba(226,232,240,0.9)', fontSize: 12, fontWeight: '700' },
  docBadgeRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  bookBtn: { borderRadius: 14, overflow: 'hidden' },
  bookBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 13,
  },
  bookBtnText: { color: '#0F172A', fontSize: 15, fontWeight: '900' },
  actionsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  actionsRowCompact: { marginTop: 4 },
  actionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  actionChipDanger: {
    borderColor: 'rgba(248,113,113,0.35)',
    backgroundColor: 'rgba(248,113,113,0.1)',
  },
  actionChipText: { color: SKY, fontSize: 12, fontWeight: '700' },
  secondarySection: { marginBottom: 14, gap: 8 },
  secondaryKicker: {
    fontSize: 9,
    fontWeight: '800',
    color: 'rgba(186,230,253,0.75)',
    letterSpacing: 1.1,
  },
  secondaryScroll: { gap: 12, paddingRight: 8 },
  compactCard: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  compactPad: { padding: 12, gap: 8 },
  compactTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  compactThumb: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  compactThumbImg: { width: '100%', height: '100%' },
  compactMain: { flex: 1, minWidth: 0 },
  compactName: { color: '#F8FAFC', fontSize: 14, fontWeight: '800' },
  compactReg: { color: 'rgba(148,163,184,0.9)', fontSize: 11, fontWeight: '700', letterSpacing: 0.8 },
  compactScore: {
    minWidth: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.55)',
  },
  compactScoreText: { fontSize: 12, fontWeight: '900' },
  addBay: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderColor: 'rgba(125,211,252,0.35)',
    backgroundColor: 'rgba(8,20,38,0.28)',
    marginBottom: 8,
  },
  addBayInner: { alignItems: 'center', paddingVertical: 22, paddingHorizontal: 16, gap: 6 },
  addBayIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(56,189,248,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    marginBottom: 4,
  },
  addBayTitle: { color: '#E2E8F0', fontSize: 16, fontWeight: '800' },
  addBaySubtitle: { color: 'rgba(148,163,184,0.9)', fontSize: 12, fontWeight: '600' },
});
