import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BookingBottomSheetOverlay from '../booking/BookingBottomSheetOverlay';
import { WWPrimaryButton } from '../ui';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY ?? '#38BDF8';
const WINDOW_H = Dimensions.get('window').height;

export type AuthEmailSheetMode = 'login' | 'signup';

export type AuthEmailSheetProps = {
  visible: boolean;
  onClose: () => void;
  mode: AuthEmailSheetMode;
  loading?: boolean;
  error?: string | null;
  email: string;
  password: string;
  name?: string;
  referralCode?: string;
  onChangeEmail: (value: string) => void;
  onChangePassword: (value: string) => void;
  onChangeName?: (value: string) => void;
  onChangeReferralCode?: (value: string) => void;
  onSubmit: () => void;
  onSwitchMode?: () => void;
  onForgotPassword?: () => void;
};

export default function AuthEmailSheet({
  visible,
  onClose,
  mode,
  loading = false,
  error = null,
  email,
  password,
  name = '',
  referralCode = '',
  onChangeEmail,
  onChangePassword,
  onChangeName,
  onChangeReferralCode,
  onSubmit,
  onSwitchMode,
  onForgotPassword,
}: AuthEmailSheetProps) {
  const [showPassword, setShowPassword] = useState(false);
  const isLogin = mode === 'login';

  const maxHeightRatio = isLogin ? 0.42 : 0.52;
  const sheetHeight = useMemo(
    () => Math.min(WINDOW_H * (isLogin ? 0.38 : 0.48), isLogin ? 340 : 420),
    [isLogin]
  );

  return (
    <BookingBottomSheetOverlay
      visible={visible}
      onClose={onClose}
      maxHeightRatio={maxHeightRatio}
      compact
      translucent
      fillBody
      sheetStyle={{ height: sheetHeight, maxHeight: sheetHeight }}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bounces={false}
        keyboardDismissMode="on-drag"
      >
          <View style={styles.headerBlock}>
            <Text style={styles.title}>{isLogin ? 'Sign in' : 'Sign up'}</Text>
          </View>

          {mode === 'signup' ? (
            <View style={styles.fieldBlock}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIcon}>
                  <Ionicons name="person-outline" size={20} color={SKY} />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Your name"
                  placeholderTextColor="rgba(148,163,184,0.75)"
                  value={name}
                  onChangeText={onChangeName}
                  autoComplete="name"
                  accessibilityLabel="Full name"
                />
              </View>
            </View>
          ) : null}

          <View style={styles.fieldBlock}>
            <View style={styles.inputWrapper}>
              <View style={styles.inputIcon}>
                <Ionicons name="mail-outline" size={20} color={SKY} />
              </View>
              <TextInput
                style={styles.input}
                placeholder="you@email.com"
                placeholderTextColor="rgba(148,163,184,0.75)"
                value={email}
                onChangeText={onChangeEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                autoComplete="email"
                accessibilityLabel="Email address"
              />
            </View>
          </View>

          <View style={styles.fieldBlock}>
            <View style={styles.inputWrapper}>
              <View style={styles.inputIcon}>
                <Ionicons name="lock-closed-outline" size={20} color={SKY} />
              </View>
              <TextInput
                style={styles.input}
                placeholder={isLogin ? 'Your password' : 'Min. 6 characters'}
                placeholderTextColor="rgba(148,163,184,0.75)"
                value={password}
                onChangeText={onChangePassword}
                secureTextEntry={!showPassword}
                autoComplete={isLogin ? 'password' : 'password-new'}
                accessibilityLabel="Password"
              />
              <TouchableOpacity
                style={styles.inputIcon}
                onPress={() => {
                  void hapticFeedback('light');
                  setShowPassword((v) => !v);
                }}
                accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color="rgba(148,163,184,0.9)"
                />
              </TouchableOpacity>
            </View>
          </View>

          {mode === 'signup' ? (
            <View style={styles.fieldBlock}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIcon}>
                  <Ionicons name="gift-outline" size={20} color={SKY} />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Optional"
                  placeholderTextColor="rgba(148,163,184,0.75)"
                  value={referralCode}
                  onChangeText={onChangeReferralCode}
                  autoCapitalize="characters"
                  accessibilityLabel="Referral code"
                />
              </View>
            </View>
          ) : null}

          {isLogin && onForgotPassword ? (
            <TouchableOpacity
              style={styles.forgotRow}
              onPress={() => {
                void hapticFeedback('light');
                onForgotPassword();
              }}
              activeOpacity={0.8}
            >
              <Text style={styles.forgotText}>Forgot password?</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.forgotSpacer} />
          )}

          {error ? (
            <View style={styles.errorRow}>
              <Ionicons name="warning-outline" size={18} color="#F87171" />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <WWPrimaryButton
            title={
              loading
                ? isLogin
                  ? 'Signing in…'
                  : 'Creating account…'
                : isLogin
                  ? 'Continue'
                  : 'Create account'
            }
            onPress={onSubmit}
            disabled={loading}
            loading={loading}
            style={styles.submitBtn}
          />
        </ScrollView>
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    minHeight: 0,
    width: '100%',
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 12,
    gap: 0,
  },
  headerBlock: {
    marginBottom: 10,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  fieldBlock: {
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(8,20,38,0.55)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  inputIcon: {
    width: 42,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
    paddingRight: 12,
    paddingVertical: 12,
  },
  forgotRow: {
    alignSelf: 'flex-end',
    marginBottom: 10,
    marginTop: 0,
  },
  forgotSpacer: {
    height: 4,
  },
  forgotText: {
    color: SKY,
    fontWeight: '700',
    fontSize: 13,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  errorText: {
    flex: 1,
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '600',
  },
  submitBtn: {
    marginTop: 4,
  },
});
