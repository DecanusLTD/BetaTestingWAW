import React, { useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BookingBottomSheetOverlay from '../booking/BookingBottomSheetOverlay';
import { WWPrimaryButton } from '../ui';
import { colors } from '../../constants/colors';

const SKY = colors.SKY ?? '#38BDF8';
const BRAND_YELLOW = '#F8D70C';
const WINDOW_H = Dimensions.get('window').height;

export type AuthResetPasswordSheetProps = {
  visible: boolean;
  onClose: () => void;
  email: string;
  onChangeEmail: (value: string) => void;
  onSubmit: () => void;
  onBackToSignIn?: () => void;
  loading?: boolean;
  error?: string | null;
  sent?: boolean;
};

export default function AuthResetPasswordSheet({
  visible,
  onClose,
  email,
  onChangeEmail,
  onSubmit,
  onBackToSignIn,
  loading = false,
  error = null,
  sent = false,
}: AuthResetPasswordSheetProps) {
  const sheetHeight = useMemo(
    () => Math.min(WINDOW_H * (sent ? 0.34 : 0.36), sent ? 300 : 320),
    [sent]
  );

  return (
    <BookingBottomSheetOverlay
      visible={visible}
      onClose={onClose}
      maxHeightRatio={0.42}
      compact
      translucent
      fillBody
      sheetStyle={{ height: sheetHeight, maxHeight: sheetHeight }}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        bounces={false}
        keyboardDismissMode="on-drag"
      >
        <View style={styles.headerBlock}>
          <Text style={styles.title}>{sent ? 'Check your email' : 'Reset password'}</Text>
          <Text style={styles.subtitle}>
            {sent
              ? `We sent a reset link to ${email.trim() || 'your email'}. Open it to set a new password.`
              : 'Enter your account email and we’ll send you a reset link.'}
          </Text>
        </View>

        {sent ? (
          <View style={styles.sentIconWrap}>
            <Ionicons name="mail-open-outline" size={36} color={SKY} />
          </View>
        ) : (
          <View style={styles.fieldBlock}>
            <View style={styles.inputWrapper}>
              <View style={styles.inputIcon}>
                <Ionicons name="mail-outline" size={20} color={SKY} />
              </View>
              <TextInput
                style={styles.input}
                placeholder="you@email.com"
                placeholderTextColor="rgba(148,163,184,0.75)"
                value={email}
                onChangeText={onChangeEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                autoComplete="email"
                autoFocus
                accessibilityLabel="Email address"
              />
            </View>
          </View>
        )}

        {error ? (
          <View style={styles.errorRow}>
            <Ionicons name="warning-outline" size={18} color="#F87171" />
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        {sent ? (
          <WWPrimaryButton
            title="Back to sign in"
            onPress={() => {
              onBackToSignIn?.() ?? onClose();
            }}
            style={styles.submitBtn}
          />
        ) : (
          <WWPrimaryButton
            title={loading ? 'Sending…' : 'Send reset link'}
            onPress={onSubmit}
            disabled={loading}
            loading={loading}
            style={styles.submitBtn}
          />
        )}
      </ScrollView>
    </BookingBottomSheetOverlay>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    minHeight: 0,
    width: '100%',
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 12,
  },
  headerBlock: {
    marginBottom: 12,
    gap: 6,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  subtitle: {
    color: BRAND_YELLOW,
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 18,
  },
  sentIconWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    marginTop: 4,
  },
  fieldBlock: {
    marginBottom: 12,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(8,20,38,0.55)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  inputIcon: {
    width: 42,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '600',
    paddingRight: 12,
    paddingVertical: 12,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  errorText: {
    flex: 1,
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '600',
  },
  submitBtn: {
    marginTop: 4,
  },
});
