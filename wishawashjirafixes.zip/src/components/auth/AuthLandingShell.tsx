import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
  StatusBar,
  Image,
  Linking,
  Dimensions,
} from 'react-native';
import { Video, ResizeMode, type AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { AUTH_PAGES_VIDEO, NEW_AUTH_LOGO } from '../../../assets/assetExports';
import { AUTH_GRADIENT_COLORS } from '../../constants/authStyles';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY ?? '#87CEEB';
/** Brand yellow from logo / plate accent */
const BRAND_YELLOW = '#F8D70C';
const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';
const { width: WINDOW_W } = Dimensions.get('window');
const LOGO_W = Math.min(360, WINDOW_W * 0.88);
const LOGO_H = Math.min(228, WINDOW_W * 0.56);

const AUTH_GLASS_GRADIENT = [
  'rgba(14,165,233,0.42)',
  'rgba(56,189,248,0.28)',
  'rgba(248,215,12,0.22)',
] as const;

function AuthGlassFill({ compact = false }: { compact?: boolean }) {
  return (
    <>
      <View style={styles.glassFallback} />
      <BlurView
        intensity={Platform.OS === 'ios' ? (compact ? 42 : 54) : compact ? 64 : 78}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[...AUTH_GLASS_GRADIENT]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0.08)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View pointerEvents="none" style={styles.glassRim} />
    </>
  );
}

export type AuthLandingShellProps = {
  mode: 'login' | 'signup';
  subcopy: string;
  switchLabel: string;
  onSwitchAuth: () => void;
  onContinueEmail: () => void;
  onApple: () => void;
  onGoogle: () => void;
  isAppleAvailable?: boolean;
  disabled?: boolean;
};

export default function AuthLandingShell({
  mode,
  subcopy,
  switchLabel,
  onSwitchAuth,
  onContinueEmail,
  onApple,
  onGoogle,
  isAppleAvailable = false,
  disabled = false,
}: AuthLandingShellProps) {
  const insets = useSafeAreaInsets();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(36)).current;
  const dockAnim = useRef(new Animated.Value(48)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.92)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 700, useNativeDriver: true }),
      Animated.spring(dockAnim, { toValue: 0, tension: 48, friction: 10, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, slideAnim, dockAnim]);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, { toValue: 1, duration: 2600, useNativeDriver: true }),
        Animated.timing(logoGlow, { toValue: 0.88, duration: 2600, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [logoGlow]);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, { toValue: 1, duration: 650, useNativeDriver: true }).start();
  };

  const pressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.97, useNativeDriver: true, speed: 50 }).start();
  };
  const pressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const openLink = (url: string) => {
    Linking.openURL(url).catch(() => {});
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={StyleSheet.absoluteFill}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>

      <LinearGradient
        pointerEvents="none"
        colors={[...AUTH_GRADIENT_COLORS]}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        pointerEvents="none"
        colors={['transparent', 'rgba(2,10,24,0.35)', 'rgba(2,10,24,0.92)']}
        locations={[0.2, 0.55, 1]}
        style={StyleSheet.absoluteFill}
      />

      <TouchableOpacity
        style={[styles.topRightLink, { top: Math.max(insets.top, 12) + 8 }]}
        onPress={() => {
          void hapticFeedback('light');
          onSwitchAuth();
        }}
        disabled={disabled}
        activeOpacity={0.85}
      >
        <Text style={styles.topRightLinkText}>{switchLabel}</Text>
      </TouchableOpacity>

      <View style={[styles.stage, { paddingTop: insets.top + 56 }]}>
        <Animated.View
          style={[
            styles.heroBlock,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.logoCrest}>
            <Animated.View style={{ opacity: logoGlow }}>
              <Image source={NEW_AUTH_LOGO} style={styles.heroLogo} resizeMode="contain" />
            </Animated.View>
            <View style={styles.brandArc} pointerEvents="none">
              {(
                [
                  { ch: 'W', x: 0.14, y: 0.18, r: -55 },
                  { ch: 'I', x: 0.22, y: 0.08, r: -36 },
                  { ch: 'S', x: 0.29, y: 0.03, r: -20 },
                  { ch: 'H', x: 0.36, y: 0.008, r: -8 },
                ] as const
              ).map((p) => (
                <Text
                  key={`l-${p.ch}`}
                  style={[
                    styles.brandChar,
                    {
                      left: LOGO_W * p.x,
                      top: LOGO_H * p.y,
                      transform: [{ rotate: `${p.r}deg` }],
                    },
                  ]}
                >
                  {p.ch}
                </Text>
              ))}
              <Text style={styles.brandCenter}>- a -</Text>
              {(
                [
                  { ch: 'W', x: 0.58, y: 0.008, r: 8 },
                  { ch: 'A', x: 0.65, y: 0.03, r: 20 },
                  { ch: 'S', x: 0.72, y: 0.08, r: 36 },
                  { ch: 'H', x: 0.8, y: 0.18, r: 55 },
                ] as const
              ).map((p) => (
                <Text
                  key={`r-${p.ch}`}
                  style={[
                    styles.brandChar,
                    {
                      left: LOGO_W * p.x,
                      top: LOGO_H * p.y,
                      transform: [{ rotate: `${p.r}deg` }],
                    },
                  ]}
                >
                  {p.ch}
                </Text>
              ))}
            </View>
          </View>
          <Text style={styles.subcopy}>{subcopy}</Text>
        </Animated.View>

        <Animated.View
          style={[
            styles.dock,
            {
              paddingBottom: Math.max(insets.bottom, 16) + 8,
              opacity: fadeAnim,
              transform: [{ translateY: dockAnim }],
            },
          ]}
        >
          <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
            <TouchableOpacity
              style={styles.emailCta}
              onPress={() => {
                void hapticFeedback('light');
                onContinueEmail();
              }}
              onPressIn={pressIn}
              onPressOut={pressOut}
              disabled={disabled}
              activeOpacity={0.92}
              accessibilityLabel="Continue with Email"
            >
              <AuthGlassFill />
              <View style={styles.ctaContent}>
                <Ionicons name="mail" size={20} color="#F8FAFC" />
                <Text style={styles.emailCtaText}>Continue with Email</Text>
              </View>
            </TouchableOpacity>
          </Animated.View>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or continue with</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.socialRow}>
            {isAppleAvailable ? (
              <TouchableOpacity
                style={styles.socialBtn}
                onPress={() => {
                  void hapticFeedback('light');
                  onApple();
                }}
                onPressIn={pressIn}
                onPressOut={pressOut}
                disabled={disabled}
                activeOpacity={0.9}
                accessibilityLabel="Continue with Apple"
              >
                <AuthGlassFill compact />
                <View style={styles.ctaContent}>
                  <Ionicons name="logo-apple" size={24} color="#F8FAFC" />
                </View>
              </TouchableOpacity>
            ) : null}
            <TouchableOpacity
              style={styles.socialBtn}
              onPress={() => {
                void hapticFeedback('light');
                onGoogle();
              }}
              onPressIn={pressIn}
              onPressOut={pressOut}
              disabled={disabled}
              activeOpacity={0.9}
              accessibilityLabel="Continue with Google"
            >
              <AuthGlassFill compact />
              <View style={styles.ctaContent}>
                <Ionicons name="logo-google" size={22} color="#F8FAFC" />
              </View>
            </TouchableOpacity>
          </View>

          <Text style={styles.trustText}>
            By continuing, you agree to{' '}
            <Text style={styles.trustLink} onPress={() => openLink(TERMS_URL)}>
              Terms
            </Text>
            {' & '}
            <Text style={styles.trustLink} onPress={() => openLink(PRIVACY_URL)}>
              Privacy Policy
            </Text>
          </Text>

          <View style={styles.switchRow}>
            <Text style={styles.switchHint}>
              {mode === 'login' ? 'New here? ' : 'Already have an account? '}
            </Text>
            <TouchableOpacity
              onPress={() => {
                void hapticFeedback('light');
                onSwitchAuth();
              }}
              activeOpacity={0.85}
            >
              <Text style={styles.switchLink}>
                {mode === 'login' ? 'Create an account' : 'Sign in'}
              </Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#020A18',
  },
  topRightLink: {
    position: 'absolute',
    right: 20,
    zIndex: 20,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 999,
    backgroundColor: 'rgba(8,20,38,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  topRightLinkText: {
    color: SKY,
    fontWeight: '800',
    fontSize: 13,
    letterSpacing: 0.2,
  },
  stage: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  heroBlock: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 8 : 4,
  },
  logoCrest: {
    width: LOGO_W,
    height: LOGO_H,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  brandArc: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 2,
  },
  brandChar: {
    position: 'absolute',
    color: SKY,
    fontSize: 12,
    fontWeight: '900',
    width: 14,
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.45)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  brandCenter: {
    position: 'absolute',
    left: LOGO_W * 0.36,
    width: LOGO_W * 0.28,
    top: LOGO_H * -0.01,
    textAlign: 'center',
    color: SKY,
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0,
    textShadowColor: 'rgba(0,0,0,0.45)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  heroLogo: {
    width: LOGO_W,
    height: LOGO_H,
  },
  subcopy: {
    marginTop: 14,
    color: BRAND_YELLOW,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 22,
    textAlign: 'center',
    maxWidth: 320,
    letterSpacing: 0.2,
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  dock: {
    paddingHorizontal: 22,
    marginTop: 22,
    paddingTop: 0,
  },
  emailCta: {
    borderRadius: 16,
    paddingVertical: 17,
    paddingHorizontal: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.38)',
    backgroundColor: 'rgba(8,20,38,0.35)',
  },
  ctaContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    zIndex: 2,
  },
  emailCtaText: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.1,
  },
  glassFallback: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(8, 24, 42, 0.55)',
  },
  glassRim: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.22)',
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 18,
    marginBottom: 14,
  },
  dividerLine: {
    flex: 1,
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.22)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(226,232,240,0.55)',
    fontSize: 12,
    fontWeight: '700',
  },
  socialRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 14,
  },
  socialBtn: {
    width: 58,
    height: 58,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
    backgroundColor: 'rgba(8,20,38,0.35)',
  },
  trustText: {
    marginTop: 18,
    textAlign: 'center',
    color: 'rgba(226,232,240,0.5)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 18,
    paddingHorizontal: 8,
  },
  trustLink: {
    color: SKY,
    fontWeight: '700',
    textDecorationLine: 'underline',
  },
  switchRow: {
    marginTop: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  switchHint: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 14,
    fontWeight: '600',
  },
  switchLink: {
    color: SKY,
    fontSize: 14,
    fontWeight: '800',
  },
});
