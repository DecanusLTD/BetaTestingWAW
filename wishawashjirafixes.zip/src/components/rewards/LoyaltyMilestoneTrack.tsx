import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  WASH_REWARD_MILESTONES,
  getMilestoneTierColor,
  type RewardMilestone,
} from '../../utils/loyaltyTier';
import { passFlow } from '../../constants/passFlowStyles';

type Props = {
  points: number;
  redeemingId: string | null;
  onRedeem: (reward: RewardMilestone) => void;
};

const NODE_W = 118;

export default function LoyaltyMilestoneTrack({ points, redeemingId, onRedeem }: Props) {
  const unlockedCount = WASH_REWARD_MILESTONES.filter((m) => points >= m.points).length;

  return (
    <View style={passFlow.section}>
      <View style={passFlow.sectionHead}>
        <Text style={passFlow.sectionTitle}>Unlock track</Text>
        <Text style={passFlow.sectionMeta}>
          {unlockedCount}/{WASH_REWARD_MILESTONES.length} unlocked
        </Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.track}>
        {WASH_REWARD_MILESTONES.map((milestone, index) => {
          const unlocked = points >= milestone.points;
          const isNext =
            !unlocked && (index === 0 || points >= WASH_REWARD_MILESTONES[index - 1]!.points);
          const tierColor = getMilestoneTierColor(milestone.tier);
          const ptsToGo = Math.max(0, milestone.points - points);
          const connectorDone = index > 0 && points >= milestone.points;

          return (
            <View key={milestone.id} style={styles.nodeWrap}>
              <View style={styles.railRow}>
                {index > 0 ? (
                  <View style={[styles.connector, connectorDone && { backgroundColor: tierColor + '99' }]} />
                ) : (
                  <View style={styles.connectorSpacer} />
                )}
                <TouchableOpacity
                  activeOpacity={unlocked ? 0.82 : 1}
                  disabled={!unlocked || redeemingId === milestone.id}
                  onPress={() => onRedeem(milestone)}
                  style={[
                    styles.dot,
                    unlocked && { borderColor: tierColor, backgroundColor: tierColor + '22' },
                    isNext && styles.dotNext,
                  ]}
                >
                  {unlocked ? (
                    <Ionicons
                      name={milestone.icon as keyof typeof Ionicons.glyphMap}
                      size={16}
                      color={tierColor}
                    />
                  ) : (
                    <Ionicons name="lock-closed" size={12} color="rgba(148,163,184,0.55)" />
                  )}
                </TouchableOpacity>
                {index < WASH_REWARD_MILESTONES.length - 1 ? (
                  <View
                    style={[
                      styles.connector,
                      points >= WASH_REWARD_MILESTONES[index + 1]!.points && {
                        backgroundColor: getMilestoneTierColor(WASH_REWARD_MILESTONES[index + 1]!.tier) + '99',
                      },
                    ]}
                  />
                ) : (
                  <View style={styles.connectorSpacer} />
                )}
              </View>

              <Text style={[styles.nodeTitle, !unlocked && styles.nodeTitleLocked]} numberOfLines={3}>
                {milestone.title}
              </Text>
              <Text style={styles.nodePts}>{milestone.points.toLocaleString()} pts</Text>

              {redeemingId === milestone.id ? (
                <ActivityIndicator size="small" color={tierColor} style={{ marginTop: 6 }} />
              ) : unlocked ? (
                <Text style={[styles.action, { color: tierColor }]}>Tap to claim</Text>
              ) : (
                <Text style={styles.ptsToGo}>
                  {ptsToGo > 0 ? `${ptsToGo.toLocaleString()} to go` : '—'}
                </Text>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    paddingBottom: 4,
    paddingRight: 6,
  },
  nodeWrap: {
    width: NODE_W,
    alignItems: 'center',
    gap: 5,
  },
  railRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 8,
  },
  connector: {
    flex: 1,
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderRadius: 1,
  },
  connectorSpacer: {
    flex: 1,
  },
  dot: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  dotNext: {
    borderColor: 'rgba(251,191,36,0.65)',
    shadowColor: '#FBBF24',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  nodeTitle: {
    color: '#F1F5F9',
    fontSize: 11,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 14,
    minHeight: 42,
  },
  nodeTitleLocked: {
    color: 'rgba(203,213,225,0.55)',
  },
  nodePts: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'center',
  },
  action: {
    fontSize: 10,
    fontWeight: '800',
    textAlign: 'center',
    marginTop: 2,
  },
  ptsToGo: {
    color: 'rgba(148,163,184,0.65)',
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 2,
  },
});
