import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { REFERRAL_BONUS_POINTS, REWARD_POINTS_PER_BOOKING } from '../../services/LoyaltyService';
import { passFlow } from '../../constants/passFlowStyles';

const EARN_ROWS = [
  { icon: 'car-outline' as const, label: 'Wash your vehicle', points: `+${REWARD_POINTS_PER_BOOKING}`, color: '#38BDF8' },
  { icon: 'star-outline' as const, label: 'Rate your Care Pro', points: '+5', color: '#FBBF24' },
  { icon: 'people-outline' as const, label: 'Refer a vehicle owner', points: `+${REFERRAL_BONUS_POINTS}`, color: '#A78BFA' },
];

export default function LoyaltyEarnStrip() {
  return (
    <View style={passFlow.section}>
      <Text style={[passFlow.sectionTitle, styles.titlePad]}>Earn more</Text>
      <View>
        {EARN_ROWS.map((item, index) => (
          <View
            key={item.label}
            style={[passFlow.flowRow, index === EARN_ROWS.length - 1 && passFlow.flowRowLast]}
          >
            <Ionicons name={item.icon} size={15} color={item.color} style={styles.icon} />
            <Text style={styles.label}>{item.label}</Text>
            <Text style={[styles.points, { color: item.color }]}>{item.points}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  titlePad: {
    marginBottom: 10,
  },
  icon: {
    width: 18,
    textAlign: 'center',
  },
  label: {
    flex: 1,
    color: 'rgba(241,245,249,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  points: {
    fontSize: 13,
    fontWeight: '800',
  },
});
