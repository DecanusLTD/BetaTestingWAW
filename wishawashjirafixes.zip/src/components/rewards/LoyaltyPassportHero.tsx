import React from 'react';
import { View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AnimatedProgress from '../booking/AnimatedProgress';
import { getTierProgress } from '../../utils/loyaltyTier';
import { passHero } from '../../constants/passFlowStyles';

type Props = {
  points: number;
  completedBookings: number;
  loading?: boolean;
};

export default function LoyaltyPassportHero({ points, completedBookings, loading }: Props) {
  const tierInfo = getTierProgress(points);
  const nextMilestone = tierInfo.nextTier
    ? `${tierInfo.pointsToNextTier.toLocaleString()} pts to ${tierInfo.nextTier}`
    : 'Top tier unlocked';

  return (
    <View style={[passHero.wrap, passHero.wrapGold]}>
      <View style={passHero.content}>
        <View style={passHero.topRow}>
          <View style={passHero.tierLine}>
            <Ionicons name="shield-checkmark" size={13} color={tierInfo.color} />
            <Text style={[passHero.tierText, { color: tierInfo.color }]}>{tierInfo.tier}</Text>
          </View>
          <Text style={passHero.perk}>{tierInfo.perk}</Text>
        </View>

        <View style={passHero.mainRow}>
          <View style={passHero.ringCol}>
            <AnimatedProgress
              progress={tierInfo.progress}
              size={88}
              strokeWidth={6}
              showPercentage
              percentageFontSize={15}
              color={tierInfo.color}
              colorCycle={[tierInfo.color, '#FBBF24', '#A78BFA']}
            />
          </View>
          <View style={passHero.statsCol}>
            <Text style={passHero.headline}>{loading ? '—' : points.toLocaleString()}</Text>
            <Text style={[passHero.headlineLabel, { color: '#FBBF24' }]}>Wash Pass points</Text>
            <Text style={passHero.metaLine}>
              {completedBookings} vehicle wash{completedBookings === 1 ? '' : 'es'} · 50 pts each
            </Text>
            <Text style={[passHero.nextLine, { color: tierInfo.color }]}>{nextMilestone}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
