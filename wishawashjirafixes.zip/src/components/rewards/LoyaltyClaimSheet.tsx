import React from 'react';
import { View, Text, StyleSheet, Modal, Pressable, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import GradientIconBox from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import {
  getMilestoneTierColor,
  getRewardCategoryColor,
  getRewardCategoryLabel,
  getRewardClaimCopy,
  type RewardMilestone,
} from '../../utils/loyaltyTier';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { WWSheetCloseButton } from '../ui';

type Props = {
  visible: boolean;
  reward: RewardMilestone | null;
  onClose: () => void;
};

export default function LoyaltyClaimSheet({ visible, reward, onClose }: Props) {
  const insets = useSafeAreaInsets();
  if (!reward) return null;

  const tierColor = getMilestoneTierColor(reward.tier);
  const categoryColor = getRewardCategoryColor(reward.category);
  const claimCopy = getRewardClaimCopy(reward);

  const handlePrimary = () => {
    void hapticFeedback('medium');
    onClose();
    if (claimCopy.showBookingCta) {
      router.push('/owner/booking/create');
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.root}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Dismiss" />
        <View style={[styles.panel, { paddingBottom: Math.max(16, insets.bottom) }]}>
          <LinearGradient
            colors={[`${tierColor}35`, 'rgba(15,23,42,0.96)', 'rgba(2,6,23,0.98)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={styles.topRow}>
            <Text style={styles.kicker}>Reward unlocked</Text>
            <WWSheetCloseButton onPress={onClose} accessibilityLabel="Close" />
          </View>

          <View style={styles.hero}>
            <GradientIconBox
              icon={reward.icon as keyof typeof Ionicons.glyphMap}
              colors={accentToGradient(tierColor)}
              boxSize={72}
              size={34}
              elevated
            />
            <View style={[styles.categoryPill, { borderColor: categoryColor + '55', backgroundColor: categoryColor + '18' }]}>
              <Text style={[styles.categoryText, { color: categoryColor }]}>
                {getRewardCategoryLabel(reward.category)}
              </Text>
            </View>
            <Text style={styles.title}>{reward.title}</Text>
            <Text style={styles.subtitle}>{reward.description}</Text>
            <View style={[styles.sparkPill, { borderColor: tierColor + '66' }]}>
              <Ionicons name="sparkles" size={14} color={tierColor} />
              <Text style={[styles.sparkText, { color: tierColor }]}>{claimCopy.walletLine}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.primaryBtn} activeOpacity={0.9} onPress={handlePrimary}>
            <LinearGradient colors={[tierColor, tierColor + 'CC']} style={styles.primaryGradient}>
              <Ionicons
                name={claimCopy.showBookingCta ? 'flash' : 'checkmark-circle'}
                size={18}
                color="#0F172A"
              />
              <Text style={styles.primaryText}>{claimCopy.primaryCta}</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity onPress={onClose} style={styles.secondaryBtn} activeOpacity={0.88}>
            <Text style={styles.secondaryText}>Keep browsing rewards</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.65)',
  },
  panel: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(251,191,36,0.28)',
    paddingHorizontal: 18,
    paddingTop: 14,
    gap: 14,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  kicker: {
    color: '#FBBF24',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  hero: {
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  categoryPill: {
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 999,
    borderWidth: 1,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  title: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
  },
  subtitle: {
    color: 'rgba(203,213,225,0.9)',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 12,
  },
  sparkPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  sparkText: {
    fontSize: 12,
    fontWeight: '800',
  },
  primaryBtn: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  primaryGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 15,
  },
  primaryText: {
    color: '#0F172A',
    fontSize: 16,
    fontWeight: '900',
  },
  secondaryBtn: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  secondaryText: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '700',
  },
});
