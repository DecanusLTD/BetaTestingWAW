import React, { useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatRelativeLoyaltyDate } from '../../utils/loyaltyTier';
import { passFlow } from '../../constants/passFlowStyles';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type LoyaltyActivityItem = {
  id: string;
  label: string;
  pointsLabel: string;
  date: string;
  icon: keyof typeof Ionicons.glyphMap;
  accent: string;
};

type Props = {
  items: LoyaltyActivityItem[];
  loading?: boolean;
  initialExpanded?: boolean;
};

export default function LoyaltyActivityFeed({ items, loading, initialExpanded = false }: Props) {
  const [expanded, setExpanded] = useState(initialExpanded);
  const latest = items[0];

  const toggle = () => {
    void hapticFeedback('light');
    setExpanded((value) => !value);
  };

  return (
    <View style={passFlow.section}>
      <TouchableOpacity
        style={[passFlow.sectionHead, styles.sectionHead]}
        onPress={toggle}
        activeOpacity={0.75}
      >
        <View style={styles.headLeft}>
          <Text style={passFlow.sectionTitle}>Recent activity</Text>
          {!loading && items.length > 0 && !expanded ? (
            <Text style={styles.preview} numberOfLines={1}>
              {latest.label} · {latest.pointsLabel}
            </Text>
          ) : null}
        </View>
        <View style={styles.headRight}>
          {!loading && items.length > 0 ? (
            <Text style={passFlow.sectionMeta}>{items.length} entries</Text>
          ) : null}
          <Ionicons
            name={expanded ? 'chevron-up' : 'chevron-down'}
            size={16}
            color="rgba(148,163,184,0.7)"
          />
        </View>
      </TouchableOpacity>

      {expanded ? (
        loading ? (
          <ActivityIndicator color="#FBBF24" style={{ marginVertical: 8 }} />
        ) : items.length === 0 ? (
          <Text style={styles.empty}>Complete a vehicle wash to start earning points.</Text>
        ) : (
          <View>
            {items.map((item, index) => (
              <View
                key={item.id}
                style={[passFlow.flowRow, index === items.length - 1 && passFlow.flowRowLast]}
              >
                <Ionicons name={item.icon} size={15} color={item.accent} style={styles.icon} />
                <View style={styles.body}>
                  <Text style={styles.label} numberOfLines={1}>
                    {item.label}
                  </Text>
                  <Text style={styles.date}>{formatRelativeLoyaltyDate(item.date)}</Text>
                </View>
                <Text style={[styles.points, { color: item.accent }]}>{item.pointsLabel}</Text>
              </View>
            ))}
          </View>
        )
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  sectionHead: {
    alignItems: 'center',
  },
  headLeft: {
    flex: 1,
    minWidth: 0,
    gap: 4,
  },
  headRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  preview: {
    color: 'rgba(148,163,184,0.8)',
    fontSize: 12,
    fontWeight: '500',
  },
  empty: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 13,
    fontWeight: '600',
    paddingVertical: 4,
  },
  icon: {
    width: 18,
    textAlign: 'center',
  },
  body: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  label: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '600',
  },
  date: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '500',
  },
  points: {
    fontSize: 13,
    fontWeight: '800',
  },
});
