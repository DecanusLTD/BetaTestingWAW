import React from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import MapView from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { MapMarkerCustomerVehicle } from '../maps/MapMarkerViews';
import { LOCATION_PICKER_MAP_STYLE, MAP_LOCKED_DARK } from '../../constants/mapConstants';
import type { FrozenBookingMapView } from '../../utils/frozenBookingMapView';

type Props = {
  mapView: FrozenBookingMapView;
  children?: React.ReactNode;
  showCenterCar?: boolean;
  markerPulse?: Animated.Value;
  /** Allow map marker presses (valeter selection). Default false — fully frozen. */
  allowMarkerPresses?: boolean;
};

export default function FrozenBookingMapStage({
  mapView,
  children,
  showCenterCar = true,
  markerPulse,
  allowMarkerPresses = false,
}: Props) {
  return (
    <View style={StyleSheet.absoluteFill}>
      <MapView
        style={StyleSheet.absoluteFill}
        region={mapView.region}
        initialRegion={mapView.region}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={LOCATION_PICKER_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        mapPadding={mapView.mapPadding}
        legalLabelInsets={mapView.legalLabelInsets}
        pointerEvents={allowMarkerPresses ? 'box-none' : 'none'}
      >
        {children}
      </MapView>
      <View pointerEvents="none" style={styles.tint} />
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(2,6,23,0.12)', 'rgba(2,6,23,0.42)', 'rgba(2,6,23,0.58)']}
        locations={[0, 0.55, 1]}
        style={styles.tintGradient}
      />
      {showCenterCar ? (
        <View pointerEvents="none" style={styles.centerPickerWrap}>
          <View style={styles.centerPickerPin}>
            {markerPulse ? (
              <Animated.View style={{ transform: [{ scale: markerPulse }] }}>
                <MapMarkerCustomerVehicle size={44} variant="car" />
              </Animated.View>
            ) : (
              <MapMarkerCustomerVehicle size={44} variant="car" />
            )}
          </View>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  tint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.28)',
  },
  tintGradient: {
    ...StyleSheet.absoluteFillObject,
  },
  centerPickerWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerPickerPin: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.22)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.45)',
  },
});
