import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { indexTrackingCardStyles as ix } from './IndexTrackingCardShell';

type Props = {
  washType: 'exterior' | 'interior';
  accentColor: string;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
};

export default function BookingWashTypeMapPill({ washType, accentColor, onPress, style }: Props) {
  const label = washType === 'exterior' ? 'Exterior' : 'Interior';
  const icon = washType === 'exterior' ? 'car-sport-outline' : 'home-outline';

  const pill = (
    <View
      style={[
        ix.optionStatusPill,
        styles.pill,
        { backgroundColor: accentColor + '14', borderColor: accentColor + '55' },
      ]}
    >
      <Ionicons name={icon} size={13} color={accentColor} />
      <Text style={[ix.optionStatusText, { color: accentColor }]}>{label}</Text>
    </View>
  );

  if (onPress) {
    return (
      <View style={[styles.wrap, style]}>
        <TouchableOpacity onPress={onPress} activeOpacity={0.88} accessibilityRole="button" accessibilityLabel={`${label} wash. Tap to change.`}>
          {pill}
        </TouchableOpacity>
      </View>
    );
  }

  return <View style={[styles.wrap, style]}>{pill}</View>;
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    zIndex: 121,
    alignSelf: 'flex-start',
  },
  pill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
});
