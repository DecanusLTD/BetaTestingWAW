import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

const DEFAULT_COLOR_CYCLE = [SKY, '#10B981', '#4AC8F6', '#34D399'];

interface AnimatedProgressProps {
  progress: number; // 0-100
  size?: number;
  strokeWidth?: number;
  showPercentage?: boolean;
  /** Font size for the percentage number; smaller values for small rings (e.g. 14 for size=72) */
  percentageFontSize?: number;
  color?: string;
  /** When true, the ring rotates continuously */
  spin?: boolean;
  /** Cycle through these colours over time; when set, spin is implied */
  colorCycle?: string[];
  /** When set, renders inside the center instead of percentage (e.g. avatar); no spin/colorCycle by default */
  centerContent?: React.ReactNode;
  /** Thinner track, softer fill, no pulse — for compact live-tracking cards */
  light?: boolean;
}

export default function AnimatedProgress({ 
  progress, 
  size = 120, 
  strokeWidth = 8,
  showPercentage = true,
  percentageFontSize,
  color = SKY,
  spin = false,
  colorCycle,
  centerContent,
  light = false,
}: AnimatedProgressProps) {
  const animatedProgress = useRef(new Animated.Value(0)).current;
  const [displayProgress, setDisplayProgress] = useState(0);
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const spinAnim = useRef(new Animated.Value(0)).current;
  /** Do not name this `colors` — shadows RN theme import and can confuse Metro/Babel. */
  const cyclePalette =
    Array.isArray(colorCycle) && colorCycle.length > 0 ? colorCycle : DEFAULT_COLOR_CYCLE;
  const cyclePaletteRef = useRef(cyclePalette);
  cyclePaletteRef.current = cyclePalette;
  const [colorIndex, setColorIndex] = useState(0);
  const effectiveColor =
    colorCycle && colorCycle.length > 0
      ? cyclePalette[colorIndex % cyclePalette.length]!
      : color;
  const ringBaseColor = typeof effectiveColor === 'string' && effectiveColor.length > 0 ? effectiveColor : SKY;
  /** Spin / colour cycle whenever requested; centre content stays fixed (used e.g. dashboard stat rings). */
  const shouldSpin = !light && (spin || !!(colorCycle && colorCycle.length > 0));
  const [prevRingColor, setPrevRingColor] = useState(ringBaseColor);
  const colorBlend = useRef(new Animated.Value(1)).current;
  const trackOpacity = light ? 0.22 : 0.5;
  const fillOpacity = light ? 0.45 : 0.7;
  const ringBorderAlpha = light ? '55' : '';
  const trackBorderAlpha = light ? '18' : '20';
  const centerInset = light ? strokeWidth * 2.4 : strokeWidth * 4;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(animatedProgress, {
        toValue: progress,
        useNativeDriver: false,
        tension: 50,
        friction: 7,
      }),
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.05,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]),
    ]).start();

    const listener = animatedProgress.addListener(({ value }) => {
      setDisplayProgress(Math.round(value));
    });
    
    return () => {
      animatedProgress.removeListener(listener);
    };
  }, [progress]);

  useEffect(() => {
    if (light) {
      pulseAnim.setValue(1);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.02,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim, light]);

  // Continuous spin
  useEffect(() => {
    if (!shouldSpin) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(spinAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        }),
        Animated.timing(spinAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [shouldSpin]);

  // Cycle through colours when colorCycle is provided
  useEffect(() => {
    if (!colorCycle || colorCycle.length === 0) return;
    const id = setInterval(() => {
      const len = cyclePaletteRef.current.length;
      if (len < 1) return;
      setColorIndex((i) => (i + 1) % len);
    }, 1600);
    return () => clearInterval(id);
  }, [colorCycle]);

  // Smooth crossfade between ring colors instead of instant jumps.
  useEffect(() => {
    if (prevRingColor === ringBaseColor) return;
    colorBlend.setValue(0);
    Animated.timing(colorBlend, {
      toValue: 1,
      duration: 420,
      useNativeDriver: true,
    }).start(({ finished }) => {
      if (finished) setPrevRingColor(ringBaseColor);
    });
  }, [ringBaseColor, prevRingColor, colorBlend]);

  const progressWidth = animatedProgress.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const rotation = spinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          transform: [{ scale: pulseAnim }],
        },
      ]}
    >
      <Animated.View
        style={[
          styles.ringWrapper,
          {
            width: size,
            height: size,
            ...(shouldSpin ? { transform: [{ rotate: rotation }] } : {}),
          },
        ]}
      >
        {/* Previous color layer (fades out) */}
        <Animated.View
          style={[
            styles.ringLayer,
            {
              opacity: colorBlend.interpolate({
                inputRange: [0, 1],
                outputRange: [1, 0],
              }),
            },
          ]}
          pointerEvents="none"
        >
          <LinearGradient
            colors={[prevRingColor + (light ? '28' : '50'), prevRingColor + (light ? '10' : '25')]}
            style={[
              styles.outerRing,
              {
                width: size,
                height: size,
                borderRadius: size / 2,
                borderWidth: strokeWidth,
                borderColor: prevRingColor + ringBorderAlpha,
                opacity: trackOpacity + 0.35,
              },
            ]}
          />
          <View
            style={[
              styles.progressRing,
              {
                width: size,
                height: size,
                borderRadius: size / 2,
                borderWidth: strokeWidth,
                borderColor: prevRingColor + trackBorderAlpha,
              },
            ]}
          >
            <Animated.View
              style={[
                styles.progressFill,
                {
                  width: progressWidth,
                  height: '100%',
                  backgroundColor: prevRingColor,
                  opacity: fillOpacity,
                },
              ]}
            />
          </View>
        </Animated.View>

        {/* Current color layer (fades in) */}
        <Animated.View style={[styles.ringLayer, { opacity: colorBlend }]} pointerEvents="none">
          <LinearGradient
            colors={[ringBaseColor + (light ? '28' : '50'), ringBaseColor + (light ? '10' : '25')]}
            style={[
              styles.outerRing,
              {
                width: size,
                height: size,
                borderRadius: size / 2,
                borderWidth: strokeWidth,
                borderColor: ringBaseColor + ringBorderAlpha,
                opacity: trackOpacity + 0.35,
              },
            ]}
          />
          <View
            style={[
              styles.progressRing,
              {
                width: size,
                height: size,
                borderRadius: size / 2,
                borderWidth: strokeWidth,
                borderColor: ringBaseColor + trackBorderAlpha,
              },
            ]}
          >
            <Animated.View
              style={[
                styles.progressFill,
                {
                  width: progressWidth,
                  height: '100%',
                  backgroundColor: ringBaseColor,
                  opacity: fillOpacity,
                },
              ]}
            />
          </View>
        </Animated.View>
      </Animated.View>

      {/* Center circle with content – no rotation */}
      <Animated.View
        style={[
          styles.centerCircle,
          {
            width: size - centerInset,
            height: size - centerInset,
            borderRadius: (size - centerInset) / 2,
            transform: [{ scale: light ? 1 : scaleAnim }],
          },
        ]}
      >
        {centerContent ?? (
          <>
            <LinearGradient
              colors={
                light
                  ? ['rgba(10,25,41,0.72)', 'rgba(10,25,41,0.82)']
                  : ['rgba(10,25,41,0.95)', 'rgba(10,25,41,0.98)']
              }
              style={StyleSheet.absoluteFill}
            />
            {showPercentage && (
              <View style={styles.percentageContainer}>
                <Text
                  style={[
                    styles.percentageText,
                    light && styles.percentageTextLight,
                    percentageFontSize != null && { fontSize: percentageFontSize },
                  ]}
                >
                  {displayProgress}
                </Text>
                <Text
                  style={[
                    styles.percentSymbol,
                    light && styles.percentSymbolLight,
                    percentageFontSize != null && { fontSize: Math.round(percentageFontSize * 0.6) },
                  ]}
                >
                  %
                </Text>
              </View>
            )}
          </>
        )}
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  ringWrapper: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringLayer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  outerRing: {
    position: 'absolute',
  },
  progressRing: {
    position: 'absolute',
    overflow: 'hidden',
  },
  progressFill: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    borderRadius: 60,
  },
  centerCircle: {
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    zIndex: 1,
  },
  percentageContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  percentageText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  percentageTextLight: {
    fontWeight: '600',
    color: 'rgba(248,250,252,0.92)',
  },
  percentSymbol: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 2,
  },
  percentSymbolLight: {
    fontWeight: '500',
    color: 'rgba(135,206,235,0.85)',
  },
});
