import React from 'react';
import { View, StyleSheet, StyleProp, ViewStyle, Image, type ImageSourcePropType } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

/**
 * Premium booking tile — layered glass, specular, soft depth. Compact two-row layout via `optionFooterRow`.
 */
export default function IndexTrackingCardShell({
  accentColor,
  children,
  style,
  backgroundImage,
  compact,
}: Readonly<{
  accentColor: string;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Optional full-bleed picture shown behind the content (whole image visible, not cropped). */
  backgroundImage?: ImageSourcePropType | null;
  /** Tighter padding + no min height — wish carousel cards. */
  compact?: boolean;
}>) {
  return (
    <View style={[styles.card, compact && styles.cardCompact, style]}>
      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <View style={[StyleSheet.absoluteFill, styles.baseFill]} pointerEvents="none" />
      <View
        style={[StyleSheet.absoluteFill, { backgroundColor: accentColor + '28' }]}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.05)', 'transparent']}
        locations={[0, 0.32, 0.68]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.85 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['transparent', 'rgba(2,6,23,0.38)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0.03)']}
        start={{ x: 0.2, y: 0 }}
        end={{ x: 0.8, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      {backgroundImage ? (
        <>
          <Image
            source={backgroundImage}
            style={StyleSheet.absoluteFill}
            resizeMode="contain"
            pointerEvents="none"
            accessibilityIgnoresInvertColors
          />
          <LinearGradient
            colors={['rgba(2,6,23,0.55)', 'rgba(2,6,23,0.32)', 'rgba(2,6,23,0.62)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
        </>
      ) : null}
      <View style={[styles.content, compact && styles.contentCompact]}>{children}</View>
    </View>
  );
}

/** Shared layout — top row (icon / copy / info) + single footer row (status + continue). */
export const indexTrackingCardStyles = StyleSheet.create({
  cardWrap: {
    marginBottom: 6,
  },
  optionCardTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    flexShrink: 0,
  },
  optionKickerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 2,
  },
  /** Reserve one line for optional tier badge so card heights stay even. */
  optionKickerSlot: {
    minHeight: 26,
    justifyContent: 'center',
  },
  optionIconBadge: {
    marginRight: 0,
    width: 44,
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  optionTitleMain: { flex: 1, minWidth: 0, paddingRight: 2, justifyContent: 'flex-start' },
  optionInfoBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  optionKicker: {
    color: 'rgba(226,232,240,0.55)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  optionTitle: {
    color: '#FAFAFA',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginTop: 3,
    lineHeight: 20,
  },
  optionSubtitle: {
    color: 'rgba(248,250,252,0.78)',
    fontSize: 12,
    marginTop: 4,
    marginBottom: 0,
    lineHeight: 16,
    fontWeight: '600',
  },
  /** One row: status (left, flex) + continue chevron (right). Keeps card heights even. */
  optionFooterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth * 2,
    borderTopColor: 'rgba(255,255,255,0.1)',
    minHeight: 38,
  },
  optionFooterLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    minWidth: 0,
    marginRight: 4,
  },
  optionStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 1,
    gap: 5,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 7,
    paddingVertical: 5,
    backgroundColor: 'rgba(0,0,0,0.22)',
  },
  optionStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#34D399',
  },
  optionStatusText: {
    color: '#6EE7B7',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.35,
    textTransform: 'uppercase',
    flexShrink: 1,
  },
  /** Right side of footer — text + chevron, no full-width bar */
  optionContinueInline: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    flexShrink: 0,
    minHeight: 42,
    borderRadius: 21,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.45)',
    backgroundColor: 'rgba(15,23,42,0.55)',
    paddingHorizontal: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.16,
    shadowRadius: 6,
    elevation: 6,
  },
  optionContinueText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
    textTransform: 'uppercase',
  },
  /** @deprecated Prefer `optionFooterRow` + `optionContinueInline` */
  optionSelectFull: {
    marginTop: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    paddingVertical: 12,
    paddingHorizontal: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  optionChevronWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const styles = StyleSheet.create({
  card: {
    overflow: 'hidden',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.38)',
    backgroundColor: 'rgba(11,18,34,0.48)',
    shadowColor: 'rgba(56,189,248,0.22)',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.5,
    shadowRadius: 30,
    elevation: 14,
    minHeight: 138,
  },
  cardCompact: {
    minHeight: 0,
  },
  baseFill: {
    backgroundColor: 'rgba(15,23,42,0.42)',
  },
  content: {
    paddingHorizontal: 13,
    paddingTop: 12,
    paddingBottom: 11,
    justifyContent: 'flex-start',
  },
  contentCompact: {
    paddingTop: 10,
    paddingBottom: 6,
  },
});
