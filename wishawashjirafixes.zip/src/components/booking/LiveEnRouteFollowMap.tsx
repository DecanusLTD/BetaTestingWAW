import React, { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import MapView, { Marker, type Region } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { MapMarkerCustomerVehicle, MapMarkerValeterLive } from '../maps/MapMarkerViews';
import {
  LOCATION_PICKER_MAP_STYLE,
  MAP_CAMERA_ANIMATION_DURATION,
  MAP_LOCKED_DARK,
  MAP_ZOOM_DELTA,
} from '../../constants/mapConstants';
import { regionForCoordinates } from '../../utils/mapUtils';

type Coord = { latitude: number; longitude: number };

type Props = {
  customer: Coord;
  valeter: Coord;
  /** When true, camera follows the Care Pro; otherwise stays locked on the customer. */
  followValeter: boolean;
};

/**
 * Live en-route map: tinted, non-interactive. Follows the Pro when within range.
 */
export default function LiveEnRouteFollowMap({ customer, valeter, followValeter }: Props) {
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (followValeter) {
      const region = regionForCoordinates([customer, valeter], 0.55);
      map.animateToRegion(region, MAP_CAMERA_ANIMATION_DURATION);
    } else {
      const region: Region = {
        latitude: customer.latitude,
        longitude: customer.longitude,
        latitudeDelta: MAP_ZOOM_DELTA * 2.2,
        longitudeDelta: MAP_ZOOM_DELTA * 2.2,
      };
      map.animateToRegion(region, MAP_CAMERA_ANIMATION_DURATION);
    }
  }, [customer.latitude, customer.longitude, valeter.latitude, valeter.longitude, followValeter]);

  const initialRegion: Region = followValeter
    ? regionForCoordinates([customer, valeter], 0.55)
    : {
        latitude: customer.latitude,
        longitude: customer.longitude,
        latitudeDelta: MAP_ZOOM_DELTA * 2.2,
        longitudeDelta: MAP_ZOOM_DELTA * 2.2,
      };

  return (
    <View style={StyleSheet.absoluteFill}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialRegion={initialRegion}
        scrollEnabled={false}
        zoomEnabled={false}
        rotateEnabled={false}
        pitchEnabled={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        customMapStyle={LOCATION_PICKER_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        pointerEvents="none"
      >
        <Marker coordinate={customer} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
          <MapMarkerCustomerVehicle size={44} variant="car" />
        </Marker>
        <Marker coordinate={valeter} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges>
          <MapMarkerValeterLive size={48} />
        </Marker>
      </MapView>
      <View pointerEvents="none" style={styles.tint} />
      <LinearGradient
        pointerEvents="none"
        colors={['rgba(2,6,23,0.1)', 'rgba(2,6,23,0.38)', 'rgba(2,6,23,0.55)']}
        locations={[0, 0.55, 1]}
        style={StyleSheet.absoluteFill}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  tint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.26)',
  },
});
