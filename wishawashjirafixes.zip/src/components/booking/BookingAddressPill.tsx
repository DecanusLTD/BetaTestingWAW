import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View, type StyleProp, type ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';

type Props = {
  address: string;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  showChevron?: boolean;
};

export default function BookingAddressPill({ address, onPress, style, showChevron = true }: Props) {
  const chrome = useMapChromeColors();

  const inner = (
    <>
      <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={[...chrome.gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.sheen}
        pointerEvents="none"
      />
      <View style={styles.inner}>
        <Ionicons name="location" size={15} color={chrome.icon} />
        <Text style={styles.text} numberOfLines={1}>
          {address}
        </Text>
        {showChevron ? (
          <Ionicons name="chevron-forward" size={14} color="rgba(226,232,240,0.78)" />
        ) : null}
      </View>
    </>
  );

  const pressableStyle = [
    styles.pressable,
    {
      borderColor: chrome.border,
      shadowColor: chrome.shadow,
    },
  ];

  if (onPress) {
    return (
      <View style={[styles.wrap, style]}>
        <TouchableOpacity
          style={pressableStyle}
          onPress={onPress}
          activeOpacity={0.88}
          accessibilityRole="button"
          accessibilityLabel={`Wash location: ${address}`}
        >
          {inner}
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, style]} pointerEvents="none">
      <View style={pressableStyle}>{inner}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 120,
  },
  pressable: {
    borderRadius: 999,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  sheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.85,
  },
  inner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    zIndex: 1,
  },
  text: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
});
