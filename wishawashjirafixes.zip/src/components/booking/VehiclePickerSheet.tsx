import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import BookingBottomSheetOverlay from './BookingBottomSheetOverlay';
import { WWPrimaryButton } from '../ui';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;

export type VehiclePickerItem = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

type VehiclePickerInlineProps = {
  vehicles: VehiclePickerItem[];
  selectedIds: string[];
  onToggle: (id: string) => void;
  loading?: boolean;
  compact?: boolean;
  /** When set, add-vehicle actions call this instead of navigating to vehicle management. */
  onAddVehicle?: () => void;
};

type VehiclePickerSheetProps = {
  visible: boolean;
  onClose: () => void;
  vehicles: VehiclePickerItem[];
  selectedIds: string[];
  onToggle: (id: string) => void;
  onContinue: (ids: string[]) => void;
  loading?: boolean;
};

/** Compact inline vehicle list for embedding in the location bottom sheet. */
export function VehiclePickerInline({
  vehicles,
  selectedIds,
  onToggle,
  loading = false,
  compact = false,
  onAddVehicle,
}: VehiclePickerInlineProps) {
  const openAddVehicle = () => {
    hapticFeedback('light');
    if (onAddVehicle) {
      onAddVehicle();
      return;
    }
    router.push('/owner/settings/vehicle-management');
  };
  if (loading) {
    if (compact) {
      return (
        <View style={styles.inlineRootCompact}>
          <Text style={styles.inlineKickerCompact}>
            Vehicles{selectedIds.length > 0 ? ` · ${selectedIds.length}` : ''}
          </Text>
          <View style={styles.hLoadingRow}>
            <ActivityIndicator size="small" color={SKY} />
          </View>
        </View>
      );
    }
    return (
      <View style={styles.loadingWrap}>
        <ActivityIndicator size="small" color={SKY} />
        <Text style={styles.loadingText}>Loading vehicles…</Text>
      </View>
    );
  }

  if (vehicles.length === 0) {
    if (compact) {
      return (
        <View style={styles.inlineRootCompact}>
          <Text style={styles.inlineKickerCompact}>Vehicles</Text>
          <TouchableOpacity
            style={styles.hChipEmpty}
            onPress={openAddVehicle}
            activeOpacity={0.85}
          >
            <Ionicons name="add-circle-outline" size={16} color={SKY} />
            <Text style={styles.hChipEmptyText}>Add a vehicle</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return (
      <View style={styles.emptyWrap}>
        <Ionicons name="car-sport-outline" size={22} color="rgba(148,163,184,0.7)" />
        <Text style={styles.emptyText}>No vehicles saved yet</Text>
        <TouchableOpacity
          style={styles.addLink}
          onPress={openAddVehicle}
          activeOpacity={0.85}
        >
          <Ionicons name="add-circle-outline" size={16} color={SKY} />
          <Text style={styles.addLinkText}>Add a vehicle</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (compact) {
    return (
      <View style={styles.inlineRootCompact}>
        <Text style={styles.inlineKickerCompact}>
          Vehicles{selectedIds.length > 0 ? ` · ${selectedIds.length} selected` : ''}
        </Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.hScroll}
          contentContainerStyle={styles.hScrollContent}
          keyboardShouldPersistTaps="handled"
          nestedScrollEnabled
        >
          {vehicles.map((vehicle) => {
            const isSelected = selectedIds.includes(vehicle.id);
            const label = vehicle.registration
              ? `${vehicle.make} · ${vehicle.registration}`
              : `${vehicle.make} ${vehicle.model}`;
            return (
              <TouchableOpacity
                key={vehicle.id}
                style={[styles.hChip, isSelected && styles.hChipSelected]}
                onPress={() => {
                  hapticFeedback('light');
                  onToggle(vehicle.id);
                }}
                activeOpacity={0.88}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: isSelected }}
                accessibilityLabel={label}
              >
                <Ionicons
                  name="car-sport"
                  size={14}
                  color={isSelected ? SKY : 'rgba(148,163,184,0.85)'}
                />
                <Text style={[styles.hChipText, isSelected && styles.hChipTextSelected]} numberOfLines={1}>
                  {label}
                </Text>
                {isSelected ? (
                  <Ionicons name="checkmark" size={12} color={SKY} style={styles.hChipCheck} />
                ) : null}
              </TouchableOpacity>
            );
          })}
          <TouchableOpacity
            style={styles.hChipAdd}
            onPress={openAddVehicle}
            activeOpacity={0.85}
            accessibilityLabel="Add or manage vehicles"
          >
            <Ionicons name="add" size={18} color="rgba(148,163,184,0.9)" />
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.inlineRoot}>
      <Text style={styles.inlineKicker}>
        YOUR VEHICLES{selectedIds.length > 0 ? ` · ${selectedIds.length} selected` : ''}
      </Text>
      <ScrollView
        style={styles.list}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        nestedScrollEnabled
      >
        {vehicles.map((vehicle) => {
          const isSelected = selectedIds.includes(vehicle.id);
          return (
            <TouchableOpacity
              key={vehicle.id}
              style={[styles.row, isSelected && styles.rowSelected]}
              onPress={() => {
                hapticFeedback('light');
                onToggle(vehicle.id);
              }}
              activeOpacity={0.88}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: isSelected }}
            >
              <View style={[styles.rowIcon, isSelected && styles.rowIconSelected]}>
                <Ionicons name="car-sport" size={18} color={isSelected ? SKY : 'rgba(148,163,184,0.9)'} />
              </View>
              <View style={styles.rowText}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {vehicle.make} {vehicle.model}
                </Text>
                <Text style={styles.rowMeta} numberOfLines={1}>
                  {vehicle.color}
                  {vehicle.registration ? ` · ${vehicle.registration}` : ''}
                  {vehicle.is_default ? ' · Default' : ''}
                </Text>
              </View>
              <Ionicons
                name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                size={22}
                color={isSelected ? SKY : 'rgba(148,163,184,0.45)'}
              />
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      <TouchableOpacity
        style={styles.manageLink}
        onPress={() => {
          hapticFeedback('light');
          router.push('/owner/settings/vehicle-management');
        }}
        activeOpacity={0.85}
      >
        <Text style={styles.manageLinkText}>Manage vehicles</Text>
      </TouchableOpacity>
    </View>
  );
}

/**
 * Minimal ride-style vehicle picker — compact bottom sheet instead of a full step/page.
 */
export default function VehiclePickerSheet({
  visible,
  onClose,
  vehicles,
  selectedIds,
  onToggle,
  onContinue,
  loading = false,
}: VehiclePickerSheetProps) {
  const selected = vehicles.filter((v) => selectedIds.includes(v.id));

  return (
    <BookingBottomSheetOverlay visible={visible} onClose={onClose} maxHeightRatio={0.52}>
      <Text style={styles.kicker}>YOUR VEHICLES</Text>
      <Text style={styles.title}>Which cars is this for?</Text>
      <Text style={styles.subtitle}>Select one or more vehicles for this booking</Text>

      <VehiclePickerInline
        vehicles={vehicles}
        selectedIds={selectedIds}
        onToggle={onToggle}
        loading={loading}
      />

      {vehicles.length > 0 && !loading ? (
        <>
          <WWPrimaryButton
            title={
              selected.length > 0
                ? `Continue with ${selected.length} vehicle${selected.length === 1 ? '' : 's'}`
                : 'Choose at least one vehicle'
            }
            onPress={() => {
              if (selectedIds.length === 0) return;
              onContinue(selectedIds);
            }}
            disabled={selectedIds.length === 0}
            leftIconName="arrow-forward"
            style={styles.cta}
          />

          <TouchableOpacity
            style={styles.manageLink}
            onPress={() => {
              hapticFeedback('light');
              onClose();
              router.push('/owner/settings/vehicle-management');
            }}
            activeOpacity={0.85}
          >
            <Text style={styles.manageLinkText}>Manage vehicles</Text>
          </TouchableOpacity>
        </>
      ) : null}
    </BookingBottomSheetOverlay>
  );
}
const styles = StyleSheet.create({
  kicker: {
    color: 'rgba(125,211,252,0.85)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  subtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 14,
  },
  inlineRoot: {
    marginBottom: 8,
  },
  inlineRootCompact: {
    marginBottom: 2,
  },
  inlineKicker: {
    color: 'rgba(125,211,252,0.85)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  inlineKickerCompact: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 6,
  },
  hScroll: {
    flexGrow: 0,
  },
  hScrollContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingRight: 4,
  },
  hChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.05)',
    maxWidth: 180,
  },
  hChipSelected: {
    backgroundColor: 'rgba(56,189,248,0.14)',
  },
  hChipText: {
    color: 'rgba(203,213,225,0.95)',
    fontSize: 13,
    fontWeight: '600',
    flexShrink: 1,
  },
  hChipTextSelected: {
    color: '#F9FAFB',
    fontWeight: '700',
  },
  hChipCheck: {
    marginLeft: -2,
  },
  hChipAdd: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  hLoadingRow: {
    height: 36,
    justifyContent: 'center',
  },
  hChipEmpty: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.1)',
  },
  hChipEmptyText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  loadingWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
  },
  loadingText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 13,
    fontWeight: '600',
  },
  emptyWrap: {
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  addLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  addLinkText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  list: {
    maxHeight: 220,
    marginBottom: 4,
  },
  listContent: {
    gap: 8,
    paddingBottom: 4,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 11,
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.16)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  rowSelected: {
    borderColor: 'rgba(125,211,252,0.45)',
    backgroundColor: 'rgba(56,189,248,0.1)',
  },
  rowIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  rowIconSelected: {
    borderColor: 'rgba(125,211,252,0.35)',
    backgroundColor: 'rgba(56,189,248,0.14)',
  },
  rowText: {
    flex: 1,
    minWidth: 0,
  },
  rowTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  rowMeta: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  cta: {
    marginTop: 4,
  },
  manageLink: {
    alignSelf: 'center',
    paddingVertical: 6,
  },
  manageLinkText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '700',
  },
});
