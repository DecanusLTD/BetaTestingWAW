/**
 * Customer map flows — bottom sheet + tracking card chrome copied from
 * wishawasherwithconnect `app/business/bookings/tracking.tsx` (layout, position, styles).
 * Content slots are customer-specific (steps, copy, actions).
 */
import React, { useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  PanResponder,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';
import {
  BOOKING_SHEET_DARK_OVERLAY,
  HEADER_STYLE_CARD_BORDER,
  HEADER_STYLE_CARD_GRADIENT,
  MAP_TRACKING_ACTIONS_BAR_HEIGHT,
  MAP_TRACKING_SHEET_MAX_HEIGHT_RATIO,
} from '../../constants/bookingCardTheme';
import BookingMapGlassBackground from './BookingMapGlassBackground';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import { useThemeOptional } from '../../contexts/ThemeContext';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY ?? '#38BDF8';

const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;
/** Fallback dismiss distance when sheet height is content-driven. */
const FIT_CONTENT_DRAG_HEIGHT = 280;

export type CustomerMapTrackingSheetShellProps = {
  accentColor?: string;
  /** Defaults to customer header gradient opaque layers */
  sheetGradient?: [string, string];
  sheetBorder?: string;
  /** Inner body of the small tracking card; omit to hide the nested card (e.g. quick booking uses one step card only). */
  cardInner?: React.ReactNode;
  /** Row under the card (primary CTA + cancel), same as business `bookingInfoRow` */
  actionRow?: React.ReactNode;
  /** Extra content inside the panel below the action row (e.g. trip picker, form steps) */
  panelFooter?: React.ReactNode;
  onChatPress?: () => void;
  onInfoPress?: () => void;
  showChatButton?: boolean;
  showInfoButton?: boolean;
  chatLabel?: string;
  /** When set, drag-down on handle area calls this (e.g. router.back). */
  onDragDismiss?: () => void;
  containerStyle?: StyleProp<ViewStyle>;
  /** Sit above the tab bar on owner track, etc. */
  bottomOffset?: number;
  /** Multiplies default sheet height (e.g. 0.9 makes it smaller). Ignored when `fitContent` is true. */
  sheetHeightScale?: number;
  /**
   * Size the sheet to the card + actions (no tall empty panel).
   * Use on Live tracking where the fixed ratio leaves dead space.
   */
  fitContent?: boolean;
  /** Inner tracking card rim — reference uses `tier.color + '70'`. */
  trackingCardBorderColor?: string;
  /**
   * Map + markers as the bottom sheet background (full-screen video stays outside).
   * Blur/tint are lightened so the map stays visible under the tracking card.
   */
  sheetMapBackground?: React.ReactNode;
};

function defaultSheetGradient(themeFallback: [string, string]): [string, string] {
  const raw = HEADER_STYLE_CARD_GRADIENT;
  const toOpaque = (s: string, alpha: number) =>
    s.includes('rgba') ? s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`) : `${s}${alpha === 1 ? 'FF' : 'EE'}`;
  return [toOpaque(raw[0], 1), toOpaque(raw[1] || raw[0], 0.93)] as [string, string];
}

/** Nested tracking card chrome (blur + gradient + rim) — same layers as `smallTrackingCard` in this shell. */
export function TrackingStyleInnerCard({
  accentColor = SKY,
  borderColor,
  contentStyle,
  children,
}: Readonly<{
  accentColor?: string;
  /** When set, overrides the default `accentColor + '70'` rim. */
  borderColor?: string;
  /** Merged with inner content padding (e.g. compact horizontal tiles). */
  contentStyle?: StyleProp<ViewStyle>;
  children: React.ReactNode;
}>) {
  const rim = borderColor ?? accentColor + '70';
  const sheetGradient = defaultSheetGradient(HEADER_STYLE_CARD_GRADIENT);
  return (
    <View style={styles.smallTrackingCardWrap}>
      <View style={[styles.smallTrackingCard, { borderColor: rim }]}>
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={sheetGradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
        <View
          style={[styles.smallTrackingCardGlowOverlay, { shadowColor: accentColor }]}
          pointerEvents="none"
        />
        <View style={[styles.smallTrackingCardContent, contentStyle]}>{children}</View>
      </View>
    </View>
  );
}

export default function CustomerMapTrackingSheetShell({
  accentColor = SKY,
  sheetGradient: sheetGradientProp,
  sheetBorder: sheetBorderProp,
  cardInner,
  actionRow,
  panelFooter,
  onChatPress,
  onInfoPress,
  showChatButton = true,
  showInfoButton = true,
  chatLabel = 'Chat',
  onDragDismiss,
  containerStyle,
  bottomOffset = 0,
  sheetHeightScale = 1,
  fitContent = false,
  trackingCardBorderColor,
  sheetMapBackground,
}: Readonly<CustomerMapTrackingSheetShellProps>) {
  const { height: screenH } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const chrome = useMapChromeColors();
  const isDark = useThemeOptional()?.isDark === true;
  const sheetBorder = sheetBorderProp ?? (isDark ? chrome.border : HEADER_STYLE_CARD_BORDER);
  const sheetBodyHeight = screenH * MAP_TRACKING_SHEET_MAX_HEIGHT_RATIO;
  const totalSheetHeight = fitContent
    ? FIT_CONTENT_DRAG_HEIGHT
    : (sheetBodyHeight + MAP_TRACKING_ACTIONS_BAR_HEIGHT) * sheetHeightScale;
  const bottomPad = Math.max(insets.bottom, 10);

  const sheetGradient = sheetGradientProp ?? defaultSheetGradient(HEADER_STYLE_CARD_GRADIENT);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const dragOffset = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, [fadeAnim]);

  const panResponder = useMemo(() => {
    if (!onDragDismiss) {
      return PanResponder.create({ onStartShouldSetPanResponder: () => false });
    }
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 5,
      onPanResponderMove: (_, g) => {
        const dy = g.dy;
        const y = Math.max(0, Math.min(dy, totalSheetHeight));
        dragOffset.setValue(y);
      },
      onPanResponderRelease: (_, g) => {
        const { dy, vy } = g;
        const shouldClose = dy > DRAG_CLOSE_THRESHOLD || (dy > 30 && vy > DRAG_VELOCITY_THRESHOLD);
        if (shouldClose) {
          Animated.timing(dragOffset, {
            toValue: totalSheetHeight,
            duration: 220,
            useNativeDriver: true,
          }).start(() => onDragDismiss());
        } else {
          Animated.spring(dragOffset, {
            toValue: 0,
            useNativeDriver: true,
            damping: 25,
            stiffness: 300,
          }).start();
        }
      },
    });
  }, [dragOffset, onDragDismiss, totalSheetHeight]);

  const panHandlers = onDragDismiss ? panResponder.panHandlers : {};

  const innerCardBorder = trackingCardBorderColor ?? accentColor + '70';
  const hasEmbeddedMap = sheetMapBackground != null;
  const showChatRow = (showChatButton && !!onChatPress) || (showInfoButton && !!onInfoPress);

  return (
    <Animated.View
      style={[
        styles.trackingSheetContainer,
        fitContent
          ? { bottom: bottomOffset, transform: [{ translateY: dragOffset }] }
          : { height: totalSheetHeight, bottom: bottomOffset, transform: [{ translateY: dragOffset }] },
        containerStyle,
      ]}
    >
      {showChatRow ? (
        <View style={styles.trackSheetChatRow}>
          {showChatButton && onChatPress ? (
            <TouchableOpacity
              onPress={() => {
                void hapticFeedback('light');
                onChatPress();
              }}
              style={[styles.trackSheetChatBtn, { borderColor: sheetBorder }]}
              activeOpacity={0.85}
            >
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={sheetGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
              <View style={styles.trackSheetChatBtnContent}>
                <Ionicons name="chatbubble-ellipses-outline" size={22} color={accentColor} />
                <Text style={[styles.trackSheetChatBtnText, { color: accentColor }]}>{chatLabel}</Text>
              </View>
            </TouchableOpacity>
          ) : (
            <View style={{ flex: 1 }} />
          )}
          {showInfoButton && onInfoPress ? (
            <TouchableOpacity
              onPress={() => {
                void hapticFeedback('light');
                onInfoPress();
              }}
              style={[styles.trackSheetInfoBtn, { borderColor: accentColor + '55' }]}
              activeOpacity={0.85}
            >
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
              <LinearGradient
                colors={sheetGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
              <Ionicons name="information-circle-outline" size={22} color={accentColor} style={styles.trackSheetInfoBtnIcon} />
            </TouchableOpacity>
          ) : null}
        </View>
      ) : null}

      <View
        style={[
          styles.trackSheetPanel,
          fitContent && styles.trackSheetPanelFit,
          { paddingBottom: bottomPad, borderColor: sheetBorder },
        ]}
      >
        {hasEmbeddedMap ? (
          <View style={styles.trackSheetMapUnderlay} pointerEvents="box-none">
            {sheetMapBackground}
          </View>
        ) : null}
        <BookingMapGlassBackground />
        {hasEmbeddedMap ? (
          <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlayOnMap]} pointerEvents="none" />
        ) : null}
        <View
          style={[styles.trackSheetGlowLine, { backgroundColor: sheetBorder, shadowColor: 'transparent' }]}
          pointerEvents="none"
        />
        <View style={[styles.trackSheetDragArea, fitContent && styles.trackSheetDragAreaCompact]} {...panHandlers} />
        <View style={styles.trackSheetHandle} />
        <View style={[styles.trackSheetBody, fitContent && styles.trackSheetBodyFit]}>
          <Animated.View
            style={[
              { opacity: fadeAnim },
              fitContent ? styles.trackSheetContentFit : styles.trackSheetContentFill,
            ]}
          >
            {cardInner != null ? (
              <View style={[styles.smallTrackingCardWrap, styles.smallTrackingCardSheetTopInset]}>
                  <View style={[styles.smallTrackingCard, { borderColor: innerCardBorder }]}>
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient
                      colors={sheetGradient}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View
                      style={[
                        StyleSheet.absoluteFill,
                        styles.trackSheetDarkOverlay,
                        isDark && styles.trackSheetDarkOverlayMatched,
                      ]}
                      pointerEvents="none"
                    />
                    <View
                      style={[styles.smallTrackingCardGlowOverlay, { shadowColor: accentColor }]}
                      pointerEvents="none"
                    />
                    <View style={[styles.smallTrackingCardContent, fitContent && styles.smallTrackingCardContentCompact]}>
                      {cardInner}
                    </View>
                  </View>
              </View>
            ) : null}
            <View style={styles.trackSheetCardToActionsSpacer} />
            {actionRow}
            {panelFooter != null ? (
              <View style={styles.panelFooterSlot} pointerEvents="box-none">
                {panelFooter}
              </View>
            ) : null}
          </Animated.View>
        </View>
      </View>
    </Animated.View>
  );
}

/** Default inner layout: kicker + status + progress ring — matches business tracking small card row. */
export function CustomerTrackingCardRow(props: {
  accentColor: string;
  serviceKicker: string;
  statusLine: string;
  progressSlot: React.ReactNode;
}) {
  const { accentColor, serviceKicker, statusLine, progressSlot } = props;
  return (
    <View style={styles.smallCardRow}>
      <View style={styles.smallCardBody}>
        <Text style={styles.smallCardService} numberOfLines={1}>
          {serviceKicker}
        </Text>
        <Text style={[styles.smallCardStatus, { color: accentColor }]} numberOfLines={2}>
          {statusLine}
        </Text>
      </View>
      <View style={[styles.smallRingWrap, { borderColor: accentColor + '60', backgroundColor: accentColor + '12' }]}>
        {progressSlot}
      </View>
    </View>
  );
}

/** Styles copied from wishawasherwithconnect `app/business/bookings/tracking.tsx` (tracking sheet + card). */
const styles = StyleSheet.create({
  trackingSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  trackSheetChatRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 20,
    paddingBottom: 6,
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  trackSheetChatBtn: {
    overflow: 'hidden',
    borderRadius: 18,
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    minWidth: 100,
  },
  trackSheetChatBtnContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    zIndex: 1,
  },
  trackSheetChatBtnText: {
    fontSize: 15,
    fontWeight: '700',
  },
  trackSheetInfoBtn: {
    overflow: 'hidden',
    width: 46,
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackSheetInfoBtnIcon: { zIndex: 1 },
  trackSheetPanel: {
    flex: 1,
    backgroundColor: colors.BG ?? '#0A1929',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 4,
  },
  trackSheetPanelFit: {
    flex: 0,
  },
  trackSheetMapUnderlay: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    zIndex: 0,
  },
  trackSheetGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 4,
  },
  trackSheetDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  /** Keep nested card glass closer to the header wash in dark mode */
  trackSheetDarkOverlayMatched: {
    backgroundColor: 'rgba(0,0,0,0.12)',
  },
  /** Lighter scrim when live map shows through under the glass stack */
  trackSheetDarkOverlayOnMap: {
    backgroundColor: 'rgba(11,18,34,0.34)',
  },
  trackSheetDragArea: {
    width: '100%',
    height: 20,
    marginBottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackSheetDragAreaCompact: {
    height: 12,
  },
  trackSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 4,
    backgroundColor: 'rgba(148,163,184,0.55)',
  },
  trackSheetBody: {
    flex: 1,
    minHeight: 0,
    marginTop: 0,
    overflow: 'hidden',
  },
  trackSheetBodyFit: {
    flex: 0,
    overflow: 'visible',
  },
  trackSheetContentFill: {
    flex: 1,
    minHeight: 0,
  },
  trackSheetContentFit: {
    flexGrow: 0,
    flexShrink: 0,
  },
  panelFooterSlot: {
    flex: 1,
    minHeight: 0,
    marginTop: 4,
  },
  smallTrackingCardWrap: { paddingHorizontal: 0 },
  /** Keep card close to the sheet handle so the block sits higher on screen. */
  smallTrackingCardSheetTopInset: { marginTop: 0 },
  /** Fixed gap between card and primary actions — kept tight (no flex stretch). */
  trackSheetCardToActionsSpacer: {
    height: 8,
    flexShrink: 0,
  },
  smallTrackingCard: {
    overflow: 'hidden',
    borderRadius: 24,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.045)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 14,
    elevation: 8,
  },
  /** Soft outer glow only — no second stroke (avoids double-border look). */
  smallTrackingCardGlowOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 0,
    backgroundColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.42,
    shadowRadius: 20,
    elevation: 4,
  },
  smallTrackingCardContent: {
    paddingHorizontal: 17,
    paddingTop: 13,
    paddingBottom: 15,
  },
  smallTrackingCardContentCompact: {
    paddingTop: 10,
    paddingBottom: 10,
  },
  smallCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  smallRingWrap: {
    marginLeft: 8,
    padding: 4,
    borderRadius: 38,
    borderWidth: 1,
  },
  smallCardBody: { flex: 1, minWidth: 0 },
  smallCardService: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.05,
    marginBottom: 1,
  },
  smallCardStatus: { fontSize: 17, fontWeight: '800', letterSpacing: 0.2 },
  bookingInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 2,
    marginBottom: 0,
  },
  bookingInfoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    gap: 12,
  },
  bookingInfoActionCard: {
    overflow: 'hidden',
    position: 'relative',
  },
  bookingInfoCardTextWrap: { flex: 1, minWidth: 0, zIndex: 1 },
  bookingInfoCardText: { fontSize: 15, fontWeight: '700' },
  bookingInfoCancelBtn: {
    width: 46,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

/** Row / type styles shared with `CustomerTrackingCardRow` — use with `TrackingStyleInnerCard` on map pickers. */
export const trackingInnerLayoutStyles = {
  row: styles.smallCardRow,
  body: styles.smallCardBody,
  kicker: styles.smallCardService,
  status: styles.smallCardStatus,
  ringWrap: styles.smallRingWrap,
} as const;

export const customerMapTrackingSheetActionStyles = {
  bookingInfoRow: styles.bookingInfoRow,
  bookingInfoCard: styles.bookingInfoCard,
  bookingInfoActionCard: styles.bookingInfoActionCard,
  bookingInfoCardTextWrap: styles.bookingInfoCardTextWrap,
  bookingInfoCardText: styles.bookingInfoCardText,
  bookingInfoCancelBtn: styles.bookingInfoCancelBtn,
};
