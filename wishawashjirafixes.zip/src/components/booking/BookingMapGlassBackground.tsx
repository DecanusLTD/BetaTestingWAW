import React from 'react';
import { StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import {
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
  BOOKING_SHEET_BLUR_INTENSITY,
  HEADER_STYLE_CARD_GRADIENT,
} from '../../constants/bookingCardTheme';
import { colors } from '../../constants/colors';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import { useThemeOptional } from '../../contexts/ThemeContext';

/**
 * Glossy navy glass fill — same stack as the map chrome header.
 * Dark mode adds only a light chrome hint so sheets stay aligned without a heavy yellow cast.
 */
export default function BookingMapGlassBackground() {
  const chrome = useMapChromeColors();
  const isDark = useThemeOptional()?.isDark === true;

  return (
    <>
      <BlurView
        intensity={BOOKING_SHEET_BLUR_INTENSITY}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={HEADER_STYLE_CARD_GRADIENT}
        locations={[0, 0.45, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      {isDark ? (
        <LinearGradient
          colors={[chrome.gradient[0], 'transparent', chrome.gradient[2]]}
          locations={[0, 0.35, 1]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[StyleSheet.absoluteFill, { opacity: 0.45 }]}
          pointerEvents="none"
        />
      ) : null}
      <LinearGradient
        colors={[...BOOKING_GLASS_TOP_SHEEN]}
        locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.35 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(10,25,41,0.08)', 'transparent']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
    </>
  );
}

/** Base fill behind glass layers on sheet shells */
export const BOOKING_MAP_GLASS_SHELL_BG = colors.BG ?? '#0A1929';
