import React from 'react';
import {
  View,
  StyleSheet,
  Modal,
  Pressable,
  Dimensions,
  Platform,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../constants/bookingCardTheme';
import { WWSheetCloseButton } from '../ui';
import { useKeyboardHeight } from '../../hooks/useKeyboardHeight';

function TranslucentSheetBackground() {
  return (
    <>
      <BlurView
        intensity={Platform.OS === 'ios' ? 32 : 48}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(14,165,233,0.14)', 'rgba(8,20,38,0.38)', 'rgba(2,10,24,0.52)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.04)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
    </>
  );
}

type BookingBottomSheetOverlayProps = {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  /** Max height as a fraction of window height (default 0.92). */
  maxHeightRatio?: number;
  /** Optional style for the sheet container (above safe area padding). */
  sheetStyle?: StyleProp<ViewStyle>;
  /** Tighter handle/close/body padding — compact list sheets. */
  compact?: boolean;
  /** Lighter glass so content behind the sheet shows through (auth sheets). */
  translucent?: boolean;
  /**
   * Fill remaining sheet height (use with a fixed `sheetStyle.height`).
   * Do not enable on content-sized sheets — flex fill collapses / blanks them.
   */
  fillBody?: boolean;
};

/**
 * Premium bottom sheet: blur + glass layers, drag handle, close only (no title row).
 */
export default function BookingBottomSheetOverlay({
  visible,
  onClose,
  children,
  maxHeightRatio = 0.92,
  sheetStyle,
  compact = false,
  translucent = false,
  fillBody = false,
}: BookingBottomSheetOverlayProps) {
  const insets = useSafeAreaInsets();
  const { height: windowHeight } = Dimensions.get('window');
  const keyboardHeight = useKeyboardHeight(visible);
  const maxHeight = Math.min(windowHeight * maxHeightRatio, windowHeight - insets.top - 8);
  const sheetBottomPad = keyboardHeight > 0 ? 12 : Math.max(insets.bottom, compact ? 8 : 12);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.root} pointerEvents="box-none">
        <Pressable
          style={[styles.backdrop, translucent && styles.backdropTranslucent]}
          onPress={onClose}
          accessibilityRole="button"
          accessibilityLabel="Dismiss"
        />
        <View
          style={[
            styles.sheet,
            translucent && styles.sheetTranslucent,
            {
              maxHeight,
              marginBottom: keyboardHeight,
              paddingBottom: sheetBottomPad,
            },
            sheetStyle,
          ]}
        >
          {translucent ? <TranslucentSheetBackground /> : <BusinessSheetBackground />}
          <View style={[styles.handle, compact && styles.handleCompact]} />
          <View style={[styles.closeRow, compact && styles.closeRowCompact]}>
            <View style={styles.closeRowSpacer} />
            <WWSheetCloseButton variant="bordered" onPress={onClose} iconSize={compact ? 20 : 24} accessibilityLabel="Close" />
          </View>
          <View style={[styles.body, compact && styles.bodyCompact, fillBody && styles.bodyFill]}>
            {children}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.55)',
  },
  backdropTranslucent: {
    backgroundColor: 'rgba(2,6,23,0.28)',
  },
  sheet: {
    width: '100%',
    flexDirection: 'column',
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    overflow: 'hidden',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  sheetTranslucent: {
    backgroundColor: 'rgba(8,20,38,0.32)',
    borderColor: 'rgba(125,211,252,0.28)',
    borderWidth: 1,
    borderBottomWidth: 0,
    shadowOpacity: 0.22,
  },
  handle: {
    alignSelf: 'center',
    width: 42,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.55)',
    marginTop: 4,
    marginBottom: 4,
  },
  handleCompact: {
    width: 36,
    marginTop: 2,
    marginBottom: 2,
  },
  closeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingBottom: 4,
  },
  closeRowCompact: {
    paddingHorizontal: 8,
    paddingBottom: 0,
  },
  closeRowSpacer: {
    flex: 1,
  },
  body: {
    paddingHorizontal: 16,
    paddingTop: 4,
    flexDirection: 'column',
  },
  bodyCompact: {
    paddingHorizontal: 14,
    paddingTop: 0,
  },
  bodyFill: {
    flex: 1,
    flexGrow: 1,
    flexShrink: 1,
    minHeight: 0,
  },
});
