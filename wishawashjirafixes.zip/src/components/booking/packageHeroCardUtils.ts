import { Image, type ImageSourcePropType } from 'react-native';

export const MAINTENANCE_PACK_ID = 'maintenance-pack';

/** Package hero PNG fallback ratio (1024×484) if asset metadata is unavailable. */
export const PACKAGE_HERO_FALLBACK_ASPECT = 484 / 1024;

export function getPackageHeroCardHeight(
  image: ImageSourcePropType,
  cardWidth: number,
  fallbackAspect: number = PACKAGE_HERO_FALLBACK_ASPECT,
): number {
  const meta = Image.resolveAssetSource(image);
  const aspect =
    meta?.width && meta?.height ? meta.height / meta.width : fallbackAspect;
  return Math.max(72, Math.round(cardWidth * aspect));
}

export function isPackageHeroCard(serviceId: string): boolean {
  return serviceId === MAINTENANCE_PACK_ID;
}

export function getPackageHeroCardImage(serviceId: string, image: ImageSourcePropType): ImageSourcePropType | null {
  return isPackageHeroCard(serviceId) ? image : null;
}
