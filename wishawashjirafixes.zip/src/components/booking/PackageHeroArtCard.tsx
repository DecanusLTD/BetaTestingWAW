import React, { useMemo } from 'react';
import {
  View,
  Image,
  StyleSheet,
  TouchableOpacity,
  type ImageSourcePropType,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { getPackageHeroCardHeight } from './packageHeroCardUtils';

type PackageHeroArtCardProps = {
  image: ImageSourcePropType;
  width: number;
  selected?: boolean;
  accentColor?: string;
  onPress: () => void;
  onInfoPress: () => void;
  accessibilityLabel?: string;
  style?: StyleProp<ViewStyle>;
};

/**
 * Full-bleed package card shaped to the hero PNG aspect ratio (no glass overlays).
 */
export default function PackageHeroArtCard({
  image,
  width,
  selected = false,
  accentColor = '#EAB308',
  onPress,
  onInfoPress,
  accessibilityLabel = 'Package',
  style,
}: PackageHeroArtCardProps) {
  const height = useMemo(() => getPackageHeroCardHeight(image, width), [image, width]);

  return (
    <TouchableOpacity
      activeOpacity={0.92}
      onPress={onPress}
      style={[styles.wrap, { width, height }, style]}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
    >
      <View
        style={[
          styles.frame,
          selected
            ? { borderColor: accentColor + 'CC', borderWidth: 2 }
            : { borderColor: 'rgba(148,163,184,0.28)', borderWidth: 1 },
        ]}
      >
        <Image
          source={image}
          style={styles.image}
          resizeMode="cover"
          accessibilityIgnoresInvertColors
        />
        <TouchableOpacity
          style={styles.infoHit}
          onPress={(e) => {
            e.stopPropagation?.();
            onInfoPress();
          }}
          activeOpacity={0.85}
          accessibilityLabel="Service details"
          accessibilityRole="button"
        />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginRight: 0,
  },
  frame: {
    flex: 1,
    borderRadius: 24,
    overflow: 'hidden',
    backgroundColor: '#060a10',
  },
  image: {
    ...StyleSheet.absoluteFillObject,
    width: '100%',
    height: '100%',
  },
  infoHit: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 52,
    height: 52,
    zIndex: 2,
  },
});
