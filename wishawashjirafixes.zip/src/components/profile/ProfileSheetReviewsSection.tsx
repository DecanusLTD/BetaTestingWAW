import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
  useWindowDimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY ?? '#38BDF8';
const H_CARD_GAP = 12;

export type ProfileSheetReviewItem = {
  id: string;
  rating: number;
  body: string | null;
  author: string;
  completedAt?: string | null;
};

function ReviewCard({
  review,
  style,
  bodyNumberOfLines,
}: Readonly<{
  review: ProfileSheetReviewItem;
  style?: object;
  bodyNumberOfLines?: number;
}>) {
  return (
    <View style={[styles.quoteCard, style]}>
      <View style={styles.quoteTop}>
        <Ionicons name="star" size={14} color="#FBBF24" />
        <Text style={styles.quoteRating}>{review.rating.toFixed(1)}</Text>
        <Text style={styles.quoteBy} numberOfLines={1}>
          {review.author}
        </Text>
      </View>
      {review.body ? (
        <Text style={styles.quoteBody} numberOfLines={bodyNumberOfLines}>
          {review.body}
        </Text>
      ) : (
        <Text style={styles.quoteMuted}>Rated without a comment</Text>
      )}
    </View>
  );
}

export default function ProfileSheetReviewsSection({
  reviews,
  loading,
  reviewCount,
}: Readonly<{
  reviews: ProfileSheetReviewItem[];
  loading: boolean;
  /** Total reviews (may exceed loaded preview count). */
  reviewCount?: number;
}>) {
  const { width: windowWidth } = useWindowDimensions();
  const [showAll, setShowAll] = useState(false);
  const cardWidth = Math.min(windowWidth - 56, 300);

  useEffect(() => {
    setShowAll(false);
  }, [reviews]);

  const toggleShowAll = () => {
    void hapticFeedback('light');
    setShowAll((prev) => !prev);
  };

  const totalReviews =
    reviewCount != null && reviewCount >= 0 ? reviewCount : reviews.length;
  const reviewsTitle =
    !loading && totalReviews > 0
      ? `Reviews (${totalReviews})`
      : 'Reviews';

  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionLabel}>{reviewsTitle}</Text>
        {!loading && reviews.length > 0 ? (
          <TouchableOpacity
            onPress={toggleShowAll}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            accessibilityRole="button"
            accessibilityLabel={showAll ? 'Show less reviews' : 'View all reviews'}
          >
            <Text style={styles.viewAllText}>{showAll ? 'Show less' : 'View all'}</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {loading ? (
        <ActivityIndicator color={SKY} style={{ marginVertical: 12 }} />
      ) : reviews.length === 0 ? (
        <View style={styles.emptyCard}>
          <Ionicons name="chatbox-ellipses-outline" size={22} color="rgba(148,163,184,0.75)" />
          <Text style={styles.emptyText}>Reviews from completed bookings will appear here when customers leave them.</Text>
        </View>
      ) : showAll ? (
        <View style={styles.stack}>
          {reviews.map((r) => (
            <ReviewCard key={r.id} review={r} />
          ))}
        </View>
      ) : (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          nestedScrollEnabled
          contentContainerStyle={styles.horizontalContent}
        >
          {reviews.map((r, index) => (
            <ReviewCard
              key={r.id}
              review={r}
              bodyNumberOfLines={4}
              style={{
                width: cardWidth,
                marginRight: index === reviews.length - 1 ? 0 : H_CARD_GAP,
              }}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
    gap: 12,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
  },
  viewAllText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  emptyCard: {
    borderRadius: 18,
    padding: 16,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    alignItems: 'center',
    gap: 10,
  },
  emptyText: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    fontWeight: '600',
  },
  horizontalContent: {
    paddingRight: 4,
  },
  stack: { gap: 10 },
  quoteCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  quoteTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  quoteRating: { fontSize: 14, fontWeight: '800', color: '#F9FAFB' },
  quoteBy: { fontSize: 13, fontWeight: '600', color: 'rgba(148,163,184,0.95)', flex: 1 },
  quoteBody: { fontSize: 14, lineHeight: 21, color: '#E2E8F0', fontStyle: 'italic' },
  quoteMuted: { fontSize: 13, color: 'rgba(148,163,184,0.85)', fontStyle: 'italic' },
});
