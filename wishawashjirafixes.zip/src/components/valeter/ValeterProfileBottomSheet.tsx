/**
 * Valeter profile — bottom sheet (Explore + /owner/valeter-details).
 * Loads profile/stats/reviews when possible; polished placeholders if columns are missing.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  useWindowDimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabase';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { colors } from '../../constants/colors';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
  BOOKING_SHEET_DARK_OVERLAY,
} from '../../constants/bookingCardTheme';
import ProfileSheetReviewsSection, { type ProfileSheetReviewItem } from '../profile/ProfileSheetReviewsSection';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import GradientIconBox from '../shared/GradientIconBox';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { washCompletionService } from '../../services/WashCompletionService';
import { useAuth } from '../../providers/enhanced-auth-context';
import { CCP, ccpFallbackName } from '../../constants/carCareProLabels';
import { WWPrimaryButton, WWSheetCloseButton } from '../ui';

const SKY = colors.SKY;
const CCP_ACCENT_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';
const CCP_ACCENT_GRADIENT = ['rgba(234,179,8,0.85)', 'rgba(120,83,14,0.72)'] as const;
const CCP_ACCENT_BORDER = 'rgba(250,204,21,0.7)';
const CCP_ACCENT_LABEL = '#1C1917';
const SHEET_MAX_RATIO = 0.92;

export type ValeterProfileSheetSeed = {
  id: string;
  name?: string;
  rating?: number;
  totalJobs?: number;
  reviewCount?: number;
  profilePicture?: string | null;
  isOnline?: boolean;
  distanceMiles?: number | null;
  etaMins?: number | null;
  specializations?: string[];
  rank?: number;
  isFavourite?: boolean;
};

type PreviousWash = {
  completedAt: string | null;
  serviceName: string | null;
};

type LoadedExtra = {
  fullName: string | null;
  profilePhotoUrl: string | null;
  bio: string | null;
  isOnline: boolean;
  rating: number;
  totalJobs: number;
  reviewCount: number;
  specializations: string[];
  isVerified: boolean;
  responseHint: string | null;
};

const DEFAULT_BIO_FALLBACK =
  `This ${CCP.singularShort} hasn't added an about section yet. They offer mobile wash and care at your location — tap below to request them.`;

function StatTile({
  icon,
  value,
  label,
  accent,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  value: string;
  label: string;
  accent: string;
}) {
  return (
    <View style={styles.statItem}>
      <View style={styles.statItemTop}>
        <Ionicons name={icon} size={12} color={accent} />
        <Text style={styles.statItemValue}>{value}</Text>
      </View>
      <Text style={styles.statItemLabel}>{label}</Text>
    </View>
  );
}

function StatDivider() {
  return <View style={styles.statDivider} />;
}

const RANK_COLORS: Record<number, string> = {
  1: '#FBBF24',
  2: '#CBD5E1',
  3: '#D97706',
};

function formatRelativeWashDate(dateOnly: string | null | undefined): string {
  if (!dateOnly) return 'recently';
  const d = new Date(dateOnly);
  if (Number.isNaN(d.getTime())) return 'recently';
  const days = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  if (days <= 0) return 'today';
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days} days ago`;
  if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function formatResponseHint(isOnline: boolean, updatedAt: string | null | undefined): string | null {
  if (isOnline) return 'Usually replies within minutes';
  if (!updatedAt) return null;
  const mins = Math.floor((Date.now() - new Date(updatedAt).getTime()) / 60000);
  if (mins < 15) return 'Active recently · quick responses';
  if (mins < 60) return 'Usually replies in ~15 min';
  if (mins < 360) return 'Typically responds within a few hours';
  return null;
}

async function loadGalleryPhotos(valeterId: string): Promise<string[]> {
  const photos: string[] = [];
  try {
    const { data } = await supabase
      .from('valeter_profiles')
      .select('portfolio_images, gallery_urls, work_photos, showcase_images')
      .eq('user_id', valeterId)
      .maybeSingle();
    if (data) {
      for (const key of ['portfolio_images', 'gallery_urls', 'work_photos', 'showcase_images'] as const) {
        const val = (data as Record<string, unknown>)[key];
        if (Array.isArray(val)) {
          val.forEach((url) => {
            if (typeof url === 'string' && url.trim() && !photos.includes(url.trim())) {
              photos.push(url.trim());
            }
          });
        }
      }
    }
  } catch {
    // Optional columns may not exist yet.
  }

  try {
    const completions = await washCompletionService.getValeterWashCompletions(valeterId);
    completions.forEach((completion) => {
      completion.photos?.forEach((url) => {
        if (url && !photos.includes(url)) photos.push(url);
      });
    });
  } catch {
    // In-memory service fallback only.
  }

  return photos.slice(0, 12);
}

export default function ValeterProfileBottomSheet({
  visible,
  onClose,
  valeterId,
  seed,
  onRequestBook,
  onToggleFavourite,
}: {
  visible: boolean;
  onClose: () => void;
  valeterId: string | null;
  seed?: ValeterProfileSheetSeed | null;
  onRequestBook: () => void | Promise<void>;
  /** When provided (e.g. Explore), parent handles favourite persistence. */
  onToggleFavourite?: () => void | Promise<void>;
}) {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { height: windowH, width: windowW } = useWindowDimensions();
  const sheetMaxHeight = Math.round(windowH * SHEET_MAX_RATIO);

  const sheetTranslate = useRef(new Animated.Value(windowH)).current;
  const avatarScale = useRef(new Animated.Value(0.82)).current;
  const bodyOpacity = useRef(new Animated.Value(0)).current;
  const onlinePulse = useRef(new Animated.Value(1)).current;

  const [loading, setLoading] = useState(false);
  const [extra, setExtra] = useState<LoadedExtra | null>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [reviews, setReviews] = useState<ProfileSheetReviewItem[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [photoExpanded, setPhotoExpanded] = useState(false);
  const [galleryPreviewUri, setGalleryPreviewUri] = useState<string | null>(null);
  const [galleryPhotos, setGalleryPhotos] = useState<string[]>([]);
  const [galleryLoading, setGalleryLoading] = useState(false);
  const [previousWash, setPreviousWash] = useState<PreviousWash | null>(null);
  const [isFavourite, setIsFavourite] = useState(Boolean(seed?.isFavourite));

  const load = useCallback(async () => {
    if (!valeterId || valeterId.trim() === '') return;
    setLoading(true);
    setImageFailed(false);
    try {
      let fullName: string | null = null;
      let profilePhotoUrl: string | null = null;
      let bio: string | null = null;

      type VpRow = {
        user_id?: string;
        full_name?: string | null;
        profile_photo_url?: string | null;
        specializations?: string[] | null;
        verification_status?: string | null;
      };

      const { data: vpData, error: vpError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, specializations, verification_status')
        .eq('user_id', valeterId)
        .maybeSingle();

      let specializations: string[] = Array.isArray(seed?.specializations) ? seed.specializations : [];
      let isVerified = false;

      if (!vpError && vpData) {
        const vp = vpData as VpRow;
        fullName = vp.full_name ?? null;
        profilePhotoUrl = vp.profile_photo_url ?? null;
        if (Array.isArray(vp.specializations) && vp.specializations.length > 0) {
          specializations = vp.specializations;
        }
        isVerified = vp.verification_status === 'verified';
      } else {
        const { data: prof } = await supabase.from('profiles').select('full_name, profile_picture').eq('id', valeterId).maybeSingle();
        const p = prof as { full_name?: string; profile_picture?: string } | null;
        fullName = p?.full_name ?? null;
        profilePhotoUrl = p?.profile_picture ?? null;
      }

      const bioRes = await supabase.from('valeter_profiles').select('bio').eq('user_id', valeterId).maybeSingle();
      if (!bioRes.error && bioRes.data) {
        const raw = (bioRes.data as { bio?: string | null }).bio;
        bio = raw?.trim() || null;
      }

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('is_online, updated_at')
        .eq('user_id', valeterId)
        .maybeSingle();
      const presence = presenceData as { is_online?: boolean; updated_at?: string | null } | null;
      const isOnline = presence?.is_online ?? seed?.isOnline ?? false;
      const responseHint = formatResponseHint(isOnline, presence?.updated_at ?? null);

      let rating = seed?.rating ?? 0;
      let totalJobs = seed?.totalJobs ?? 0;
      let reviewCount = 0;
      const stats = await ValeterStatsService.getValeterStats(valeterId).catch(() => null);
      if (stats) {
        rating = stats.averageRating ?? rating;
        totalJobs = stats.totalJobs ?? totalJobs;
        reviewCount = stats.customerReviews ?? 0;
      }

      setExtra({
        fullName,
        profilePhotoUrl,
        bio,
        isOnline,
        rating,
        totalJobs,
        reviewCount,
        specializations,
        isVerified,
        responseHint,
      });
    } catch {
      setExtra({
        fullName: null,
        profilePhotoUrl: null,
        bio: null,
        isOnline: seed?.isOnline ?? false,
        rating: seed?.rating ?? 0,
        totalJobs: seed?.totalJobs ?? 0,
        reviewCount: seed?.reviewCount ?? 0,
        specializations: seed?.specializations ?? [],
        isVerified: false,
        responseHint: seed?.isOnline ? 'Usually replies within minutes' : null,
      });
    } finally {
      setLoading(false);
    }
  }, [valeterId, seed?.isOnline, seed?.rating, seed?.totalJobs, seed?.reviewCount, seed?.specializations]);

  useEffect(() => {
    if (!visible || !valeterId) {
      setExtra(null);
      setGalleryPhotos([]);
      setPreviousWash(null);
      return;
    }
    setIsFavourite(Boolean(seed?.isFavourite));
    void load();
  }, [visible, valeterId, load, seed?.isFavourite]);

  useEffect(() => {
    if (!visible || !valeterId) return;
    let cancelled = false;
    setGalleryLoading(true);
    void loadGalleryPhotos(valeterId).then((photos) => {
      if (!cancelled) setGalleryPhotos(photos);
    }).finally(() => {
      if (!cancelled) setGalleryLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId]);

  useEffect(() => {
    if (!visible || !valeterId || !user?.id) {
      setPreviousWash(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from('bookings')
          .select('completed_at, service_name')
          .eq('user_id', user.id)
          .eq('valeter_id', valeterId)
          .eq('status', 'completed')
          .order('completed_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (cancelled) return;
        if (data) {
          const row = data as { completed_at?: string | null; service_name?: string | null };
          setPreviousWash({
            completedAt: row.completed_at ?? null,
            serviceName: row.service_name ?? null,
          });
        } else {
          setPreviousWash(null);
        }
      } catch {
        if (!cancelled) setPreviousWash(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId, user?.id]);

  useEffect(() => {
    if (!visible || !valeterId || !user?.id || seed?.isFavourite != null || onToggleFavourite) return;
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from('favourites')
          .select('id')
          .eq('user_id', user.id)
          .eq('valeter_id', valeterId)
          .maybeSingle();
        if (!cancelled) setIsFavourite(Boolean(data));
      } catch {
        if (!cancelled) setIsFavourite(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId, user?.id, seed?.isFavourite, onToggleFavourite]);

  useEffect(() => {
    if (visible) {
      sheetTranslate.setValue(windowH);
      avatarScale.setValue(1.06);
      bodyOpacity.setValue(0);
      Animated.parallel([
        Animated.spring(sheetTranslate, { toValue: 0, useNativeDriver: true, speed: 14, bounciness: 4 }),
        Animated.spring(avatarScale, { toValue: 1, useNativeDriver: true, speed: 12, bounciness: 4 }),
        Animated.timing(bodyOpacity, { toValue: 1, duration: 280, delay: 80, useNativeDriver: true }),
      ]).start();
    } else {
      sheetTranslate.setValue(windowH);
      avatarScale.setValue(1.06);
      bodyOpacity.setValue(0);
    }
  }, [visible, windowH, sheetTranslate, avatarScale, bodyOpacity]);

  useEffect(() => {
    if (!visible || !valeterId) {
      setReviews([]);
      return;
    }
    let cancelled = false;
    (async () => {
      setReviewsLoading(true);
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id,rating,review,completed_at,user_id')
          .eq('valeter_id', valeterId)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(8);
        if (cancelled || error || !data?.length) {
          if (!cancelled) setReviews([]);
          return;
        }
        const userIds = [...new Set(data.map((r: { user_id?: string }) => r.user_id).filter(Boolean))] as string[];
        const nameBy = new Map<string, string>();
        if (userIds.length) {
          const { data: profs } = await supabase.from('profiles').select('id,full_name').in('id', userIds);
          (profs || []).forEach((p: { id: string; full_name?: string | null }) => {
            nameBy.set(p.id, p.full_name?.trim() || 'Customer');
          });
        }
        if (!cancelled) {
          setReviews(
            data.map((r: { id: string; rating?: number | null; review?: string | null; user_id?: string; completed_at?: string | null }) => ({
              id: String(r.id),
              rating: Number(r.rating) || 0,
              body: r.review?.trim() || null,
              author: (r.user_id && nameBy.get(r.user_id)) || 'Customer',
              completedAt: r.completed_at ?? null,
            }))
          );
        }
      } catch {
        if (!cancelled) setReviews([]);
      } finally {
        if (!cancelled) setReviewsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId]);

  useEffect(() => {
    if (!visible) {
      setPhotoExpanded(false);
      setGalleryPreviewUri(null);
    }
  }, [visible]);

  const merged = useMemo(() => {
    const name = extra?.fullName || seed?.name || ccpFallbackName();
    const photo = extra?.profilePhotoUrl ?? seed?.profilePicture ?? null;
    const rating = extra?.rating ?? seed?.rating ?? 0;
    const jobs = extra?.totalJobs ?? seed?.totalJobs ?? 0;
    const reviewCount = extra?.reviewCount ?? seed?.reviewCount ?? 0;
    const online = extra?.isOnline ?? seed?.isOnline ?? false;
    const bioText = (extra?.bio && extra.bio.trim()) || null;
    const specializations = extra?.specializations ?? seed?.specializations ?? [];
    const isVerified = extra?.isVerified ?? false;
    const rank = seed?.rank ?? null;
    const isTopRated = rating >= 4.8 && jobs >= 10;
    return {
      name: formatDisplayName(name) || name,
      photo,
      rating,
      jobs,
      reviewCount,
      online,
      bioText,
      specializations,
      isVerified,
      rank,
      isTopRated,
      distanceMiles: seed?.distanceMiles ?? null,
      etaMins: seed?.etaMins ?? null,
      responseHint: extra?.responseHint ?? null,
    };
  }, [extra, seed]);

  const handleToggleFavourite = useCallback(async () => {
    if (onToggleFavourite) {
      void hapticFeedback('light');
      onToggleFavourite();
      return;
    }
    if (!user?.id || !valeterId) return;
    void hapticFeedback('light');
    const next = !isFavourite;
    setIsFavourite(next);
    try {
      if (next) {
        await supabase.from('favourites').insert({ user_id: user.id, valeter_id: valeterId });
      } else {
        await supabase.from('favourites').delete().eq('user_id', user.id).eq('valeter_id', valeterId);
      }
    } catch {
      setIsFavourite(!next);
      Alert.alert('Error', 'Could not update favourite.');
    }
  }, [onToggleFavourite, user?.id, valeterId, isFavourite]);

  useEffect(() => {
    if (!visible || !merged.online) {
      onlinePulse.setValue(1);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(onlinePulse, { toValue: 1.08, duration: 900, useNativeDriver: true }),
        Animated.timing(onlinePulse, { toValue: 1, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [visible, merged.online, onlinePulse]);

  const featuredReview = useMemo(() => {
    const withBody = reviews.filter((r) => r.body && r.body.trim().length > 0);
    if (!withBody.length) return null;
    return withBody.reduce((best, r) => (r.rating > best.rating ? r : best), withBody[0]);
  }, [reviews]);

  const bioParagraph = merged.bioText || DEFAULT_BIO_FALLBACK;
  const rankColor = merged.rank != null ? RANK_COLORS[merged.rank] ?? CCP_ACCENT_YELLOW : null;
  const ctaTitle = previousWash ? 'Book again' : CCP.requestButton;
  const ctaSubtitle = previousWash
    ? `Last wash ${formatRelativeWashDate(previousWash.completedAt)}${
        previousWash.serviceName ? ` · ${previousWash.serviceName}` : ''
      }`
    : merged.online
      ? [
          merged.distanceMiles != null ? `${merged.distanceMiles.toFixed(1)} mi away` : null,
          merged.etaMins != null ? `~${merged.etaMins} min ETA` : null,
          merged.responseHint ?? 'Available now',
        ]
          .filter(Boolean)
          .join(' · ')
      : merged.responseHint ?? 'Request a wash — they’ll confirm availability';

  if (!valeterId) return null;

  const showFavourite = seed?.isFavourite ?? isFavourite;
  const galleryCardWidth = Math.min(windowW * 0.42, 168);

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <View style={styles.root}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Dismiss profile" />
        <Animated.View
          style={[
            styles.panel,
            {
              borderColor: HEADER_STYLE_CARD_BORDER,
              maxHeight: sheetMaxHeight,
              paddingBottom: Math.max(14, insets.bottom),
              transform: [{ translateY: sheetTranslate }],
            },
          ]}
        >
          <BusinessSheetBackground />
          <View style={[styles.rail, { backgroundColor: CCP_ACCENT_YELLOW + '99', shadowColor: CCP_ACCENT_YELLOW }]} pointerEvents="none" />
          <View style={styles.handle} />

          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollContent}
          >
            <View style={styles.heroBanner}>
              <TouchableOpacity
                activeOpacity={merged.photo && !imageFailed ? 0.96 : 1}
                disabled={!merged.photo || imageFailed}
                onPress={() => {
                  void hapticFeedback('light');
                  setPhotoExpanded(true);
                }}
                accessibilityRole="button"
                accessibilityLabel={merged.photo && !imageFailed ? 'View profile photo' : undefined}
                style={StyleSheet.absoluteFill}
              >
                {merged.photo && !imageFailed ? (
                  <Animated.Image
                    source={{ uri: merged.photo }}
                    style={[styles.heroPhotoFill, { transform: [{ scale: avatarScale }] }]}
                    resizeMode="cover"
                    onError={() => setImageFailed(true)}
                  />
                ) : (
                  <View style={styles.heroPhotoFallback}>
                    <GradientIconBox icon="person" preset="sky" boxSize={96} borderRadius={28} elevated size={44} />
                  </View>
                )}
              </TouchableOpacity>

              <LinearGradient
                colors={['rgba(2,6,23,0.15)', 'rgba(2,6,23,0.35)', 'rgba(2,6,23,0.92)']}
                locations={[0, 0.42, 1]}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />

              <View style={styles.heroTopRow} pointerEvents="box-none">
                {merged.rank != null && merged.rank <= 3 ? (
                  <View style={[styles.rankRibbon, { backgroundColor: rankColor + 'E8', borderColor: rankColor ?? CCP_ACCENT_YELLOW }]}>
                    <Ionicons name="trophy" size={12} color="#0F172A" />
                    <Text style={styles.rankRibbonText}>#{merged.rank} Top pick</Text>
                  </View>
                ) : (
                  <View style={styles.heroTopSpacer} />
                )}
                <View style={styles.heroTopActions}>
                  {user?.id ? (
                    <TouchableOpacity
                      onPress={() => void handleToggleFavourite()}
                      hitSlop={10}
                      style={styles.heartBtn}
                      accessibilityLabel={
                        showFavourite
                          ? `Remove ${merged.name} from favourites`
                          : `Save ${merged.name} to favourites`
                      }
                    >
                      <Ionicons
                        name={showFavourite ? 'heart' : 'heart-outline'}
                        size={22}
                        color={showFavourite ? '#F87171' : 'rgba(248,250,252,0.88)'}
                      />
                    </TouchableOpacity>
                  ) : null}
                  <WWSheetCloseButton onPress={onClose} hitSlop={14} accessibilityLabel="Close" />
                </View>
              </View>

              {merged.online ? (
                <View style={styles.heroOnlineBadge} pointerEvents="none">
                  <Animated.View
                    style={[
                      styles.onlinePulseRing,
                      {
                        transform: [{ scale: onlinePulse }],
                        opacity: onlinePulse.interpolate({
                          inputRange: [1, 1.08],
                          outputRange: [0.45, 0],
                        }),
                      },
                    ]}
                  />
                  <View style={styles.onlineDot} />
                </View>
              ) : null}

              {merged.photo && !imageFailed ? (
                <View style={styles.heroExpandHint} pointerEvents="none">
                  <Ionicons name="expand-outline" size={14} color="#F8FAFC" />
                </View>
              ) : null}

              <View style={styles.heroCenter} pointerEvents="box-none">
                <Text style={styles.name} numberOfLines={2}>
                  {merged.name}
                </Text>
                <Text style={styles.kicker}>{CCP.singularShort}</Text>

                <View style={styles.trustRow}>
                  {merged.online ? (
                    <View style={[styles.trustPill, styles.trustPillOnline]}>
                      <View style={styles.trustPillDot} />
                      <Text style={styles.trustPillOnlineText}>Available now</Text>
                    </View>
                  ) : null}
                  {merged.isVerified ? (
                    <View style={[styles.trustPill, styles.trustPillVerified]}>
                      <Ionicons name="shield-checkmark" size={12} color="#34D399" />
                      <Text style={styles.trustPillVerifiedText}>Verified</Text>
                    </View>
                  ) : null}
                  {merged.isTopRated ? (
                    <View style={[styles.trustPill, styles.trustPillTopRated]}>
                      <Ionicons name="star" size={12} color="#FBBF24" />
                      <Text style={styles.trustPillTopRatedText}>Top rated</Text>
                    </View>
                  ) : null}
                  {merged.responseHint && !merged.online ? (
                    <View style={[styles.trustPill, styles.trustPillResponse]}>
                      <Ionicons name="chatbubble-ellipses-outline" size={12} color={SKY} />
                      <Text style={styles.trustPillResponseText}>{merged.responseHint}</Text>
                    </View>
                  ) : null}
                </View>
              </View>
            </View>

            <Animated.View style={[styles.bodyPad, { opacity: bodyOpacity }]}>
              {previousWash ? (
                <TouchableOpacity
                  style={styles.bookAgainBanner}
                  activeOpacity={0.88}
                  onPress={() => {
                    void hapticFeedback('medium');
                    void Promise.resolve(onRequestBook());
                  }}
                >
                  <View style={styles.bookAgainIconWrap}>
                    <Ionicons name="refresh-circle" size={22} color={CCP_ACCENT_YELLOW} />
                  </View>
                  <View style={styles.bookAgainTextCol}>
                    <Text style={styles.bookAgainTitle}>You’ve washed with {merged.name.split(' ')[0]}</Text>
                    <Text style={styles.bookAgainSubtitle}>
                      Last wash {formatRelativeWashDate(previousWash.completedAt)}
                      {previousWash.serviceName ? ` · ${previousWash.serviceName}` : ''}
                    </Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="rgba(148,163,184,0.9)" />
                </TouchableOpacity>
              ) : null}

              <View style={styles.statStrip}>
                <StatTile
                  icon="star"
                  value={merged.rating > 0 ? merged.rating.toFixed(1) : 'New'}
                  label="Rating"
                  accent="#FBBF24"
                />
                <StatDivider />
                <StatTile icon="checkmark-done-outline" value={String(merged.jobs)} label="Jobs done" accent={SKY} />
                <StatDivider />
                <StatTile
                  icon="chatbubbles-outline"
                  value={merged.reviewCount > 0 ? String(merged.reviewCount) : '—'}
                  label="Reviews"
                  accent="#A78BFA"
                />
              </View>

              {merged.distanceMiles != null || merged.etaMins != null ? (
                <View style={styles.arrivalStrip}>
                  {merged.distanceMiles != null ? (
                    <View style={styles.arrivalItem}>
                      <Ionicons name="navigate-outline" size={15} color={SKY} />
                      <Text style={styles.arrivalText}>{merged.distanceMiles.toFixed(1)} mi away</Text>
                    </View>
                  ) : null}
                  {merged.etaMins != null ? (
                    <View style={styles.arrivalItem}>
                      <Ionicons name="time-outline" size={15} color={SKY} />
                      <Text style={styles.arrivalText}>~{merged.etaMins} min arrival</Text>
                    </View>
                  ) : null}
                </View>
              ) : null}

              {galleryLoading ? (
                <View style={styles.section}>
                  <Text style={styles.sectionLabel}>Their work</Text>
                  <ActivityIndicator color={SKY} style={{ marginVertical: 8 }} />
                </View>
              ) : galleryPhotos.length > 0 ? (
                <View style={styles.section}>
                  <Text style={styles.sectionLabel}>Their work</Text>
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.galleryRow}
                  >
                    {galleryPhotos.map((uri, index) => (
                      <TouchableOpacity
                        key={`${uri}-${index}`}
                        activeOpacity={0.88}
                        onPress={() => {
                          void hapticFeedback('light');
                          setGalleryPreviewUri(uri);
                        }}
                        style={[styles.galleryCard, { width: galleryCardWidth }]}
                      >
                        <Image source={{ uri }} style={styles.galleryImage} resizeMode="cover" />
                        <LinearGradient
                          colors={['transparent', 'rgba(2,6,23,0.75)']}
                          style={styles.galleryImageOverlay}
                          pointerEvents="none"
                        />
                        <View style={styles.galleryExpandHint} pointerEvents="none">
                          <Ionicons name="expand-outline" size={12} color="#F8FAFC" />
                        </View>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              ) : null}

              {merged.specializations.length > 0 ? (
                <View style={styles.section}>
                  <Text style={styles.sectionLabel}>Specialities</Text>
                  <View style={styles.specRow}>
                    {merged.specializations.slice(0, 5).map((spec) => (
                      <View key={spec} style={styles.specChip}>
                        <Text style={styles.specChipText}>{spec}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              ) : null}

              {featuredReview ? (
                <View style={styles.section}>
                  <Text style={styles.sectionLabel}>Customers say</Text>
                  <View style={styles.featuredQuote}>
                    <Ionicons name="chatbubble-ellipses-outline" size={18} color={CCP_ACCENT_YELLOW} style={styles.featuredQuoteIcon} />
                    <Text style={styles.featuredQuoteBody} numberOfLines={4}>
                      “{featuredReview.body}”
                    </Text>
                    <View style={styles.featuredQuoteFooter}>
                      <Ionicons name="star" size={12} color="#FBBF24" />
                      <Text style={styles.featuredQuoteMeta}>
                        {featuredReview.rating.toFixed(1)} · {featuredReview.author}
                      </Text>
                    </View>
                  </View>
                </View>
              ) : null}

              <View style={styles.section}>
                <Text style={styles.sectionLabel}>About</Text>
                <View style={styles.aboutCard}>
                  {loading && !extra ? (
                    <ActivityIndicator color={SKY} style={{ marginVertical: 8 }} />
                  ) : (
                    <Text style={styles.aboutBody}>{bioParagraph}</Text>
                  )}
                </View>
              </View>

              <ProfileSheetReviewsSection
                reviews={reviews}
                loading={reviewsLoading}
                reviewCount={merged.reviewCount}
              />
            </Animated.View>
          </ScrollView>

          <View style={styles.ctaWrap}>
            <Text style={styles.ctaSubtitle} numberOfLines={2}>
              {ctaSubtitle}
            </Text>
            <WWPrimaryButton
              title={ctaTitle}
              onPress={() => {
                void hapticFeedback('medium');
                void Promise.resolve(onRequestBook());
              }}
              leftIconName="flash-outline"
              leftIconSize={22}
              gradientColors={CCP_ACCENT_GRADIENT}
              borderColor={CCP_ACCENT_BORDER}
              labelColor={CCP_ACCENT_LABEL}
            />
          </View>
        </Animated.View>
      </View>

      <Modal
        visible={Boolean(photoExpanded && merged.photo && !imageFailed) || Boolean(galleryPreviewUri)}
        transparent
        animationType="fade"
        onRequestClose={() => {
          setPhotoExpanded(false);
          setGalleryPreviewUri(null);
        }}
      >
        <View style={styles.photoViewerRoot}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => {
              setPhotoExpanded(false);
              setGalleryPreviewUri(null);
            }}
            accessibilityLabel="Close photo"
          />
          <View style={[styles.photoViewerTopBar, { paddingTop: insets.top + 8 }]}>
            <WWSheetCloseButton
              size={44}
              iconSize={26}
              iconColor="#FFFFFF"
              onPress={() => {
                setPhotoExpanded(false);
                setGalleryPreviewUri(null);
              }}
              accessibilityLabel="Close photo"
            />
          </View>
          {galleryPreviewUri ? (
            <Image source={{ uri: galleryPreviewUri }} style={styles.photoViewerImage} resizeMode="contain" />
          ) : merged.photo ? (
            <Image source={{ uri: merged.photo }} style={styles.photoViewerImage} resizeMode="contain" />
          ) : null}
        </View>
      </Modal>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.55)',
  },
  panel: {
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderWidth: 1,
    borderBottomWidth: 0,
    overflow: 'hidden',
  },
  sheetDarkScrim: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  rail: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
  },
  handle: {
    alignSelf: 'center',
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.45)',
    marginTop: 10,
    marginBottom: 6,
  },
  scrollContent: {
    paddingBottom: 12,
  },
  heroBanner: {
    minHeight: 300,
    overflow: 'hidden',
    marginBottom: 4,
    backgroundColor: 'rgba(15,23,42,0.9)',
  },
  heroPhotoFill: {
    ...StyleSheet.absoluteFillObject,
    width: '100%',
    height: '100%',
  },
  heroPhotoFallback: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.92)',
  },
  heroTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 4,
    zIndex: 2,
  },
  heroTopSpacer: {
    width: 1,
  },
  heroTopActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  heartBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
  },
  rankRibbon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  rankRibbonText: {
    color: '#0F172A',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  heroCenter: {
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingTop: 72,
    paddingBottom: 20,
    zIndex: 2,
  },
  bodyPad: {
    paddingHorizontal: 18,
  },
  heroOnlineBadge: {
    position: 'absolute',
    left: 16,
    top: 52,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(15,23,42,0.88)',
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 3,
  },
  onlinePulseRing: {
    position: 'absolute',
    top: -6,
    left: -6,
    right: -6,
    bottom: -6,
    borderRadius: 17,
    borderWidth: 2,
    borderColor: '#34D399',
  },
  heroExpandHint: {
    position: 'absolute',
    right: 16,
    bottom: 96,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(15,23,42,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.22)',
    zIndex: 3,
  },
  onlineDot: {
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: '#34D399',
  },
  name: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.4,
    textAlign: 'center',
  },
  kicker: {
    marginTop: 4,
    color: 'rgba(226,232,240,0.72)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  trustRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
  },
  trustPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  trustPillOnline: {
    backgroundColor: 'rgba(52,211,153,0.14)',
    borderColor: 'rgba(52,211,153,0.45)',
  },
  trustPillOnlineText: {
    color: '#34D399',
    fontSize: 11,
    fontWeight: '800',
  },
  trustPillDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#34D399',
  },
  trustPillVerified: {
    backgroundColor: 'rgba(52,211,153,0.1)',
    borderColor: 'rgba(52,211,153,0.35)',
  },
  trustPillVerifiedText: {
    color: '#6EE7B7',
    fontSize: 11,
    fontWeight: '800',
  },
  trustPillTopRated: {
    backgroundColor: 'rgba(251,191,36,0.12)',
    borderColor: 'rgba(251,191,36,0.4)',
  },
  trustPillTopRatedText: {
    color: '#FBBF24',
    fontSize: 11,
    fontWeight: '800',
  },
  trustPillResponse: {
    backgroundColor: 'rgba(56,189,248,0.1)',
    borderColor: 'rgba(56,189,248,0.32)',
  },
  trustPillResponseText: {
    color: '#7DD3FC',
    fontSize: 11,
    fontWeight: '800',
  },
  bookAgainBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(234,179,8,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(250,204,21,0.35)',
  },
  bookAgainIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(234,179,8,0.16)',
  },
  bookAgainTextCol: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  bookAgainTitle: {
    color: '#FDE68A',
    fontSize: 14,
    fontWeight: '800',
  },
  bookAgainSubtitle: {
    color: 'rgba(226,232,240,0.78)',
    fontSize: 12,
    fontWeight: '600',
  },
  galleryRow: {
    gap: 10,
    paddingRight: 4,
  },
  galleryCard: {
    height: 132,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.55)',
  },
  galleryImage: {
    width: '100%',
    height: '100%',
  },
  galleryImageOverlay: {
    ...StyleSheet.absoluteFillObject,
  },
  galleryExpandHint: {
    position: 'absolute',
    right: 8,
    bottom: 8,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.72)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  statStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
    paddingVertical: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    gap: 3,
  },
  statItemTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statItemValue: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  statItemLabel: {
    color: 'rgba(148,163,184,0.82)',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  statDivider: {
    width: StyleSheet.hairlineWidth,
    height: 24,
    backgroundColor: 'rgba(148,163,184,0.22)',
  },
  arrivalStrip: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(56,189,248,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.22)',
  },
  arrivalItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  arrivalText: {
    color: '#BAE6FD',
    fontSize: 13,
    fontWeight: '700',
  },
  specRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  specChip: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: 'rgba(234,179,8,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(250,204,21,0.35)',
  },
  specChipText: {
    color: '#FDE68A',
    fontSize: 12,
    fontWeight: '700',
  },
  featuredQuote: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.58)',
    borderWidth: 1,
    borderColor: 'rgba(250,204,21,0.28)',
    position: 'relative',
  },
  featuredQuoteIcon: {
    marginBottom: 8,
    opacity: 0.9,
  },
  featuredQuoteBody: {
    color: 'rgba(248,250,252,0.94)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '600',
    fontStyle: 'italic',
  },
  featuredQuoteFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 10,
  },
  featuredQuoteMeta: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '700',
  },
  ctaWrap: {
    paddingHorizontal: 18,
    paddingTop: 6,
    paddingBottom: 4,
    gap: 6,
    width: '100%',
    alignSelf: 'stretch',
  },
  ctaSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 17,
  },
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  aboutCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  aboutBody: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  photoViewerRoot: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.94)',
    justifyContent: 'center',
  },
  photoViewerTopBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 2,
    paddingHorizontal: 16,
    alignItems: 'flex-end',
  },
  photoViewerImage: {
    width: '100%',
    height: '78%',
    alignSelf: 'center',
  },
});
