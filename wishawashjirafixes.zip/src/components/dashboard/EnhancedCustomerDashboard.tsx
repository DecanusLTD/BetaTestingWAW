import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  StatusBar,
  Alert,
  Image,
  Pressable,
  Modal,
  Platform,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import GradientIconBox from '../shared/GradientIconBox';
import TopCareProCard from '../shared/TopCareProCard';
import AppHeader from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import {
  SUBTLE_WAVE_DASHBOARD_TINT_ENABLED,
  subtleWaveDashboardTint,
} from '../../constants/subtleWaveDashboardTint';
import { useThemeOptional } from '../../contexts/ThemeContext';
import { colors } from '../../constants/colors';
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { fetchValeterIdentitiesByIds, fetchValeterIdentity, resolveValeterDisplayName } from '../../utils/valeterDisplayName';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../hooks/useOwnerScrollContentPadding';
import { DASHBOARD_SPLIT_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import { SkeletonList } from '../shared/SkeletonLoader';
import AnimatedProgress from '../booking/AnimatedProgress';
import {
  normalizeStatusForTracking,
  getStatusProgress as getTripStatusProgress,
  getRingColorForStep,
  getStatusMessage,
  isCustomerDetailingService,
} from '../../utils/trackingStatusHelpers';
import {
  MapValeterMarkerView,
} from '../shared/washValeterPlaceholders';
import ValeterProfileBottomSheet, {
  type ValeterProfileSheetSeed,
} from '../valeter/ValeterProfileBottomSheet';
import HubLocationProfileBottomSheet, {
  type HubLocationSheetSeed,
} from '../hub/HubLocationProfileBottomSheet';
import { BlurView } from 'expo-blur';
import { useAdaptiveLayout } from '../../constants/adaptiveLayout';
import { MAP_LOCKED_DARK, NAVIGATION_MAP_STYLE } from '../../constants/mapConstants';
import { MapMarkerCustomerVehicle, MapMarkerServiceSpot, MapMarkerValeterLive } from '../maps/MapMarkerViews';
import { distanceKm, regionForCoordinates } from '../../utils/mapUtils';
import { isBookingManuallyStarted } from '../../utils/activeBookingGuard';
import { getLoyaltyBalance } from '../../services/LoyaltyService';
import { fetchUnreadBookingChatThreads } from '../../services/BookingChatService';
import { getNextMilestone, getTierProgress } from '../../utils/loyaltyTier';
import {
  clearPendingRatingBookingId,
  getPendingRatingBookingId,
} from '../../utils/pendingCustomerRating';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../constants/launchCustomerScope';
import { CCP, ccpFallbackName, ccpPluralLower, ccpSingularLower } from '../../constants/carCareProLabels';
import {
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
} from '../../constants/bookingCardTheme';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';
import { accentToGradient } from '../../utils/accentGradient';
import {
  cpz,
  dz,
  dzHero,
  getTopCareProCardWidth,
} from '../../constants/topCareProCardLayout';

const { width } = Dimensions.get('window');

/** Dashboard Top Care Pros — slightly tighter than explore sheet tiles. */
const TOP_CARE_PRO_CARD_ZOOM = 0.84;

/** Book A Wish glass tint — saturated enough to read on blur; still translucent. */
const CUSTOMER_WISH_HERO_GRADIENT = [
  'rgba(14,165,233,0.58)',
  'rgba(56,189,248,0.42)',
  'rgba(202,224,80,0.48)',
] as const;

const CUSTOMER_WISH_HERO_GLASS_RIM = 'rgba(91, 143, 168, 0.48)';

function renderBookWishGlassFill() {
  return (
    <>
      <View style={styles.bookWishGlassFallback} />
      <BlurView
        intensity={Platform.OS === 'ios' ? 58 : 84}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[...CUSTOMER_WISH_HERO_GRADIENT]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.26)', 'rgba(255,255,255,0.1)', 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View pointerEvents="none" style={styles.bookWishGlassRim} />
      <View pointerEvents="none" style={styles.bookWishGlassTopGlow} />
    </>
  );
}

function renderTopPickGlossSheen() {
  return (
    <LinearGradient
      colors={[...BOOKING_GLASS_TOP_SHEEN]}
      locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0.85 }}
      style={StyleSheet.absoluteFill}
      pointerEvents="none"
    />
  );
}

function getValeterInitials(name: string | null): string {
  if (!name?.trim()) return '—';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    const lastInitial = parts.at(-1)?.[0] ?? '';
    return (parts[0][0] + lastInitial).toUpperCase().slice(0, 2);
  }
  return name.slice(0, 2).toUpperCase();
}
const isSmallScreen = width < 375;
const DASHBOARD_H_INSET = isSmallScreen ? 12 : 16;
const DASHBOARD_V_GAP = dz(8);
const DASHBOARD_NEARBY_RADIUS_KM = 40; // ~25 miles
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
  latitude?: number | null;
  longitude?: number | null;
}

interface ValeterReview {
  rating: number;
  review?: string | null;
}

type TopWasherValeter = {
  kind: 'valeter';
  id: string;
  name: string;
  organization: string;
  rating: number;
  jobsCompleted: number;
  reviewCount: number;
  isOnline: boolean;
  profilePicture?: string | null;
  joinedAt?: string | null;
  reviews?: ValeterReview[];
  latitude?: number | null;
  longitude?: number | null;
};

type TopWasherHub = {
  kind: 'hub';
  id: string;
  name: string;
  organization: string;
  rating: number;
  jobsCompleted: number;
  reviewCount: number;
  isOnline: boolean;
  profilePicture?: string | null;
  latitude?: number | null;
  longitude?: number | null;
};

type TopWasher = TopWasherValeter | TopWasherHub;

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus =
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'pending_payment'
  | 'pending_valeter_acceptance'
  | 'pending_business_acceptance'
  | 'pending'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  location_id: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
  valeter_id: string | null;
  counterparty_photo_url: string | null;
  latitude: number | null;
  longitude: number | null;
  vehicle_id?: string | null;
  wash_type?: string | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = [
  'scheduled',
  'in_progress',
  'pending_payment',
  'pending_valeter_acceptance',
  'pending_business_acceptance',
  'pending',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
];
const ACTIVE_STATUSES_FALLBACK = ACTIVE_STATUSES.filter((s) => s !== 'pending_business_acceptance');

type ActiveBookingSectionProps = Readonly<{
  activeBookingLoading: boolean;
  activeBooking: ActiveBooking | null;
  activeBookingMapRegion: Region | null;
  userLocation: { latitude: number; longitude: number } | null;
  valeterLocation: { latitude: number; longitude: number } | null;
  onResumeTracking: () => void;
  styles: Record<string, object>;
  eta?: number | null;
  loyaltyData?: LoyaltyData | null;
  reservedCounts?: { nearbyValeters: number; carWashCount: number; detailingHubCount: number; recentBookingsLoading: boolean };
  sectionStyle?: any;
}>;

function ActiveBookingSection({
  activeBookingLoading,
  activeBooking,
  activeBookingMapRegion,
  userLocation,
  valeterLocation,
  onResumeTracking,
  styles: s,
  eta: _eta,
  loyaltyData: _loyaltyData,
  reservedCounts: _reservedCounts,
  sectionStyle,
}: ActiveBookingSectionProps) {
  if (activeBookingLoading) {
    return (
      <View style={[s.activeBookingSection, sectionStyle]}>
        <View style={s.activeBookingSkeleton}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={s.activeBookingLoadingText}>Checking active booking…</Text>
        </View>
      </View>
    );
  }

  if (!activeBooking) return null;

  const isPaymentDue = activeBooking.status === 'pending_payment';
  const isConnectingPro =
    activeBooking.status === 'pending_valeter_acceptance' ||
    activeBooking.status === 'pending' ||
    activeBooking.status === 'pending_business_acceptance';
  const chatLocked = isPaymentDue || isConnectingPro;
  const normalized = normalizeStatusForTracking(activeBooking.status);
  const isDetailing = isCustomerDetailingService(activeBooking.service_type, activeBooking.service_name);
  const progress = getTripStatusProgress(normalized);
  const accent = isPaymentDue ? '#F59E0B' : getRingColorForStep(normalized) || SKY;
  const serviceLabel = getServiceDisplayName(activeBooking.service_type, activeBooking.service_name);
  const statusTitle = isPaymentDue
    ? 'Payment due'
    : getStatusMessage(
        normalized,
        activeBooking.location_id ? { name: 'Car Wash' } : null,
        isDetailing,
      );
  const proRole = isDetailing ? 'Detailer' : CCP.singularShort;
  const ctaLabel = isPaymentDue ? 'Pay now' : 'Track live';
  const openPrimary = () => {
    if (isPaymentDue) {
      router.push({ pathname: '/owner/track', params: { bookingId: activeBooking.id } });
      return;
    }
    onResumeTracking();
  };
  const openChat = () => {
    if (isPaymentDue) {
      Alert.alert('Payment needed', 'Finish payment first, then you can message your Care Pro.');
      return;
    }
    if (isConnectingPro) {
      Alert.alert(
        'Still connecting',
        `Chat unlocks once your ${ccpSingularLower()} accepts the booking.`,
      );
      return;
    }
    void hapticFeedback('light');
    router.push({ pathname: '/owner/inbox', params: { bookingId: activeBooking.id } });
  };

  return (
    <View style={[s.activeBookingSection, sectionStyle]}>
      <TouchableOpacity activeOpacity={0.92} onPress={openPrimary} style={s.activeBookingCard}>
        <View style={s.activeBookingMapContainer}>
          {activeBookingMapRegion && userLocation ? (
            <MapView
              style={StyleSheet.absoluteFill}
              region={activeBookingMapRegion}
              scrollEnabled={false}
              zoomEnabled={false}
              pitchEnabled={false}
              rotateEnabled={false}
              customMapStyle={NAVIGATION_MAP_STYLE}
              userInterfaceStyle={MAP_LOCKED_DARK}
              pointerEvents="none"
            >
              <Marker coordinate={userLocation}>
                <MapMarkerCustomerVehicle size={dz(34)} />
              </Marker>
              {valeterLocation ? (
                <Marker coordinate={valeterLocation}>
                  <MapValeterMarkerView size={38} />
                </Marker>
              ) : null}
              {activeBooking.latitude != null &&
              activeBooking.longitude != null &&
              !valeterLocation ? (
                <Marker
                  coordinate={{
                    latitude: activeBooking.latitude,
                    longitude: activeBooking.longitude,
                  }}
                >
                  <MapMarkerServiceSpot size={dz(34)} />
                </Marker>
              ) : null}
            </MapView>
          ) : (
            <LinearGradient
              colors={
                isPaymentDue
                  ? ['rgba(245,158,11,0.18)', 'rgba(15,23,42,0.92)']
                  : ['rgba(56,189,248,0.16)', 'rgba(15,23,42,0.92)']
              }
              style={StyleSheet.absoluteFill}
            />
          )}
          <LinearGradient
            colors={['rgba(2,6,23,0.08)', 'rgba(2,6,23,0.22)', 'rgba(2,6,23,0.88)']}
            locations={[0, 0.45, 1]}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={s.activeBookingLiveBadge} pointerEvents="none">
            <View style={[s.activeBookingLiveDot, { backgroundColor: accent }]} />
            <Text style={s.activeBookingLiveText}>{isPaymentDue ? 'Action needed' : 'Live job'}</Text>
          </View>
        </View>

        <View style={s.activeBookingBody}>
          <BlurView intensity={Platform.OS === 'ios' ? 28 : 40} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={['rgba(15,23,42,0.55)', 'rgba(2,6,23,0.88)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <LinearGradient
            colors={[...BOOKING_GLASS_TOP_SHEEN]}
            locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
            style={s.activeBookingBodySheen}
            pointerEvents="none"
          />

          <View style={s.activeBookingMainRow}>
            <View style={s.activeBookingRingWrap}>
              <AnimatedProgress
                progress={progress}
                size={48}
                strokeWidth={3}
                showPercentage
                percentageFontSize={12}
                color={accent}
                light
              />
            </View>
            <View style={s.activeBookingCardContent}>
              <Text style={[s.activeBookingTitle, { color: accent }]} numberOfLines={1}>
                {statusTitle}
              </Text>
              <Text style={s.activeBookingSubtitle} numberOfLines={1}>
                {serviceLabel}
              </Text>
              {activeBooking.valeter_name ? (
                <View style={s.activeBookingProRow}>
                  {activeBooking.counterparty_photo_url ? (
                    <Image
                      source={{ uri: activeBooking.counterparty_photo_url }}
                      style={s.activeBookingProAvatar}
                    />
                  ) : (
                    <View style={[s.activeBookingProAvatarFallback, { backgroundColor: accent + '28' }]}>
                      <Ionicons name="person" size={11} color={accent} />
                    </View>
                  )}
                  <Text style={s.activeBookingValeter} numberOfLines={1}>
                    {proRole} · {formatDisplayName(activeBooking.valeter_name)}
                  </Text>
                </View>
              ) : (
                <Text style={s.activeBookingValeter} numberOfLines={1}>
                  {activeBooking.location_address || `Matching your ${CCP.singularShort.toLowerCase()}`}
                </Text>
              )}
            </View>
          </View>

          <View style={s.activeBookingProgressTrack}>
            <View style={[s.activeBookingProgressFill, { width: `${progress}%`, backgroundColor: accent }]} />
          </View>

          <View style={s.activeBookingBottomRow}>
            <View style={s.activeBookingPriceWrap}>
              <Text style={s.activeBookingPriceLabel}>Total</Text>
              <Text style={s.activeBookingPrice}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
            </View>
            <View style={s.activeBookingActions}>
              <TouchableOpacity
                onPress={(e) => {
                  e?.stopPropagation?.();
                  openChat();
                }}
                style={[s.activeBookingChatBtn, chatLocked && s.activeBookingChatBtnLocked]}
                hitSlop={8}
                accessibilityLabel={chatLocked ? 'Chat locked' : 'Open chat'}
              >
                <Ionicons
                  name={chatLocked ? 'lock-closed' : 'chatbubble-ellipses-outline'}
                  size={16}
                  color={chatLocked ? 'rgba(148,163,184,0.85)' : SKY}
                />
              </TouchableOpacity>
              <View style={[s.activeBookingCta, { borderColor: accent + '66', backgroundColor: accent + '22' }]}>
                <Text style={[s.activeBookingMetaCta, { color: accent }]}>{ctaLabel}</Text>
                <Ionicons name="arrow-forward" size={14} color={accent} />
              </View>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

function getValetersEmptyMessage(availabilityFilter: 'today' | 'tomorrow' | 'next_week'): string {
  if (availabilityFilter === 'today') return `No ${CCP.pluralShort} available today`;
  if (availabilityFilter === 'tomorrow') return `No ${CCP.pluralShort} scheduled for tomorrow`;
  return `No ${CCP.pluralShort} available next week`;
}

function getLocationsEmptyMessage(availabilityFilter: 'today' | 'tomorrow' | 'next_week'): string {
  if (availabilityFilter === 'today') return 'No wash locations in this list today';
  if (availabilityFilter === 'tomorrow') return 'No wash locations scheduled for tomorrow';
  return 'No wash locations in this list for next week';
}

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const ownerScrollPad = useOwnerScrollContentPadding(true);
  const adaptive = useAdaptiveLayout();
  const chrome = useMapChromeColors();
  const isTabletLayout = adaptive.isTablet;
  const horizontalInset = adaptive.horizontalPadding;
  const contentMaxWidth = adaptive.isTablet ? adaptive.contentMaxWidth : undefined;
  const sectionContainerStyle = isTabletLayout
    ? { width: '100%' as const, maxWidth: contentMaxWidth, alignSelf: 'center' as const }
    : undefined;
  const tabletSectionMarginReset = isTabletLayout ? { marginHorizontal: 0 } : undefined;

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]); // value reserved for future UI
  const [carWashCount, setCarWashCount] = useState(0); // value reserved for future UI
  const [detailingHubCount, setDetailingHubCount] = useState(0); // value reserved for future UI
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [headerProfilePicture, setHeaderProfilePicture] = useState<string | null>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);
  const [recentBookings, setRecentBookings] = useState<ActiveBooking[]>([]);
  const [recentBookingsLoading, setRecentBookingsLoading] = useState(false); // value reserved for future UI
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [eta, setEta] = useState<number | null>(null); // value reserved for future ETA display
  const valeterPresenceChannelRef = useRef<any>(null);

  const [topWashers, setTopWashers] = useState<TopWasher[]>([]);
  const [availabilityFilter, setAvailabilityFilter] = useState<'today' | 'tomorrow' | 'next_week'>('today');
  /** Split Car care pros vs fixed wash locations in the top-picks section. */
  const [washPicksSegment, setWashPicksSegment] = useState<'pros' | 'locations'>('pros');
  const [showAvailabilityPicker, setShowAvailabilityPicker] = useState(false);
  const [valeterProfileSheet, setValeterProfileSheet] = useState<ValeterProfileSheetSeed | null>(null);
  const [hubLocationSheet, setHubLocationSheet] = useState<HubLocationSheetSeed | null>(null);
  const [failedValeterImageIds, setFailedValeterImageIds] = useState<Set<string>>(new Set());
  const [dashboardRefreshing, setDashboardRefreshing] = useState(false);

  const quickScale0 = useRef(new Animated.Value(1)).current;
  const quickScale1 = useRef(new Animated.Value(1)).current;
  const quickScale2 = useRef(new Animated.Value(1)).current;
  const quickScale4 = useRef(new Animated.Value(1)).current;

  const [loyaltyData, setLoyaltyData] = useState<LoyaltyData | null>(null);
  const { refresh } = useLiveLocation();

  const loadLoyaltyData = useCallback(async () => {
    if (!user?.id) {
      setLoyaltyData(null);
      return;
    }
    try {
      const balance = await getLoyaltyBalance(user.id);
      const tierInfo = getTierProgress(balance.effectivePoints);
      const nextMilestone = getNextMilestone(balance.effectivePoints);
      setLoyaltyData({
        points: balance.effectivePoints,
        tier: tierInfo.tier,
        pointsToNextTier: tierInfo.pointsToNextTier || (nextMilestone ? nextMilestone.points - balance.effectivePoints : 0),
        nextReward: nextMilestone?.title ?? 'All rewards unlocked',
      });
    } catch {
      setLoyaltyData(null);
    }
  }, [user?.id]);

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_business_acceptance',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const filteredTopWashers = useMemo(() => {
    const byJobsAndRating = (a: TopWasher, b: TopWasher) =>
      b.jobsCompleted - a.jobsCompleted || b.rating - a.rating;
    const valeters = topWashers.filter((w): w is TopWasherValeter => w.kind === 'valeter');
    const hubs = MOBILE_SERVICE_ONLY_LAUNCH
      ? []
      : topWashers.filter((w): w is TopWasherHub => w.kind === 'hub');
    if (availabilityFilter === 'today') {
      const online = valeters.filter((v) => v.isOnline);
      const vList =
        online.length > 0
          ? online.sort(byJobsAndRating)
          : valeters.sort(
              (a, b) => Number(b.isOnline) - Number(a.isOnline) || byJobsAndRating(a, b)
            );
      return [...vList, ...hubs.sort(byJobsAndRating)].sort(byJobsAndRating);
    }
    if (availabilityFilter === 'tomorrow') {
      return [...valeters.sort((a, b) => Number(a.isOnline) - Number(b.isOnline) || byJobsAndRating(a, b)), ...hubs.sort(byJobsAndRating)].sort(
        byJobsAndRating
      );
    }
    return [...valeters.sort(byJobsAndRating), ...hubs.sort(byJobsAndRating)].sort(byJobsAndRating);
  }, [topWashers, availabilityFilter]);

  const topPicksValeters = useMemo(
    () => filteredTopWashers.filter((w): w is TopWasherValeter => w.kind === 'valeter'),
    [filteredTopWashers]
  );
  const topPicksHubs = useMemo(
    () => filteredTopWashers.filter((w): w is TopWasherHub => w.kind === 'hub'),
    [filteredTopWashers]
  );
  const displayedWashPicks = MOBILE_SERVICE_ONLY_LAUNCH || washPicksSegment === 'pros' ? topPicksValeters : topPicksHubs;

  /** Live online pros within radius of the customer — drives map markers + nearby count. */
  const exploreNearbyPros = useMemo(() => {
    const withCoords = nearbyValeters.filter(
      (v): v is NearbyValeter & { latitude: number; longitude: number } =>
        typeof v.latitude === 'number' &&
        typeof v.longitude === 'number' &&
        Number.isFinite(v.latitude) &&
        Number.isFinite(v.longitude)
    );

    if (!userLocation) {
      return withCoords.map((v) => ({ ...v, distance: v.distance }));
    }

    return withCoords
      .map((v) => ({
        ...v,
        distance: distanceKm(userLocation, { latitude: v.latitude, longitude: v.longitude }),
      }))
      .filter((v) => (v.distance ?? 999) <= DASHBOARD_NEARBY_RADIUS_KM)
      .sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0));
  }, [nearbyValeters, userLocation]);

  const exploreNearbyCount = exploreNearbyPros.length;
  const exploreMapMarkers = useMemo(() => exploreNearbyPros.slice(0, 12), [exploreNearbyPros]);

  const explorePreviewHubs = useMemo(() => {
    if (MOBILE_SERVICE_ONLY_LAUNCH) return [] as TopWasherHub[];
    return topPicksHubs
      .filter((h) => h.latitude != null && h.longitude != null)
      .slice(0, 4);
  }, [topPicksHubs]);

  const explorePreviewRegion: Region | null = useMemo(() => {
    const points: { latitude: number; longitude: number }[] = [
      ...(userLocation ? [userLocation] : []),
      ...exploreMapMarkers.map((p) => ({ latitude: p.latitude, longitude: p.longitude })),
      ...explorePreviewHubs
        .map((h) =>
          h.latitude != null && h.longitude != null
            ? { latitude: h.latitude, longitude: h.longitude }
            : null
        )
        .filter((p): p is { latitude: number; longitude: number } => p != null),
    ];
    if (points.length === 0) return null;
    return regionForCoordinates(points, points.length === 1 ? 0.4 : 0.55);
  }, [exploreMapMarkers, explorePreviewHubs, userLocation]);

  const exploreNearbyLabel = useMemo(() => {
    if (exploreNearbyCount <= 0) return `No ${ccpPluralLower()} nearby`;
    if (exploreNearbyCount === 1) return `1 ${ccpSingularLower()} nearby`;
    return `${exploreNearbyCount} ${ccpPluralLower()} nearby`;
  }, [exploreNearbyCount]);

  const showActiveJobInHub = activeBookingLoading || Boolean(activeBooking);
  const hubActiveBookingSectionStyle = { marginHorizontal: 0, marginTop: DASHBOARD_V_GAP, marginBottom: 0 };

  const topPickCardWidth = useMemo(() => {
    if (!isTabletLayout) return getTopCareProCardWidth(width);
    const inner = Math.min(adaptive.width, adaptive.contentMaxWidth) - horizontalInset * 2;
    return Math.min(dz(320), Math.max(dz(260), Math.floor(inner * 0.9)));
  }, [isTabletLayout, adaptive.width, adaptive.contentMaxWidth, horizontalInset, width]);

  /** Keep Top Care Pros visible; `false` would hide the section via `styles.hiddenSection`. */
  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHideProgress = useRef(new Animated.Value(0)).current;
  const lastScrollYRef = useRef(0);
  const headerScrollClearance = insets.top + DASHBOARD_SPLIT_HEADER_CONTENT_OFFSET + dz(2);

  const handleDashboardScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const currentY = Math.max(0, event.nativeEvent.contentOffset.y);
      const diff = currentY - lastScrollYRef.current;

      if (currentY <= 8) {
        Animated.timing(headerHideProgress, {
          toValue: 0,
          duration: 220,
          useNativeDriver: false,
        }).start();
      } else if (diff > 6) {
        Animated.timing(headerHideProgress, {
          toValue: 1,
          duration: 220,
          useNativeDriver: false,
        }).start();
      } else if (diff < -6) {
        Animated.timing(headerHideProgress, {
          toValue: 0,
          duration: 220,
          useNativeDriver: false,
        }).start();
      }

      lastScrollYRef.current = currentY;
    },
    [headerHideProgress]
  );

  const animatedScrollPaddingTop = headerHideProgress.interpolate({
    inputRange: [0, 1],
    outputRange: [headerScrollClearance, insets.top + dz(4)],
    extrapolate: 'clamp',
  });

  // Animated bubbles for header background
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + random * width * 0.3,
        delay: index * 800,
        duration: 12000 + random * 8000,
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      Animated.parallel([
        Animated.loop(
          Animated.sequence([
            Animated.delay(bubble.delay),
            Animated.timing(bubble.translateY, {
              toValue: bubble.endY,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: bubble.startY,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        ),
        Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.35,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.15,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: bubble.initialOpacity,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
    });
  }, [bubbleData]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      // Recalculate ETA if valeter location exists
      if (valeterLocation) {
        calculateETA(valeterLocation);
      }
      return coords;
    } catch (error) {
      console.warn('Error getting location:', error);
      return null;
    }
  };

  const loadValeterLocation = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) {
        console.warn('Error loading valeter location:', error);
        return;
      }

      if (data?.last_lat && data?.last_lng) {
        const valeterCoords = {
          latitude: Number(data.last_lat),
          longitude: Number(data.last_lng),
        };
        setValeterLocation(valeterCoords);
        calculateETA(valeterCoords);
      } else {
        setValeterLocation(null);
        setEta(null);
      }
    } catch (error) {
      console.warn('Error loading valeter location:', error);
    }
  };

  const calculateETA = (valeterCoords: { latitude: number; longitude: number }) => {
    if (!userLocation) return;

    const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
      const R = 3959; // Earth radius in miles
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLon = ((lon2 - lon1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    };

    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      valeterCoords.latitude,
      valeterCoords.longitude
    );

    // Average speed: 25 mph in city, estimate ETA in minutes
    const averageSpeed = 25; // mph
    const timeInHours = distance / averageSpeed;
    const timeInMinutes = Math.round(timeInHours * 60);
    
    setEta(timeInMinutes);
  };

  const subscribeToValeterPresence = (valeterId: string) => {
    // Remove existing subscription
    if (valeterPresenceChannelRef.current) {
      supabase.removeChannel(valeterPresenceChannelRef.current);
      valeterPresenceChannelRef.current = null;
    }

    const channel = supabase
      .channel(`valeter-presence-dashboard-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            const valeterCoords = {
              latitude: Number(updated.last_lat),
              longitude: Number(updated.last_lng),
            };
            setValeterLocation(valeterCoords);
            calculateETA(valeterCoords);
          }
        }
      )
      .subscribe();

    valeterPresenceChannelRef.current = channel;
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      let { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error?.code === '22P02') {
        const retry = await supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,location_lat,location_lng,scheduled_at,price,valeter_name,valeter_id')
          .eq('user_id', user.id)
          .in('status', ACTIVE_STATUSES_FALLBACK as any)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();
        data = retry.data;
        error = retry.error;
      }

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        setValeterLocation(null);
        setEta(null);
        return;
      }

      if (data.status === 'scheduled' || data.status === 'confirmed') {
        const startAt = data.scheduled_at ? new Date(data.scheduled_at).getTime() : NaN;
        const withinLeadWindow = Number.isFinite(startAt) && startAt - Date.now() <= 60 * 60 * 1000;
        const manuallyStarted = await isBookingManuallyStarted(data.id);
        if (!withinLeadWindow && !manuallyStarted) {
          setActiveBooking(null);
          setValeterLocation(null);
          setEta(null);
          return;
        }
      }

      const lat = data.location_lat == null ? null : Number(data.location_lat);
      const lng = data.location_lng == null ? null : Number(data.location_lng);

      let resolvedValeterName = data.valeter_name ?? null;
      if (data.valeter_id) {
        const identity = await fetchValeterIdentity(data.valeter_id);
        if (identity.name && identity.name !== ccpFallbackName()) {
          resolvedValeterName = identity.name;
        } else {
          resolvedValeterName = resolveValeterDisplayName(null, null, data.valeter_name);
        }
      }

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        location_id: null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: resolvedValeterName,
        valeter_id: data.valeter_id ?? null,
        counterparty_photo_url: null,
        latitude: lat,
        longitude: lng,
      });

      if (data.valeter_id) {
        loadValeterLocation(data.valeter_id);
        subscribeToValeterPresence(data.valeter_id);
      } else {
        setValeterLocation(null);
        setEta(null);
      }
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  const loadRecentBookings = async () => {
    if (!user?.id) return;

    try {
      setRecentBookingsLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id,status,service_type,service_name,location_address,location_id,scheduled_at,price,valeter_name,valeter_id,vehicle_id,wash_type'
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .eq('status', 'completed')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) {
        console.warn('[CustomerDashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }

      if (!data || data.length === 0) {
        setRecentBookings([]);
        return;
      }

      const valeterIds = [...new Set(data.map((b) => b.valeter_id).filter(Boolean))] as string[];
      const identityMap = await fetchValeterIdentitiesByIds(valeterIds);

      setRecentBookings(
        data.map((booking) => {
          const identity = booking.valeter_id ? identityMap.get(booking.valeter_id) : undefined;
          const resolvedName =
            identity?.name && identity.name !== ccpFallbackName()
              ? identity.name
              : resolveValeterDisplayName(null, null, booking.valeter_name);
          return {
            id: booking.id,
            status: booking.status as DbBookingStatus,
            service_type: booking.service_type,
            service_name: booking.service_name ?? null,
            location_address: booking.location_address ?? null,
            location_id: (booking as any).location_id ?? null,
            scheduled_at: booking.scheduled_at,
            price: Number(booking.price ?? 0),
            valeter_name: resolvedName || booking.valeter_name || null,
            valeter_id: booking.valeter_id ?? null,
            counterparty_photo_url: identity?.photoUrl ?? null,
            latitude: null,
            longitude: null,
            vehicle_id: (booking as any).vehicle_id ?? null,
            wash_type: (booking as any).wash_type ?? null,
          };
        })
      );
    } catch (e) {
      console.warn('[CustomerDashboard] loadRecentBookings exception:', e);
      setRecentBookings([]);
    } finally {
      setRecentBookingsLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    getCurrentLocation();
    loadActiveBooking();
    loadRecentBookings();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => {
          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;
            const terminalStatuses = ['completed', 'cancelled', 'valeter_declined', 'valeter_timeout'];

            if (terminalStatuses.includes(newStatus)) {
              setActiveBooking(null);
              loadRecentBookings();
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      if (valeterPresenceChannelRef.current) {
        supabase.removeChannel(valeterPresenceChannelRef.current);
        valeterPresenceChannelRef.current = null;
      }
    };
  }, [user?.id, activeBooking?.id]);

  // Notifications count (unchanged)
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, chatThreads, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchUnreadBookingChatThreads(user.id),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const chatNotifications = chatThreads.map((thread) => ({
          id: `chat-${thread.bookingId}`,
          type: 'chat' as const,
        }));
        const allNotifications = [...bookingNotifications, ...chatNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    const channel = supabase
      .channel(`customer-notification-count-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'customer_vehicles',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'booking_messages',
        },
        () => {
          fetchNotificationCount();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        () => {
          fetchNotificationCount();
        }
      )
      .subscribe();
    return () => {
      isMounted = false;
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfile = async () => {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', user.id)
        .maybeSingle();

      if (profileData) {
        setProfileName(profileData.full_name || user.name || 'Customer');
        const pic = (profileData as { profile_picture?: string | null }).profile_picture;
        setHeaderProfilePicture(pic && typeof pic === 'string' ? pic : null);
      } else {
        setProfileName(user.name || 'Customer');
        setHeaderProfilePicture(null);
      }
    };
    loadProfile();
  }, [user?.id]);

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const [identityMap, vpOrgRes] = await Promise.all([
        fetchValeterIdentitiesByIds(ids),
        supabase.from('valeter_profiles').select('user_id, company_name').in('user_id', ids),
      ]);
      const orgById = new Map<string, string>();
      for (const row of vpOrgRes.data || []) {
        const r = row as { user_id: string; company_name?: string | null };
        if (r.company_name) orgById.set(r.user_id, r.company_name);
      }

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const identity = identityMap.get(p.user_id);
        return {
          id: p.user_id,
          name: identity?.name || ccpFallbackName(),
          organization: orgById.get(p.user_id) || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
          latitude: p.last_lat == null ? null : Number(p.last_lat),
          longitude: p.last_lng == null ? null : Number(p.last_lng),
        };
      });

      setNearbyValeters(list);
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  const loadCarWashCount = async () => {
    try {
      const { count, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.warn('[CarWashCount] error:', error);
        return;
      }

      setCarWashCount(count || 0);
    } catch (e) {
      console.error('[CarWashCount] load error:', e);
    }
  };

  const loadDetailingHubCount = async () => {
    try {
      // Schema-safe fallback: estimate detailing studios from active location count.
      const { count: allCount, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.warn('[DetailingHubCount] error:', error);
        return;
      }

      setDetailingHubCount(Math.floor((allCount || 0) * 0.3));
    } catch (e) {
      console.error('[DetailingHubCount] load error:', e);
    }
  };

  const loadTopWashers = async () => {
    try {
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select('valeter_id, location_id, rating')
        .eq('status', 'completed');
      if (completedError) throw completedError;

      type ValeterAgg = { jobs: number; ratingSum: number; ratingCount: number };
      const valeterAgg = new Map<string, ValeterAgg>();
      const hubJobCounts = new Map<string, number>();
      const hubRatingCounts = new Map<string, number>();
      for (const row of completedRows || []) {
        const vid = (row as { valeter_id?: string | null }).valeter_id;
        const lid = (row as { location_id?: string | null }).location_id;
        const ratingRaw = (row as { rating?: number | null }).rating;
        const rv = ratingRaw != null && Number.isFinite(Number(ratingRaw)) ? Number(ratingRaw) : null;
        if (vid) {
          const cur = valeterAgg.get(vid) ?? { jobs: 0, ratingSum: 0, ratingCount: 0 };
          cur.jobs += 1;
          if (rv != null) {
            cur.ratingSum += rv;
            cur.ratingCount += 1;
          }
          valeterAgg.set(vid, cur);
        }
        if (lid) {
          hubJobCounts.set(lid, (hubJobCounts.get(lid) || 0) + 1);
          if (rv != null) {
            hubRatingCounts.set(lid, (hubRatingCounts.get(lid) || 0) + 1);
          }
        }
      }

      const valeterAvgFromAgg = (a: ValeterAgg) => (a.ratingCount > 0 ? a.ratingSum / a.ratingCount : 0);

      type Cand =
        | { kind: 'valeter'; id: string; jobs: number; completionAvgRating: number; reviewCount: number }
        | { kind: 'hub'; id: string; jobs: number; reviewCount: number };
      let cands: Cand[] = [
        ...Array.from(valeterAgg.entries()).map(([id, agg]) => ({
          kind: 'valeter' as const,
          id,
          jobs: agg.jobs,
          completionAvgRating: valeterAvgFromAgg(agg),
          reviewCount: agg.ratingCount,
        })),
        ...Array.from(hubJobCounts.entries()).map(([id, jobs]) => ({
          kind: 'hub' as const,
          id,
          jobs,
          reviewCount: hubRatingCounts.get(id) || 0,
        })),
      ]
        .filter((c) => c.jobs > 0)
        .sort((a, b) => {
          if (b.jobs !== a.jobs) return b.jobs - a.jobs;
          const ar = a.kind === 'valeter' ? a.completionAvgRating : 0;
          const br = b.kind === 'valeter' ? b.completionAvgRating : 0;
          return br - ar;
        })
        .slice(0, 10);

      if (cands.length === 0) {
        const [{ data: vp }, { data: hubRows }] = await Promise.all([
          supabase.from('valeter_profiles').select('user_id').limit(5),
          supabase.from('car_wash_locations').select('id').limit(5),
        ]);
        const vFallback = ((vp || []) as { user_id: string }[]).map((p) => ({
          kind: 'valeter' as const,
          id: p.user_id,
          jobs: 0,
          completionAvgRating: 0,
          reviewCount: 0,
        }));
        const hFallback = ((hubRows || []) as { id: string }[]).map((h) => ({
          kind: 'hub' as const,
          id: h.id,
          jobs: 0,
          reviewCount: 0,
        }));
        cands = [...vFallback, ...hFallback].slice(0, 8);
      }

      if (cands.length === 0) {
        setTopWashers([]);
        return;
      }

      const valeterIds = cands.filter((c): c is Extract<Cand, { kind: 'valeter' }> => c.kind === 'valeter').map((c) => c.id);
      const hubIds = cands.filter((c): c is Extract<Cand, { kind: 'hub' }> => c.kind === 'hub').map((c) => c.id);

      const [presenceRes, profilesRes, fallbackProfilesRes, statsBatch, hubLocRes] = await Promise.all([
        valeterIds.length
          ? supabase.from('valeter_presence').select('user_id, is_online, last_lat, last_lng').in('user_id', valeterIds)
          : Promise.resolve({ data: [] as { user_id: string; is_online: boolean; last_lat?: number | null; last_lng?: number | null }[] }),
        valeterIds.length
          ? supabase
              .from('valeter_profiles')
              .select('user_id, full_name, company_name, profile_photo_url, created_at')
              .in('user_id', valeterIds)
          : Promise.resolve({ data: [] as Record<string, unknown>[] }),
        valeterIds.length
          ? supabase
              .from('profiles')
              .select('id, full_name, profile_picture, created_at')
              .in('id', valeterIds)
          : Promise.resolve({
              data: [] as {
                id: string;
                full_name?: string | null;
                profile_picture?: string | null;
                created_at?: string | null;
              }[],
            }),
        valeterIds.length ? ValeterStatsService.getValeterStatsBatch(valeterIds) : Promise.resolve(new Map()),
        hubIds.length
          ? supabase.from('car_wash_locations').select('id,name,rating,total_reviews,latitude,longitude').in('id', hubIds)
          : Promise.resolve({ data: [] as { id: string; name?: string; rating?: number; total_reviews?: number | null; latitude?: number | null; longitude?: number | null }[] }),
      ]);

      const presence = presenceRes.data;
      const profiles = profilesRes.data;
      const fallbackProfiles = fallbackProfilesRes.data || [];
      const hubLocations = hubLocRes.data || [];

      const list = await Promise.all(
        cands.map(async (cand): Promise<TopWasher> => {
          if (cand.kind === 'hub') {
            const loc = hubLocations.find((h) => h.id === cand.id);
            const name = String(loc?.name || 'Car wash');
            const rating = Number(loc?.rating) || 0;
            const reviewCount =
              loc?.total_reviews != null && Number(loc.total_reviews) > 0
                ? Number(loc.total_reviews)
                : cand.reviewCount;
            const base: TopWasherHub = {
              kind: 'hub',
              id: cand.id,
              name,
              organization: 'Car wash venue',
              rating,
              jobsCompleted: cand.jobs,
              reviewCount,
              isOnline: false,
              latitude: loc?.latitude == null ? null : Number(loc.latitude),
              longitude: loc?.longitude == null ? null : Number(loc.longitude),
            };
            return base;
          }

          const r = cand;
          const p = presence?.find((x) => x.user_id === r.id);
          const pr = profiles?.find((x) => (x as { user_id: string }).user_id === r.id) as
            | {
                user_id: string;
                full_name?: string | null;
                company_name?: string | null;
                profile_photo_url?: string | null;
                created_at?: string | null;
              }
            | undefined;
          const stats = statsBatch.get(r.id);
          const fallbackProfile = fallbackProfiles.find((fp) => fp.id === r.id);
          const name: string = String(pr?.full_name || fallbackProfile?.full_name || ccpFallbackName());
          let profilePicture: string | null = pr?.profile_photo_url ?? null;
          let joinedAt: string | null = pr?.created_at ?? null;
          if (!profilePicture && fallbackProfile?.profile_picture) {
            profilePicture = fallbackProfile.profile_picture;
          }
          if (!joinedAt && fallbackProfile?.created_at) {
            joinedAt = fallbackProfile.created_at;
          }
          const { data: reviewRows } = await supabase
            .from('bookings')
            .select('rating, review')
            .eq('valeter_id', r.id)
            .eq('status', 'completed')
            .not('rating', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(5);
          const reviews: ValeterReview[] = (reviewRows || []).map((row: any) => ({
            rating: Number(row.rating) || 0,
            review: row.review ?? null,
          }));
          let displayRating = 0;
          if (reviews.length > 0) {
            displayRating = reviews.reduce((s, x) => s + x.rating, 0) / reviews.length;
          } else if (stats != null && stats.averageRating > 0) {
            displayRating = stats.averageRating;
          }
          const base: TopWasherValeter = {
            kind: 'valeter',
            id: r.id,
            name,
            organization: String(pr?.company_name || 'Independent'),
            rating: displayRating,
            jobsCompleted: r.jobs,
            reviewCount: stats?.customerReviews ?? r.reviewCount ?? reviews.length,
            isOnline: !!p?.is_online,
            latitude: p?.last_lat == null ? null : Number(p.last_lat),
            longitude: p?.last_lng == null ? null : Number(p.last_lng),
          };
          if (profilePicture) base.profilePicture = profilePicture;
          if (joinedAt) base.joinedAt = joinedAt;
          if (reviews.length > 0) base.reviews = reviews;
          return base;
        })
      );

      setTopWashers(list);
    } catch (e) {
      console.error('[TopWashers] load error:', e);
      setTopWashers([]);
    }
  };

  useEffect(() => {
    loadNearbyValeters();
    loadCarWashCount();
    loadDetailingHubCount();
    loadTopWashers();
    const interval = setInterval(() => {
      loadNearbyValeters();
      loadCarWashCount();
      loadDetailingHubCount();
      loadTopWashers();
    }, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  useFocusEffect(
    useCallback(() => {
      if (user?.id) {
        loadRecentBookings();
        void loadLoyaltyData();
      }
    }, [user?.id, loadLoyaltyData])
  );

  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      void (async () => {
        if (!user?.id) return;
        const pendingId = await getPendingRatingBookingId();
        if (!pendingId || cancelled) return;
        const { data, error } = await supabase
          .from('bookings')
          .select('id,status,rating,user_id')
          .eq('id', pendingId)
          .maybeSingle();
        if (cancelled || error || !data) return;
        if (data.user_id !== user.id) {
          await clearPendingRatingBookingId();
          return;
        }
        if (data.status !== 'completed') {
          await clearPendingRatingBookingId();
          return;
        }
        const r = data.rating;
        if (r != null && Number(r) >= 1 && Number(r) <= 5) {
          await clearPendingRatingBookingId();
          return;
        }
        await clearPendingRatingBookingId();
        router.replace({
          pathname: '/owner/booking/completion',
          params: { bookingId: pendingId, celebrated: '1' },
        } as any);
      })();
      return () => {
        cancelled = true;
      };
    }, [user?.id])
  );

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/track',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string, params?: Record<string, string>) => {
    if (!activeBooking?.id) {
      if (params != null && Object.keys(params).length > 0) {
        router.push({ pathname: route, params } as any);
      } else {
        router.push(route as any);
      }
      return;
    }

    Alert.alert(
      'Active booking in progress',
      'You already have an active booking. You can resume tracking it now.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'View booking',
          onPress: handleResumeTracking,
        },
      ]
    );
  };

  const onDashboardRefresh = async () => {
    if (!user?.id) return;
    setDashboardRefreshing(true);
    try {
      await getCurrentLocation();
      await Promise.all([
        loadActiveBooking(),
        loadRecentBookings(),
        loadTopWashers(),
        loadNearbyValeters(),
        loadCarWashCount(),
        loadDetailingHubCount(),
        loadLoyaltyData(),
      ]);
    } finally {
      setDashboardRefreshing(false);
    }
  };

  const activeBookingMapRegion: Region | null = useMemo(() => {
    if (!userLocation) return null;
    const points: { latitude: number; longitude: number }[] = [userLocation];
    if (valeterLocation) points.push(valeterLocation);
    if (activeBooking?.latitude != null && activeBooking?.longitude != null) {
      points.push({ latitude: activeBooking.latitude, longitude: activeBooking.longitude });
    }
    const lats = points.map((p) => p.latitude);
    const lngs = points.map((p) => p.longitude);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    const pad = 0.006;
    return {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max(0.012, (maxLat - minLat) * 1.6 + pad * 2),
      longitudeDelta: Math.max(0.012, (maxLng - minLng) * 1.6 + pad * 2),
    };
  }, [userLocation, valeterLocation, activeBooking?.latitude, activeBooking?.longitude]);

  const themeOptional = useThemeOptional();
  const colorScheme = themeOptional?.colorScheme ?? 'light';
  const showSubtleWaveTint =
    SUBTLE_WAVE_DASHBOARD_TINT_ENABLED && colorScheme === 'light';

  return (
    <SafeAreaView style={styles.container}>
      {showSubtleWaveTint ? (
        <LinearGradient
          colors={[...subtleWaveDashboardTint.colors]}
          locations={[...subtleWaveDashboardTint.locations]}
          start={subtleWaveDashboardTint.start}
          end={subtleWaveDashboardTint.end}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
      ) : null}
      <StatusBar barStyle="light-content" backgroundColor="transparent" />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={formatDisplayName(profileName || user?.name || 'Customer')}
        subtitle={(() => {
          const h = new Date().getHours();
          if (h < 12) return 'Good morning!';
          if (h < 17) return 'Good afternoon!';
          return 'Good evening!';
        })()}
        variant="dashboard"
        dashboardSplitChrome
        fullWidth
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        hideOnScroll
        headerHideProgress={headerHideProgress}
        leftAction={
          <TouchableOpacity
            onPress={() => { hapticFeedback('light'); router.push('/owner/owner-profile' as any); }}
            style={styles.headerProfilePicWrap}
            activeOpacity={0.8}
            accessibilityLabel="Profile"
            accessibilityRole="button"
          >
            {headerProfilePicture ? (
              <Image source={{ uri: headerProfilePicture }} style={styles.headerProfilePic} resizeMode="cover" />
            ) : (
              <GradientIconBox icon="person" preset="sky" boxSize={dz(36)} size={dz(18)} borderRadius={dz(18)} />
            )}
          </TouchableOpacity>
        }
        rightAction={
          <GradientNotificationBell count={notificationCount} onPress={handleNotificationPress} />
        }
        {...(loyaltyData?.points !== undefined ? { points: loyaltyData.points } : {})}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
          listener: handleDashboardScroll,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: animatedScrollPaddingTop,
          paddingBottom: ownerScrollPad.paddingBottom + dz(4),
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={dashboardRefreshing} onRefresh={onDashboardRefresh} tintColor={SKY} colors={[SKY]} />
        }
      >
        {loading ? (
          <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
            <View style={styles.bookWishCard}>
              {renderBookWishGlassFill()}
              <View style={[styles.bookWishContent, styles.bookWishContentLoading]}>
                <ActivityIndicator size="small" color="#F8FAFC" />
                <Text style={styles.bookWishLoadingText}>Loading…</Text>
              </View>
            </View>
            <View style={{ marginHorizontal: horizontalInset, marginTop: 16 }}>
              <SkeletonList count={4} />
            </View>
          </View>
        ) : (
          <View style={{ flex: 1 }}>
            <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
              <TouchableOpacity
                style={styles.bookWishCard}
                onPress={() => handleAttemptNewBooking('/owner/booking/create')}
                activeOpacity={0.88}
              >
                {renderBookWishGlassFill()}
                <View style={styles.bookWishContent}>
                  <GradientIconBox
                    icon="car-sport"
                    preset="sky"
                    boxSize={dzHero(44)}
                    size={dzHero(24)}
                    elevated
                  />
                  <View style={styles.bookWishTextWrap}>
                    <Text style={styles.bookWishTitle}>Book A Wish</Text>
                    <Text style={styles.bookWishSubtitle} numberOfLines={1}>
                      {activeBooking ? 'Finish your active booking first' : 'Wash Detail and Repair'}
                    </Text>
                  </View>
                  <View style={styles.bookWishChevron}>
                    <GradientIconBox
                      icon="arrow-forward-circle"
                      preset="sky"
                      boxSize={dzHero(40)}
                      borderRadius={dzHero(13)}
                      elevated
                      size={dzHero(28)}
                    />
                  </View>
                </View>
              </TouchableOpacity>

              <View style={styles.yourHubSection}>
                <View style={styles.yourHubHeader}>
                  <View style={styles.topWashersHeaderMain}>
                    <Text style={styles.topPickTrackKicker}>YOUR HUB</Text>
                    <Text style={styles.topPickTrackSubtitle} numberOfLines={2}>
                      Manage the parts you use most
                    </Text>
                  </View>
                </View>
                <View style={styles.quickActionsRow}>
                    <Pressable
                      onPressIn={() => Animated.spring(quickScale0, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
                      onPressOut={() => Animated.spring(quickScale0, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
                      onPress={() => {
                        hapticFeedback('light');
                        router.push('/owner/settings/vehicle-management');
                      }}
                      style={styles.quickActionPressable}
                    >
                      <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale0 }] }]}>
                        <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet]}>
                          <GradientIconBox
                            icon="car-sport"
                            preset="blue"
                            boxSize={isTabletLayout ? dzHero(56) : dzHero(48)}
                            borderRadius={isTabletLayout ? dzHero(16) : dzHero(14)}
                            elevated
                          />
                        </View>
                        <Text style={styles.quickActionItemLabel}>Vehicles</Text>
                      </Animated.View>
                    </Pressable>

                    <Pressable
                      onPressIn={() => Animated.spring(quickScale1, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
                      onPressOut={() => Animated.spring(quickScale1, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
                      onPress={() => {
                        hapticFeedback('light');
                        router.push('/owner/features/rewards');
                      }}
                      style={styles.quickActionPressable}
                    >
                      <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale1 }] }]}>
                        <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet]}>
                          <GradientIconBox
                            icon="trophy"
                            preset="amber"
                            boxSize={isTabletLayout ? dzHero(56) : dzHero(48)}
                            borderRadius={isTabletLayout ? dzHero(16) : dzHero(14)}
                            elevated
                          />
                        </View>
                        <Text style={styles.quickActionItemLabel}>Rewards</Text>
                      </Animated.View>
                    </Pressable>

                    <Pressable
                      onPressIn={() => Animated.spring(quickScale2, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
                      onPressOut={() => Animated.spring(quickScale2, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
                      onPress={() => {
                        hapticFeedback('light');
                        router.push('/owner/features/referral-system');
                      }}
                      style={styles.quickActionPressable}
                    >
                      <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale2 }] }]}>
                        <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet]}>
                          <GradientIconBox
                            icon="people-circle"
                            preset="amber"
                            boxSize={isTabletLayout ? dzHero(56) : dzHero(48)}
                            borderRadius={isTabletLayout ? dzHero(16) : dzHero(14)}
                            elevated
                          />
                        </View>
                        <Text style={styles.quickActionItemLabel}>Referrals</Text>
                      </Animated.View>
                    </Pressable>
                </View>
              </View>

              {showActiveJobInHub ? (
                <ActiveBookingSection
                  activeBookingLoading={activeBookingLoading}
                  activeBooking={activeBooking}
                  activeBookingMapRegion={activeBookingMapRegion}
                  userLocation={userLocation}
                  valeterLocation={valeterLocation}
                  onResumeTracking={handleResumeTracking}
                  styles={styles}
                  eta={eta}
                  loyaltyData={loyaltyData}
                  reservedCounts={{ nearbyValeters: exploreNearbyCount, carWashCount, detailingHubCount, recentBookingsLoading }}
                  sectionStyle={hubActiveBookingSectionStyle}
                />
              ) : (
              <Pressable
                onPressIn={() => Animated.spring(quickScale4, { toValue: 0.97, useNativeDriver: true, speed: 120 }).start()}
                onPressOut={() => Animated.spring(quickScale4, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
                onPress={() => {
                  hapticFeedback('light');
                  router.push('/owner/explore');
                }}
                style={styles.explorePreviewPressable}
              >
                <Animated.View
                  style={[
                    styles.explorePreviewInline,
                    isTabletLayout && styles.explorePreviewInlineTablet,
                    { transform: [{ scale: quickScale4 }] },
                  ]}
                >
                  <View style={styles.explorePreviewInlineHeader}>
                    <View style={styles.topWashersHeaderMain}>
                      <Text style={styles.topPickTrackKicker}>EXPLORE</Text>
                      <Text style={styles.topPickTrackSubtitle} numberOfLines={2}>
                        {exploreNearbyLabel}
                      </Text>
                    </View>
                    {exploreNearbyCount > 0 ? (
                      <View style={styles.explorePreviewLiveDotWrap}>
                        <View style={styles.explorePreviewLiveDot} />
                        <Text style={styles.explorePreviewLiveText}>Live</Text>
                      </View>
                    ) : null}
                  </View>

                  <View style={styles.explorePreviewMapShell}>
                    <View style={styles.explorePreviewMapInner}>
                      {explorePreviewRegion ? (
                        <MapView
                          style={StyleSheet.absoluteFill}
                          region={explorePreviewRegion}
                          scrollEnabled={false}
                          zoomEnabled={false}
                          pitchEnabled={false}
                          rotateEnabled={false}
                          customMapStyle={NAVIGATION_MAP_STYLE}
                          userInterfaceStyle={MAP_LOCKED_DARK}
                          pointerEvents="none"
                        >
                          {userLocation ? (
                            <Marker coordinate={userLocation} anchor={{ x: 0.5, y: 0.5 }}>
                              <MapMarkerCustomerVehicle size={dz(42)} />
                            </Marker>
                          ) : null}
                          {exploreMapMarkers.map((pro) => (
                            <Marker
                              key={`explore-preview-pro-${pro.id}`}
                              coordinate={{ latitude: pro.latitude, longitude: pro.longitude }}
                              anchor={{ x: 0.5, y: 0.5 }}
                            >
                              <MapMarkerValeterLive size={dz(40)} />
                            </Marker>
                          ))}
                          {explorePreviewHubs.map((hub) =>
                            hub.latitude != null && hub.longitude != null ? (
                              <Marker
                                key={`explore-preview-hub-${hub.id}`}
                                coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
                              >
                                <MapMarkerServiceSpot size={dz(36)} />
                              </Marker>
                            ) : null
                          )}
                        </MapView>
                      ) : (
                        <View style={styles.explorePreviewEmptyMap}>
                          <GradientIconBox icon="navigate" preset="sky" boxSize={dz(48)} borderRadius={dz(16)} elevated />
                          <Text style={styles.explorePreviewEmptyText}>Finding Pros near you…</Text>
                        </View>
                      )}

                      <LinearGradient
                        colors={['rgba(2,10,24,0.55)', 'transparent', 'transparent', 'rgba(2,10,24,0.88)']}
                        locations={[0, 0.22, 0.55, 1]}
                        start={{ x: 0.5, y: 0 }}
                        end={{ x: 0.5, y: 1 }}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                      <LinearGradient
                        colors={['rgba(56,189,248,0.18)', 'transparent', 'rgba(248,215,12,0.08)']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                      <View style={styles.explorePreviewMapSheen} pointerEvents="none" />
                      <View style={styles.explorePreviewMapRim} pointerEvents="none" />

                      <View style={styles.explorePreviewMapBadgeRow} pointerEvents="none">
                        <View style={styles.explorePreviewMapBadge}>
                          <Text style={styles.explorePreviewMapBadgeText}>{exploreNearbyLabel}</Text>
                        </View>
                      </View>

                      <View style={styles.explorePreviewMapCta} pointerEvents="none">
                        <View style={styles.explorePreviewMapCtaPill}>
                          <Text style={styles.explorePreviewMapCtaText}>Explore</Text>
                          <Ionicons name="chevron-forward" size={12} color="rgba(248,250,252,0.75)" />
                        </View>
                      </View>
                    </View>
                  </View>
                </Animated.View>
              </Pressable>
              )}
            </View>

        {/* Top picks — mobile pros (and locations when hub booking is enabled) */}
            <View
              style={[
                styles.availabilitySectionBottom,
                sectionContainerStyle,
                tabletSectionMarginReset,
              ]}
            >
              <View style={styles.topWashersHeader}>
                <View style={styles.topWashersHeaderTopRow}>
                  <View style={styles.topWashersHeaderMain}>
                    <View style={styles.topWashersTitleRow}>
                      <Text style={[styles.topPickTrackKicker, styles.topWashersKickerInline]}>
                        {MOBILE_SERVICE_ONLY_LAUNCH ? 'TOP CARE PROS' : 'TOP WASH PICKS'}
                      </Text>
                      <Text style={styles.topWashersCountText}>{displayedWashPicks.length}</Text>
                    </View>
                    <Text style={styles.topPickTrackSubtitle} numberOfLines={2}>
                      {MOBILE_SERVICE_ONLY_LAUNCH || washPicksSegment === 'pros'
                        ? `${CCP.pluralShort} — most washes & highest rated`
                        : 'Fixed wash spots — venues & hubs'}
                    </Text>
                  </View>
                  <TouchableOpacity
                    style={styles.topWashersFilterBtn}
                    onPress={() => {
                      hapticFeedback('light');
                      setShowAvailabilityPicker(true);
                    }}
                    activeOpacity={0.8}
                  >
                    <Text style={[styles.topWashersFilterBtnText, { color: chrome.icon }]}>
                      {availabilityFilter === 'today'
                        ? 'Today'
                        : availabilityFilter === 'tomorrow'
                          ? 'Tomorrow'
                          : 'Next week'}
                    </Text>
                    <Ionicons name="chevron-down" size={14} color={chrome.icon} />
                  </TouchableOpacity>
                </View>

                {!MOBILE_SERVICE_ONLY_LAUNCH ? (
                  <View style={styles.topWashersSegmentRow}>
                      <Pressable
                        style={[
                          styles.topWashersSegmentTab,
                          washPicksSegment === 'pros'
                            ? {
                                borderColor: chrome.border,
                                backgroundColor: `${chrome.accent}1A`,
                              }
                            : styles.topWashersSegmentTabIdle,
                        ]}
                        onPress={() => {
                          hapticFeedback('light');
                          setWashPicksSegment('pros');
                        }}
                      >
                        <Ionicons
                          name={washPicksSegment === 'pros' ? 'person' : 'person-outline'}
                          size={13}
                          color={washPicksSegment === 'pros' ? chrome.icon : 'rgba(148,163,184,0.55)'}
                        />
                        <Text
                          style={[
                            styles.topWashersSegmentLabel,
                            washPicksSegment === 'pros' && { color: chrome.icon },
                          ]}
                          numberOfLines={1}
                        >
                          {CCP.pluralShort}
                        </Text>
                        {topPicksValeters.length > 0 ? (
                          <View style={styles.topWashersSegmentCount}>
                            <Text
                              style={[
                                styles.topWashersSegmentCountText,
                                washPicksSegment === 'pros' && { color: chrome.icon },
                              ]}
                            >
                              {topPicksValeters.length}
                            </Text>
                          </View>
                        ) : null}
                      </Pressable>
                      <Pressable
                        style={[
                          styles.topWashersSegmentTab,
                          washPicksSegment === 'locations'
                            ? {
                                borderColor: 'rgba(125,211,252,0.45)',
                                backgroundColor: `${SKY}1A`,
                              }
                            : styles.topWashersSegmentTabIdle,
                        ]}
                        onPress={() => {
                          hapticFeedback('light');
                          setWashPicksSegment('locations');
                        }}
                      >
                        <Ionicons
                          name={washPicksSegment === 'locations' ? 'business' : 'business-outline'}
                          size={13}
                          color={washPicksSegment === 'locations' ? '#E0F2FE' : 'rgba(148,163,184,0.55)'}
                        />
                        <Text
                          style={[
                            styles.topWashersSegmentLabel,
                            washPicksSegment === 'locations' && { color: '#E0F2FE' },
                          ]}
                          numberOfLines={1}
                        >
                          Locations
                        </Text>
                        {topPicksHubs.length > 0 ? (
                          <View style={styles.topWashersSegmentCount}>
                            <Text
                              style={[
                                styles.topWashersSegmentCountText,
                                washPicksSegment === 'locations' && { color: '#E0F2FE' },
                              ]}
                            >
                              {topPicksHubs.length}
                            </Text>
                          </View>
                        ) : null}
                      </Pressable>
                    </View>
                  ) : null}
              </View>

                <View style={styles.prosNearbyContainer}>
                  {filteredTopWashers.length > 0 ? (
                    displayedWashPicks.length > 0 ? (
                      (() => {
                        const imageFailKey = (w: TopWasher) => `${w.kind}:${w.id}`;
                        const openHubSheet = (w: TopWasherHub) => {
                          setHubLocationSheet({
                            id: w.id,
                            name: w.name,
                            rating: w.rating,
                            jobsCompleted: w.jobsCompleted,
                          });
                        };
                        const cards = displayedWashPicks.map((w, pickIndex) => {
                          const accent = w.kind === 'hub' ? SKY : chrome.accent;
                          const cardBorder = w.kind === 'hub' ? 'rgba(148,196,220,0.4)' : chrome.border;
                          const displayName =
                            w.kind === 'hub'
                              ? w.name || 'Car wash'
                              : formatDisplayName(w.name) || w.name || ccpFallbackName();

                          if (w.kind === 'valeter') {
                            return (
                              <TopCareProCard
                                key={`valeter-${w.id}`}
                                width={topPickCardWidth}
                                zoom={TOP_CARE_PRO_CARD_ZOOM}
                                pro={{
                                  id: w.id,
                                  name: w.name,
                                  rating: w.rating,
                                  totalJobs: w.jobsCompleted,
                                  reviewCount: w.reviewCount,
                                  isOnline: w.isOnline,
                                  profilePicture: w.profilePicture ?? null,
                                }}
                                rank={pickIndex + 1}
                                accent={accent}
                                borderColor={cardBorder}
                                onPress={() => {
                                  hapticFeedback('light');
                                  setValeterProfileSheet({
                                    id: w.id,
                                    name: w.name,
                                    rating: w.rating,
                                    totalJobs: w.jobsCompleted,
                                    reviewCount: w.reviewCount,
                                    profilePicture: w.profilePicture ?? null,
                                    isOnline: w.isOnline,
                                    rank: pickIndex + 1,
                                  });
                                }}
                              />
                            );
                          }

                          const hub = w;
                          return (
                            <View
                              key={`hub-${hub.id}`}
                              style={[styles.topPickTrackCard, { width: topPickCardWidth, borderColor: cardBorder }]}
                            >
                              <View
                                style={[styles.topPickTrackAccentRail, { backgroundColor: accent }]}
                                pointerEvents="none"
                              />
                              <Pressable
                                style={({ pressed }) => [pressed && { opacity: 0.92 }]}
                                onPress={() => {
                                  hapticFeedback('light');
                                  openHubSheet(hub);
                                }}
                              >
                                <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                                <LinearGradient
                                  colors={[accent + '18', 'transparent']}
                                  start={{ x: 0, y: 0 }}
                                  end={{ x: 1, y: 1 }}
                                  style={StyleSheet.absoluteFill}
                                  pointerEvents="none"
                                />
                                {renderTopPickGlossSheen()}
                                <View style={styles.topPickTrackCardPad}>
                                  <View style={styles.topPickTrackCardTop}>
                                    <View style={[styles.topPickTrackIconWrap, { backgroundColor: accent + '25' }]}>
                                      {hub.profilePicture && !failedValeterImageIds.has(imageFailKey(hub)) ? (
                                        <Image
                                          source={{ uri: hub.profilePicture }}
                                          style={styles.topPickTrackAvatarImg}
                                          resizeMode="cover"
                                          onError={() =>
                                            setFailedValeterImageIds((prev) => new Set(prev).add(imageFailKey(hub)))
                                          }
                                        />
                                      ) : (
                                        <GradientIconBox
                                          icon="business"
                                          colors={accentToGradient(accent)}
                                          boxSize={cpz(dz(36))}
                                          borderRadius={cpz(dz(10))}
                                          elevated
                                          size={cpz(dz(20))}
                                        />
                                      )}
                                    </View>
                                    <View style={styles.topPickTrackCardMain}>
                                      <Text style={styles.topPickTrackKicker}>CAR WASH</Text>
                                      <Text style={styles.topPickTrackTitle} numberOfLines={1}>
                                        {displayName}
                                      </Text>
                                      <Text style={styles.topPickTrackSubtitle} numberOfLines={1}>
                                        {hub.organization || 'Wash location'}
                                      </Text>
                                    </View>
                                  </View>
                                  <View style={styles.topPickTrackCardBottom}>
                                    <View style={styles.topPickTrackBottomMeta}>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="star" size={14} color="#FBBF24" />
                                        <Text style={styles.topPickTrackEtaText}>
                                          {hub.rating > 0 ? hub.rating.toFixed(1) : 'New'}
                                        </Text>
                                      </View>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                                        <Text style={styles.topPickTrackEtaText}>{hub.jobsCompleted} jobs</Text>
                                      </View>
                                      <View style={styles.topPickTrackEtaWrap}>
                                        <Ionicons name="chatbubble-outline" size={14} color={SKY} />
                                        <Text style={styles.topPickTrackEtaText}>
                                          {hub.reviewCount > 0
                                            ? `${hub.reviewCount} ${hub.reviewCount === 1 ? 'review' : 'reviews'}`
                                            : 'No reviews'}
                                        </Text>
                                      </View>
                                    </View>
                                  </View>
                                </View>
                              </Pressable>
                            </View>
                          );
                        });
                        return (
                          <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            contentContainerStyle={styles.topPicksCarouselContent}
                          >
                            {cards}
                          </ScrollView>
                        );
                      })()
                    ) : (
                      <View style={styles.prosEmptyState}>
                        <GradientIconBox
                          icon={washPicksSegment === 'pros' ? 'people-outline' : 'location-outline'}
                          preset="gray"
                          boxSize={dz(44)}
                          borderRadius={dz(14)}
                          muted
                          borderless
                        />
                        <Text style={styles.prosEmptyText}>
                          {washPicksSegment === 'pros'
                            ? topPicksValeters.length === 0 && topPicksHubs.length > 0
                              ? `No ${ccpPluralLower()} in this list — try the Locations tab.`
                              : getValetersEmptyMessage(availabilityFilter)
                            : topPicksHubs.length === 0 && topPicksValeters.length > 0
                              ? `No wash locations in this list — try the ${CCP.pluralShort} tab.`
                              : getLocationsEmptyMessage(availabilityFilter)}
                        </Text>
                      </View>
                    )
                  ) : (
                    <View style={styles.prosEmptyState}>
                      <GradientIconBox icon="sparkles-outline" preset="sky" boxSize={dz(44)} borderRadius={dz(14)} muted borderless />
                      <Text style={styles.prosEmptyText}>
                        Nothing to show for this time — try another day above.
                      </Text>
                    </View>
                  )}
                </View>

              {/* Availability picker modal (Today / Tomorrow / Next Week) */}
              <Modal visible={showAvailabilityPicker} transparent animationType="fade" onRequestClose={() => setShowAvailabilityPicker(false)}>
                <Pressable style={styles.availabilityPickerOverlay} onPress={() => setShowAvailabilityPicker(false)}>
                  <Pressable style={styles.availabilityPickerContent} onPress={(e) => e.stopPropagation()}>
                    <Text style={styles.availabilityPickerTitle}>When</Text>
                    {(['today', 'tomorrow', 'next_week'] as const).map((option) => (
                      <TouchableOpacity
                        key={option}
                        style={[styles.availabilityPickerOption, availabilityFilter === option && styles.availabilityPickerOptionActive]}
                        onPress={() => {
                          hapticFeedback('light');
                          setAvailabilityFilter(option);
                          setShowAvailabilityPicker(false);
                        }}
                        activeOpacity={0.8}
                      >
                        <Text style={[styles.availabilityPickerOptionText, availabilityFilter === option && styles.availabilityPickerOptionTextActive]}>
                          {option === 'today' ? 'Today' : option === 'tomorrow' ? 'Tomorrow' : 'Next Week'}
                        </Text>
                        {availabilityFilter === option && <Ionicons name="checkmark" size={18} color={SKY} />}
                      </TouchableOpacity>
                    ))}
                  </Pressable>
                </Pressable>
              </Modal>
            </View>

        {/* Payment due / active booking card — shown in YOUR HUB when active; otherwise here */}
        {!showActiveJobInHub ? (
        <ActiveBookingSection
          activeBookingLoading={activeBookingLoading}
          activeBooking={activeBooking}
          activeBookingMapRegion={activeBookingMapRegion}
          userLocation={userLocation}
          valeterLocation={valeterLocation}
          onResumeTracking={handleResumeTracking}
          styles={styles}
          eta={eta}
          loyaltyData={loyaltyData}
          reservedCounts={{ nearbyValeters: exploreNearbyCount, carWashCount, detailingHubCount, recentBookingsLoading }}
          sectionStyle={[sectionContainerStyle, tabletSectionMarginReset]}
        />
        ) : null}

        {/* Recent Bookings Section */}
        {recentBookings.length > 0 && (
          <View style={[styles.recentBookingsSection, sectionContainerStyle, tabletSectionMarginReset]}>
            <View style={styles.recentBookingsHeader}>
              <View style={styles.recentBookingsHeaderLeft}>
                <View style={styles.recentBookingsIconWrapper}>
                  <GradientIconBox icon="time-outline" preset="sky" boxSize={dz(34)} borderRadius={dz(10)} elevated size={dz(18)} />
                </View>
                <View>
                  <Text style={styles.recentBookingsTitle}>Recent Bookings</Text>
                  <Text style={styles.recentBookingsSubtitle}>
                    {recentBookings.length} booking{recentBookings.length === 1 ? '' : 's'}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={styles.recentBookingsViewAllRow}
                onPress={() => router.push('/owner/wash-history')}
                activeOpacity={0.7}
              >
                <Text style={styles.recentBookingsViewAll}>View all</Text>
                <GradientIconBox icon="arrow-forward-circle" preset="sky" boxSize={dz(28)} borderRadius={dz(9)} elevated size={dz(16)} />
              </TouchableOpacity>
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.recentBookingsScrollContent}>
              {recentBookings.map((booking) => (
                <TouchableOpacity
                  key={booking.id}
                  style={[
                    styles.recentBookingCard,
                    {
                      borderLeftWidth: 4,
                      borderLeftColor: booking.status === 'completed' ? '#10B981' : '#EF4444',
                    },
                  ]}
                  activeOpacity={0.9}
                  onPress={() => router.push(`/owner/wash-history?highlightId=${booking.id}`)}
                >
                  <View style={styles.recentBookingCardContent}>
                    <View style={styles.recentBookingTopRow}>
                      <View style={styles.recentBookingIconWrap}>
                        <GradientIconBox
                          icon={booking.status === 'completed' ? 'checkmark-circle' : 'close-circle'}
                          preset={booking.status === 'completed' ? 'emerald' : 'red'}
                          boxSize={dz(32)}
                          borderRadius={dz(10)}
                          elevated
                          size={dz(18)}
                        />
                      </View>
                      <View style={styles.recentBookingInfo}>
                        <Text style={styles.recentBookingService} numberOfLines={1}>
                          {getServiceDisplayName(booking.service_type, booking.service_name)}
                        </Text>
                        <Text style={styles.recentBookingStatus} numberOfLines={1}>
                          {booking.status === 'completed' ? 'Completed' : 'Cancelled'}
                        </Text>
                      </View>
                      <View style={styles.recentBookingValeterAvatar}>
                        <Text style={styles.recentBookingValeterInitials}>{getValeterInitials(booking.valeter_name)}</Text>
                      </View>
                    </View>
                    {booking.location_address ? (
                      <View style={styles.recentBookingLocation}>
                        <Ionicons name="location-outline" size={12} color="rgba(255,255,255,0.6)" />
                        <Text style={styles.recentBookingLocationText} numberOfLines={1}>
                          {booking.location_address}
                        </Text>
                      </View>
                    ) : null}
                    <View style={styles.recentBookingBottomRow}>
                      <Text style={styles.recentBookingPrice}>£{Number(booking.price || 0).toFixed(2)}</Text>
                      {booking.scheduled_at ? (
                        <Text style={styles.recentBookingDate}>
                          {new Date(booking.scheduled_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        </Text>
                      ) : null}
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

          </View>
        )}
      </Animated.ScrollView>

      <ValeterProfileBottomSheet
        visible={valeterProfileSheet != null}
        onClose={() => setValeterProfileSheet(null)}
        valeterId={valeterProfileSheet?.id ?? null}
        seed={valeterProfileSheet}
        onRequestBook={() => {
          const id = valeterProfileSheet?.id;
          if (!id) return;
          setValeterProfileSheet(null);
          handleAttemptNewBooking('/owner/booking/create', { preferredValeterId: id });
        }}
      />

      {!MOBILE_SERVICE_ONLY_LAUNCH ? (
      <HubLocationProfileBottomSheet
        visible={hubLocationSheet != null}
        onClose={() => setHubLocationSheet(null)}
        locationId={hubLocationSheet?.id ?? null}
        seed={hubLocationSheet}
        onRequestBook={(hubId) => {
          setHubLocationSheet(null);
          router.push({ pathname: '/owner/booking/physical/vehicle', params: { locationId: hubId } } as any);
        }}
      />
      ) : null}

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'transparent' },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  headerRightRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerProfilePicWrap: {
    width: dz(36),
    height: dz(36),
    borderRadius: dz(18),
    overflow: 'hidden',
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 0,
    borderColor: 'transparent',
  },
  headerProfilePic: {
    width: '100%',
    height: '100%',
  },
  headerProfilePicMirror: {
    transform: [{ scaleX: -1 }],
  },

  bookingButtonsSection: {
    flexDirection: 'column',
    gap: DASHBOARD_V_GAP,
    marginHorizontal: DASHBOARD_H_INSET,
    marginTop: 0,
    marginBottom: DASHBOARD_V_GAP,
  },
  bookWishCard: {
    borderRadius: dzHero(20),
    overflow: 'hidden',
    marginBottom: dzHero(4),
    position: 'relative',
    borderWidth: 0,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: dzHero(8) },
    shadowOpacity: 0.2,
    shadowRadius: dzHero(16),
    elevation: 10,
  },
  bookWishGlassFallback: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.38)',
  },
  bookWishGlassRim: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: dzHero(20),
    borderWidth: 1,
    borderColor: CUSTOMER_WISH_HERO_GLASS_RIM,
  },
  bookWishGlassTopGlow: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: dzHero(20),
    borderTopRightRadius: dzHero(20),
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.32)',
  },
  bookWishContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: dzHero(12),
    paddingHorizontal: dzHero(14),
    gap: dzHero(10),
    zIndex: 1,
    minHeight: dzHero(56),
  },
  bookWishContentLoading: {
    justifyContent: 'center',
  },
  bookWishLoadingText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: dzHero(13),
    fontWeight: '600',
    marginTop: 8,
  },
  bookWishTextWrap: {
    flex: 1,
    minWidth: 0,
    alignItems: 'center',
  },
  bookWishTitle: {
    color: '#F8FAFC',
    fontSize: isSmallScreen ? dzHero(19) : dzHero(20),
    fontWeight: '800',
    letterSpacing: 0.15,
    textAlign: 'center',
  },
  bookWishSubtitle: {
    color: 'rgba(255,255,255,0.62)',
    fontSize: dzHero(14),
    fontWeight: '600',
    marginTop: dzHero(5),
    textAlign: 'center',
  },
  bookWishChevron: {
    width: dzHero(42),
    height: dzHero(42),
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActionsRow: {
    flexDirection: 'row',
    width: '100%',
    gap: dzHero(10),
  },
  quickActionPressable: {
    flex: 1,
    minWidth: 0,
  },
  quickActionItem: {
    flex: 1,
    alignItems: 'center',
    gap: dzHero(7),
    minWidth: 0,
    opacity: 0.95,
  },
  quickActionItemTablet: {
    minWidth: 0,
    gap: dzHero(9),
  },
  quickActionIconBox: {
    width: dzHero(48),
    height: dzHero(48),
    borderRadius: dzHero(14),
  },
  quickActionIconBoxTablet: {
    width: dzHero(56),
    height: dzHero(56),
    borderRadius: dzHero(16),
  },
  quickActionItemLabel: {
    color: '#F9FAFB',
    fontSize: dzHero(12),
    fontWeight: '600',
    textAlign: 'center',
  },
  explorePreviewPressable: {
    width: '100%',
    marginTop: DASHBOARD_V_GAP,
  },
  explorePreviewInline: {
    paddingHorizontal: 0,
    paddingTop: 0,
    paddingBottom: 0,
    backgroundColor: 'transparent',
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  explorePreviewInlineTablet: {
    paddingHorizontal: 0,
  },
  explorePreviewCard: {
    borderRadius: dz(22),
    overflow: 'hidden',
    padding: dz(14),
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(15,23,42,0.62)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
  explorePreviewCardTablet: {
    padding: dz(16),
  },
  explorePreviewGlow: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(139,92,246,0.08)',
  },
  explorePreviewInlineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: dz(10),
    gap: dz(12),
  },
  explorePreviewLiveDotWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  explorePreviewLiveDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#34D399',
  },
  explorePreviewLiveText: {
    color: 'rgba(110,231,183,0.9)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  explorePreviewList: {
    gap: 10,
  },
  explorePreviewMapShell: {
    height: dz(210),
    borderRadius: dz(22),
    overflow: 'hidden',
    backgroundColor: 'rgba(8,20,38,0.9)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    marginBottom: 0,
    position: 'relative',
    shadowColor: '#020617',
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.35,
    shadowRadius: 22,
    elevation: 12,
  },
  explorePreviewMapInner: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
    borderRadius: dz(22),
  },
  explorePreviewEmptyMap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(15,23,42,0.85)',
  },
  explorePreviewMapSheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '38%',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  explorePreviewMapRim: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: dz(22),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  explorePreviewMapBadgeRow: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  explorePreviewMapBadge: {
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 8,
    backgroundColor: 'rgba(2,10,24,0.55)',
  },
  explorePreviewMapBadgeText: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  explorePreviewMapCta: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 10,
    alignItems: 'flex-end',
  },
  explorePreviewMapCtaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: 'rgba(2,10,24,0.55)',
  },
  explorePreviewMapCtaText: {
    color: 'rgba(248,250,252,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  explorePreviewMiniCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: dz(10),
    padding: dz(10),
    borderRadius: dz(14),
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  explorePreviewMiniIconWrap: {
    width: dz(42),
    height: dz(42),
    borderRadius: dz(13),
    overflow: 'hidden',
  },
  explorePreviewMiniTextCol: {
    flex: 1,
    minWidth: 0,
  },
  explorePreviewMiniName: {
    color: '#F9FAFB',
    fontSize: dz(13),
    fontWeight: '700',
  },
  explorePreviewMiniMeta: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 1,
  },
  explorePreviewMiniPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.22)',
  },
  explorePreviewMiniPillText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
  explorePreviewEmpty: {
    paddingVertical: 14,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
  },
  explorePreviewEmptyText: {
    color: 'rgba(255,255,255,0.62)',
    fontSize: 13,
    fontWeight: '600',
  },
  explorePreviewFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    marginTop: 8,
  },
  explorePreviewFooterText: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 13,
    fontWeight: '700',
  },
  explorePreviewFooterHint: {
    color: 'rgba(255,255,255,0.52)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'right',
  },
  yourHubSection: {
    marginTop: DASHBOARD_V_GAP,
    paddingTop: dz(4),
  },
  yourHubHeader: {
    marginBottom: DASHBOARD_V_GAP,
  },
  statusRingsSection: {
    marginTop: 4,
    paddingVertical: 8,
    paddingHorizontal: 2,
  },
  statusRingsTitle: {
    color: 'rgba(248,250,252,0.88)',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 0.4,
    marginBottom: 10,
    textTransform: 'uppercase',
  },
  statusRingsRow: {
    flexDirection: 'row',
    width: '100%',
    gap: 18,
  },
  statusRingItem: {
    flex: 1,
    minWidth: 0,
    alignItems: 'center',
  },
  statusRingWrap: {
    width: dz(80),
    height: dz(80),
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusRingCenterFill: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  statusRingCenterValue: {
    color: '#F9FAFB',
    fontSize: dz(18),
    fontWeight: '700',
    zIndex: 1,
  },
  statusRingCenterSm: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '800',
    maxWidth: 62,
    textAlign: 'center',
    zIndex: 1,
  },
  statusRingLabel: {
    marginTop: dz(8),
    color: '#F9FAFB',
    fontSize: dz(13),
    fontWeight: '800',
    textAlign: 'center',
  },
  statusRingHint: {
    marginTop: 2,
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },

  /* Active Booking — map preview + glass details */
  activeBookingSection: {
    marginHorizontal: DASHBOARD_H_INSET,
    marginBottom: dz(16),
  },
  activeBookingSkeleton: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(15,23,42,0.4)',
    padding: 22,
    alignItems: 'center',
  },
  activeBookingCard: {
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(2,6,23,0.72)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    shadowColor: '#020617',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 8,
  },
  activeBookingGradient: {
    padding: dz(12),
  },
  activeBookingCardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 56,
    gap: 14,
  },
  activeBookingMapContainer: {
    height: 108,
    overflow: 'hidden',
    position: 'relative',
  },
  activeBookingLiveBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(2,6,23,0.62)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  activeBookingLiveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  activeBookingLiveText: {
    color: 'rgba(248,250,252,0.94)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  activeBookingBody: {
    position: 'relative',
    overflow: 'hidden',
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 10,
    gap: 8,
  },
  activeBookingBodySheen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 22,
  },
  activeBookingMainRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  activeBookingRingWrap: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBookingCardContent: {
    flex: 1,
    minWidth: 0,
    gap: 1,
  },
  activeBookingLoadingText: {
    color: LIGHT_SKY,
    fontSize: 14,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
  activeBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  activeBookingIconWrap: {
    width: dz(50),
    height: dz(50),
    borderRadius: dz(16),
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 0,
    borderColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeBookingTitle: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  activeBookingSubtitle: {
    color: 'rgba(248,250,252,0.9)',
    fontSize: 13,
    fontWeight: '600',
  },
  activeBookingProRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 2,
    minWidth: 0,
  },
  activeBookingProAvatar: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(148,163,184,0.2)',
  },
  activeBookingProAvatarFallback: {
    width: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBookingValeter: {
    color: 'rgba(226,232,240,0.78)',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
    minWidth: 0,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: SKY,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '900',
  },
  activeBookingMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 6,
  },
  activeBookingMetaText: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  activeBookingProgressTrack: {
    height: 3,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.18)',
    overflow: 'hidden',
  },
  activeBookingProgressFill: {
    height: '100%',
    borderRadius: 999,
  },
  activeBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  activeBookingPriceWrap: {
    gap: 1,
  },
  activeBookingPriceLabel: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  activeBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  activeBookingActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  activeBookingCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 12,
    fontWeight: '800',
  },
  activeBookingMap: {
    width: '100%',
    height: '100%',
  },
  mapMarkerContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapMarkerImage: {
    width: 32,
    height: 32,
  },
  etaOverlay: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  etaText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '800',
  },

  /* Recent Bookings Section */
  recentBookingsSection: {
    marginHorizontal: DASHBOARD_H_INSET,
    marginBottom: dz(12),
  },
  recentBookingsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  recentBookingsHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  recentBookingsIconWrapper: {
    width: dz(36),
    height: dz(36),
    borderRadius: dz(10),
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  recentBookingsTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? dz(16) : dz(18),
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  recentBookingsSubtitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  recentBookingsViewAll: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  recentBookingsViewAllRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  recentBookingsScrollContent: {
    gap: 12,
    paddingRight: 4,
  },
  recentBookingCard: {
    width: dz(172),
    borderRadius: dz(12),
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  recentBookingCardContent: {
    padding: 14,
    gap: 10,
  },
  recentBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  recentBookingIconWrap: {
    marginTop: 2,
  },
  recentBookingValeterAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  recentBookingValeterInitials: {
    color: LIGHT_SKY,
    fontSize: 11,
    fontWeight: '800',
  },
  recentBookingInfo: {
    flex: 1,
    gap: 4,
  },
  recentBookingService: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  recentBookingStatus: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  recentBookingLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  recentBookingLocationText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
  },
  recentBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  recentBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  recentBookingDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },

  /* Availability - New Design */
  availabilitySection: { 
    marginBottom: dz(20),
    marginHorizontal: DASHBOARD_H_INSET,
  },
  availabilityHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  availabilityHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  availabilitySectionTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? dz(18) : dz(20),
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#EF4444',
  },
  liveText: {
    color: '#EF4444',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  availabilityCardNew: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  availabilityGradientNew: { 
    padding: 20,
  },
  availabilityMainDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
    marginBottom: 16,
  },
  availabilityCountCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 2,
  },
  availabilityCountNumber: {
    color: LIGHT_SKY,
    fontSize: 33,
    fontWeight: '900',
    lineHeight: 36,
  },
  availabilityCountLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityCountNumberSmall: {
    color: LIGHT_SKY,
    fontSize: 25,
    fontWeight: '900',
    lineHeight: 28,
    marginTop: 4,
  },
  availabilityCountLabelSmall: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityQuickInfo: {
    flex: 1,
    gap: 10,
  },
  quickInfoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  quickInfoText: {
    color: LIGHT_SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  availabilityStatusBar: {
    height: 6,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 12,
  },
  statusBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  qualityIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
  },
  qualityText: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.3,
  },

  poweredBySection: {
    alignItems: 'center',
    paddingVertical: dz(24),
    paddingHorizontal: DASHBOARD_H_INSET,
    marginTop: dz(8),
  },
  poweredByText: {
    color: LIGHT_SKY,
    fontSize: 13,
    opacity: 0.8,
    fontWeight: '600',
  },
  hiddenSection: {
    display: 'none',
  },
  /* Live Availability - Bottom Redesigned */
  availabilitySectionBottom: {
    marginHorizontal: DASHBOARD_H_INSET,
    marginBottom: dz(18),
    marginTop: dz(2),
    paddingTop: dz(14),
    borderTopWidth: StyleSheet.hairlineWidth * 2,
    borderTopColor: 'rgba(148,163,184,0.16)',
  },
  availabilityCardBottom: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  availabilityGradientBottom: {
    padding: 24,
  },
  availabilityHeaderBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  availabilityHeaderLeftBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  availabilityIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  availabilityTitleBottom: {
    color: '#F9FAFB',
    fontSize: 21,
    fontWeight: '800',
    letterSpacing: 0.3,
    marginBottom: 2,
  },
  availabilitySubtitleBottom: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  liveIndicatorBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  liveDotBottom: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  liveTextBottom: {
    color: '#EF4444',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  availabilityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  availabilityRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  availabilityRowContent: {
    flex: 1,
  },
  availabilityRowLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 4,
  },
  availabilityRowValue: {
    color: SKY,
    fontSize: 19,
    fontWeight: '800',
  },
  /* Top Care Pros section header — text only */
  topWashersHeader: {
    marginBottom: DASHBOARD_V_GAP,
    gap: DASHBOARD_V_GAP,
  },
  topWashersHeaderTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  topWashersHeaderMain: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  topWashersTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  topWashersCountText: {
    color: 'rgba(186,230,253,0.92)',
    fontSize: 12,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    letterSpacing: 0.4,
  },
  topWashersFilterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingTop: 2,
    flexShrink: 0,
  },
  topWashersFilterBtnText: {
    fontSize: dz(11),
    fontWeight: '700',
  },
  topWashersSegmentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  topWashersSegmentTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: dz(4),
    minHeight: dz(28),
    paddingVertical: dz(4),
    paddingHorizontal: dz(6),
    borderRadius: dz(8),
    borderWidth: 1,
  },
  topWashersSegmentTabIdle: {
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(8,20,38,0.28)',
  },
  topWashersSegmentLabel: {
    color: 'rgba(148,163,184,0.78)',
    fontSize: dz(11),
    fontWeight: '700',
    letterSpacing: 0.15,
    flexShrink: 1,
  },
  topWashersSegmentCount: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  topWashersSegmentCountText: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  availabilityPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  availabilityPickerContent: {
    width: '100%',
    maxWidth: 280,
    borderRadius: 16,
    backgroundColor: '#1E293B',
    borderWidth: 0,
    borderColor: 'transparent',
    padding: 16,
  },
  availabilityPickerTitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityPickerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 12,
    marginBottom: 4,
  },
  availabilityPickerOptionActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  availabilityPickerOptionText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 17,
    fontWeight: '600',
  },
  availabilityPickerOptionTextActive: {
    color: '#E0F2FE',
  },
  topRatedTabs: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 10,
    padding: 4,
  },
  topRatedTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingVertical: 10,
    paddingHorizontal: 6,
    borderRadius: 8,
    minWidth: 0,
  },
  topRatedTabActive: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  topRatedTabText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 13,
    fontWeight: '700',
    flexShrink: 1,
  },
  topRatedTabTextActive: {
    color: '#0A1929',
  },
  availabilityFiltersRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 4,
  },
  availabilityFilterPill: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  availabilityFilterPillActive: {
    borderColor: 'rgba(125,211,252,0.45)',
    backgroundColor: 'rgba(135,206,235,0.24)',
  },
  availabilityFilterText: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 13,
    fontWeight: '700',
  },
  availabilityFilterTextActive: {
    color: '#E0F2FE',
  },
  prosNearbyContainer: {
    marginBottom: 4,
  },
  topPicksCarouselContent: {
    gap: dz(12),
    paddingVertical: dz(8),
    paddingRight: dz(8),
    alignItems: 'stretch',
  },
  topPickTrackCard: {
    overflow: 'hidden',
    borderRadius: cpz(dz(18)),
    backgroundColor: 'rgba(6,16,32,0.55)',
    alignSelf: 'stretch',
    shadowColor: 'rgba(56,189,248,0.18)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.32,
    shadowRadius: 14,
    elevation: 6,
    borderWidth: 1,
    borderColor: 'rgba(148,196,220,0.38)',
  },
  topPickTrackCardPad: { padding: cpz(dz(12)), position: 'relative', gap: cpz(dz(10)) },
  topPickTrackAccentRail: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
  },
  topPickTrackCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: cpz(dz(10)),
  },
  topPickTrackIconWrap: {
    width: cpz(dz(48)),
    height: cpz(dz(48)),
    borderRadius: cpz(dz(14)),
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.36)',
  },
  topPickTrackAvatarImg: { width: cpz(dz(48)), height: cpz(dz(48)), borderRadius: cpz(dz(14)) },
  topPickTrackCardMain: { flex: 1, minWidth: 0, gap: cpz(dz(2)) },
  topPickTrackKicker: {
    fontSize: dz(12),
    fontWeight: '900',
    color: 'rgba(186,230,253,0.92)',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
    marginBottom: 5,
  },
  topWashersKickerInline: {
    marginBottom: 0,
  },
  topPickTrackTitle: {
    color: '#F8FAFC',
    fontSize: cpz(dz(16)),
    fontWeight: '900',
    letterSpacing: 0.1,
  },
  topPickTrackSubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: cpz(dz(14)),
    fontWeight: '600',
    marginBottom: cpz(dz(4)),
  },
  topPickTrackStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  topPickTrackStatusDot: { width: 7, height: 7, borderRadius: 4 },
  topPickTrackStatusPillText: { fontSize: dz(12), fontWeight: '800' },
  topPickTrackCardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingTop: 8,
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  topPickTrackBottomMeta: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8 },
  topPickTrackEtaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.3)',
    backgroundColor: 'rgba(8,20,38,0.56)',
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  topPickTrackEtaText: { color: SKY, fontSize: dz(11), fontWeight: '800' },
  topProAvatarFill: {
    width: '100%',
    height: '100%',
  },
  topProOnlineDot: {
    position: 'absolute',
    bottom: 3,
    right: 3,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: 'rgba(30,41,59,0.95)',
  },
  // Explore-style cards (same design as Explore page for consistency)
  exploreCardWrap: {
    width: Math.min(268, width - 56),
    marginRight: 12,
  },
  exploreCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(15,23,42,0.52)',
  },
  exploreHubHero: {
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  exploreHubHeroImage: { width: 72, height: 72, opacity: 0.9 },
  exploreRatingPill: {
    position: 'absolute',
    bottom: 8,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  exploreRatingPillText: { color: '#FBBF24', fontSize: 14, fontWeight: '700' },
  exploreCardBody: { padding: 14 },
  exploreHubNameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4, gap: 8 },
  exploreCardTitle: { fontSize: 16, fontWeight: '800', flex: 1, color: '#F9FAFB', letterSpacing: -0.2 },
  exploreAddressRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 6 },
  exploreAddressText: { flex: 1, fontSize: 14, color: '#94A3B8' },
  exploreCardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, gap: 12 },
  exploreFooterLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  exploreViewDetailsText: { fontSize: 14, fontWeight: '700', color: SKY },
  exploreBookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: SKY,
  },
  exploreBookBtnSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: SKY,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  exploreBookBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  exploreBookBtnTextSmall: { color: '#fff', fontSize: 12, fontWeight: '800' },
  exploreFromPrice: { fontSize: 14, fontWeight: '600', color: '#94A3B8', marginBottom: 6 },
  exploreDistancePill: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  exploreDistanceText: { color: SKY, fontSize: 13, fontWeight: '700' },
  exploreValeterCard: {
    borderRadius: 26,
    overflow: 'hidden',
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(11,18,34,0.78)',
    shadowColor: '#020617',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.28,
    shadowRadius: 16,
    elevation: 8,
  },
  exploreValeterMain: { flexDirection: 'row' },
  exploreValeterAvatarWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 10,
    position: 'relative',
  },
  exploreValeterAvatar: { width: 48, height: 48, borderRadius: 16 },
  exploreValeterAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: SKY + '25',
  },
  exploreOnlineDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: 'rgba(30,41,59,0.8)',
  },
  exploreValeterBody: { flex: 1, minWidth: 0 },
  exploreValeterNameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 2 },
  exploreValeterStatsRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8, marginTop: 2 },
  exploreStatItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  exploreStatItemText: { fontSize: 13, color: '#94A3B8' },
  exploreAvailabilityBadge: {
    backgroundColor: '#10B98120',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginLeft: 4,
  },
  exploreAvailabilityBadgeText: { color: '#10B981', fontSize: 12, fontWeight: '700' },
  exploreValeterFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6, gap: 8 },
  exploreInfoBtn: { padding: 4 },
  proCard: {
    width: width - (isSmallScreen ? 24 : 40),
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  proCardTablet: {
    width: Math.min(980, width) - 56,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  proCardTopRow: {
    position: 'absolute',
    top: 6,
    left: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 5,
  },
  proCardTopRowHub: {
    justifyContent: 'flex-end',
  },
  proCardTopRowValeter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 8,
  },
  proCardThumb: {
    width: 24,
    height: 24,
    borderRadius: 12,
  },
  proCardThumbPlaceholder: {
    backgroundColor: 'rgba(135,206,235,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proCardInfoBtn: {},
  proCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  proCardBody: {
    flex: 1,
    minWidth: 0,
    marginLeft: 12,
    justifyContent: 'center',
  },
  proCardAvatarWrap: {
    position: 'relative',
    marginRight: 0,
  },
  proAvatar: {
    width: dz(40),
    height: dz(40),
    borderRadius: dz(12),
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proAvatarImg: {
    width: dz(40),
    height: dz(40),
    borderRadius: dz(12),
  },
  proAvatarImgRing: {
    width: dz(40),
    height: dz(40),
    borderRadius: dz(10),
  },
  proAvatarRing: {
    width: dz(40),
    height: dz(40),
    borderRadius: dz(10),
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  proAvatarValeterIcon: {
    width: dz(44),
    height: dz(44),
  },
  proAvatarHub: {
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  proOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    borderWidth: 1.5,
    borderColor: 'rgba(15,23,42,0.8)',
  },
  proName: {
    color: '#F9FAFB',
    fontSize: dz(14),
    fontWeight: '700',
    textAlign: 'left',
    marginBottom: 1,
    paddingHorizontal: 0,
  },
  proOrganization: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 12,
    textAlign: 'left',
    marginBottom: 2,
    paddingHorizontal: 0,
  },
  proAddress: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    textAlign: 'left',
    marginBottom: 2,
    paddingHorizontal: 0,
    lineHeight: 14,
  },
  proCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 4,
    marginBottom: 2,
  },
  proRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  proRatingText: {
    color: '#FBBF24',
    fontSize: 13,
    fontWeight: '700',
  },
  proMetaText: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 12,
    fontWeight: '600',
  },
  proStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.18)',
    alignSelf: 'flex-start',
  },
  proStatusPillOffline: {
    backgroundColor: 'rgba(148,163,184,0.2)',
  },
  proStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  proStatusDotOffline: {
    backgroundColor: '#94A3B8',
  },
  proStatusText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
  proStatusTextOffline: {
    color: '#94A3B8',
  },
  proDistancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 0,
  },
  proDistanceText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  prosEmptyState: {
    paddingVertical: 28,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: 18,
    borderWidth: 0,
    borderColor: 'transparent',
  },
  prosEmptyText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  statIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumber: {
    color: LIGHT_SKY,
    fontSize: 33,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 14,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statBadgeText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
  availabilityStatDivider: {
    width: 1,
    height: 80,
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  availabilityQuickInfoBottom: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickInfoCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  quickInfoContent: {
    flex: 1,
    gap: 2,
  },
  quickInfoLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  quickInfoValue: {
    color: LIGHT_SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  availabilityQualityBar: {
    gap: 10,
  },
  qualityBarBackground: {
    height: 8,
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  qualityBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  qualityIndicatorBottom: {
    alignItems: 'flex-start',
  },
  qualityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  qualityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  qualityTextBottom: {
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  /* Detailing Hub Count - Purple Styled */
  availabilityStatCardPurple: {
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.3)',
    marginTop: 12,
  },
  statIconWrapperPurple: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumberPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 33,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabelPurple: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 14,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadgePurple: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  statBadgeTextPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
    fontWeight: '700',
  },
  availabilityETARow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  statsSection: {
    marginBottom: 18,
  },
  statsScroll: {
    flexGrow: 0,
  },
  statsScrollContent: {
    paddingHorizontal: DASHBOARD_H_INSET,
    paddingVertical: dz(4),
  },
  statsSlideCard: {
    width: width * 0.52,
    minWidth: 160,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
    marginRight: 10,
  },
  statsSlideIconWrapper: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 8,
  },
  statsSlideValue: {
    color: '#F9FAFB',
    fontSize: 21,
    fontWeight: '800',
    marginBottom: 2,
  },
  statsSlideLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  etaCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  etaContent: {
    flex: 1,
  },
  etaLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  etaValue: {
    color: SKY,
    fontSize: 19,
    fontWeight: '800',
  },

  profileModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  profileModalContent: {
    backgroundColor: 'transparent',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '85%',
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.5)',
    overflow: 'hidden',
  },
  profileModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
  },
  profileModalTitle: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
  },
  profileModalScroll: {
    paddingHorizontal: 20,
    paddingBottom: 32,
  },
  profileModalAvatar: {
    alignItems: 'center',
    marginBottom: 12,
  },
  profileModalAvatarImg: {
    width: 88,
    height: 88,
    borderRadius: 44,
    borderWidth: 2,
    borderColor: SKY,
  },
  profileModalAvatarInner: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileModalHubIcon: {
    width: 76,
    height: 76,
  },
  profileModalName: {
    color: '#F9FAFB',
    fontSize: 21,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
  },
  profileModalOrg: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 8,
  },
  profileModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginBottom: 16,
  },
  profileModalJoinedText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  profileModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
    marginBottom: 24,
  },
  profileModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  profileModalStatText: {
    color: '#E5E7EB',
    fontSize: 15,
    fontWeight: '600',
  },
  profileModalPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  profileModalPillOffline: {
    backgroundColor: 'rgba(148,163,184,0.2)',
    borderColor: 'rgba(148,163,184,0.3)',
  },
  profileModalPillText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '700',
  },
  profileModalPillTextOffline: {
    color: '#94A3B8',
  },
  profileModalSection: {
    marginTop: 8,
  },
  profileModalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 12,
  },
  profileModalReviewsPlaceholder: {
    padding: 24,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    gap: 8,
  },
  profileModalPlaceholderText: {
    color: 'rgba(148,163,184,0.7)',
    fontSize: 14,
    fontWeight: '500',
  },
  profileModalReviewItem: {
    padding: 12,
    marginBottom: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
  },
  profileModalReviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  profileModalReviewRating: {
    color: '#FBBF24',
    fontSize: 15,
    fontWeight: '700',
  },
  profileModalReviewText: {
    color: '#E5E7EB',
    fontSize: 15,
    lineHeight: 20,
  },
  activeBookingChatBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(56,189,248,0.35)',
    backgroundColor: 'rgba(56,189,248,0.12)',
  },
  activeBookingChatBtnLocked: {
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(148,163,184,0.1)',
  },
  profileModalCover: {
    height: 120,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  profileModalCoverImg: {
    width: '100%',
    height: '100%',
  },
  profileModalCoverPlaceholder: {
    flex: 1,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  profileModalHubLogo: {
    alignItems: 'center',
    marginTop: -28,
    marginBottom: 12,
  },
  profileModalHubLogoImg: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: SKY,
  },
  profileModalHubLogoInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#1E293B',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  profileModalAddress: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 15,
    flex: 1,
  },

  washHubModalOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  washHubModalContentWrap: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '85%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '40',
  },
  washHubModalContent: {
    padding: 24,
    backgroundColor: 'transparent',
  },
  washHubModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  washHubModalTitle: {
    fontSize: 21,
    fontWeight: '800',
  },
  washHubModalName: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 8,
  },
  washHubModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalAddress: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 15,
    flex: 1,
  },
  washHubModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  washHubModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  washHubModalStatText: {
    fontSize: 13,
    fontWeight: '700',
  },
  washHubModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalJoinedText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  washHubModalSection: {
    marginTop: 4,
  },
  washHubModalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 8,
  },
  washHubModalReviewItem: {
    padding: 10,
    marginBottom: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  washHubModalReviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  washHubModalReviewRating: {
    color: '#FBBF24',
    fontSize: 13,
    fontWeight: '700',
  },
  washHubModalReviewText: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 18,
  },
  washHubModalReviewsPlaceholder: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    gap: 6,
  },
  washHubModalPlaceholderText: {
    color: 'rgba(148,163,184,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
});
