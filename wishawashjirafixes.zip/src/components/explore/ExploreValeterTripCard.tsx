import React from 'react';
import TopCareProCard, { type TopCareProCardData } from '../shared/TopCareProCard';

export type { TopCareProCardData as ExploreValeterCardData };

type Props = {
  valeter: TopCareProCardData;
  width: number;
  accent: string;
  borderColor: string;
  onPress: () => void;
  onBook: () => void;
  onToggleFavourite?: () => void;
};

export default function ExploreValeterTripCard({
  valeter,
  width,
  accent,
  borderColor,
  onPress,
  onBook,
  onToggleFavourite,
}: Props) {
  return (
    <TopCareProCard
      pro={valeter}
      width={width}
      accent={accent}
      borderColor={borderColor}
      onPress={onPress}
      onBook={onBook}
      onToggleFavourite={onToggleFavourite}
      style={{ marginRight: 12 }}
    />
  );
}
