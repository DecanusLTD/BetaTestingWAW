/**
 * Bottom sheet - full Hinge-style hub profile (washes, detailing teaser, reviews).
 * Matches Explore filter sheet chrome (BusinessSheetBackground, handle, dim backdrop).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  TouchableOpacity,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { colors } from '../../constants/colors';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import { isLocationOpenNow, type OpeningHourRow } from '../shared/OpeningHoursSheet';
import HubProfileBody, { type HubProfileReview, type HubProfileService } from './HubProfileBody';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
  getIndexTrackingCardWidth,
} from '../../constants/bookingCardTheme';
import { WWPrimaryButton, WWSheetCloseButton } from '../ui';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../constants/launchCustomerScope';

const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;

export type ExploreHubProfileSheetHub = {
  id: string;
  name: string;
  address: string | null;
  rating?: number | null;
  total_reviews?: number | null;
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  offers_mobile?: boolean | null;
  openingHours?: OpeningHourRow[];
  profileImageUrl?: string | null;
};

function money(n: unknown): number {
  if (typeof n === 'number' && Number.isFinite(n)) return n;
  if (typeof n === 'string') return Number(n) || 0;
  return 0;
}

type Props = {
  hub: ExploreHubProfileSheetHub;
  glassBorder: string;
  onClose: () => void;
  onRequestHours: () => void;
  onBook: (hub: ExploreHubProfileSheetHub) => void;
};

export default function ExploreHubProfileSheet({
  hub,
  glassBorder,
  onClose,
  onRequestHours,
  onBook,
}: Readonly<Props>) {
  const insets = useSafeAreaInsets();
  const { height, width: windowW } = useWindowDimensions();
  const [services, setServices] = useState<HubProfileService[]>([]);
  const [reviews, setReviews] = useState<HubProfileReview[]>([]);
  const [extrasLoading, setExtrasLoading] = useState(false);

  const loadExtras = useCallback(async (locationId: string) => {
    setExtrasLoading(true);
    setServices([]);
    setReviews([]);
    try {
      const { data: svcData, error: svcError } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);
      if (!svcError && svcData) {
        const list: HubProfileService[] = (svcData as any[]).map((r) => ({
          service_name: (r.service_name || '').trim(),
          price: money(r.price),
          duration_minutes: typeof r.duration_minutes === 'number' ? r.duration_minutes : 0,
          is_enabled: r.is_enabled !== false,
        })).filter((s) => s.service_name && s.is_enabled);
        setServices(list);
      }

      const { data: reviewRows } = await supabase
        .from('bookings')
        .select('user_id, rating, review, completed_at')
        .eq('location_id', locationId)
        .eq('status', 'completed')
        .not('rating', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(15);
      const rows = (reviewRows || []) as { user_id: string; rating: number; review: string | null }[];
      if (rows.length > 0) {
        const userIds = [...new Set(rows.map((r) => r.user_id))];
        const { data: profilesData } = await supabase.from('profiles').select('id, full_name').in('id', userIds);
        const nameByUserId = new Map<string, string>();
        (profilesData || []).forEach((p: { id: string; full_name?: string | null }) => {
          nameByUserId.set(p.id, (p.full_name?.trim() || 'Customer'));
        });
        setReviews(
          rows.map((r) => ({
            rating: Number(r.rating) || 0,
            review: r.review ?? null,
            reviewerName: nameByUserId.get(r.user_id) || 'Customer',
          }))
        );
      }
    } finally {
      setExtrasLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadExtras(hub.id);
  }, [hub.id, loadExtras]);

  const hours = hub.openingHours ?? [];
  const accent = hub.detailing_offered ? DETAILING_YELLOW : SKY;
  const kicker = hub.detailing_offered ? 'DETAIL STUDIO' : 'WASH HUB';
  const rating = hub.rating != null ? Number(hub.rating) : null;
  const reviewCount = hub.total_reviews != null ? Number(hub.total_reviews) : null;
  const sheetMaxH = Math.min(height * 0.94, height - insets.top - 8);

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.sheetRoot}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityRole="button" accessibilityLabel="Dismiss" />
        <View style={[styles.sheetInner, { paddingBottom: insets.bottom }]}>
          <View
            style={[
              styles.sheetCard,
              {
                borderColor: HEADER_STYLE_CARD_BORDER || glassBorder,
                maxHeight: sheetMaxH,
              },
            ]}
          >
            <BusinessSheetBackground />
            <View style={styles.handle} />
            <View style={styles.titleRow}>
              <View style={styles.titleTextCol}>
                <Text style={styles.sheetTitle}>Car wash details</Text>
                <Text style={styles.sheetSubtitle} numberOfLines={1}>
                  Services, pricing and customer reviews
                </Text>
              </View>
              <WWSheetCloseButton onPress={onClose} hitSlop={12} accessibilityLabel="Close" />
            </View>

            <ScrollView
              style={styles.sheetScroll}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.scrollContent}
              bounces
            >
              <HubProfileBody
                name={hub.name}
                kicker={kicker}
                address={hub.address}
                rating={rating}
                reviewCount={reviewCount}
                isOpen={isLocationOpenNow(hours)}
                ecoWashing={hub.eco_washing ?? null}
                detailingOffered={hub.detailing_offered ?? null}
                offersMobile={hub.offers_mobile ?? null}
                profileImageUrl={hub.profileImageUrl ?? null}
                openingHours={hours}
                onOpenHours={() => {
                  hapticFeedback('light');
                  onRequestHours();
                }}
                services={services}
                reviews={reviews}
                extrasLoading={extrasLoading}
                accentColor={accent}
                borderGlass={glassBorder}
                onWashTierPress={
                  MOBILE_SERVICE_ONLY_LAUNCH
                    ? undefined
                    : (tierId) => {
                        hapticFeedback('light');
                        onClose();
                        router.push({
                          pathname: '/owner/booking/physical/vehicle',
                          params: { locationId: hub.id, serviceId: tierId },
                        });
                      }
                }
              />
            </ScrollView>

            {!MOBILE_SERVICE_ONLY_LAUNCH ? (
            <View style={[styles.footer, { borderTopColor: glassBorder, paddingBottom: Math.max(4, insets.bottom) }]}>
              <WWPrimaryButton
                title="Book wash"
                onPress={() => {
                  hapticFeedback('light');
                  onClose();
                  onBook(hub);
                }}
                leftIconName="calendar-outline"
                leftIconSize={20}
                style={{
                  alignSelf: 'center',
                  width: getIndexTrackingCardWidth(windowW),
                }}
              />
            </View>
            ) : null}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  sheetRoot: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  sheetInner: { width: '100%', alignSelf: 'stretch' },
  sheetCard: {
    width: '100%',
    flex: 0,
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    overflow: 'hidden',
    paddingHorizontal: 18,
    borderWidth: 1,
    borderBottomWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  handle: {
    width: 46,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 10,
    marginBottom: 8,
    backgroundColor: 'rgba(148,163,184,0.55)',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 8,
    zIndex: 1,
  },
  titleTextCol: { flex: 1, minWidth: 0 },
  sheetTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', letterSpacing: -0.4 },
  sheetSubtitle: {
    fontSize: 12,
    color: 'rgba(226,232,240,0.92)',
    marginTop: 3,
    letterSpacing: 0.15,
  },
  sheetScroll: { flexShrink: 1 },
  scrollContent: { paddingBottom: 4 },
  footer: {
    paddingTop: 12,
    marginHorizontal: -18,
    paddingHorizontal: 18,
    borderTopWidth: 1,
    backgroundColor: 'rgba(2,6,23,0.45)',
  },
});
