import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import {
  BOOKING_CARD,
  BOOKING_GLASS_TOP_SHEEN,
  BOOKING_GLASS_TOP_SHEEN_LOCATIONS,
} from '../../constants/bookingCardTheme';
import { CONTENT_PADDING_H } from '../../constants/pageStyles';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const SKY = colors.SKY;
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

export type CalendarMarkedDay = {
  count: number;
  accent?: string;
};

export function toDayKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export function buildMonthGrid(year: number, month: number): (Date | null)[] {
  const lastDom = new Date(year, month + 1, 0).getDate();
  const startPad = (new Date(year, month, 1).getDay() + 6) % 7;
  const cells: (Date | null)[] = Array.from({ length: startPad }, () => null);
  for (let dom = 1; dom <= lastDom; dom += 1) {
    cells.push(new Date(year, month, dom));
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

type Props = {
  visibleMonth: Date;
  onShiftMonth: (delta: number) => void;
  selectedDay: Date | null;
  onSelectDay: (day: Date) => void;
  markedDays?: Map<string, CalendarMarkedDay>;
  monthKicker?: string;
  minSelectableDay?: Date;
  monthMeta?: string;
};

export default function DigitalMonthCalendar({
  visibleMonth,
  onShiftMonth,
  selectedDay,
  onSelectDay,
  markedDays,
  monthKicker = 'SCHEDULE',
  minSelectableDay,
  monthMeta,
}: Props) {
  const { width } = useWindowDimensions();
  const today = useMemo(() => startOfDay(new Date()), []);
  const minDay = useMemo(() => (minSelectableDay ? startOfDay(minSelectableDay) : null), [minSelectableDay]);

  const monthCells = useMemo(
    () => buildMonthGrid(visibleMonth.getFullYear(), visibleMonth.getMonth()),
    [visibleMonth]
  );

  const monthLabel = visibleMonth.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

  const cellGap = 6;
  const calendarPad = 14;
  const innerWidth = width - CONTENT_PADDING_H * 2;
  const cellSize = Math.floor((innerWidth - calendarPad * 2 - cellGap * 6) / 7);

  const handleShift = (delta: number) => {
    hapticFeedback('light');
    onShiftMonth(delta);
  };

  const handleDayPress = (day: Date) => {
    if (minDay && startOfDay(day).getTime() < minDay.getTime()) {
      const mark = markedDays?.get(toDayKey(day));
      if (!mark?.count) return;
    }
    hapticFeedback('light');
    onSelectDay(day);
  };

  return (
    <View style={styles.calendarShell}>
      <BlurView intensity={42} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(56,189,248,0.14)', 'rgba(8,20,38,0.55)', 'rgba(15,23,42,0.4)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={[...BOOKING_GLASS_TOP_SHEEN]}
        locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.85 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <View style={styles.calendarInner}>
        <View style={styles.monthHeader}>
          <TouchableOpacity onPress={() => handleShift(-1)} style={styles.monthNavBtn} activeOpacity={0.85}>
            <Ionicons name="chevron-back" size={20} color={SKY} />
          </TouchableOpacity>
          <View style={styles.monthTitleWrap}>
            <Text style={styles.monthKicker}>{monthKicker}</Text>
            <Text style={styles.monthTitle}>{monthLabel}</Text>
            {monthMeta ? <Text style={styles.monthMeta}>{monthMeta}</Text> : null}
          </View>
          <TouchableOpacity onPress={() => handleShift(1)} style={styles.monthNavBtn} activeOpacity={0.85}>
            <Ionicons name="chevron-forward" size={20} color={SKY} />
          </TouchableOpacity>
        </View>

        <View style={styles.weekdayRow}>
          {WEEKDAYS.map((wd) => (
            <View key={wd} style={[styles.weekdayCell, { width: cellSize }]}>
              <Text style={styles.weekdayText}>{wd}</Text>
            </View>
          ))}
        </View>

        <View style={[styles.grid, { gap: cellGap }]}>
          {monthCells.map((day, idx) => {
            if (!day) {
              return <View key={`empty-${idx}`} style={{ width: cellSize, height: cellSize }} />;
            }

            const key = toDayKey(day);
            const mark = markedDays?.get(key);
            const hasMark = (mark?.count ?? 0) > 0;
            const isToday = isSameDay(day, today);
            const isSelected = selectedDay != null && isSameDay(day, selectedDay);
            const isBeforeMin = minDay != null && startOfDay(day).getTime() < minDay.getTime();
            const isDisabled = isBeforeMin && !hasMark;
            const accent = mark?.accent ?? SKY;

            return (
              <Pressable
                key={key}
                onPress={() => handleDayPress(day)}
                disabled={isDisabled}
                style={[
                  styles.dayCell,
                  { width: cellSize, height: cellSize },
                  isDisabled && styles.dayCellDisabled,
                  hasMark && { borderColor: accent + '66' },
                  isToday && styles.dayCellToday,
                  isSelected && styles.dayCellSelected,
                ]}
              >
                {isSelected ? (
                  <LinearGradient
                    colors={[accent + '44', 'rgba(8,20,38,0.72)']}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                ) : null}
                <Text
                  style={[
                    styles.dayNumber,
                    isDisabled && styles.dayNumberDisabled,
                    isToday && styles.dayNumberToday,
                    isSelected && styles.dayNumberSelected,
                  ]}
                >
                  {day.getDate()}
                </Text>
                {hasMark ? (
                  <View style={styles.dayDotsRow}>
                    {Array.from({ length: Math.min(mark!.count, 3) }).map((_, i) => (
                      <View key={i} style={[styles.dayDot, { backgroundColor: accent }]} />
                    ))}
                  </View>
                ) : null}
                {isToday ? <View style={styles.todayRing} pointerEvents="none" /> : null}
              </Pressable>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  calendarShell: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(8,20,38,0.35)',
    shadowColor: 'rgba(56,189,248,0.25)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
    elevation: 6,
  },
  calendarInner: {
    padding: 14,
    gap: 12,
  },
  monthHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  monthNavBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
    backgroundColor: 'rgba(8,20,38,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  monthTitleWrap: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
  },
  monthKicker: {
    color: 'rgba(186,230,253,0.88)',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  monthTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  monthMeta: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 11,
    fontWeight: '600',
  },
  weekdayRow: {
    flexDirection: 'row',
    paddingHorizontal: 2,
    gap: 6,
  },
  weekdayCell: {
    alignItems: 'center',
  },
  weekdayText: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  dayCell: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(8,20,38,0.42)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    position: 'relative',
  },
  dayCellDisabled: {
    opacity: 0.35,
  },
  dayCellToday: {
    borderColor: 'rgba(125,211,252,0.55)',
  },
  dayCellSelected: {
    borderColor: SKY,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 4,
  },
  dayNumber: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  dayNumberDisabled: {
    color: 'rgba(148,163,184,0.5)',
  },
  dayNumberToday: {
    color: SKY,
  },
  dayNumberSelected: {
    color: '#F9FAFB',
  },
  dayDotsRow: {
    flexDirection: 'row',
    gap: 3,
    marginTop: 4,
  },
  dayDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
  },
  todayRing: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(125,211,252,0.45)',
  },
});
