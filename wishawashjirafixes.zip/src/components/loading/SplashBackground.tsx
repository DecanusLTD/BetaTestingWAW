import React from 'react';
import { StyleSheet } from 'react-native';
import Animated from 'react-native-reanimated';

type SplashBackgroundProps = {
  backgroundColor: string;
  opacity?: number;
};

export default function SplashBackground({ backgroundColor, opacity = 1 }: Readonly<SplashBackgroundProps>) {
  return (
    <Animated.View style={[StyleSheet.absoluteFillObject, { opacity, backgroundColor }]} />
  );
}
