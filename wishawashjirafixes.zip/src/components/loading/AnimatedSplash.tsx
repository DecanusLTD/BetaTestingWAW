import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, type ImageSourcePropType } from 'react-native';
import Animated, {
  Easing,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { colors } from '../../constants/colors';
import SplashBackground from './SplashBackground';
import SplashLogo from './SplashLogo';
import SplashRipple from './SplashRipple';

const LOGO_PULSE_STEP_MS = 520;
const RIPPLE_START_DELAY_MS = 420;
const RIPPLE_FADE_MS = 120;
const RIPPLE_EXPAND_MS = 620;
const OVERLAY_EXIT_DELAY_MS = 100;
const OVERLAY_EXIT_MS = 220;
const FALLBACK_STATE_DELAY_MS = 1200;

type AnimatedSplashProps = {
  startupReady: boolean;
  onFinish: () => void;
  logoSource: ImageSourcePropType;
  backgroundColor: string;
};

export default function AnimatedSplash({
  startupReady,
  onFinish,
  logoSource,
  backgroundColor,
}: Readonly<AnimatedSplashProps>) {
  const [showFallback, setShowFallback] = useState(false);
  const containerOpacity = useSharedValue(1);
  const logoScale = useSharedValue(1);
  const logoOpacity = useSharedValue(1);
  const rippleScale = useSharedValue(0.1);
  const rippleOpacity = useSharedValue(0);

  useEffect(() => {
    const fallbackTimer = setTimeout(() => {
      setShowFallback(true);
      // Secondary state: subtle pulse while waiting on startup.
      logoScale.value = withRepeat(
        withSequence(
          withTiming(1.03, { duration: LOGO_PULSE_STEP_MS, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.98, { duration: LOGO_PULSE_STEP_MS, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );
    }, FALLBACK_STATE_DELAY_MS);
    return () => clearTimeout(fallbackTimer);
  }, [logoScale]);

  useEffect(() => {
    if (!startupReady) return;
    setShowFallback(false);
    rippleOpacity.value = withDelay(RIPPLE_START_DELAY_MS, withTiming(1, { duration: RIPPLE_FADE_MS }));
    rippleScale.value = withDelay(
      RIPPLE_START_DELAY_MS,
      withTiming(14, { duration: RIPPLE_EXPAND_MS, easing: Easing.out(Easing.cubic) })
    );
    containerOpacity.value = withDelay(
      OVERLAY_EXIT_DELAY_MS,
      withTiming(0, { duration: OVERLAY_EXIT_MS }, (finished) => {
        if (finished) runOnJS(onFinish)();
      })
    );
  }, [containerOpacity, onFinish, rippleOpacity, rippleScale, startupReady]);

  const containerStyle = useAnimatedStyle(() => ({ opacity: containerOpacity.value }));
  return (
    <Animated.View style={[styles.root, containerStyle]} pointerEvents="auto">
      <SplashBackground backgroundColor={backgroundColor} />
      <SplashLogo source={logoSource} scale={logoScale} opacity={logoOpacity} />
      <SplashRipple scale={rippleScale} opacity={rippleOpacity} />

      {showFallback ? (
        <View style={styles.fallbackWrap}>
          <Text style={styles.fallbackText}>Preparing your experience</Text>
          <View style={styles.progressTrack}>
            <View style={[styles.progressLine, { width: startupReady ? '100%' : '62%' }, startupReady ? styles.progressReady : null]} />
          </View>
        </View>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallbackWrap: {
    position: 'absolute',
    bottom: 92,
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  fallbackText: {
    color: 'rgba(241,245,249,0.85)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  progressTrack: {
    width: 190,
    height: 3,
    borderRadius: 999,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  progressLine: {
    height: '100%',
    backgroundColor: 'rgba(241,245,249,0.8)',
  },
  progressReady: {
    backgroundColor: colors.SKY,
  },
});
