import React, { useMemo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, BOOKING_GLASS_TOP_SHEEN, BOOKING_GLASS_TOP_SHEEN_LOCATIONS } from '../../constants/bookingCardTheme';
import { CONTENT_PADDING_H } from '../../constants/pageStyles';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import GradientIconBox from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';

const SKY = colors.SKY;
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as const;

export type UpcomingCalendarBooking = {
  id: string;
  scheduledAt?: string | Date | null;
  serviceName?: string | null;
  service_type?: string | null;
  valeterName?: string | null;
  address?: string | null;
  status?: string;
};

function toDayKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function buildMonthGrid(year: number, month: number): (Date | null)[] {
  const lastDom = new Date(year, month + 1, 0).getDate();
  const startPad = (new Date(year, month, 1).getDay() + 6) % 7;
  const cells: (Date | null)[] = Array.from({ length: startPad }, () => null);
  for (let dom = 1; dom <= lastDom; dom += 1) {
    cells.push(new Date(year, month, dom));
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

function getServiceAccent(booking: UpcomingCalendarBooking): string {
  const t = (booking.service_type ?? booking.serviceName ?? '').toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

function getServiceIconName(accent: string): 'leaf' | 'sparkles' | 'water' {
  if (accent === ECO_GREEN) return 'leaf';
  if (accent === DETAILING_YELLOW) return 'sparkles';
  return 'water';
}

function formatTime(dateLike: Date | string | null | undefined): string {
  if (!dateLike) return '—';
  return new Date(dateLike).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

type Props = {
  bookings: UpcomingCalendarBooking[];
  onOpenBooking: (booking: UpcomingCalendarBooking) => void;
  onStartJourney: (booking: UpcomingCalendarBooking) => void;
};

export default function UpcomingBookingsCalendar({ bookings, onOpenBooking, onStartJourney }: Props) {
  const { width } = useWindowDimensions();
  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const initialMonth = useMemo(() => {
    if (bookings.length > 0 && bookings[0].scheduledAt) {
      const d = new Date(bookings[0].scheduledAt);
      return new Date(d.getFullYear(), d.getMonth(), 1);
    }
    return new Date(today.getFullYear(), today.getMonth(), 1);
  }, [bookings, today]);

  const [visibleMonth, setVisibleMonth] = useState(initialMonth);
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  const bookingsByDay = useMemo(() => {
    const map = new Map<string, UpcomingCalendarBooking[]>();
    for (const b of bookings) {
      if (!b.scheduledAt) continue;
      const key = toDayKey(new Date(b.scheduledAt));
      const list = map.get(key) ?? [];
      list.push(b);
      map.set(key, list);
    }
    for (const [, list] of map) {
      list.sort((a, b) => new Date(a.scheduledAt!).getTime() - new Date(b.scheduledAt!).getTime());
    }
    return map;
  }, [bookings]);

  const monthCells = useMemo(
    () => buildMonthGrid(visibleMonth.getFullYear(), visibleMonth.getMonth()),
    [visibleMonth]
  );

  const monthLabel = visibleMonth.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  const bookingCountThisMonth = useMemo(() => {
    let n = 0;
    for (const d of monthCells) {
      if (!d) continue;
      if (d.getMonth() !== visibleMonth.getMonth()) continue;
      n += bookingsByDay.get(toDayKey(d))?.length ?? 0;
    }
    return n;
  }, [monthCells, visibleMonth, bookingsByDay]);

  const selectedBookings = useMemo(() => {
    if (!selectedDay) return [];
    return bookingsByDay.get(toDayKey(selectedDay)) ?? [];
  }, [selectedDay, bookingsByDay]);

  const cellGap = 6;
  const calendarPad = 14;
  const innerWidth = width - CONTENT_PADDING_H * 2;
  const cellSize = Math.floor((innerWidth - calendarPad * 2 - cellGap * 6) / 7);

  const shiftMonth = useCallback((delta: number) => {
    hapticFeedback('light');
    setVisibleMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
    setSelectedDay(null);
  }, []);

  const handleSelectDay = useCallback(
    (day: Date) => {
      hapticFeedback('light');
      setSelectedDay((prev) => (prev && isSameDay(prev, day) ? null : day));
    },
    []
  );

  return (
    <View style={styles.root}>
      <View style={styles.calendarShell}>
        <BlurView intensity={42} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
        <LinearGradient
          colors={['rgba(56,189,248,0.14)', 'rgba(8,20,38,0.55)', 'rgba(15,23,42,0.4)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <LinearGradient
          colors={[...BOOKING_GLASS_TOP_SHEEN]}
          locations={[...BOOKING_GLASS_TOP_SHEEN_LOCATIONS]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0.85 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />

        <View style={styles.calendarInner}>
          <View style={styles.monthHeader}>
            <TouchableOpacity onPress={() => shiftMonth(-1)} style={styles.monthNavBtn} activeOpacity={0.85}>
              <Ionicons name="chevron-back" size={20} color={SKY} />
            </TouchableOpacity>
            <View style={styles.monthTitleWrap}>
              <Text style={styles.monthKicker}>UPCOMING</Text>
              <Text style={styles.monthTitle}>{monthLabel}</Text>
              <Text style={styles.monthMeta}>
                {bookingCountThisMonth > 0
                  ? `${bookingCountThisMonth} booking${bookingCountThisMonth === 1 ? '' : 's'} this month`
                  : 'No bookings this month'}
              </Text>
            </View>
            <TouchableOpacity onPress={() => shiftMonth(1)} style={styles.monthNavBtn} activeOpacity={0.85}>
              <Ionicons name="chevron-forward" size={20} color={SKY} />
            </TouchableOpacity>
          </View>

          <View style={styles.weekdayRow}>
            {WEEKDAYS.map((wd) => (
              <View key={wd} style={[styles.weekdayCell, { width: cellSize }]}>
                <Text style={styles.weekdayText}>{wd}</Text>
              </View>
            ))}
          </View>

          <View style={[styles.grid, { gap: cellGap }]}>
            {monthCells.map((day, idx) => {
              if (!day) {
                return <View key={`empty-${idx}`} style={{ width: cellSize, height: cellSize }} />;
              }

              const key = toDayKey(day);
              const dayBookings = bookingsByDay.get(key) ?? [];
              const hasBooking = dayBookings.length > 0;
              const isToday = isSameDay(day, today);
              const isSelected = selectedDay != null && isSameDay(day, selectedDay);
              const isPast = day.getTime() < today.getTime() && !isToday;
              const primaryAccent = hasBooking ? getServiceAccent(dayBookings[0]) : SKY;

              return (
                <Pressable
                  key={key}
                  onPress={() => handleSelectDay(day)}
                  style={[
                    styles.dayCell,
                    { width: cellSize, height: cellSize },
                    isPast && !hasBooking && styles.dayCellPast,
                    hasBooking && { borderColor: primaryAccent + '66' },
                    isToday && styles.dayCellToday,
                    isSelected && styles.dayCellSelected,
                  ]}
                >
                  {isSelected ? (
                    <LinearGradient
                      colors={[primaryAccent + '44', 'rgba(8,20,38,0.72)']}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                  ) : null}
                  <Text
                    style={[
                      styles.dayNumber,
                      isPast && !hasBooking && styles.dayNumberPast,
                      isToday && styles.dayNumberToday,
                      isSelected && styles.dayNumberSelected,
                    ]}
                  >
                    {day.getDate()}
                  </Text>
                  {hasBooking ? (
                    <View style={styles.dayDotsRow}>
                      {dayBookings.slice(0, 3).map((b) => (
                        <View
                          key={b.id}
                          style={[styles.dayDot, { backgroundColor: getServiceAccent(b) }]}
                        />
                      ))}
                    </View>
                  ) : null}
                  {isToday ? <View style={styles.todayRing} pointerEvents="none" /> : null}
                </Pressable>
              );
            })}
          </View>
        </View>
      </View>

      {selectedDay ? (
        <Animated.View entering={FadeInDown.duration(280)} style={styles.dayPanel}>
          <View style={styles.dayPanelHeader}>
            <Text style={styles.dayPanelTitle}>
              {selectedDay.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
            <TouchableOpacity onPress={() => setSelectedDay(null)} hitSlop={10}>
              <Ionicons name="close-circle" size={22} color="rgba(148,163,184,0.75)" />
            </TouchableOpacity>
          </View>

          {selectedBookings.length === 0 ? (
            <Text style={styles.dayPanelEmpty}>No bookings on this day</Text>
          ) : (
            selectedBookings.map((booking, index) => {
              const accent = getServiceAccent(booking);
              const displayName =
                getServiceDisplayName(booking.service_type, booking.serviceName) ??
                booking.serviceName ??
                'Car Wash';
              const startsAt = booking.scheduledAt ? new Date(booking.scheduledAt) : null;
              const diffMs = startsAt ? startsAt.getTime() - Date.now() : 0;
              const days = Math.max(0, Math.floor(diffMs / (24 * 60 * 60 * 1000)));
              const hours = Math.max(0, Math.floor((diffMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000)));
              const mins = Math.max(0, Math.floor((diffMs % (60 * 60 * 1000)) / (60 * 1000)));
              const countdown = days > 0 ? `${days}d ${hours}h` : `${hours}h ${mins}m`;

              return (
                <Animated.View key={booking.id} entering={FadeInDown.delay(index * 40)} style={styles.bookingCard}>
                  <View style={[styles.bookingAccent, { backgroundColor: accent }]} />
                  <View style={styles.bookingBody}>
                    <View style={styles.bookingTop}>
                      <GradientIconBox
                        icon={getServiceIconName(accent)}
                        colors={accentToGradient(accent)}
                        boxSize={40}
                        size={20}
                        elevated
                      />
                      <View style={styles.bookingMain}>
                        <Text style={styles.bookingService} numberOfLines={1}>
                          {displayName}
                        </Text>
                        <Text style={styles.bookingTime}>{formatTime(booking.scheduledAt)}</Text>
                        {booking.valeterName ? (
                          <Text style={styles.bookingMeta} numberOfLines={1}>
                            {booking.valeterName}
                          </Text>
                        ) : null}
                      </View>
                      <View style={styles.countdownPill}>
                        <Ionicons name="time-outline" size={11} color={SKY} />
                        <Text style={styles.countdownText}>{countdown}</Text>
                      </View>
                    </View>
                    <View style={styles.bookingActions}>
                      <TouchableOpacity
                        onPress={() => onStartJourney(booking)}
                        style={styles.startBtn}
                        activeOpacity={0.85}
                      >
                        <Ionicons name="navigate-outline" size={14} color={SKY} />
                        <Text style={styles.startBtnText}>Start journey</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => onOpenBooking(booking)}
                        style={styles.openBtn}
                        activeOpacity={0.85}
                      >
                        <Text style={styles.openBtnText}>Open</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </Animated.View>
              );
            })
          )}
        </Animated.View>
      ) : bookings.length === 0 ? (
        <View style={styles.hintRow}>
          <Ionicons name="sparkles-outline" size={16} color="rgba(125,211,252,0.7)" />
          <Text style={styles.hintText}>Your calendar is clear — book a wash when you&apos;re ready</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    gap: 14,
    marginBottom: 8,
  },
  calendarShell: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    backgroundColor: 'rgba(8,20,38,0.35)',
    shadowColor: 'rgba(56,189,248,0.25)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
    elevation: 6,
  },
  calendarInner: {
    padding: 14,
    gap: 12,
  },
  monthHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  monthNavBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
    backgroundColor: 'rgba(8,20,38,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  monthTitleWrap: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
  },
  monthKicker: {
    color: 'rgba(186,230,253,0.88)',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  monthTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  monthMeta: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 11,
    fontWeight: '600',
  },
  weekdayRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  weekdayCell: {
    alignItems: 'center',
  },
  weekdayText: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  dayCell: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.14)',
    backgroundColor: 'rgba(8,20,38,0.42)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    position: 'relative',
  },
  dayCellPast: {
    opacity: 0.45,
  },
  dayCellToday: {
    borderColor: 'rgba(125,211,252,0.55)',
  },
  dayCellSelected: {
    borderColor: SKY,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 4,
  },
  dayNumber: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  dayNumberPast: {
    color: 'rgba(148,163,184,0.65)',
  },
  dayNumberToday: {
    color: SKY,
  },
  dayNumberSelected: {
    color: '#F9FAFB',
  },
  dayDotsRow: {
    flexDirection: 'row',
    gap: 3,
    marginTop: 4,
  },
  dayDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
  },
  todayRing: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(125,211,252,0.45)',
  },
  dayPanel: {
    gap: 10,
  },
  dayPanelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  dayPanelTitle: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  dayPanelEmpty: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 13,
    fontWeight: '600',
    paddingVertical: 8,
  },
  bookingCard: {
    flexDirection: 'row',
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.65)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bookingAccent: {
    width: 4,
  },
  bookingBody: {
    flex: 1,
    padding: 14,
    gap: 10,
  },
  bookingTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  bookingMain: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  bookingService: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
  },
  bookingTime: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  bookingMeta: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 11,
    fontWeight: '600',
  },
  countdownPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.4)',
    backgroundColor: 'rgba(8,20,38,0.6)',
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  countdownText: {
    color: SKY,
    fontSize: 10,
    fontWeight: '800',
  },
  bookingActions: {
    flexDirection: 'row',
    gap: 8,
  },
  startBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.42)',
    backgroundColor: 'rgba(8,20,38,0.66)',
    paddingVertical: 9,
  },
  startBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '800',
  },
  openBtn: {
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.5)',
    paddingHorizontal: 14,
    paddingVertical: 9,
    justifyContent: 'center',
  },
  openBtnText: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '700',
  },
  hintRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 4,
    paddingVertical: 6,
  },
  hintText: {
    flex: 1,
    color: 'rgba(148,163,184,0.88)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  },
});
