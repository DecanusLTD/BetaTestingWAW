import React from 'react';
import { View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AnimatedProgress from '../booking/AnimatedProgress';
import { getReferralTierProgress } from '../../utils/referralTier';
import { passHero } from '../../constants/passFlowStyles';

type Props = {
  rewardedCount: number;
  totalCount: number;
  pendingCount: number;
  pointsEarned: number;
  loading?: boolean;
};

export default function ReferralPassportHero({
  rewardedCount,
  totalCount,
  pendingCount,
  pointsEarned,
  loading,
}: Props) {
  const tierInfo = getReferralTierProgress(rewardedCount);
  const nextLine = tierInfo.nextTier
    ? `${tierInfo.ownersToNext} more owner${tierInfo.ownersToNext === 1 ? '' : 's'} to ${tierInfo.nextTier.name}`
    : 'Top owner rank unlocked';

  return (
    <View style={[passHero.wrap, passHero.wrapAmber]}>
      <View style={passHero.content}>
        <View style={passHero.topRow}>
          <View style={passHero.tierLine}>
            <Ionicons
              name={tierInfo.tier.icon as keyof typeof Ionicons.glyphMap}
              size={13}
              color={tierInfo.tier.color}
            />
            <Text style={[passHero.tierText, { color: tierInfo.tier.color }]}>{tierInfo.tier.name}</Text>
          </View>
          <Text style={passHero.perk}>Owner rank</Text>
        </View>

        <View style={passHero.mainRow}>
          <View style={passHero.ringCol}>
            <AnimatedProgress
              progress={tierInfo.progress}
              size={88}
              strokeWidth={6}
              showPercentage
              percentageFontSize={15}
              color={tierInfo.tier.color}
              colorCycle={[tierInfo.tier.color, '#F59E0B', '#8B5CF6']}
            />
          </View>
          <View style={passHero.statsCol}>
            <Text style={passHero.headline}>{loading ? '—' : totalCount}</Text>
            <Text style={[passHero.headlineLabel, { color: '#F59E0B' }]}>Owners referred</Text>
            <Text style={passHero.metaLine}>
              +{loading ? '—' : pointsEarned} pts earned · {loading ? '—' : pendingCount} pending
            </Text>
            <Text style={[passHero.nextLine, { color: tierInfo.tier.color }]}>{nextLine}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
