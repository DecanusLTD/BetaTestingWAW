import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { passFlow } from '../../constants/passFlowStyles';

const STEPS = [
  { icon: 'share-social' as const, label: 'Share', sub: 'Invite car owners' },
  { icon: 'car' as const, label: 'They book', sub: 'First wash completed' },
  { icon: 'flash' as const, label: 'You earn', sub: '+5 pts each' },
];

export default function ReferralHowItWorksStrip() {
  return (
    <View style={passFlow.section}>
      <Text style={[passFlow.sectionTitle, styles.titlePad]}>How it works</Text>
      <View style={styles.flow}>
        {STEPS.map((step, index) => (
          <React.Fragment key={step.label}>
            {index > 0 ? (
              <Ionicons name="chevron-forward" size={11} color="rgba(148,163,184,0.35)" />
            ) : null}
            <View style={styles.step}>
              <Ionicons name={step.icon} size={14} color="#F59E0B" />
              <Text style={styles.stepLabel}>{step.label}</Text>
              <Text style={styles.stepSub}>{step.sub}</Text>
            </View>
          </React.Fragment>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  titlePad: {
    marginBottom: 12,
  },
  flow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    gap: 10,
  },
  step: {
    gap: 3,
    minWidth: 88,
    maxWidth: 110,
  },
  stepLabel: {
    color: '#F1F5F9',
    fontSize: 13,
    fontWeight: '700',
  },
  stepSub: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '500',
    lineHeight: 14,
  },
});
