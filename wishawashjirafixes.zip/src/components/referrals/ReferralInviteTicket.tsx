import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { REFERRAL_BONUS_POINTS } from '../../services/LoyaltyService';
import { passFlow } from '../../constants/passFlowStyles';

type Props = {
  referralCode: string;
  inviteLink: string;
  onCopy: () => void;
  onShare: () => void;
};

export default function ReferralInviteTicket({ referralCode, inviteLink, onCopy, onShare }: Props) {
  return (
    <View style={passFlow.section}>
      <View style={passFlow.sectionHead}>
        <Text style={passFlow.sectionTitle}>Your invite code</Text>
        <View style={styles.actions}>
          <TouchableOpacity onPress={onCopy} activeOpacity={0.7} hitSlop={8}>
            <Text style={styles.actionText}>Copy</Text>
          </TouchableOpacity>
          <Text style={styles.actionDot}>·</Text>
          <TouchableOpacity onPress={onShare} activeOpacity={0.7} hitSlop={8}>
            <Text style={[styles.actionText, styles.actionPrimary]}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>

      <Text style={styles.code}>{referralCode}</Text>
      <Text style={styles.link} numberOfLines={2}>
        {inviteLink}
      </Text>
      <Text style={styles.earnHint}>
        +{REFERRAL_BONUS_POINTS} pts per owner who completes their first wash
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  actionText: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 12,
    fontWeight: '700',
  },
  actionPrimary: {
    color: '#F59E0B',
  },
  actionDot: {
    color: 'rgba(148,163,184,0.45)',
    fontSize: 12,
  },
  code: {
    color: '#F8FAFC',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 2.5,
    marginBottom: 8,
  },
  link: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 17,
    marginBottom: 8,
  },
  earnHint: {
    color: 'rgba(148,163,184,0.75)',
    fontSize: 11,
    fontWeight: '600',
  },
});
