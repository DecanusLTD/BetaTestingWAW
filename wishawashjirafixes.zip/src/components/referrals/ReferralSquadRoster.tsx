import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatRelativeLoyaltyDate } from '../../utils/loyaltyTier';
import { passFlow } from '../../constants/passFlowStyles';
import { hapticFeedback } from '../../services/HapticFeedbackService';

export type ReferralRosterItem = {
  id: string;
  name: string;
  date: string;
  status: 'pending' | 'completed' | 'rewarded';
  rewardAmount: number;
};

type Props = {
  items: ReferralRosterItem[];
  loading?: boolean;
  onShare: () => void;
  initialExpanded?: boolean;
};

function statusLabel(status: ReferralRosterItem['status']): string {
  if (status === 'rewarded') return 'Rewarded';
  if (status === 'completed') return 'Booked';
  return 'Invited';
}

function statusAccent(status: ReferralRosterItem['status']): string {
  if (status === 'rewarded') return '#10B981';
  if (status === 'completed') return '#F59E0B';
  return '#94A3B8';
}

export default function ReferralSquadRoster({ items, loading, onShare, initialExpanded = false }: Props) {
  const [expanded, setExpanded] = useState(initialExpanded);
  const latest = items[0];

  const toggle = () => {
    void hapticFeedback('light');
    setExpanded((value) => !value);
  };

  return (
    <View style={passFlow.section}>
      <TouchableOpacity
        style={[passFlow.sectionHead, styles.sectionHead]}
        onPress={toggle}
        activeOpacity={0.75}
      >
        <View style={styles.headLeft}>
          <Text style={passFlow.sectionTitle}>Referred owners</Text>
          {!loading && items.length > 0 && !expanded ? (
            <Text style={styles.preview} numberOfLines={1}>
              {latest.name} · {statusLabel(latest.status)}
            </Text>
          ) : null}
        </View>
        <View style={styles.headRight}>
          {!loading ? <Text style={passFlow.sectionMeta}>{items.length}</Text> : null}
          <Ionicons
            name={expanded ? 'chevron-up' : 'chevron-down'}
            size={16}
            color="rgba(148,163,184,0.7)"
          />
        </View>
      </TouchableOpacity>

      {expanded ? (
        loading ? (
          <ActivityIndicator color="#F59E0B" style={{ marginVertical: 8 }} />
        ) : items.length === 0 ? (
          <View style={[passFlow.borderedList, passFlow.borderedListAmber, styles.empty]}>
            <Text style={styles.emptyTitle}>No owners yet</Text>
            <Text style={styles.emptySub}>Share your code with other car owners to climb the ranks.</Text>
            <TouchableOpacity style={styles.emptyCta} onPress={onShare} activeOpacity={0.82}>
              <Text style={styles.emptyCtaText}>Share invite</Text>
              <Ionicons name="arrow-forward" size={14} color="#F59E0B" />
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[passFlow.borderedList, passFlow.borderedListAmber]}>
            {items.map((item, index) => {
              const accent = statusAccent(item.status);
              return (
                <View
                  key={item.id}
                  style={[passFlow.flowRow, index === items.length - 1 && passFlow.flowRowLast]}
                >
                  <Ionicons name="car-outline" size={15} color={accent} style={styles.icon} />
                  <View style={styles.body}>
                    <Text style={styles.label} numberOfLines={1}>
                      {item.name}
                    </Text>
                    <Text style={styles.meta}>
                      {formatRelativeLoyaltyDate(item.date)} · {statusLabel(item.status)}
                    </Text>
                  </View>
                  {item.status === 'rewarded' ? (
                    <Text style={[styles.reward, { color: accent }]}>+{item.rewardAmount} pts</Text>
                  ) : (
                    <Text style={[styles.pending, { color: accent }]}>—</Text>
                  )}
                </View>
              );
            })}
          </View>
        )
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  sectionHead: {
    alignItems: 'center',
  },
  headLeft: {
    flex: 1,
    minWidth: 0,
    gap: 4,
  },
  headRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  preview: {
    color: 'rgba(148,163,184,0.8)',
    fontSize: 12,
    fontWeight: '500',
  },
  empty: {
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 4,
  },
  emptyTitle: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '700',
  },
  emptySub: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  emptyCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    marginTop: 4,
  },
  emptyCtaText: {
    color: '#F59E0B',
    fontSize: 14,
    fontWeight: '800',
  },
  icon: {
    width: 18,
    textAlign: 'center',
  },
  body: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  label: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '600',
  },
  meta: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    fontWeight: '500',
  },
  reward: {
    fontSize: 13,
    fontWeight: '800',
  },
  pending: {
    fontSize: 13,
    fontWeight: '600',
  },
});
