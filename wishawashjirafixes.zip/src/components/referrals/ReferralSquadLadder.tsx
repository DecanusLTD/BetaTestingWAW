import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { REFERRAL_TIERS, getReferralBadgeForCount, formatOwnerCount } from '../../utils/referralTier';
import { passFlow } from '../../constants/passFlowStyles';

type Props = {
  rewardedCount: number;
};

const NODE_W = 100;

export default function ReferralSquadLadder({ rewardedCount }: Props) {
  const unlockedCount = REFERRAL_TIERS.filter((tier) => rewardedCount >= tier.min).length;

  return (
    <View style={passFlow.section}>
      <View style={passFlow.sectionHead}>
        <Text style={passFlow.sectionTitle}>Owner ranks</Text>
        <Text style={passFlow.sectionMeta}>
          {unlockedCount}/{REFERRAL_TIERS.length} levels
        </Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.track}>
        {REFERRAL_TIERS.map((tier, index) => {
          const unlocked = rewardedCount >= tier.min;
          const isNext =
            !unlocked && (index === 0 || rewardedCount >= REFERRAL_TIERS[index - 1]!.min);
          const badge = tier.min > 0 ? getReferralBadgeForCount(tier.min) : undefined;
          const ownersToGo = Math.max(0, tier.min - rewardedCount);

          return (
            <View key={tier.name} style={styles.nodeWrap}>
              <View style={styles.railRow}>
                {index > 0 ? (
                  <View style={[styles.connector, unlocked && { backgroundColor: tier.color + '99' }]} />
                ) : (
                  <View style={styles.connectorSpacer} />
                )}
                <View
                  style={[
                    styles.dot,
                    unlocked && { borderColor: tier.color, backgroundColor: tier.color + '22' },
                    isNext && styles.dotNext,
                  ]}
                >
                  {unlocked ? (
                    <Ionicons name={tier.icon as keyof typeof Ionicons.glyphMap} size={15} color={tier.color} />
                  ) : (
                    <Ionicons name="lock-closed" size={12} color="rgba(148,163,184,0.55)" />
                  )}
                </View>
                {index < REFERRAL_TIERS.length - 1 ? (
                  <View
                    style={[
                      styles.connector,
                      rewardedCount >= REFERRAL_TIERS[index + 1]!.min && {
                        backgroundColor: REFERRAL_TIERS[index + 1]!.color + '99',
                      },
                    ]}
                  />
                ) : (
                  <View style={styles.connectorSpacer} />
                )}
              </View>

              <Text style={[styles.nodeTitle, !unlocked && styles.nodeTitleLocked]} numberOfLines={1}>
                {tier.name}
              </Text>
              <Text style={[styles.nodeSub, unlocked && { color: tier.color }]} numberOfLines={2}>
                {badge?.label ?? tier.subtitle}
              </Text>

              {unlocked ? (
                <Text style={[styles.status, { color: tier.color }]}>Unlocked</Text>
              ) : isNext ? (
                <Text style={styles.next}>
                  {ownersToGo} more owner{ownersToGo === 1 ? '' : 's'}
                </Text>
              ) : (
                <Text style={styles.locked}>{formatOwnerCount(tier.min)}</Text>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    paddingBottom: 4,
    paddingRight: 6,
  },
  nodeWrap: {
    width: NODE_W,
    alignItems: 'center',
    gap: 4,
  },
  railRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 8,
  },
  connector: {
    flex: 1,
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderRadius: 1,
  },
  connectorSpacer: {
    flex: 1,
  },
  dot: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  dotNext: {
    borderColor: 'rgba(245,158,11,0.65)',
    shadowColor: '#F59E0B',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  nodeTitle: {
    color: '#F1F5F9',
    fontSize: 11,
    fontWeight: '800',
    textAlign: 'center',
  },
  nodeTitleLocked: {
    color: 'rgba(203,213,225,0.55)',
  },
  nodeSub: {
    color: 'rgba(148,163,184,0.8)',
    fontSize: 9,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 12,
    minHeight: 24,
  },
  status: {
    fontSize: 9,
    fontWeight: '800',
    textAlign: 'center',
    marginTop: 2,
  },
  next: {
    color: '#F59E0B',
    fontSize: 9,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 2,
  },
  locked: {
    color: 'rgba(148,163,184,0.6)',
    fontSize: 9,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 2,
  },
});
