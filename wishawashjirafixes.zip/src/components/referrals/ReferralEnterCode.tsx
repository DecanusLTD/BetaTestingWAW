import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { passFlow } from '../../constants/passFlowStyles';

type Props = {
  entryCode: string;
  onChangeCode: (value: string) => void;
  hasApplied: boolean;
  applying: boolean;
  onApply: () => void;
  initialExpanded?: boolean;
};

export default function ReferralEnterCode({
  entryCode,
  onChangeCode,
  hasApplied,
  applying,
  onApply,
  initialExpanded = false,
}: Props) {
  const [expanded, setExpanded] = useState(initialExpanded);

  if (hasApplied) {
    return (
      <View style={[passFlow.section, styles.appliedWrap]}>
        <Ionicons name="checkmark-circle" size={16} color="#10B981" />
        <Text style={styles.appliedText}>Referral code applied</Text>
      </View>
    );
  }

  return (
    <View style={passFlow.section}>
      <TouchableOpacity
        style={styles.toggle}
        onPress={() => setExpanded((v) => !v)}
        activeOpacity={0.75}
      >
        <Text style={styles.toggleText}>Got another owner&apos;s code?</Text>
        <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color="rgba(148,163,184,0.7)" />
      </TouchableOpacity>

      {expanded ? (
        <View style={styles.panel}>
          <Text style={styles.hint}>£5 off your first booking as a vehicle owner.</Text>
          <View style={styles.row}>
            <TextInput
              style={styles.input}
              placeholder="WAW-XXXXXXXX"
              placeholderTextColor="rgba(255,255,255,0.35)"
              value={entryCode}
              onChangeText={(v) => onChangeCode(v.toUpperCase())}
              autoCapitalize="characters"
              autoCorrect={false}
              editable={!applying}
              accessibilityLabel="Owner referral code"
            />
            <TouchableOpacity
              style={[styles.applyBtn, applying && styles.applyBtnDisabled]}
              onPress={onApply}
              disabled={applying}
              activeOpacity={0.82}
            >
              {applying ? (
                <ActivityIndicator size="small" color="#F59E0B" />
              ) : (
                <Text style={styles.applyText}>Apply</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  toggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.14)',
  },
  toggleText: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 14,
    fontWeight: '600',
  },
  panel: {
    paddingTop: 14,
    gap: 10,
  },
  hint: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 17,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  input: {
    flex: 1,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(245,158,11,0.45)',
    paddingHorizontal: 0,
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  applyBtn: {
    paddingHorizontal: 4,
    paddingVertical: 8,
    minWidth: 56,
    alignItems: 'center',
    justifyContent: 'center',
  },
  applyBtnDisabled: {
    opacity: 0.6,
  },
  applyText: {
    color: '#F59E0B',
    fontSize: 14,
    fontWeight: '800',
  },
  appliedWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 4,
  },
  appliedText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '600',
  },
});
