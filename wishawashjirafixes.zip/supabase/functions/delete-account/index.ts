// @ts-nocheck
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.0';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Content-Type': 'application/json',
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: CORS_HEADERS,
  });
}

async function deleteStorageObjectsForUser(supabase: ReturnType<typeof createClient>, userId: string) {
  const folders = [userId, `users/${userId}`];
  const pathsToDelete = new Set<string>();

  for (const folder of folders) {
    const { data, error } = await supabase.storage.from('uploads').list(folder, { limit: 200 });
    if (error) continue;
    for (const file of data ?? []) {
      const name = String(file?.name || '');
      if (!name || name === '.emptyFolderPlaceholder') continue;
      pathsToDelete.add(`${folder}/${name}`);
    }
  }

  if (pathsToDelete.size > 0) {
    await supabase.storage.from('uploads').remove([...pathsToDelete]);
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return json({ ok: true });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      return json({ error: 'Missing Supabase environment variables' }, 500);
    }

    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return json({ error: 'Missing authorization token' }, 401);

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    const user = userData?.user;
    if (userError || !user) {
      return json({ error: 'Unauthorized' }, 401);
    }

    const userId = user.id;
    const deleteOps: Array<Promise<unknown>> = [];

    deleteOps.push(
      supabase.from('booking_messages').delete().eq('sender_id', userId),
      supabase.from('favourites').delete().eq('user_id', userId),
      supabase.from('hub_favourites').delete().eq('user_id', userId),
      supabase.from('user_devices').delete().eq('user_id', userId),
      supabase.from('customer_vehicles').delete().eq('user_id', userId),
      supabase.from('bookings').delete().eq('user_id', userId),
      supabase.from('profiles').delete().eq('id', userId),
    );

    await deleteStorageObjectsForUser(supabase, userId);

    const results = await Promise.all(deleteOps);
    const tableErrors = results
      .map((res: any, index) => ({ res, index }))
      .filter(({ res }) => res?.error)
      .map(({ res, index }) => ({
        index,
        error: res.error?.message || String(res.error),
      }));

    const { error: authDeleteError } = await supabase.auth.admin.deleteUser(userId);
    if (authDeleteError) {
      return json({
        error: authDeleteError.message,
        details: tableErrors,
      }, 500);
    }

    return json({
      ok: true,
      deleted: true,
      details: tableErrors,
    });
  } catch (e: any) {
    return json({ error: e?.message || String(e) }, 500);
  }
});
