// ChatMessage interface for chat service
interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
}

// Simple notification service mock
const notificationService = {
  sendChatNotification: async (message: ChatMessage) => {
    // Mock implementation - in real app this would send push notifications
  }
};

export interface ChatConversation {
  id: string;
  customerId: string;
  valeterId: string;
  customerName: string;
  valeterName: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  isActive: boolean;
}

export interface ChatMessageExtended extends ChatMessage {
  conversationId: string;
  messageType: 'text' | 'image' | 'location' | 'status';
  status?: 'sent' | 'delivered' | 'read';
}

class ChatService {
  private conversations: ChatConversation[] = [];
  private messages: Map<string, ChatMessageExtended[]> = new Map();
  private messageListeners: ((message: ChatMessageExtended) => void)[] = [];
  private conversationListeners: ((conversation: ChatConversation) => void)[] = [];

  // Initialize chat service
  initialize() {
    // Conversations and messages will be loaded from database when needed
    this.conversations = [];
    this.messages.clear();
  }

  // Get conversations for a user
  getConversations(userId: string): ChatConversation[] {
    return this.conversations.filter(conv => 
      conv.customerId === userId || conv.valeterId === userId
    );
  }

  // Get messages for a conversation
  getMessages(conversationId: string): ChatMessageExtended[] {
    return this.messages.get(conversationId) || [];
  }

  // Send a message
  async sendMessage(
    conversationId: string,
    senderId: string,
    senderName: string,
    message: string,
    messageType: 'text' | 'image' | 'location' | 'status' = 'text'
  ): Promise<ChatMessageExtended> {
    const newMessage: ChatMessageExtended = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId,
      senderName,
      message,
      timestamp: new Date(),
      isRead: false,
      messageType,
      status: 'sent',
    };

    // Add message to conversation
    const conversationMessages = this.messages.get(conversationId) || [];
    conversationMessages.push(newMessage);
    this.messages.set(conversationId, conversationMessages);

    // Update conversation
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (conversation) {
      conversation.lastMessage = message;
      conversation.lastMessageTime = new Date();
      conversation.unreadCount += 1;
    }

    // Notify listeners
    this.messageListeners.forEach(listener => listener(newMessage));
    this.conversationListeners.forEach(listener => {
      if (conversation) listener(conversation);
    });

    // Send push notification to recipient
    const recipientId = conversation?.customerId === senderId 
      ? conversation.valeterId 
      : conversation?.customerId;
    
    if (recipientId) {
      try {
        await notificationService.sendChatNotification({
          id: newMessage.id,
          senderId: newMessage.senderId,
          senderName: newMessage.senderName,
          message: newMessage.message,
          timestamp: newMessage.timestamp,
          isRead: newMessage.isRead,
        });
      } catch (error) {
        // Log notification errors but don't fail the message sending
      }
    }

    return newMessage;
  }

  // Mark messages as read
  markMessagesAsRead(conversationId: string, userId: string) {
    const messages = this.messages.get(conversationId);
    if (messages) {
      messages.forEach(msg => {
        if (msg.senderId !== userId) {
          msg.isRead = true;
          msg.status = 'read';
        }
      });
    }

    // Reset unread count
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (conversation) {
      conversation.unreadCount = 0;
    }
  }

  // Create a new conversation
  createConversation(
    customerId: string,
    valeterId: string,
    customerName: string,
    valeterName: string
  ): ChatConversation {
    const conversation: ChatConversation = {
      id: `conv_${Date.now()}`,
      customerId,
      valeterId,
      customerName,
      valeterName,
      lastMessage: '',
      lastMessageTime: new Date(),
      unreadCount: 0,
      isActive: true,
    };

    this.conversations.push(conversation);
    this.messages.set(conversation.id, []);

    return conversation;
  }

  // Get unread count for a user
  getUnreadCount(userId: string): number {
    return this.conversations
      .filter(conv => conv.customerId === userId || conv.valeterId === userId)
      .reduce((total, conv) => total + conv.unreadCount, 0);
  }

  // Add message listener
  addMessageListener(listener: (message: ChatMessageExtended) => void) {
    this.messageListeners.push(listener);
  }

  // Add conversation listener
  addConversationListener(listener: (conversation: ChatConversation) => void) {
    this.conversationListeners.push(listener);
  }

  // Remove listeners
  removeListeners() {
    this.messageListeners = [];
    this.conversationListeners = [];
  }

  // Simulate typing indicator
  simulateTyping(conversationId: string, senderId: string, isTyping: boolean) {
    // In a real app, this would send a typing indicator to the other user
  }

  // Get conversation by participants
  getConversationByParticipants(userId1: string, userId2: string): ChatConversation | null {
    return this.conversations.find(conv => 
      (conv.customerId === userId1 && conv.valeterId === userId2) ||
      (conv.customerId === userId2 && conv.valeterId === userId1)
    ) || null;
  }
}

// Export singleton instance
export const chatService = new ChatService();

export default chatService;

