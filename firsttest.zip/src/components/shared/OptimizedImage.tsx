import React, { useState, useEffect } from 'react';
import { Image, ImageProps, ActivityIndicator, View, StyleSheet } from 'react-native';
import { PerformanceService } from '../../services/PerformanceService';

interface OptimizedImageProps extends Omit<ImageProps, 'source'> {
  source: { uri: string } | number;
  maxWidth?: number;
  quality?: number;
  placeholder?: React.ReactNode;
  fallback?: React.ReactNode;
}

/**
 * Optimized image component with lazy loading, caching, and error handling
 */
export default function OptimizedImage({
  source,
  maxWidth = 800,
  quality = 0.8,
  placeholder,
  fallback,
  style,
  ...props
}: OptimizedImageProps) {
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    loadImage();
  }, [source]);

  const loadImage = async () => {
    try {
      setLoading(true);
      setError(false);

      // Handle local images (require statements)
      if (typeof source === 'number') {
        setImageUri(null); // Local images don't need optimization
        setLoading(false);
        return;
      }

      const uri = source.uri;
      if (!uri) {
        setError(true);
        setLoading(false);
        return;
      }

      // Optimize and cache image
      const optimizedUri = await PerformanceService.optimizeImage(uri, maxWidth, quality);
      setImageUri(optimizedUri);
      setLoading(false);
    } catch (err) {
      console.error('Error loading image:', err);
      setError(true);
      setLoading(false);
    }
  };

  if (error && fallback) {
    return <>{fallback}</>;
  }

  if (loading && placeholder) {
    return <>{placeholder}</>;
  }

  if (loading) {
    return (
      <View style={[styles.loadingContainer, style]}>
        <ActivityIndicator size="small" color="#87CEEB" />
      </View>
    );
  }

  return (
    <Image
      {...props}
      source={typeof source === 'number' ? source : { uri: imageUri || source.uri }}
      style={style}
      onError={() => {
        setError(true);
        setLoading(false);
      }}
      onLoadEnd={() => setLoading(false)}
    />
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
});

