import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { Image } from 'react-native';

/**
 * Performance optimization service for caching, image optimization, and offline support
 */
export class PerformanceService {
  private static CACHE_PREFIX = '@wishawash_cache_';
  private static IMAGE_CACHE_DIR = `${FileSystem.cacheDirectory}images/`;
  private static CACHE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

  /**
   * Initialize cache directory
   */
  static async initializeCache(): Promise<void> {
    try {
      const dirInfo = await FileSystem.getInfoAsync(this.IMAGE_CACHE_DIR);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(this.IMAGE_CACHE_DIR, { intermediates: true });
      }
    } catch (error) {
      console.error('Error initializing cache:', error);
    }
  }

  /**
   * Cache data with expiration
   */
  static async cacheData<T>(key: string, data: T, expiryMs: number = this.CACHE_EXPIRY_MS): Promise<void> {
    try {
      const cacheItem = {
        data,
        timestamp: Date.now(),
        expiry: Date.now() + expiryMs,
      };
      await AsyncStorage.setItem(
        `${this.CACHE_PREFIX}${key}`,
        JSON.stringify(cacheItem)
      );
    } catch (error) {
      console.error('Error caching data:', error);
    }
  }

  /**
   * Get cached data if not expired
   */
  static async getCachedData<T>(key: string): Promise<T | null> {
    try {
      const cached = await AsyncStorage.getItem(`${this.CACHE_PREFIX}${key}`);
      if (!cached) return null;

      const cacheItem = JSON.parse(cached);
      
      // Check if expired
      if (Date.now() > cacheItem.expiry) {
        await AsyncStorage.removeItem(`${this.CACHE_PREFIX}${key}`);
        return null;
      }

      return cacheItem.data as T;
    } catch (error) {
      console.error('Error getting cached data:', error);
      return null;
    }
  }

  /**
   * Clear expired cache entries
   */
  static async clearExpiredCache(): Promise<void> {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const cacheKeys = keys.filter(key => key.startsWith(this.CACHE_PREFIX));
      
      for (const key of cacheKeys) {
        const cached = await AsyncStorage.getItem(key);
        if (cached) {
          const cacheItem = JSON.parse(cached);
          if (Date.now() > cacheItem.expiry) {
            await AsyncStorage.removeItem(key);
          }
        }
      }
    } catch (error) {
      console.error('Error clearing expired cache:', error);
    }
  }

  /**
   * Clear all cache
   */
  static async clearAllCache(): Promise<void> {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const cacheKeys = keys.filter(key => key.startsWith(this.CACHE_PREFIX));
      await AsyncStorage.multiRemove(cacheKeys);
      
      // Clear image cache
      const dirInfo = await FileSystem.getInfoAsync(this.IMAGE_CACHE_DIR);
      if (dirInfo.exists) {
        await FileSystem.deleteAsync(this.IMAGE_CACHE_DIR, { idempotent: true });
        await this.initializeCache();
      }
    } catch (error) {
      console.error('Error clearing all cache:', error);
    }
  }

  /**
   * Optimize and cache image
   */
  static async optimizeImage(uri: string, maxWidth: number = 800, quality: number = 0.8): Promise<string> {
    try {
      // Check if already cached
      const cacheKey = this.getImageCacheKey(uri);
      const cachedUri = await this.getCachedImageUri(cacheKey);
      if (cachedUri) {
        return cachedUri;
      }

      // For React Native, we'll use the Image component's resize capabilities
      // In production, you might want to use a library like react-native-image-resizer
      const optimizedUri = uri; // Placeholder - actual optimization would happen here
      
      // Cache the optimized image
      await this.cacheImageUri(cacheKey, optimizedUri);
      
      return optimizedUri;
    } catch (error) {
      console.error('Error optimizing image:', error);
      return uri; // Return original if optimization fails
    }
  }

  /**
   * Preload images for better performance
   */
  static async preloadImages(uris: string[]): Promise<void> {
    try {
      await Promise.all(
        uris.map(uri => {
          return new Promise<void>((resolve) => {
            Image.prefetch(uri)
              .then(() => resolve())
              .catch(() => resolve()); // Continue even if one fails
          });
        })
      );
    } catch (error) {
      console.error('Error preloading images:', error);
    }
  }

  /**
   * Get image cache key from URI
   */
  private static getImageCacheKey(uri: string): string {
    // Create a hash-like key from the URI
    return uri.split('/').pop()?.split('?')[0] || uri;
  }

  /**
   * Cache image URI
   */
  private static async cacheImageUri(key: string, uri: string): Promise<void> {
    try {
      await this.cacheData(`image_${key}`, { uri, cachedAt: Date.now() });
    } catch (error) {
      console.error('Error caching image URI:', error);
    }
  }

  /**
   * Get cached image URI
   */
  private static async getCachedImageUri(key: string): Promise<string | null> {
    try {
      const cached = await this.getCachedData<{ uri: string; cachedAt: number }>(`image_${key}`);
      return cached?.uri || null;
    } catch (error) {
      console.error('Error getting cached image URI:', error);
      return null;
    }
  }

  /**
   * Check if device is online
   */
  static async isOnline(): Promise<boolean> {
    try {
      // In production, use NetInfo or similar
      return true; // Placeholder
    } catch (error) {
      return true; // Default to online
    }
  }

  /**
   * Get cache size
   */
  static async getCacheSize(): Promise<number> {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const cacheKeys = keys.filter(key => key.startsWith(this.CACHE_PREFIX));
      
      let totalSize = 0;
      for (const key of cacheKeys) {
        const value = await AsyncStorage.getItem(key);
        if (value) {
          totalSize += value.length;
        }
      }
      
      return totalSize;
    } catch (error) {
      console.error('Error getting cache size:', error);
      return 0;
    }
  }
}

