import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import GlassCard from '../src/components/booking/GlassCard';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function PrivacyPolicy() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Privacy Policy" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="shield-checkmark" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="information-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>1. Introduction</Text>
          </View>
          <Text style={styles.sectionText}>
            Welcome to Wish a Wash. We respect your privacy and are committed to protecting your personal data. This policy explains how we collect, use, and safeguard your information.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="document-text" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>2. Data We Collect</Text>
          </View>
          <Text style={styles.sectionText}>
            We collect information you provide directly to us, including:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Name, email, and phone number</Text>
            <Text style={styles.bulletPoint}>• Payment information (processed securely)</Text>
            <Text style={styles.bulletPoint}>• Vehicle details (via DVLA integration)</Text>
            <Text style={styles.bulletPoint}>• Location data (for service delivery)</Text>
            <Text style={styles.bulletPoint}>• Usage data and preferences</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="settings" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>3. How We Use Your Data</Text>
          </View>
          <Text style={styles.sectionText}>
            We use your data to:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Provide and improve our services</Text>
            <Text style={styles.bulletPoint}>• Process payments and bookings</Text>
            <Text style={styles.bulletPoint}>• Communicate with you about services</Text>
            <Text style={styles.bulletPoint}>• Send important updates and reminders</Text>
            <Text style={styles.bulletPoint}>• Ensure platform security and prevent fraud</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="lock-closed" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>4. Data Security</Text>
          </View>
          <Text style={styles.sectionText}>
            We implement appropriate technical and organisational measures to protect your personal data against unauthorised access, alteration, disclosure, or destruction. All data is encrypted in transit and at rest.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="person" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>5. Your Rights</Text>
          </View>
          <Text style={styles.sectionText}>
            Under UK GDPR, you have the right to:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Access your personal data</Text>
            <Text style={styles.bulletPoint}>• Rectify inaccurate information</Text>
            <Text style={styles.bulletPoint}>• Request erasure of your data</Text>
            <Text style={styles.bulletPoint}>• Restrict processing of your data</Text>
            <Text style={styles.bulletPoint}>• Data portability</Text>
            <Text style={styles.bulletPoint}>• Object to processing</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            To exercise these rights, contact us through the app or email support.
          </Text>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  bulletList: {
    marginTop: 12,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
});



