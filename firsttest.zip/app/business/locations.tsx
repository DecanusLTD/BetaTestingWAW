import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  created_at: string;
}

export default function BusinessLocations() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLocationName, setNewLocationName] = useState('');
  const [newLocationAddress, setNewLocationAddress] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadLocations();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadLocations = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude, status, created_at')
        .eq('organization_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLocations(data || []);
    } catch (error) {
      console.error('Error loading locations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddLocation = async () => {
    if (!newLocationName.trim() || !newLocationAddress.trim()) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (!user?.id) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      // For now, just UI - backend will handle geocoding
      const { error } = await supabase
        .from('car_wash_locations')
        .insert({
          name: newLocationName.trim(),
          address: newLocationAddress.trim(),
          organization_id: user.id,
          latitude: null,
          longitude: null,
          is_active: true,
          status: 'active',
        });

      if (error) throw error;

      setShowAddModal(false);
      setNewLocationName('');
      setNewLocationAddress('');
      await loadLocations();
      Alert.alert('Success', 'Location added successfully');
    } catch (error: any) {
      console.error('Error adding location:', error);
      Alert.alert('Error', error.message || 'Failed to add location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = async (locationId: string) => {
    Alert.alert(
      'Delete Location',
      'Are you sure you want to delete this location? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              const { error } = await supabase
                .from('car_wash_locations')
                .delete()
                .eq('id', locationId);

              if (error) throw error;
              await loadLocations();
              Alert.alert('Success', 'Location deleted');
            } catch (error: any) {
              console.error('Error deleting location:', error);
              Alert.alert('Error', error.message || 'Failed to delete location');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Locations" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading locations...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Locations"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setShowAddModal(true);
            }}
            style={styles.addButton}
          >
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
        scrollY={scrollY}
        enableScrollAnimation={true}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {locations.length === 0 ? (
          <Animated.View style={[styles.emptyContainer, { opacity: fadeAnim }]}>
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings at your business
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    setShowAddModal(true);
                  }}
                  style={styles.addFirstButton}
                >
                  <LinearGradient
                    colors={['#10B981', '#059669']}
                    style={styles.addFirstButtonGradient}
                  >
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addFirstButtonText}>Add Location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Animated.View>
        ) : (
          <View style={styles.locationsList}>
            {locations.map((location, index) => (
              <Animated.View
                key={location.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateY: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [30 + index * 10, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push(`/business/locations/${location.id}` as any);
                  }}
                  style={styles.locationCard}
                  accountType="business"
                >
                  <View style={styles.locationHeader}>
                    <View style={styles.locationIconWrapper}>
                      <Ionicons name="location" size={24} color={SKY} />
                    </View>
                    <View style={styles.locationInfo}>
                      <Text style={styles.locationName}>{location.name}</Text>
                      <Text style={styles.locationAddress} numberOfLines={2}>
                        {location.address || 'Address not set'}
                      </Text>
                    </View>
                    <TouchableOpacity
                      onPress={async (e) => {
                        e.stopPropagation();
                        await hapticFeedback('light');
                        handleDeleteLocation(location.id);
                      }}
                      style={styles.deleteButton}
                    >
                      <Ionicons name="trash-outline" size={20} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.locationFooter}>
                    <View style={styles.statusBadge}>
                      <View
                        style={[
                          styles.statusDot,
                          { backgroundColor: location.status === 'active' ? '#10B981' : '#6B7280' },
                        ]}
                      />
                      <Text style={styles.statusText}>
                        {location.status === 'active' ? 'Active' : 'Inactive'}
                      </Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={SKY} />
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </View>
        )}
      </Animated.ScrollView>

      {/* Add Location Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowAddModal(false)}
      >
        <View style={styles.modalOverlay}>
          <GlassCard style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add New Location</Text>
              <TouchableOpacity
                onPress={() => {
                  hapticFeedback('light');
                  setShowAddModal(false);
                }}
                style={styles.modalCloseButton}
              >
                <Ionicons name="close" size={24} color={SKY} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Location Name</Text>
                <GlassCard style={styles.inputContainer} accountType="business">
                  <TextInput
                    style={styles.textInput}
                    placeholder="e.g., Main Car Wash Hub"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    value={newLocationName}
                    onChangeText={setNewLocationName}
                    autoCapitalize="words"
                  />
                </GlassCard>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Address</Text>
                <GlassCard style={styles.inputContainer} accountType="business">
                  <TextInput
                    style={[styles.textInput, styles.textArea]}
                    placeholder="Enter full address"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    value={newLocationAddress}
                    onChangeText={setNewLocationAddress}
                    multiline
                    numberOfLines={3}
                    autoCapitalize="words"
                  />
                </GlassCard>
              </View>

              <TouchableOpacity
                onPress={handleAddLocation}
                style={styles.saveButton}
                disabled={saving}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.saveButtonGradient}
                >
                  {saving ? (
                    <ActivityIndicator size="small" color="#FFFFFF" />
                  ) : (
                    <>
                      <Ionicons name="checkmark" size={20} color="#FFFFFF" />
                      <Text style={styles.saveButtonText}>Add Location</Text>
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 400,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 32,
  },
  addFirstButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addFirstButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  locationsList: {
    gap: 16,
  },
  locationCard: {
    padding: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  locationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '700',
  },
  modalCloseButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBody: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  inputContainer: {
    padding: 0,
    overflow: 'hidden',
  },
  textInput: {
    color: '#F9FAFB',
    fontSize: 16,
    padding: 16,
    minHeight: 50,
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  saveButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  saveButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
