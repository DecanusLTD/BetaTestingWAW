import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function InviteValeter() {
    const { user } = useAuth();
  const [email, setEmail] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [role, setRole] = useState('valeter');
  const [sending, setSending] = useState(false);

  const roles = [
    { id: 'location_manager', label: 'Location Manager', icon: 'person' },
    { id: 'senior_valeter', label: 'Senior Valeter', icon: 'star' },
    { id: 'valeter', label: 'Valeter', icon: 'person-circle' },
    { id: 'staff', label: 'Staff', icon: 'people' },
  ];

  const handleSendInvite = async () => {
    if (!email.trim()) {
      Alert.alert('Error', 'Please enter an email address');
      return;
    }

    if (!user?.id) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }

    try {
      setSending(true);
      await hapticFeedback('medium');

      // TODO: Send actual invite via backend
      // For now, just UI placeholder

      Alert.alert('Invite Sent', `Invitation sent to ${email}`, [
        {
          text: 'OK',
          onPress: () => {
            setEmail('');
            setSelectedLocation(null);
            router.back();
          },
        },
      ]);
    } catch (error: any) {
      console.error('Error sending invite:', error);
      Alert.alert('Error', error.message || 'Failed to send invite');
    } finally {
      setSending(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader title="Invite Valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.description}>
          Invite a valeter to join your business team. They will receive an email invitation.
        </Text>

        {/* Email Input */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Email Address</Text>
          <GlassCard style={styles.inputCard}>
            <View style={styles.inputContainer}>
              <Ionicons name="mail" size={20} color={SKY} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="valeter@example.com"
                placeholderTextColor="rgba(249,250,251,0.5)"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </GlassCard>
        </View>

        {/* Role Selection */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Role</Text>
          <View style={styles.rolesGrid}>
            {roles.map((roleOption) => (
              <TouchableOpacity
                key={roleOption.id}
                onPress={async () => {
                  await hapticFeedback('light');
                  setRole(roleOption.id);
                }}
                style={styles.roleButton}
              >
                <GlassCard
                  style={[
                    styles.roleCard,
                    role === roleOption.id && styles.roleCardActive,
                  ]}
                  borderColor={
                    role === roleOption.id
                      ? 'rgba(135,206,235,0.5)'
                      : 'rgba(135,206,235,0.2)'
                  }
                >
                  <Ionicons
                    name={roleOption.icon as any}
                    size={24}
                    color={role === roleOption.id ? SKY : 'rgba(249,250,251,0.6)'}
                  />
                  <Text
                    style={[
                      styles.roleText,
                      role === roleOption.id && styles.roleTextActive,
                    ]}
                  >
                    {roleOption.label}
                  </Text>
                </GlassCard>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Location Selection Placeholder */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Location Assignment</Text>
          <GlassCard style={styles.infoCard}>
            <View style={styles.infoContent}>
              <Ionicons name="information-circle" size={20} color={SKY} />
              <Text style={styles.infoText}>
                Location assignment can be configured after the valeter accepts the invite.
              </Text>
            </View>
          </GlassCard>
        </View>

        {/* Send Button */}
        <TouchableOpacity
          onPress={handleSendInvite}
          style={styles.sendButton}
          disabled={sending}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={['#10B981', '#059669']}
            style={styles.sendButtonGradient}
          >
            {sending ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <Ionicons name="send" size={20} color="#FFFFFF" />
                <Text style={styles.sendButtonText}>Send Invitation</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  description: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 32,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  inputCard: {
    padding: 0,
    overflow: 'hidden',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  inputIcon: {
    marginRight: 12,
  },
  textInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
  },
  rolesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  roleButton: {
    flex: 1,
    minWidth: '47%',
  },
  roleCard: {
    padding: 16,
    alignItems: 'center',
    gap: 8,
  },
  roleCardActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  roleText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  roleTextActive: {
    color: SKY,
    fontWeight: '700',
  },
  infoCard: {
    padding: 16,
  },
  infoContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  infoText: {
    flex: 1,
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  sendButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 16,
  },
  sendButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 18,
    paddingHorizontal: 32,
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
