import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Modal,
  TextInput,
  FlatList,
  Linking,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

const BG = colors.BG;
const ACCENT = colors.ECO_GREEN;
const SKY = colors.SKY;

export default function HelpSupport() {
  const { user } = useAuth();
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{id: string, message: string, isUser: boolean, timestamp: Date, type?: 'ai' | 'human' | 'system'}>>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<string>('');
  const [issueDescription, setIssueDescription] = useState('');

  const isValeter = user?.userType === 'valeter';

  // Comprehensive FAQ with smart responses
  const faqs = [
    {
      id: '1',
      question: 'How do I book a car wash service?',
      answer: '📅 **Booking Process:**\n\n1. Tap "Book Now" or "Instant Wash" on your dashboard\n2. Choose between "On-Demand" (valeter comes to you) or "Location" (physical car wash)\n3. Select your vehicle type (or add one if needed)\n4. Choose service type (Basic Wash, Premium Wash, Full Valet)\n5. Set your location (current GPS or custom address)\n6. Select preferred time (on-demand or scheduled)\n7. Review summary and confirm payment\n\n⏱️ A valeter will be assigned within 5-10 minutes for on-demand bookings.\n\n💡 **Tip:** Save your vehicle details for faster booking next time!',
      category: 'booking'
    },
    {
      id: '2',
      question: 'What is the cancellation policy?',
      answer: '💰 **Cancellation & Refund Policy:**\n\n**On-Demand Bookings:**\n• Within 5 minutes: 100% refund\n• Within 15 minutes: 90% refund\n• Within 30 minutes: 75% refund\n• Within 1 hour: 50% refund\n• Within 2 hours: 25% refund\n• After 2 hours: No refund\n\n**Scheduled Bookings:**\n• Cancel 24+ hours before: Full refund\n• Cancel 12-24 hours before: 75% refund\n• Cancel 6-12 hours before: 50% refund\n• Cancel less than 6 hours: No refund\n\n**Processing:** Refunds are processed within 24-48 hours to your original payment method.\n\n📞 **Need help?** Contact us via WhatsApp: +44 7960 944743',
      category: 'refunds'
    },
    {
      id: '3',
      question: 'How do I track my valeter?',
      answer: '📍 **Real-Time Tracking:**\n\nOnce a valeter accepts your job:\n• View their live location on the map\n• See estimated arrival time (ETA)\n• Track their route in real-time\n• Updates every 30 seconds\n• Chat directly with your valeter\n\n**Features:**\n• Get notified when valeter is en route\n• Receive arrival notifications\n• View valeter profile and ratings\n• Track service progress\n\n**If tracking isn\'t working:**\n1. Refresh the app\n2. Check your internet connection\n3. Ensure location permissions are enabled\n\n📞 **Issues?** Contact support: +44 7960 944743',
      category: 'tracking'
    },
    {
      id: '4',
      question: 'What payment methods are accepted?',
      answer: '💳 **Payment Methods:**\n\n**Accepted:**\n• Visa, Mastercard, American Express\n• Debit cards (all major banks)\n• PayPal\n• Apple Pay\n• Google Pay\n\n**Security:**\n• All payments processed via Stripe\n• 256-bit SSL encryption\n• Your card details are never stored\n• PCI DSS compliant\n• Secure tokenization\n\n**Payment Process:**\n• Payment is required before service\n• Charged when valeter accepts job\n• Refunds processed to original method\n• Receipts sent via email\n\n🔒 **Your payment information is completely secure!**',
      category: 'payments'
    },
    {
      id: '5',
      question: 'How do I become a valeter?',
      answer: '🚗 **Become a Valeter:**\n\n**Requirements:**\n• Valid UK driving license\n• Valid car insurance\n• DBS check (we can help arrange)\n• Vehicle in good condition\n• Smartphone with GPS\n\n**Application Process:**\n1. Download app and select "Join as Valeter"\n2. Complete profile information\n3. Upload required documents:\n   - Driving license\n   - Insurance certificate\n   - DBS check (if applicable)\n   - Vehicle registration\n4. Background check (5-7 business days)\n5. Vehicle inspection (if required)\n6. Account verification\n\n**Timeline:** Verification typically takes 3-5 business days.\n\n💰 **Earnings:** Set your own schedule, competitive rates, weekly payments.\n\n📞 **Questions?** WhatsApp: +44 7960 944743',
      category: 'valeter'
    },
    {
      id: '6',
      question: 'What if I\'m not satisfied with the service?',
      answer: '⭐ **Service Quality Guarantee:**\n\n**If you\'re not satisfied:**\n1. Contact us within 24 hours of service\n2. Include photos if applicable\n3. Provide booking ID and details\n4. Describe the issue clearly\n\n**We may offer:**\n• Full or partial refund\n• Free re-service with different valeter\n• Account credit\n• Discount on next booking\n\n**Resolution Timeline:**\n• Response within 2 hours\n• Investigation within 24 hours\n• Resolution within 48 hours\n\n**Your satisfaction is our priority!**\n\n📞 **Contact us:** WhatsApp: +44 7960 944743',
      category: 'quality'
    },
    {
      id: '7',
      question: 'How do rewards and points work?',
      answer: '🎁 **Rewards & Loyalty Program:**\n\n**Earn Points:**\n• 10 points per £1 spent on bookings\n• 5 points for rating valeters\n• 50 points per friend referral\n• Bonus points during promotions\n\n**Tier Levels:**\n• **Bronze:** 0-500 points (5% discount)\n• **Silver:** 501-1,500 points (10% discount)\n• **Gold:** 1,501-3,000 points (15% discount)\n• **Platinum:** 3,000+ points (20% discount + exclusive perks)\n\n**Redeem For:**\n• Discounts on services\n• Free washes\n• Exclusive rewards\n• Priority booking\n• Special promotions\n\n**Check your tier:** Profile → Rewards section\n\n💡 **Tip:** Refer friends to earn bonus points!',
      category: 'rewards'
    },
    {
      id: '8',
      question: 'Is my data secure?',
      answer: '🔒 **Data Security & Privacy:**\n\n**Security Measures:**\n• 256-bit SSL encryption\n• Secure payment processing (Stripe)\n• PCI DSS compliant\n• Regular security audits\n• Two-factor authentication available\n\n**Privacy:**\n• GDPR compliant\n• We never share your data with third parties\n• Your location is only shared with assigned valeter\n• You control your privacy settings\n• Data deletion available on request\n\n**What We Store:**\n• Account information (name, email, phone)\n• Booking history\n• Payment methods (encrypted tokens only)\n• Vehicle information\n\n**Your Rights:**\n• Access your data anytime\n• Request data deletion\n• Update preferences\n• Opt-out of marketing\n\n🔐 **Your privacy and security are our top priorities!**',
      category: 'security'
    },
    {
      id: '9',
      question: 'How do I report an issue?',
      answer: '⚠️ **Reporting Issues:**\n\n**How to Report:**\n1. Go to Help & Support\n2. Tap "Report an Issue"\n3. Select issue type\n4. Provide details:\n   - Booking ID (if applicable)\n   - Description of issue\n   - Photos (if relevant)\n   - Preferred contact method\n\n**Response Times:**\n• Urgent issues: Within 1 hour\n• General issues: Within 2 hours\n• Non-urgent: Within 24 hours\n\n**Resolution:**\n• Investigation within 24 hours\n• Resolution within 48 hours\n• Follow-up to ensure satisfaction\n\n**Alternative Contact:**\n• WhatsApp: +44 7960 944743 (24/7)\n• Email: support@wishawash.com\n• Emergency: +44 7960 944743\n\n📞 **We\'re here to help!**',
      category: 'support'
    },
    {
      id: '10',
      question: 'What are the service areas?',
      answer: '🗺️ **Service Coverage:**\n\n**Current Service Areas:**\n• London (Greater London)\n• Manchester\n• Birmingham\n• Leeds\n• Liverpool\n• Surrounding areas\n\n**How to Check:**\n• Enter your postcode in the app\n• View available valeters in your area\n• See estimated wait times\n• Check service availability\n\n**Expanding:**\nWe\'re constantly expanding to new areas. Check the app regularly for updates!\n\n**Physical Locations:**\nWe also have physical car wash locations. Check the map for nearest locations.\n\n**Not in Coverage?**\n• Join our waitlist\n• Get notified when we launch in your area\n• Refer friends to speed up expansion\n\n📞 **Questions?** WhatsApp: +44 7960 944743',
      category: 'coverage'
    },
    {
      id: '11',
      question: 'How do I change my booking?',
      answer: '✏️ **Modifying Bookings:**\n\n**What You Can Change:**\n• Service type (upgrade/downgrade)\n• Location (before valeter accepts)\n• Time (if scheduled)\n• Vehicle (if multiple saved)\n\n**Time Limits:**\n• On-demand: Can change before valeter accepts\n• Scheduled: Modify up to 1 hour before\n• After valeter accepts: Contact support\n\n**How to Modify:**\n1. Go to Active Bookings\n2. Select booking to modify\n3. Tap "Edit Booking"\n4. Make changes\n5. Confirm updates\n\n**Cancellations:**\nFollow our refund policy (see Cancellation Policy FAQ)\n\n**Urgent Changes:**\nContact support immediately:\n• WhatsApp: +44 7960 944743\n• Emergency: +44 7960 944743\n\n📞 **We\'ll help you make changes quickly!**',
      category: 'booking'
    },
    {
      id: '12',
      question: 'What if my valeter doesn\'t show up?',
      answer: '🚨 **Valeter No-Show Policy:**\n\n**If valeter doesn\'t arrive:**\n• Wait 15 minutes past scheduled time\n• Contact us immediately\n• We\'ll find you another valeter\n• Or provide full refund + compensation\n\n**What We Do:**\n• Immediately assign new valeter\n• Priority booking for you\n• Full refund if no replacement\n• Compensation for inconvenience\n• Investigation with valeter\n\n**Compensation:**\n• Account credit\n• Discount on next booking\n• Free service upgrade\n\n**Response Time:**\n• Within 5 minutes of contact\n• New valeter assigned within 15 minutes\n• Full resolution within 1 hour\n\n**Emergency Contact:**\n• WhatsApp: +44 7960 944743 (24/7)\n• Emergency: +44 7960 944743\n\n📞 **We\'ll resolve this immediately!**',
      category: 'service'
    },
    {
      id: '13',
      question: 'How do I update my profile?',
      answer: '👤 **Updating Your Profile:**\n\n**What You Can Update:**\n• Name and contact information\n• Email address\n• Phone number\n• Profile picture\n• Vehicle information\n• Payment methods\n• Notification preferences\n\n**How to Update:**\n1. Go to Profile section\n2. Tap "Edit Profile"\n3. Make your changes\n4. Save updates\n\n**For Valeters:**\n• Update documents\n• Change availability\n• Update vehicle info\n• Modify service areas\n\n**Profile Settings:**\n• Privacy settings\n• Notification preferences\n• Account security\n• Linked accounts\n\n📞 **Need help?** Contact support: +44 7960 944743',
      category: 'account'
    },
    {
      id: '14',
      question: 'How do I contact support?',
      answer: '📞 **Contact Support:**\n\n**24/7 Support Available:**\n\n**WhatsApp (Recommended):**\n• +44 7960 944743\n• Fastest response time\n• Available 24/7\n• Send photos/videos\n\n**Phone:**\n• +44 7960 944743\n• Available 24/7\n• For urgent issues\n\n**Email:**\n• support@wishawash.com\n• General inquiries\n• Response within 24 hours\n\n**In-App:**\n• Help & Support section\n• AI Assistant (24/7)\n• Live Chat via WhatsApp\n• Report an Issue\n\n**Response Times:**\n• WhatsApp: Within minutes\n• Phone: Immediate\n• Email: Within 24 hours\n\n💬 **We\'re here to help 24/7!**',
      category: 'support'
    }
  ];

  const contactOptions = [
    {
      id: '1',
      title: 'Customer Support',
      subtitle: 'General inquiries and account help',
      icon: 'call',
      action: () => handleCallSupport(),
      phone: '+44 7960 944743',
      email: 'support@wishawash.com',
      whatsapp: '+447960944743'
    },
    {
      id: '2',
      title: 'Technical Support',
      subtitle: 'App issues and technical problems',
      icon: 'construct',
      action: () => handleTechnicalSupport(),
      phone: '+44 7960 944743',
      email: 'tech@wishawash.com',
      whatsapp: '+447960944743'
    },
    {
      id: '3',
      title: 'Emergency Contact',
      subtitle: 'Urgent issues during service',
      icon: 'warning',
      action: () => handleEmergencyContact(),
      phone: '+44 7960 944743',
      email: 'emergency@wishawash.com',
      whatsapp: '+447960944743'
    },
    {
      id: '4',
      title: 'Feedback & Suggestions',
      subtitle: 'Help us improve our service',
      icon: 'chatbubble',
      action: () => handleFeedback(),
      phone: null,
      email: 'feedback@wishawash.com'
    },
  ];

  const quickActions = [
    {
      id: '1',
      title: 'Report an Issue',
      subtitle: 'Report service problems',
      icon: 'warning',
      action: () => handleReportIssue(),
    },
    {
      id: '2',
      title: 'Request Refund',
      subtitle: 'Cancel and get refund',
      icon: 'cash',
      action: () => handleRequestRefund(),
    },
    {
      id: '3',
      title: 'Update Profile',
      subtitle: 'Change account details',
      icon: 'person',
      action: () => {
        if (isValeter) {
          router.push('/valeter/profile/valeter-profile');
        } else {
          router.push('/owner/owner-profile');
        }
      },
    },
    {
      id: '4',
      title: 'Privacy Settings',
      subtitle: 'Manage data preferences',
      icon: 'lock-closed',
      action: () => handlePrivacySettings(),
    },
  ];

  const handleCallSupport = async () => {
    try {
      await hapticFeedback('light');
      const whatsappNumber = '+447960944743';
      const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`;
      
      Alert.alert(
        'Contact Customer Support',
        'Get help with your account, bookings, or general inquiries. Available 24/7 via WhatsApp.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'WhatsApp (Recommended)', 
            onPress: async () => {
              const canOpen = await Linking.canOpenURL(whatsappUrl);
              if (canOpen) {
                await Linking.openURL(whatsappUrl);
              } else {
                Alert.alert('WhatsApp Not Available', 'Please install WhatsApp or call us at +44 7960 944743');
              }
            }
          },
          { 
            text: 'Call Now', 
            onPress: () => Linking.openURL(`tel:${whatsappNumber}`)
          },
          { 
            text: 'Send Email', 
            onPress: () => Linking.openURL('mailto:support@wishawash.com?subject=Customer Support Request')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleCallSupport:', error);
      Alert.alert('Error', 'Unable to open contact options. Please call +44 7960 944743');
    }
  };

  const handleTechnicalSupport = async () => {
    try {
      await hapticFeedback('light');
      const whatsappNumber = '+447960944743';
      const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`;
      
      Alert.alert(
        'Technical Support',
        'Having app issues? We can help with technical problems, bugs, or account access issues.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'WhatsApp Support', 
            onPress: async () => {
              const canOpen = await Linking.canOpenURL(whatsappUrl);
              if (canOpen) {
                await Linking.openURL(whatsappUrl);
              } else {
                Alert.alert('WhatsApp Not Available', 'Please install WhatsApp or call us at +44 7960 944743');
              }
            }
          },
          { 
            text: 'AI Assistant', 
            onPress: () => handleAIChat()
          },
          { 
            text: 'Call Support', 
            onPress: () => Linking.openURL(`tel:${whatsappNumber}`)
          },
          { 
            text: 'Email Tech Team', 
            onPress: () => Linking.openURL('mailto:tech@wishawash.com?subject=Technical Issue Report')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleTechnicalSupport:', error);
      Alert.alert('Error', 'Unable to open contact options. Please call +44 7960 944743');
    }
  };

  const handleEmergencyContact = async () => {
    try {
      await hapticFeedback('medium');
      const whatsappNumber = '+447960944743';
      const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`;
      
      Alert.alert(
        'Emergency Contact',
        'For urgent issues during active service. Available 24/7 for immediate assistance.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'WhatsApp (Fastest)', 
            onPress: async () => {
              const canOpen = await Linking.canOpenURL(whatsappUrl);
              if (canOpen) {
                await Linking.openURL(whatsappUrl);
              } else {
                Linking.openURL(`tel:${whatsappNumber}`);
              }
            },
            style: 'destructive'
          },
          { 
            text: 'Emergency Hotline', 
            onPress: () => Linking.openURL(`tel:${whatsappNumber}`),
            style: 'destructive'
          },
          { 
            text: 'Emergency Email', 
            onPress: () => Linking.openURL('mailto:emergency@wishawash.com?subject=URGENT: Service Issue')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleEmergencyContact:', error);
      Alert.alert('Emergency', 'Please call +44 7960 944743 immediately for urgent assistance');
    }
  };

  const handleFeedback = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Feedback & Suggestions',
        'We\'d love to hear from you! Share your thoughts, suggestions, or ideas to help us improve.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'WhatsApp (Quick)', 
            onPress: async () => {
              const whatsappNumber = '+447960944743';
              const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`;
              const canOpen = await Linking.canOpenURL(whatsappUrl);
              if (canOpen) {
                await Linking.openURL(whatsappUrl);
              } else {
                Alert.alert('WhatsApp Not Available', 'Please install WhatsApp or email us at feedback@wishawash.com');
              }
            }
          },
          { 
            text: 'Send Email', 
            onPress: () => Linking.openURL('mailto:feedback@wishawash.com?subject=App Feedback')
          },
          { 
            text: 'Rate App', 
            onPress: () => Linking.openURL('https://apps.apple.com/app/wish-a-wash')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleFeedback:', error);
    }
  };

  const handleReportIssue = async () => {
    try {
      await hapticFeedback('light');
      router.push('/owner/support/report-issue');
    } catch (error) {
      console.error('Error in handleReportIssue:', error);
    }
  };

  const handleRequestRefund = async () => {
    try {
      await hapticFeedback('light');
      router.push('/owner/support/request-refund');
    } catch (error) {
      console.error('Error in handleRequestRefund:', error);
    }
  };

  const handlePrivacySettings = async () => {
    try {
      await hapticFeedback('light');
      router.push('/owner/settings/privacy-settings');
    } catch (error) {
      console.error('Error in handlePrivacySettings:', error);
    }
  };

  const toggleFAQ = async (id: string) => {
    try {
      await hapticFeedback('light');
      setExpandedFAQ(expandedFAQ === id ? null : id);
    } catch (error) {
      console.error('Error in toggleFAQ:', error);
    }
  };

  const handleWebChat = async () => {
    try {
      await hapticFeedback('medium');
      const whatsappNumber = '+447960944743';
      const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}`;
      
      const canOpen = await Linking.canOpenURL(whatsappUrl);
      if (canOpen) {
        await Linking.openURL(whatsappUrl);
      } else {
        Alert.alert(
          'WhatsApp Not Available',
          'Please install WhatsApp to contact support, or call us at +44 7960 944743',
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Call Instead', 
              onPress: () => Linking.openURL(`tel:${whatsappNumber}`)
            }
          ]
        );
      }
    } catch (error) {
      console.error('Error in handleWebChat:', error);
      Alert.alert('Error', 'Unable to open WhatsApp. Please call us at +44 7960 944743');
    }
  };

  const handleAIChat = async () => {
    try {
      await hapticFeedback('medium');
      setShowAIChat(true);
      setChatMessage('');
      
      const welcomeMessage = isValeter 
        ? 'Hi! I\'m your Wish a Wash AI Assistant. I can help you with:\n\n• Going online and availability\n• Payment and earnings questions\n• Document uploads and verification\n• Job assignments and troubleshooting\n• Account settings and profile\n\nWhat can I help you with today?'
        : 'Hi! I\'m your Wish a Wash AI Assistant. I can help you with:\n\n• Booking services and scheduling\n• Payment methods and charges\n• Tracking your valeter\n• Refunds and cancellations\n• Rewards and points\n• Account settings\n\nWhat would you like to know?';
      
      setChatHistory([{
        id: '1',
        message: welcomeMessage,
        isUser: false,
        timestamp: new Date(),
        type: 'ai'
      }]);
    } catch (error) {
      console.error('Error in handleAIChat:', error);
    }
  };

  const sendMessage = async () => {
    if (!chatMessage.trim()) return;

    try {
      const userMessage = {
        id: Date.now().toString(),
        message: chatMessage,
        isUser: true,
        timestamp: new Date()
      };

      setChatHistory(prev => [...prev, userMessage]);
      setChatMessage('');
      setIsTyping(true);

      // AI response logic with intelligent escalation
      setTimeout(() => {
        const userMessageLower = chatMessage.toLowerCase();
        let aiResponse = '';
        let shouldEscalate = false;

        // Check if AI can handle the issue based on user type
        if (isValeter) {
          // Valeter-specific responses
          if (userMessageLower.includes('online') || userMessageLower.includes('go online') || userMessageLower.includes('available')) {
            aiResponse = '🟢 **Going Online:**\n\n1. Ensure all documents are uploaded and verified\n2. Check Documents section for any pending items\n3. Enable location services in your phone settings\n4. Tap "Go Online" in the app\n\nIf you\'re still having issues, check:\n• Document verification status\n• Location permissions\n• App is updated to latest version\n\nNeed help? Contact support via WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('payment') || userMessageLower.includes('not received') || userMessageLower.includes('earnings') || userMessageLower.includes('money')) {
            aiResponse = '💰 **Payment Information:**\n\n• Payments are processed weekly on Fridays\n• Funds take 2-3 business days to reach your account\n• Check your bank details in Profile → Payment Settings\n• If payment is overdue, contact support via WhatsApp: +44 7960 944743\n\nI can help you check your payment history or update your bank details.';
          } else if (userMessageLower.includes('document') || userMessageLower.includes('upload')) {
            aiResponse = '📄 **Document Upload:**\n\n1. Go to Profile → Documents section\n2. Select document type to upload\n3. Take clear photos or upload files\n4. Ensure all text is readable\n5. Submit for verification\n\n⏱️ Verification typically takes 24-48 hours\n\n**Required Documents:**\n• Driving License\n• Insurance Certificate\n• DBS Check (if applicable)\n• Vehicle Registration\n\nNeed help? WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('insurance') || userMessageLower.includes('verification')) {
            aiResponse = '✅ **Verification Process:**\n\n**Required Documents:**\n• Driving License (valid)\n• Insurance Certificate (current)\n• DBS Check (if applicable)\n• Vehicle Registration\n\n**Timeline:**\n• Document review: 24-48 hours\n• Background check: 5-7 business days\n• You\'ll receive notifications at each step\n\n**Need Help?**\nContact our verification team via WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('background') || userMessageLower.includes('check')) {
            aiResponse = '🔍 **Background Checks:**\n\n• Processed within 5-7 business days\n• You\'ll receive a notification when complete\n• Required for all valeters\n• Includes criminal record check\n\n**If it\'s been longer:**\nContact our verification team via WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('job') || userMessageLower.includes('assignment') || userMessageLower.includes('request')) {
            aiResponse = '📋 **Job Assignments:**\n\n**How it works:**\n• Jobs assigned based on your location\n• Must be online and in active service area\n• Location services must be enabled\n• Accept jobs within 2 minutes\n\n**Not receiving jobs?**\n1. Check you\'re online\n2. Verify location permissions\n3. Ensure you\'re in a service area\n4. Check app is updated\n\nNeed help? WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('rating') || userMessageLower.includes('review')) {
            aiResponse = '⭐ **Ratings & Reviews:**\n\n**Why ratings matter:**\n• Higher ratings = more job opportunities\n• Customers see your average rating\n• Maintain quality service for better ratings\n\n**Tips:**\n• Respond promptly to messages\n• Complete jobs on time\n• Be professional and courteous\n\n**Unfair rating?**\nYou can appeal through the app or contact support: +44 7960 944743';
          } else if (userMessageLower.includes('emergency') || userMessageLower.includes('urgent')) {
            shouldEscalate = true;
            aiResponse = 'This sounds urgent. Let me connect you with a human agent immediately for faster assistance.';
          } else {
            aiResponse = 'I understand your question. While I can help with general information, for specific account issues, I recommend speaking with our support team. Would you like me to connect you with a human agent?';
            shouldEscalate = true;
          }
        } else {
          // Customer-specific responses
          if (userMessageLower.includes('booking') || userMessageLower.includes('book') || userMessageLower.includes('schedule')) {
            aiResponse = '📅 **Booking a Service:**\n\n1. Tap "Book Now" or "Instant Wash" on your dashboard\n2. Select your vehicle (or add one if needed)\n3. Choose service type (Basic, Premium, Full Valet)\n4. Set your location (current or custom address)\n5. Select time (on-demand or scheduled)\n6. Review and confirm payment\n\n⏱️ A valeter will be assigned within 5-10 minutes for on-demand bookings.\n\nNeed help? Contact support: +44 7960 944743';
          } else if (userMessageLower.includes('refund') || userMessageLower.includes('cancel')) {
            aiResponse = '💰 **Refunds & Cancellations:**\n\n**Cancellation Policy:**\n• Within 5 min: Full refund\n• Within 15 min: 90% refund\n• Within 30 min: 75% refund\n• Within 1 hour: 50% refund\n• Within 2 hours: 25% refund\n• After 2 hours: No refund\n\n**To Request:**\n1. Go to Help & Support → Request Refund\n2. Include your booking ID\n3. Provide reason for refund\n4. Refunds processed within 24-48 hours\n\nFor urgent issues, WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('tracking') || userMessageLower.includes('where') || userMessageLower.includes('location')) {
            aiResponse = '📍 **Tracking Your Valeter:**\n\n• Once a valeter accepts, you\'ll see real-time location\n• Updates every 30 seconds\n• View ETA and route on the map\n• Chat directly with your valeter\n\n**If tracking isn\'t working:**\n1. Refresh the app\n2. Check your internet connection\n3. Ensure location permissions are enabled\n\nNeed help? WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('payment') || userMessageLower.includes('charge') || userMessageLower.includes('card')) {
            aiResponse = '💳 **Payment Methods:**\n\n**Accepted:**\n• Visa, Mastercard, American Express\n• PayPal\n• Apple Pay\n• Google Pay\n\n**Security:**\n• All payments processed via Stripe\n• Your card details are never stored\n• 256-bit SSL encryption\n\n**Issues?**\nIf you see an unexpected charge, contact us immediately via WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('quality') || userMessageLower.includes('satisfied') || userMessageLower.includes('complaint')) {
            aiResponse = '⭐ **Service Quality:**\n\nIf you\'re not satisfied:\n1. Contact us within 24 hours of service\n2. Include photos if applicable\n3. Provide booking ID and details\n\n**We may offer:**\n• Full or partial refund\n• Free re-service\n• Account credit\n\nYour satisfaction is our priority! WhatsApp: +44 7960 944743';
          } else if (userMessageLower.includes('rewards') || userMessageLower.includes('points') || userMessageLower.includes('tier')) {
            aiResponse = '🎁 **Rewards & Points:**\n\n**Earn Points:**\n• 10 points per £1 spent on bookings\n• 5 points for rating valeters\n• 50 points per friend referral\n\n**Tiers:**\n• Bronze: 0-500 points\n• Silver: 501-1,500 points\n• Gold: 1,501-3,000 points\n• Platinum: 3,000+ points\n\n**Redeem for:**\n• Discounts on services\n• Free washes\n• Exclusive rewards\n\nCheck your tier in Profile → Rewards';
          } else if (userMessageLower.includes('emergency') || userMessageLower.includes('urgent')) {
            shouldEscalate = true;
            aiResponse = 'This sounds urgent. Let me connect you with a human agent immediately for faster assistance.';
          } else {
            aiResponse = 'I understand your question. While I can help with general information, for specific account issues, I recommend speaking with our support team. Would you like me to connect you with a human agent?';
            shouldEscalate = true;
          }
        }

        const aiMessage = {
          id: (Date.now() + 1).toString(),
          message: aiResponse,
          isUser: false,
          timestamp: new Date(),
          type: shouldEscalate ? 'human' : 'ai'
        };

        setChatHistory(prev => [...prev, aiMessage]);
        setIsTyping(false);

        if (shouldEscalate) {
          setTimeout(() => {
            const escalationMessage = {
              id: (Date.now() + 2).toString(),
              message: 'For immediate assistance, you can contact our support team via WhatsApp at +44 7960 944743. They\'re available 24/7 to help with your issue.',
              isUser: false,
              timestamp: new Date(),
              type: 'system'
            };
            setChatHistory(prev => [...prev, escalationMessage]);
            
            // Add WhatsApp button message
            setTimeout(() => {
              const whatsappButtonMessage = {
                id: (Date.now() + 3).toString(),
                message: 'Would you like me to open WhatsApp for you?',
                isUser: false,
                timestamp: new Date(),
                type: 'system',
                hasAction: true
              };
              setChatHistory(prev => [...prev, whatsappButtonMessage]);
            }, 1500);
          }, 2000);
        }
      }, 1500);
    } catch (error) {
      console.error('Error in sendMessage:', error);
      setIsTyping(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={customerTheme.backgroundGradient}
        style={StyleSheet.absoluteFill}
      />
      
      <AppHeader title="Help & Support" />

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40 }}
      >

        {/* Chat Options */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Get Help</Text>
            <Text style={styles.sectionSubtitle}>Choose how you'd like to get assistance</Text>
          </View>
          <View style={styles.chatOptionsGrid}>
            <TouchableOpacity 
              style={styles.modernChatOption} 
              onPress={handleWebChat}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={['rgba(135, 206, 235, 0.15)', 'rgba(30, 58, 138, 0.2)']}
                style={styles.modernChatOptionGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <View style={styles.modernChatIconWrapper}>
                  <Ionicons name="chatbubbles" size={28} color="#FFFFFF" />
                </View>
                <Text style={styles.modernChatTitle}>Live Chat</Text>
                <Text style={styles.modernChatSubtitle}>Speak with a human agent</Text>
                <Text style={styles.modernChatBadge}>Available now</Text>
              </LinearGradient>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.modernChatOption} 
              onPress={handleAIChat}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={['rgba(16, 185, 129, 0.15)', 'rgba(5, 150, 105, 0.2)']}
                style={styles.modernChatOptionGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <View style={styles.modernChatIconWrapper}>
                  <Ionicons name="sparkles" size={28} color="#FFFFFF" />
                </View>
                <Text style={styles.modernChatTitle}>AI Assistant</Text>
                <Text style={styles.modernChatSubtitle}>Instant help with AI</Text>
                <Text style={styles.modernChatBadge}>24/7 Available</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
            <Text style={styles.sectionSubtitle}>Common tasks and support options</Text>
          </View>
          <View style={styles.modernQuickActionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity 
                key={action.id} 
                style={styles.modernQuickAction} 
                onPress={action.action}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={['rgba(255, 255, 255, 0.08)', 'rgba(255, 255, 255, 0.04)']}
                  style={styles.modernQuickActionGradient}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                >
                  <View style={styles.modernQuickActionIconWrapper}>
                    <Ionicons name={action.icon as any} size={24} color="#FFFFFF" />
                  </View>
                  <Text style={styles.modernQuickActionTitle}>{action.title}</Text>
                  <Text style={styles.modernQuickActionSubtitle}>{action.subtitle}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Contact Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Us</Text>
          <View style={styles.contactGrid}>
            {contactOptions.map((contact) => (
              <TouchableOpacity key={contact.id} style={styles.contactOption} onPress={contact.action}>
                <Ionicons name={contact.icon as any} size={24} color="#87CEEB" style={styles.contactIcon} />
                <View style={styles.contactInfo}>
                  <Text style={styles.contactTitle}>{contact.title}</Text>
                  <Text style={styles.contactSubtitle}>{contact.subtitle}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqItem}
                onPress={() => toggleFAQ(faq.id)}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <Text style={styles.faqToggle}>
                    {expandedFAQ === faq.id ? '−' : '+'}
                  </Text>
                </View>
                {expandedFAQ === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Troubleshooting */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Common Issues</Text>
          <View style={styles.troubleshootingCard}>
            <View style={styles.issueItem}>
              <Ionicons name="phone-portrait" size={24} color="#87CEEB" style={styles.issueIcon} />
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>App not working?</Text>
                <Text style={styles.issueDescription}>Try restarting the app or updating to the latest version</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Ionicons name="card" size={24} color="#87CEEB" style={styles.issueIcon} />
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Payment issues?</Text>
                <Text style={styles.issueDescription}>Check your card details or try a different payment method</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Ionicons name="car" size={24} color="#87CEEB" style={styles.issueIcon} />
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>No valeters available?</Text>
                <Text style={styles.issueDescription}>Try adjusting your location or service time</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Ionicons name="time" size={24} color="#87CEEB" style={styles.issueIcon} />
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Long wait times?</Text>
                <Text style={styles.issueDescription}>Peak hours may have longer wait times. Try booking in advance</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Legal Links */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal</Text>
          <View style={styles.legalGrid}>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/terms-of-service')}>
              <Text style={styles.legalLinkText}>Terms of Service</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/privacy-policy')}>
              <Text style={styles.legalLinkText}>Privacy Policy</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/cookie-policy')}>
              <Text style={styles.legalLinkText}>Cookie Policy</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoCard}>
          <Text style={styles.appInfoTitle}>Wish a Wash</Text>
          <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
          <Text style={styles.appInfoCopyright}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>


      {/* AI Chat Modal */}
      <Modal visible={showAIChat} animationType="slide">
        <SafeAreaView style={styles.modernChatContainer}>
          <LinearGradient
            colors={customerTheme.backgroundGradient}
            style={StyleSheet.absoluteFill}
          />
          
          {/* Modern Header */}
          <View style={styles.modernChatHeader}>
            <TouchableOpacity 
              onPress={() => setShowAIChat(false)} 
              style={styles.modernChatBackButton}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['rgba(255, 255, 255, 0.15)', 'rgba(255, 255, 255, 0.08)']}
                style={styles.modernChatBackButtonGradient}
              >
                <Text style={styles.modernChatBackButtonText}>←</Text>
              </LinearGradient>
            </TouchableOpacity>
            <View style={styles.modernChatHeaderContent}>
              <View style={styles.modernChatHeaderIcon}>
                <Ionicons name="sparkles" size={22} color="#10B981" />
              </View>
              <View>
                <Text style={styles.modernChatTitle}>AI Assistant</Text>
                <Text style={styles.modernChatSubtitle}>Always here to help</Text>
              </View>
            </View>
            <View style={styles.modernChatHeaderSpacer} />
          </View>
          
          {/* Chat Messages */}
          <ScrollView 
            style={styles.modernChatMessages}
            contentContainerStyle={styles.modernChatMessagesContent}
            showsVerticalScrollIndicator={false}
          >
            {chatHistory.map((message) => (
              <View key={message.id}>
                <View 
                  style={[
                    styles.modernMessageContainer,
                    message.isUser ? styles.modernUserMessage : styles.modernAiMessage
                  ]}
                >
                  {!message.isUser && (
                    <View style={styles.modernAiAvatar}>
                      <Text style={styles.modernAiAvatarText}>AI</Text>
                    </View>
                  )}
                  <LinearGradient
                    colors={message.isUser 
                      ? [ACCENT, '#059669'] 
                      : ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.05)']}
                    style={[
                      styles.modernMessageBubble,
                      message.isUser 
                        ? { borderBottomRightRadius: 4, borderBottomLeftRadius: 20 }
                        : { borderBottomRightRadius: 20, borderBottomLeftRadius: 4 }
                    ]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                <Text style={[
                      styles.modernMessageText,
                      message.isUser ? styles.modernUserMessageText : styles.modernAiMessageText
                ]}>
                  {message.message}
                </Text>
                    <Text style={styles.modernMessageTime}>
                      {message.timestamp.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                </Text>
                  </LinearGradient>
                  {message.isUser && (
                    <View style={styles.modernUserAvatar}>
                      <Text style={styles.modernUserAvatarText}>You</Text>
                    </View>
                  )}
                </View>
                {message.type === 'system' && (message as any).hasAction && (
                  <TouchableOpacity
                    style={styles.modernWhatsAppButton}
                    onPress={handleWebChat}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['#25D366', '#128C7E']}
                      style={styles.modernWhatsAppButtonGradient}
                    >
                      <Ionicons name="logo-whatsapp" size={18} color="#FFFFFF" />
                      <Text style={styles.modernWhatsAppButtonText}>Open WhatsApp</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                )}
              </View>
            ))}
            {isTyping && (
              <View style={styles.modernTypingIndicator}>
                <View style={styles.modernTypingDots}>
                  <View style={[styles.modernTypingDot, { animationDelay: '0ms' }]} />
                  <View style={[styles.modernTypingDot, { animationDelay: '150ms' }]} />
                  <View style={[styles.modernTypingDot, { animationDelay: '300ms' }]} />
                </View>
                <Text style={styles.modernTypingText}>AI is thinking...</Text>
              </View>
            )}
          </ScrollView>
          
          {/* Quick Reply Suggestions */}
          {chatHistory.length === 1 && (
            <View style={styles.modernQuickRepliesContainer}>
              <Text style={styles.modernQuickRepliesTitle}>Quick Questions</Text>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.modernQuickRepliesScroll}
              >
                {(isValeter ? [
                  'How do I go online?',
                  'Payment not received?',
                  'Document upload help',
                  'Verification status'
                ] : [
                  'How to book?',
                  'Request refund',
                  'Track my valeter',
                  'Payment issues'
                ]).map((reply, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.modernQuickReplyButton}
                    onPress={() => {
                      setChatMessage(reply);
                      setTimeout(() => sendMessage(), 100);
                    }}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['rgba(135, 206, 235, 0.2)', 'rgba(30, 58, 138, 0.25)']}
                      style={styles.modernQuickReplyGradient}
                    >
                      <Text style={styles.modernQuickReplyText}>{reply}</Text>
                    </LinearGradient>
            </TouchableOpacity>
                ))}
              </ScrollView>
              </View>
            )}
          
          {/* Input Container */}
          <View style={styles.modernChatInputContainer}>
            <View style={styles.modernChatInputWrapper}>
            <TextInput
                style={styles.modernChatInput}
              value={chatMessage}
              onChangeText={setChatMessage}
              placeholder="Ask me anything..."
                placeholderTextColor="#87CEEB"
              multiline
                maxLength={500}
            />
              <TouchableOpacity 
                style={[
                  styles.modernSendButton,
                  !chatMessage.trim() && styles.modernSendButtonDisabled
                ]} 
                onPress={sendMessage}
                disabled={!chatMessage.trim()}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={chatMessage.trim() ? [ACCENT, '#059669'] : ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.05)']}
                  style={styles.modernSendButtonGradient}
                >
                  <Text style={styles.modernSendButtonIcon}>→</Text>
                </LinearGradient>
            </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickAction: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  contactGrid: {
    gap: 12,
  },
  contactOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  contactIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  contactInfo: {
    flex: 1,
  },
  contactTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  contactSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
  },
  faqContainer: {
    gap: 12,
  },
  faqItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  faqHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQuestion: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    marginRight: 16,
  },
  faqToggle: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  faqAnswer: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  troubleshootingCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  troubleshootingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  issueItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  issueIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  issueInfo: {
    flex: 1,
  },
  issueTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  issueDescription: {
    color: '#87CEEB',
    fontSize: 12,
    lineHeight: 16,
  },
  legalGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  legalLink: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  legalLinkText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  appInfoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  appInfoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  appInfoVersion: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  appInfoCopyright: {
    color: '#9CA3AF',
    fontSize: 10,
    textAlign: 'center',
  },
  // Chat styles
  chatOptionsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  chatOption: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  chatOptionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  chatOptionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  chatOptionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  chatBackButton: {
    padding: 8,
  },
  chatBackButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  chatTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  chatMessages: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 12,
    maxWidth: '80%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#87CEEB',
    borderRadius: 16,
    padding: 12,
    borderBottomRightRadius: 4,
  },
  agentMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  aiMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  userMessageText: {
    color: '#0A1929',
    fontWeight: '500',
  },
  agentMessageText: {
    color: '#F9FAFB',
  },
  aiMessageText: {
    color: '#F9FAFB',
  },
  messageTime: {
    fontSize: 10,
    color: '#9CA3AF',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  typingIndicator: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  typingText: {
    color: '#87CEEB',
    fontSize: 12,
    fontStyle: 'italic',
  },
  chatInputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
  },
  chatInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginRight: 8,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  quickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  quickReplyButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 8,
    marginRight: 8,
  },
  quickReplyText: {
    color: '#F9FAFB',
    fontSize: 14,
  },

  // Modern Styles
  sectionHeader: {
    marginBottom: 16,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 4,
    opacity: 0.9,
  },
  
  // Modern Chat Options
  modernChatOption: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  modernChatOptionGradient: {
    padding: 20,
    alignItems: 'center',
    minHeight: 140,
  },
  modernChatIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  modernChatIcon: {
    fontSize: 28,
  },
  modernChatTitle: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  modernChatSubtitle: {
    color: '#E5E7EB',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 8,
    opacity: 0.9,
  },
  modernChatBadge: {
    color: ACCENT,
    fontSize: 11,
    fontWeight: '700',
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    overflow: 'hidden',
  },
  
  // Modern Quick Actions
  modernQuickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  modernQuickAction: {
    width: '48%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  modernQuickActionGradient: {
    padding: 18,
    alignItems: 'center',
    minHeight: 120,
  },
  modernQuickActionIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  modernQuickActionIcon: {
    fontSize: 24,
  },
  modernQuickActionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
  },
  modernQuickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    opacity: 0.9,
  },
  
  // Modern AI Chat Modal
  modernChatContainer: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  modernChatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modernChatBackButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  modernChatBackButtonGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modernChatBackButtonText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
  },
  modernChatHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
    marginLeft: 12,
  },
  modernChatHeaderIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  modernChatHeaderEmoji: {
    fontSize: 22,
  },
  modernChatSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  modernChatHeaderSpacer: {
    width: 40,
  },
  modernChatMessages: {
    flex: 1,
  },
  modernChatMessagesContent: {
    padding: 16,
    paddingBottom: 20,
  },
  modernMessageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
    gap: 8,
  },
  modernUserMessage: {
    justifyContent: 'flex-end',
  },
  modernAiMessage: {
    justifyContent: 'flex-start',
  },
  modernMessageBubble: {
    maxWidth: '75%',
    borderRadius: 20,
    padding: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  modernMessageText: {
    fontSize: 15,
    lineHeight: 20,
    fontWeight: '500',
  },
  modernUserMessageText: {
    color: '#FFFFFF',
  },
  modernAiMessageText: {
    color: '#F9FAFB',
  },
  modernMessageTime: {
    fontSize: 10,
    color: 'rgba(255, 255, 255, 0.6)',
    marginTop: 6,
    fontWeight: '500',
  },
  modernAiAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  modernAiAvatarText: {
    color: ACCENT,
    fontSize: 11,
    fontWeight: '800',
  },
  modernUserAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  modernUserAvatarText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
  },
  modernTypingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  modernTypingDots: {
    flexDirection: 'row',
    gap: 4,
  },
  modernTypingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    opacity: 0.6,
  },
  modernTypingText: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '500',
    fontStyle: 'italic',
  },
  modernQuickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
  },
  modernQuickRepliesTitle: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  modernQuickRepliesScroll: {
    gap: 10,
  },
  modernQuickReplyButton: {
    borderRadius: 20,
    overflow: 'hidden',
    marginRight: 10,
  },
  modernQuickReplyGradient: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  modernQuickReplyText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
  },
  modernChatInputContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
  },
  modernChatInputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  modernChatInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 12,
    color: '#F9FAFB',
    fontSize: 15,
    maxHeight: 100,
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  modernSendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
  },
  modernSendButtonDisabled: {
    opacity: 0.5,
  },
  modernSendButtonGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modernSendButtonIcon: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
  },
  modernWhatsAppButton: {
    marginTop: 12,
    marginBottom: 8,
    borderRadius: 20,
    overflow: 'hidden',
    alignSelf: 'flex-start',
  },
  modernWhatsAppButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 8,
  },
  modernWhatsAppButtonIcon: {
    fontSize: 18,
  },
  modernWhatsAppButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
});
