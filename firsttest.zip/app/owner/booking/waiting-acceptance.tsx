import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import CountdownTimer from '../../../src/components/booking/CountdownTimer';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function WaitingAcceptance() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [valeter, setValeter] = useState<any | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [status, setStatus] = useState<'pending_valeter_acceptance' | 'pending_payment' | 'confirmed'>('pending_valeter_acceptance');

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    loadBooking();
    subscribeToBooking();
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
      setStatus(data.status);

      if (data?.valeter_id) {
        const { data: valeterProfile, error: valeterError } = await supabase
          .from('valeter_profiles')
          .select('full_name, profile_photo_url, company_name')
          .eq('user_id', data.valeter_id)
          .maybeSingle();

        if (!valeterError && valeterProfile) {
          setValeter(valeterProfile);
        } else {
          setValeter(null);
        }
      } else {
        setValeter(null);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);
          
          if (updated.status === 'pending_payment') {
            router.replace({
              pathname: '/owner/booking/payment',
              params: { bookingId },
            });
          } else if (updated.status === 'confirmed') {
            router.replace({
              pathname: '/owner/booking/tracking',
              params: { bookingId },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleCountdownComplete = () => {
    // Timeout - valeter didn't accept
    Alert.alert(
      'Request Expired',
      'The valeter didn\'t respond in time. Would you like to select another valeter?',
      [
        { text: 'Cancel', style: 'cancel', onPress: () => router.back() },
        { text: 'Select Another', onPress: () => router.back() },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Waiting for Acceptance" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Status Badge */}
          <View style={styles.statusContainer}>
            <StatusBadge status="pending" size="large" />
          </View>

          {/* Countdown Timer */}
          <View style={styles.timerContainer}>
            <CountdownTimer
              seconds={countdown}
              onComplete={handleCountdownComplete}
              size="large"
            />
          </View>

          {/* Valeter Card */}
          {valeter && (
            <GlassCard style={styles.valeterCard} accountType="customer">
              <View style={styles.valeterHeader}>
                <Ionicons name="person-circle" size={48} color={SKY} />
                <Text style={styles.valeterName}>{valeter.full_name || 'Valeter'}</Text>
                <Text style={styles.valeterSubtext}>Reviewing your request</Text>
              </View>
            </GlassCard>
          )}

          {/* Info Card */}
          <GlassCard style={styles.infoCard} accountType="customer">
            <View style={styles.infoHeader}>
              <Ionicons name="information-circle" size={24} color={SKY} />
              <Text style={styles.infoTitle}>What's Next?</Text>
            </View>
            <View style={styles.infoList}>
              <View style={styles.infoItem}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.infoText}>Valeter received your request</Text>
              </View>
              <View style={styles.infoItem}>
                <Ionicons name="time-outline" size={20} color={SKY} />
                <Text style={styles.infoText}>They have 5 minutes to respond</Text>
              </View>
              <View style={styles.infoItem}>
                <Ionicons name="card-outline" size={20} color={SKY} />
                <Text style={styles.infoText}>You'll pay once they accept</Text>
              </View>
            </View>
          </GlassCard>

          {/* Pulsing Icon */}
          <Animated.View
            style={[
              styles.pulseContainer,
              {
                transform: [{ scale: pulseAnim }],
              },
            ]}
          >
            <View style={styles.pulseOuter}>
              <View style={styles.pulseInner}>
                <Ionicons name="hourglass-outline" size={48} color={SKY} />
              </View>
            </View>
          </Animated.View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    alignItems: 'center',
  },
  statusContainer: {
    marginBottom: 24,
  },
  timerContainer: {
    marginBottom: 32,
  },
  valeterCard: {
    padding: 24,
    marginBottom: 20,
    width: '100%',
  },
  valeterHeader: {
    alignItems: 'center',
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 12,
    marginBottom: 4,
  },
  valeterSubtext: {
    color: SKY,
    fontSize: 14,
  },
  infoCard: {
    padding: 20,
    marginBottom: 32,
    width: '100%',
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  infoList: {
    gap: 12,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  pulseContainer: {
    marginTop: 20,
  },
  pulseOuter: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  pulseInner: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

