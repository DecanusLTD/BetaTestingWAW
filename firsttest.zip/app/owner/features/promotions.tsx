import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface Promotion {
  id: string;
  code?: string;
  title: string;
  description: string;
  discount?: number;
  discountPercent?: number;
  expiry?: Date;
  type: 'code' | 'offer' | 'subscription';
  price?: number;
  savings?: number;
  benefits?: string[];
}

export default function Promotions() {
  const { user } = useAuth();
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Get current season
  const getCurrentSeason = (): 'spring' | 'summer' | 'autumn' | 'winter' => {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return 'spring'; // March-May
    if (month >= 5 && month <= 7) return 'summer'; // June-August
    if (month >= 8 && month <= 10) return 'autumn'; // September-November
    return 'winter'; // December-February
  };

  const loadPromotions = async () => {
    setLoading(true);
    try {
      const currentSeason = getCurrentSeason();
      const now = Date.now();
      
      // Seasonal promotions - only show during appropriate seasons
      const seasonalPromotions: Promotion[] = [];
      
      if (currentSeason === 'spring') {
        seasonalPromotions.push({
          id: 'promo-spring',
          code: 'SPRING20',
          title: 'Spring Cleaning Special',
          description: '20% off all car washes this spring',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'summer') {
        seasonalPromotions.push({
          id: 'promo-summer',
          code: 'SUMMER25',
          title: 'Summer Special',
          description: '25% off all car washes this summer',
          discountPercent: 25,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'autumn') {
        seasonalPromotions.push({
          id: 'promo-autumn',
          code: 'AUTUMN15',
          title: 'Autumn Clean',
          description: '15% off all car washes this autumn',
          discountPercent: 15,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'winter') {
        seasonalPromotions.push({
          id: 'promo-winter',
          code: 'WINTER20',
          title: 'Winter Warm-Up',
          description: '20% off all car washes this winter',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      }
      
      setPromotions(seasonalPromotions);
    } catch (error) {
      console.error('Error loading promotions:', error);
      setPromotions([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadPromotions();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    loadPromotions();
  };

  const handleRedeem = (promo: Promotion) => {
    if (promo.code) {
      router.push({
        pathname: '/owner/booking',
        params: { promoCode: promo.code },
      } as any);
    }
  };

  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Promotions" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading promotions...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader title="Promotions" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Header Info */}
        <View style={styles.headerSection}>
          <BlurView intensity={30} tint="dark" style={styles.headerCard}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.headerIconWrapper}>
              <Ionicons name="pricetag" size={32} color={SKY} />
            </View>
            <Text style={styles.headerTitle}>Special Offers</Text>
            <Text style={styles.headerDescription}>
              Discover exclusive discounts and promotional codes to save on your next booking.
            </Text>
          </BlurView>
        </View>

        {/* Promotions List */}
        {promotions.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="pricetag-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Promotions Available</Text>
            <Text style={styles.emptySubtitle}>
              Check back soon for new offers and discounts
            </Text>
          </View>
        ) : (
          <View style={styles.promotionsSection}>
            {promotions.map((promo) => {
              const isExpiringSoon = promo.expiry && (promo.expiry.getTime() - Date.now()) < 48 * 60 * 60 * 1000;
              const timeRemaining = promo.expiry 
                ? Math.max(0, promo.expiry.getTime() - Date.now())
                : null;
              const hoursRemaining = timeRemaining ? Math.floor(timeRemaining / (1000 * 60 * 60)) : null;
              const minutesRemaining = timeRemaining ? Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)) : null;

              return (
                <TouchableOpacity
                  key={promo.id}
                  style={[
                    styles.promotionCard,
                    isExpiringSoon && styles.promotionCardUrgent,
                  ]}
                  onPress={() => handleRedeem(promo)}
                  activeOpacity={0.8}
                >
                  <BlurView intensity={35} tint="dark" style={styles.promotionBlur}>
                    <LinearGradient
                      colors={isExpiringSoon 
                        ? ['rgba(239,68,68,0.12)', 'rgba(239,68,68,0.06)']
                        : ['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                      style={StyleSheet.absoluteFill}
                    />
                    <View style={[styles.promotionBorder, { 
                      borderColor: isExpiringSoon 
                        ? 'rgba(239,68,68,0.4)' 
                        : 'rgba(135,206,235,0.3)' 
                    }]} />

                    <View style={styles.promotionHeader}>
                      <View style={[
                        styles.promotionIconWrapper,
                        { backgroundColor: isExpiringSoon 
                          ? 'rgba(239,68,68,0.2)' 
                          : 'rgba(135,206,235,0.2)' 
                        }
                      ]}>
                        <Ionicons 
                          name={promo.type === 'offer' ? 'flash' : 'pricetag'} 
                          size={24} 
                          color={isExpiringSoon ? '#EF4444' : SKY} 
                        />
                      </View>
                      <View style={styles.promotionContent}>
                        <Text style={styles.promotionTitle}>{promo.title}</Text>
                        <Text style={styles.promotionDescription}>{promo.description}</Text>
                        {promo.code && (
                          <View style={styles.promoCodeContainer}>
                            <Text style={styles.promoCodeLabel}>Code:</Text>
                            <Text style={styles.promoCode}>{promo.code}</Text>
                          </View>
                        )}
                      </View>
                    </View>

                    <View style={styles.promotionFooter}>
                      <View style={styles.promotionDiscount}>
                        {promo.discountPercent ? (
                          <Text style={[
                            styles.promotionDiscountText,
                            isExpiringSoon && { color: '#EF4444' }
                          ]}>
                            {promo.discountPercent}% OFF
                          </Text>
                        ) : promo.discount ? (
                          <Text style={[
                            styles.promotionDiscountText,
                            isExpiringSoon && { color: '#EF4444' }
                          ]}>
                            Save £{promo.discount}
                          </Text>
                        ) : null}
                        {timeRemaining && timeRemaining > 0 && (
                          <Text style={[
                            styles.promotionTimer,
                            isExpiringSoon && { color: '#EF4444' },
                          ]}>
                            {hoursRemaining}h {minutesRemaining}m left
                          </Text>
                        )}
                      </View>
                      <TouchableOpacity
                        style={[
                          styles.redeemButton,
                          isExpiringSoon && { backgroundColor: 'rgba(239,68,68,0.3)' },
                        ]}
                        onPress={() => handleRedeem(promo)}
                      >
                        <Text style={[
                          styles.redeemButtonText,
                          isExpiringSoon && { color: '#EF4444' }
                        ]}>
                          Redeem
                        </Text>
                        <Ionicons 
                          name="arrow-forward" 
                          size={16} 
                          color={isExpiringSoon ? '#EF4444' : SKY} 
                        />
                      </TouchableOpacity>
                    </View>
                  </BlurView>
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* Info Section */}
        <View style={styles.infoSection}>
          <BlurView intensity={30} tint="dark" style={styles.infoCard}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.infoIconWrapper}>
              <Ionicons name="information-circle" size={24} color={SKY} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>How to Use Promo Codes</Text>
              <Text style={styles.infoText}>
                Apply your promo code during checkout. Some codes may have restrictions or expiry dates. 
                Only one promo code can be used per booking.
              </Text>
            </View>
          </BlurView>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
  },
  headerSection: {
    marginBottom: 24,
    marginTop: 8,
  },
  headerCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 20,
    alignItems: 'center',
  },
  headerIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerDescription: {
    color: SKY,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    opacity: 0.9,
  },
  promotionsSection: {
    marginBottom: 24,
  },
  promotionCard: {
    marginBottom: 16,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  promotionCardUrgent: {
    borderWidth: 2,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  promotionBlur: {
    padding: 20,
    borderRadius: 20,
  },
  promotionBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
  },
  promotionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  promotionIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  promotionContent: {
    flex: 1,
  },
  promotionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 6,
  },
  promotionDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 8,
    lineHeight: 20,
  },
  promoCodeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  promoCodeLabel: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  promoCode: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 2,
    fontFamily: 'monospace',
  },
  promotionFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  promotionDiscount: {
    flex: 1,
  },
  promotionDiscountText: {
    color: SKY,
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  promotionTimer: {
    color: SKY,
    fontSize: 12,
    opacity: 0.8,
  },
  redeemButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  redeemButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: SKY,
    fontSize: 14,
    textAlign: 'center',
    opacity: 0.8,
  },
  infoSection: {
    marginBottom: 24,
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 16,
    flexDirection: 'row',
  },
  infoIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: SKY,
    fontSize: 13,
    lineHeight: 18,
    opacity: 0.9,
  },
});

