import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

const steps = [
  {
    id: 1,
    title: 'Sign Up',
    description: 'Create your account and verify your email address',
    icon: 'person-add-outline',
    color: '#3B82F6',
  },
  {
    id: 2,
    title: 'Complete Profile',
    description: 'Add your personal information, experience, and bio',
    icon: 'document-text-outline',
    color: '#8B5CF6',
  },
  {
    id: 3,
    title: 'Upload Documents',
    description: 'Submit your driving licence, insurance, and background check',
    icon: 'folder-outline',
    color: '#10B981',
  },
  {
    id: 4,
    title: 'Vehicle Information',
    description: 'Add details about your vehicle and equipment',
    icon: 'car-outline',
    color: '#F59E0B',
  },
  {
    id: 5,
    title: 'Get Verified',
    description: 'Wait for admin approval (usually within 24-48 hours)',
    icon: 'shield-checkmark-outline',
    color: '#EF4444',
  },
  {
    id: 6,
    title: 'Start Earning',
    description: 'Accept bookings and start providing services',
    icon: 'cash-outline',
    color: '#06B6D4',
  },
];

const benefits = [
  {
    icon: 'cash',
    title: 'Flexible Earnings',
    description: 'Set your own schedule and earn on your terms',
  },
  {
    icon: 'people',
    title: 'Build Your Business',
    description: 'Grow your customer base and reputation',
  },
  {
    icon: 'trophy',
    title: 'Tier System',
    description: 'Unlock rewards and benefits as you progress',
  },
  {
    icon: 'location',
    title: 'Work Locally',
    description: 'Serve customers in your area',
  },
];

export default function BecomeValeter() {
  const router = useRouter();
  
  const handleGetStarted = async () => {
    await hapticFeedback('medium');
    router.push('/valeter/valeter-onboarding');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Become a Valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.heroIconContainer}>
            <LinearGradient
              colors={[SKY, '#3B82F6']}
              style={styles.heroIconGradient}
            >
              <Ionicons name="car-sport" size={48} color="#FFFFFF" />
            </LinearGradient>
          </View>
          <Text style={styles.heroTitle}>Start Your Valeting Journey</Text>
          <Text style={styles.heroSubtitle}>
            Join our network of professional valeters and start earning today
          </Text>
        </View>

        {/* Benefits Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Why Become a Valeter?</Text>
          <View style={styles.benefitsGrid}>
            {benefits.map((benefit, index) => (
              <View key={index} style={styles.benefitCard}>
                <View style={[styles.benefitIconContainer, { backgroundColor: benefit.icon === 'cash' ? '#10B98120' : benefit.icon === 'people' ? '#3B82F620' : benefit.icon === 'trophy' ? '#F59E0B20' : '#06B6D420' }]}>
                  <Ionicons
                    name={benefit.icon as any}
                    size={24}
                    color={benefit.icon === 'cash' ? '#10B981' : benefit.icon === 'people' ? '#3B82F6' : benefit.icon === 'trophy' ? '#F59E0B' : '#06B6D4'}
                  />
                </View>
                <Text style={styles.benefitTitle}>{benefit.title}</Text>
                <Text style={styles.benefitDescription}>{benefit.description}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Steps Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How to Get Started</Text>
          <View style={styles.stepsContainer}>
            {steps.map((step, index) => (
              <View key={step.id} style={styles.stepRow}>
                <View style={styles.stepNumberContainer}>
                  <LinearGradient
                    colors={[step.color, step.color + 'CC']}
                    style={styles.stepNumberGradient}
                  >
                    <Text style={styles.stepNumber}>{step.id}</Text>
                  </LinearGradient>
                </View>
                <View style={styles.stepContent}>
                  <View style={styles.stepHeader}>
                    <Ionicons name={step.icon as any} size={20} color={step.color} />
                    <Text style={styles.stepTitle}>{step.title}</Text>
                  </View>
                  <Text style={styles.stepDescription}>{step.description}</Text>
                </View>
                {index < steps.length - 1 && (
                  <View style={styles.stepConnector} />
                )}
              </View>
            ))}
          </View>
        </View>

        {/* Requirements Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Requirements</Text>
          <View style={styles.requirementsCard}>
            <View style={styles.requirementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#10B981" />
              <Text style={styles.requirementText}>Valid UK driving licence</Text>
            </View>
            <View style={styles.requirementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#10B981" />
              <Text style={styles.requirementText}>Valid insurance coverage</Text>
            </View>
            <View style={styles.requirementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#10B981" />
              <Text style={styles.requirementText}>Background check clearance</Text>
            </View>
            <View style={styles.requirementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#10B981" />
              <Text style={styles.requirementText}>Vehicle suitable for valeting</Text>
            </View>
            <View style={styles.requirementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#10B981" />
              <Text style={styles.requirementText}>Basic valeting equipment</Text>
            </View>
          </View>
        </View>

        {/* CTA Button */}
        <TouchableOpacity
          style={styles.ctaButton}
          onPress={handleGetStarted}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={[SKY, '#3B82F6']}
            style={styles.ctaGradient}
          >
            <Ionicons name="rocket-outline" size={20} color="#FFFFFF" />
            <Text style={styles.ctaText}>Get Started</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  heroSection: {
    alignItems: 'center',
    marginBottom: 32,
    marginTop: 20,
  },
  heroIconContainer: {
    marginBottom: 20,
  },
  heroIconGradient: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  heroSubtitle: {
    color: '#9CA3AF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  benefitsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  benefitCard: {
    width: (width - 52) / 2,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  benefitIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  benefitTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  benefitDescription: {
    color: '#9CA3AF',
    fontSize: 12,
    lineHeight: 18,
  },
  stepsContainer: {
    position: 'relative',
  },
  stepRow: {
    flexDirection: 'row',
    marginBottom: 24,
    position: 'relative',
  },
  stepNumberContainer: {
    marginRight: 16,
  },
  stepNumberGradient: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepNumber: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  stepContent: {
    flex: 1,
    paddingTop: 4,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#9CA3AF',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 4,
  },
  stepConnector: {
    position: 'absolute',
    left: 23,
    top: 48,
    width: 2,
    height: 24,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  requirementsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    gap: 16,
  },
  requirementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  requirementText: {
    color: '#F9FAFB',
    fontSize: 16,
    flex: 1,
  },
  ctaButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    gap: 8,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

