import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  savings?: number;
  duration: string;
  benefits: string[];
  popular?: boolean;
  icon: string;
  color: string;
}

export default function Subscriptions() {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans: SubscriptionPlan[] = [
    {
      id: 'basic',
      name: 'Basic Package',
      description: 'Perfect for regular car care',
      price: 80,
      originalPrice: 100,
      savings: 20,
      duration: 'month',
      benefits: ['4 washes per month', 'Priority booking', '10% discount on extras'],
      icon: 'car',
      color: SKY,
    },
    {
      id: 'premium',
      name: 'Premium Package',
      description: 'Best value for frequent users',
      price: 120,
      originalPrice: 150,
      savings: 30,
      duration: 'month',
      benefits: ['8 washes per month', 'Unlimited priority booking', 'Free wax & polish', '20% discount on extras'],
      popular: true,
      icon: 'diamond',
      color: colors.PREMIUM_PURPLE,
    },
    {
      id: 'ultimate',
      name: 'Ultimate Package',
      description: 'Complete car care solution',
      price: 180,
      originalPrice: 240,
      savings: 60,
      duration: 'month',
      benefits: ['12 washes per month', 'Unlimited priority booking', 'Free wax & polish', '30% discount on extras'],
      icon: 'star',
      color: '#F59E0B',
    },
  ];

  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId);
    // Navigate to payment/confirmation
    router.push({
      pathname: '/owner/booking/payment',
      params: { subscriptionId: planId },
    } as any);
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Subscriptions" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Info */}
        <View style={styles.headerSection}>
          <BlurView intensity={30} tint="dark" style={styles.headerCard}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.headerIconWrapper}>
              <Ionicons name="calendar" size={32} color={SKY} />
            </View>
            <Text style={styles.headerTitle}>Choose Your Plan</Text>
            <Text style={styles.headerDescription}>
              Save money with our monthly subscription packages. Cancel at any time.
            </Text>
          </BlurView>
        </View>

        {/* Subscription Plans */}
        <View style={styles.plansSection}>
          {plans.map((plan) => (
            <TouchableOpacity
              key={plan.id}
              style={[styles.planCard, plan.popular && styles.planCardPopular]}
              onPress={() => handleSelectPlan(plan.id)}
              activeOpacity={0.8}
            >
              <BlurView intensity={35} tint="dark" style={styles.planBlur}>
                <LinearGradient
                  colors={[`${plan.color}15`, `${plan.color}08`]}
                  style={StyleSheet.absoluteFill}
                />
                <View style={[styles.planBorder, { borderColor: `${plan.color}40` }]} />
                
                {plan.popular && (
                  <View style={[styles.popularBadge, { backgroundColor: `${plan.color}30` }]}>
                    <Text style={[styles.popularText, { color: plan.color }]}>Most Popular</Text>
                  </View>
                )}

                <View style={styles.planHeader}>
                  <View style={[styles.planIconWrapper, { backgroundColor: `${plan.color}20` }]}>
                    <Ionicons name={plan.icon as any} size={28} color={plan.color} />
                  </View>
                  <View style={styles.planTitleSection}>
                    <Text style={styles.planName}>{plan.name}</Text>
                    <Text style={styles.planDescription}>{plan.description}</Text>
                  </View>
                </View>

                <View style={styles.planPricing}>
                  <View style={styles.priceRow}>
                    {plan.originalPrice && (
                      <Text style={styles.originalPrice}>£{plan.originalPrice}</Text>
                    )}
                    <Text style={[styles.planPrice, { color: plan.color }]}>£{plan.price}</Text>
                    <Text style={styles.planDuration}>/{plan.duration}</Text>
                  </View>
                  {plan.savings && (
                    <View style={[styles.savingsBadge, { backgroundColor: `${plan.color}20` }]}>
                      <Text style={[styles.savingsText, { color: plan.color }]}>
                        Save £{plan.savings}/{plan.duration}
                      </Text>
                    </View>
                  )}
                </View>

                <View style={styles.planBenefits}>
                  <Text style={styles.benefitsTitle}>What's included:</Text>
                  {plan.benefits.map((benefit, index) => (
                    <View key={index} style={styles.benefitRow}>
                      <Ionicons name="checkmark-circle" size={16} color={plan.color} />
                      <Text style={styles.benefitText}>{benefit}</Text>
                    </View>
                  ))}
                </View>

                <TouchableOpacity
                  style={[styles.selectButton, { backgroundColor: `${plan.color}30` }]}
                  onPress={() => handleSelectPlan(plan.id)}
                >
                  <Text style={[styles.selectButtonText, { color: plan.color }]}>
                    Select Plan
                  </Text>
                  <Ionicons name="arrow-forward" size={18} color={plan.color} />
                </TouchableOpacity>
              </BlurView>
            </TouchableOpacity>
          ))}
        </View>

        {/* Info Section */}
        <View style={styles.infoSection}>
          <BlurView intensity={30} tint="dark" style={styles.infoCard}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.infoIconWrapper}>
              <Ionicons name="information-circle" size={24} color={SKY} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoTitle}>Flexible Subscriptions</Text>
              <Text style={styles.infoText}>
                All subscriptions can be cancelled at any time. Unused washes roll over to the next month. 
                Upgrade or downgrade your plan at any time from your account settings.
              </Text>
            </View>
          </BlurView>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  headerSection: {
    marginBottom: 24,
    marginTop: 8,
  },
  headerCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 20,
    alignItems: 'center',
  },
  headerIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerDescription: {
    color: SKY,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    opacity: 0.9,
  },
  plansSection: {
    marginBottom: 24,
  },
  planCard: {
    marginBottom: 20,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  planCardPopular: {
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.4)',
  },
  planBlur: {
    padding: 20,
    borderRadius: 20,
  },
  planBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
  },
  popularBadge: {
    position: 'absolute',
    top: 16,
    right: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.4)',
  },
  popularText: {
    fontSize: 12,
    fontWeight: '700',
  },
  planHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  planIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  planTitleSection: {
    flex: 1,
  },
  planName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  planDescription: {
    color: SKY,
    fontSize: 14,
    opacity: 0.8,
  },
  planPricing: {
    marginBottom: 20,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 8,
  },
  originalPrice: {
    color: '#6B7280',
    fontSize: 18,
    textDecorationLine: 'line-through',
    marginRight: 8,
  },
  planPrice: {
    fontSize: isSmallScreen ? 32 : 36,
    fontWeight: '800',
  },
  planDuration: {
    color: '#9CA3AF',
    fontSize: 16,
    marginLeft: 4,
  },
  savingsBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  savingsText: {
    fontSize: 12,
    fontWeight: '700',
  },
  planBenefits: {
    marginBottom: 20,
  },
  benefitsTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  benefitRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  benefitText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  selectButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  selectButtonText: {
    fontSize: 16,
    fontWeight: '700',
  },
  infoSection: {
    marginBottom: 24,
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 16,
    flexDirection: 'row',
  },
  infoIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: SKY,
    fontSize: 13,
    lineHeight: 18,
    opacity: 0.9,
  },
});

