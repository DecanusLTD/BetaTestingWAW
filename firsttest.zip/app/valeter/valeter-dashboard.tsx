import React from 'react';
import PowerfulDriverDashboard from '../../src/components/dashboard/PowerfulDriverDashboard';

export default function ValeterDashboard() {
  return <PowerfulDriverDashboard />;
}
