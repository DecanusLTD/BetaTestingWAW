import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  StatusBar,
  Dimensions,
  Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { supabase } from '../../../src/lib/supabase';
import { Ionicons } from '@expo/vector-icons';
import { simpleDocumentUploadService } from '../../../src/services/SimpleDocumentUploadService';
import { fetchRadiusPreference, RadiusColumn } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CARD_WIDTH = (SCREEN_WIDTH - 40) * 0.85;
const CARD_MARGIN = 12;
const SNAP_INTERVAL = CARD_WIDTH + CARD_MARGIN * 2;

interface RadiusOption {
  value: number;
  label: string;
  description: string;
  color: string;
  icon: keyof typeof Ionicons.glyphMap;
}

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

const getNotifPrefsKey = (userId: string) => `valeter:notif_prefs:${userId}`;

export default function DistanceCovering() {
  const { user } = useAuth();

  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRadius, setIsLoadingRadius] = useState(true);
  const [documentsCount, setDocumentsCount] = useState(0);

  // ✅ local-only
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);

  // (unchanged - still Supabase)
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);

  const scrollViewRef = useRef<ScrollView>(null);
  const radiusScrollRef = useRef<ScrollView>(null);
  const [radiusColumn, setRadiusColumn] = useState<RadiusColumn>('working_radius');

  const radiusOptions: RadiusOption[] = [
    { value: 5, label: '5 miles', description: 'Local area coverage', color: '#10B981', icon: 'home' },
    { value: 10, label: '10 miles', description: 'City district coverage', color: '#3B82F6', icon: 'business' },
    { value: 15, label: '15 miles', description: 'Extended city coverage', color: '#8B5CF6', icon: 'location' },
    { value: 20, label: '20 miles', description: 'Metropolitan area coverage', color: '#F59E0B', icon: 'map' },
    { value: 25, label: '25 miles', description: 'Wide area coverage', color: '#EF4444', icon: 'globe' },
    { value: 30, label: '30 miles', description: 'Maximum coverage area', color: '#7C3AED', icon: 'rocket' },
  ];

  useEffect(() => {
    loadCurrentRadius();
    loadDocumentsCount();
    loadNotificationPreferencesLocal(); // ✅ local
    loadAvailabilitySchedule(); // (unchanged)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!isLoadingRadius && selectedRadius) {
      const index = radiusOptions.findIndex((opt) => opt.value === selectedRadius);
      if (radiusScrollRef.current && index >= 0) {
        setTimeout(() => {
          radiusScrollRef.current?.scrollTo({ x: index * SNAP_INTERVAL, animated: true });
        }, 300);
      }
    }
  }, [isLoadingRadius, selectedRadius]);

  const loadCurrentRadius = async () => {
    if (!user?.id) return;

    try {
      setIsLoadingRadius(true);
      const { value, column } = await fetchRadiusPreference(user.id);
      setRadiusColumn(column);

      if (typeof value === 'number') setSelectedRadius(value);
      else setSelectedRadius(10);
    } catch (error) {
      console.error('Error loading radius:', error);
    } finally {
      setIsLoadingRadius(false);
    }
  };

  const loadDocumentsCount = async () => {
    if (!user?.id) return;
    try {
      const docs = simpleDocumentUploadService.getUserDocuments(user.id);
      setDocumentsCount(docs.length);
    } catch (error) {
      console.error('Error loading documents count:', error);
    }
  };

  // ✅ Local-only notification prefs (AsyncStorage)
  const loadNotificationPreferencesLocal = async () => {
    if (!user?.id) {
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
      return;
    }

    try {
      const raw = await AsyncStorage.getItem(getNotifPrefsKey(user.id));
      if (!raw) {
        setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
        return;
      }

      const parsed = JSON.parse(raw) as Partial<NotificationPreferences> | null;
      const merged: NotificationPreferences = {
        ...DEFAULT_NOTIFICATION_PREFS,
        ...(parsed || {}),
      };

      setNotificationPrefs(merged);
    } catch (error) {
      console.error('Error loading local notification preferences:', error);
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
    }
  };

  const saveNotificationPreferencesLocal = async (prefs: NotificationPreferences) => {
    if (!user?.id) return;
    try {
      await AsyncStorage.setItem(getNotifPrefsKey(user.id), JSON.stringify(prefs));
    } catch (error) {
      console.error('Error saving local notification preferences:', error);
    }
  };

  // (unchanged - still Supabase)
  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      const { data: profile } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    }
  };

  const handleRadiusSelect = async (radius: number) => {
    try {
      await hapticFeedback('light');
      setSelectedRadius(radius);
      const index = radiusOptions.findIndex((opt) => opt.value === radius);
      if (radiusScrollRef.current && index >= 0) {
        radiusScrollRef.current.scrollTo({ x: index * SNAP_INTERVAL, animated: true });
      }
    } catch {
      // ignore
    }
  };

  // ✅ Local-only toggle (no Supabase)
  const handleNotificationToggle = async (key: keyof NotificationPreferences) => {
    try {
      await hapticFeedback('light');
      const newPrefs: NotificationPreferences = { ...notificationPrefs, [key]: !notificationPrefs[key] };
      setNotificationPrefs(newPrefs);
      await saveNotificationPreferencesLocal(newPrefs);
    } catch (error) {
      console.error('Error updating local notification preferences:', error);
    }
  };

  // (unchanged - still Supabase)
  const handleDayToggle = async (day: keyof AvailabilitySchedule) => {
    try {
      await hapticFeedback('light');
      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
      };
      setAvailabilitySchedule(newSchedule);

      if (user?.id) {
        await supabase.from('valeter_profiles').update({ availability_schedule: newSchedule }).eq('user_id', user.id);
      }
    } catch (error) {
      console.error('Error updating availability schedule:', error);
    }
  };

  const handleSaveRadius = async () => {
    if (!user?.id) {
      Alert.alert('Error', 'Please sign in to update your settings.');
      return;
    }

    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      // ✅ notificationPrefs are local now — keep them OUT of Supabase payload
      const buildPayload = (column: RadiusColumn) => ({
        [column]: selectedRadius,
        availability_schedule: availabilitySchedule,
      });

      let error: any;

      if (existingProfile) {
        const { error: updateError } = await supabase
          .from('valeter_profiles')
          .update(buildPayload(radiusColumn))
          .eq('user_id', user.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, ...buildPayload(radiusColumn), is_online: false });
        error = insertError;
      }

      if (error && error.code === '42703' && radiusColumn === 'working_radius') {
        setRadiusColumn('radius_coverage');
        const fallbackPayload = buildPayload('radius_coverage');

        if (existingProfile) {
          const { error: legacyUpdateError } = await supabase
            .from('valeter_profiles')
            .update(fallbackPayload)
            .eq('user_id', user.id);
          error = legacyUpdateError;
        } else {
          const { error: legacyInsertError } = await supabase
            .from('valeter_profiles')
            .insert({ user_id: user.id, ...fallbackPayload, is_online: false });
          error = legacyInsertError;
        }
      }

      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        Alert.alert(
          'Database Migration Required',
          `Some columns need to be added. Please run this SQL in Supabase:

ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS working_radius INTEGER DEFAULT 10;
ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS availability_schedule JSONB;

Your notification preferences are saved locally on this device.`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      if (error) throw error;

      Alert.alert('Settings Updated', `Your settings have been saved successfully.`, [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', error.message || 'Failed to save settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRadiusDescription = (radius: number) => {
    switch (radius) {
      case 5:
        return 'Perfect for local neighbourhood work';
      case 10:
        return 'Ideal for city district coverage';
      case 15:
        return 'Great for extended city areas';
      case 20:
        return 'Covers metropolitan areas';
      case 25:
        return 'Wide coverage for busy areas';
      case 30:
        return 'Maximum coverage for high-demand areas';
      default:
        return 'Select your preferred coverage area';
    }
  };

  if (isLoadingRadius) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
          <ActivityIndicator size="large" color="#3B82F6" />
          <Text style={{ color: '#FFFFFF', marginTop: 16 }}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Settings" />

      <ScrollView
        ref={scrollViewRef}
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 20 }}
      >
        <View style={styles.currentSelection}>
          <Text style={styles.currentSelectionTitle}>Current Radius</Text>
          <View style={styles.currentRadiusCard}>
            <Text style={styles.currentRadiusValue}>{selectedRadius} miles</Text>
            <Text style={styles.currentRadiusDescription}>{getRadiusDescription(selectedRadius)}</Text>
          </View>
        </View>

        <View style={styles.optionsSection}>
          <Text style={styles.sectionTitle}>Select Your Working Radius</Text>
          <Text style={styles.sectionSubtitle}>Choose how you're willing to travel for jobs</Text>

          <ScrollView
            ref={radiusScrollRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            snapToInterval={SNAP_INTERVAL}
            decelerationRate="fast"
            contentContainerStyle={styles.horizontalScrollContent}
            style={styles.horizontalScrollView}
          >
            {radiusOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                style={[
                  styles.radiusOptionHorizontal,
                  selectedRadius === option.value && styles.selectedOptionHorizontal,
                ]}
                onPress={() => handleRadiusSelect(option.value)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={
                    selectedRadius === option.value
                      ? [option.color, option.color + 'CC']
                      : ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.05)']
                  }
                  style={styles.optionGradientHorizontal}
                >
                  <Ionicons
                    name={option.icon}
                    size={32}
                    color={selectedRadius === option.value ? '#FFFFFF' : option.color}
                  />
                  <Text
                    style={[
                      styles.optionLabel,
                      selectedRadius === option.value && styles.selectedOptionText,
                    ]}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={[
                      styles.optionDescription,
                      selectedRadius === option.value && styles.selectedOptionText,
                    ]}
                  >
                    {option.description}
                  </Text>
                  {selectedRadius === option.value && (
                    <View style={styles.selectedIndicator}>
                      <Ionicons name="checkmark-circle" size={24} color="#FFFFFF" />
                    </View>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>Documents</Text>
          <TouchableOpacity
            style={styles.settingsCard}
            onPress={() => router.push('/valeter/profile/valeter-documents')}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(139,92,246,0.2)', 'rgba(124,58,237,0.25)']}
              style={styles.settingsCardGradient}
            >
              <View style={styles.settingsCardContent}>
                <View style={styles.settingsIconWrapper}>
                  <Ionicons name="document-text" size={28} color="#8B5CF6" />
                </View>
                <View style={styles.settingsTextContainer}>
                  <Text style={styles.settingsCardTitle}>Manage Documents</Text>
                  <Text style={styles.settingsCardSubtitle}>
                    {documentsCount > 0
                      ? `${documentsCount} document${documentsCount !== 1 ? 's' : ''} uploaded`
                      : 'Upload verification documents'}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#8B5CF6" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* ✅ Notification Preferences (LOCAL ONLY) */}
        <View style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>Notification Preferences</Text>
          <View style={styles.settingsCard}>
            <LinearGradient
              colors={['rgba(59,130,246,0.2)', 'rgba(37,99,235,0.25)']}
              style={styles.settingsCardGradient}
            >
              <View style={styles.toggleRow}>
                <View style={styles.toggleLeft}>
                  <Ionicons name="notifications" size={20} color="#3B82F6" />
                  <Text style={styles.toggleLabel}>Job Request Alerts</Text>
                </View>
                <Switch
                  value={notificationPrefs.jobAlerts}
                  onValueChange={() => handleNotificationToggle('jobAlerts')}
                  trackColor={{ false: '#374151', true: '#3B82F6' }}
                  thumbColor="#FFFFFF"
                />
              </View>

              <View style={styles.toggleRow}>
                <View style={styles.toggleLeft}>
                  <Ionicons name="volume-high" size={20} color="#3B82F6" />
                  <Text style={styles.toggleLabel}>Sound Alerts</Text>
                </View>
                <Switch
                  value={notificationPrefs.sound}
                  onValueChange={() => handleNotificationToggle('sound')}
                  trackColor={{ false: '#374151', true: '#3B82F6' }}
                  thumbColor="#FFFFFF"
                />
              </View>

              <View style={styles.toggleRow}>
                <View style={styles.toggleLeft}>
                  <Ionicons name="phone-portrait" size={20} color="#3B82F6" />
                  <Text style={styles.toggleLabel}>Vibration</Text>
                </View>
                <Switch
                  value={notificationPrefs.vibration}
                  onValueChange={() => handleNotificationToggle('vibration')}
                  trackColor={{ false: '#374151', true: '#3B82F6' }}
                  thumbColor="#FFFFFF"
                />
              </View>

              <View style={[styles.toggleRow, { borderBottomWidth: 0 }]}>
                <View style={styles.toggleLeft}>
                  <Ionicons name="mail" size={20} color="#3B82F6" />
                  <Text style={styles.toggleLabel}>Email Notifications</Text>
                </View>
                <Switch
                  value={notificationPrefs.email}
                  onValueChange={() => handleNotificationToggle('email')}
                  trackColor={{ false: '#374151', true: '#3B82F6' }}
                  thumbColor="#FFFFFF"
                />
              </View>
            </LinearGradient>
          </View>
        </View>

        {/* Availability (unchanged - still Supabase) */}
        <View style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>Availability Schedule</Text>
          <View style={styles.settingsCard}>
            <LinearGradient
              colors={['rgba(16,185,129,0.2)', 'rgba(5,150,105,0.25)']}
              style={styles.settingsCardGradient}
            >
              {(
                ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const
              ).map((day) => {
                const dayName = day.charAt(0).toUpperCase() + day.slice(1);
                const schedule = availabilitySchedule[day];
                return (
                  <View key={day} style={styles.scheduleRow}>
                    <View style={styles.scheduleLeft}>
                      <Switch
                        value={schedule.enabled}
                        onValueChange={() => handleDayToggle(day)}
                        trackColor={{ false: '#374151', true: '#10B981' }}
                        thumbColor="#FFFFFF"
                      />
                      <Text style={styles.scheduleDayLabel}>{dayName}</Text>
                    </View>

                    {schedule.enabled && (
                      <View style={styles.timeContainer}>
                        <Text style={styles.timeText}>{schedule.startTime}</Text>
                        <Text style={styles.timeSeparator}>-</Text>
                        <Text style={styles.timeText}>{schedule.endTime}</Text>
                      </View>
                    )}
                  </View>
                );
              })}
            </LinearGradient>
          </View>
        </View>

        <View className="quickActions" style={styles.settingsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActionsGrid}>
            <TouchableOpacity
              style={styles.quickActionCard}
              onPress={() => router.push('/valeter/profile/valeter-profile')}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['rgba(59,130,246,0.2)', 'rgba(37,99,235,0.25)']}
                style={styles.quickActionGradient}
              >
                <Ionicons name="person" size={32} color="#3B82F6" />
                <Text style={styles.quickActionLabel}>Profile</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionCard}
              onPress={() => router.push('/valeter/valeter-analytics')}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['rgba(16,185,129,0.2)', 'rgba(5,150,105,0.25)']}
                style={styles.quickActionGradient}
              >
                <Ionicons name="analytics" size={32} color="#10B981" />
                <Text style={styles.quickActionLabel}>Analytics</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionCard}
              onPress={() => router.push('/valeter/valeter-rewards-system')}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['rgba(245,158,11,0.2)', 'rgba(217,119,6,0.25)']}
                style={styles.quickActionGradient}
              >
                <Ionicons name="gift" size={32} color="#F59E0B" />
                <Text style={styles.quickActionLabel}>Rewards</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionCard}
              onPress={() => router.push('/valeter/valeter-wash-history')}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['rgba(139,92,246,0.2)', 'rgba(124,58,237,0.25)']}
                style={styles.quickActionGradient}
              >
                <Ionicons name="time" size={32} color="#8B5CF6" />
                <Text style={styles.quickActionLabel}>History</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoTitleRow}>
            <Ionicons name="bulb" size={20} color="#F59E0B" />
            <Text style={styles.infoTitle}>How it works</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoText}>• You'll receive job notifications within your selected radius</Text>
            <Text style={styles.infoText}>• Larger radius = more job opportunities but longer travel times</Text>
            <Text style={styles.infoText}>• Smaller radius = faster response times but fewer opportunities</Text>
            <Text style={styles.infoText}>• You can change this setting anytime</Text>
            <Text style={[styles.infoText, { marginTop: 8, opacity: 0.85 }]}>
              • Notification toggles are saved locally on this device
            </Text>
          </View>
        </View>
      </ScrollView>

      <View style={styles.bottomSection}>
        <TouchableOpacity
          style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
          onPress={handleSaveRadius}
          disabled={isLoading}
        >
          <LinearGradient colors={['#3B82F6', '#2563EB']} style={styles.saveButtonGradient}>
            <Text style={styles.saveButtonText}>{isLoading ? 'Saving...' : 'Save Settings'}</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  headerSpacer: { width: 40 },
  content: { flex: 1, paddingHorizontal: 20 },

  currentSelection: { marginTop: 20, marginBottom: 30 },
  currentSelectionTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  currentRadiusCard: { backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 16, padding: 20, alignItems: 'center' },
  currentRadiusValue: { color: '#3B82F6', fontSize: 32, fontWeight: 'bold', marginBottom: 8 },
  currentRadiusDescription: { color: '#E0E7FF', fontSize: 14, textAlign: 'center', lineHeight: 20 },

  optionsSection: { marginBottom: 30 },
  sectionTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  sectionSubtitle: { color: '#E0E7FF', fontSize: 14, marginBottom: 20, lineHeight: 20 },

  horizontalScrollView: { marginHorizontal: -20 },
  horizontalScrollContent: { paddingHorizontal: 20, paddingVertical: 8 },
  radiusOptionHorizontal: { width: CARD_WIDTH, marginRight: CARD_MARGIN, borderRadius: 16, overflow: 'hidden' },
  selectedOptionHorizontal: {
    transform: [{ scale: 1.05 }],
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  optionGradientHorizontal: { padding: 20, alignItems: 'center', minHeight: 140, justifyContent: 'center', position: 'relative' },
  selectedIndicator: { position: 'absolute', top: 12, right: 12 },
  optionLabel: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'center' },
  optionDescription: { color: '#E0E7FF', fontSize: 12, textAlign: 'center', lineHeight: 16 },
  selectedOptionText: { color: '#FFFFFF' },

  infoSection: { marginBottom: 30 },
  infoTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  infoTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },
  infoCard: { backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 16, padding: 20 },
  infoText: { color: '#E0E7FF', fontSize: 14, lineHeight: 20, marginBottom: 8 },

  bottomSection: { paddingHorizontal: 20, paddingVertical: 20, borderTopWidth: 1, borderTopColor: 'rgba(255, 255, 255, 0.1)' },
  saveButton: { borderRadius: 12, overflow: 'hidden' },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonGradient: { paddingVertical: 16, alignItems: 'center' },
  saveButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },

  settingsSection: { marginBottom: 30 },
  settingsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    marginTop: 12,
  },
  settingsCardGradient: { padding: 16 },
  settingsCardContent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  settingsIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  settingsTextContainer: { flex: 1, gap: 4 },
  settingsCardTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', letterSpacing: 0.2 },
  settingsCardSubtitle: { color: '#87CEEB', fontSize: 13, opacity: 0.9, fontWeight: '500' },

  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  toggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  toggleLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '600' },

  scheduleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  scheduleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  scheduleDayLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', minWidth: 80 },

  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  timeText: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },
  timeSeparator: { color: '#87CEEB', fontSize: 14 },

  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 12,
    gap: 12,
  },
  quickActionCard: {
    width: (SCREEN_WIDTH - 60) / 2,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  quickActionGradient: { padding: 20, alignItems: 'center', justifyContent: 'center', minHeight: 100 },
  quickActionLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '600', marginTop: 8, textAlign: 'center' },
});
