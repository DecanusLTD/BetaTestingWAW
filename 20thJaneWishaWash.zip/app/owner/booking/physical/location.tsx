import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  Animated,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import StatusDot, { StatusType } from '../../../../src/components/shared/StatusDot';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

type LatLng = { latitude: number; longitude: number };

// Local extension for this screen (no need to touch shared Hub type)
type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [radiusMiles, setRadiusMiles] = useState(10);

  useEffect(() => {
    loadHubs();
    getCurrentLocation();
  }, []);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered');

      if (error) throw error;
      setHubs(normalizeHubs(data || []));
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    } catch {}
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;

      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;

      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    if (!coords) return hubs;
    return hubs.filter((hub) => {
      const d = calculateDistance(hub);
      return d && Number(d) <= radiusMiles;
    });
  }, [hubs, coords, radiusMiles, calculateDistance]);

  const getStatusType = (status?: string | null): StatusType => {
    if (!status) return 'offline';
    if (status.toLowerCase().includes('busy')) return 'busy';
    if (status.toLowerCase().includes('available')) return 'available';
    return 'offline';
  };

  const renderFeatureChips = (hub: HubRow) => {
    const chips: Array<{ key: string; icon: keyof typeof Ionicons.glyphMap; label: string }> = [];
    if (hub.eco_washing) chips.push({ key: 'eco', icon: 'leaf-outline', label: 'Eco washing' });
    if (hub.detailing_offered) chips.push({ key: 'detail', icon: 'sparkles-outline', label: 'Detailing' });

    if (chips.length === 0) return null;

    return (
      <View style={styles.chipsRow}>
        {chips.map((c) => (
          <View key={c.key} style={styles.chip}>
            <Ionicons name={c.icon} size={14} color={SKY} />
            <Text style={styles.chipText}>{c.label}</Text>
          </View>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Choose a hub" />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Finding nearby hubs…</Text>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + (isSmallScreen ? 16 : 24),
            },
          ]}
        >
          {/* Radius selector */}
          <GlassCard style={styles.radiusCard} accountType="customer">
            <View style={styles.radiusHeader}>
              <Ionicons name="radio-outline" size={20} color={SKY} />
              <Text style={styles.radiusTitle}>Search radius</Text>
              <Text style={styles.radiusValue}>{radiusMiles} mi</Text>
            </View>

            <Slider
              minimumValue={1}
              maximumValue={50}
              step={1}
              value={radiusMiles}
              onValueChange={setRadiusMiles}
              minimumTrackTintColor={SKY}
              maximumTrackTintColor="rgba(255,255,255,0.2)"
              thumbTintColor={SKY}
            />
          </GlassCard>

          {filteredHubs.map((hub) => {
            const distance = calculateDistance(hub);
            return (
              <GlassCard key={hub.id} style={styles.hubCard} accountType="customer">
                <Text style={styles.hubName}>{hub.name}</Text>
                <Text style={styles.hubAddress}>{hub.address}</Text>

                {/* NEW: eco/detailing chips */}
                {renderFeatureChips(hub)}

                <View style={styles.hubMetaRow}>
                  {distance && <Text style={styles.metaText}>{distance} mi away</Text>}
                  <StatusDot status={getStatusType(hub.status)} size={12} />
                </View>

                <TouchableOpacity
                  style={styles.selectButton}
                  onPress={() =>
                    router.push({
                      pathname: '/owner/booking/physical/service',
                      params: { locationId: hub.id, vehicleId },
                    })
                  }
                >
                  <Text style={styles.selectButtonText}>Select hub</Text>
                  <Ionicons name="arrow-forward" size={16} color={BG} />
                </TouchableOpacity>
              </GlassCard>
            );
          })}

          {filteredHubs.length === 0 && (
            <View style={styles.emptyState}>
              <Ionicons name="map-outline" size={48} color={SKY} />
              <Text style={styles.emptyText}>No hubs within {radiusMiles} miles</Text>
            </View>
          )}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: '#E5E7EB' },

  scrollContent: {
    paddingHorizontal: isSmallScreen ? 12 : 20,
    gap: 16,
    paddingBottom: 40,
  },

  radiusCard: { padding: 16 },
  radiusHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  radiusTitle: { color: LIGHT_SKY, fontSize: 14, fontWeight: '700', flex: 1 },
  radiusValue: { color: SKY, fontWeight: '800' },

  hubCard: { padding: 16 },
  hubName: { color: '#F9FAFB', fontSize: 18, fontWeight: '700' },
  hubAddress: { color: 'rgba(249,250,251,0.85)', marginBottom: 8 },

  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 10,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  chipText: { color: 'rgba(249,250,251,0.88)', fontSize: 12, fontWeight: '800' },

  hubMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  metaText: { color: '#E5E7EB' },

  selectButton: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  selectButtonText: { color: BG, fontWeight: '700' },

  emptyState: { alignItems: 'center', marginTop: 40 },
  emptyText: { color: '#F9FAFB', marginTop: 12, fontSize: 16, fontWeight: '700' },
});
