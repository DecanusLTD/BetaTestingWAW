import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../app/components/NavigationTab';

const SKY = colors.SKY;
const BG = colors.BG;
const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SLOT_WIDTH = 140;

type LocationRow = {
  id: string;
  name: string | null;
  address: string | null;
};

type OpeningHoursRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null; // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number; // 30
};

type LocationServiceRow = {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
};

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

function parseHHMM(raw: string | null): { h: number; m: number } | null {
  const s = String(raw || '').trim();
  if (!s) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return { h: hh, m: mm };
}

// Convert JS getDay (0=Sun..6=Sat) -> our DB day (0=Mon..6=Sun)
function jsDayToDbDay(jsDay: number) {
  // Sun(0)->6, Mon(1)->0, Tue(2)->1 ... Sat(6)->5
  return (jsDay + 6) % 7;
}

function buildSlotsFromHours(hours: OpeningHoursRow[], daysAhead = 7) {
  const now = new Date();
  const slots: string[] = [];

  // map day -> hours row
  const byDay = new Map<number, OpeningHoursRow>();
  for (const r of hours) byDay.set(r.day_of_week, r);

  for (let offset = 0; offset < daysAhead; offset++) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + offset);

    const dbDay = jsDayToDbDay(d.getDay());
    const row = byDay.get(dbDay);
    if (!row || !row.is_open) continue;

    const open = parseHHMM(row.open_time);
    const close = parseHHMM(row.close_time);
    const step = Number(row.slot_minutes || 30);

    if (!open || !close) continue;
    if (!Number.isFinite(step) || step <= 0) continue;

    const start = new Date(d);
    start.setHours(open.h, open.m, 0, 0);

    const end = new Date(d);
    end.setHours(close.h, close.m, 0, 0);

    // if close <= open, ignore (bad config)
    if (end.getTime() <= start.getTime()) continue;

    // generate slots up to (but not including) end
    for (let t = start.getTime(); t + step * 60_000 <= end.getTime(); t += step * 60_000) {
      const slotDate = new Date(t);

      // don't show past slots for today
      if (slotDate.getTime() < now.getTime() + 2 * 60_000) continue;

      slots.push(slotDate.toISOString());
    }
  }

  // sort ascending
  slots.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  return slots;
}

export default function PhysicalSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
  }>();

  const locationId = params.locationId as string | undefined;
  const serviceId = params.serviceId as string | undefined;
  const vehicleId = params.vehicleId as string | undefined;
  const washType = params.washType as string | undefined;

  const [location, setLocation] = useState<LocationRow | null>(null);
  const [serviceRow, setServiceRow] = useState<LocationServiceRow | null>(null);

  const [loading, setLoading] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(true);

  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);

  // fallback (if your booking flow still passes a local serviceId from constants)
  const fallbackService = useMemo(
    () => serviceOptions.find((opt) => opt.id === serviceId),
    [serviceId]
  );

  useEffect(() => {
    if (!locationId) return;

    const loadAll = async () => {
      try {
        setLoading(true);

        const [{ data: loc, error: locErr }, svcRes] = await Promise.all([
          supabase
            .from('car_wash_locations')
            .select('id,name,address')
            .eq('id', locationId)
            .maybeSingle(),
          serviceId
            ? supabase
                .from('location_services')
                .select('id,location_id,service_name,is_enabled,price,duration_minutes')
                .eq('id', serviceId)
                .maybeSingle()
            : Promise.resolve({ data: null, error: null } as any),
        ]);

        if (locErr) throw locErr;

        setLocation((loc as LocationRow) ?? null);

        // Only accept service if it belongs to this location (prevents mismatched IDs)
        if (svcRes?.error) {
          // don’t hard fail, we can still show fallback service from constants
          console.warn('[PhysicalSchedule] service load error:', svcRes.error.message);
          setServiceRow(null);
        } else {
          const svc = (svcRes?.data as LocationServiceRow | null) ?? null;
          if (svc && svc.location_id === locationId) setServiceRow(svc);
          else setServiceRow(null);
        }
      } catch (e: any) {
        console.error('[PhysicalSchedule] loadAll error:', e);
        Alert.alert('Error', e?.message || 'Failed to load booking info');
        setLocation(null);
        setServiceRow(null);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [locationId, serviceId]);

  const loadSlots = async () => {
    if (!locationId) return;

    try {
      setLoadingSlots(true);

      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('id,location_id,day_of_week,is_open,open_time,close_time,slot_minutes')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as OpeningHoursRow[];
      const slots = buildSlotsFromHours(rows, 7);

      setTimeSlots(slots);

      // if previously selected slot is no longer valid
      if (selectedSlot && !slots.includes(selectedSlot)) setSelectedSlot(null);
    } catch (e: any) {
      console.error('[PhysicalSchedule] loadSlots error:', e);

      // If table doesn't exist yet / not migrated in this env, show a helpful empty state
      setTimeSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  useEffect(() => {
    loadSlots();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  const handleContinue = async () => {
    if (!serviceId || !selectedSlot || !locationId || !vehicleId) return;
    await hapticFeedback('medium');

    router.push({
      pathname: '/owner/booking/physical/confirm',
      params: {
        locationId,
        serviceId,
        vehicleId,
        washType: washType || '',
        scheduledAt: selectedSlot,
      },
    });
  };

  if (!locationId || !serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const getServiceIcon = () => {
    const name = (serviceRow?.service_name || fallbackService?.name || '').toLowerCase();
    if (name.includes('interior')) return 'car-sport-outline';
    if (name.includes('detail')) return 'sparkles-outline';
    if (name.includes('premium')) return 'diamond-outline';
    if (name.includes('wash')) return 'water-outline';
    if (name.includes('bronze') || name.includes('silver') || name.includes('gold') || name.includes('platinum'))
      return 'medal-outline';
    return 'pricetag-outline';
  };

  const serviceTitle = serviceRow?.service_name || fallbackService?.name || 'Service';
  const servicePrice =
    serviceRow?.price !== null && serviceRow?.price !== undefined
      ? Number(serviceRow.price).toFixed(2)
      : fallbackService?.price
        ? String(fallbackService.price)
        : '—';

  const serviceDuration =
    serviceRow?.duration_minutes !== null && serviceRow?.duration_minutes !== undefined
      ? `${serviceRow.duration_minutes} min`
      : fallbackService?.dur || '';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Pick time slot" />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + 120,
            },
          ]}
        >
          {/* Location (from DB) */}
          {location && (
            <GlassCard style={styles.hubSummary} accountType="customer">
              <Text style={styles.label}>Location</Text>
              <Text style={styles.title}>{location.name || 'Location'}</Text>
              {!!location.address && <Text style={styles.sub}>{location.address}</Text>}
            </GlassCard>
          )}

          {/* Service (prefer DB location_services, fallback to constants) */}
          <GlassCard style={styles.serviceCard} accountType="customer">
            <View style={styles.serviceHeader}>
              <View style={styles.iconWrap}>
                <Ionicons name={getServiceIcon() as any} size={18} color={SKY} />
              </View>

              <View style={{ flex: 1 }}>
                <Text style={styles.label}>Service</Text>
                <Text style={styles.title} numberOfLines={1}>
                  {serviceTitle}
                </Text>
              </View>

              <View style={styles.pricePill}>
                <Text style={styles.priceText}>£{servicePrice}</Text>
              </View>
            </View>

            {!!fallbackService?.desc && !serviceRow && <Text style={styles.sub}>{fallbackService.desc}</Text>}

            <View style={styles.metaRow}>
              {!!serviceDuration && <Text style={styles.meta}>⏱ {serviceDuration}</Text>}
              {washType && <Text style={styles.meta}>🌱 {washType}</Text>}
            </View>
          </GlassCard>

          {/* Time slots (from opening hours DB) */}
          <View style={styles.section}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Choose a time slot</Text>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadSlots();
                }}
                activeOpacity={0.85}
                style={styles.refreshBtn}
              >
                {loadingSlots ? (
                  <ActivityIndicator size="small" color={SKY} />
                ) : (
                  <Ionicons name="refresh" size={18} color={SKY} />
                )}
              </TouchableOpacity>
            </View>

            {loadingSlots ? (
              <View style={[styles.center, { height: 120 }]}>
                <ActivityIndicator size="large" color={SKY} />
              </View>
            ) : timeSlots.length === 0 ? (
              <GlassCard style={styles.emptySlotsCard} accountType="customer">
                <Ionicons name="time-outline" size={22} color={SKY} style={{ opacity: 0.9 }} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.emptyTitle}>No slots available</Text>
                  <Text style={styles.emptySub}>
                    This location hasn’t set opening hours yet (or they’re closed for the next 7 days).
                  </Text>
                </View>
              </GlassCard>
            ) : (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.slotRow}>
                {timeSlots.map((slot) => {
                  const date = new Date(slot);
                  const isSelected = selectedSlot === slot;

                  return (
                    <GlassCard
                      key={slot}
                      onPress={() => setSelectedSlot(slot)}
                      style={[styles.slotCard, isSelected && styles.slotSelected]}
                      accountType="customer"
                    >
                      <Text style={styles.slotDay}>
                        {date.toLocaleDateString('en-GB', {
                          weekday: 'short',
                          day: 'numeric',
                          month: 'short',
                        })}
                      </Text>
                      <Text style={styles.slotTime}>
                        {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                      </Text>

                      {isSelected && (
                        <View style={styles.tick}>
                          <Ionicons name="checkmark" size={12} color={BG} />
                        </View>
                      )}
                    </GlassCard>
                  );
                })}
              </ScrollView>
            )}
          </View>
        </ScrollView>
      )}

      {/* Fixed footer */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + TAB_BAR_TOTAL_HEIGHT }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedSlot}
          activeOpacity={0.85}
          style={[styles.continueButton, !selectedSlot && { opacity: 0.5 }]}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color={BG} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  scrollContent: {
    paddingHorizontal: isSmallScreen ? 14 : 20,
    gap: 16,
  },

  label: {
    color: 'rgba(135,206,235,0.9)',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  title: { color: '#F9FAFB', fontSize: 16, fontWeight: '800' },
  sub: { color: 'rgba(249,250,251,0.85)', fontSize: 13, marginTop: 4 },

  hubSummary: { padding: 16 },
  serviceCard: { padding: 16 },

  serviceHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pricePill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: SKY,
    borderRadius: 999,
  },
  priceText: { color: BG, fontWeight: '900', fontSize: 12 },

  metaRow: { flexDirection: 'row', gap: 12, marginTop: 10 },
  meta: { color: '#E5E7EB', fontSize: 12, fontWeight: '700' },

  section: { gap: 12, paddingTop: 8 },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },

  refreshBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(135,206,235,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  slotRow: { paddingVertical: 4, gap: 12 },
  slotCard: {
    width: SLOT_WIDTH,
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  slotSelected: {
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  slotDay: { color: '#E5E7EB', fontSize: 12, fontWeight: '700' },
  slotTime: { color: '#F9FAFB', fontSize: 16, fontWeight: '900', marginTop: 2 },

  tick: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },

  emptySlotsCard: {
    padding: 14,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '900' },
  emptySub: { color: 'rgba(249,250,251,0.75)', fontSize: 12, marginTop: 4, lineHeight: 18 },

  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: isSmallScreen ? 14 : 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  continueButton: {
    backgroundColor: SKY,
    borderRadius: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueText: { color: BG, fontSize: 16, fontWeight: '900' },
});
