import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Platform,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useAuth } from "../../../src/providers/enhanced-auth-context";
import { supabase } from "../../../src/lib/supabase";
import { hapticFeedback } from "../../../src/services/HapticFeedbackService";
import GlassCard from "../../../src/components/booking/GlassCard";
import CountdownTimer from "../../../src/components/booking/CountdownTimer";
import { getServiceDisplayName } from "../../../src/utils/serviceNameMapper";
import AppHeader, { HEADER_CONTENT_OFFSET } from "../../../src/components/shared/AppHeader";
import { customerTheme } from "../../../src/constants/customerTheme";
import { colors } from "../../../src/constants/colors";
import LoadingScreen from "../../../src/components/LoadingScreen";

// Stripe (native only)
let useStripe: any = null;
if (Platform.OS !== "web") {
  try {
    const stripe = require("@stripe/stripe-react-native");
    useStripe = stripe.useStripe;
  } catch (e) {
    console.warn("Stripe not available:", e);
    useStripe = null;
  }
}

const { width } = Dimensions.get("window");
const SKY = colors.SKY;

type PrepState = "idle" | "preparing" | "ready" | "error";

function asStringParam(v: unknown): string | null {
  if (!v) return null;
  if (Array.isArray(v)) return typeof v[0] === "string" ? v[0] : null;
  return typeof v === "string" ? v : null;
}

function moneyGBP(value: any) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0.00";
  return n.toFixed(2);
}

export default function BookingPayment() {
  const { user } = useAuth();
  const params = useLocalSearchParams();

  // ✅ handles string | string[] | undefined
  const bookingId = useMemo(() => asStringParam((params as any)?.bookingId), [params]);

  const stripeHook = useStripe ? useStripe() : null;
  const initPaymentSheet = stripeHook?.initPaymentSheet;
  const presentPaymentSheet = stripeHook?.presentPaymentSheet;

  const [booking, setBooking] = useState<any | null>(null);
  const [loadingBooking, setLoadingBooking] = useState(false);

  const [processing, setProcessing] = useState(false);
  const [countdown] = useState(600);

  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [prepState, setPrepState] = useState<PrepState>("idle");
  const [lastError, setLastError] = useState<string | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;
  const successAnim = useRef(new Animated.Value(0)).current;

  const sheetReady = prepState === "ready";

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(cardAnim, { toValue: 1, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId]);

  useEffect(() => {
    // Auto-prepare once booking is loaded
    if (booking?.id && user?.id && Platform.OS !== "web") {
      preparePaymentSheet();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking?.id, user?.id]);

  const loadBooking = async () => {
    if (!bookingId) return;

    try {
      setLoadingBooking(true);
      setLastError(null);

      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("id", bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
    } catch (e: any) {
      console.error("Error loading booking:", e);
      setBooking(null);
      setPrepState("error");
      setLastError(
        e?.message ||
          "Couldn’t load booking. If this is your booking, check RLS policies allow the customer to select it."
      );
    } finally {
      setLoadingBooking(false);
    }
  };

  const extractClientSecret = (data: any): string | null => {
    return (
      data?.clientSecret ??
      data?.client_secret ??
      data?.paymentIntentClientSecret ??
      data?.payment_intent_client_secret ??
      data?.paymentIntent?.clientSecret ??
      data?.paymentIntent?.client_secret ??
      data?.payment_intent?.client_secret ??
      null
    );
  };

  const preparePaymentSheet = async () => {
    if (Platform.OS === "web") return;
    if (!booking || !user?.id || !bookingId) return;

    if (!initPaymentSheet || !presentPaymentSheet) {
      const msg =
        "Stripe not initialised. Check StripeProvider is mounted at the app root, and that @stripe/stripe-react-native is installed correctly.";
      console.error("[Payment] Stripe hook missing:", { initPaymentSheet, presentPaymentSheet });
      setLastError(msg);
      setPrepState("error");
      return;
    }

    setPrepState("preparing");
    setLastError(null);
    setClientSecret(null);

    const priceNumber = Number(booking.price);
    const amountPence = Math.round((Number.isFinite(priceNumber) ? priceNumber : 0) * 100);

    console.log("[Payment] preparing", {
      bookingId,
      price: booking.price,
      amountPence,
      platform: Platform.OS,
    });

    if (!amountPence || Number.isNaN(amountPence) || amountPence < 50) {
      const msg = `Invalid amount: ${amountPence}. Check booking.price is a number in pounds (e.g. 12.99).`;
      console.error("[Payment]", msg, booking?.price);
      setLastError(msg);
      setPrepState("error");
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke("hyper-endpoint", {
        body: {
          bookingId,
          amount: amountPence,
          currency: "gbp",
          customerId: user.id,
          description: `Wish a Wash booking ${bookingId}`,
        },
      });

      console.log("[Payment] edge response", { data, error });

      if (error) {
        const msg = error?.message || "Edge function failed creating payment intent.";
        console.error("[Payment] Edge function error:", error);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      const cs = extractClientSecret(data);
      if (!cs) {
        const msg =
          "No client secret returned. Your edge function response shape likely differs. Check logs for data keys.";
        console.error("[Payment] Missing client secret. Data:", data);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      setClientSecret(cs);

      const { error: sheetError } = await initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: "Wish a Wash",
        returnURL: "waw://stripe-redirect",
        style: "automatic",
      });

      console.log("[Payment] initPaymentSheet result", sheetError);

      if (sheetError) {
        const msg = sheetError.message || "initPaymentSheet failed.";
        console.error("[Payment] initPaymentSheet error:", sheetError);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      setPrepState("ready");
    } catch (e: any) {
      const msg = e?.message || "Unexpected error preparing payment.";
      console.error("[Payment] preparePaymentSheet exception:", e);
      setLastError(msg);
      setPrepState("error");
    }
  };

  const markBookingPaid = async () => {
    if (!bookingId) return;

    const { error } = await supabase
      .from("bookings")
      .update({
        status: "confirmed",
        payment_completed_at: new Date().toISOString(),
      })
      .eq("id", bookingId);

    if (error) throw error;
  };

  const handlePayment = async () => {
    if (!bookingId) {
      Alert.alert("Missing booking", "No bookingId was passed to payment screen.");
      return;
    }
    if (!booking || !user?.id) return;
    if (processing) return;

    if (Platform.OS === "web") {
      Alert.alert("Not supported", "This payment flow is native-only.");
      return;
    }

    if (!presentPaymentSheet) {
      Alert.alert("Stripe not ready", "Stripe is not initialised in the app.");
      return;
    }

    if (!sheetReady || !clientSecret) {
      const msg =
        lastError ||
        (prepState === "preparing" ? "Payment is still preparing…" : "Payment isn’t ready. Tap Retry.");
      Alert.alert("Hold up", msg);
      return;
    }

    setProcessing(true);
    await hapticFeedback("medium");

    try {
      console.log("[Payment] presenting sheet…");
      const { error } = await presentPaymentSheet();
      console.log("[Payment] presentPaymentSheet result:", error);

      if (error) {
        if (error.code === "Canceled") {
          setProcessing(false);
          return;
        }
        throw error;
      }

      await markBookingPaid();

      Animated.spring(successAnim, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }).start();

      setTimeout(() => {
        router.replace({
          pathname: "/owner/booking/tracking",
          params: { bookingId },
        });
      }, 1200);
    } catch (e: any) {
      console.error("[Payment] failed:", e);
      Alert.alert("Payment Failed", e?.message || "Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const handleCountdownComplete = () => {
    Alert.alert("Payment Timeout", "The payment window has expired. Please try again.", [
      { text: "OK", onPress: () => router.back() },
    ]);
  };

  // ✅ explicit missing bookingId UI (this is the real “missing booking info” case)
  if (!bookingId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: "center", alignItems: "center", padding: 20 }]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16, textAlign: "center" }}>
          Missing bookingId
        </Text>
        <Text style={{ color: "rgba(255,255,255,0.75)", marginTop: 8, textAlign: "center" }}>
          Payment screen was opened without a booking reference.
        </Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginTop: 14, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)" }}
        >
          <Text style={{ color: SKY, fontWeight: "800" }}>Go back</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  if (loadingBooking && !booking) return <LoadingScreen />;

  // ✅ booking failed to load UI
  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Payment" />
        <View style={{ padding: 20, paddingTop: HEADER_CONTENT_OFFSET + 20 }}>
          <GlassCard style={{ padding: 18 }} accountType="customer">
            <Text style={{ color: "#F9FAFB", fontSize: 16, fontWeight: "900" }}>Couldn’t load booking</Text>
            <Text style={{ color: "rgba(249,250,251,0.8)", marginTop: 8, lineHeight: 18 }}>
              {lastError || "Unknown error."}
            </Text>

            <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
              <TouchableOpacity
                onPress={loadBooking}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)", alignItems: "center" }}
              >
                <Text style={{ color: SKY, fontWeight: "900" }}>Retry</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => router.back()}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", alignItems: "center" }}
              >
                <Text style={{ color: "#F9FAFB", fontWeight: "900" }}>Back</Text>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      </SafeAreaView>
    );
  }

  const statusText =
    prepState === "ready"
      ? "Payment ready"
      : prepState === "preparing"
      ? "Preparing payment…"
      : prepState === "error"
      ? "Payment setup failed"
      : "Tap Retry to prepare";

  const totalDisplay = moneyGBP(booking.price);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <AppHeader title="Payment" />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.timerContainer}>
            <CountdownTimer seconds={countdown} onComplete={handleCountdownComplete} size="medium" />
          </View>

          <GlassCard style={styles.summaryCard} accountType="customer">
            <View style={styles.summaryHeader}>
              <Ionicons name="receipt-outline" size={24} color={SKY} />
              <Text style={styles.summaryTitle}>Booking Summary</Text>
            </View>

            <View style={styles.summaryContent}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Service</Text>
                <Text style={styles.summaryValue}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
              </View>

              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Location</Text>
                <Text style={styles.summaryValue} numberOfLines={2}>
                  {booking.location_address || "—"}
                </Text>
              </View>

              <View style={[styles.summaryRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>£{totalDisplay}</Text>
              </View>
            </View>
          </GlassCard>

          <Animated.View style={[styles.paymentCardContainer, { transform: [{ scale: cardAnim }] }]}>
            <GlassCard style={styles.paymentCard}>
              <View style={styles.paymentHeader}>
                <Ionicons name="card-outline" size={32} color={SKY} />
                <Text style={styles.paymentTitle}>Pay securely with Stripe</Text>
              </View>

              <View style={styles.readyRow}>
                <View
                  style={[
                    styles.dot,
                    { opacity: sheetReady ? 1 : 0.35, backgroundColor: sheetReady ? "#10B981" : SKY },
                  ]}
                />
                <Text style={styles.readyText}>{statusText}</Text>

                <TouchableOpacity onPress={preparePaymentSheet} style={styles.retryBtn} activeOpacity={0.85}>
                  <Text style={styles.retryText}>{prepState === "preparing" ? "…" : "Retry"}</Text>
                </TouchableOpacity>
              </View>

              {!!lastError && (
                <View style={styles.errorBox}>
                  <Text style={styles.errorTitle}>Debug</Text>
                  <Text style={styles.errorText}>{lastError}</Text>
                </View>
              )}
            </GlassCard>
          </Animated.View>

          <Animated.View
            style={[
              styles.successContainer,
              {
                opacity: successAnim,
                transform: [{ scale: successAnim.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1] }) }],
              },
            ]}
            pointerEvents="none"
          >
            <View style={styles.successCircle}>
              <Ionicons name="checkmark-circle" size={64} color="#10B981" />
            </View>
            <Text style={styles.successText}>Payment Successful!</Text>
          </Animated.View>

          <TouchableOpacity
            onPress={handlePayment}
            style={[styles.payButton, (!sheetReady || processing) && { opacity: 0.6 }]}
            activeOpacity={0.85}
            disabled={!sheetReady || processing}
          >
            <LinearGradient colors={["#10B981", "#059669"]} style={styles.payGradient}>
              <Ionicons name="lock-closed" size={20} color="#FFFFFF" />
              <Text style={styles.payText}>
                {processing ? "Processing…" : `Pay £${totalDisplay}`}
              </Text>
            </LinearGradient>
          </TouchableOpacity>

          <View style={{ height: 24 }} />
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  content: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  timerContainer: { alignItems: "center", marginBottom: 24 },

  summaryCard: { padding: 20, marginBottom: 20 },
  summaryHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 16 },
  summaryTitle: { color: "#F9FAFB", fontSize: 18, fontWeight: "bold" },
  summaryContent: { gap: 12 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  summaryLabel: { color: "#9CA3AF", fontSize: 14 },
  summaryValue: { color: "#F9FAFB", fontSize: 14, fontWeight: "600", textAlign: "right", flex: 1, marginLeft: 16 },

  totalRow: { marginTop: 8, paddingTop: 12, borderTopWidth: 1, borderTopColor: "rgba(135,206,235,0.2)" },
  totalLabel: { color: "#F9FAFB", fontSize: 18, fontWeight: "bold" },
  totalValue: { color: SKY, fontSize: 24, fontWeight: "bold" },

  paymentCardContainer: { marginBottom: 24 },
  paymentCard: { padding: 20 },
  paymentHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  paymentTitle: { color: "#F9FAFB", fontSize: 18, fontWeight: "bold" },

  readyRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  dot: { width: 10, height: 10, borderRadius: 10 },
  readyText: { color: "#F9FAFB", fontSize: 14, flex: 1, opacity: 0.9 },

  retryBtn: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.35)",
  },
  retryText: { color: SKY, fontWeight: "700" },

  errorBox: {
    marginTop: 14,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(239,68,68,0.35)",
    backgroundColor: "rgba(239,68,68,0.08)",
  },
  errorTitle: { color: "#FCA5A5", fontWeight: "800", marginBottom: 6 },
  errorText: { color: "#FECACA", fontSize: 12, lineHeight: 16 },

  successContainer: { position: "absolute", top: "50%", left: 0, right: 0, alignItems: "center", zIndex: 1000 },
  successCircle: { marginBottom: 16 },
  successText: { color: "#10B981", fontSize: 20, fontWeight: "bold" },

  payButton: {
    borderRadius: 16,
    overflow: "hidden",
    elevation: 8,
    shadowColor: "#10B981",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  payGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 18,
    paddingHorizontal: 32,
    gap: 8,
  },
  payText: { color: "#FFFFFF", fontSize: 18, fontWeight: "bold" },
});
