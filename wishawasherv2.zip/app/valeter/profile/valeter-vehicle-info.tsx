import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
  Image,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { DVLA_CONFIG } from '../../../src/config/dvla';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

// ✅ backwards-compatible mediaTypes for expo-image-picker
const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  if (anyPicker?.MediaType?.Images) return anyPicker.MediaType.Images;
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return anyPicker?.MediaTypeOptions?.All ?? undefined;
};

const cleanUrl = (u?: string | null) => {
  if (!u) return null;
  return String(u).split('?')[0];
};

const guessMime = (uri: string) => {
  const lower = uri.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
};

const safeDate = (d?: any) => {
  if (!d) return null;
  // DVLA gives YYYY-MM-DD. Keep it as string for DB date columns.
  const s = String(d).trim();
  return s.length >= 10 ? s.slice(0, 10) : s;
};

const formatDate = (d?: string | null) => {
  if (!d) return null;
  // keep it simple: YYYY-MM-DD -> DD/MM/YYYY
  const s = String(d).slice(0, 10);
  const [y, m, day] = s.split('-');
  if (!y || !m || !day) return s;
  return `${day}/${m}/${y}`;
};

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;

  // ✅ DVLA fields
  tax_status?: string | null;
  tax_due_date?: string | null; // date column
  mot_status?: string | null;
  mot_expiry_date?: string | null; // date column
}

type EntryMode = 'dvla' | 'manual';

export default function ValeterVehicleInfo() {
  const router = useRouter();
  const { user } = useAuth();

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [entryMode, setEntryMode] = useState<EntryMode>('dvla');
  const [dvlaReg, setDvlaReg] = useState('');
  const [dvlaLoading, setDvlaLoading] = useState(false);

  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user?.id]);

  useEffect(() => {
    if (profile?.vehicle_registration) setDvlaReg(profile.vehicle_registration);
    if (profile?.vehicle_photo_url) setPhotoPreview(`${cleanUrl(profile.vehicle_photo_url)}?v=${Date.now()}`);
  }, [profile?.vehicle_registration, profile?.vehicle_photo_url]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);

      const { data, error } = await supabase
        .from('valeter_profiles')
        .select(
          'user_id, vehicle_make, vehicle_model, vehicle_registration, vehicle_photo_url, tax_status, tax_due_date, mot_status, mot_expiry_date'
        )
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile(data as any);
      } else {
        const newProfile: Partial<ValeterProfileData> = { user_id: user!.id };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created as any);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const dvlaLookup = async (regRaw?: string) => {
    const reg = (regRaw ?? dvlaReg).replace(/\s/g, '').toUpperCase();

    if (!reg) {
      Alert.alert('Missing registration', 'Enter a registration first.');
      return;
    }

    setDvlaLoading(true);

    try {
      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': DVLA_CONFIG.apiKey,
        },
        body: JSON.stringify({
          registrationNumber: reg,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        console.error('[DVLA] error response:', data);
        throw new Error(data?.message || 'DVLA lookup failed');
      }

      // ✅ DVLA response fields
      const make = data.make;
      const model = data.model;

      // ✅ Tax + MOT fields
      const taxStatus = data.taxStatus; // "Taxed" / "Untaxed" etc
      const taxDueDate = safeDate(data.taxDueDate); // YYYY-MM-DD
      const motStatus = data.motStatus; // "Valid" / "Not valid" / "No details held" etc
      const motExpiryDate = safeDate(data.motExpiryDate); // YYYY-MM-DD

      if (!make && !model && !taxStatus && !motStatus) {
        throw new Error('No vehicle data returned from DVLA');
      }

      setProfile((prev) =>
        prev
          ? {
              ...prev,
              vehicle_registration: reg,
              vehicle_make: make ?? prev.vehicle_make,
              vehicle_model: model ?? prev.vehicle_model,
              tax_status: taxStatus ?? prev.tax_status,
              tax_due_date: taxDueDate ?? prev.tax_due_date,
              mot_status: motStatus ?? prev.mot_status,
              mot_expiry_date: motExpiryDate ?? prev.mot_expiry_date,
            }
          : prev
      );

      await hapticFeedback('light');
    } catch (err: any) {
      console.error('[DVLA lookup failed]', err);
      Alert.alert('DVLA lookup failed', err?.message || 'Could not retrieve vehicle details from DVLA.');
    } finally {
      setDvlaLoading(false);
    }
  };

  const uploadVehiclePhoto = async () => {
    if (!user?.id) return;

    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload a vehicle photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.85,
      } as any);

      if ((result as any).canceled || !(result as any).assets?.[0]?.uri) return;

      const uri = (result as any).assets[0].uri as string;
      setPhotoPreview(uri);
      setPhotoUploading(true);

      const mime = guessMime(uri);
      const ext = mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
      const path = `valeter-vehicles/${user.id}/vehicle.${ext}`;

      // ✅ upload as ArrayBuffer (reliable in RN)
      const ab = await (await fetch(uri)).arrayBuffer();

      const { error: uploadErr } = await supabase.storage.from('uploads').upload(path, ab, {
        contentType: mime,
        upsert: true,
        cacheControl: '3600',
      });

      if (uploadErr) throw uploadErr;

      const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(path);
      const publicUrl = publicData?.publicUrl ? `${cleanUrl(publicData.publicUrl)}?v=${Date.now()}` : null;
      if (!publicUrl) throw new Error('Could not create public URL for uploaded photo.');

      setPhotoPreview(publicUrl);

      // Save onto profile (requires `vehicle_photo_url` column)
      const { error: updErr } = await supabase
        .from('valeter_profiles')
        .update({ vehicle_photo_url: cleanUrl(publicUrl) })
        .eq('user_id', user.id);

      if (updErr) {
        console.warn('[vehicle_photo_url] update failed', updErr);
      } else {
        setProfile((p) => (p ? { ...p, vehicle_photo_url: cleanUrl(publicUrl) } : p));
      }

      await hapticFeedback('light');
    } catch (e: any) {
      console.error('[photo] upload failed:', e);
      Alert.alert('Upload failed', e?.message || 'Could not upload vehicle photo.');
      setPhotoPreview(profile?.vehicle_photo_url ? `${cleanUrl(profile.vehicle_photo_url)}?v=${Date.now()}` : null);
    } finally {
      setPhotoUploading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);

      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          vehicle_make: profile.vehicle_make ?? null,
          vehicle_model: profile.vehicle_model ?? null,
          vehicle_registration: profile.vehicle_registration ?? null,

          // ✅ persist DVLA status fields too
          tax_status: profile.tax_status ?? null,
          tax_due_date: profile.tax_due_date ?? null,
          mot_status: profile.mot_status ?? null,
          mot_expiry_date: profile.mot_expiry_date ?? null,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Vehicle information updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save vehicle information');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load vehicle information</Text>
        </View>
      </SafeAreaView>
    );
  }

  const modeActiveStyle = (mode: EntryMode) => ({
    backgroundColor: entryMode === mode ? 'rgba(135,206,235,0.18)' : 'rgba(255,255,255,0.06)',
    borderColor: entryMode === mode ? 'rgba(135,206,235,0.5)' : 'rgba(135,206,235,0.22)',
  });

  const taxText =
    profile.tax_status
      ? `${profile.tax_status}${profile.tax_due_date ? ` (due ${formatDate(profile.tax_due_date)})` : ''}`
      : 'Unknown';

  const motText =
    profile.mot_status
      ? `${profile.mot_status}${profile.mot_expiry_date ? ` (expires ${formatDate(profile.mot_expiry_date)})` : ''}`
      : 'Unknown';

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Vehicle Information"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            activeOpacity={0.7}
            style={{ padding: 8 }}
          >
            <Ionicons name={isEditing ? 'close' : 'create'} size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40 }}
      >
        {/* ✅ Entry Mode */}
        {isEditing && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>How do you want to add details?</Text>
            <View style={styles.modeRow}>
              <TouchableOpacity
                style={[styles.modeBtn, modeActiveStyle('dvla')]}
                onPress={async () => {
                  await hapticFeedback('light');
                  setEntryMode('dvla');
                }}
                activeOpacity={0.85}
              >
                <Ionicons name="search" size={16} color={SKY} />
                <Text style={styles.modeBtnText}>Use DVLA</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modeBtn, modeActiveStyle('manual')]}
                onPress={async () => {
                  await hapticFeedback('light');
                  setEntryMode('manual');
                }}
                activeOpacity={0.85}
              >
                <Ionicons name="create" size={16} color={SKY} />
                <Text style={styles.modeBtnText}>Manual</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ✅ Photo Upload */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Photo</Text>

          <View style={styles.photoCard}>
            <View style={styles.photoLeft}>
              <View style={styles.photoThumb}>
                {photoPreview ? (
                  <Image source={{ uri: photoPreview }} style={styles.photoImg} />
                ) : (
                  <Ionicons name="image" size={22} color={SKY} />
                )}
              </View>

              <View style={{ flex: 1 }}>
                <Text style={styles.photoTitle}>{photoPreview ? 'Photo added' : 'No photo yet'}</Text>
                <Text style={styles.photoSub}>
                  {photoPreview ? 'This helps confirm the vehicle on arrival.' : 'Upload a quick snap for reference.'}
                </Text>
              </View>
            </View>

            <TouchableOpacity
              style={[styles.photoBtn, photoUploading && { opacity: 0.6 }]}
              onPress={uploadVehiclePhoto}
              disabled={photoUploading}
              activeOpacity={0.85}
            >
              {photoUploading ? <ActivityIndicator color="#fff" /> : <Ionicons name="cloud-upload" size={18} color="#fff" />}
            </TouchableOpacity>
          </View>
        </View>

        {/* ✅ DVLA Lookup (only when editing + DVLA mode) */}
        {isEditing && entryMode === 'dvla' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>DVLA Lookup</Text>

            <View style={styles.dvlaCard}>
              <View style={{ flex: 1 }}>
                <Text style={styles.dvlaLabel}>Registration</Text>
                <TextInput
                  style={styles.dvlaInput}
                  value={dvlaReg}
                  onChangeText={(t) => {
                    const clean = t.replace(/\s/g, '').toUpperCase();
                    setDvlaReg(clean);
                    setProfile({ ...profile, vehicle_registration: clean });
                  }}
                  placeholder="AB12CDE"
                  placeholderTextColor="rgba(255,255,255,0.55)"
                  autoCapitalize="characters"
                />
              </View>

              <TouchableOpacity
                style={[styles.dvlaBtn, dvlaLoading && { opacity: 0.6 }]}
                onPress={() => dvlaLookup(dvlaReg)}
                disabled={dvlaLoading}
                activeOpacity={0.85}
              >
                {dvlaLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Ionicons name="sparkles" size={16} color="#fff" />
                    <Text style={styles.dvlaBtnText}>Lookup</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>

            <Text style={styles.dvlaHint}>This will auto-fill Make + Model + Tax + MOT (and keeps your manual edits too).</Text>
          </View>
        )}

        {/* Vehicle fields */}
        <View style={styles.section}>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="car" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Make</Text>
              </View>

              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_make || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_make: text })}
                  placeholder={entryMode === 'dvla' ? 'Auto-filled from DVLA' : 'Enter make (e.g., BMW)'}
                  placeholderTextColor="rgba(255,255,255,0.55)"
                  editable={entryMode === 'manual' || !!profile.vehicle_make}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_make || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="car-sport" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Model</Text>
              </View>

              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_model || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_model: text })}
                  placeholder={entryMode === 'dvla' ? 'Auto-filled from DVLA' : 'Enter model (e.g., 3 Series)'}
                  placeholderTextColor="rgba(255,255,255,0.55)"
                  editable={entryMode === 'manual' || !!profile.vehicle_model}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_model || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="receipt" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Registration</Text>
              </View>

              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_registration || ''}
                  onChangeText={(text) => {
                    const cleanReg = text.replace(/\s/g, '').toUpperCase();
                    setProfile({ ...profile, vehicle_registration: cleanReg });
                    setDvlaReg(cleanReg);
                  }}
                  placeholder="Enter UK registration"
                  placeholderTextColor="rgba(255,255,255,0.55)"
                  autoCapitalize="characters"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_registration || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* ✅ DVLA Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>DVLA Status</Text>

          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="card" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Tax</Text>
              </View>
              <Text style={styles.settingValue}>{taxText}</Text>
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="shield-checkmark" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>MOT</Text>
              </View>
              <Text style={styles.settingValue}>{motText}</Text>
            </View>
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
              onPress={handleSaveProfile}
              disabled={isSaving}
            >
              <LinearGradient colors={['#10B981', '#059669']} style={styles.saveButtonGradient}>
                {isSaving ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.saveButtonText}>Save Changes</Text>}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#FFFFFF', marginTop: 16 },

  content: { flex: 1, paddingHorizontal: 20 },

  section: { marginBottom: 20 },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: '800',
    marginBottom: 10,
    letterSpacing: 0.2,
  },

  // Mode
  modeRow: { flexDirection: 'row', gap: 10 },
  modeBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    flexDirection: 'row',
  },
  modeBtnText: { color: '#F9FAFB', fontWeight: '800', fontSize: 13 },

  // Photo
  photoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 12,
  },
  photoLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  photoThumb: {
    width: 54,
    height: 54,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  photoImg: { width: '100%', height: '100%' },
  photoTitle: { color: '#F9FAFB', fontWeight: '800', fontSize: 14 },
  photoSub: { color: SKY, fontWeight: '600', fontSize: 11, marginTop: 2, opacity: 0.9 },
  photoBtn: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: SKY,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },

  // DVLA
  dvlaCard: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-end',
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  dvlaLabel: { color: SKY, fontWeight: '800', fontSize: 12, marginBottom: 6 },
  dvlaInput: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.6)',
    paddingVertical: Platform.OS === 'ios' ? 10 : 6,
    letterSpacing: 1.2,
  },
  dvlaBtn: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#0EA5E9',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dvlaBtnText: { color: '#fff', fontWeight: '900', fontSize: 13 },
  dvlaHint: { marginTop: 8, color: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: '600' },

  // Existing fields
  settingsContainer: { gap: 8 },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  settingIcon: { marginRight: 10, width: 20, textAlign: 'center' },
  settingText: { color: '#F9FAFB', fontSize: 14, fontWeight: '700' },
  settingValue: { color: SKY, fontSize: 13, textAlign: 'right', flex: 1 },
  settingInput: {
    color: '#F9FAFB',
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.6)',
    paddingVertical: 4,
  },

  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveButtonGradient: { paddingVertical: 16, alignItems: 'center' },
  saveButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
