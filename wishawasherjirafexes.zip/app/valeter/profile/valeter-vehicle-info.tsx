import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  Platform,
  Image,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { DVLA_CONFIG } from '../../../src/config/dvla';
import { colors } from '../../../src/constants/colors';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import ValeterScreenHeader, {
  useValeterHeaderContentOffset,
} from '../../../src/components/valeter/ValeterScreenHeader';
import { lightMistElevated, lightMistInput } from '../../../src/constants/accountThemes';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import {
  valeterStripeConnectService,
  type StripeConnectStatus,
} from '../../../src/services/valeterStripeConnectService';

const { height: WINDOW_HEIGHT } = Dimensions.get('window');
const STAGE_HEIGHT = Math.round(Math.min(380, Math.max(260, WINDOW_HEIGHT * 0.42)));
const BUCKET = 'valeter_documents';
const IMAGE_MEDIA_TYPES: any = (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;
  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  return { extRaw, ext, mime };
};

const base64ToUint8Array = (base64: string) => {
  const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

const SKY = colors.SKY ?? '#38BDF8';
const VALETER_BG_FALLBACK: [string, string] = ['#0F172A', '#1E293B'];

// Premium LinkedIn/Uber: flat, elevated cards, strong hierarchy, minimal decoration
const CARD_BG = 'rgba(255,255,255,0.06)';
const CARD_BORDER = 'rgba(255,255,255,0.08)';
const LABEL_MUTED = 'rgba(255,255,255,0.5)';
const VALUE_WHITE = '#F8FAFC';

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;
  tax_status?: string;
  tax_due_date?: string;
  mot_status?: string;
  mot_expiry_date?: string;
}

const formatUkReg = (reg: string) => {
  const r = (reg || '').replace(/\s/g, '').toUpperCase();
  if (!r) return '—';
  if (r.length <= 4) return r;
  return `${r.slice(0, 4)} ${r.slice(4)}`;
};

type ComplianceTone = 'ok' | 'soon' | 'bad' | 'unknown';

const THREE_MONTHS_MS = 1000 * 60 * 60 * 24 * 92;

function parseComplianceDate(raw?: string | null): Date | null {
  if (!raw?.trim()) return null;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getExpiryTone(expiry?: string | null): ComplianceTone | null {
  const date = parseComplianceDate(expiry);
  if (!date) return null;
  const end = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const today = new Date();
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const delta = end - start;
  if (delta < 0) return 'bad';
  if (delta <= THREE_MONTHS_MS) return 'soon';
  return 'ok';
}

function getTaxTone(status?: string | null, dueDate?: string | null): ComplianceTone {
  const s = (status || '').trim().toLowerCase();
  if (s.includes('untaxed') || s === 'sorn' || s.includes('not taxed')) return 'bad';
  const byDate = getExpiryTone(dueDate);
  if (byDate === 'bad') return 'bad';
  if (byDate === 'soon') return 'soon';
  if (s === 'taxed' || byDate === 'ok') return 'ok';
  if (s && s !== 'taxed') return 'bad';
  return 'unknown';
}

function getMotTone(status?: string | null, expiryDate?: string | null): ComplianceTone {
  const s = (status || '').trim().toLowerCase();
  if (s.includes('not valid') || s === 'invalid' || s.includes('expired')) return 'bad';
  const byDate = getExpiryTone(expiryDate);
  if (byDate === 'bad') return 'bad';
  if (byDate === 'soon') return 'soon';
  if (s === 'valid' || byDate === 'ok') return 'ok';
  if (s && s !== 'valid' && !s.includes('no details')) return 'bad';
  return 'unknown';
}

const TONE_COLORS = {
  ok: { border: 'rgba(34,197,94,0.35)', bg: 'rgba(34,197,94,0.12)', dot: '#22C55E', text: '#4ADE80' },
  soon: { border: 'rgba(249,115,22,0.4)', bg: 'rgba(249,115,22,0.12)', dot: '#F97316', text: '#FB923C' },
  bad: { border: 'rgba(239,68,68,0.4)', bg: 'rgba(239,68,68,0.12)', dot: '#EF4444', text: '#F87171' },
  unknown: { border: 'rgba(148,163,184,0.28)', bg: 'rgba(255,255,255,0.04)', dot: '#94A3B8', text: '#F8FAFC' },
} as const;

function ShowroomComplianceChip({
  label,
  value,
  date,
  tone,
}: Readonly<{
  label: string;
  value: string;
  date: string | null;
  tone: ComplianceTone;
}>) {
  const palette = TONE_COLORS[tone] ?? TONE_COLORS.unknown;
  return (
    <View
      style={[
        showroomStyles.chip,
        { borderColor: palette.border, backgroundColor: palette.bg },
      ]}
    >
      <View style={[showroomStyles.chipDot, { backgroundColor: palette.dot }]} />
      <View style={showroomStyles.chipBody}>
        <Text style={showroomStyles.chipLabel}>{label}</Text>
        <Text style={[showroomStyles.chipValue, { color: palette.text }]} numberOfLines={1}>
          {value || '—'}
        </Text>
        {date ? <Text style={showroomStyles.chipDate}>{date}</Text> : null}
      </View>
    </View>
  );
}

const showroomStyles = StyleSheet.create({
  chip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  chipDot: { width: 8, height: 8, borderRadius: 4 },
  chipBody: { flex: 1, minWidth: 0 },
  chipLabel: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  chipValue: { fontSize: 13, fontWeight: '700', marginTop: 1 },
  chipDate: { color: 'rgba(148,163,184,0.75)', fontSize: 10, marginTop: 2, fontWeight: '600' },
});

export default function ValeterVehicleInfo() {
  const { user, isLoading: authLoading } = useAuth();
  const insets = useSafeAreaInsets();
  const headerOffset = useValeterHeaderContentOffset(10);
  const { theme: valeterTheme } = useAccountTheme();
  const gradientBg = (valeterTheme?.background || VALETER_BG_FALLBACK) as [string, string];
  const primary = valeterTheme?.primary ?? SKY;
  const textMain = valeterTheme?.textPrimary ?? VALUE_WHITE;
  const textMuted = valeterTheme?.textSecondary ?? LABEL_MUTED;
  const isLight = valeterTheme?.mode === 'light';
  const placardBg = isLight ? lightMistElevated : undefined;
  const placardBorder = isLight ? 'rgba(232,197,71,0.28)' : undefined;
  const inputBg = isLight ? lightMistInput : CARD_BG;
  const inputBorder = isLight ? 'rgba(158,201,224,0.32)' : CARD_BORDER;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLookingUpDVLA, setIsLookingUpDVLA] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [stripeStatus, setStripeStatus] = useState<StripeConnectStatus | null>(null);
  const [stripeStatusLoading, setStripeStatusLoading] = useState(true);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user?.id]);

  useEffect(() => {
    let mounted = true;
    const loadStripeStatus = async () => {
      if (!user?.id) {
        if (mounted) {
          setStripeStatus(null);
          setStripeStatusLoading(false);
        }
        return;
      }
      try {
        if (mounted) setStripeStatusLoading(true);
        const status = await valeterStripeConnectService.getStatus(user.id);
        if (mounted) setStripeStatus(status.stripeConnectStatus);
      } catch (error) {
        console.warn('[ValeterVehicleInfo] failed to load stripe status', error);
        if (mounted) setStripeStatus('not_started');
      } finally {
        if (mounted) setStripeStatusLoading(false);
      }
    };

    void loadStripeStatus();

    return () => {
      mounted = false;
    };
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();
      if (data) setProfile(data);
      else {
        const { data: created } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user!.id, full_name: ' ' })
          .select()
          .single();
        setProfile(created);
      }
    } catch {
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const lookupDVLA = async (registration: string) => {
    if (!registration?.trim()) {
      Alert.alert('Enter registration', 'Add your registration to look up details.');
      return;
    }
    if (!DVLA_CONFIG.apiKey) {
      Alert.alert('DVLA not configured', 'Missing DVLA API key');
      return;
    }
    try {
      setIsLookingUpDVLA(true);
      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': DVLA_CONFIG.apiKey },
        body: JSON.stringify({ registrationNumber: registration.trim() }),
      });
      if (!res.ok) throw new Error('DVLA lookup failed');
      const data = await res.json();
      setProfile(prev =>
        prev
          ? {
              ...prev,
              vehicle_make: data.make ?? prev.vehicle_make,
              tax_status: data.taxStatus ?? null,
              tax_due_date: data.taxDueDate ?? null,
              mot_status: data.motStatus ?? null,
              mot_expiry_date: data.motExpiryDate ?? null,
            }
          : prev
      );
      await hapticFeedback('success');
      Alert.alert('Updated', 'Tax and MOT details have been updated from DVLA.');
    } catch (e: any) {
      Alert.alert('DVLA lookup failed', e.message || 'Unable to fetch vehicle details');
    } finally {
      setIsLookingUpDVLA(false);
    }
  };

  const uploadVehiclePhotoToStorage = async (uri: string): Promise<string> => {
    if (!user?.id) throw new Error('No user');
    const { extRaw, mime } = getExtAndMimeFromUri(uri);
    const fileName = `vehicle_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
    const storagePath = `vehicles/${user.id}/${fileName}`;
    const base64 = await FileSystem.readAsStringAsync(uri.startsWith('file://') ? uri : uri, { encoding: 'base64' as any });
    const bytes = base64ToUint8Array(base64);
    const { data, error } = await supabase.storage.from(BUCKET).upload(storagePath, bytes, { contentType: mime, upsert: true });
    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('bucket') || msg.includes('not found')) throw new Error("Storage bucket 'valeter_documents' not found.");
      if (msg.includes('policy') || msg.includes('permission')) throw new Error('Upload blocked by storage policy.');
      throw error;
    }
    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? storagePath);
    return pub?.publicUrl ?? storagePath;
  };

  const persistVehiclePhotoUrl = async (publicUrl: string) => {
    if (!user?.id) return;
    const { error } = await supabase
      .from('valeter_profiles')
      .update({ vehicle_photo_url: publicUrl })
      .eq('user_id', user.id);
    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('column') && msg.includes('vehicle_photo')) return;
      throw error;
    }
    setProfile(prev => (prev ? { ...prev, vehicle_photo_url: publicUrl } : null));
  };

  const onVehiclePhotoPicked = async (uri: string) => {
    try {
      setUploadingPhoto(true);
      const publicUrl = await uploadVehiclePhotoToStorage(uri);
      await persistVehiclePhotoUrl(publicUrl);
      hapticFeedback('medium');
      Alert.alert('Done', 'Vehicle photo updated.');
    } catch (e: any) {
      Alert.alert('Upload failed', e?.message ?? 'Please try again.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const showVehiclePhotoOptions = () => {
    hapticFeedback('light');
    Alert.alert(
      'Vehicle photo',
      'Choose a photo of your vehicle',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Take photo',
          onPress: async () => {
            const perm = await ImagePicker.requestCameraPermissionsAsync();
            if (perm.status !== 'granted') {
              Alert.alert('Permission needed', 'Camera access is required to take a photo.');
              return;
            }
            const result = await ImagePicker.launchCameraAsync({
              mediaTypes: IMAGE_MEDIA_TYPES,
              allowsEditing: true,
              aspect: [16, 10],
              quality: 0.85,
            });
            if (!result.canceled && result.assets?.[0]?.uri) await onVehiclePhotoPicked(result.assets[0].uri);
          },
        },
        {
          text: 'Choose from library',
          onPress: async () => {
            const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (perm.status !== 'granted') {
              Alert.alert('Permission needed', 'Photo library access is required.');
              return;
            }
            const result = await ImagePicker.launchImageLibraryAsync({
              mediaTypes: IMAGE_MEDIA_TYPES,
              allowsEditing: true,
              aspect: [16, 10],
              quality: 0.85,
            });
            if (!result.canceled && result.assets?.[0]?.uri) await onVehiclePhotoPicked(result.assets[0].uri);
          },
        },
      ]
    );
  };

  const handleSaveProfile = async () => {
    if (!profile || !user?.id) return;
    try {
      setIsSaving(true);
      const payload: Record<string, unknown> = {
        vehicle_make: profile.vehicle_make,
        vehicle_model: profile.vehicle_model,
        vehicle_registration: profile.vehicle_registration,
        tax_status: profile.tax_status,
        tax_due_date: profile.tax_due_date,
        mot_status: profile.mot_status,
        mot_expiry_date: profile.mot_expiry_date,
      };
      if (profile.vehicle_photo_url !== undefined) payload.vehicle_photo_url = profile.vehicle_photo_url;
      const { error } = await supabase.from('valeter_profiles').update(payload).eq('user_id', user.id);
      if (error) throw error;
      Alert.alert('Saved', 'Vehicle details updated');
      setIsEditing(false);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to save vehicle details');
    } finally {
      setIsSaving(false);
    }
  };

  const formatDate = (d: string | null | undefined) =>
    d ? new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : null;

  const renderLockedState = () => (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader title="My garage" />
      <View style={[styles.lockStateWrap, { paddingTop: headerOffset }]}>
        <View
          style={[
            styles.lockStateCard,
            { borderColor: `${primary}28`, backgroundColor: isLight ? lightMistElevated : 'rgba(255,255,255,0.06)' },
          ]}
        >
          <View style={[styles.lockStateIconWrap, { backgroundColor: `${primary}18`, borderColor: `${primary}35` }]}>
            <Ionicons name="lock-closed" size={28} color={primary} />
          </View>
          <Text style={[styles.lockStateTitle, { color: textMain }]}>Vehicle setup locked</Text>
          <Text style={[styles.lockStateBody, { color: textMuted }]}>
            This page will become available after sign up is completed.
          </Text>
          <Text style={[styles.lockStateHint, { color: textMuted }]}>
            Finish onboarding and Stripe Connect first, then come back here to add your vehicle details.
          </Text>
          <TouchableOpacity
            style={[styles.lockStateButton, { backgroundColor: primary }]}
            onPress={() => {
              hapticFeedback('light');
              router.push('/valeter/valeter-onboarding');
            }}
            activeOpacity={0.88}
          >
            <Text style={styles.lockStateButtonText}>Continue sign up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );

  const vehicleEditAction = (
    <TouchableOpacity
      onPress={() => {
        hapticFeedback('light');
        setIsEditing((v) => !v);
      }}
      style={[styles.headerEditBtn, { borderColor: `${primary}35`, backgroundColor: `${primary}12` }]}
      activeOpacity={0.8}
      hitSlop={6}
    >
      <Text style={[styles.headerEditText, { color: primary }]} numberOfLines={1}>
        {isEditing ? 'Cancel' : 'Edit'}
      </Text>
    </TouchableOpacity>
  );

  if (authLoading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="My garage" />
        <View style={[styles.loadingWrap, { paddingTop: headerOffset }]}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  if (stripeStatusLoading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="My garage" />
        <View style={[styles.loadingWrap, { paddingTop: headerOffset }]}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  if (stripeStatus !== 'completed') {
    return renderLockedState();
  }

  if (isLoading || !profile) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="My garage" rightAction={vehicleEditAction} />
        <View style={[styles.loadingWrap, { paddingTop: headerOffset }]}>
          <DefaultLoadingSkeleton message="Loading…" />
        </View>
      </SafeAreaView>
    );
  }

  const hasRegistration = !!(profile.vehicle_registration || '').trim();
  const taxTone = getTaxTone(profile.tax_status, profile.tax_due_date);
  const motTone = getMotTone(profile.mot_status, profile.mot_expiry_date);

  const vehicleTitle =
    [profile.vehicle_make, profile.vehicle_model].filter(Boolean).join(' ') || 'Your valeting vehicle';
  const regDisplay = formatUkReg(profile.vehicle_registration || '');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={
          isLight
            ? ['rgba(158,201,224,0.16)', 'rgba(232,197,71,0.06)', 'rgba(42,70,96,0.5)']
            : ['rgba(56,189,248,0.08)', 'transparent', 'rgba(15,23,42,0.6)']
        }
        style={styles.garageAmbient}
        pointerEvents="none"
      />
      <ValeterScreenHeader title="My garage" rightAction={vehicleEditAction} />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: headerOffset, paddingBottom: insets.bottom + VALETER_CONTENT_BOTTOM_PAD },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.showroom}>
          <View style={styles.showroomHeader}>
            <View style={[styles.garageBadge, { borderColor: `${primary}40`, backgroundColor: `${primary}12` }]}>
              <Ionicons name="business-outline" size={12} color={primary} />
              <Text style={[styles.garageBadgeText, { color: primary }]}>Showroom</Text>
            </View>
          </View>

          <View style={[styles.stageFrame, { borderColor: `${primary}25` }]}>
            <LinearGradient
              colors={['#0B1220', '#111827', '#0F172A']}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={[`${primary}22`, 'transparent', 'transparent']}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={styles.stageSpotlight}
              pointerEvents="none"
            />

            <TouchableOpacity
              style={styles.stagePhoto}
              onPress={showVehiclePhotoOptions}
              disabled={uploadingPhoto}
              activeOpacity={0.92}
            >
              {profile.vehicle_photo_url ? (
                <Image source={{ uri: profile.vehicle_photo_url }} style={styles.stageImage} resizeMode="cover" />
              ) : (
                <View style={styles.stageEmpty}>
                  <View style={[styles.stageEmptyGlow, { backgroundColor: `${primary}20` }]} />
                  <Ionicons name="car-sport" size={56} color={primary} />
                  <Text style={styles.stageEmptyTitle}>Add your work vehicle</Text>
                  <Text style={styles.stageEmptySub}>Show customers your mobile unit</Text>
                </View>
              )}
              <LinearGradient
                colors={['transparent', 'rgba(0,0,0,0.15)', 'rgba(0,0,0,0.72)']}
                style={styles.stageVignette}
                pointerEvents="none"
              />
              <View style={styles.stageFloorLine} pointerEvents="none" />
            </TouchableOpacity>

            <View style={styles.plateBadge}>
              <View style={styles.plateStripe} />
              <Text style={styles.plateText}>{regDisplay}</Text>
            </View>

            <TouchableOpacity
              style={[styles.cameraFab, { borderColor: `${primary}55`, backgroundColor: `${primary}22` }]}
              onPress={showVehiclePhotoOptions}
              disabled={uploadingPhoto}
              activeOpacity={0.85}
            >
              {uploadingPhoto ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <>
                  <Ionicons name="camera" size={16} color="#fff" />
                  <Text style={styles.cameraFabText}>{profile.vehicle_photo_url ? 'Update' : 'Add photo'}</Text>
                </>
              )}
            </TouchableOpacity>
          </View>

          <View style={[styles.placard, isLight && { backgroundColor: placardBg, borderColor: placardBorder }]}>
            {isEditing ? (
              <>
                <Text style={[styles.placardEditTitle, { color: textMain }]}>Update your showroom</Text>
                <View style={styles.placardField}>
                  <Text style={[styles.placardFieldLabel, { color: textMuted }]}>Registration</Text>
                  <TextInput
                    style={[styles.placardInput, { color: textMain, borderColor: inputBorder, backgroundColor: inputBg }]}
                    value={profile.vehicle_registration || ''}
                    autoCapitalize="characters"
                    onChangeText={(t) =>
                      setProfile({
                        ...profile,
                        vehicle_registration: t.replace(/\s/g, '').toUpperCase().slice(0, 8),
                      })
                    }
                    placeholder="AB12 CDE"
                    placeholderTextColor={textMuted}
                  />
                </View>
                <View style={styles.placardField}>
                  <Text style={[styles.placardFieldLabel, { color: textMuted }]}>Model</Text>
                  <TextInput
                    style={[styles.placardInput, { color: textMain, borderColor: inputBorder, backgroundColor: inputBg }]}
                    value={profile.vehicle_model || ''}
                    onChangeText={(t) => setProfile({ ...profile, vehicle_model: t })}
                    placeholder="Transit Custom"
                    placeholderTextColor={textMuted}
                  />
                </View>
                {profile.vehicle_make ? (
                  <Text style={[styles.placardMakeHint, { color: textMuted }]}>Make: {profile.vehicle_make} (from DVLA)</Text>
                ) : null}
                {hasRegistration && DVLA_CONFIG.apiKey ? (
                  <TouchableOpacity
                    style={[styles.dvlaBtn, { borderColor: `${primary}40`, backgroundColor: `${primary}10` }]}
                    onPress={() => lookupDVLA(profile.vehicle_registration || '')}
                    disabled={isLookingUpDVLA}
                    activeOpacity={0.85}
                  >
                    {isLookingUpDVLA ? (
                      <ActivityIndicator size="small" color={primary} />
                    ) : (
                      <>
                        <Ionicons name="search-outline" size={18} color={primary} />
                        <Text style={[styles.dvlaBtnText, { color: primary }]}>Pull Tax & MOT from DVLA</Text>
                      </>
                    )}
                  </TouchableOpacity>
                ) : null}
                <TouchableOpacity
                  style={[styles.primaryBtn, { backgroundColor: primary }]}
                  onPress={handleSaveProfile}
                  disabled={isSaving}
                  activeOpacity={0.88}
                >
                  {isSaving ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.primaryBtnText}>Save to garage</Text>
                  )}
                </TouchableOpacity>
              </>
            ) : (
              <>
                <Text style={[styles.placardTitle, { color: textMain }]} numberOfLines={2}>
                  {vehicleTitle}
                </Text>
                <Text style={[styles.placardSub, { color: textMuted }]}>Your on-the-road presence · seen by customers on every job</Text>
                <View style={styles.chipRow}>
                  <ShowroomComplianceChip
                    label="Tax"
                    value={profile.tax_status || 'Unknown'}
                    date={formatDate(profile.tax_due_date)}
                    tone={taxTone}
                  />
                  <ShowroomComplianceChip
                    label="MOT"
                    value={profile.mot_status || 'Unknown'}
                    date={formatDate(profile.mot_expiry_date)}
                    tone={motTone}
                  />
                </View>
              </>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  garageAmbient: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lockStateWrap: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  lockStateCard: {
    borderRadius: 24,
    borderWidth: 1,
    paddingVertical: 28,
    paddingHorizontal: 22,
    alignItems: 'center',
    gap: 12,
  },
  lockStateIconWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  lockStateTitle: {
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
    letterSpacing: -0.2,
  },
  lockStateBody: {
    fontSize: 15,
    fontWeight: '700',
    textAlign: 'center',
    lineHeight: 22,
  },
  lockStateHint: {
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 19,
    opacity: 0.95,
  },
  lockStateButton: {
    marginTop: 6,
    minHeight: 48,
    alignSelf: 'stretch',
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  lockStateButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '800',
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  headerEditBtn: {
    minWidth: 72,
    paddingHorizontal: 14,
    paddingVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    borderWidth: 1,
    flexShrink: 0,
  },
  headerEditText: {
    fontSize: 14,
    fontWeight: '700',
  },

  showroom: {
    marginBottom: 0,
  },
  showroomHeader: {
    marginBottom: 8,
  },
  garageBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  garageBadgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  stageFrame: {
    borderRadius: 22,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: '#0B1220',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.35, shadowRadius: 18 },
      android: { elevation: 8 },
    }),
  },
  stageSpotlight: {
    ...StyleSheet.absoluteFillObject,
    height: '55%',
  },
  stagePhoto: {
    height: STAGE_HEIGHT,
    width: '100%',
  },
  stageImage: {
    width: '100%',
    height: '100%',
  },
  stageEmpty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  stageEmptyGlow: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    opacity: 0.35,
  },
  stageEmptyTitle: {
    color: VALUE_WHITE,
    fontSize: 16,
    fontWeight: '800',
    marginTop: 12,
  },
  stageEmptySub: {
    color: LABEL_MUTED,
    fontSize: 13,
    fontWeight: '500',
    marginTop: 4,
    textAlign: 'center',
  },
  stageVignette: {
    ...StyleSheet.absoluteFillObject,
  },
  stageFloorLine: {
    position: 'absolute',
    left: 24,
    right: 24,
    bottom: 18,
    height: 2,
    borderRadius: 1,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  plateBadge: {
    position: 'absolute',
    left: 16,
    bottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#CBD5E1',
    overflow: 'hidden',
    paddingRight: 12,
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 4 },
      android: { elevation: 3 },
    }),
  },
  plateStripe: {
    width: 8,
    alignSelf: 'stretch',
    backgroundColor: '#003399',
  },
  plateText: {
    color: '#0F172A',
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 2,
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  cameraFab: {
    position: 'absolute',
    right: 14,
    bottom: 24,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
  },
  cameraFabText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  placard: {
    marginTop: 10,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    backgroundColor: CARD_BG,
    gap: 10,
  },
  placardTitle: {
    color: VALUE_WHITE,
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  placardSub: {
    color: LABEL_MUTED,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  chipRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 2,
  },
  placardEditTitle: {
    color: VALUE_WHITE,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  placardField: {
    gap: 6,
  },
  placardFieldLabel: {
    color: LABEL_MUTED,
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  placardInput: {
    color: VALUE_WHITE,
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  placardMakeHint: {
    color: LABEL_MUTED,
    fontSize: 12,
    fontWeight: '600',
  },
  dvlaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  dvlaBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },

  primaryBtn: {
    paddingVertical: 18,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: { shadowColor: SKY, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
      android: { elevation: 4 },
    }),
  },
  primaryBtnText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
  },
});
