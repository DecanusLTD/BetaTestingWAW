import { supabase } from '../lib/supabase';

export type ValeterBookingChatNotificationThread = {
  bookingId: string;
  unreadCount: number;
  latestMessageAt: string;
  latestMessagePreview: string;
  bookingStatus?: string | null;
  serviceName?: string | null;
  serviceType?: string | null;
  scheduledAt?: string | null;
  timeSlot?: string | null;
  locationAddress?: string | null;
  address?: string | null;
};

function buildUnreadChatPreview(message: {
  message_type?: string | null;
  content?: string | null;
}): string {
  const content = message.content?.trim();

  if (message.message_type === 'payment_request') {
    return 'New payment request';
  }

  if (message.message_type === 'image') {
    return content || 'Sent a photo';
  }

  if (message.message_type === 'voice') {
    return 'Sent a voice note';
  }

  return content || 'New message';
}

export async function fetchUnreadValeterBookingChatThreads(userId: string): Promise<ValeterBookingChatNotificationThread[]> {
  const { data: unreadMessages, error } = await supabase
    .from('booking_messages')
    .select('id,booking_id,sender_role,message_type,content,created_at')
    .eq('sender_role', 'customer')
    .is('read_at', null)
    .order('created_at', { ascending: false })
    .limit(200);

  if (error || !unreadMessages?.length) return [];

  const bookingIds = Array.from(new Set(unreadMessages.map((message) => message.booking_id)));
  const { data: bookings, error: bookingsError } = await supabase
    .from('bookings')
    .select('id,status,service_name,service_type,scheduled_at,time_slot,location_address,address,valeter_id')
    .eq('valeter_id', userId)
    .in('id', bookingIds);

  if (bookingsError || !bookings?.length) return [];

  const bookingMap = new Map<string, (typeof bookings)[number]>();
  bookings.forEach((booking) => {
    bookingMap.set(String(booking.id), booking);
  });

  const grouped = new Map<string, ValeterBookingChatNotificationThread>();

  unreadMessages.forEach((message) => {
    const booking = bookingMap.get(String(message.booking_id));
    if (!booking) return;

    const existing = grouped.get(String(message.booking_id));
    const latestMessageAt = message.created_at;
    const nextPreview = buildUnreadChatPreview(message as { message_type?: string | null; content?: string | null });

    if (!existing) {
      grouped.set(String(message.booking_id), {
        bookingId: String(message.booking_id),
        unreadCount: 1,
        latestMessageAt,
        latestMessagePreview: nextPreview,
        bookingStatus: booking.status ?? null,
        serviceName: booking.service_name ?? null,
        serviceType: booking.service_type ?? null,
        scheduledAt: booking.scheduled_at ?? null,
        timeSlot: booking.time_slot ?? null,
        locationAddress: booking.location_address ?? null,
        address: booking.address ?? null,
      });
      return;
    }

    existing.unreadCount += 1;
    if (new Date(latestMessageAt).getTime() >= new Date(existing.latestMessageAt).getTime()) {
      existing.latestMessageAt = latestMessageAt;
      existing.latestMessagePreview = nextPreview;
    }
  });

  return Array.from(grouped.values()).sort(
    (a, b) => new Date(b.latestMessageAt).getTime() - new Date(a.latestMessageAt).getTime()
  );
}

export async function markValeterBookingChatMessagesAsRead(bookingId: string) {
  if (!bookingId) return;

  const { error } = await supabase
    .from('booking_messages')
    .update({ read_at: new Date().toISOString() })
    .eq('booking_id', bookingId)
    .eq('sender_role', 'customer')
    .is('read_at', null);

  if (error) throw error;
}
