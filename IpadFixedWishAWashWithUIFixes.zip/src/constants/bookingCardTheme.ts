import { Dimensions } from 'react-native';
import { colors } from './colors';

const { width } = Dimensions.get('window');

/** Single curved radius for all booking cards – matches detailing vehicle selection exactly */
const CARD_BORDER_RADIUS = 18;

/** Vertical position for card strip on map views – tracking & payment (cards higher) */
export const CARD_STRIP_TOP = 156;

/** Book a Service index: position cards lower (bottom offset from tab bar + insets). */
export const BOOKING_INDEX_CARDS_BOTTOM_PADDING = 24;

/** Gradient matching customer UI (teal/navy) – same palette as dashboard background */
export const HEADER_STYLE_CARD_GRADIENT = [
  'rgba(74,122,142,0.48)',
  'rgba(21,34,56,0.42)',
] as [string, string];

/** Border color – matches customer theme primary (#7EB8D4) */
export const HEADER_STYLE_CARD_BORDER = 'rgba(126,184,212,0.5)';

/** Curved border style – lighter shadow so cards feel less heavy */
export const CURVED_BOOKING_CARD = {
  borderRadius: CARD_BORDER_RADIUS,
  overflow: 'hidden' as const,
  backgroundColor: 'transparent',
  borderWidth: 1,
  borderColor: HEADER_STYLE_CARD_BORDER,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 1 },
  shadowOpacity: 0.08,
  shadowRadius: 6,
  elevation: 3,
};

/** Slightly narrower than screen so each card fits with visible margins */
export const BOOKING_CARD = {
  CARD_WIDTH: Math.min(width - 48, 340),
  SNAP_INTERVAL: Math.min(width - 48, 340) + 16,
  PADDING_H: 20,
  PADDING_TOP: 14,
  BORDER_RADIUS: CARD_BORDER_RADIUS,
  INTENSITY: 35,
  SKY: colors.SKY,
  GRADIENT: [colors.SKY, '#60A5FA', '#3B82F6'] as const,
  GRADIENT_CTA: [colors.SKY, '#60A5FA'] as const,
  ICON_SIZE: 58,
  ICON_RADIUS: 18,
  CURVED: CURVED_BOOKING_CARD,
};
