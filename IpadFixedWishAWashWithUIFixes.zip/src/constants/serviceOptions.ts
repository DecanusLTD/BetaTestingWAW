export interface ServiceOption {
  id: string;
  name: string;
  desc: string;
  dur: string;
  icon: string;
  colors: [string, string];
  price: number;
  minPrice?: number;
  maxPrice?: number;
  bulletPoints?: string[];
}

/* =======================
   STANDARD VALET SERVICES
======================= */

export const serviceOptions: ServiceOption[] = [
  {
    id: 'bronze-wash',
    name: 'Bronze Wash',
    desc: 'Quick clean – exterior or interior. Hand wash & wheels, or full vacuum & wipe-down.',
    dur: '15–20 min',
    icon: 'water-outline',
    colors: ['#CD7F32', '#A0522D'],
    price: 15,
    bulletPoints: [
      'Exterior: snow foam, hand wash, wheels & dry',
      'OR Interior: vacuum, dashboard, console & glass',
    ],
  },
  {
    id: 'silver-wash',
    name: 'Silver Wash',
    desc: 'Inside and out. Wash, wheels & windows outside; vacuum, trims & glass inside.',
    dur: '25–30 min',
    icon: 'sparkles-outline',
    colors: ['#C0C0C0', '#A8A8A8'],
    price: 25,
    bulletPoints: [
      'Exterior wash, wheels & arches',
      'Full vacuum, dashboard & trims',
      'All windows in and out',
    ],
  },
  {
    id: 'gold-wash',
    name: 'Gold Wash',
    desc: 'Full exterior wash, wheels & tyres cleaned, interior vacuum, dash & trims wiped, windows inside & out, door shuts wiped.',
    dur: '45–60 min',
    icon: 'sparkles',
    colors: ['#FFD700', '#FFA500'],
    price: 45,
    bulletPoints: [
      'Full exterior wash',
      'Wheels & tyres cleaned',
      'Interior vacuum',
      'Dash & trims wiped',
      'Windows inside & out',
      'Door shuts wiped',
    ],
  },
  {
    id: 'platinum-wash',
    name: 'Platinum Wash (Not Detailing)',
    desc: 'Deeper exterior wash, wheels deep cleaned & tyres dressed, detailed interior vacuum, interior trims cleaned & dressed, glass inside & out. No machine polishing, paint correction, or detailing.',
    dur: '2–3 hours',
    icon: 'star-outline',
    colors: ['#E5E4E2', '#BCC6CC'],
    price: 85,
    bulletPoints: [
      'Deeper exterior wash',
      'Wheels deep cleaned & tyres dressed',
      'Detailed interior vacuum',
      'Interior trims cleaned & dressed',
      'Glass cleaned inside & out',
      '❗ No machine polishing, paint correction, or detailing',
    ],
  },
];

/* =======================
   ECO VALET SERVICES
======================= */

export const ecoServiceOptions: ServiceOption[] = [
  {
    id: 'eco-bronze-wash',
    name: 'Eco Bronze Wash',
    desc: 'Same great clean, kinder to the planet. Biodegradable products, less water.',
    dur: '15–20 min',
    icon: 'leaf-outline',
    colors: ['#10B981', '#059669'],
    price: 18,
    minPrice: 15,
    maxPrice: 22,
    bulletPoints: [
      'Exterior or interior',
      'Eco shampoo, low-water wash',
      'Wheels & interior vacuum',
    ],
  },
  {
    id: 'eco-silver-wash',
    name: 'Eco Silver Wash',
    desc: 'Full inside & out with eco products. Same result, smaller footprint.',
    dur: '25–30 min',
    icon: 'leaf',
    colors: ['#34D399', '#10B981'],
    price: 28,
    minPrice: 25,
    maxPrice: 32,
    bulletPoints: [
      'Eco wash, wheels & dry',
      'Vacuum, trims & all glass',
    ],
  },
  {
    id: 'eco-gold-wash',
    name: 'Eco Gold Wash',
    desc: 'Full eco valet – tyre dressing, interior refresh, natural deodoriser.',
    dur: '45–60 min',
    icon: 'reload-outline',
    colors: ['#059669', '#047857'],
    price: 48,
    minPrice: 45,
    maxPrice: 55,
    bulletPoints: [
      'Eco Silver + wheel & tyre dressing',
      'Fabric refresh, leather-safe conditioner',
      'Natural deodoriser',
    ],
  },
  {
    id: 'eco-platinum-wash',
    name: 'Eco Platinum Wash',
    desc: 'Premium eco detail – decon, sealant, deep interior & protection.',
    dur: '2–3 hours',
    icon: 'earth-outline',
    colors: ['#047857', '#065F46'],
    price: 90,
    minPrice: 85,
    maxPrice: 100,
    bulletPoints: [
      'Eco Gold + paint decontamination',
      'Eco wax or sealant',
      'Steam interior, odour & fabric guard',
    ],
  },
];

/* =======================
   DETAILING SERVICES
======================= */

export const detailingServiceOptions: ServiceOption[] = [
  {
    id: 'interior-detail',
    name: 'Interior Detail',
    desc: 'Deep interior cleaning & protection. A thorough interior clean designed to refresh and protect your vehicle’s cabin.',
    dur: '1–2 hours',
    icon: 'home-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 60,
    bulletPoints: [
      'Full vacuum of carpets, seats, boot, and mats',
      'Deep cleaning of fabric seats or gentle leather cleaning & conditioning',
      'Dashboard, centre console, door cards, and trims cleaned and dressed',
      'Air vents, buttons, and hard-to-reach areas detailed',
      'Interior glass cleaned streak-free',
      'Light stain removal (heavy staining may require extra time)',
      'Deodorising treatment for a fresh, clean scent',
      'Best for: Daily drivers, families, ride-share vehicles',
    ],
  },
  {
    id: 'exterior-detail',
    name: 'Exterior Detail',
    desc: 'Paint correction & exterior protection. A comprehensive exterior clean to restore gloss and protect your paintwork.',
    dur: '2–3 hours',
    icon: 'car-sport-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 80,
    bulletPoints: [
      'Pre-wash snow foam & safe contact wash',
      'Wheel faces, barrels & tyres cleaned and dressed',
      'Bug, tar, and road grime removal',
      'Chemical decontamination to remove embedded contaminants',
      'Light machine polish to enhance shine and reduce minor swirl marks',
      'Protective wax or sealant applied',
      'Exterior glass cleaned',
      'Door shuts cleaned',
      'Best for: Improving appearance and protecting paint',
    ],
  },
  {
    id: 'full-detail',
    name: 'Full Detail',
    desc: 'Complete interior & exterior detailing. The ultimate refresh for your vehicle, inside and out.',
    dur: '4–5 hours',
    icon: 'diamond',
    colors: ['#EAB308', '#CA8A04'],
    price: 130,
    bulletPoints: [
      'Everything from Interior Detail',
      'Everything from Exterior Detail',
      'Deeper interior attention to trims, crevices, and high-touch areas',
      'Enhanced paint gloss and longer-lasting protection',
      'Tyres and exterior plastics restored to a factory-fresh look',
      'Best for: Selling your car, special occasions, or full reset',
    ],
  },
  {
    id: 'paint-correction',
    name: 'Paint Correction',
    desc: 'Professional paint restoration & polishing. Designed to restore paint clarity by removing defects and imperfections.',
    dur: '5–6 hours',
    icon: 'color-filter-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 200,
    bulletPoints: [
      'Full exterior wash & decontamination',
      'Paint inspection under proper lighting',
      'Multi-stage machine polishing (cut & refine)',
      'Removal of swirl marks, light scratches, oxidation, and holograms',
      'Significant gloss, depth, and clarity improvement',
      'Protective sealant applied after correction',
      'Note: Level of correction depends on paint condition and package selected.',
      'Best for: Enthusiasts, neglected paint, pre-ceramic prep',
    ],
  },
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    desc: 'Long-lasting ceramic paint protection. A premium coating that chemically bonds to your paint for superior protection.',
    dur: '6–8 hours',
    icon: 'shield-checkmark-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 350,
    bulletPoints: [
      'Full exterior detail & paint decontamination',
      'Paint preparation and polishing (light correction included)',
      'Application of professional-grade ceramic coating',
      'Hydrophobic finish for extreme water beading',
      'Enhanced gloss and colour depth',
      'Protection against UV rays, dirt, chemicals, and oxidation',
      'Easier washing & maintenance',
      'Long-term protection (typically 1–3+ years depending on coating)',
      'Best for: New cars or freshly corrected paint',
    ],
  },
  {
    id: 'ppf',
    name: 'PPF (Paint Protection Film)',
    desc: 'Premium paint protection film installation. The highest level of physical paint protection available.',
    dur: 'Varies by coverage area',
    icon: 'layers-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 500,
    minPrice: 400,
    maxPrice: 600,
    bulletPoints: [
      'Paint preparation and surface cleansing',
      'Precision-cut or custom-fit PPF installation',
      'Protection against stone chips, scratches, and road debris',
      'Self-healing technology (minor scratches disappear with heat)',
      'UV-resistant, non-yellowing film',
      'Common coverage: Front bumper, bonnet (partial or full), wings, mirrors, headlights, or full vehicle',
      'Best for: Performance, luxury, and new vehicles',
    ],
  },
];

/* =======================
   ADD-ON OPTIONS (wash & detail)
======================= */

export interface AddOnOption {
  id: string;
  name: string;
  desc: string;
  price: number;
  icon: string;
}

export const addOnOptions: AddOnOption[] = [
  {
    id: 'pet-hair',
    name: 'Pet hair removal',
    desc: 'Deep clean to remove pet hair from upholstery and carpets.',
    price: 12,
    icon: 'paw-outline',
  },
  {
    id: 'stain-removal',
    name: 'Stain removal',
    desc: 'Targeted treatment for stubborn stains on seats and carpets.',
    price: 15,
    icon: 'water-outline',
  },
  {
    id: 'odour-neutraliser',
    name: 'Odour neutraliser',
    desc: 'Professional deodorising for smoke, pets, or general odours.',
    price: 10,
    icon: 'sparkles-outline',
  },
  {
    id: 'wheel-clean',
    name: 'Wheel deep clean',
    desc: 'Inside and out wheel clean with tyre dressing.',
    price: 8,
    icon: 'disc-outline',
  },
  {
    id: 'engine-bay',
    name: 'Engine bay clean',
    desc: 'Safe exterior engine bay clean and dress.',
    price: 25,
    icon: 'construct-outline',
  },
];
