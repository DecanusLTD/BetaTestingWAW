/**
 * Central app logo asset. Preload at boot so splash and loading screens show it instantly.
 */
import { Asset } from 'expo-asset';

export const APP_LOGO_SOURCE = require('../../assets/icon.png');

/** Car marker / vehicle icon used on maps and booking flows. */
export const CAR_IMAGE = require('../../assets/car.png');

/** Onboarding background video (used in app/onboarding and app/owner/customer-onboarding). */
export const ONBOARDING_VIDEO = require('../../assets/car-cleaning.mp4');

let preloadStarted = false;

/** Call once at app start so the logo is cached and appears immediately on loading/splash screens. */
export async function preloadAppLogo(): Promise<void> {
  if (preloadStarted) return;
  preloadStarted = true;
  try {
    await Asset.fromModule(APP_LOGO_SOURCE).downloadAsync();
  } catch {
    // non-critical; image will still load on first use
  }
}

/** Image-only assets to preload at boot. Videos are excluded to avoid memory spikes and native crashes on launch. */
const BOOT_IMAGE_ASSETS = [
  require('../../assets/icon.png'),
  require('../../assets/icon-auth.png'),
  require('../../assets/car.png'),
  require('../../assets/cleaning.png'),
  require('../../assets/detailing.png'),
];

let bootPreloadStarted = false;

/** Preload critical image assets at boot. Videos (auth.mp4, onboarding.mp4) load on first use to avoid launch crashes. */
export async function preloadBootAssets(): Promise<void> {
  if (bootPreloadStarted) return;
  bootPreloadStarted = true;
  const results = await Promise.allSettled(
    BOOT_IMAGE_ASSETS.map((mod) => Asset.fromModule(mod).downloadAsync())
  );
  if (__DEV__) {
    results.forEach((r, i) => {
      if (r.status === 'rejected') {
        console.warn(`Boot asset preload failed [${i}]:`, r.reason);
      }
    });
  }
}
