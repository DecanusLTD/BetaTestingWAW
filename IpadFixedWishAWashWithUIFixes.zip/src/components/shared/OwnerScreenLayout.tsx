import React from 'react';
import { View, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { customerTheme } from '../../constants/customerTheme';

interface OwnerScreenLayoutProps {
  children: React.ReactNode;
  /** Optional header (e.g. AppHeader) – not wrapped in SafeAreaView so it can overlap. */
  header?: React.ReactNode;
  /** Set to false to disable gradient (e.g. for map screens that have their own bg). */
  withGradient?: boolean;
}

/**
 * Standard owner screen chrome: SafeAreaView + gradient background.
 * Add your own AppHeader and ScrollView/FlatList with getScrollContentPadding(insets, true).
 */
export default function OwnerScreenLayout({
  children,
  header,
  withGradient = true,
}: Readonly<OwnerScreenLayoutProps>) {
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {withGradient && (
        <LinearGradient
          colors={customerTheme.backgroundGradient}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      )}
      {header}
      <View style={styles.content}>{children}</View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1 },
});
