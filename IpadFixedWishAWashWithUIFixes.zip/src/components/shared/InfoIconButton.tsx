import React from 'react';
import { TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { BOOKING_CARD } from '../../constants/bookingCardTheme';

const SIZE = 36;
const ICON_SIZE = 22;

export interface InfoIconButtonProps {
  onPress: () => void;
  /** Accent color for icon and border (e.g. SKY, service color). */
  accentColor: string;
  style?: ViewStyle;
  /** Hit slop for touch area. Default 14. */
  hitSlop?: number;
}

/**
 * Info icon button matching the "select a wash hub" card design:
 * BlurView circle, filled information-circle icon, accent border.
 * Use on all booking flow cards for consistency.
 */
export default function InfoIconButton({
  onPress,
  accentColor,
  style,
  hitSlop = 14,
}: InfoIconButtonProps) {
  const borderColor = accentColor + '40';

  return (
    <TouchableOpacity
      onPress={onPress}
      hitSlop={{ top: hitSlop, bottom: hitSlop, left: hitSlop, right: hitSlop }}
      style={[styles.wrap, style]}
      activeOpacity={0.8}
    >
      <BlurView intensity={20} tint="dark" style={[styles.btn, { borderColor }]}>
        <Ionicons name="information-circle" size={ICON_SIZE} color={accentColor} />
      </BlurView>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginLeft: 4,
  },
  btn: {
    width: SIZE,
    height: SIZE,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1,
  },
});
