import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { customerTheme } from '../constants/customerTheme';

const THEME_STORAGE_KEY = 'app_theme_dark';

export type ColorScheme = 'light' | 'dark';

export const lightTheme = {
  backgroundGradient: ['#E0F2FE', '#BAE6FD'] as [string, string],
  backgroundColor: '#F0F9FF',
  headerBg: 'rgba(226,232,240,0.9)',
  skyBlue: '#0EA5E9',
  navyBlue: '#0369A1',
  darkNavy: '#0C4A6E',
  primary: '#0284C7',
};

export const darkTheme = customerTheme;

export type AppTheme = typeof darkTheme;

type ThemeContextValue = {
  colorScheme: ColorScheme;
  isDark: boolean;
  theme: AppTheme;
  setColorScheme: (scheme: ColorScheme) => void;
  toggleDarkMode: () => void;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [colorScheme, setColorScheme] = useState<ColorScheme>('dark');

  useEffect(() => {
    AsyncStorage.getItem(THEME_STORAGE_KEY).then((stored) => {
      if (stored === 'true') setColorScheme('dark');
      else if (stored === 'false') setColorScheme('light');
    });
  }, []);

  const persistAndSetColorScheme = useCallback((scheme: ColorScheme) => {
    setColorScheme(scheme);
    AsyncStorage.setItem(THEME_STORAGE_KEY, scheme === 'dark' ? 'true' : 'false');
  }, []);

  const toggleDarkMode = useCallback(() => {
    setColorScheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      AsyncStorage.setItem(THEME_STORAGE_KEY, next === 'dark' ? 'true' : 'false');
      return next;
    });
  }, []);

  const value = useMemo(
    () => ({
      colorScheme,
      isDark: colorScheme === 'dark',
      theme: colorScheme === 'dark' ? darkTheme : lightTheme,
      setColorScheme: persistAndSetColorScheme,
      toggleDarkMode,
    }),
    [colorScheme, persistAndSetColorScheme, toggleDarkMode]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}

export function useThemeOptional(): ThemeContextValue | null {
  return useContext(ThemeContext);
}
