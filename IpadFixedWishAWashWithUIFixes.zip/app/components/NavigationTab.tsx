import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Modal,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useBookingFlowTheme } from '../../src/contexts/BookingFlowThemeContext';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 70;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 28;
const LIGHT_BLUE = '#87CEEB';
const DETAILING_YELLOW = colors.DETAILING_YELLOW;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      { name: 'Trip', icon: 'navigate', route: '/valeter/jobs/tracking' },
      { name: 'Earnings', icon: 'wallet', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Chat', icon: 'chatbubble-ellipses', route: '/owner/support/help-support' },
    { name: 'Track', icon: 'navigate', route: '/owner/track' },
    { name: 'History', icon: 'time', route: '/owner/wash-history' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

function findTabIndex(tabs: Tab[], predicate: (t: Tab) => boolean): number {
  const idx = tabs.findIndex(predicate);
  return Math.max(0, idx);
}

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    return findTabIndex(tabs, (t) => t.route.includes('/booking'));
  }
  if (pathname.includes('/track')) {
    return findTabIndex(tabs, (t) => t.route === '/owner/track' || t.route.includes('/track'));
  }
  if (pathname.includes('/rewards')) {
    return findTabIndex(tabs, (t) => t.route === '/rewards' || t.route.includes('rewards'));
  }
  if (pathname.includes('/valeter/jobs/')) {
    const isTrip =
      pathname.includes('/valeter/jobs/tracking') ||
      pathname.includes('/valeter/jobs/accept') ||
      pathname.includes('/valeter/jobs/complete');
    return isTrip
      ? findTabIndex(tabs, (t) => t.route === '/valeter/jobs/tracking')
      : findTabIndex(tabs, (t) => t.route === '/valeter/jobs/queue');
  }
  if (pathname.includes('/valeter/valeter-wash-history')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/valeter-wash-history');
  }
  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    return findTabIndex(tabs, (t) => t.route === '/valeter/profile/valeter-profile');
  }
  const businessRoutes = ['/business/dashboard', '/business/locations', '/business/bookings', '/business/team', '/business/profile'] as const;
  for (const route of businessRoutes) {
    if (pathname.includes(route)) return findTabIndex(tabs, (t) => t.route === route);
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }
  return 0;
};

// Separate component for tab items to allow hooks inside
function TabItem({
  tab,
  isActive,
  glowAnim,
  accent,
  onPress,
}: Readonly<{
  tab: Tab;
  isActive: boolean;
  glowAnim: Animated.SharedValue<number>;
  accent: string;
  onPress: () => void;
}>) {
  const iconName = isActive ? tab.icon : (`${tab.icon}-outline` as keyof typeof Ionicons.glyphMap);
  const iconColor = isActive ? '#FFFFFF' : 'rgba(255,255,255,0.5)';
  const labelColor = isActive ? accent : 'rgba(255,255,255,0.5)';

  const glowStyle = useAnimatedStyle(() => {
    const glowOpacity = glowAnim.value;
    const glowScale = 1 + glowAnim.value * 0.12;
    return {
      shadowOpacity: 0.5 + glowOpacity * 0.3,
      shadowRadius: 14 + glowOpacity * 6,
      transform: [{ scale: glowScale }],
    };
  });

  return (
    <TouchableOpacity
      style={styles.tab}
      onPress={onPress}
      activeOpacity={isActive ? 1 : 0.7}
      disabled={isActive}
      accessibilityRole="tab"
      accessibilityLabel={isActive ? `${tab.name}, selected` : tab.name}
      accessibilityState={{ selected: isActive }}
      accessibilityHint={isActive ? undefined : `Switch to ${tab.name}`}
    >
      <Animated.View
        style={[
          styles.iconContainer,
          isActive && styles.iconContainerActive,
          glowStyle,
          {
            backgroundColor: isActive ? accent : 'rgba(255,255,255,0.06)',
            shadowColor: isActive ? accent : 'transparent',
          },
        ]}
      >
        <Ionicons name={iconName as never} size={22} color={iconColor} style={styles.icon} />
      </Animated.View>
      <Text
        style={[styles.tabLabel, { color: labelColor }]}
        numberOfLines={1}
        allowFontScaling={true}
      >
        {tab.name}
      </Text>
    </TouchableOpacity>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: bookingFlowTheme } = useBookingFlowTheme();

  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const isOnBookingIndex = pathname === '/owner/booking' || pathname === '/owner/booking/index';
  const useDetailingAccent = isCustomerRoute && isOnBookingIndex && bookingFlowTheme === 'detailing';

  const defaultAccent =
    (isBusinessRoute && businessTheme?.primary) ||
    (isCustomerRoute && customerTheme?.primary) ||
    colors.navActive ||
    LIGHT_BLUE;

  // Store glow animations for each tab - initialize with max 5 tabs
  const glowAnim0 = useSharedValue(0);
  const glowAnim1 = useSharedValue(0);
  const glowAnim2 = useSharedValue(0);
  const glowAnim3 = useSharedValue(0);
  const glowAnim4 = useSharedValue(0);
  const glowAnimations = [glowAnim0, glowAnim1, glowAnim2, glowAnim3, glowAnim4];

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
      '/owner/booking',
      '/owner/booking/',
      '/owner/booking/physical/',
      '/owner/booking/eco/',
      '/owner/booking/detailing/',
      '/owner/booking/create',
      '/owner/booking/payment',
      '/owner/booking/tracking',
      '/valeter/jobs/accept',
      '/valeter/jobs/tracking',
      '/valeter/jobs/complete',
    ];
    return hideRoutes.some((route) => pathname.includes(route));
  }, [pathname]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';
  const bottomPad = Math.max(insets.bottom, 10) + 8;

  if (shouldHideTab) {
    return <View style={styles.hidden} />;
  }

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View style={[styles.barWrapper, { marginBottom: bottomPad }]}>
        <View style={styles.navBackdrop} pointerEvents="none">
          <BlurView intensity={58} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(135,206,235,0.22)', 'rgba(30,58,138,0.16)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </View>
        {tabs.map((tab, index) => {
          const isActive = index === activeIndex;
          const isProfile = isProfileTab(tab);
          const glowAnim = glowAnimations[index] || glowAnim0;
          const isBookTab = tab.route.includes('/booking');
          const tabAccent = useDetailingAccent && isBookTab ? DETAILING_YELLOW : defaultAccent;
          const useYellowPill = useDetailingAccent && isBookTab;

          const handleTabPress = async () => {
            if (isActive) return;
            glowAnim.value = withTiming(1, { duration: 200 }, () => {
              glowAnim.value = withTiming(0, { duration: 300 });
            });
            if (isProfile && isBusinessRoute) {
              await hapticFeedback('light');
              setShowProfileActions(true);
            } else {
              await hapticFeedback('light');
              router.push(tab.route as any);
            }
          };

return (
    <View key={tab.route} style={[styles.individualPill, useYellowPill && { shadowColor: DETAILING_YELLOW }]}>
              <BlurView intensity={48} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient
                colors={
                  useYellowPill
                    ? ['rgba(234,179,8,0.28)', 'rgba(234,179,8,0.15)']
                    : ['rgba(135,206,235,0.28)', 'rgba(135,206,235,0.15)']
                }
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[StyleSheet.absoluteFill, styles.pillGradient]}
              />
              <TabItem
                tab={tab}
                isActive={isActive}
                glowAnim={glowAnim}
                accent={tabAccent}
                onPress={handleTabPress}
              />
            </View>
          );
        })}
      </View>

      <Modal
        visible={showProfileActions}
        transparent
        animationType="fade"
        onRequestClose={() => setShowProfileActions(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={[
              styles.actionSheet,
              isBusinessRoute &&
                businessTheme && {
                  backgroundColor: businessTheme.background?.[0] || 'rgba(15, 23, 42, 0.95)',
                  borderColor: `${businessTheme.primary}55`,
                },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.actionSheetHeader}>
              <Text style={[styles.actionSheetTitle, isBusinessRoute && businessTheme && { color: businessTheme.primary }]}>
                Profile Options
              </Text>
              <TouchableOpacity onPress={() => setShowProfileActions(false)} style={styles.actionSheetClose}>
                <Ionicons name="close" size={22} color={defaultAccent} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/profile' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${defaultAccent}20` }]}>
                <Ionicons name="person" size={20} color={defaultAccent} />
              </View>
              <Text style={styles.actionSheetItemText}>Business Profile</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/settings' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${defaultAccent}20` }]}>
                <Ionicons name="settings" size={20} color={defaultAccent} />
              </View>
              <Text style={styles.actionSheetItemText}>Settings</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
    elevation: 0,
  },

  barWrapper: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: 12,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 34,
    overflow: 'hidden',
    gap: 10,
  },
  navBackdrop: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 34,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  individualPill: {
    flex: 1,
    maxWidth: 68,
    minHeight: 64,
    borderRadius: 28,
    overflow: 'hidden',
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    shadowColor: LIGHT_BLUE,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  },
  pillGradient: {
    borderRadius: 28,
  },
  barGradient: {
    borderRadius: BAR_RADIUS,
  },
  barBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: BAR_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    pointerEvents: 'none',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  barRow: {
    position: 'relative',
    zIndex: 1,
  },

  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    gap: 4,
  },

  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.28,
    shadowRadius: 6,
    elevation: 4,
  },

  iconContainerActive: {
    shadowOpacity: 0.45,
    shadowRadius: 10,
    elevation: 8,
  },

  icon: {},

  tabLabel: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
    textAlign: 'center',
    maxWidth: '100%',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 16,
    paddingBottom: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    marginBottom: 8,
  },

  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
  },

  actionSheetClose: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    gap: 14,
  },

  actionSheetIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
  },
  hidden: {
    position: 'absolute',
    width: 0,
    height: 0,
  },
});
