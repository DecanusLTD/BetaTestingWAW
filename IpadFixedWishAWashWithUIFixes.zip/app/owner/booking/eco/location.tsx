import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region, MapPressEvent } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import EmptyState from '../../../../src/components/shared/EmptyState';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { Hub } from '../../../../src/types/booking';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const ECO_GREEN = colors.ECO_GREEN;
const LIGHT_SKY = colors.LIGHT_SKY;
const BG = colors.BG ?? '#0A1929';
const HUB_RADIUS_MILES = 10;

interface HubWithRating extends Hub {
  averageRating?: number;
  totalReviews?: number;
}

export default function EcoLocationSelect() {
  const params = useLocalSearchParams();
  const { coords } = useLiveLocation();
  const deliveryType = params.deliveryType as string; // 'comeToYou' or 'goToThem'
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const washType = params.washType as string;

  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);
  const [selectedHub, setSelectedHub] = useState<HubWithRating | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<HubWithRating[]>([]);
  const [filteredHubs, setFilteredHubs] = useState<HubWithRating[]>([]);
  const [showMapView, setShowMapView] = useState(false);
  
  const isComeToYou = deliveryType === 'comeToYou';

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const panelSlideAnim = useRef(new Animated.Value(height)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(mapAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    if (!isComeToYou) {
      loadHubs();
    }
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (coords) {
      setLocation({ latitude: coords.latitude, longitude: coords.longitude });
      setRegion({ latitude: coords.latitude, longitude: coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    }
  }, [coords]);

  const loadHubs = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,wait_time_minutes,organization_id')
        .order('created_at', { ascending: true });
      if (error) throw error;
      
      // Calculate ratings for each hub
      const hubsWithRatings = await Promise.all(
        (data || []).map(async (hub) => {
          // Get bookings with ratings and try to match by coordinates
          let ratings: number[] = [];
          
          if (hub.latitude && hub.longitude) {
            // Get all bookings with ratings and location data
            const { data: allBookings } = await supabase
              .from('bookings')
              .select('rating, location_lat, location_lng')
              .not('rating', 'is', null)
              .not('location_lat', 'is', null)
              .not('location_lng', 'is', null);
            
            // Filter bookings within 0.01 degrees (~1km) of hub
            const nearbyBookings = allBookings?.filter(b => {
              if (!b.location_lat || !b.location_lng) return false;
              const latDiff = Math.abs(b.location_lat - hub.latitude!);
              const lngDiff = Math.abs(b.location_lng - hub.longitude!);
              return latDiff < 0.01 && lngDiff < 0.01;
            }) || [];
            
            ratings = nearbyBookings.map(b => b.rating).filter(Boolean) as number[];
          }
          
          const averageRating = ratings.length > 0
            ? ratings.reduce((sum, r) => sum + r, 0) / ratings.length
            : undefined;
          
          return {
            ...hub,
            averageRating: averageRating ? Math.round(averageRating * 10) / 10 : undefined,
            totalReviews: ratings.length,
          } as HubWithRating;
        })
      );
      
      setHubs(hubsWithRatings);
    } catch (err) {
      console.error('[eco-location] load hubs error', err);
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      
      setLocation(coords);
      setRegion({
        ...coords,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    } catch (error) {
      console.error('Error getting location:', error);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coordinate = event?.nativeEvent?.coordinate;
    if (!coordinate) return;

    await hapticFeedback('light');
    setSelectedHub(null);
    const coords = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    };
    setLocation(coords);
    setRegion({
      ...coords,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    } catch (error) {
      console.error('Error reverse geocoding:', error);
    }
  };

  const handleHubSelect = (hub: HubWithRating) => {
    hapticFeedback('medium');
    setSelectedHub(hub);
    setSelectedLocation(null);
    
    if (hub.latitude && hub.longitude) {
      setLocation({ latitude: hub.latitude, longitude: hub.longitude });
      setRegion({
        latitude: hub.latitude,
        longitude: hub.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
    
    // Switch to map view
    setShowMapView(true);
    
    Animated.spring(panelSlideAnim, {
      toValue: 0,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();
  };

  const handleHubMarkerPress = (hub: HubWithRating) => {
    hapticFeedback('light');
    setSelectedHub(hub);
    setSelectedLocation(null);
    
    if (hub.latitude && hub.longitude) {
      setLocation({ latitude: hub.latitude, longitude: hub.longitude });
      setRegion({
        latitude: hub.latitude,
        longitude: hub.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
    
    Animated.spring(panelSlideAnim, {
      toValue: 0,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    await getCurrentLocation();
    
    setTimeout(() => {
      if (location) {
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    }, 300);
  };

  const handleSelect = () => {
    hapticFeedback('medium');
    
    if (isComeToYou) {
      // For "They Come to You", route to valeter selection with selected location
      if (!selectedLocation && !location) {
        Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
        return;
      }
      
      const selected = selectedLocation || (location ? { ...location, address: 'Current Location' } : null);
      if (!selected) return;
      
      router.push({
        pathname: '/owner/booking/eco/valeter-selection',
        params: {
          serviceId: serviceId || '',
          vehicleId: vehicleId || '',
          latitude: selected.latitude.toString(),
          longitude: selected.longitude.toString(),
          address: selected.address,
          washType: washType || '',
        },
      });
    } else {
      // For "You Go to Them", route to service selection with selected hub
      if (!selectedHub) {
        Alert.alert('Hub Required', 'Please select a hub from the map.');
        return;
      }
      
      router.push({
        pathname: '/owner/booking/eco/service',
        params: { 
          locationId: selectedHub.id,
          vehicleId: vehicleId || '',
        },
      });
    }
  };

  const calculateDistance = (hub: HubWithRating) => {
    if (!coords || !hub.latitude || !hub.longitude) return null;
    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 3959;
    const dLat = toRad(hub.latitude - coords.latitude);
    const dLon = toRad(hub.longitude - coords.longitude);
    const lat1 = toRad(coords.latitude);
    const lat2 = toRad(hub.latitude);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return (R * c).toFixed(1);
  };

  const filterHubsByRadius = () => {
    if (!coords) {
      // If no coords available, show all hubs with valid coordinates
      setFilteredHubs(hubs.filter(hub => hub.latitude && hub.longitude));
      return;
    }

    const filtered = hubs.filter(hub => {
      if (!hub.latitude || !hub.longitude) return false;
      const distanceStr = calculateDistance(hub);
      if (!distanceStr) return false;
      const distance = parseFloat(distanceStr);
      return distance <= HUB_RADIUS_MILES;
    });

    setFilteredHubs(filtered);
  };

  // Filter hubs when coords or hubs change
  useEffect(() => {
    if (!isComeToYou) {
      filterHubsByRadius();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coords, hubs, isComeToYou]);

  const formatWait = (minutes?: number | null) => {
    if (!minutes) return 'Instant availability';
    if (minutes < 15) return 'Under 15 min wait';
    return `${minutes} min wait`;
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={isComeToYou ? "Select Location" : "Choose eco hub"}
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        rightAction={
          <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
            <Ionicons name="locate" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={ECO_GREEN} />
          <Text style={styles.loadingText}>Finding eco-friendly hubs…</Text>
        </View>
      ) : !isComeToYou && !showMapView ? (
        // Hub List View
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
          showsVerticalScrollIndicator={false}
        >
          {filteredHubs.map((hub) => {
            const distance = calculateDistance(hub);
            return (
              <GlassCard key={hub.id} style={styles.hubCard} accountType="customer">
                <View style={styles.hubHeader}>
                  <View style={styles.hubHeaderLeft}>
                    <View style={styles.hubIconWrapper}>
                      <Ionicons name="leaf" size={20} color={ECO_GREEN} />
                    </View>
                    <View style={styles.hubInfo}>
                      <Text style={styles.hubName}>{hub.name}</Text>
                      <Text style={styles.hubAddress}>{hub.address || 'Address coming soon'}</Text>
                    </View>
                  </View>
                  {distance && (
                    <View style={styles.distancePill}>
                      <Ionicons name="navigate" size={12} color={BG} />
                      <Text style={styles.distanceText}>{distance} mi</Text>
                    </View>
                  )}
                </View>
                
                {/* Star Rating */}
                {hub.averageRating !== undefined && (
                  <View style={styles.ratingContainerList}>
                    <View style={styles.ratingStars}>
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Ionicons
                          key={star}
                          name={star <= Math.round(hub.averageRating!) ? 'star' : 'star-outline'}
                          size={14}
                          color="#FBBF24"
                        />
                      ))}
                    </View>
                    <Text style={styles.ratingTextList}>
                      {hub.averageRating.toFixed(1)}
                      {hub.totalReviews !== undefined && hub.totalReviews > 0 && (
                        <Text style={styles.ratingCountList}> ({hub.totalReviews})</Text>
                      )}
                    </Text>
                  </View>
                )}
                
                <View style={styles.hubMetaRow}>
                  <View style={styles.metaItem}>
                    <Ionicons name="time-outline" size={14} color={ECO_GREEN} />
                    <Text style={styles.metaText}>{formatWait(hub.wait_time_minutes)}</Text>
                  </View>
                  {hub.status && (
                    <View style={styles.metaItem}>
                      <Ionicons name="leaf-outline" size={14} color={ECO_GREEN} />
                      <Text style={styles.metaText}>{hub.status}</Text>
                    </View>
                  )}
                </View>
                <TouchableOpacity 
                  style={styles.selectButton} 
                  onPress={() => handleHubSelect(hub)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.selectButtonText}>Select hub</Text>
                  <Ionicons name="arrow-forward" size={16} color={BG} />
                </TouchableOpacity>
              </GlassCard>
            );
          })}

          {filteredHubs.length === 0 && (
            <EmptyState
              icon="leaf-outline"
              title="No eco hubs available yet"
              subtitle="We're expanding our eco-friendly network. Check back soon!"
              iconColor={ECO_GREEN}
              style={styles.emptyState}
            />
          )}
        </ScrollView>
      ) : (
        // Map View
        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ scale: mapAnim }],
            },
          ]}
        >
          {/* Nearby Hubs Counter */}
          {!isComeToYou && filteredHubs.length > 0 && (
            <View style={styles.counterBox}>
              <View style={styles.counterContent}>
                <Ionicons name="leaf" size={16} color={ECO_GREEN} />
                <Text style={styles.counterText}>
                  {filteredHubs.length} {filteredHubs.length === 1 ? 'hub' : 'hubs'} nearby
                </Text>
              </View>
            </View>
          )}

          {/* Map */}
          <View style={styles.mapContainer}>
            <MapView
              style={styles.map}
              region={region}
              onPress={handleMapPress}
              showsUserLocation={true}
              showsMyLocationButton={false}
            >
              {/* Hub Markers - Only show for "You Go to Them" */}
              {!isComeToYou && filteredHubs.map((hub) => (
                <Marker
                  key={hub.id}
                  coordinate={{
                    latitude: hub.latitude!,
                    longitude: hub.longitude!,
                  }}
                  onPress={() => handleHubMarkerPress(hub)}
                >
                  <View style={styles.hubMarkerContainer}>
                    <View style={styles.hubMarkerPin}>
                      <Ionicons name="leaf" size={24} color={ECO_GREEN} />
                    </View>
                    {selectedHub?.id === hub.id && (
                      <Animated.View
                        style={[
                          styles.hubMarkerPulse,
                          {
                            transform: [{ scale: markerPulse }],
                          },
                        ]}
                      />
                    )}
                  </View>
                </Marker>
              ))}

              {/* Selected Location Marker - Show for "They Come to You" or when no hub selected */}
              {(isComeToYou || (!selectedHub && selectedLocation)) && location && (
                <Marker coordinate={location}>
                  <Animated.View
                    style={[
                      styles.markerContainer,
                      {
                        transform: [{ scale: markerPulse }],
                      },
                    ]}
                  >
                    <View style={styles.markerPin}>
                      <Ionicons name="location" size={24} color={ECO_GREEN} />
                    </View>
                    <View style={styles.markerPulse} />
                  </Animated.View>
                </Marker>
              )}
            </MapView>
          </View>

          {/* Hub/Location Card - Slides up from bottom */}
          <Animated.View
            style={[
              styles.cardContainer,
              {
                transform: [{ translateY: panelSlideAnim }],
              },
            ]}
          >
            <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollContainer}>
              {selectedHub ? (
                <View style={[styles.locationCardStripWrap, { borderLeftColor: ECO_GREEN }]}>
                <GlassCard style={styles.locationCard} borderRadius={BOOKING_CARD.BORDER_RADIUS}>
                  <View style={styles.badge}>
                    <Ionicons name="leaf" size={14} color={ECO_GREEN} />
                    <Text style={styles.badgeText}>Eco-Friendly</Text>
                  </View>
                  <View style={styles.locationHeader}>
                    <Text style={styles.locationTitle}>{selectedHub.name}</Text>
                    {calculateDistance(selectedHub) && (
                      <View style={styles.distancePill}>
                        <Ionicons name="navigate" size={12} color={BG} />
                        <Text style={styles.distanceText}>{calculateDistance(selectedHub)} mi</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.locationAddress}>{selectedHub.address || 'Address coming soon'}</Text>
                  
                  {/* Star Rating */}
                  {selectedHub.averageRating !== undefined && (
                    <View style={styles.ratingContainer}>
                      <View style={styles.ratingStars}>
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Ionicons
                            key={star}
                            name={star <= Math.round(selectedHub.averageRating!) ? 'star' : 'star-outline'}
                            size={16}
                            color="#FBBF24"
                          />
                        ))}
                      </View>
                      <Text style={styles.ratingText}>
                        {selectedHub.averageRating.toFixed(1)}
                        {selectedHub.totalReviews !== undefined && selectedHub.totalReviews > 0 && (
                          <Text style={styles.ratingCount}> ({selectedHub.totalReviews} {selectedHub.totalReviews === 1 ? 'review' : 'reviews'})</Text>
                        )}
                      </Text>
                    </View>
                  )}
                  
                  <View style={styles.hubMetaRow}>
                    <View style={styles.metaItem}>
                      <Ionicons name="time-outline" size={14} color={ECO_GREEN} />
                      <Text style={styles.metaText}>{formatWait(selectedHub.wait_time_minutes)}</Text>
                    </View>
                    {selectedHub.status && (
                      <View style={styles.metaItem}>
                        <Ionicons name="leaf-outline" size={14} color={ECO_GREEN} />
                        <Text style={styles.metaText}>{selectedHub.status}</Text>
                      </View>
                    )}
                  </View>
                </GlassCard>
                </View>
              ) : selectedLocation ? (
                <View style={[styles.locationCardStripWrap, { borderLeftColor: ECO_GREEN }]}>
                <GlassCard style={styles.locationCard} borderRadius={BOOKING_CARD.BORDER_RADIUS}>
                  <View style={styles.locationHeader}>
                    <Ionicons name="location" size={24} color={ECO_GREEN} />
                    <Text style={styles.locationTitle}>Selected Location</Text>
                  </View>
                  <View style={styles.locationInfo}>
                    <Text style={styles.locationAddress}>{selectedLocation.address}</Text>
                    <View style={styles.locationCoords}>
                      <Ionicons name="map-outline" size={12} color={ECO_GREEN} />
                      <Text style={styles.coordsText}>
                        {selectedLocation.latitude.toFixed(4)}, {selectedLocation.longitude.toFixed(4)}
                      </Text>
                    </View>
                  </View>
                  {!isComeToYou && (
                    <Text style={styles.tapHint}>Tap a hub marker on the map to select</Text>
                  )}
                </GlassCard>
                </View>
              ) : (
                <View style={[styles.locationCardStripWrap, { borderLeftColor: ECO_GREEN }]}>
                <GlassCard style={styles.locationCard} borderRadius={BOOKING_CARD.BORDER_RADIUS}>
                  <Text style={styles.tapHint}>
                    {isComeToYou 
                      ? 'Tap on the map or use your current location' 
                      : 'Tap on the map or select a hub marker'}
                  </Text>
                </GlassCard>
                </View>
              )}
            </ScrollView>

            {/* Continue Button */}
            {(isComeToYou ? (selectedLocation || location) : selectedHub) && (
              <Animated.View
                style={{
                  opacity: fadeAnim,
                  transform: [{ scale: fadeAnim }],
                }}
              >
                <TouchableOpacity
                  onPress={handleSelect}
                  style={styles.continueButton}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[ECO_GREEN, '#059669']}
                    style={styles.continueGradient}
                  >
                    <Text style={styles.continueText}>
                      {isComeToYou ? 'Continue' : 'Select Hub'}
                    </Text>
                    <Ionicons name="arrow-forward" size={20} color={LIGHT_SKY} />
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>
            )}
          </Animated.View>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  content: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  mapContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 0,
  },
  map: {
    flex: 1,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerPin: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    borderWidth: 2,
    borderColor: ECO_GREEN,
  },
  hubMarkerPulse: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: ECO_GREEN,
    opacity: 0.3,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPin: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: ECO_GREEN,
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.5,
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: BOOKING_CARD.BORDER_RADIUS,
    borderTopRightRadius: BOOKING_CARD.BORDER_RADIUS,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 16,
    zIndex: 100,
  },
  scrollContainer: {
    padding: 16,
    paddingBottom: 100,
  },
  locationCardStripWrap: {
    borderLeftWidth: 5,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    marginBottom: 12,
  },
  locationCard: {
    padding: 16,
    marginBottom: 12,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  badgeText: {
    color: ECO_GREEN,
    fontSize: 11,
    fontWeight: '700',
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 8,
  },
  locationTitle: {
    color: LIGHT_SKY,
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  distancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: ECO_GREEN,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  distanceText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '700',
  },
  locationInfo: {
    gap: 8,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 14,
    marginBottom: 8,
  },
  hubMetaRow: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    color: '#E5E7EB',
    fontSize: 13,
  },
  locationCoords: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  coordsText: {
    color: ECO_GREEN,
    fontSize: 12,
  },
  tapHint: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  continueButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: LIGHT_SKY,
    fontSize: 18,
    fontWeight: 'bold',
  },
  scrollContent: {
    paddingHorizontal: isSmallScreen ? 12 : 20,
    paddingBottom: 40,
  },
  hubCard: {
    marginBottom: 12,
    padding: 16,
  },
  hubHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 12,
  },
  hubHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    flex: 1,
  },
  hubIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  hubInfo: {
    flex: 1,
  },
  hubName: {
    color: LIGHT_SKY,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  hubAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  selectButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: ECO_GREEN,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginTop: 12,
    gap: 8,
  },
  selectButtonText: {
    color: BG,
    fontSize: 15,
    fontWeight: '700',
  },
  ratingContainerList: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  ratingTextList: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  ratingCountList: {
    color: '#9CA3AF',
    fontSize: 12,
    fontWeight: '400',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    paddingHorizontal: 20,
  },
  counterBox: {
    position: 'absolute',
    top: HEADER_CONTENT_OFFSET + 16,
    left: 16,
    zIndex: 100,
    backgroundColor: 'rgba(10, 25, 41, 0.9)',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  counterContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  counterText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
    marginBottom: 8,
  },
  ratingStars: {
    flexDirection: 'row',
    gap: 2,
  },
  ratingText: {
    color: LIGHT_SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  ratingCount: {
    color: '#9CA3AF',
    fontSize: 12,
    fontWeight: '400',
  },
});
