import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
  Image,
  ScrollView,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import { BOOKING_CARD, CURVED_BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../src/constants/mapConstants';
import InfoIconButton from '../../../../src/components/shared/InfoIconButton';

const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  created_at?: string | null;
  rating?: number | null;
  imageUrl?: string | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [hubMode, setHubMode] = useState<'wash' | 'detailing'>('wash');
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [radiusModalVisible, setRadiusModalVisible] = useState(false);
  const [infoModalHub, setInfoModalHub] = useState<HubRow | null>(null);
  const [hubStats, setHubStats] = useState<{ completed: number; active: number } | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude ?? 51.5074,
    longitude: coords?.longitude ?? -0.1278,
    latitudeDelta: 0.002,
    longitudeDelta: 0.002,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  // Keep map centered on live location when no hub selected; when coords updates, show user
  useEffect(() => {
    if (coords && !selectedHub) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
  }, [coords?.latitude, coords?.longitude, selectedHub]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();

    loadHubs();
  }, []);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered,created_at,rating');

      if (error) throw error;
      const rows = (data || []).map((h: any) => ({
        ...h,
        imageUrl: undefined,
      }));
      setHubs(normalizeHubs(rows));
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    }
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;
      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;
      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    let list = hubs;
    if (hubMode === 'detailing') {
      list = list.filter((h) => h.detailing_offered === true);
    }
    if (!coords) return list;
    return list
      .map((hub) => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= radiusMiles)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, hubMode, coords, radiusMiles, calculateDistance]);

  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    const lat = hub.latitude ?? 51.5074;
    const lng = hub.longitude ?? -0.1278;
    setRegion({
      latitude: lat,
      longitude: lng,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });
  };

  const handleContinue = async () => {
    if (!selectedHub) return;
    await hapticFeedback('medium');
    const isDetailing = hubMode === 'detailing';
    if (!vehicleId) {
      // Location-first flow: go to vehicle selection with locationId, then service → schedule → confirm → payment
      router.push({
        pathname: isDetailing ? '/owner/booking/detailing/physical' : '/owner/booking/physical/vehicle',
        params: { locationId: selectedHub.id },
      });
      return;
    }
    router.push({
      pathname: isDetailing ? '/owner/booking/detailing/physical/service' : '/owner/booking/physical/service',
      params: { locationId: selectedHub.id, vehicleId },
    });
  };

  const openRadiusModal = async () => {
    await hapticFeedback('light');
    setRadiusModalVisible(true);
  };

  const openHubInfo = async (hub: HubRow) => {
    hapticFeedback('light');
    setInfoModalHub(hub);
    setHubStats(null);
    try {
      const [completedRes, activeRes] = await Promise.all([
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).eq('status', 'completed'),
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).in('status', ['scheduled', 'in_progress', 'valeter_assigned', 'en_route', 'arrived']),
      ]);
      setHubStats({
        completed: (completedRes as { count?: number })?.count ?? 0,
        active: (activeRes as { count?: number })?.count ?? 0,
      });
    } catch {
      setHubStats({ completed: 0, active: 0 });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <MapView style={StyleSheet.absoluteFill} region={region} showsUserLocation>
        {filteredHubs.map((hub) => {
          const distance = calculateDistance(hub);
          const outOfRange = distance && Number(distance) > radiusMiles;
          return (
            <Marker
              key={hub.id}
              coordinate={{ latitude: hub.latitude ?? 51.5074, longitude: hub.longitude ?? -0.1278 }}
              onPress={() => handleHubSelect(hub)}
            >
              <Image
                source={hubMode === 'detailing' ? require('../../../../assets/detailing.png') : require('../../../../assets/cleaning.png')}
                style={[styles.marker, outOfRange && { opacity: 0.4 }]}
              />
            </Marker>
          );
        })}
      </MapView>

      {/* Wash / Detailing toggle - same level and size as mobile valeter (create) flow */}
      <View style={[styles.serviceModeToggle, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 12, position: 'absolute', left: 16, right: 16, zIndex: 10 }]}>
        <TouchableOpacity
          onPress={() => { hapticFeedback('light'); setHubMode('wash'); setSelectedHub(null); }}
          style={[styles.serviceModePill, hubMode === 'wash' && styles.serviceModePillActive]}
          activeOpacity={0.8}
        >
          <Ionicons name="water-outline" size={18} color={hubMode === 'wash' ? '#FFFFFF' : SKY} />
          <Text style={[styles.serviceModeLabel, hubMode === 'wash' && styles.serviceModeLabelActive]}>Wash</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => { hapticFeedback('light'); setHubMode('detailing'); setSelectedHub(null); }}
          style={[styles.serviceModePill, hubMode === 'detailing' && styles.serviceModePillActiveDetail]}
          activeOpacity={0.8}
        >
          <Ionicons name="diamond-outline" size={18} color={hubMode === 'detailing' ? '#FFFFFF' : DETAILING_YELLOW} />
          <Text style={[styles.serviceModeLabel, hubMode === 'detailing' && styles.serviceModeLabelActiveDetail]}>Detail</Text>
        </TouchableOpacity>
      </View>

      {/* Recentre button – consistent position on map */}
      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          if (coords) {
            setRegion({ latitude: coords.latitude, longitude: coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
          } else {
            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== 'granted') return;
              const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
            } catch {}
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title={hubMode === 'detailing' ? 'Detail Hubs' : 'Nearby Wash Hubs'}
        subtitle={hubMode === 'detailing' ? 'Select a detail hub' : 'Select a wash hub'}
        showBack
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity onPress={openRadiusModal} style={styles.radiusButton} activeOpacity={0.8}>
            <Ionicons name="radio-button-on" size={18} color={SKY} />
            <Text style={styles.radiusButtonText}>{radiusMiles} mi</Text>
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          { opacity: fadeAnim, transform: [{ translateY: slideAnim }], bottom: 96 + Math.max(insets.bottom, 14) },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
        >
          {filteredHubs.map((hub) => {
            const distance = calculateDistance(hub);
            const primaryColor = hubMode === 'detailing' ? DETAILING_YELLOW : SKY;
            return (
              <View key={hub.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <TouchableOpacity
                  onPress={() => handleHubSelect(hub)}
                  activeOpacity={0.9}
                  style={styles.hubCardTouchable}
                >
                  <BlurView intensity={28} tint="dark" style={[styles.hubCard, { borderColor: primaryColor + '30' }]}>
                    <View style={[styles.hubCardStripCurved, { backgroundColor: primaryColor }]} />
                    <View style={styles.hubCardInner}>
                      <View style={styles.cardTop}>
                        <View style={[styles.hubIconWrap, { backgroundColor: primaryColor + '18', borderColor: primaryColor + '30' }]}>
                          <Ionicons name="business" size={28} color={primaryColor} />
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{hub.name}</Text>
                            <InfoIconButton
                              onPress={() => { hapticFeedback('light'); openHubInfo(hub); }}
                              accentColor={primaryColor}
                            />
                          </View>
                          <Text style={styles.cardSubtitle} numberOfLines={2}>{hub.address}</Text>
                          {distance != null && (
                            <View style={[styles.quickHint, { backgroundColor: primaryColor + '18' }]}>
                              <Ionicons name="navigate-outline" size={11} color={primaryColor} />
                              <Text style={[styles.quickHintText, { color: primaryColor }]}>{distance} mi</Text>
                            </View>
                          )}
                        </View>
                      </View>
                      <View style={[styles.ctaDivider, { backgroundColor: primaryColor + '20' }]} />
                      <TouchableOpacity
                        onPress={() => handleHubSelect(hub)}
                        activeOpacity={0.85}
                        style={[styles.hubCtaBtn, { backgroundColor: primaryColor + '24', borderColor: primaryColor + '35' }]}
                      >
                        <Text style={[styles.hubCtaText, { color: primaryColor }]}>Confirm hub</Text>
                        <Ionicons name="arrow-forward" size={16} color={primaryColor} />
                      </TouchableOpacity>
                    </View>
                  </BlurView>
                </TouchableOpacity>
              </View>
            );
          })}
        </ScrollView>
      </Animated.View>

      {/* Continue button */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedHub}
          style={styles.ctaButtonOuter}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={selectedHub ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {(() => {
                if (selectedHub) return 'Continue';
                return hubMode === 'detailing' ? 'Select a detail hub' : 'Select a wash hub';
              })()}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Wash Hub info popup – same as dashboard top wash hub cards (BlurView + fade, centered) */}
      <Modal
        visible={!!infoModalHub}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalHub(null)}
      >
        <Pressable style={styles.washHubModalOverlay} onPress={() => setInfoModalHub(null)}>
          <Pressable style={styles.washHubModalContentWrap} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={32} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={styles.washHubModalContent}>
              {infoModalHub && (
                <>
                  <View style={styles.washHubModalHeader}>
                    <Text style={[styles.washHubModalTitle, { color: customerTheme.primary }]}>Wash Hub</Text>
                    <TouchableOpacity onPress={() => setInfoModalHub(null)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                      <Ionicons name="close" size={24} color={customerTheme.primary} />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.washHubModalName}>{infoModalHub.name}</Text>
                  {infoModalHub.address ? (
                    <View style={styles.washHubModalAddressRow}>
                      <Ionicons name="location-outline" size={14} color={SKY} />
                      <Text style={styles.washHubModalAddress} numberOfLines={2}>{infoModalHub.address}</Text>
                    </View>
                  ) : null}
                  <View style={styles.washHubModalStats}>
                    {infoModalHub.rating != null && (
                      <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                        <Ionicons name="star" size={14} color="#FBBF24" />
                        <Text style={[styles.washHubModalStatText, { color: '#FBBF24' }]}>{infoModalHub.rating.toFixed(1)}</Text>
                      </View>
                    )}
                    {hubStats && (
                      <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                        <Ionicons name="car-outline" size={14} color={customerTheme.primary} />
                        <Text style={[styles.washHubModalStatText, { color: customerTheme.primary }]}>{hubStats.completed} washes</Text>
                      </View>
                    )}
                    {hubStats && hubStats.active > 0 && (
                      <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                        <Ionicons name="time" size={14} color={customerTheme.primary} />
                        <Text style={[styles.washHubModalStatText, { color: customerTheme.primary }]}>{hubStats.active} active</Text>
                      </View>
                    )}
                  </View>
                  {infoModalHub.created_at && (
                    <View style={styles.washHubModalJoinedRow}>
                      <Ionicons name="calendar-outline" size={14} color={SKY} />
                      <Text style={styles.washHubModalJoinedText}>
                        Joined {new Date(infoModalHub.created_at).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                      </Text>
                    </View>
                  )}
                  {(infoModalHub.eco_washing || infoModalHub.detailing_offered) && (
                    <View style={styles.washHubModalStats}>
                      {infoModalHub.eco_washing && (
                        <View style={[styles.washHubModalStat, { backgroundColor: 'rgba(16,185,129,0.2)' }]}>
                          <Ionicons name="leaf" size={12} color="#10B981" />
                          <Text style={[styles.washHubModalStatText, { color: '#10B981' }]}>Eco</Text>
                        </View>
                      )}
                      {infoModalHub.detailing_offered && (
                        <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                          <Ionicons name="sparkles" size={12} color={customerTheme.primary} />
                          <Text style={[styles.washHubModalStatText, { color: customerTheme.primary }]}>Detailing</Text>
                        </View>
                      )}
                    </View>
                  )}
                </>
              )}
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Radius popup overlay */}
      <Modal
        visible={radiusModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRadiusModalVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setRadiusModalVisible(false)}
        >
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Search Radius</Text>
                <TouchableOpacity
                onPress={() => setRadiusModalVisible(false)}
                hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
              >
                <Ionicons name="close" size={24} color={colors.headerSubtext} />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalValue}>{radiusMiles} miles</Text>
            <Slider
              minimumValue={5}
              maximumValue={30}
              step={1}
              value={radiusMiles}
              onValueChange={setRadiusMiles}
              minimumTrackTintColor={SKY}
              maximumTrackTintColor="#334155"
              thumbTintColor={SKY}
              style={styles.slider}
            />
            <TouchableOpacity
              onPress={() => {
                setRadiusModalVisible(false);
                hapticFeedback('light');
              }}
              style={styles.modalDone}
              activeOpacity={0.9}
            >
              <Text style={styles.modalDoneText}>Done</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  marker: { width: 40, height: 40 },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 4,
  },
  serviceModePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  serviceModePillActive: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  serviceModePillActiveDetail: {
    backgroundColor: DETAILING_YELLOW,
    borderColor: DETAILING_YELLOW,
  },
  serviceModeLabel: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  serviceModeLabelActive: {
    color: '#FFFFFF',
  },
  serviceModeLabelActiveDetail: {
    color: '#FFFFFF',
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radiusButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(91, 143, 168, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(91, 143, 168, 0.4)',
  },
  radiusButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  hubCardStripCurved: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: BOOKING_CARD.BORDER_RADIUS,
    borderBottomLeftRadius: BOOKING_CARD.BORDER_RADIUS,
  },
  hubCardTouchable: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  hubCard: {
    ...CURVED_BOOKING_CARD,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1.5,
    padding: 20,
  },
  hubCardInner: {},
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  hubIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
  },
  cardSubtitle: {
    color: colors.headerSubtext,
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 10,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  ctaDivider: {
    height: 1,
    marginTop: 12,
    marginBottom: 10,
    borderRadius: 1,
  },
  hubCtaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    gap: 6,
    borderRadius: 18,
    borderWidth: 1,
  },
  hubCtaText: {
    fontSize: 14,
    fontWeight: '700',
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButtonOuter: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  ctaButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 320,
    backgroundColor: '#1E293B',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: 18,
    fontWeight: '700',
  },
  modalValue: {
    color: SKY,
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 16,
    textAlign: 'center',
  },
  slider: {
    width: '100%',
    height: 40,
    marginBottom: 20,
  },
  modalDone: {
    backgroundColor: SKY,
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  washHubModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  washHubModalContentWrap: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '85%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  washHubModalContent: {
    padding: 20,
    backgroundColor: 'transparent',
  },
  washHubModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  washHubModalTitle: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  washHubModalName: {
    color: colors.headerText,
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  washHubModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 12,
  },
  washHubModalAddress: {
    color: colors.headerSubtext,
    fontSize: 13,
    flex: 1,
    opacity: 0.95,
  },
  washHubModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  washHubModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  washHubModalStatText: {
    fontSize: 12,
    fontWeight: '700',
  },
  washHubModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalJoinedText: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '600',
  },
});
