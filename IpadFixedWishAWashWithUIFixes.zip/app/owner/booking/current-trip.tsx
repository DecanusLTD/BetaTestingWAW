import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Animated,
  TouchableOpacity,
  ScrollView,
  Linking,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import ValeterDeclinedOverlay from '../../../src/components/booking/ValeterDeclinedOverlay';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { regionForCoordinates, FIT_PADDING } from '../../../src/utils/mapUtils';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type BookingStatus = 'en_route' | 'arrived' | 'in_progress' | 'nearly_there';

type TripStep = {
  id: BookingStatus | 'complete';
  label: string;
  completed: boolean;
  active: boolean;
};

export default function CurrentTrip() {
  const insets = useSafeAreaInsets();
  useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<Record<string, unknown> | null>(null);
  const [status, setStatus] = useState<BookingStatus>('en_route');
  const [eta] = useState<string>('5 min');
  const { coords: liveCoords } = useLiveLocation();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [destinationLocation, setDestinationLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);
  const [showValeterDeclinedOverlay, setShowValeterDeclinedOverlay] = useState(false);

  const slideAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 1,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();

    if (liveCoords) {
      const c = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(c);
      updateMapRegion(c);
    }
    loadBooking();
    getCurrentLocation();
    subscribeToBooking();
  }, [bookingId, liveCoords]);

  useEffect(() => {
    // Animate progress based on status
    const progressMap: Record<BookingStatus, number> = {
      en_route: 0.25,
      nearly_there: 0.5,
      arrived: 0.75,
      in_progress: 0.9,
    };
    Animated.spring(progressAnim, {
      toValue: progressMap[status] || 0,
      tension: 50,
      friction: 8,
      useNativeDriver: false,
    }).start();
  }, [status]);

  const getCurrentLocation = async () => {
    try {
      const { status: permStatus } = await Location.requestForegroundPermissionsAsync();
      if (permStatus !== 'granted') return;

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      updateMapRegion(coords);
    } catch (error) {
      console.warn('Error getting location:', error);
    }
  };

  const updateMapRegion = (center: { latitude: number; longitude: number }) => {
    setRegion({
      latitude: center.latitude,
      longitude: center.longitude,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });
  };

  // Fit map so user and destination are always visible
  useEffect(() => {
    if (!userLocation || !destinationLocation) return;
    setRegion(regionForCoordinates([userLocation, destinationLocation], 0.4));
  }, [userLocation?.latitude, userLocation?.longitude, destinationLocation?.latitude, destinationLocation?.longitude]);

  const handleRecenterMap = () => {
    hapticFeedback('light');
    const coords: Array<{ latitude: number; longitude: number }> = [];
    if (userLocation) coords.push(userLocation);
    if (destinationLocation) coords.push(destinationLocation);
    if (coords.length >= 1 && mapRef.current) {
      mapRef.current.fitToCoordinates(coords, { edgePadding: FIT_PADDING, animated: true });
    }
  };

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          customer_vehicles:customer_vehicles(*),
          profiles:user_id(full_name, phone)
        `)
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);

      // Set status
      if (data.status === 'en_route') setStatus('en_route');
      else if (data.status === 'arrived') setStatus('arrived');
      else if (data.status === 'in_progress') setStatus('in_progress');

      // Get destination coordinates (region will fit both in useEffect when userLocation is set)
      if (data.latitude && data.longitude) {
        setDestinationLocation({
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
        });
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setBooking(updated);
          if (updated.status === 'arrived') setStatus('arrived');
          else if (updated.status === 'in_progress') setStatus('in_progress');
          // Real-time sync: job cancelled/declined → show gamified overlay
          else if (
            updated.status === 'cancelled' ||
            updated.status === 'valeter_declined' ||
            updated.status === 'valeter_timeout'
          ) {
            setShowValeterDeclinedOverlay(true);
          }
          // Completed → go to completion
          else if (updated.status === 'completed') {
            router.replace({
              pathname: '/owner/booking/completion',
              params: { bookingId },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleMarkAsArriving = async () => {
    await hapticFeedback('medium');
    // Update booking status
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'arrived' })
        .eq('id', bookingId);
      if (error) throw error;
      setStatus('arrived');
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleCall = () => {
    if (booking?.profiles?.phone) {
      Linking.openURL(`tel:${booking.profiles.phone}`);
    }
  };

  const handleMessage = () => {
    // Navigate to chat or open messaging
    router.push({
      pathname: '/owner/booking/chat',
      params: { bookingId },
    });
  };

  const getStatusLabel = () => {
    switch (status) {
      case 'en_route':
        return 'On the way!';
      case 'nearly_there':
        return 'Nearly there!';
      case 'arrived':
        return 'Arrived!';
      case 'in_progress':
        return 'Washing';
      default:
        return 'On the way!';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'en_route':
        return '#10B981';
      case 'nearly_there':
        return '#F59E0B';
      case 'arrived':
        return '#3B82F6';
      case 'in_progress':
        return PREMIUM_PURPLE;
      default:
        return '#10B981';
    }
  };

  const steps: TripStep[] = [
    { id: 'en_route', label: 'On the way', completed: false, active: status === 'en_route' },
    { id: 'nearly_there', label: 'Nearly there', completed: status !== 'en_route', active: status === 'nearly_there' },
    { id: 'in_progress', label: 'Washing', completed: ['arrived', 'in_progress'].includes(status), active: status === 'in_progress' },
    { id: 'complete', label: 'Complete', completed: false, active: false },
  ];

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen Map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {destinationLocation && (
            <Marker coordinate={destinationLocation}>
              <View style={styles.destinationMarkerContainer}>
                <View style={styles.destinationMarkerPin}>
                  <Ionicons name="location" size={28} color="#EF4444" />
                </View>
                <View style={styles.destinationMarkerLabel}>
                  <Text style={styles.destinationMarkerText}>Destination</Text>
                </View>
              </View>
            </Marker>
          )}

          {userLocation && destinationLocation && (
            <Polyline
              coordinates={[userLocation, destinationLocation]}
              strokeColor={SKY}
              strokeWidth={4}
              lineDashPattern={[5, 5]}
            />
          )}
        </MapView>
      </View>

      {/* Re-center / Fit journey button */}
      {userLocation && destinationLocation && (
        <TouchableOpacity
          onPress={handleRecenterMap}
          style={[styles.recenterButton, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
          activeOpacity={0.85}
        >
          <View style={styles.recenterButtonInner}>
            <Ionicons name="locate" size={22} color={SKY} />
          </View>
        </TouchableOpacity>
      )}

      <AppHeader
        title="Current Trip"
        subtitle={getStatusLabel()}
        showBack
        onBack={() => router.back()}
      />

      {/* Status Bar */}
      <Animated.View
        style={[
          styles.statusBar,
          {
            opacity: slideAnim,
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-50, 0],
                }),
              },
            ],
          },
        ]}
      >
        <BlurView intensity={90} tint="dark" style={styles.statusBarBlur}>
          <Text style={styles.statusBarText}>
            Current: <Text style={styles.statusBarHighlight}>{getStatusLabel()}</Text>
          </Text>
        </BlurView>
      </Animated.View>

      {/* Action Button */}
      {status === 'en_route' && (
        <Animated.View
          style={[
            styles.actionButtonContainer,
            {
              opacity: slideAnim,
              transform: [
                {
                  translateY: slideAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [50, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <TouchableOpacity
            onPress={handleMarkAsArriving}
            style={styles.actionButton}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[SKY, '#0EA5E9']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="location" size={20} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Mark as arriving</Text>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      )}

      {/* Main Trip Details Card */}
      <Animated.View
        style={[
          styles.tripCard,
          {
            opacity: slideAnim,
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [100, 0],
                }),
              },
            ],
          },
        ]}
      >
        <BlurView intensity={90} tint="dark" style={styles.tripCardBlur}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.tripCardContent}
          >
            {/* Status Section */}
            <View style={styles.statusSection}>
              <View style={styles.statusLeft}>
                <View style={[styles.statusDot, { backgroundColor: getStatusColor() }]} />
                <Text style={styles.statusText}>{getStatusLabel()}</Text>
              </View>
              <View style={styles.statusRight}>
                <Text style={styles.etaText}>ETA: {eta}</Text>
                <TouchableOpacity style={styles.etaButton} activeOpacity={0.7}>
                  <Ionicons name="chevron-up" size={16} color="rgba(255,255,255,0.7)" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Customer/Destination Info */}
            <View style={styles.customerSection}>
              <View style={styles.customerLeft}>
                <View style={styles.customerAvatar}>
                  <Ionicons name="person" size={28} color={SKY} />
                </View>
                <View style={styles.customerInfo}>
                  <Text style={styles.customerAddress} numberOfLines={2}>
                    {booking?.address || '289 Ordsall Lane, M5 3HP, Salford, England, United Kingdom'}
                  </Text>
                  <Text style={styles.serviceInfo}>
                    {booking?.service_type || 'priority_wash'} • £{booking?.price || '62.00'}
                  </Text>
                </View>
              </View>
              <View style={styles.customerActions}>
                <TouchableOpacity
                  onPress={handleCall}
                  style={styles.contactButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="call" size={20} color="rgba(255,255,255,0.8)" />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleMessage}
                  style={styles.contactButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="chatbubble-ellipses" size={20} color="rgba(255,255,255,0.8)" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Progress Steps */}
            <View style={styles.progressSection}>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground}>
                  <Animated.View
                    style={[
                      styles.progressBarFill,
                      {
                        width: progressWidth,
                        backgroundColor: getStatusColor(),
                      },
                    ]}
                  />
                </View>
              </View>
              <View style={styles.stepsContainer}>
                {steps.map((step, index) => (
                  <View key={step.id} style={styles.stepItem}>
                    <View
                      style={[
                        styles.stepDot,
                        step.completed && styles.stepDotCompleted,
                        step.active && styles.stepDotActive,
                        step.completed && { backgroundColor: getStatusColor() },
                        step.active && { backgroundColor: getStatusColor() },
                      ]}
                    />
                    <Text
                      style={[
                        styles.stepLabel,
                        step.active && styles.stepLabelActive,
                        step.completed && styles.stepLabelCompleted,
                      ]}
                    >
                      {step.label}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Location Details */}
            <View style={styles.locationSection}>
              <Text style={styles.locationTitle}>Location</Text>
              <Text style={styles.locationAddress}>
                {booking?.address || '289 Ordsall Lane, M5 3HP, Salford, England, United Kingdom'}
              </Text>
            </View>
          </ScrollView>
        </BlurView>
      </Animated.View>

      <ValeterDeclinedOverlay
        visible={showValeterDeclinedOverlay}
        onFindNewValeter={() => {
          setShowValeterDeclinedOverlay(false);
          void (async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({
                  status: 'pending_valeter_acceptance',
                  valeter_id: null,
                  request_sent_at: new Date().toISOString(),
                })
                .eq('id', bookingId);
              if (error) throw error;
              router.replace({ pathname: '/owner/booking/valeter-selection', params: { bookingId } } as any);
            } catch (e) {
              console.error('Error reopening booking:', e);
              router.replace('/owner/owner-dashboard');
            }
          })();
        }}
        onBackToDashboard={() => {
          setShowValeterDeclinedOverlay(false);
          router.replace('/owner/owner-dashboard');
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    zIndex: 1000,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerRight: {
    width: 40,
  },
  statusBar: {
    position: 'absolute',
    top: 100,
    left: 16,
    right: 16,
    zIndex: 999,
  },
  statusBarBlur: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusBarText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    padding: 12,
    textAlign: 'center',
  },
  statusBarHighlight: {
    color: SKY,
    fontWeight: '900',
  },
  actionButtonContainer: {
    position: 'absolute',
    top: 160,
    left: 16,
    right: 16,
    zIndex: 998,
  },
  actionButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  tripCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.6,
    zIndex: 997,
  },
  tripCardBlur: {
    borderTopLeftRadius: BOOKING_CARD.BORDER_RADIUS,
    borderTopRightRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  tripCardContent: {
    padding: 24,
    paddingBottom: 48,
  },
  statusSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
    paddingBottom: 18,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  statusLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statusDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  statusRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  etaText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 16,
    fontWeight: '700',
  },
  etaButton: {
    width: 32,
    height: 32,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 26,
  },
  customerLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    flex: 1,
  },
  customerAvatar: {
    width: 54,
    height: 54,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerInfo: {
    flex: 1,
    gap: 8,
  },
  customerAddress: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
    lineHeight: 22,
  },
  serviceInfo: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  customerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  contactButton: {
    width: 44,
    height: 44,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressSection: {
    marginBottom: 24,
  },
  progressBarContainer: {
    marginBottom: 16,
  },
  progressBarBackground: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 2,
  },
  stepsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  stepItem: {
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  stepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  stepDotCompleted: {
    backgroundColor: SKY,
  },
  stepDotActive: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  stepLabel: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  stepLabelActive: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 14,
  },
  stepLabelCompleted: {
    color: 'rgba(255,255,255,0.8)',
  },
  locationSection: {
    gap: 10,
  },
  locationTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 6,
  },
  locationAddress: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 22,
  },
  recenterButton: {
    position: 'absolute',
    zIndex: 100,
  },
  recenterButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarkerImage: {
    width: 48,
    height: 48,
  },
  destinationMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  destinationMarkerPin: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: '#EF4444',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
  },
  destinationMarkerLabel: {
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  destinationMarkerText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
});
