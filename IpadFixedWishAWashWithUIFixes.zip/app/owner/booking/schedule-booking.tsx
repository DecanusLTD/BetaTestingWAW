import React from 'react';
import { View, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader from '../../../src/components/shared/AppHeader';

const DETAILING_YELLOW = colors.DETAILING_YELLOW;

export default function ScheduleBooking() {
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <AppHeader
        title=""
        showBack
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        primaryColor={DETAILING_YELLOW}
      />
      <View style={styles.iconWrap}>
        <View style={styles.iconButton}>
          <Ionicons name="calendar-outline" size={64} color={DETAILING_YELLOW} />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  iconWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconButton: {
    padding: 24,
  },
});
