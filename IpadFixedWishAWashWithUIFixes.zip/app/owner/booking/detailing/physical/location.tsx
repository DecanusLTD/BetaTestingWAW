import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  ScrollView,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../../src/lib/supabase';
import useLiveLocation from '../../../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../../src/components/shared/AppHeader';
import { RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../../src/constants/mapConstants';
import { customerTheme } from '../../../../../src/constants/customerTheme';
import { colors } from '../../../../../src/constants/colors';
import { Hub } from '../../../../../src/types/booking';
import { hapticFeedback } from '../../../../../src/services/HapticFeedbackService';
import InfoIconButton from '../../../../../src/components/shared/InfoIconButton';
import { BOOKING_CARD, CURVED_BOOKING_CARD } from '../../../../../src/constants/bookingCardTheme';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const ACCENT = colors.DETAILING_YELLOW;
const ACCENT_DARK = colors.DETAILING_YELLOW_DARK;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

type LatLng = { latitude: number; longitude: number };

type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  created_at?: string | null;
  rating?: number | null;
  imageUrl?: string | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [radiusModalVisible, setRadiusModalVisible] = useState(false);
  const [infoModalHub, setInfoModalHub] = useState<HubRow | null>(null);
  const [hubStats, setHubStats] = useState<{ completed: number; active: number } | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude ?? 51.5074,
    longitude: coords?.longitude ?? -0.1278,
    latitudeDelta: 0.002,
    longitudeDelta: 0.002,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    if (coords && !selectedHub) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
  }, [coords?.latitude, coords?.longitude, selectedHub]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();

    loadHubs();
  }, []);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered,created_at,rating');

      if (error) throw error;
      const rows = (data || []).map((h: any) => ({
        ...h,
        imageUrl: undefined,
      }));
      const all = normalizeHubs(rows);
      setHubs(all.filter((h) => h.detailing_offered === true));
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    }
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;
      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;
      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    if (!coords) return hubs;
    return hubs
      .map((hub) => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= radiusMiles)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, coords, radiusMiles, calculateDistance]);

  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    setRegion({
      latitude: hub.latitude,
      longitude: hub.longitude,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });
  };

  const handleContinue = async () => {
    if (!selectedHub || !vehicleId) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/detailing/physical/service',
      params: { locationId: selectedHub.id, vehicleId },
    });
  };

  const openRadiusModal = async () => {
    await hapticFeedback('light');
    setRadiusModalVisible(true);
  };

  const openHubInfo = async (hub: HubRow) => {
    hapticFeedback('light');
    setInfoModalHub(hub);
    setHubStats(null);
    try {
      const [completedRes, activeRes] = await Promise.all([
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).eq('status', 'completed'),
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).in('status', ['scheduled', 'in_progress', 'valeter_assigned', 'en_route', 'arrived']),
      ]);
      setHubStats({
        completed: (completedRes as { count?: number })?.count ?? 0,
        active: (activeRes as { count?: number })?.count ?? 0,
      });
    } catch {
      setHubStats({ completed: 0, active: 0 });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <MapView style={StyleSheet.absoluteFill} region={region} showsUserLocation>
        {hubs.map((hub) => {
          const distance = calculateDistance(hub);
          const outOfRange = distance && Number(distance) > radiusMiles;
          return (
            <Marker
              key={hub.id}
              coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
              onPress={() => handleHubSelect(hub)}
            >
              <Image
                source={require('../../../../../assets/cleaning.png')}
                style={[styles.marker, outOfRange && { opacity: 0.4 }]}
              />
            </Marker>
          );
        })}
      </MapView>

      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          if (coords) {
            setRegion({ latitude: coords.latitude, longitude: coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
          } else {
            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== 'granted') return;
              const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
            } catch {}
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={ACCENT} />
      </TouchableOpacity>

      <AppHeader
        title="Nearby Detail Hubs"
        subtitle="We've found nearby detail hubs"
        showBack
        onBack={() => router.back()}
        primaryColor={ACCENT}
        rightAction={
          <TouchableOpacity onPress={openRadiusModal} style={styles.radiusButton} activeOpacity={0.8}>
            <Ionicons name="radio-button-on" size={18} color={ACCENT} />
            <Text style={styles.radiusButtonText}>{radiusMiles} mi</Text>
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          { opacity: fadeAnim, transform: [{ translateY: slideAnim }], bottom: 96 + Math.max(insets.bottom, 14) },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
        >
          {filteredHubs.map((hub) => {
            const distance = calculateDistance(hub);
            const gradient = [ACCENT, ACCENT_DARK, '#B45309'];
            return (
              <View key={hub.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <TouchableOpacity
                  onPress={() => handleHubSelect(hub)}
                  activeOpacity={0.95}
                  style={styles.curvedCardTouchable}
                >
                  <BlurView intensity={55} tint="dark" style={[styles.curvedCard, styles.curvedCardBlur]}>
                    <View style={[styles.curvedStrip, { backgroundColor: ACCENT }]} />
                    <LinearGradient
                      colors={[...gradient.map((c: string) => c + '12'), 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.modernCard}>
                    <View style={styles.cardInner}>
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: ACCENT + '25', borderColor: ACCENT + '40' }]}>
                          <LinearGradient
                            colors={gradient}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                            style={styles.iconGradient}
                          >
                            <Ionicons name="business" size={30} color="#FFFFFF" />
                          </LinearGradient>
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{hub.name}</Text>
                            <InfoIconButton
                              onPress={() => { hapticFeedback('light'); openHubInfo(hub); }}
                              accentColor={ACCENT}
                            />
                          </View>
                          <Text style={styles.cardSubtitle} numberOfLines={2}>{hub.address}</Text>
                          <View style={styles.cardMetaRow}>
                            {distance != null && (
                              <View style={[styles.quickHint, { backgroundColor: ACCENT + '15' }]}>
                                <Ionicons name="navigate-outline" size={11} color={ACCENT} />
                                <Text style={[styles.quickHintText, { color: ACCENT }]}>{distance} mi</Text>
                              </View>
                            )}
                          </View>
                        </View>
                      </View>
                      <View style={[styles.ctaDivider, { backgroundColor: ACCENT + '20' }]} />
                      <TouchableOpacity
                        onPress={() => handleHubSelect(hub)}
                        activeOpacity={0.9}
                        style={styles.cardCtaButton}
                      >
                        <LinearGradient
                          colors={gradient}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={styles.cardCtaGradient}
                        >
                          <Text style={styles.cardCtaText}>Confirm {hub.name}</Text>
                          <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </View>
                  </BlurView>
                </TouchableOpacity>
              </View>
            );
          })}
        </ScrollView>
      </Animated.View>

      {/* Continue Button - separate from cards */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedHub}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={selectedHub ? [ACCENT, ACCENT_DARK] : ['#475569', '#334155']}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {selectedHub ? 'Continue' : 'Select a detail hub'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Hub info popup - dashboard-style with cover photo and profile pic */}
      <Modal
        visible={!!infoModalHub}
        transparent
        animationType="slide"
        onRequestClose={() => setInfoModalHub(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalHub(null)}>
          <Pressable style={styles.hubInfoModalContent} onPress={(e) => e.stopPropagation()}>
            {infoModalHub && (
              <View style={styles.hubInfoModalInner}>
                <View style={styles.hubInfoModalHeader}>
                  <Text style={styles.hubInfoModalTitle}>Detail Hub Profile</Text>
                  <TouchableOpacity onPress={() => setInfoModalHub(null)} hitSlop={12}>
                    <Ionicons name="close" size={24} color={customerTheme.primary} />
                  </TouchableOpacity>
                </View>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.hubInfoModalScroll}>
                  <View style={styles.hubInfoCover}>
                    {infoModalHub.imageUrl ? (
                      <Image source={{ uri: infoModalHub.imageUrl }} style={styles.hubInfoCoverImg} resizeMode="cover" />
                    ) : (
                      <View style={styles.hubInfoCoverPlaceholder}>
                        <Ionicons name="business" size={48} color="rgba(148,163,184,0.6)" />
                        <Text style={styles.hubInfoCoverPlaceholderText}>Cover photo</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.hubInfoLogo}>
                    {infoModalHub.imageUrl ? (
                      <Image source={{ uri: infoModalHub.imageUrl }} style={styles.hubInfoLogoImg} resizeMode="cover" />
                    ) : (
                      <View style={styles.hubInfoLogoInner}>
                        <Ionicons name="business" size={36} color={ACCENT} />
                      </View>
                    )}
                  </View>
                  <Text style={styles.hubInfoTitle}>{infoModalHub.name}</Text>
                  {infoModalHub.created_at && (
                    <View style={styles.hubInfoJoinedRow}>
                      <Ionicons name="calendar-outline" size={16} color={ACCENT} />
                      <Text style={[styles.hubInfoJoinedText, { color: ACCENT }]}>
                        Joined {new Date(infoModalHub.created_at).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                      </Text>
                    </View>
                  )}
                  {infoModalHub.address ? (
                    <View style={styles.hubInfoAddressRow}>
                      <Ionicons name="location-outline" size={16} color={ACCENT} />
                      <Text style={styles.hubInfoAddress}>{infoModalHub.address}</Text>
                    </View>
                  ) : null}
                  <View style={styles.hubInfoStats}>
                    {infoModalHub.rating != null && (
                      <View style={styles.hubInfoStat}>
                        <Ionicons name="star" size={18} color="#FBBF24" />
                        <Text style={styles.hubInfoStatText}>{infoModalHub.rating.toFixed(1)}</Text>
                      </View>
                    )}
                    {hubStats && (
                      <View style={styles.hubInfoStat}>
                        <Ionicons name="car-outline" size={18} color={ACCENT} />
                        <Text style={styles.hubInfoStatText}>{hubStats.completed} washes</Text>
                      </View>
                    )}
                    {hubStats && hubStats.active > 0 && (
                      <View style={styles.hubInfoStat}>
                        <Ionicons name="time" size={18} color={ACCENT} />
                        <Text style={styles.hubInfoStatText}>{hubStats.active} active</Text>
                      </View>
                    )}
                  </View>
                  {(infoModalHub.eco_washing || infoModalHub.detailing_offered) && (
                    <View style={styles.hubInfoTags}>
                      {infoModalHub.eco_washing && (
                        <View style={styles.hubInfoTag}>
                          <Ionicons name="leaf" size={12} color="#10B981" />
                          <Text style={styles.hubInfoTagText}>Eco</Text>
                        </View>
                      )}
                      {infoModalHub.detailing_offered && (
                        <View style={styles.hubInfoTag}>
                          <Ionicons name="sparkles" size={12} color={ACCENT} />
                          <Text style={styles.hubInfoTagText}>Detailing</Text>
                        </View>
                      )}
                    </View>
                  )}
                </ScrollView>
              </View>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Radius popup overlay */}
      <Modal
        visible={radiusModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRadiusModalVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setRadiusModalVisible(false)}
        >
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Search Radius</Text>
              <TouchableOpacity
                onPress={() => setRadiusModalVisible(false)}
                hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
              >
                <Ionicons name="close" size={24} color={customerTheme.primary} />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalValue}>{radiusMiles} miles</Text>
            <Slider
              minimumValue={5}
              maximumValue={30}
              step={1}
              value={radiusMiles}
              onValueChange={setRadiusMiles}
              minimumTrackTintColor={ACCENT}
              maximumTrackTintColor="#334155"
              thumbTintColor={ACCENT}
              style={styles.slider}
            />
            <TouchableOpacity
              onPress={() => {
                setRadiusModalVisible(false);
                hapticFeedback('light');
              }}
              style={styles.modalDone}
              activeOpacity={0.9}
            >
              <Text style={styles.modalDoneText}>Done</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  marker: { width: 40, height: 40 },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: ACCENT,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radiusButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(91, 143, 168, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(91, 143, 168, 0.4)',
  },
  radiusButtonText: {
    color: ACCENT,
    fontSize: 14,
    fontWeight: '700',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  curvedCardTouchable: {
    borderRadius: CURVED_BOOKING_CARD.borderRadius,
    overflow: 'hidden',
    ...CURVED_BOOKING_CARD,
  },
  curvedCard: {
    borderRadius: CURVED_BOOKING_CARD.borderRadius,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  curvedCardBlur: {
    flex: 1,
    padding: 0,
  },
  curvedStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: CURVED_BOOKING_CARD.borderRadius,
    borderBottomLeftRadius: CURVED_BOOKING_CARD.borderRadius,
  },
  modernCard: {
    padding: 20,
    overflow: 'hidden',
  },
  cardInner: {},
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    overflow: 'hidden',
    marginRight: 14,
    borderWidth: 1,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 10,
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  cardCtaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  cardCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  cardCtaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 320,
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitle: {
    color: customerTheme.primary,
    fontSize: 18,
    fontWeight: '800',
  },
  modalValue: {
    color: ACCENT,
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 16,
    textAlign: 'center',
  },
  slider: {
    width: '100%',
    height: 40,
    marginBottom: 20,
  },
  modalDone: {
    backgroundColor: ACCENT,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  hubInfoModalContent: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '85%',
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  hubInfoModalInner: {
    flex: 1,
  },
  hubInfoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  hubInfoModalTitle: {
    color: customerTheme.primary,
    fontSize: 18,
    fontWeight: '800',
  },
  hubInfoModalScroll: {
    maxHeight: 400,
    paddingHorizontal: 20,
  },
  hubInfoCover: {
    height: 120,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  hubInfoCoverImg: {
    width: '100%',
    height: '100%',
  },
  hubInfoCoverPlaceholder: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: customerTheme.primary + '12',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  hubInfoCoverPlaceholderText: {
    color: colors.headerSubtext,
    fontSize: 13,
  },
  hubInfoLogo: {
    alignItems: 'center',
    marginTop: -28,
    marginBottom: 12,
  },
  hubInfoLogoImg: {
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 2,
    borderColor: ACCENT,
  },
  hubInfoLogoInner: {
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: customerTheme.backgroundColor,
    borderWidth: 2,
    borderColor: ACCENT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubInfoJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginBottom: 12,
  },
  hubInfoJoinedText: {
    fontSize: 13,
    fontWeight: '600',
  },
  hubInfoAddressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  hubInfoTitle: {
    color: colors.headerText,
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  hubInfoAddress: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    flex: 1,
    opacity: 0.95,
  },
  hubInfoStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 16,
  },
  hubInfoStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  hubInfoStatText: {
    color: colors.headerText,
    fontSize: 14,
    opacity: 0.92,
  },
  hubInfoTags: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 16,
  },
  hubInfoTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: customerTheme.primary + '18',
  },
  hubInfoTagText: {
    color: ACCENT,
    fontSize: 12,
    fontWeight: '600',
  },
  hubInfoDone: {
    margin: 20,
    marginTop: 0,
    backgroundColor: ACCENT,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  hubInfoDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
