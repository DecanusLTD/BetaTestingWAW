import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
  Alert,
  Animated as RNAnimated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import LoadingScreen from '../../src/components/LoadingScreen';
import EmptyState from '../../src/components/shared/EmptyState';
import GlassCard from '@/components/booking/GlassCard';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../src/constants/layoutConstants';
import { CONTENT_PADDING_H, sectionHeader as sectionHeaderStyle, sectionHeaderIcon } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { customerTheme } from '../../src/constants/customerTheme';
import { BORDER_RADIUS } from '../../src/constants/designTokens';
import Animated, { FadeInDown } from 'react-native-reanimated';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const RATING_GOLD = '#F59E0B';

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'tipped'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'tipped',
  'closed',
  'archived',
  'complete',
]);

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

export default function WashHistory() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const scrollY = useRef(new RNAnimated.Value(0)).current;

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  // ✅ Schema-safe mapping for your `public.bookings`
  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null, // not in schema
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null, // not in schema
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // -------------------------
      // Completed bookings (history)
      // -------------------------
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `
          id,
          user_id,
          status,
          service_name,
          service_type,
          wash_type,
          price,
          scheduled_at,
          created_at,
          completed_at,
          valeter_name,
          location_address,
          location_lat,
          location_lng,
          rating,
          customer_review,
          tip_amount,
          special_instructions,
          cancelled_at
        `
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        // completed_at is the main signal, but allow status=completed too
        .or('completed_at.not.is.null,status.eq.completed')
        .order('completed_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const completedList = normalizeFromBookings(completedRows || [])
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);

      setWashCompletions(completedList);
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const performDeleteOne = useCallback(async (completion: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .eq('id', completion.id)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions((prev) => prev.filter((c) => c.id !== completion.id));
    } catch (e) {
      console.error('[wash-history] Delete error:', e);
      Alert.alert('Error', 'Could not remove from history');
    }
  }, [user?.id]);

  const handleDeleteOne = useCallback(
    (completion: NormalizedCompletion) => {
      Alert.alert(
        'Remove from history',
        `Remove "${completion.serviceName ?? 'this booking'}" from your wash history?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Remove', style: 'destructive', onPress: () => { void performDeleteOne(completion); } },
        ]
      );
    },
    [performDeleteOne]
  );

  const performClearAll = useCallback(async () => {
    if (!user?.id) return;
    try {
      const ids = washCompletions.map((c) => c.id);
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .in('id', ids)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions([]);
    } catch (e) {
      console.error('[wash-history] Clear all error:', e);
      Alert.alert('Error', 'Could not clear history');
    }
  }, [user?.id, washCompletions]);

  const handleClearAll = useCallback(() => {
    if (washCompletions.length === 0) return;
    Alert.alert(
      'Clear wash history',
      `Remove all ${washCompletions.length} booking${washCompletions.length === 1 ? '' : 's'} from your history? You can't undo this.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Clear all', style: 'destructive', onPress: () => { void performClearAll(); } },
      ]
    );
  }, [washCompletions.length, performClearAll]);

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();

    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    }
  };

  const insets = useSafeAreaInsets();

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="History"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={
          <TouchableOpacity onPress={() => router.push('/owner/booking')} style={styles.bookButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <RNAnimated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...getScrollContentPadding(insets, true) }]}
        showsVerticalScrollIndicator={false}
        onScroll={RNAnimated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {washCompletions.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyContainer}>
            <EmptyState
              icon="time-outline"
              title="No Bookings Yet"
              subtitle="Your completed bookings will appear here"
              actionLabel="Book a Service"
              onAction={() => router.push('/owner/booking')}
              iconColor={SKY}
              style={styles.emptyState}
            />
          </Animated.View>
        ) : (
          <>
            {washCompletions.length > 0 && (
              <View style={styles.sectionContainer}>
                <View style={[sectionHeaderStyle, styles.sectionHeaderRow]}>
                  <View style={sectionHeaderIcon}>
                    <Ionicons name="checkmark-circle" size={18} color={SKY} />
                  </View>
                  <View style={styles.sectionHeaderText}>
                    <Text style={styles.sectionHeading}>Wash History</Text>
                    <Text style={styles.sectionSubtitleText}>{washCompletions.length} completed</Text>
                  </View>
                  <TouchableOpacity
                    onPress={handleClearAll}
                    style={styles.clearAllButton}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="trash-outline" size={20} color="#EF4444" />
                    <Text style={styles.clearAllText}>Clear all</Text>
                  </TouchableOpacity>
                </View>

                {washCompletions.map((completion, index) => {
                  const isHighlighted = highlightId === completion.id;
                  const serviceName = completion.serviceName ?? completion.service_type ?? 'Car Wash';
                  const price = completion.price ?? 0;
                  const valeterName = completion.valeterName;
                  const address = completion.address;

                  return (
                    <Animated.View
                      key={completion.id}
                      entering={FadeInDown.delay(index * 80)}
                      style={styles.bookingCardWrap}
                    >
                      <GlassCard style={[styles.bookingCard, isHighlighted && styles.highlightCard]} accountType="customer">
                        <View style={styles.bookingContent}>
                          <View style={styles.bookingHeader}>
                            <View style={styles.bookingIconWrapper}>
                              <Ionicons name="checkmark-circle" size={22} color={SKY} />
                            </View>

                            <View style={styles.bookingInfo}>
                              <Text style={styles.bookingService}>{serviceName}</Text>
                              <Text style={styles.bookingDate}>
                                {formatDate(completion.completedAt ?? completion.createdAt)}
                              </Text>
                            </View>

                            <TouchableOpacity
                              onPress={() => handleDeleteOne(completion)}
                              style={styles.deleteOneButton}
                              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                              activeOpacity={0.7}
                            >
                              <Ionicons name="trash-outline" size={20} color="#EF4444" />
                            </TouchableOpacity>

                            {completion.rating != null && (
                              <View style={[styles.ratingBadge, { backgroundColor: `${RATING_GOLD}20`, borderColor: `${RATING_GOLD}40` }]}>
                                <Ionicons name="star" size={14} color={RATING_GOLD} />
                                <Text style={[styles.ratingText, { color: RATING_GOLD }]}>{completion.rating}</Text>
                              </View>
                            )}
                          </View>

                          <View style={styles.bookingFooter}>
                            <View style={styles.bookingMeta}>
                              {valeterName && (
                                <View style={styles.metaItem}>
                                  <Ionicons name="person-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>{valeterName}</Text>
                                </View>
                              )}
                              {address && (
                                <View style={styles.metaItem}>
                                  <Ionicons name="location-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>
                                    {address}
                                  </Text>
                                </View>
                              )}
                            </View>

                            <View style={styles.priceContainer}>
                              <Text style={styles.bookingPrice}>{formatCurrency(price)}</Text>
                            </View>
                          </View>

                          <TouchableOpacity
                            style={styles.repeatButton}
                            onPress={() => handleRepeatBooking(completion)}
                            activeOpacity={0.8}
                          >
                            <LinearGradient
                              colors={[SKY, '#0EA5E9']}
                              style={styles.repeatButtonGradient}
                            >
                              <Ionicons name="repeat" size={16} color="#FFFFFF" />
                              <Text style={styles.repeatButtonText}>Repeat Booking</Text>
                            </LinearGradient>
                          </TouchableOpacity>
                        </View>
                      </GlassCard>
                    </Animated.View>
                  );
                })}
              </View>
            )}
          </>
        )}
      </RNAnimated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: {},

  bookButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(59,130,246,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.35)',
  },

  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyState: {
    minHeight: 260,
  },

  sectionContainer: {
    width: '100%',
    marginBottom: 24,
  },
  sectionHeaderRow: {
    marginBottom: 16,
  },
  sectionHeaderText: {
    flex: 1,
  },
  clearAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  clearAllText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '600',
  },
  deleteOneButton: {
    padding: 8,
    marginRight: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  sectionHeading: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 0.2,
    marginBottom: 2,
  },
  sectionSubtitleText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
  },

  bookingCardWrap: {
    marginBottom: 16,
  },
  bookingCard: {
    padding: 0,
    borderRadius: BORDER_RADIUS.lg,
    overflow: 'hidden',
  },
  highlightCard: {
    shadowColor: SKY,
    shadowOpacity: 0.25,
    shadowRadius: 10,
  },

  bookingContent: { padding: 16, gap: 10 },
  bookingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  bookingIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    backgroundColor: `${SKY}20`,
    borderWidth: 1,
    borderColor: `${SKY}40`,
  },
  bookingInfo: { flex: 1, minWidth: 0 },
  bookingService: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  bookingDate: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },

  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 10,
    gap: 4,
  },
  ratingText: {
    fontSize: 13,
    fontWeight: '700',
  },

  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(59,130,246,0.2)',
  },
  bookingMeta: {
    flexDirection: 'row',
    gap: 10,
    flex: 1,
    paddingRight: 8,
    minWidth: 0,
  },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4, flex: 1, minWidth: 0 },
  metaText: {
    fontSize: 12,
    fontWeight: '500',
    flexShrink: 1,
    color: 'rgba(255,255,255,0.7)',
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  bookingPrice: {
    color: LIGHT_SKY,
    fontSize: 16,
    fontWeight: '800',
  },

  repeatButton: {
    borderRadius: 12,
    marginTop: 4,
    overflow: 'hidden',
  },
  repeatButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  repeatButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
});