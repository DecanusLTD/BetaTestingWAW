import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Alert,
  ActivityIndicator,
  Dimensions,
  Animated,
  Linking,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";
import MapView, { Region, Marker, Polyline } from "react-native-maps";
import * as Location from "expo-location";
import { colors } from "../../src/constants/colors";
import AppHeader, { HEADER_CONTENT_OFFSET } from "../../src/components/shared/AppHeader";
import { customerTheme } from "../../src/constants/customerTheme";
import { hapticFeedback } from "../../src/services/HapticFeedbackService";

const SKY = colors.SKY ?? "#38BDF8";
const { width } = Dimensions.get("window");

type Params = {
  destLat: string;
  destLng: string;
  address?: string;
};

type RouteStep = {
  instruction: string;
  distance: number;
  endLatitude: number;
  endLongitude: number;
};

type RouteResult = {
  coordinates: { latitude: number; longitude: number }[];
  steps: RouteStep[];
  distance: number;
  expectedTravelTime: number;
};

function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function formatDistance(meters: number): string {
  if (meters < 1000) return `${Math.round(meters)} m`;
  const km = (meters / 1000).toFixed(1);
  return `${km} km`;
}

export default function NavigateScreen() {
  const params = useLocalSearchParams<Params>();
  const destLat = params.destLat ? parseFloat(params.destLat) : NaN;
  const destLng = params.destLng ? parseFloat(params.destLng) : NaN;
  const address = params.address ?? "Wash hub";

  const isValidDest = Number.isFinite(destLat) && Number.isFinite(destLng);
  const isIOS = Platform.OS === "ios";

  const [userLocation, setUserLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [loadingRoute, setLoadingRoute] = useState(isIOS && isValidDest);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [distanceToNextStep, setDistanceToNextStep] = useState<number | null>(null);
  const [region, setRegion] = useState<Region | null>(null);
  const slideAnim = useRef(new Animated.Value(0)).current;

  const destination = isValidDest
    ? { latitude: destLat, longitude: destLng }
    : null;

  // Load route (iOS only, MapKit)
  useEffect(() => {
    if (!isIOS || !isValidDest || !destination) return;

    let cancelled = false;

    async function run() {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setRouteError("Location permission required for navigation.");
        setLoadingRoute(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.BestForNavigation,
      });
      if (cancelled) return;
      const origin = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      setUserLocation(origin);

      try {
        const mod = require("wishwash-mapkit-directions");
        const getRouteWithSteps = mod?.getRouteWithSteps ?? mod?.default?.getRouteWithSteps;
        if (!getRouteWithSteps) {
          setRouteError("MapKit directions not available. Use a development build.");
          return;
        }
        const result: RouteResult = await getRouteWithSteps(origin, destination);
        if (cancelled) return;
        setRoute(result);
        setRouteError(null);
        fitRegion(result.coordinates, origin);
      } catch (e: any) {
        if (!cancelled) {
          setRouteError(e?.message ?? "Could not load route. Use a development build for in-app navigation.");
        }
      } finally {
        if (!cancelled) setLoadingRoute(false);
      }
    }

    run();
    return () => {
      cancelled = true;
    };
  }, [isIOS, isValidDest, destLat, destLng]);

  function fitRegion(
    coords: { latitude: number; longitude: number }[],
    user: { latitude: number; longitude: number }
  ) {
    if (coords.length === 0) return;
    const lats = coords.map((c) => c.latitude).concat([user.latitude]);
    const lngs = coords.map((c) => c.longitude).concat([user.longitude]);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    const pad = 0.005;
    setRegion({
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max(maxLat - minLat + pad, 0.002),
      longitudeDelta: Math.max(maxLng - minLng + pad, 0.002),
    });
  }

  // Watch user location and update current step + distance to next step
  useEffect(() => {
    if (!isIOS || !route || route.steps.length === 0) return;

    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        timeInterval: 3000,
        distanceInterval: 15,
      },
      (loc) => {
        const { latitude, longitude } = loc.coords;
        setUserLocation({ latitude, longitude });

        const steps = route.steps;
        let bestIndex = 0;
        let bestDist = Infinity;

        for (let i = 0; i < steps.length; i++) {
          const step = steps[i];
          const d = haversineMeters(
            latitude,
            longitude,
            step.endLatitude,
            step.endLongitude
          );
          if (d < bestDist) {
            bestDist = d;
            bestIndex = i;
          }
        }

        setCurrentStepIndex(bestIndex);
        const distToNext =
          bestIndex < steps.length - 1
            ? haversineMeters(
                latitude,
                longitude,
                steps[bestIndex].endLatitude,
                steps[bestIndex].endLongitude
              )
            : haversineMeters(
                latitude,
                longitude,
                destination!.latitude,
                destination!.longitude
              );
        setDistanceToNextStep(distToNext);
      }
    );

    return () => subscription.then((sub) => sub.remove());
  }, [isIOS, route?.coordinates?.length, destination?.latitude, destination?.longitude]);

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 1,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();
  }, []);

  const openInAppleMaps = () => {
    const url = `https://maps.apple.com/?daddr=${destLat},${destLng}&dirflg=d`;
    Linking.openURL(url).catch(() =>
      Alert.alert("Error", "Could not open Apple Maps.")
    );
    router.back();
  };

  const openInGoogleMaps = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${destLat},${destLng}`;
    Linking.openURL(url).catch(() =>
      Alert.alert("Error", "Could not open Google Maps.")
    );
    router.back();
  };

  if (!isValidDest) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient
          colors={customerTheme.backgroundGradient}
          style={StyleSheet.absoluteFill}
        />
        <AppHeader
          title="Navigate"
          showBack
          onBack={() => {
            hapticFeedback("light");
            router.back();
          }}
        />
        <View style={[styles.centered, { paddingTop: HEADER_CONTENT_OFFSET }]}>
          <Ionicons name="navigate-outline" size={48} color={SKY} />
          <Text style={styles.title}>Invalid destination</Text>
          <Text style={styles.subtitle}>Missing or invalid coordinates.</Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Non‑iOS: show external maps options only
  if (!isIOS) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient
          colors={customerTheme.backgroundGradient}
          style={StyleSheet.absoluteFill}
        />
        <AppHeader
          title="Navigate"
          subtitle={address}
          showBack
          onBack={() => {
            hapticFeedback("light");
            router.back();
          }}
        />
        <View style={[styles.centered, { paddingTop: HEADER_CONTENT_OFFSET }]}>
          <View style={styles.iconWrap}>
            <Ionicons name="navigate" size={56} color={SKY} />
          </View>
          <Text style={styles.title}>{address}</Text>
          <Text style={styles.subtitle}>
            Open in your preferred maps app for turn-by-turn directions.
          </Text>
          <View style={styles.buttons}>
            <TouchableOpacity
              style={styles.primaryButton}
              onPress={openInGoogleMaps}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={["#4285F4", "#34A853"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.primaryButtonGradient}
              >
                <Ionicons name="navigate" size={22} color="#FFFFFF" />
                <Text style={styles.primaryButtonText}>Open in Google Maps</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // iOS: in‑app turn‑by‑turn
  const currentStep = route?.steps?.[currentStepIndex];
  const distanceText =
    distanceToNextStep != null ? formatDistance(distanceToNextStep) : "—";

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient
        colors={customerTheme.backgroundGradient}
        style={StyleSheet.absoluteFill}
      />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        {region ? (
          <MapView
            style={StyleSheet.absoluteFill}
            region={region}
            mapType="mutedStandard"
            showsUserLocation={true}
            showsMyLocationButton={true}
            followsUserLocation={false}
            onRegionChangeComplete={setRegion}
          >
            {destination && (
              <Marker coordinate={destination} title={address}>
                <View style={styles.destMarker}>
                  <Ionicons name="business" size={28} color="#EF4444" />
                </View>
              </Marker>
            )}
            {route?.coordinates && route.coordinates.length > 0 && (
              <Polyline
                coordinates={route.coordinates}
                strokeColor={SKY}
                strokeWidth={5}
                lineCap="round"
                lineJoin="round"
              />
            )}
          </MapView>
        ) : (
          <View
            style={[
              StyleSheet.absoluteFill,
              styles.loadingMap,
            ]}
          >
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingMapText}>
              {loadingRoute ? "Loading route…" : "Getting location…"}
            </Text>
          </View>
        )}
      </View>

      <AppHeader
        title="Navigate to hub"
        subtitle={address}
        showBack
        onBack={() => {
          hapticFeedback("light");
          router.back();
        }}
      />

      {loadingRoute && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Fetching route…</Text>
        </View>
      )}

      {routeError && !loadingRoute && (
        <View style={[styles.loadingOverlay, styles.errorOverlay]}>
          <Text style={styles.errorText}>{routeError}</Text>
          <TouchableOpacity
            style={[styles.primaryButton, { marginBottom: 8 }]}
            onPress={openInAppleMaps}
            activeOpacity={0.9}
          >
            <LinearGradient
              colors={[SKY, "#0EA5E9"]}
              style={styles.primaryButtonGradient}
            >
              <Ionicons name="navigate" size={20} color="#FFFFFF" />
              <Text style={styles.primaryButtonText}>Open in Apple Maps</Text>
            </LinearGradient>
          </TouchableOpacity>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Turn-by-turn card */}
      {route && !loadingRoute && !routeError && (
        <Animated.View
          style={[
            styles.card,
            {
              opacity: slideAnim,
              transform: [
                {
                  translateY: slideAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [120, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <BlurView intensity={80} tint="dark" style={styles.cardBlur}>
            <View style={styles.cardContent}>
              <View style={styles.cardRow}>
                <View style={styles.stepIconWrap}>
                  <Ionicons name="navigate" size={24} color={SKY} />
                </View>
                <View style={styles.stepTextWrap}>
                  <Text style={styles.distanceLabel}>
                    {distanceText} to next step
                  </Text>
                  <Text style={styles.instruction} numberOfLines={2}>
                    {currentStep?.instruction || "Head to destination"}
                  </Text>
                </View>
              </View>
              <View style={styles.metaRow}>
                <Text style={styles.metaText}>
                  Step {Math.min(currentStepIndex + 1, route.steps.length)} of{" "}
                  {route.steps.length}
                </Text>
                <Text style={styles.metaText}>
                  {formatDistance(route.distance)} total · ~
                  {Math.round(route.expectedTravelTime / 60)} min
                </Text>
              </View>
            </View>
          </BlurView>
        </Animated.View>
      )}

      {/* Fallback: open in Apple Maps (small link) */}
      {route && !loadingRoute && !routeError && (
        <TouchableOpacity
          style={styles.externalLink}
          onPress={() => {
            hapticFeedback("light");
            Linking.openURL(
              `https://maps.apple.com/?daddr=${destLat},${destLng}&dirflg=d`
            ).catch(() => {});
          }}
        >
          <Text style={styles.externalLinkText}>Open in Apple Maps</Text>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgPrimary ?? "#0A1929",
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 24,
  },
  iconWrap: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: SKY + "20",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FFF",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "rgba(255,255,255,0.7)",
    textAlign: "center",
    marginBottom: 24,
  },
  buttons: {
    width: "100%",
    maxWidth: 320,
    gap: 12,
    marginBottom: 24,
  },
  primaryButton: {
    width: "100%",
    overflow: "hidden",
    borderRadius: 14,
  },
  primaryButtonGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    gap: 10,
  },
  primaryButtonText: {
    fontSize: 17,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  backBtn: {
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  backBtnText: {
    fontSize: 16,
    color: SKY,
    fontWeight: "600",
  },
  loadingMap: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(10,25,41,0.95)",
  },
  loadingMapText: {
    color: SKY,
    marginTop: 12,
    fontSize: 16,
    fontWeight: "600",
  },
  loadingOverlay: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 160,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  loadingText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "600",
  },
  errorOverlay: {
    bottom: 120,
  },
  errorText: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 15,
    textAlign: "center",
    marginBottom: 8,
  },
  destMarker: {
    alignItems: "center",
    justifyContent: "center",
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "rgba(255,255,255,0.95)",
  },
  card: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 48,
    borderRadius: 20,
    overflow: "hidden",
  },
  cardBlur: {
    borderRadius: 20,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.25)",
  },
  cardContent: {
    padding: 20,
  },
  cardRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 14,
  },
  stepIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: SKY + "25",
    alignItems: "center",
    justifyContent: "center",
  },
  stepTextWrap: {
    flex: 1,
    minWidth: 0,
  },
  distanceLabel: {
    fontSize: 13,
    fontWeight: "700",
    color: SKY,
    marginBottom: 4,
  },
  instruction: {
    fontSize: 17,
    fontWeight: "600",
    color: "#F9FAFB",
  },
  metaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.1)",
  },
  metaText: {
    fontSize: 12,
    color: "rgba(255,255,255,0.6)",
    fontWeight: "500",
  },
  externalLink: {
    position: "absolute",
    bottom: 16,
    alignSelf: "center",
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  externalLinkText: {
    fontSize: 13,
    color: SKY,
    fontWeight: "600",
  },
});
