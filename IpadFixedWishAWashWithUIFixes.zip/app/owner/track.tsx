import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Modal,
  Pressable,
  Image,
  Platform,
  Alert,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../src/hooks/useLiveLocation';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import { customerTheme } from '../../src/constants/customerTheme';
import { BOOKING_CARD } from '../../src/constants/bookingCardTheme';
import { DEFAULT_MAP_REGION } from '../../src/constants/mapConstants';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { getDashboardHeaderTopOffset } from '../../src/constants/layoutConstants';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import PulsingBorderLoader from '../../src/components/booking/PulsingBorderLoader';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const CARD_WIDTH = width - 24; // Bigger cards – same as BOOKING_CARD

const ACTIVE_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

type ActiveBooking = {
  id: string;
  status: string;
  service_type: string;
  service_name?: string | null;
  price: number | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  location_id?: string | null;
  scheduled_at?: string | null;
  valeter_name?: string | null;
  created_at?: string | null;
};

type ValeterLoc = { [valeterId: string]: { latitude: number; longitude: number } };
type HubLoc = { [locationId: string]: { latitude: number; longitude: number } };

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return '#60A5FA';
    case 'valeter_assigned':
    case 'confirmed':
      return '#8B5CF6';
    case 'pending_valeter_acceptance':
    case 'pending':
    case 'pending_payment':
      return '#F59E0B';
    default:
      return SKY;
  }
};

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'en_route':
      return 'En route';
    case 'arrived':
      return 'Arrived';
    case 'in_progress':
      return 'In progress';
    case 'valeter_assigned':
      return 'Assigned';
    case 'confirmed':
      return 'Confirmed';
    case 'pending_valeter_acceptance':
      return 'Connecting';
    case 'pending':
      return 'Pending';
    case 'pending_payment':
      return 'Pay now';
    case 'scheduled':
      return 'Scheduled';
    default:
      return status.replaceAll('_', ' ').replaceAll(/\b\w/g, (l) => l.toUpperCase());
  }
};

const getCTAText = (status: string): string => {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending':
      return 'View status';
    case 'pending_payment':
      return 'Pay now';
    case 'en_route':
      return 'Track';
    default:
      return 'View trip';
  }
};

function calcEta(
  valeterCoords: { latitude: number; longitude: number },
  userCoords: { latitude: number; longitude: number } | null | undefined
): number | null {
  if (!userCoords) return null;
  const R = 3959;
  const dLat = ((valeterCoords.latitude - userCoords.latitude) * Math.PI) / 180;
  const dLon = ((valeterCoords.longitude - userCoords.longitude) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((userCoords.latitude * Math.PI) / 180) *
      Math.cos((valeterCoords.latitude * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const dist = R * c;
  return Math.round((dist / 25) * 60);
}

async function fetchValeterPresence(valeterId: string) {
  const { data } = await supabase
    .from('valeter_presence')
    .select('last_lat, last_lng')
    .eq('user_id', valeterId)
    .maybeSingle();
  return data?.last_lat != null && data?.last_lng != null
    ? { latitude: data.last_lat, longitude: data.last_lng }
    : null;
}

async function fetchHubLocation(locationId: string) {
  const { data } = await supabase
    .from('car_wash_locations')
    .select('latitude, longitude')
    .eq('id', locationId)
    .maybeSingle();
  return data?.latitude != null && data?.longitude != null
    ? { latitude: data.latitude, longitude: data.longitude }
    : null;
}

async function processOneBooking(
  b: ActiveBooking,
  coords: { latitude: number; longitude: number } | null
): Promise<{ vl?: [string, { latitude: number; longitude: number }]; hl?: [string, { latitude: number; longitude: number }]; eta?: number }> {
  const out: { vl?: [string, { latitude: number; longitude: number }]; hl?: [string, { latitude: number; longitude: number }]; eta?: number } = {};
  if (b.valeter_id) {
    const vc = await fetchValeterPresence(b.valeter_id);
    if (vc) {
      out.vl = [b.valeter_id, vc];
      if (coords) {
        const e = calcEta(vc, coords);
        if (e != null) out.eta = e;
      }
    }
  }
  if (b.location_id) {
    const hc = await fetchHubLocation(b.location_id);
    if (hc) out.hl = [b.location_id, hc];
  }
  return out;
}

async function fetchValeterHubAndEta(
  bookings: ActiveBooking[],
  coords: { latitude: number; longitude: number } | null
): Promise<{ vlMap: ValeterLoc; hlMap: HubLoc; eta: Record<string, number> }> {
  const vlMap: ValeterLoc = {};
  const hlMap: HubLoc = {};
  const eta: Record<string, number> = {};
  for (const b of bookings) {
    const one = await processOneBooking(b, coords);
    if (one.vl) vlMap[one.vl[0]] = one.vl[1];
    if (one.hl) hlMap[one.hl[0]] = one.hl[1];
    if (one.eta != null) eta[b.id] = one.eta;
  }
  return { vlMap, hlMap, eta };
}

function computeMapRegionFromBookings(
  bookings: ActiveBooking[],
  coords: { latitude: number; longitude: number } | null,
  vlMap: ValeterLoc,
  hlMap: HubLoc
): Region | null {
  if (bookings.length === 0 || !coords) return null;
  const first = bookings[0];
  let other: { latitude: number; longitude: number } | null = null;
  if (first.valeter_id && vlMap[first.valeter_id]) other = vlMap[first.valeter_id];
  else if (first.location_id && hlMap[first.location_id]) other = hlMap[first.location_id];
  else if (first.location_lat != null && first.location_lng != null)
    other = { latitude: first.location_lat, longitude: first.location_lng };
  if (!other) {
    return {
      ...coords,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    };
  }
  const latSpan = Math.abs(other.latitude - coords.latitude) || 0.0005;
  const lngSpan = Math.abs(other.longitude - coords.longitude) || 0.0005;
  return {
    latitude: (coords.latitude + other.latitude) / 2,
    longitude: (coords.longitude + other.longitude) / 2,
    latitudeDelta: Math.max(0.008, latSpan * 2.8),
    longitudeDelta: Math.max(0.008, lngSpan * 2.8),
  };
}

const LOADING_MESSAGES = [
  'Valeters available nearby',
  'Same-day booking available',
  'Professional valeters ready to serve you',
  'Book now for a sparkling clean car',
  'Valeters in your area',
  'Quick response times',
  'Premium car care at your fingertips',
  'Your car deserves the best',
];

/** When there are no active bookings: calm, teach-what-happens-next copy (Option C) */
const EMPTY_STATE_MESSAGES = [
  "When you book, your washer will appear here in real time.",
  "Book a wash and track your valeter live on the map.",
  "Same-day washes available — book to see your trip here.",
];

type TrackCardsSectionProps = {
  loading: boolean;
  activeBookings: ActiveBooking[];
  loadingMessageIndex: number;
  emptyMessageIndex: number;
  refreshing: boolean;
  onRefresh: () => void;
  etaMap: Record<string, number>;
  cancellingId: string | null;
  onOpenInfo: (b: ActiveBooking) => void;
  onCardPress: (bookingId: string) => void;
  canCancel: (b: ActiveBooking) => boolean;
  onCancelOne: (bookingId: string) => void;
};

function TrackCardsSection({
  loading,
  activeBookings,
  loadingMessageIndex,
  emptyMessageIndex,
  refreshing,
  onRefresh,
  etaMap,
  cancellingId,
  onOpenInfo,
  onCardPress,
  canCancel,
  onCancelOne,
}: Readonly<TrackCardsSectionProps>) {
  if (loading) {
    return (
      <BlurView intensity={70} tint="dark" style={styles.emptyCard}>
        <View style={styles.emptyContent}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={styles.loadingText}>{LOADING_MESSAGES[loadingMessageIndex]}</Text>
        </View>
      </BlurView>
    );
  }
  if (activeBookings.length === 0) {
    return (
      <View style={[styles.emptyCardWrapper, { width: CARD_WIDTH }]}>
        <BlurView intensity={70} tint="dark" style={styles.emptyCard}>
          <View style={styles.emptyContent}>
            <Ionicons name="car-outline" size={32} color={SKY} />
            <View style={styles.emptyTextWrap}>
              <Text style={styles.emptyTitle}>You're all set</Text>
              <Text style={styles.emptySubtext}>{EMPTY_STATE_MESSAGES[emptyMessageIndex]}</Text>
            </View>
            <TouchableOpacity
              style={[styles.bookBtn, { marginLeft: 'auto' }]}
              onPress={async () => {
                await hapticFeedback('medium');
                router.push('/owner/booking');
              }}
              activeOpacity={0.85}
            >
              <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.bookBtnGrad}>
                <Text style={styles.bookBtnText}>Book a wash</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </BlurView>
        <PulsingBorderLoader color={SKY} borderRadius={BOOKING_CARD.BORDER_RADIUS} style={StyleSheet.absoluteFill} />
      </View>
    );
  }
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.horizontalScroll}
      snapToInterval={CARD_WIDTH + 16}
      decelerationRate="fast"
      snapToAlignment="start"
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={() => { onRefresh(); }} />
      }
    >
      {activeBookings.map((booking) => {
        const statusColor = getStatusColor(booking.status);
        const eta = etaMap[booking.id];
        const isDetailing = booking.service_type?.includes('detailing');
        return (
          <TouchableOpacity
            key={booking.id}
            activeOpacity={0.85}
            onPress={() => onCardPress(booking.id)}
            style={[styles.horizontalCard, { width: CARD_WIDTH }]}
          >
            <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={[statusColor + '15', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.cardTop}>
              <View style={[styles.serviceIconWrap, { backgroundColor: statusColor + '25' }]}>
                <Image
                  source={
                    isDetailing ? require('../../assets/detailing.png') : require('../../assets/cleaning.png')
                  }
                  style={styles.serviceIcon}
                  resizeMode="contain"
                />
              </View>
              <View style={styles.cardMain}>
                <Text style={styles.cardService} numberOfLines={1}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
                {booking.valeter_name && (
                  <Text style={styles.cardValeter} numberOfLines={1}>{booking.valeter_name}</Text>
                )}
                <View style={[styles.statusPill, { backgroundColor: statusColor + '30' }]}>
                  <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                  <Text style={[styles.statusPillText, { color: statusColor }]}>{getStatusLabel(booking.status)}</Text>
                </View>
              </View>
            </View>
            <View style={styles.cardBottom}>
              <Text style={styles.cardPriceValue}>£{Number(booking.price || 0).toFixed(2)}</Text>
              {eta != null && (
                <View style={styles.etaWrap}>
                  <Ionicons name="time-outline" size={12} color={SKY} />
                  <Text style={styles.etaText}>{eta} min</Text>
                </View>
              )}
              <TouchableOpacity
                onPress={(e) => {
                  e.stopPropagation();
                  hapticFeedback('light');
                  onOpenInfo(booking);
                }}
                hitSlop={12}
                style={styles.infoBtn}
              >
                <Ionicons name="information-circle-outline" size={20} color={SKY} />
              </TouchableOpacity>
              {canCancel(booking) && (
                <TouchableOpacity
                  onPress={(e) => {
                    e.stopPropagation();
                    hapticFeedback('light');
                    Alert.alert(
                      'Cancel this booking?',
                      'This trip will be cancelled.',
                      [
                        { text: 'Keep', style: 'cancel' },
                        { text: 'Cancel', style: 'destructive', onPress: () => { onCancelOne(booking.id); } },
                      ]
                    );
                  }}
                  hitSlop={8}
                  style={styles.cardCancelBtn}
                  disabled={cancellingId === booking.id}
                >
                  {cancellingId === booking.id ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                  )}
                </TouchableOpacity>
              )}
              <Text style={styles.ctaText}>{getCTAText(booking.status)}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

type TrackMapMarkersProps = Readonly<{
  userLocation: { latitude: number; longitude: number } | null;
  activeBookings: ActiveBooking[];
  valeterLocations: ValeterLoc;
  hubLocations: HubLoc;
  styles: Record<string, object>;
}>;

function TrackMapMarkers({ userLocation, activeBookings, valeterLocations, hubLocations, styles: s }: TrackMapMarkersProps) {
  return (
    <>
      {userLocation && (
        <Marker coordinate={userLocation}>
          <View style={s.markerWrap}>
            <Image source={require('../../assets/car.png')} style={s.markerImg} resizeMode="contain" />
          </View>
        </Marker>
      )}
      {activeBookings.map((b) => {
        const vl = b.valeter_id ? valeterLocations[b.valeter_id] : null;
        const hl = b.location_id ? hubLocations[b.location_id] : null;
        const coord =
          vl ||
          hl ||
          (b.location_lat != null && b.location_lng != null
            ? { latitude: b.location_lat, longitude: b.location_lng }
            : null);
        if (!coord) return null;
        return (
          <Marker key={b.id} coordinate={coord}>
            <View style={s.bookingMarkerWrap}>
              <Image
                source={
                  b.service_type?.includes('detailing')
                    ? require('../../assets/detailing.png')
                    : require('../../assets/cleaning.png')
                }
                style={s.bookingMarkerImg}
                resizeMode="contain"
              />
            </View>
          </Marker>
        );
      })}
    </>
  );
}

type TrackMapTopBarProps = Readonly<{
  topOffset: number;
  activeBookings: ActiveBooking[];
  canCancelBooking: (b: ActiveBooking) => boolean;
  cancellingAll: boolean;
  onRefresh: () => void;
  onCancelAll: () => void;
  styles: Record<string, object>;
}>;

function TrackMapTopBar({
  topOffset,
  activeBookings,
  canCancelBooking,
  cancellingAll,
  onRefresh,
  onCancelAll,
  styles: s,
}: TrackMapTopBarProps) {
  const showCancelAll = activeBookings.some(canCancelBooking);
  return (
    <View style={[s.mapTopBar, { top: topOffset }]}>
      <TouchableOpacity style={s.mapTopBarLeft} onPress={onRefresh} activeOpacity={0.8}>
        <BlurView intensity={60} tint="dark" style={s.mapTopBarPill}>
          <Ionicons name="calendar" size={20} color={SKY} />
          <Text style={s.mapTopBarCount}>{activeBookings.length}</Text>
          {activeBookings.length === 0 && <Text style={s.mapTopBarHint}>active</Text>}
        </BlurView>
      </TouchableOpacity>
      {showCancelAll && (
        <TouchableOpacity
          style={s.mapTopBarRight}
          onPress={onCancelAll}
          disabled={cancellingAll}
          activeOpacity={0.8}
        >
          <BlurView intensity={60} tint="dark" style={s.cancelAllPill}>
            {cancellingAll ? (
              <ActivityIndicator size="small" color="#EF4444" />
            ) : (
              <>
                <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                <Text style={s.cancelAllText}>Cancel all</Text>
              </>
            )}
          </BlurView>
        </TouchableOpacity>
      )}
    </View>
  );
}

type TrackInfoModalProps = Readonly<{
  visible: boolean;
  booking: ActiveBooking | null;
  onClose: () => void;
  onTrackPress: (bookingId: string) => void;
  onCancelPress: (bookingId: string) => void;
  formatDate: (d?: string | null) => string;
  formatCurrency: (n?: number | null) => string;
  canCancel: (b: ActiveBooking) => boolean;
  cancellingId: string | null;
  styles: Record<string, object>;
}>;

function TrackInfoModal({
  visible,
  booking,
  onClose,
  onTrackPress,
  onCancelPress,
  formatDate,
  formatCurrency,
  canCancel,
  cancellingId,
  styles: s,
}: TrackInfoModalProps) {
  if (!booking) return null;
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={s.modalOverlay} onPress={onClose}>
        <Pressable style={s.modalContent} onPress={(e) => e.stopPropagation()}>
          <View style={s.modalHeader}>
            <Text style={s.modalTitle}>Booking details</Text>
            <TouchableOpacity onPress={onClose} hitSlop={12}>
              <Ionicons name="close" size={24} color={customerTheme.primary} />
            </TouchableOpacity>
          </View>
          <Text style={s.modalService}>
            {getServiceDisplayName(booking.service_type, booking.service_name)}
          </Text>
          <View style={s.modalRows}>
            {booking.location_address && (
              <View style={s.modalRow}>
                <Ionicons name="location-outline" size={18} color={SKY} />
                <Text style={s.modalRowText}>{booking.location_address}</Text>
              </View>
            )}
            <View style={s.modalRow}>
              <Ionicons name="time-outline" size={18} color={SKY} />
              <Text style={s.modalRowText}>{formatDate(booking.scheduled_at || booking.created_at)}</Text>
            </View>
            <View style={s.modalRow}>
              <Ionicons name="wallet-outline" size={18} color={SKY} />
              <Text style={s.modalRowText}>{formatCurrency(booking.price)}</Text>
            </View>
            {booking.valeter_name && (
              <View style={s.modalRow}>
                <Ionicons name="person-outline" size={18} color={SKY} />
                <Text style={s.modalRowText}>{booking.valeter_name}</Text>
              </View>
            )}
          </View>
          <TouchableOpacity
            onPress={() => {
              onClose();
              onTrackPress(booking.id);
            }}
            style={s.modalCta}
            activeOpacity={0.9}
          >
            <LinearGradient colors={[SKY, '#0EA5E9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={s.modalCtaGrad}>
              <Ionicons name="navigate" size={18} color="#FFFFFF" />
              <Text style={s.modalCtaText}>{getCTAText(booking.status)}</Text>
            </LinearGradient>
          </TouchableOpacity>
          {canCancel(booking) && (
            <TouchableOpacity
              onPress={() => {
                Alert.alert('Cancel this booking?', 'This trip will be cancelled.', [
                  { text: 'Keep', style: 'cancel' },
                  { text: 'Cancel booking', style: 'destructive', onPress: () => onCancelPress(booking.id) },
                ]);
              }}
              style={s.modalCancelBtn}
              disabled={cancellingId === booking.id}
            >
              {cancellingId === booking.id ? (
                <ActivityIndicator size="small" color="#EF4444" />
              ) : (
                <>
                  <Ionicons name="close-circle-outline" size={18} color="#EF4444" />
                  <Text style={s.modalCancelText}>Cancel booking</Text>
                </>
              )}
            </TouchableOpacity>
          )}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function useTrackPageData() {
  const { user } = useAuth();
  const { coords: liveCoords } = useLiveLocation();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeBookings, setActiveBookings] = useState<ActiveBooking[]>([]);
  const [valeterLocations, setValeterLocations] = useState<ValeterLoc>({});
  const [hubLocations, setHubLocations] = useState<HubLoc>({});
  const [etaMap, setEtaMap] = useState<Record<string, number>>({});
  const [infoModalBooking, setInfoModalBooking] = useState<ActiveBooking | null>(null);
  const [mapRegion, setMapRegion] = useState<Region | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancellingAll, setCancellingAll] = useState(false);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
  const [emptyMessageIndex, setEmptyMessageIndex] = useState(0);
  const presenceChannels = useRef<Record<string, any>>({});

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return null;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
      setUserLocation(coords);
      return coords;
    } catch {
      return null;
    }
  };

  const loadActiveBookings = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const coords = await getCurrentLocation();
      const { data, error } = await supabase
        .from('bookings')
        .select(
          `id, status, service_type, service_name, price, location_address, location_lat, location_lng, valeter_id, location_id, scheduled_at, valeter_name, created_at`
        )
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const bookings = (data || []) as ActiveBooking[];
      setActiveBookings(bookings);

      const { vlMap, hlMap, eta } = await fetchValeterHubAndEta(bookings, coords);
      setValeterLocations((prev) => ({ ...prev, ...vlMap }));
      setHubLocations((prev) => ({ ...prev, ...hlMap }));
      setEtaMap((prev) => ({ ...prev, ...eta }));

      const region = computeMapRegionFromBookings(bookings, coords, vlMap, hlMap);
      if (region) setMapRegion(region);
      else if (coords) setMapRegion({ ...coords, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    } catch (e) {
      console.error('Error loading active bookings:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (!loading) return;
    const t = setInterval(() => {
      setLoadingMessageIndex((i) => (i + 1) % LOADING_MESSAGES.length);
    }, 2800);
    return () => clearInterval(t);
  }, [loading]);

  useEffect(() => {
    if (loading || activeBookings.length > 0) return;
    const t = setInterval(() => {
      setEmptyMessageIndex((i) => (i + 1) % EMPTY_STATE_MESSAGES.length);
    }, 3200);
    return () => clearInterval(t);
  }, [loading, activeBookings.length]);

  useEffect(() => {
    if (liveCoords && activeBookings.length === 0) {
      setMapRegion({
        latitude: liveCoords.latitude,
        longitude: liveCoords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
  }, [liveCoords, activeBookings.length]);

  useEffect(() => {
    loadActiveBookings();
    const channel = supabase
      .channel('customer-track-bookings')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${user?.id}` },
        () => loadActiveBookings()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
      Object.values(presenceChannels.current).forEach((ch) => ch && supabase.removeChannel(ch));
    };
  }, [user?.id]);

  useEffect(() => {
    for (const b of activeBookings) {
      if (b.valeter_id && !presenceChannels.current[b.valeter_id]) {
        const ch = supabase
          .channel(`valeter-presence-track-${b.valeter_id}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'valeter_presence',
              filter: `user_id=eq.${b.valeter_id}`,
            },
            (payload) => {
              const n = payload.new as any;
              if (n?.last_lat != null && n?.last_lng != null) {
                const vc = { latitude: n.last_lat, longitude: n.last_lng };
                setValeterLocations((prev) => ({ ...prev, [b.valeter_id!]: vc }));
                if (userLocation) {
                  const e = calcEta(vc, userLocation);
                  if (e != null) setEtaMap((prev) => ({ ...prev, [b.id]: e }));
                }
              }
            }
          )
          .subscribe();
        presenceChannels.current[b.valeter_id] = ch;
      }
    }
  }, [activeBookings.map((x) => x.valeter_id).join(',')]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await hapticFeedback('light');
    await loadActiveBookings();
  };

  const canCancelBooking = (b: ActiveBooking) =>
    b.status !== 'completed' && b.status !== 'cancelled';

  const cancelOneBooking = async (bookingId: string) => {
    if (!user?.id) return;
    try {
      setCancellingId(bookingId);
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled from trips',
        })
        .eq('id', bookingId)
        .eq('user_id', user.id);
      if (error) throw error;
      setInfoModalBooking(null);
      await loadActiveBookings();
      hapticFeedback('medium');
    } catch (e) {
      console.warn('cancelOneBooking', e);
      Alert.alert('Could not cancel', 'Please try again.');
    } finally {
      setCancellingId(null);
    }
  };

  const cancelAllBookings = () => {
    const toCancel = activeBookings.filter(canCancelBooking);
    if (toCancel.length > 0) {
      const plural = toCancel.length === 1 ? '' : 's';
      Alert.alert(
        'Cancel all trips?',
        `This will cancel ${toCancel.length} active booking${plural}.`,
        [
          { text: 'Keep', style: 'cancel' },
          { text: 'Cancel all', style: 'destructive', onPress: () => { runCancelAll(); } },
        ]
      );
    }
  };

  const runCancelAll = async () => {
    const toCancel = activeBookings.filter(canCancelBooking);
    if (!user?.id || toCancel.length === 0) return;
    try {
      setCancellingAll(true);
      for (const b of toCancel) {
        await supabase
          .from('bookings')
          .update({
            status: 'cancelled',
            cancelled_at: new Date().toISOString(),
            cancelled_by: 'customer',
            cancellation_reason: 'Cancelled all from trips',
          })
          .eq('id', b.id)
          .eq('user_id', user.id);
      }
      setInfoModalBooking(null);
      await loadActiveBookings();
      hapticFeedback('medium');
    } catch (e) {
      console.warn('cancelAllBookings', e);
      Alert.alert('Could not cancel all', 'Please try again.');
    } finally {
      setCancellingAll(false);
    }
  };

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';
  const formatDate = (d?: string | null) =>
    d
      ? new Date(d).toLocaleDateString('en-GB', {
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit',
        })
      : '—';

  return {
    loading,
    refreshing,
    activeBookings,
    userLocation,
    valeterLocations,
    hubLocations,
    etaMap,
    mapRegion,
    infoModalBooking,
    setInfoModalBooking,
    cancellingId,
    cancellingAll,
    loadingMessageIndex,
    emptyMessageIndex,
    loadActiveBookings,
    handleRefresh,
    handleCardPress: async (bookingId: string) => {
      await hapticFeedback('medium');
      router.push(`/owner/booking/tracking?bookingId=${bookingId}` as any);
    },
    canCancelBooking,
    cancelOneBooking,
    cancelAllBookings,
    formatCurrency,
    formatDate,
  };
}

export default function CustomerTrackPage() {
  const insets = useSafeAreaInsets();
  const data = useTrackPageData();

  const {
    loading,
    refreshing,
    activeBookings,
    userLocation,
    valeterLocations,
    hubLocations,
    etaMap,
    mapRegion,
    infoModalBooking,
    setInfoModalBooking,
    cancellingId,
    cancellingAll,
    loadingMessageIndex,
    emptyMessageIndex,
    handleRefresh,
    handleCardPress,
    canCancelBooking,
    cancelOneBooking,
    cancelAllBookings,
    formatCurrency,
    formatDate,
  } = data;

  const n = activeBookings.length;
  let headerSubtitle: string;
  if (n === 0) headerSubtitle = "You're all set";
  else if (n === 1) headerSubtitle = '1 trip';
  else headerSubtitle = `${n} trips`;

  const showMapLabel = !loading && activeBookings.length === 0;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <View style={styles.mapWrapper}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={mapRegion ?? DEFAULT_MAP_REGION}
          showsUserLocation={false}
          mapType={Platform.OS === 'ios' ? 'mutedStandard' : 'standard'}
        >
          <TrackMapMarkers
            userLocation={userLocation}
            activeBookings={activeBookings}
            valeterLocations={valeterLocations}
            hubLocations={hubLocations}
            styles={styles}
          />
        </MapView>
        {showMapLabel && (
          <View style={styles.mapSoftLabelWrap} pointerEvents="none">
            <BlurView intensity={40} tint="dark" style={styles.mapSoftLabelPill}>
              <Ionicons name="car-outline" size={16} color={SKY} style={{ opacity: 0.9 }} />
              <Text style={styles.mapSoftLabelText}>Washers available nearby</Text>
            </BlurView>
          </View>
        )}
      </View>

      <View style={styles.headerOverlay}>
        <AppHeader
          title="Active Bookings"
          subtitle={headerSubtitle}
          showBack
          onBack={() => { hapticFeedback('light'); router.back(); }}
          accountType="customer"
        />
      </View>

      <TrackMapTopBar
        topOffset={getDashboardHeaderTopOffset(insets) + 32}
        activeBookings={activeBookings}
        canCancelBooking={canCancelBooking}
        cancellingAll={cancellingAll}
        onRefresh={handleRefresh}
        onCancelAll={cancelAllBookings}
        styles={styles}
      />

      <View style={[styles.horizontalCardsWrapper, { bottom: TAB_BAR_TOTAL_HEIGHT + 56 }]}>
        <TrackCardsSection
          loading={loading}
          activeBookings={activeBookings}
          loadingMessageIndex={loadingMessageIndex}
          emptyMessageIndex={emptyMessageIndex}
          refreshing={refreshing}
          onRefresh={handleRefresh}
          etaMap={etaMap}
          cancellingId={cancellingId}
          onOpenInfo={setInfoModalBooking}
          onCardPress={handleCardPress}
          canCancel={canCancelBooking}
          onCancelOne={cancelOneBooking}
        />
      </View>

      <TrackInfoModal
        visible={!!infoModalBooking}
        booking={infoModalBooking}
        onClose={() => setInfoModalBooking(null)}
        onTrackPress={handleCardPress}
        onCancelPress={cancelOneBooking}
        formatDate={formatDate}
        formatCurrency={formatCurrency}
        canCancel={canCancelBooking}
        cancellingId={cancellingId}
        styles={styles}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  mapWrapper: {
    ...StyleSheet.absoluteFillObject,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  loadingText: {
    color: SKY,
    fontSize: 17,
    marginTop: 14,
  },
  markerWrap: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerImg: { width: 28, height: 28 },
  mapTopBar: {
    position: 'absolute',
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    zIndex: 11,
  },
  mapTopBarLeft: {},
  mapTopBarRight: {},
  mapTopBarPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  mapTopBarCount: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
  },
  mapTopBarHint: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  mapSoftLabelWrap: {
    position: 'absolute',
    bottom: 24,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapSoftLabelPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapSoftLabelText: {
    color: 'rgba(248,250,252,0.9)',
    fontSize: 13,
    fontWeight: '700',
  },
  cancelAllPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  cancelAllText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '700',
  },
  horizontalCardsWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: 12,
  },
  horizontalScroll: {
    flexDirection: 'row',
    gap: 12,
    paddingRight: 20,
  },
  emptyCardWrapper: {
    position: 'relative',
  },
  emptyCard: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    padding: 24,
    backgroundColor: 'rgba(255,255,255,0.06)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  bookingMarkerWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(30,58,138,0.9)',
    borderWidth: 2,
    borderColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookingMarkerImg: { width: 24, height: 24 },
  emptyContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  emptyTextWrap: { flex: 1, minWidth: 0 },
  emptyTitle: { color: '#F9FAFB', fontSize: 19, fontWeight: '800' },
  emptySubtext: { color: SKY, fontSize: 15, marginTop: 6, fontWeight: '600' },
  bookBtn: { borderRadius: 18, overflow: 'hidden' },
  bookBtnGrad: {
    paddingVertical: 12,
    paddingHorizontal: 22,
  },
  bookBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  horizontalCard: {
    padding: 24,
    minHeight: 140,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(255,255,255,0.06)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 14,
  },
  serviceIconWrap: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceIcon: { width: 34, height: 34 },
  cardMain: { flex: 1, minWidth: 0 },
  cardService: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 4,
  },
  cardValeter: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 6,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  statusPillText: { fontSize: 14, fontWeight: '700' },
  cardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingTop: 14,
    marginTop: 4,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  cardPriceValue: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', flex: 1 },
  etaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  etaText: { color: SKY, fontSize: 15, fontWeight: '700' },
  infoBtn: { padding: 4 },
  cardCancelBtn: { padding: 4 },
  ctaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ctaText: { color: SKY, fontSize: 15, fontWeight: '800' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 20,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitle: { color: customerTheme.primary, fontSize: 18, fontWeight: '800' },
  modalService: { color: customerTheme.primary, fontSize: 15, fontWeight: '700', marginBottom: 14 },
  modalRows: { gap: 10, marginBottom: 18 },
  modalRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  modalRowText: { color: colors.headerSubtext, fontSize: 13, flex: 1, opacity: 0.95 },
  modalCta: { borderRadius: 12, overflow: 'hidden' },
  modalCtaGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  modalCtaText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  modalCancelBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  modalCancelText: { color: '#EF4444', fontSize: 15, fontWeight: '700' },
});
