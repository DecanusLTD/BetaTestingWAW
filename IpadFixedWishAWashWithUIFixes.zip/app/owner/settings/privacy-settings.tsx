import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  Switch,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { useThemeOptional } from '../../../src/contexts/ThemeContext';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { BORDER_RADIUS, CARD_SHADOW } from '../../../src/constants/designTokens';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function PrivacySettings() {
  const insets = useSafeAreaInsets();
  useAuth();
  const theme = useThemeOptional();
  const [locationSharing, setLocationSharing] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [dataAnalytics, setDataAnalytics] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  const [isCabDriver, setIsCabDriver] = useState<boolean>(false); // UI-only state

  const settings = [
    ...(theme
      ? [
          {
            id: 'darkMode' as const,
            title: 'Dark mode',
            subtitle: theme.isDark ? 'On – use light mode to switch' : 'Off – use light mode',
            value: theme.isDark,
            onValueChange: (value: boolean) => {
              hapticFeedback('light');
              theme.setColorScheme(value ? 'dark' : 'light');
            },
            icon: 'moon' as const,
          },
        ]
      : []),
    {
      id: 'location',
      title: 'Location Sharing',
      subtitle: 'Allow app to access your location',
      value: locationSharing,
      onValueChange: setLocationSharing,
      icon: 'location',
    },
    {
      id: 'push',
      title: 'Push Notifications',
      subtitle: 'Receive notifications on your device',
      value: pushNotifications,
      onValueChange: setPushNotifications,
      icon: 'notifications',
    },
    {
      id: 'email',
      title: 'Email Notifications',
      subtitle: 'Receive updates via email',
      value: emailNotifications,
      onValueChange: setEmailNotifications,
      icon: 'mail',
    },
    {
      id: 'sms',
      title: 'SMS Notifications',
      subtitle: 'Receive text message updates',
      value: smsNotifications,
      onValueChange: setSmsNotifications,
      icon: 'chatbubble',
    },
    {
      id: 'analytics',
      title: 'Data Analytics',
      subtitle: 'Help improve our service',
      value: dataAnalytics,
      onValueChange: setDataAnalytics,
      icon: 'analytics',
    },
    {
      id: 'marketing',
      title: 'Marketing Emails',
      subtitle: 'Receive promotional content',
      value: marketingEmails,
      onValueChange: setMarketingEmails,
      icon: 'megaphone',
    },
    {
      id: 'cabDriver',
      title: 'I\'m a Cab Driver',
      subtitle: 'Enable for exclusive car wash discounts',
      value: isCabDriver,
      onValueChange: (value: boolean) => {
        setIsCabDriver(value);
        // UI-only toggle, no backend save
      },
      icon: 'car-sport',
    },
  ];

  const activeTheme = theme?.theme ?? customerTheme;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: activeTheme.backgroundColor }]} edges={[]}>
      <LinearGradient colors={activeTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Privacy Settings"
        accountType="customer"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, getScrollContentPadding(insets, true)]}
        showsVerticalScrollIndicator={false}
      >
        {settings.map((setting) => (
          <View key={setting.id} style={styles.settingCard}>
            <View style={styles.settingIconWrapper}>
              <Ionicons name={setting.icon as any} size={22} color={SKY} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{setting.title}</Text>
              <Text style={styles.settingSubtitle}>{setting.subtitle}</Text>
            </View>
            <Switch
              value={setting.value}
              onValueChange={setting.onValueChange}
              trackColor={{ false: '#374151', true: SKY }}
              thumbColor={setting.value ? '#FFFFFF' : '#9CA3AF'}
            />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceOverlay,
    borderRadius: BORDER_RADIUS.md,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...CARD_SHADOW,
  },
  settingIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: BORDER_RADIUS.sm,
    backgroundColor: colors.headerGlassBg,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    color: colors.textOnDarkPrimary,
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    letterSpacing: 0.15,
    marginBottom: 4,
  },
  settingSubtitle: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
});

