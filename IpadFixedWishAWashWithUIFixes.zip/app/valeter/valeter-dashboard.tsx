import PowerfulDriverDashboard from '../../src/components/dashboard/PowerfulDriverDashboard';

export default function ValeterDashboardScreen() {
  return <PowerfulDriverDashboard />;
}
