import { Stack } from 'expo-router';
import { AccountThemeProvider } from '../../src/components/shared/AccountThemeProvider';

export default function ValeterLayout() {
  return (
    <AccountThemeProvider accountType="valeter">
      <Stack screenOptions={{ headerShown: false }} />
    </AccountThemeProvider>
  );
}
