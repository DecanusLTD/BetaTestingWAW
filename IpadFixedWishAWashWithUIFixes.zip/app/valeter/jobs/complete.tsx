import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Image,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const theme = getAccountTheme('valeter');
const SKY = theme.primary;

export default function ValeterJobComplete() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ bookingId: string; celebrated?: string }>();
  const bookingId = params.bookingId;
  const alreadyCelebrated = params.celebrated === '1';

  const [booking, setBooking] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [customerName, setCustomerName] = useState<string>('Customer');
  const [customerPhoto, setCustomerPhoto] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(!alreadyCelebrated);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
    if (bookingId) loadBooking();
    else setLoading(false);
  }, [bookingId]);

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .eq('valeter_id', user?.id)
        .single();

      if (error) throw error;
      setBooking(data);

      if (data?.user_id) {
        try {
          const { data: prof } = await supabase
            .from('profiles')
            .select('full_name, profile_picture')
            .eq('id', data.user_id)
            .maybeSingle();
          if (prof?.full_name) setCustomerName(prof.full_name);
          if (prof?.profile_picture) setCustomerPhoto(prof.profile_picture);
        } catch {}
      }
    } catch (e) {
      console.warn('ValeterJobComplete loadBooking:', e);
      setBooking(null);
    } finally {
      setLoading(false);
    }
  };

  const handleRatingSelect = (value: number) => {
    hapticFeedback('light');
    setRating(value);
  };

  const handleSubmit = async () => {
    await hapticFeedback('medium');
    if (bookingId && rating > 0) {
      try {
        await supabase
          .from('bookings')
          .update({ valeter_rating: rating } as any)
          .eq('id', bookingId)
          .eq('valeter_id', user?.id);
      } catch (e) {
        console.warn('Save valeter rating:', e);
      }
    }
    router.replace('/valeter/valeter-dashboard');
  };

  const handleSkip = () => {
    hapticFeedback('light');
    router.replace('/valeter/valeter-dashboard');
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Job Complete" showBack onBack={() => router.replace('/valeter/valeter-dashboard')} />
        <View style={styles.loadingWrap}>
          <Text style={styles.loadingText}>Booking not found</Text>
          <TouchableOpacity onPress={() => router.replace('/valeter/valeter-dashboard')} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Back to Dashboard</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const price = Number(booking?.price ?? 0);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Job Complete"
        subtitle="Rate your experience"
        showBack
        onBack={() => { hapticFeedback('light'); router.replace('/valeter/valeter-dashboard'); }}
        accountType="valeter"
      />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, opacity: showSuccessOverlay ? 0 : 1 },
          ]}
          pointerEvents={showSuccessOverlay ? 'none' : 'auto'}
        >
          {/* Customer / Job summary card */}
          <GlassCard style={styles.profileCard} accountType="valeter">
            <View style={styles.profileCardRow}>
              <View style={styles.profileAvatarWrap}>
                {customerPhoto ? (
                  <Image source={{ uri: customerPhoto }} style={styles.profileAvatar} />
                ) : (
                  <View style={styles.profileAvatarPlaceholder}>
                    <Ionicons name="person" size={32} color={SKY} />
                  </View>
                )}
              </View>
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>{customerName}</Text>
                <View style={styles.serviceTheyDid}>
                  <Text style={styles.serviceTheyDidLabel}>Service completed</Text>
                  <Text style={styles.serviceTheyDidValue}>
                    {getServiceDisplayName(booking.service_type, booking.service_name)}
                  </Text>
                </View>
                <View style={styles.earningsRow}>
                  <Ionicons name="wallet" size={18} color={SKY} />
                  <Text style={styles.earningsText}>£{price.toFixed(2)} earned</Text>
                </View>
              </View>
            </View>
          </GlassCard>

          {/* Rating Section - How was this job? */}
          <GlassCard style={styles.ratingCard} accountType="valeter">
            <View style={styles.ratingHeader}>
              <Ionicons name="star" size={24} color="#FBBF24" />
              <Text style={styles.ratingTitle}>How was this job?</Text>
            </View>
            <View style={styles.starsContainer}>
              {[1, 2, 3, 4, 5].map((value) => (
                <TouchableOpacity
                  key={value}
                  onPress={() => handleRatingSelect(value)}
                  style={styles.starButton}
                >
                  <Ionicons
                    name={value <= rating ? 'star' : 'star-outline'}
                    size={40}
                    color={value <= rating ? '#FBBF24' : '#6B7280'}
                  />
                </TouchableOpacity>
              ))}
            </View>
            {rating > 0 && (
              <Text style={styles.ratingLabel}>
                {rating === 5 ? 'Excellent!' : rating === 4 ? 'Great!' : rating === 3 ? 'Good!' : rating === 2 ? 'Fair' : 'Poor'}
              </Text>
            )}
          </GlassCard>

          <View style={styles.actionsContainer}>
            <TouchableOpacity onPress={handleSubmit} style={styles.submitButton} activeOpacity={0.8}>
              <LinearGradient colors={[SKY, '#059669']} style={styles.submitGradient}>
                <Text style={styles.submitText}>
                  {rating > 0 ? 'Submit & finish' : 'Done'}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleSkip} style={styles.skipButton}>
              <Text style={styles.skipText}>Skip for now</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Animated.View>

      <SuccessOverlay
        visible={showSuccessOverlay}
        type="completed"
        message="Job completed!"
        onComplete={() => setShowSuccessOverlay(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  content: { flex: 1 },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    alignItems: 'center',
  },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
  },
  backBtn: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 14,
    backgroundColor: 'rgba(16,185,129,0.25)',
  },
  backBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  profileCard: {
    padding: 20,
    marginBottom: 16,
    width: '100%',
  },
  profileCardRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
  },
  profileAvatarWrap: { width: 64, height: 64 },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  profileAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(16,185,129,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: { flex: 1, minWidth: 0 },
  profileName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  serviceTheyDid: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(16,185,129,0.2)',
  },
  serviceTheyDidLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 2,
  },
  serviceTheyDidValue: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  earningsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 10,
  },
  earningsText: {
    color: SKY,
    fontSize: 17,
    fontWeight: '800',
  },
  ratingCard: {
    padding: 24,
    marginBottom: 24,
    width: '100%',
  },
  ratingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 20,
  },
  ratingTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 16,
  },
  starButton: { padding: 4 },
  ratingLabel: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  actionsContainer: {
    width: '100%',
    alignItems: 'center',
    gap: 12,
  },
  submitButton: {
    width: '100%',
    borderRadius: 14,
    overflow: 'hidden',
  },
  submitGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },
  skipButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  skipText: {
    color: '#94A3B8',
    fontSize: 15,
    fontWeight: '600',
  },
});
