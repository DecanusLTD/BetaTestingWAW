export default {
  owner: "reeceyrackz",
  name: "Wish a Wash",
  slug: "wish-a-wash",
  scheme: "waw",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  userInterfaceStyle: "automatic",
  splash: {
    image: "./assets/icon.png",
    resizeMode: "contain",
    backgroundColor: "#0A1929" // Dark blue background matching app theme (colors.BG)
  },
  assetBundlePatterns: [
    "**/*"
  ],
  experiments: { 
    typedRoutes: true,
    tsconfigPaths: true
  },
  ios: {
    supportsTablet: true,
    bundleIdentifier: "com.wishawashapp",
    buildNumber: "20",
    config: {
      usesNonExemptEncryption: false,
    },
    infoPlist: {
      NSLocationWhenInUseUsageDescription: "We use your location to find nearby valeters and show your service location.",
      NSLocationAlwaysAndWhenInUseUsageDescription: "We use your location to provide real-time tracking and service updates.",
      NSCameraUsageDescription: "We use your camera to take photos of your vehicle for service documentation.",
      NSMicrophoneUsageDescription: "We use your microphone for voice booking and communication features.",
      NSPhotoLibraryUsageDescription: "We use your photo library to select vehicle photos for service documentation.",
      UIBackgroundModes: ["location", "fetch", "remote-notification"],
      CFBundleDisplayName: "Wish a Wash"
    }
  },
  android: {
    package: "com.wishawashapp",
    versionCode: 1,
    permissions: [
      "ACCESS_FINE_LOCATION",
      "ACCESS_COARSE_LOCATION",
      "CAMERA",
      "RECORD_AUDIO",
      "READ_EXTERNAL_STORAGE",
      "WRITE_EXTERNAL_STORAGE",
      "INTERNET",
      "ACCESS_NETWORK_STATE",
      "VIBRATE",
      "WAKE_LOCK"
    ],
    adaptiveIcon: {
      foregroundImage: "./assets/icon.png",
      backgroundColor: "#87CEEB" // Sky blue base (gradient: sky blue #87CEEB → navy #1E3A8A → green #10B981)
    }
  },
  web: {
    favicon: "./assets/favicon.png",
    bundler: "metro"
  },
  plugins: [
    "expo-router",
    "expo-location",
    "expo-notifications",
    "expo-image-picker",
    "expo-camera",
    "expo-media-library",
    "expo-file-system",
    "expo-apple-authentication"
  ],
  extra: {
    eas: {
      projectId: "7f69047d-c084-4c60-a239-e53eb850a12f"
    }
  }
};
