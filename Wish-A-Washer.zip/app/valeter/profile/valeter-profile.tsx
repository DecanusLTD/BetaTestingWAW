import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
  Modal,
  Dimensions,
  ActivityIndicator,
  Animated,
  StatusBar,
  TextInput,
  Switch,
  Pressable,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../../src/services/Valeterstatsservice';
import { ValeterTierService, ValeterTier } from '../../../src/services/ValeterTierService';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
  is_self_sufficient?: boolean;
}

type BookingRow = {
  id: string;
  valeter_id: string | null;
  status: string; // booking_status enum
  price: number | string | null;
  scheduled_at: string;
  completed_at: string | null;
  updated_at: string;
};

// -------- New: service settings defs --------
type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum';
const TIER_DEFS: Array<{ key: TierKey; name: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'medal-outline' },
  { key: 'silver', name: 'Silver Wash', icon: 'medal-outline' },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy-outline' },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond-outline' },
];

type DetailingKey = 'mini' | 'interior' | 'exterior' | 'full' | 'seats' | 'engine' | 'ceramic';

type DetailingItem = {
  key: DetailingKey;
  name: string;
  enabled: boolean;
  price: number | null;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'mini', name: 'Mini Detail', icon: 'sparkles-outline' },
  { key: 'interior', name: 'Interior Detail', icon: 'car-outline' },
  { key: 'exterior', name: 'Exterior Detail', icon: 'water-outline' },
  { key: 'full', name: 'Full Detail', icon: 'diamond-outline' },
  { key: 'seats', name: 'Seat Shampoo', icon: 'shirt-outline' },
  { key: 'engine', name: 'Engine Bay Clean', icon: 'cog-outline' },
  { key: 'ceramic', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
];

const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
  const t = (raw || '').trim();
  if (!t) return null;
  const v = Number(t);
  if (!Number.isFinite(v) || v < 0) return null;
  return kind === 'minutes' ? Math.round(v) : v;
};

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null }));

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<DetailingKey, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, d));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = it?.key as DetailingKey;
      if (!key || !map.has(key)) continue;
      map.set(key, {
        key,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price:
          it?.price === null || it?.price === undefined || it?.price === ''
            ? null
            : Number.isFinite(Number(it?.price))
              ? Number(it?.price)
              : null,
      });
    }
  }
  return Array.from(map.values());
};

type TierPricing = Record<TierKey, { price: number | null; minutes: number | null }>;
const defaultTierPricing = (): TierPricing => ({
  bronze: { price: null, minutes: null },
  silver: { price: null, minutes: null },
  gold: { price: null, minutes: null },
  platinum: { price: null, minutes: null },
});

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  (Object.keys(base) as TierKey[]).forEach((k) => {
    const row = obj?.[k] || {};
    base[k] = {
      price: row?.price === null || row?.price === undefined ? null : Number.isFinite(Number(row.price)) ? Number(row.price) : null,
      minutes:
        row?.minutes === null || row?.minutes === undefined ? null : Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
    };
  });
  return base;
};
// -------------------------------------------

export default function ValeterProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingPicture, setUploadingPicture] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);

  // NEW: services modal
  const [showServicesModal, setShowServicesModal] = useState(false);
  const [servicesLoading, setServicesLoading] = useState(false);
  const [servicesSaving, setServicesSaving] = useState(false);
  const [ecoWashing, setEcoWashing] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [tierPricing, setTierPricing] = useState<TierPricing>(defaultTierPricing());

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0,
  });

  const [currentTier, setCurrentTier] = useState<ValeterTier | null>(null);

  const [organizationName, setOrganizationName] = useState<string | null>(null);
  const [isIndependent, setIsIndependent] = useState<boolean>(true);

  const [todayStats, setTodayStats] = useState({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const CountUpNumber = ({
    value,
    prefix = '',
    suffix = '',
    decimals = 0,
    duration = 650,
    style,
  }: {
    value: number;
    prefix?: string;
    suffix?: string;
    decimals?: number;
    duration?: number;
    style?: any;
  }) => {
    const anim = useRef(new Animated.Value(0)).current;
    const [display, setDisplay] = useState(0);

    useEffect(() => {
      anim.stopAnimation();
      anim.setValue(0);
      const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
      Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
        anim.removeListener(listenerId);
        setDisplay(value);
      });
      return () => anim.removeListener(listenerId);
    }, [value]);

    const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
    return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
  };

  const formatMinutesToHm = (mins: number) => {
    const safe = Math.max(0, Math.round(mins));
    const h = Math.floor(safe / 60);
    const m = safe % 60;
    return `${h}h ${m}m`;
  };

  const getDayRangeISO = () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date(start);
    end.setDate(end.getDate() + 1);

    return { startISO: start.toISOString(), endISO: end.toISOString() };
  };

  const computeTodayOverviewFromSchema = async (userId: string) => {
    const { startISO, endISO } = getDayRangeISO();

    const { data, error } = await supabase
      .from('bookings')
      .select('id,valeter_id,status,price,scheduled_at,completed_at,updated_at')
      .eq('valeter_id', userId)
      .gte('scheduled_at', startISO)
      .lt('scheduled_at', endISO);

    if (error) throw error;

    const rows = (data || []) as BookingRow[];
    const completed = rows.filter((b) => b.status === 'completed');

    const jobsCompleted = completed.length;

    const earnings = completed.reduce((sum, b) => {
      const n = Number(b.price ?? 0);
      return sum + (Number.isFinite(n) ? n : 0);
    }, 0);

    let minStart: number | null = null;
    let maxEnd: number | null = null;

    for (const b of rows) {
      const start = b.scheduled_at ? new Date(b.scheduled_at).getTime() : null;
      const end = (b.completed_at || b.updated_at) ? new Date(b.completed_at || b.updated_at).getTime() : null;

      if (start && (minStart === null || start < minStart)) minStart = start;
      if (end && (maxEnd === null || end > maxEnd)) maxEnd = end;
    }

    let hoursOnline = '0h 0m';
    if (minStart && maxEnd && maxEnd > minStart) {
      const diffMins = (maxEnd - minStart) / 60000;
      hoursOnline = formatMinutesToHm(Math.min(diffMins, 24 * 60));
    }

    return {
      hoursOnline,
      jobsCompleted,
      earnings: Math.round(earnings),
    };
  };

  useEffect(() => {
    const fetchStats = async () => {
      if (!user?.id) return;

      try {
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
        setCurrentTier(ValeterTierService.calculateTier(stats));

        const today = await computeTodayOverviewFromSchema(user.id);
        setTodayStats(today);
      } catch (error) {
        console.error('Error fetching valeter stats:', error);
      }
    };

    fetchStats();
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
      loadBusinessInfo();
      loadValeterServiceSettings(); // NEW
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;

    const usersSubscription = supabase
      .channel('user-organization-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        () => {
          loadBusinessInfo();
        }
      )
      .subscribe();

    return () => {
      usersSubscription.unsubscribe();
    };
  }, [user?.id]);

  const loadBusinessInfo = async () => {
    if (!user?.id) return;
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('organization_id, is_individual_valeter')
        .eq('id', user.id)
        .maybeSingle();

      if (userData) {
        const hasOrg = !!userData.organization_id;
        setIsIndependent(!hasOrg || userData.is_individual_valeter === true);

        if (hasOrg && userData.organization_id) {
          const { data: orgData } = await supabase
            .from('organizations')
            .select('name')
            .eq('id', userData.organization_id)
            .maybeSingle();

          setOrganizationName(orgData?.name ?? null);
        } else {
          setOrganizationName(null);
        }
      } else {
        setIsIndependent(true);
        setOrganizationName(null);
      }
    } catch (error) {
      console.error('Error loading business info:', error);
    }
  };

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: (user as any)?.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  // NEW: load / save service settings
  const loadValeterServiceSettings = async () => {
    if (!user?.id) return;
    try {
      setServicesLoading(true);

      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('*')
        .eq('valeter_id', user.id)
        .maybeSingle();

      // If table doesn't exist yet, fail silently (we show SQL in chat)
      if (error) {
        console.warn('[ValeterProfile] valeter_service_settings load error:', error.message);
        return;
      }

      if (data) {
        setEcoWashing(data.eco_washing === true);
        setDetailingOffered(data.detailing_offered === true);
        setDetailingItems(coerceDetailingMenu(data.detailing_menu));
        setTierPricing(coerceTierPricing(data.tier_pricing));
      } else {
        // defaults
        setEcoWashing(false);
        setDetailingOffered(false);
        setDetailingItems(buildDefaultDetailingItems());
        setTierPricing(defaultTierPricing());
      }
    } catch (e) {
      console.warn('[ValeterProfile] loadValeterServiceSettings error:', e);
    } finally {
      setServicesLoading(false);
    }
  };

  const saveValeterServiceSettings = async () => {
    if (!user?.id) return;
    try {
      setServicesSaving(true);
      await hapticFeedback('medium');

      const payload = {
        valeter_id: user.id,
        eco_washing: ecoWashing,
        detailing_offered: detailingOffered,
        detailing_menu: { items: detailingItems },
        tier_pricing: tierPricing,
      };

      const { error } = await supabase.from('valeter_service_settings').upsert(payload, { onConflict: 'valeter_id' });
      if (error) throw error;

      Alert.alert('Saved', 'Your services & pricing have been updated.');
      setShowServicesModal(false);
    } catch (e: any) {
      console.error('[ValeterProfile] saveValeterServiceSettings error:', e);
      Alert.alert('Error', e?.message || 'Failed to save services');
    } finally {
      setServicesSaving(false);
    }
  };

  const BUCKET = 'valeter_documents';

  async function uploadUriToSupabase(uri: string, path: string, contentType = 'image/jpeg') {
    const file = {
      uri,
      name: path.split('/').pop() || 'upload.jpg',
      type: contentType,
    } as any;

    const { data, error } = await supabase.storage.from(BUCKET).upload(path, file, {
      contentType,
      upsert: false,
    });

    if (error) throw error;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert('Logout', 'Are you sure you want to logout?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
              router.replace('/');
            } catch (error) {
              console.error('Logout error:', error);
              Alert.alert('Logout Error', 'Failed to logout. Please try again.');
            }
          },
        },
      ]);
    } catch {}
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert('Delete Account', 'This action cannot be undone. Are you sure?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => Alert.alert('Account Deleted', 'Your account has been deleted.'),
        },
      ]);
    } catch {}
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');
      setShowPhotoModal(true);
    } catch {}
  };

  const takePhoto = async () => {
    try {
      setUploadingPicture(true);

      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaType.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const pickImage = async () => {
    try {
      setUploadingPicture(true);

      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaType.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const uploadProfilePhoto = async (uri: string) => {
    try {
      const ext = uri.split('.').pop() || 'jpg';
      const fileName = `profile_${user!.id}_${Date.now()}.${ext}`;
      const storagePath = `profiles/${user!.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, `image/${ext}`);

      const { error } = await supabase
        .from('valeter_profiles')
        .update({ profile_photo_url: publicUrl })
        .eq('user_id', user!.id);

      if (error) throw error;

      setProfilePicture(publicUrl);
      setProfile((prev) => (prev ? { ...prev, profile_photo_url: publicUrl } : null));

      await hapticFeedback('medium');
      Alert.alert('Success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('Error uploading profile photo:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Valeter Profile"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="valeter"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Ionicons name="person" size={40} color={SKY} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            )}

            <TouchableOpacity
              style={[styles.uploadButton, isLoading && styles.uploadButtonDisabled]}
              onPress={handleUploadProfilePicture}
              disabled={isLoading}
            >
              <Ionicons name="camera" size={16} color="#0A1929" />
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{profile.full_name || 'Valeter Name'}</Text>
              {profile.verification_badge && (
                <View style={styles.verificationBadgeSmall}>
                  <Ionicons name="checkmark-circle" size={14} color="#FFFFFF" />
                </View>
              )}
            </View>

            <View style={styles.emailRow}>
              <Text style={styles.userEmail}>{user?.email || 'valeter@example.com'}</Text>
              {currentTier && <Text style={styles.tierBadgeIcon}>{currentTier.icon}</Text>}
            </View>

            {profile.experience && (
              <Text style={styles.userExperience}>{profile.experience} experience</Text>
            )}

            {profile.is_self_sufficient !== undefined && (
              <View style={styles.selfSufficiencyBadge}>
                <Ionicons
                  name={profile.is_self_sufficient ? 'battery-charging' : 'water'}
                  size={14}
                  color={profile.is_self_sufficient ? '#10B981' : SKY}
                />
                <Text
                  style={[
                    styles.selfSufficiencyText,
                    { color: profile.is_self_sufficient ? '#10B981' : SKY },
                  ]}
                >
                  {profile.is_self_sufficient ? 'Self-Sufficient' : 'Needs Resources'}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Tier Info Section */}
        {currentTier && (
          <View style={styles.section}>
            <View style={styles.tierInfoCard}>
              <LinearGradient
                colors={[currentTier.color + '20', currentTier.color + '10']}
                style={styles.tierInfoCardGradient}
              >
                <View style={styles.tierInfoRow}>
                  <Text style={styles.tierInfoIcon}>{currentTier.icon}</Text>
                  <View style={styles.tierInfoTextContainer}>
                    <Text style={styles.tierInfoTitle}>{currentTier.name} Valeter</Text>
                    <Text style={styles.tierInfoSubtitle}>
                      {valeterStats.totalJobs} jobs • {valeterStats.experienceMonths} months • ⭐{' '}
                      {valeterStats.averageRating.toFixed(1)}
                    </Text>
                  </View>

                  {currentTier.nextTierProgress > 0 && (
                    <View style={styles.tierInfoProgress}>
                      <Text style={[styles.tierInfoProgressText, { color: currentTier.color }]}>
                        {currentTier.nextTierProgress}%
                      </Text>
                      <Text style={styles.tierInfoProgressLabel}>to next tier</Text>
                    </View>
                  )}
                </View>
              </LinearGradient>
            </View>
          </View>
        )}

        {/* Today's Overview */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="time" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <Text style={styles.statNumber}>{todayStats.hoursOnline}</Text>
                  <Text style={styles.statLabel}>Hours Online</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="checkmark-circle" size={22} color="#10B981" />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={todayStats.jobsCompleted} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Jobs Completed</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="cash" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={todayStats.earnings} prefix="£" style={styles.statNumber} />
                  <Text style={styles.statLabel}>Earnings Today</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="trending-up" size={22} color="#F59E0B" />
                </View>
                <View style={styles.statTextContainer}>
                  <Text style={styles.statNumber}>
                    {todayStats.jobsCompleted > 0
                      ? `£${(todayStats.earnings / todayStats.jobsCompleted).toFixed(2)}`
                      : '£0'}
                  </Text>
                  <Text style={styles.statLabel}>Avg per Job</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Business Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Business Information</Text>
          <View style={styles.businessCard}>
            <View style={styles.businessHeader}>
              <Ionicons name={isIndependent ? 'person' : 'business'} size={18} color={SKY} />
              <View style={styles.businessInfo}>
                <Text style={styles.businessTitle}>
                  {isIndependent ? 'Independent Valeter' : 'Organization Valeter'}
                </Text>
                {!isIndependent && organizationName && (
                  <Text style={styles.businessSubtitle}>{organizationName}</Text>
                )}
              </View>
            </View>
          </View>
        </View>

        {/* Profile Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile Settings</Text>
          <View style={styles.menuSection}>
            {/* NEW BUTTON */}
            <TouchableOpacity
              style={styles.menuItem}
              onPress={async () => {
                await hapticFeedback('light');
                await loadValeterServiceSettings();
                setShowServicesModal(true);
              }}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="pricetags" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Services & Pricing</Text>
                <Text style={styles.menuSubtitle}>Wash tiers, eco washing, detailing</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => router.push('/valeter/profile/valeter-personal-info')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="person" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Personal Information</Text>
                <Text style={styles.menuSubtitle}>Name, email, bio, experience</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => router.push('/valeter/profile/valeter-vehicle-info')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="car" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Vehicle Information</Text>
                <Text style={styles.menuSubtitle}>Make, model, registration</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => router.push('/valeter/profile/valeter-legal-compliance')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="shield-checkmark" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Legal Compliance</Text>
                <Text style={styles.menuSubtitle}>Compliance status and action items</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => router.push('/valeter/profile/valeter-documents')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="document-text" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Required Documents</Text>
                <Text style={styles.menuSubtitle}>Upload and manage documents</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          <View style={styles.settingsContainer}>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/owner/settings/privacy-settings');
              }}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="settings" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Privacy & Security</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={SKY} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>
          <View style={styles.settingsContainer}>
            <TouchableOpacity style={[styles.settingItem, styles.logoutItem]} onPress={handleLogout}>
              <View style={styles.settingLeft}>
                <Ionicons name="log-out" size={20} color="#EF4444" style={styles.settingIcon} />
                <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#EF4444" />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.settingItem, styles.deleteItem]}
              onPress={handleDeleteAccount}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="trash" size={20} color="#EF4444" style={styles.settingIcon} />
                <Text style={[styles.settingText, styles.deleteText]}>Delete Account</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </Animated.ScrollView>

      {/* Services & Pricing Modal (NEW) */}
      <Modal visible={showServicesModal} transparent animationType="fade" onRequestClose={() => setShowServicesModal(false)}>
        <Pressable style={styles.modalOverlay2} onPress={() => setShowServicesModal(false)}>
          <Pressable style={styles.modalSheet} onPress={() => {}}>
            <View style={styles.sheetHeader}>
              <Text style={styles.sheetTitle}>Services & Pricing</Text>
              <TouchableOpacity
                style={styles.sheetCloseBtn}
                onPress={() => setShowServicesModal(false)}
              >
                <Ionicons name="close" size={20} color="#F9FAFB" />
              </TouchableOpacity>
            </View>

            {servicesLoading ? (
              <View style={{ paddingVertical: 18, alignItems: 'center', gap: 10 }}>
                <ActivityIndicator size="small" color={SKY} />
                <Text style={{ color: '#E5E7EB', fontWeight: '700' }}>Loading…</Text>
              </View>
            ) : (
              <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 14 }}>
                  <Text style={styles.sheetSub}>
                    These are your default prices. Locations can override later (but this is your baseline).
                  </Text>

                  {/* Eco washing */}
                  <View style={styles.toggleRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.toggleLabel}>Eco washing</Text>
                      <Text style={styles.toggleHint}>Show as eco-friendly</Text>
                    </View>
                    <Switch value={ecoWashing} onValueChange={async (v) => { await hapticFeedback('light'); setEcoWashing(v); }} />
                  </View>

                  {/* Tier pricing */}
                  <Text style={styles.blockTitle}>Wash tiers</Text>
                  <View style={{ gap: 10 }}>
                    {TIER_DEFS.map((t) => {
                      const row = tierPricing[t.key];
                      return (
                        <View key={t.key} style={styles.serviceBox}>
                          <View style={styles.serviceTop}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                              <Ionicons name={t.icon} size={18} color={SKY} />
                              <Text style={styles.serviceName}>{t.name}</Text>
                            </View>
                            <View style={styles.pill}>
                              <Text style={styles.pillText}>£{money(row.price)}</Text>
                            </View>
                          </View>

                          <View style={styles.inputsRow}>
                            <View style={{ flex: 1 }}>
                              <Text style={styles.inputLabel}>Price (£)</Text>
                              <View style={styles.inputCard}>
                                <TextInput
                                  defaultValue={row.price === null ? '' : String(row.price)}
                                  placeholder="0"
                                  placeholderTextColor="rgba(249,250,251,0.45)"
                                  keyboardType="decimal-pad"
                                  style={styles.input}
                                  onEndEditing={(e) => {
                                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'price');
                                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                                    setTierPricing((prev) => ({ ...prev, [t.key]: { ...prev[t.key], price: v } }));
                                  }}
                                />
                              </View>
                            </View>

                            <View style={{ width: 120 }}>
                              <Text style={styles.inputLabel}>Minutes</Text>
                              <View style={styles.inputCard}>
                                <TextInput
                                  defaultValue={row.minutes === null ? '' : String(row.minutes)}
                                  placeholder="—"
                                  placeholderTextColor="rgba(249,250,251,0.45)"
                                  keyboardType="number-pad"
                                  style={styles.input}
                                  onEndEditing={(e) => {
                                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'minutes');
                                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                                    setTierPricing((prev) => ({ ...prev, [t.key]: { ...prev[t.key], minutes: v } }));
                                  }}
                                />
                              </View>
                            </View>
                          </View>
                        </View>
                      );
                    })}
                  </View>

                  {/* Detailing */}
                  <View style={{ height: 14 }} />
                  <View style={styles.toggleRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.toggleLabel}>Detailing offered</Text>
                      <Text style={styles.toggleHint}>Enable detailing add-ons</Text>
                    </View>
                    <Switch value={detailingOffered} onValueChange={async (v) => { await hapticFeedback('light'); setDetailingOffered(v); }} />
                  </View>

                  {detailingOffered && (
                    <>
                      <Text style={styles.blockTitle}>Detailing menu</Text>
                      <View style={{ gap: 10 }}>
                        {DETAILING_DEFS.map((d) => {
                          const item = detailingItems.find((x) => x.key === d.key) || {
                            key: d.key,
                            name: d.name,
                            enabled: false,
                            price: null,
                          };

                          return (
                            <View key={d.key} style={styles.serviceBox}>
                              <View style={styles.serviceTop}>
                                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                                  <Ionicons name={d.icon} size={18} color={SKY} />
                                  <Text style={styles.serviceName}>{d.name}</Text>
                                </View>

                                <View style={{ alignItems: 'flex-end', gap: 6 }}>
                                  <Text style={styles.inputLabel}>Offered</Text>
                                  <Switch
                                    value={!!item.enabled}
                                    onValueChange={async (v) => {
                                      await hapticFeedback('light');
                                      setDetailingItems((prev) =>
                                        prev.map((x) => (x.key === d.key ? { ...x, enabled: v } : x))
                                      );
                                    }}
                                  />
                                </View>
                              </View>

                              <View style={styles.inputsRow}>
                                <View style={{ flex: 1 }}>
                                  <Text style={styles.inputLabel}>Price (£)</Text>
                                  <View style={[styles.inputCard, !item.enabled && { opacity: 0.55 }]}>
                                    <TextInput
                                      editable={!!item.enabled}
                                      defaultValue={item.price === null ? '' : String(item.price)}
                                      placeholder="0"
                                      placeholderTextColor="rgba(249,250,251,0.45)"
                                      keyboardType="decimal-pad"
                                      style={styles.input}
                                      onEndEditing={(e) => {
                                        const v = parseMaybeNumber(e.nativeEvent.text || '', 'price');
                                        if ((e.nativeEvent.text || '').trim() && v === null) return;
                                        setDetailingItems((prev) =>
                                          prev.map((x) => (x.key === d.key ? { ...x, price: v } : x))
                                        );
                                      }}
                                    />
                                  </View>
                                </View>

                                <View style={{ width: 120, justifyContent: 'flex-end' }}>
                                  <View style={styles.pill}>
                                    <Text style={styles.pillText}>{item.price ? `£${money(item.price)}` : '—'}</Text>
                                  </View>
                                </View>
                              </View>
                            </View>
                          );
                        })}
                      </View>
                    </>
                  )}

                  <View style={{ height: 16 }} />

                  <TouchableOpacity
                    style={[styles.primaryAction, servicesSaving && { opacity: 0.75 }]}
                    disabled={servicesSaving}
                    onPress={saveValeterServiceSettings}
                    activeOpacity={0.85}
                  >
                    <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.primaryActionGrad}>
                      {servicesSaving ? (
                        <ActivityIndicator size="small" color="#fff" />
                      ) : (
                        <>
                          <Ionicons name="save-outline" size={18} color="#fff" />
                          <Text style={styles.primaryActionText}>Save</Text>
                        </>
                      )}
                    </LinearGradient>
                  </TouchableOpacity>
                </ScrollView>
              </KeyboardAvoidingView>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Photo Upload Modal */}
      <Modal visible={showPhotoModal} transparent={true} animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload Profile Picture</Text>
            <Text style={styles.modalDescription}>Choose how you want to add your profile picture</Text>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setShowPhotoModal(false);
                  takePhoto();
                }}
                activeOpacity={0.8}
              >
                <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.modalButtonGradient}>
                  <Ionicons name="camera" size={20} color="#FFFFFF" />
                  <Text style={styles.modalButtonText}>Take Photo</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setShowPhotoModal(false);
                  pickImage();
                }}
                activeOpacity={0.8}
              >
                <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.modalButtonGradient}>
                  <Ionicons name="images" size={20} color="#FFFFFF" />
                  <Text style={styles.modalButtonText}>Choose from Gallery</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalButtonCancel}
                onPress={() => setShowPhotoModal(false)}
                activeOpacity={0.8}
              >
                <Text style={styles.modalButtonTextCancel}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#F9FAFB', fontSize: 18, marginTop: 12 },
  scrollView: { flex: 1 },

  heroSection: { padding: isSmallScreen ? 20 : 24, alignItems: 'center' },
  profilePictureContainer: { alignItems: 'center', marginBottom: 20, position: 'relative' },
  profilePicture: {
    width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
    borderWidth: 3, borderColor: 'rgba(135,206,235,0.3)', overflow: 'hidden',
  },
  profilePicturePlaceholder: {
    width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
    borderWidth: 3, borderColor: 'rgba(135,206,235,0.3)',
  },
  profileImage: { width: '100%', height: '100%', borderRadius: 60 },
  uploadButton: {
    position: 'absolute', bottom: 12, right: 0, width: 36, height: 36, borderRadius: 18,
    backgroundColor: SKY, justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#0A1929',
  },
  uploadButtonDisabled: { opacity: 0.7, backgroundColor: '#6B7280' },

  profileInfo: { alignItems: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  userName: { color: '#F9FAFB', fontSize: isSmallScreen ? 24 : 28, fontWeight: '800' },
  emailRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  userEmail: { color: SKY, fontSize: isSmallScreen ? 14 : 16 },
  userExperience: { color: SKY, fontSize: isSmallScreen ? 14 : 16, fontStyle: 'italic' },
  selfSufficiencyBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8,
    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)', alignSelf: 'flex-start',
  },
  selfSufficiencyText: { fontSize: 12, fontWeight: '600' },

  tierBadgeIcon: { fontSize: 40 },
  tierInfoCard: { borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  tierInfoCardGradient: { padding: 12 },
  tierInfoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  tierInfoIcon: { fontSize: 32 },
  tierInfoTextContainer: { flex: 1 },
  tierInfoTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', marginBottom: 4 },
  tierInfoSubtitle: { color: '#E0E7FF', fontSize: 13, fontWeight: '500' },
  tierInfoProgress: { alignItems: 'flex-end' },
  tierInfoProgressText: { fontSize: 18, fontWeight: '900', marginBottom: 2 },
  tierInfoProgressLabel: { color: '#E0E7FF', fontSize: 11, fontWeight: '600' },

  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  sectionTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 16 : 18, fontWeight: '800', marginBottom: 12 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  statCard: {
    width: (width - 48) / 2 - 6,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  statCardContent: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statTextContainer: { flex: 1 },
  statNumber: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#F9FAFB', marginBottom: 2 },
  statLabel: { fontSize: 12, color: SKY, fontWeight: '600' },

  businessCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: 'rgba(135,206,235,0.2)' },
  businessHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  businessInfo: { flex: 1 },
  businessTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  businessSubtitle: { color: SKY, fontSize: 13, marginTop: 2 },

  menuSection: { gap: 8 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    marginBottom: 8,
  },
  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  menuContent: { flex: 1 },
  menuTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: '#87CEEB', fontSize: 11, fontWeight: '600' },

  settingsContainer: { gap: 8 },
  settingItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 12, paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12, borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  settingIcon: { marginRight: 10, width: 20, textAlign: 'center' },
  settingText: { color: '#F9FAFB', fontSize: 14, fontWeight: '700' },

  logoutItem: { borderBottomWidth: 0, backgroundColor: 'rgba(239,68,68,0.1)' },
  deleteItem: { borderBottomWidth: 0, backgroundColor: 'rgba(239,68,68,0.1)' },
  logoutText: { color: '#EF4444' },
  deleteText: { color: '#EF4444' },

  appInfoSection: { padding: 20 },
  appInfoText: { color: SKY, fontSize: 12, textAlign: 'center', marginBottom: 4, opacity: 0.7 },

  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#0A1929',
  },
  verificationBadgeSmall: { backgroundColor: '#10B981', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, marginLeft: 8 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#1E3A8A', borderRadius: 20, padding: 24, margin: 20, width: '90%', maxWidth: 400, borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)' },
  modalTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  modalDescription: { color: '#E5E7EB', fontSize: 14, marginBottom: 24, textAlign: 'center' },
  modalActions: { gap: 12 },
  modalButton: { borderRadius: 12, overflow: 'hidden', elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4 },
  modalButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, paddingHorizontal: 16, gap: 8 },
  modalButtonText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },
  modalButtonCancel: { backgroundColor: 'rgba(255,255,255,0.1)', paddingVertical: 14, paddingHorizontal: 16, alignItems: 'center', borderRadius: 12, marginTop: 4 },
  modalButtonTextCancel: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },

  // NEW modal sheet styles
  modalOverlay2: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.62)',
    padding: 14,
    justifyContent: 'flex-end',
  },
  modalSheet: {
    maxHeight: '86%',
    borderRadius: 20,
    padding: 14,
    backgroundColor: 'rgba(16,20,28,0.94)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sheetTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '900' },
  sheetCloseBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)',
    justifyContent: 'center', alignItems: 'center',
  },
  sheetSub: { color: 'rgba(249,250,251,0.70)', fontSize: 12, marginTop: 8, lineHeight: 18 },

  toggleRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, marginTop: 14 },
  toggleLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '800' },
  toggleHint: { color: 'rgba(249,250,251,0.65)', fontSize: 12, marginTop: 4 },

  blockTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '900', marginTop: 16, marginBottom: 10 },

  serviceBox: {
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceTop: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 },
  serviceName: { color: '#F9FAFB', fontSize: 14, fontWeight: '900', flexShrink: 1 },

  pill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignSelf: 'flex-start',
  },
  pillText: { color: 'rgba(249,250,251,0.88)', fontSize: 12, fontWeight: '900' },

  inputsRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inputLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inputCard: {
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    overflow: 'hidden',
  },
  input: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  primaryAction: { borderRadius: 14, overflow: 'hidden' },
  primaryActionGrad: { paddingVertical: 14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  primaryActionText: { color: '#fff', fontSize: 14, fontWeight: '900' },
});
