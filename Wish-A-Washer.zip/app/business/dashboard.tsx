import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GradientNotificationBell from '../../src/components/shared/GradientNotificationBell';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
}

type BookingStatus =
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'confirmed'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | string;

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

export default function BusinessDashboard() {
  const { user } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessName, setBusinessName] = useState<string>('');
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [businessRating, setBusinessRating] = useState<number>(0);
  const [notificationCount, setNotificationCount] = useState<number>(0);

  const [stats, setStats] = useState({
    totalLocations: 0,
    activeBookings: 0,
    valetersOnline: 0,
    todayRevenue: 0, // we keep this but we won't query unknown columns
    totalRevenue: 0, // same
    completionRate: 0,
    averageRating: 0,
    bookingsThisWeek: 0,
  });

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      loadData();
      fetchNotificationCount();

      const interval = setInterval(fetchNotificationCount, 45000);
      return () => clearInterval(interval);
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  const loadData = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      const [locs, orgData, rating, bookingMetrics, teamCount] = await Promise.all([
        loadLocations(),
        loadOrganizationData(),
        calculateBusinessRating(),
        loadBookingMetrics(),
        loadTeamCount(),
      ]);

      if (orgData) {
        setBusinessName(orgData.name || '');
        setBusinessAddress(orgData.address || '');
      }

      setBusinessRating(rating);

      setStats({
        totalLocations: locs.length,
        activeBookings: bookingMetrics.activeBookings,
        valetersOnline: teamCount, // if you have a real "online" field later, we can replace this
        todayRevenue: 0,
        totalRevenue: 0,
        completionRate: bookingMetrics.completionRate,
        averageRating: rating,
        bookingsThisWeek: bookingMetrics.bookingsThisWeek,
      });
    } catch (error: any) {
      console.error('Error loading business data:', error);
      Alert.alert('Error', error?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const loadLocations = async (): Promise<Location[]> => {
    if (!organizationId) return [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const list = (data || []) as Location[];
      setLocations(list);
      return list;
    } catch (error) {
      console.error('Error loading locations:', error);
      return [];
    }
  };

  const loadOrganizationData = async () => {
    if (!organizationId) return null;
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('name, address')
        .eq('id', organizationId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    } catch (error) {
      console.error('Error loading organization data:', error);
      return null;
    }
  };

  /**
   * ✅ IMPORTANT FIX:
   * Your bookings table DOES NOT have bookings.location_id.
   * We scope bookings to this business using location_address matching
   * the org's car_wash_locations.address list.
   */
  const loadBookingMetrics = async () => {
    if (!organizationId) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    // 1) Get addresses for this org
    const { data: locs, error: locErr } = await supabase
      .from('car_wash_locations')
      .select('address')
      .eq('organization_id', organizationId);

    if (locErr) throw locErr;

    const addresses = (locs || [])
      .map((l: any) => l.address)
      .filter((a: any) => typeof a === 'string' && a.trim().length > 0) as string[];

    if (addresses.length === 0) {
      // No locations = no location-scoped bookings
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    // 2) Load bookings for those addresses (select only columns we KNOW exist)
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select('id, status, created_at')
      .in('location_address', addresses)
      .order('created_at', { ascending: false })
      .limit(500);

    if (error) throw error;

    const rows = (bookings || []) as { id: string; status: BookingStatus; created_at: string }[];

    const ACTIVE_STATUSES: BookingStatus[] = [
      'confirmed',
      'in_progress',
      'pending_business_acceptance',
      'pending_valeter_acceptance',
    ];
    const COMPLETE_STATUSES: BookingStatus[] = ['completed'];
    const CANCEL_STATUSES: BookingStatus[] = ['cancelled'];

    const activeBookings = rows.filter((b) => ACTIVE_STATUSES.includes(b.status)).length;

    const bookingsThisWeek = rows.filter((b) => {
      const t = new Date(b.created_at).getTime();
      return Number.isFinite(t) && t >= weekAgo.getTime();
    }).length;

    const completed = rows.filter((b) => COMPLETE_STATUSES.includes(b.status)).length;
    const cancelled = rows.filter((b) => CANCEL_STATUSES.includes(b.status)).length;
    const finished = completed + cancelled;

    // Completion rate: completed / (completed+cancelled) * 100
    const completionRate = finished > 0 ? Math.round((completed / finished) * 100) : 0;

    return { activeBookings, bookingsThisWeek, completionRate };
  };

  const loadTeamCount = async (): Promise<number> => {
    if (!organizationId) return 0;

    try {
      // count valeters belonging to this org
      const { count, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (error) throw error;
      return count || 0;
    } catch (e) {
      console.warn('Error loading team count:', e);
      return 0;
    }
  };

  const fetchNotificationCount = async () => {
    if (!organizationId) return;

    try {
      // Get all valeters belonging to this organization
      const { data: valeters } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      const valeterIds = valeters?.map((v: any) => v.id) || [];

      let newBookingsCount = 0;
      if (valeterIds.length > 0) {
        const { count } = await supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .in('valeter_id', valeterIds)
          .in('status', [
            'pending',
            'pending_valeter_acceptance',
            'pending_payment',
            'confirmed',
            'valeter_assigned',
          ]);
        newBookingsCount = count || 0;
      }

      const { count: teamRequestsCount } = await supabase
        .from('team_requests')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('status', 'pending');

      setNotificationCount(newBookingsCount + (teamRequestsCount || 0));
    } catch (error) {
      console.error('Error fetching notification count:', error);
      setNotificationCount(0);
    }
  };

  const calculateBusinessRating = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valetersError) throw valetersError;
      if (!valeters || valeters.length === 0) return 0;

      const valeterIds = valeters.map((v: any) => v.id);

      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('rating, status, valeter_id')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('rating', 'is', null);

      if (bookingsError) throw bookingsError;
      if (!bookings || bookings.length === 0) return 0;

      const ratings = bookings
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);

      if (ratings.length === 0) return 0;

      const average = ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length;
      return Math.round(average * 10) / 10;
    } catch (error) {
      console.error('Error calculating business rating:', error);
      return 0;
    }
  };

  const quickActions = [
    {
      id: 'bookings',
      title: 'View Bookings',
      subtitle: 'Manage all',
      icon: 'calendar',
      gradient: ['#3B82F6', '#2563EB'],
      route: '/business/bookings',
    },
    {
      id: 'services',
      title: 'Services & Pricing',
      subtitle: 'View options',
      icon: 'list',
      gradient: ['#8B5CF6', '#7C3AED'],
      route: '/business/services',
    },
    {
      id: 'locations',
      title: 'Locations',
      subtitle: 'Manage sites',
      icon: 'location',
      gradient: ['#10B981', '#059669'],
      route: '/business/locations',
    },
    {
      id: 'team',
      title: 'Team',
      subtitle: 'Manage staff',
      icon: 'people',
      gradient: ['#F59E0B', '#D97706'],
      route: '/business/team',
    },
    {
      id: 'analytics',
      title: 'Analytics',
      subtitle: 'View insights',
      icon: 'stats-chart',
      gradient: [businessTheme.primary, businessTheme.primaryAlt],
      route: '/business/analytics',
    },
    {
      id: 'settings',
      title: 'Settings',
      subtitle: 'Configure',
      icon: 'settings',
      gradient: [businessTheme.primaryAlt, businessTheme.primary],
      route: '/business/settings',
    },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Dashboard" showBack={false} accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading business data...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader
        title={businessName || 'Business Overview'}
        subtitle={
          businessAddress ||
          `${getGreeting()}${user?.name ? `, ${user.name.split(' ')[0]}` : ''}`
        }
        variant="dashboard"
        accountType="business"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        businessName={businessName}
        businessAddress={businessAddress}
        businessRating={businessRating}
        rightAction={
          <GradientNotificationBell
            count={notificationCount}
            onPress={() => router.push('/business/notifications')}
            accentColor={businessTheme.primary}
          />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET },
        ]}
      >
        {/* Key Metrics (improved) */}
        <View style={styles.metricsSection}>
          <View style={styles.sectionTitleRow}>
            <Text style={styles.sectionTitle}>Key Metrics</Text>

            <View style={styles.sectionHintPill}>
              <Ionicons name="pulse" size={14} color={SKY} />
              <Text style={styles.sectionHintText}>Live</Text>
            </View>
          </View>

          <GlassCard style={styles.metricsHeroCard} accountType="business">
            <LinearGradient
              colors={[
                'rgba(255,255,255,0.06)',
                'rgba(255,255,255,0.02)',
                'rgba(0,0,0,0.10)',
              ]}
              style={StyleSheet.absoluteFill}
            />

            <View style={styles.heroRow}>
              <View style={styles.heroLeft}>
                <View
                  style={[
                    styles.heroIcon,
                    {
                      backgroundColor: `${businessTheme.primaryAlt}22`,
                      borderColor: `${businessTheme.primaryAlt}33`,
                    },
                  ]}
                >
                  <Ionicons name="calendar" size={18} color={businessTheme.primaryAlt} />
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.heroLabel}>Active bookings</Text>
                  <Text style={styles.heroValue}>{stats.activeBookings}</Text>
                  <Text style={styles.heroSub}>{stats.bookingsThisWeek} this week</Text>
                </View>
              </View>

              <View style={styles.heroRight}>
                <View style={styles.heroRingWrap}>
                  <View style={styles.heroRingTrack} />
                  <View
                    style={[
                      styles.heroRingFill,
                      {
                        width: `${clamp((stats.activeBookings / 20) * 100, 0, 100)}%`,
                        backgroundColor: businessTheme.primaryAlt,
                      },
                    ]}
                  />
                </View>
                <Text style={styles.heroRingText}>Load</Text>
              </View>
            </View>

            <View style={styles.heroStrip}>
              <View style={styles.stripItem}>
                <Ionicons name="location" size={14} color={businessTheme.primary} />
                <Text style={styles.stripText}>
                  <Text style={styles.stripStrong}>{stats.totalLocations}</Text> locations
                </Text>
              </View>

              <View style={styles.stripDot} />

              <View style={styles.stripItem}>
                <Ionicons name="people" size={14} color={SKY} />
                <Text style={styles.stripText}>
                  <Text style={styles.stripStrong}>{stats.valetersOnline}</Text> team
                </Text>
              </View>

              <View style={styles.stripDot} />

              <View style={styles.stripItem}>
                <Ionicons name="trending-up" size={14} color="#34D399" />
                <Text style={styles.stripText}>
                  <Text style={styles.stripStrong}>
                    {Math.round(clamp(stats.completionRate, 0, 100))}%
                  </Text>{' '}
                  completion
                </Text>
              </View>
            </View>
          </GlassCard>

          <View style={styles.metricsMiniRow}>
            <GlassCard style={styles.metricsMiniCard} accountType="business">
              <LinearGradient
                colors={['rgba(135,206,235,0.10)', 'rgba(255,255,255,0.02)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.miniTop}>
                <View
                  style={[
                    styles.miniIcon,
                    { backgroundColor: `${SKY}1A`, borderColor: `${SKY}2A` },
                  ]}
                >
                  <Ionicons name="people" size={16} color={SKY} />
                </View>
                <Text style={styles.miniLabel}>Team Members</Text>
              </View>
              <Text style={styles.miniValue}>{stats.valetersOnline}</Text>
              <Text style={styles.miniSub}>Assigned to org</Text>
            </GlassCard>

            <GlassCard style={styles.metricsMiniCard} accountType="business">
              <LinearGradient
                colors={['rgba(52,211,153,0.10)', 'rgba(255,255,255,0.02)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.miniTop}>
                <View
                  style={[
                    styles.miniIcon,
                    {
                      backgroundColor: 'rgba(52,211,153,0.14)',
                      borderColor: 'rgba(52,211,153,0.22)',
                    },
                  ]}
                >
                  <Ionicons name="checkmark-done" size={16} color="#34D399" />
                </View>
                <Text style={styles.miniLabel}>Completion</Text>
              </View>
              <Text style={styles.miniValue}>
                {Math.round(clamp(stats.completionRate, 0, 100))}%
              </Text>
              <Text style={styles.miniSub}>Completed vs cancelled</Text>
            </GlassCard>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsContainer}
          >
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                activeOpacity={0.85}
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push(action.route as any);
                }}
                style={styles.quickActionCard}
              >
                <View style={styles.quickActionContent}>
                  <View style={styles.quickActionIconWrapper}>
                    <Ionicons name={action.icon as any} size={18} color={businessTheme.primary} />
                  </View>
                  <View style={styles.quickActionTextContainer}>
                    <Text style={styles.quickActionTitle}>{action.title}</Text>
                    <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Locations Summary */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Locations</Text>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/locations');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {locations.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    router.push('/business/locations');
                  }}
                  style={styles.addButton}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={['#10B981', '#059669']} style={styles.addButtonGradient}>
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          ) : (
            <View style={styles.locationsList}>
              {locations.slice(0, 3).map((location, index) => (
                <Animated.View
                  key={location.id}
                  style={[
                    { opacity: fadeAnim },
                    {
                      transform: [
                        {
                          translateY: fadeAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: [30 + index * 10, 0],
                          }),
                        },
                      ],
                    },
                  ]}
                >
                  <GlassCard
                    onPress={async () => {
                      await hapticFeedback('light');
                      router.push(`/business/locations/${location.id}` as any);
                    }}
                    style={styles.locationCard}
                    accountType="business"
                  >
                    <View style={styles.locationContent}>
                      <View style={styles.locationIconWrapper}>
                        <Ionicons name="location" size={20} color={businessTheme.primary} />
                      </View>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationAddress} numberOfLines={1}>
                          {location.address || 'Address not set'}
                        </Text>
                      </View>
                      <Ionicons name="chevron-forward" size={18} color={businessTheme.primary} />
                    </View>
                  </GlassCard>
                </Animated.View>
              ))}

              {locations.length > 3 && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push('/business/locations');
                  }}
                  style={styles.viewMoreButton}
                >
                  <Text style={styles.viewMoreText}>
                    View {locations.length - 3} more location{locations.length - 3 !== 1 ? 's' : ''}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        <View style={styles.poweredBySection}>
          <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },

  scrollView: { flex: 1 },
  scrollContent: { padding: isSmallScreen ? 16 : 20, paddingBottom: 100 },

  // --- Key Metrics (improved) ---
  metricsSection: { marginBottom: 26 },

  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },

  sectionHintPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  sectionHintText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '900',
  },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
    letterSpacing: 0.2,
  },

  metricsHeroCard: {
    borderRadius: 22,
    overflow: 'hidden',
    padding: 14,
    marginBottom: 12,
  },

  heroRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },

  heroLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },

  heroIcon: {
    width: 40,
    height: 40,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },

  heroLabel: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    fontWeight: '800',
  },

  heroValue: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
    marginTop: 2,
  },

  heroSub: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },

  heroRight: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: 6,
    width: 86,
  },

  heroRingWrap: {
    width: 78,
    height: 10,
    borderRadius: 999,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.10)',
  },

  heroRingTrack: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },

  heroRingFill: {
    height: '100%',
    borderRadius: 999,
  },

  heroRingText: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '800',
  },

  heroStrip: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.10)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },

  stripItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },

  stripText: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '800',
  },

  stripStrong: {
    color: '#F9FAFB',
    fontWeight: '900',
  },

  stripDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.18)',
  },

  metricsMiniRow: {
    flexDirection: 'row',
    gap: 12,
  },

  metricsMiniCard: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    padding: 14,
    minHeight: 110,
  },

  miniTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },

  miniIcon: {
    width: 34,
    height: 34,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },

  miniLabel: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    fontWeight: '900',
  },

  miniValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
  },

  miniSub: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '700',
    marginTop: 4,
  },

  // --- Quick actions ---
  quickActionsSection: { marginBottom: 32 },
  quickActionsContainer: { paddingRight: isSmallScreen ? 16 : 20 },
  quickActionCard: {
    borderRadius: 16,
    backgroundColor: `${businessTheme.primary}1A`,
    borderWidth: 1,
    borderColor: `${businessTheme.primary}33`,
    width: 130,
    marginRight: 12,
  },
  quickActionContent: { padding: SPACING.md, gap: SPACING.sm },
  quickActionIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  quickActionTextContainer: { gap: 2 },
  quickActionTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '700', letterSpacing: 0.1 },
  quickActionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '500' },

  // --- Locations ---
  section: { marginBottom: 32 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  viewAllText: { color: SKY, fontSize: 14, fontWeight: '600' },

  locationsList: { gap: 12 },
  locationCard: { ...CARD_SIZES.small },
  locationContent: { flexDirection: 'row', alignItems: 'center', gap: SPACING.lg, padding: CARD_SIZES.small.padding },
  locationIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: { flex: 1 },
  locationName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 4, letterSpacing: 0.2 },
  locationAddress: { color: 'rgba(249,250,251,0.7)', fontSize: 13, lineHeight: 18 },

  emptyCard: { ...CARD_SIZES.large },
  emptyContent: { alignItems: 'center' },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginTop: 20, marginBottom: 12 },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, textAlign: 'center', marginBottom: 24, lineHeight: 20 },

  addButton: { borderRadius: 16, overflow: 'hidden' },
  addButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 22 },
  addButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800' },

  viewMoreButton: { padding: 12, alignItems: 'center' },
  viewMoreText: { color: SKY, fontSize: 14, fontWeight: '600' },

  poweredBySection: { alignItems: 'center', paddingVertical: 24, marginTop: 8 },
  poweredByText: { color: SKY, fontSize: 12, opacity: 0.8, fontWeight: '600' },
});
