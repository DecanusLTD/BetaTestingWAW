import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
  RefreshControl,
  Platform,
  KeyboardAvoidingView,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import * as ImagePicker from 'expo-image-picker';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const businessTheme = getAccountTheme('business');
const SKY = colors.SKY;

type OrgRow = Record<string, any>;

function getMissingColumn(message?: string | null) {
  const m = (message || '').match(/column\s+organizations\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

const DARK_TEXT = '#0F172A';
const MUTED_TEXT = 'rgba(15,23,42,0.62)';
const CARD_FILL = 'rgba(255,255,255,0.78)';
const CARD_STROKE = 'rgba(15,23,42,0.10)';

export default function BusinessProfile() {
  const { user } = useAuth();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // logo
  const [logoUrl, setLogoUrl] = useState<string>('');
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  // form fields
  const [businessName, setBusinessName] = useState('');
  const [businessEmail, setBusinessEmail] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [taxId, setTaxId] = useState('');

  const originalRef = useRef({
    logoUrl: '',
    businessName: '',
    businessEmail: '',
    businessPhone: '',
    businessAddress: '',
    businessDescription: '',
    taxId: '',
  });

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const hasChanges = useMemo(() => {
    const o = originalRef.current;
    return (
      logoUrl !== o.logoUrl ||
      businessName !== o.businessName ||
      businessEmail !== o.businessEmail ||
      businessPhone !== o.businessPhone ||
      businessAddress !== o.businessAddress ||
      businessDescription !== o.businessDescription ||
      taxId !== o.taxId
    );
  }, [logoUrl, businessName, businessEmail, businessPhone, businessAddress, businessDescription, taxId]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadBusinessProfile();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  useFocusEffect(
    React.useCallback(() => {
      if (isOrgUser && organizationId) loadBusinessProfile(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [organizationId, isOrgUser])
  );

  const applyOrgToForm = (org: OrgRow | null) => {
    const nextName = (org?.name ?? '') as string;
    const nextEmail = ((org?.email ?? user?.email ?? '') as string) || '';
    const nextPhone = (org?.phone ?? '') as string;
    const nextAddress = (org?.address ?? '') as string;
    const nextDesc = (org?.description ?? '') as string;

    const nextTax = (org?.tax_id ?? org?.vat_number ?? org?.vat ?? org?.taxid ?? '') as string;

    const nextLogo = (org?.logo ?? org?.logo_url ?? org?.avatar_url ?? org?.profile_picture ?? '') as string;

    setBusinessName(nextName);
    setBusinessEmail(nextEmail);
    setBusinessPhone(nextPhone);
    setBusinessAddress(nextAddress);
    setBusinessDescription(nextDesc);
    setTaxId(nextTax);
    setLogoUrl(nextLogo);

    originalRef.current = {
      logoUrl: nextLogo,
      businessName: nextName,
      businessEmail: nextEmail,
      businessPhone: nextPhone,
      businessAddress: nextAddress,
      businessDescription: nextDesc,
      taxId: nextTax,
    };
  };

  const loadBusinessProfile = async (showSpinner = true) => {
    if (!isOrgUser || !organizationId) return;

    try {
      if (showSpinner) setLoading(true);

      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) throw error;

      applyOrgToForm(data || null);
    } catch (error: any) {
      console.error('Error loading business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to load business information');
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  const onRefresh = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      setRefreshing(true);
      await loadBusinessProfile(false);
    } finally {
      setRefreshing(false);
    }
  };

  const cancelEditing = async () => {
    await hapticFeedback('light');
    const o = originalRef.current;
    setLogoUrl(o.logoUrl);
    setBusinessName(o.businessName);
    setBusinessEmail(o.businessEmail);
    setBusinessPhone(o.businessPhone);
    setBusinessAddress(o.businessAddress);
    setBusinessDescription(o.businessDescription);
    setTaxId(o.taxId);
    setIsEditing(false);
  };

  // storage
  const BUCKET = 'org-logos';

  const uploadLogoToStorage = async (localUri: string) => {
    if (!organizationId) return '';

    const ext = (localUri.split('.').pop() || 'jpg').toLowerCase();
    const path = `organizations/${organizationId}/logo_${Date.now()}.${ext}`;

    const res = await fetch(localUri);
    const blob = await res.blob();

    const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, blob, {
      upsert: true,
      contentType: blob.type || (ext === 'png' ? 'image/png' : 'image/jpeg'),
    });

    if (upErr) throw upErr;

    const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
    return data?.publicUrl || '';
  };

  const handlePickLogo = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload your logo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.9,
      });

      if (result.canceled) return;

      const uri = result.assets?.[0]?.uri;
      if (!uri) return;

      setIsUploadingLogo(true);

      let finalUrl = uri;

      try {
        const uploaded = await uploadLogoToStorage(uri);
        if (uploaded) finalUrl = uploaded;
      } catch (e: any) {
        console.warn('[BusinessProfile] logo upload failed (using local preview):', e?.message || e);
        Alert.alert(
          'Logo upload not configured',
          'I picked the image but couldn’t upload it yet. If you want it to persist, create a Supabase Storage bucket named "org-logos" (or update BUCKET in this file).'
        );
      }

      setLogoUrl(finalUrl);
      setIsEditing(true);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = async () => {
    await hapticFeedback('light');
    setLogoUrl('');
    setIsEditing(true);
  };

  const handleSave = async () => {
    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    if (!businessName.trim()) {
      Alert.alert('Missing info', 'Business name is required.');
      return;
    }

    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const payload: Record<string, any> = {
        id: organizationId,
        name: businessName.trim(),
        email: businessEmail.trim() || null,
        phone: businessPhone.trim() || null,
        address: businessAddress.trim() || null,
        description: businessDescription.trim() || null,
        updated_at: new Date().toISOString(),
      };

      const logoValue = logoUrl.trim() || null;

      let { error } = await supabase
        .from('organizations')
        .upsert({ ...payload, tax_id: taxId.trim() || null, logo: logoValue });

      if (error) {
        const missing = getMissingColumn(error.message);

        if (missing === 'tax_id') {
          const retry = await supabase
            .from('organizations')
            .upsert({ ...payload, vat_number: taxId.trim() || null, logo: logoValue });
          error = retry.error;
        }

        if (missing === 'logo') {
          const retry2 = await supabase
            .from('organizations')
            .upsert({ ...payload, tax_id: taxId.trim() || null, logo_url: logoValue });
          error = retry2.error;
        }

        if (error) {
          const missing2 = getMissingColumn(error.message);
          if (missing2 === 'logo_url') {
            const retry3 = await supabase
              .from('organizations')
              .upsert({ ...payload, tax_id: taxId.trim() || null, avatar_url: logoValue });
            error = retry3.error;
          }
        }
      }

      if (error) throw error;

      await loadBusinessProfile(false);
      Alert.alert('Saved', 'Your business profile has been updated.');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save business information');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Profile" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={businessTheme.primary} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Profile" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={businessTheme.primary} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const TitleRight = () => {
    if (!isEditing) {
      return (
        <TouchableOpacity
          onPress={async () => {
            await hapticFeedback('light');
            setIsEditing(true);
          }}
          style={styles.headerAction}
          activeOpacity={0.85}
        >
          <Ionicons name="create-outline" size={18} color={DARK_TEXT} />
        </TouchableOpacity>
      );
    }

    return (
      <TouchableOpacity onPress={cancelEditing} style={styles.headerAction} activeOpacity={0.85}>
        <Ionicons name="close" size={18} color={DARK_TEXT} />
      </TouchableOpacity>
    );
  };

  const CircleLogo = () => {
    if (logoUrl) {
      return <Image source={{ uri: logoUrl }} style={styles.logoCircleImg} />;
    }
    return (
      <View style={styles.logoCircleFallback}>
        <Ionicons name="business" size={34} color={businessTheme.primary} />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Profile"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
        rightAction={<TitleRight />}
      />

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
            {/* ====== CENTERED CIRCLE HERO ====== */}
            <View style={styles.heroCard}>
              <View style={styles.heroTop}>
                <View style={styles.logoCircleOuter}>
                  <View style={styles.logoCircleInner}>
                    <CircleLogo />
                  </View>

                  <TouchableOpacity
                    style={styles.logoEditBtn}
                    onPress={handlePickLogo}
                    activeOpacity={0.85}
                    disabled={isUploadingLogo}
                  >
                    {isUploadingLogo ? (
                      <ActivityIndicator size="small" color={DARK_TEXT} />
                    ) : (
                      <Ionicons name="camera" size={16} color={DARK_TEXT} />
                    )}
                  </TouchableOpacity>
                </View>

                <Text style={styles.heroName} numberOfLines={1}>
                  {businessName || 'Your business'}
                </Text>

                <Text style={styles.heroSub} numberOfLines={1}>
                  {businessEmail || user?.email || 'Add your email'}
                </Text>

                <View style={styles.heroPillsRow}>
                  <View style={styles.pill}>
                    <Ionicons name="shield-checkmark" size={14} color={businessTheme.primary} />
                    <Text style={styles.pillText}>Business</Text>
                  </View>

                  <View style={styles.pill}>
                    <Ionicons name="location" size={14} color={businessTheme.primary} />
                    <Text style={styles.pillText}>{businessAddress ? 'Address set' : 'No address'}</Text>
                  </View>
                </View>

                <View style={styles.heroActionsRow}>
                  <TouchableOpacity
                    style={styles.heroBtn}
                    onPress={handlePickLogo}
                    activeOpacity={0.86}
                    disabled={isUploadingLogo}
                  >
                    <Ionicons name="image" size={16} color={DARK_TEXT} />
                    <Text style={styles.heroBtnText}>{logoUrl ? 'Change logo' : 'Upload logo'}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.heroBtn, !logoUrl && { opacity: 0.45 }]}
                    onPress={handleRemoveLogo}
                    activeOpacity={0.86}
                    disabled={!logoUrl}
                  >
                    <Ionicons name="trash" size={16} color={DARK_TEXT} />
                    <Text style={styles.heroBtnText}>Remove</Text>
                  </TouchableOpacity>
                </View>

                {!isEditing ? (
                  <Text style={styles.heroHint}>Tap the pencil to edit details. Upload a logo to personalise the account.</Text>
                ) : (
                  <Text style={styles.heroHint}>
                    Editing mode on — make changes then hit <Text style={{ fontWeight: '900' }}>Save</Text>.
                  </Text>
                )}
              </View>
            </View>

            {/* ====== FORM ====== */}
            <View style={styles.section}>
              <Text style={styles.label}>Business Name</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={styles.input}
                  value={businessName}
                  onChangeText={setBusinessName}
                  placeholder="Enter business name"
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={styles.label}>Email</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={styles.input}
                  value={businessEmail}
                  onChangeText={setBusinessEmail}
                  placeholder="Enter email"
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={styles.label}>Phone Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={styles.input}
                  value={businessPhone}
                  onChangeText={setBusinessPhone}
                  placeholder="Enter phone number"
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  keyboardType="phone-pad"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={styles.label}>Business Address</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={businessAddress}
                  onChangeText={setBusinessAddress}
                  placeholder="Enter business address"
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  multiline
                  numberOfLines={3}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={styles.label}>Business Description</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={[styles.input, styles.textArea, { minHeight: 120 }]}
                  value={businessDescription}
                  onChangeText={setBusinessDescription}
                  placeholder="What do you do? (e.g. premium detailing, fleet washing…) "
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  multiline
                  numberOfLines={4}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={styles.label}>Tax ID / VAT Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <View style={styles.lightCardFill} />
                <TextInput
                  style={styles.input}
                  value={taxId}
                  onChangeText={setTaxId}
                  placeholder="Enter tax ID"
                  placeholderTextColor="rgba(15,23,42,0.35)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* ====== SAVE / CANCEL ====== */}
            {isEditing ? (
              <View style={{ gap: 10, marginTop: SPACING.lg }}>
                <TouchableOpacity
                  style={[styles.saveButton, (!hasChanges || isSaving) && { opacity: 0.6 }]}
                  onPress={handleSave}
                  disabled={!hasChanges || isSaving}
                  activeOpacity={0.86}
                >
                  <LinearGradient
                    colors={[businessTheme.primaryAlt, businessTheme.primary]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.saveButtonGradient}
                  >
                    {isSaving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#fff" />
                        <Text style={styles.saveButtonText}>Save</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.secondaryButton, isSaving && { opacity: 0.7 }]}
                  onPress={cancelEditing}
                  disabled={isSaving}
                  activeOpacity={0.86}
                >
                  <Ionicons name="close" size={18} color={DARK_TEXT} />
                  <Text style={styles.secondaryButtonText}>Cancel</Text>
                </TouchableOpacity>

                {!hasChanges && <Text style={styles.hintText}>No changes to save.</Text>}
              </View>
            ) : (
              <Text style={styles.hintText}>Tip: add a logo + description. It makes the business pages feel way more premium.</Text>
            )}

            <View style={{ height: 28 }} />
          </Animated.View>
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const CIRCLE = 104;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FBFF' },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: { color: MUTED_TEXT, fontSize: 14, fontWeight: '700' },

  scrollView: { flex: 1 },
  scrollContent: { padding: isSmallScreen ? 16 : 20, paddingBottom: 110 },

  content: { gap: SPACING.lg },
  section: { gap: SPACING.sm },

  label: { color: MUTED_TEXT, fontSize: 13, fontWeight: '800', marginBottom: 4, letterSpacing: 0.2 },

  heroCard: {
    borderRadius: 22,
    padding: 16,
    backgroundColor: CARD_FILL,
    borderWidth: 1,
    borderColor: CARD_STROKE,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.08,
    shadowRadius: 18,
    elevation: 10,
  },
  heroTop: {
    alignItems: 'center',
  },

  // === centered circle logo ===
  logoCircleOuter: {
    width: CIRCLE,
    height: CIRCLE,
    borderRadius: CIRCLE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.10,
    shadowRadius: 16,
    elevation: 9,
    marginBottom: 12,
  },
  logoCircleInner: {
    width: CIRCLE - 10,
    height: CIRCLE - 10,
    borderRadius: (CIRCLE - 10) / 2,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.98)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoCircleImg: {
    width: '100%',
    height: '100%',
  },
  logoCircleFallback: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoEditBtn: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.94)',
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 14,
    elevation: 10,
  },

  heroName: { color: DARK_TEXT, fontSize: 20, fontWeight: '900', letterSpacing: 0.2, textAlign: 'center' },
  heroSub: { color: MUTED_TEXT, fontSize: 13, fontWeight: '800', marginTop: 6, textAlign: 'center' },

  heroPillsRow: { flexDirection: 'row', gap: 8, marginTop: 12, flexWrap: 'wrap', justifyContent: 'center' },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(37,99,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(37,99,235,0.12)',
  },
  pillText: { color: DARK_TEXT, fontSize: 12, fontWeight: '900' },

  heroActionsRow: { flexDirection: 'row', gap: 10, marginTop: 14, width: '100%' },
  heroBtn: {
    flex: 1,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  heroBtnText: { color: DARK_TEXT, fontSize: 13, fontWeight: '900' },

  heroHint: { marginTop: 12, color: MUTED_TEXT, fontSize: 12, fontWeight: '700', lineHeight: 16, textAlign: 'center' },

  // inputs
  inputCard: { ...CARD_SIZES.small, overflow: 'hidden' },
  lightCardFill: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: CARD_FILL,
    borderWidth: 1,
    borderColor: CARD_STROKE,
    borderRadius: 18,
  },
  input: { color: DARK_TEXT, fontSize: 16, padding: 0, fontWeight: '800' },
  textArea: { minHeight: 80, textAlignVertical: 'top' },

  headerAction: {
    width: 36,
    height: 36,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.85)',
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.12)',
  },

  saveButton: { borderRadius: 16, overflow: 'hidden' },
  saveButtonGradient: {
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 18,
  },
  saveButtonText: { color: '#fff', fontSize: 16, fontWeight: '900' },

  secondaryButton: {
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  secondaryButtonText: { color: DARK_TEXT, fontSize: 15, fontWeight: '900' },

  hintText: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 8,
    textAlign: 'center',
    fontWeight: '700',
  },
});
