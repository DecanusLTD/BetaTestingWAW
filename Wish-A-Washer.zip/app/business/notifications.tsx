import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface NotificationSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
  category: 'bookings' | 'team' | 'analytics' | 'system';
}

export default function BusinessNotifications() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<NotificationSetting[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadSettings();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load notification settings from database
      const defaultSettings: NotificationSetting[] = [
        {
          id: 'new_booking',
          label: 'New Bookings',
          description: 'Get notified when new bookings are created',
          enabled: true,
          category: 'bookings',
        },
        {
          id: 'booking_cancelled',
          label: 'Booking Cancellations',
          description: 'Alert when customers cancel bookings',
          enabled: true,
          category: 'bookings',
        },
        {
          id: 'valeter_online',
          label: 'Valeter Status',
          description: 'Notifications when valeters come online or go offline',
          enabled: false,
          category: 'team',
        },
        {
          id: 'team_updates',
          label: 'Team Updates',
          description: 'Important updates about your team members',
          enabled: true,
          category: 'team',
        },
        {
          id: 'daily_summary',
          label: 'Daily Summary',
          description: 'Receive daily reports of your business performance',
          enabled: true,
          category: 'analytics',
        },
        {
          id: 'weekly_report',
          label: 'Weekly Reports',
          description: 'Weekly analytics and insights',
          enabled: false,
          category: 'analytics',
        },
        {
          id: 'system_updates',
          label: 'System Updates',
          description: 'Important app updates and maintenance notices',
          enabled: true,
          category: 'system',
        },
      ];
      setSettings(defaultSettings);
    } catch (error) {
      console.error('Error loading notification settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSetting = async (settingId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      setSettings(prev =>
        prev.map(s => (s.id === settingId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // await supabase.from('business_notification_settings').upsert({...});
    } catch (error) {
      console.error('Error toggling setting:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'bookings':
        return 'calendar';
      case 'team':
        return 'people';
      case 'analytics':
        return 'stats-chart';
      case 'system':
        return 'settings';
      default:
        return 'notifications';
    }
  };

  const groupedSettings = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) {
      acc[setting.category] = [];
    }
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, NotificationSetting[]>);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Notification Settings" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Notification Settings"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Manage Notifications</Text>
          <Text style={styles.sectionSubtitle}>
            Choose which notifications you want to receive
          </Text>

          {Object.entries(groupedSettings).map(([category, categorySettings]) => (
            <View key={category} style={styles.categorySection}>
              <View style={styles.categoryHeader}>
                <Ionicons
                  name={getCategoryIcon(category) as any}
                  size={18}
                  color="#8B5CF6"
                />
                <Text style={styles.categoryTitle}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </Text>
              </View>

              <View style={styles.settingsList}>
                {categorySettings.map((setting) => (
                  <GlassCard key={setting.id} style={styles.settingCard} accountType="business">
                    <View style={styles.settingContent}>
                      <View style={styles.settingInfo}>
                        <Text style={styles.settingLabel}>{setting.label}</Text>
                        <Text style={styles.settingDescription}>{setting.description}</Text>
                      </View>
                      <Switch
                        value={setting.enabled}
                        onValueChange={() => toggleSetting(setting.id)}
                        trackColor={{ false: 'rgba(255,255,255,0.1)', true: '#8B5CF6' }}
                        thumbColor={setting.enabled ? '#FFFFFF' : '#6B7280'}
                        ios_backgroundColor="rgba(255,255,255,0.1)"
                      />
                    </View>
                  </GlassCard>
                ))}
              </View>
            </View>
          ))}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.xl,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: SPACING.lg,
  },
  categorySection: {
    gap: SPACING.md,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.xs,
  },
  categoryTitle: {
    color: '#8B5CF6',
    fontSize: 16,
    fontWeight: '700',
  },
  settingsList: {
    gap: SPACING.sm,
  },
  settingCard: {
    ...CARD_SIZES.small,
  },
  settingContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: CARD_SIZES.small.padding,
  },
  settingInfo: {
    flex: 1,
    gap: 2,
    marginRight: SPACING.md,
  },
  settingLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  settingDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    lineHeight: 16,
    marginTop: 2,
  },
});

