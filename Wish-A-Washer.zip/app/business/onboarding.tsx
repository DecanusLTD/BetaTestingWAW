import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

const onboardingSlides = [
  {
    id: 1,
    title: 'Welcome to Wish a Wash for Businesses',
    description:
      'Manage your physical car wash locations, accept bookings, and grow your business with ease.',
    icon: 'business',
    color: '#3B82F6',
  },
  {
    id: 2,
    title: 'Add Your Locations',
    description:
      'Start by adding your physical car wash locations. Each location can accept bookings independently.',
    icon: 'location',
    color: '#10B981',
  },
  {
    id: 3,
    title: 'Invite Valeters to Your Team',
    description:
      'Build your team by inviting valeters to work at your locations. They can accept bookings and clock in/out.',
    icon: 'people',
    color: '#F59E0B',
  },
  {
    id: 4,
    title: 'Accept and Manage Bookings',
    description:
      'Receive booking requests, accept or reject them, and assign valeters. Track everything in real-time.',
    icon: 'calendar',
    color: '#8B5CF6',
  },
  {
    id: 5,
    title: 'Use AI Car Care Hub',
    description:
      'Access tips and guides on eco washes, learn how to grow your business, and discover free marketing opportunities.',
    icon: 'bulb',
    color: '#EC4899',
  },
  {
    id: 6,
    title: 'Eco Wash Benefits',
    description:
      'Offer eco-friendly services and benefit from free marketing. Attract environmentally conscious customers.',
    icon: 'leaf',
    color: '#10B981',
  },
  {
    id: 7,
    title: 'Terms & Policies',
    description:
      'Please review and agree to our Terms of Service and Privacy Policy to continue.',
    icon: 'document-text',
    color: '#6B7280',
  },
];

export default function BusinessOnboarding() {
    const scrollViewRef = useRef<ScrollView>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const handleScroll = (event: any) => {
    const slideIndex = Math.round(event.nativeEvent.contentOffset.x / width);
    if (slideIndex !== currentSlide) {
      setCurrentSlide(slideIndex);
      hapticFeedback('light');
      Animated.sequence([
        Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    }
  };

  const goToSlide = (index: number) => {
    scrollViewRef.current?.scrollTo({ x: index * width, animated: true });
    setCurrentSlide(index);
    hapticFeedback('light');
  };

  const handleNext = () => {
    if (currentSlide < onboardingSlides.length - 1) {
      goToSlide(currentSlide + 1);
    } else {
      handleGetStarted();
    }
  };

  const handleGetStarted = async () => {
    await hapticFeedback('medium');
    // TODO: Mark onboarding as seen
    router.replace('/business/dashboard');
  };

  const handleSkip = async () => {
    await hapticFeedback('medium');
    // TODO: Mark onboarding as seen
    router.replace('/business/dashboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Welcome to Wish a Wash"
        showBack={false}
        rightAction={
          currentSlide < onboardingSlides.length - 1 ? (
            <TouchableOpacity
              onPress={handleSkip}
              style={styles.skipButton}
            >
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          ) : null
        }
      />

      <View style={styles.contentWrapper}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.slidesContainer}
        >
          {onboardingSlides.map((slide) => (
            <View key={slide.id} style={styles.slide}>
              <Animated.View style={[styles.slideContent, { opacity: fadeAnim }]}>
                <GlassCard style={styles.iconCard} borderColor={`${slide.color}40`}>
                  <LinearGradient
                    colors={[`${slide.color}25`, `${slide.color}15`]}
                    style={styles.iconGradient}
                  >
                    <Ionicons name={slide.icon as any} size={64} color={slide.color} />
                  </LinearGradient>
                </GlassCard>

                <Text style={styles.slideTitle}>{slide.title}</Text>
                <Text style={styles.slideDescription}>{slide.description}</Text>
              </Animated.View>
            </View>
          ))}
        </ScrollView>

        {/* Pagination Dots */}
        <View style={styles.pagination}>
          {onboardingSlides.map((_, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => goToSlide(index)}
              style={[
                styles.dot,
                currentSlide === index && styles.dotActive,
                { backgroundColor: currentSlide === index ? SKY : 'rgba(135,206,235,0.3)' },
              ]}
            />
          ))}
        </View>

        {/* Navigation Buttons */}
        <View style={styles.navigation}>
          {currentSlide > 0 && (
            <TouchableOpacity
              onPress={() => goToSlide(currentSlide - 1)}
              style={styles.backButton}
            >
              <GlassCard style={styles.navButtonCard} borderColor="rgba(135,206,235,0.3)">
                <Ionicons name="chevron-back" size={24} color={SKY} />
              </GlassCard>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            onPress={handleNext}
            style={[styles.nextButton, currentSlide === 0 && styles.nextButtonFull]}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.nextButtonGradient}
            >
              <Text style={styles.nextButtonText}>
                {currentSlide === onboardingSlides.length - 1 ? 'Get Started' : 'Next'}
              </Text>
              <Ionicons
                name={currentSlide === onboardingSlides.length - 1 ? 'checkmark' : 'chevron-forward'}
                size={20}
                color="#FFFFFF"
              />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  contentWrapper: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  skipButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  skipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slidesContainer: {
    flex: 1,
  },
  slide: {
    width,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  slideContent: {
    alignItems: 'center',
    maxWidth: 400,
  },
  iconCard: {
    width: 140,
    height: 140,
    borderRadius: 70,
    padding: 0,
    overflow: 'hidden',
    marginBottom: 40,
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: 0.3,
  },
  slideDescription: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  dotActive: {
    width: 24,
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 40,
    gap: 12,
  },
  backButton: {
    width: 50,
  },
  navButtonCard: {
    width: 50,
    height: 50,
    borderRadius: 25,
    padding: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextButton: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  nextButtonFull: {
    marginLeft: 0,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
