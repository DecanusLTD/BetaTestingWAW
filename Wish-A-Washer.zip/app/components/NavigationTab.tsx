import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 78;
const BAR_MARGIN_H = 16;
const BAR_RADIUS = 34;

const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT + 16;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      { name: 'Trip', icon: 'navigate', route: '/valeter/jobs/tracking' },
      { name: 'Earnings', icon: 'cash', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Book', icon: 'calendar', route: '/owner/booking' },
    { name: 'History', icon: 'time', route: '/owner/wash-history' },
    { name: 'Rewards', icon: 'gift', route: '/owner/features/rewards' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex((t) => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }

  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex((t) => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }

  if (pathname.includes('/valeter/jobs/')) {
    if (
      pathname.includes('/valeter/jobs/tracking') ||
      pathname.includes('/valeter/jobs/accept') ||
      pathname.includes('/valeter/jobs/complete')
    ) {
      const tripIndex = tabs.findIndex((t) => t.route === '/valeter/jobs/tracking');
      return tripIndex >= 0 ? tripIndex : 0;
    }
    const jobsIndex = tabs.findIndex((t) => t.route === '/valeter/jobs/queue');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }

  if (pathname.includes('/valeter/valeter-wash-history')) {
    const earningsIndex = tabs.findIndex((t) => t.route === '/valeter/valeter-wash-history');
    return earningsIndex >= 0 ? earningsIndex : 0;
  }

  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex((t) => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex((t) => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex((t) => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex((t) => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }

  return 0;
};

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent =
    (isBusinessRoute && businessTheme?.primary) ||
    (isCustomerRoute && customerTheme?.primary) ||
    colors.navActive;

  // ✅ Business needs dark text/icons on a light background
  const inactiveIcon = isBusinessRoute ? 'rgba(15,23,42,0.58)' : 'rgba(255,255,255,0.70)';
  const inactiveLabel = isBusinessRoute ? 'rgba(15,23,42,0.52)' : 'rgba(255,255,255,0.68)';

  const barWidth = width - BAR_MARGIN_H * 2;
  const pad = 12;
  const slotW = (barWidth - pad * 2) / tabs.length;

  const activeW = Math.max(72, slotW - 12);
  const activeH = 60;
  const activeR = 26;

  const xPos = useSharedValue(activeIndex);
  useEffect(() => {
    xPos.value = withSpring(activeIndex, { damping: 18, stiffness: 160, mass: 0.85 });
  }, [activeIndex, xPos]);

  const activeStyle = useAnimatedStyle(() => {
    const x = pad + xPos.value * slotW + (slotW - activeW) / 2;
    return {
      transform: [{ translateX: x }],
      width: activeW,
      height: activeH,
    };
  });

  const shouldHideTab = () => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
    ];
    return hideRoutes.some((route) => pathname.includes(route));
  };
  if (shouldHideTab()) return null;

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!user?.id) return;

      try {
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
          return;
        }

        if (user.userType === 'organization' || user.userType === 'business') {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('avatar_url, profile_picture')
            .eq('id', user.id)
            .maybeSingle();

          if (!profileError && profileData) {
            const picUrl = (profileData as any).avatar_url || (profileData as any).profile_picture;
            if (picUrl) {
              setProfilePicture(picUrl);
              return;
            }
          }

          const { data: orgData, error: orgError } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.id)
            .maybeSingle();

          if (!orgError && orgData && (orgData as any).logo) {
            setProfilePicture((orgData as any).logo);
            return;
          }
        } else {
          const tableName = user.userType === 'valeter' ? 'valeter_profiles' : 'customer_profiles';
          const { data, error } = await supabase
            .from(tableName)
            .select('avatar_url, profile_picture')
            .eq('user_id', user.id)
            .maybeSingle();

          if (!error && data) {
            const picUrl = (data as any).avatar_url || (data as any).profile_picture;
            if (picUrl) setProfilePicture(picUrl);
          }
        }
      } catch (error) {
        console.error('[NavigationTab] Error loading profile picture:', error);
      }
    };

    loadProfilePicture();
  }, [user?.id, user?.profilePicture, user?.userType]);

  // ✅ Different glass styling for business (light UI)
  const blurTint = isBusinessRoute ? 'light' : Platform.OS === 'ios' ? 'default' : 'dark';
  const blurIntensity = Platform.OS === 'ios' ? (isBusinessRoute ? 70 : 85) : 22;

  const microFrostBg = isBusinessRoute ? 'rgba(255,255,255,0.40)' : 'rgba(255,255,255,0.03)';
  const strokeColor = isBusinessRoute ? 'rgba(15,23,42,0.10)' : 'rgba(255,255,255,0.10)';
  const topHighlight = isBusinessRoute ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.16)';

  const barShadowOpacity = isBusinessRoute ? 0.12 : 0.30;
  const barShadowRadius = isBusinessRoute ? 20 : 18;

  const capsuleBg = isBusinessRoute ? 'rgba(255,255,255,0.62)' : 'rgba(255,255,255,0.11)';

  return (
    <View pointerEvents="box-none" style={[styles.screenWrap, { paddingBottom: Math.max(insets.bottom, 10) }]}>
      <View
        style={[
          styles.bar,
          {
            width: barWidth,
            borderRadius: BAR_RADIUS,
            shadowOpacity: barShadowOpacity,
            shadowRadius: barShadowRadius,
          },
        ]}
      >
        <BlurView
          intensity={blurIntensity}
          tint={blurTint as any}
          experimentalBlurMethod="dimezisBlurView"
          style={StyleSheet.absoluteFill}
        />

        <View style={[styles.microFrost, { backgroundColor: microFrostBg }]} />
        <View style={[styles.glassHighlightTop, { backgroundColor: topHighlight }]} />
        <View style={[styles.glassStroke, { borderColor: strokeColor }]} />

        <Animated.View
          pointerEvents="none"
          style={[
            styles.activeCapsule,
            activeStyle,
            {
              borderRadius: activeR,
              borderColor: `${accent}55`,
              shadowColor: accent,
              backgroundColor: capsuleBg,
            },
          ]}
        />

        <View style={[styles.row, { paddingHorizontal: pad }]}>
          {tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const isProfile = isProfileTab(tab);
            const showProfilePic = isProfile && !!profilePicture;

            const handleTabPress = async () => {
              if (isProfile && isBusinessRoute) {
                await hapticFeedback('light');
                setShowProfileActions(true);
              } else {
                await hapticFeedback('light');
                router.push(tab.route as any);
              }
            };

            return (
              <TouchableOpacity
                key={tab.route}
                style={[styles.tab, { width: slotW }]}
                onPress={handleTabPress}
                activeOpacity={0.85}
              >
                {showProfilePic ? (
                  <View
                    style={[
                      styles.avatarWrap,
                      isActive && { borderColor: `${accent}80`, shadowColor: accent },
                      isBusinessRoute && { borderColor: 'rgba(15,23,42,0.16)', backgroundColor: 'rgba(255,255,255,0.55)' },
                    ]}
                  >
                    <Image source={{ uri: profilePicture as string }} style={styles.avatar} />
                  </View>
                ) : (
                  <Ionicons
                    name={isActive ? tab.icon : (`${tab.icon}-outline` as any)}
                    size={26}
                    color={isActive ? accent : inactiveIcon}
                    style={styles.icon}
                  />
                )}

                <Text
                  style={[
                    styles.label,
                    { color: isActive ? accent : inactiveLabel },
                    isActive && styles.labelActive,
                  ]}
                  numberOfLines={1}
                >
                  {tab.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <Modal
        visible={showProfileActions}
        transparent
        animationType="fade"
        onRequestClose={() => setShowProfileActions(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={[
              styles.actionSheet,
              isBusinessRoute && businessTheme && {
                backgroundColor: 'rgba(248,251,255,0.92)',
                borderColor: `${businessTheme.primary}33`,
              },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={[styles.actionSheetHeader, isBusinessRoute && { borderBottomColor: 'rgba(15,23,42,0.08)' }]}>
              <Text
                style={[
                  styles.actionSheetTitle,
                  isBusinessRoute && { color: 'rgba(15,23,42,0.92)' },
                ]}
              >
                Profile Options
              </Text>
              <TouchableOpacity onPress={() => setShowProfileActions(false)} style={styles.actionSheetClose}>
                <Ionicons name="close" size={22} color={accent} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/profile' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}14`, borderColor: `${accent}22` }]}>
                <Ionicons name="person" size={20} color={accent} />
              </View>
              <Text style={[styles.actionSheetItemText, isBusinessRoute && { color: 'rgba(15,23,42,0.92)' }]}>
                Business Profile
              </Text>
              <Ionicons name="chevron-forward" size={18} color={isBusinessRoute ? 'rgba(15,23,42,0.35)' : 'rgba(255,255,255,0.55)'} />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/settings' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}14`, borderColor: `${accent}22` }]}>
                <Ionicons name="settings" size={20} color={accent} />
              </View>
              <Text style={[styles.actionSheetItemText, isBusinessRoute && { color: 'rgba(15,23,42,0.92)' }]}>
                Settings
              </Text>
              <Ionicons name="chevron-forward" size={18} color={isBusinessRoute ? 'rgba(15,23,42,0.35)' : 'rgba(255,255,255,0.55)'} />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },

  bar: {
    height: TAB_BAR_HEIGHT,
    marginHorizontal: BAR_MARGIN_H,
    overflow: 'hidden',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.30,
    shadowRadius: 18,
    elevation: 24,
  },

  microFrost: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },

  glassHighlightTop: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.16)',
  },

  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    borderRadius: BAR_RADIUS,
  },

  activeCapsule: {
    position: 'absolute',
    left: 0,
    top: (TAB_BAR_HEIGHT - 60) / 2,
    backgroundColor: 'rgba(255,255,255,0.11)',
    borderWidth: 1,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 10,
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  tab: {
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },

  icon: {
    marginBottom: 6,
  },

  label: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.2,
  },

  labelActive: {
    fontWeight: '900',
  },

  avatarWrap: {
    width: 30,
    height: 30,
    borderRadius: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.16,
    shadowRadius: 14,
    elevation: 8,
  },

  avatar: {
    width: '100%',
    height: '100%',
    borderRadius: 15,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 16,
    paddingBottom: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    marginBottom: 8,
  },

  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
  },

  actionSheetClose: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    gap: 14,
  },

  actionSheetIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
  },
});
