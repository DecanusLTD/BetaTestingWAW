import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import GlassCard from '../src/components/booking/GlassCard';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function TermsOfService() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Terms of Service" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="document-text" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="checkmark-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>1. Acceptance of Terms</Text>
          </View>
          <Text style={styles.sectionText}>
            By using Wish a Wash, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use our service.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="car" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>2. Service Description</Text>
          </View>
          <Text style={styles.sectionText}>
            Wish a Wash connects customers with professional valeters for vehicle cleaning services. We facilitate bookings, payments, and communication between customers and service providers.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="people" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>3. User Responsibilities</Text>
          </View>
          <Text style={styles.sectionText}>
            You are responsible for:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Providing accurate information (vehicle details via DVLA integration)</Text>
            <Text style={styles.bulletPoint}>• Maintaining account security</Text>
            <Text style={styles.bulletPoint}>• Treating valeters and other users with respect</Text>
            <Text style={styles.bulletPoint}>• Being at least 18 years old to use our service</Text>
            <Text style={styles.bulletPoint}>• Ensuring your vehicle is accessible for service</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="card" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>4. Payment Terms</Text>
          </View>
          <Text style={styles.sectionText}>
            Payment is processed securely through our payment partners. Prices are displayed before booking confirmation. All payments are final unless cancelled according to our cancellation policy.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="close-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>5. Cancellation Policy</Text>
          </View>
          <Text style={styles.sectionText}>
            Cancellation terms:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Free cancellation up to 2 hours before scheduled time</Text>
            <Text style={styles.bulletPoint}>• Cancellations within 2 hours may incur charges</Text>
            <Text style={styles.bulletPoint}>• Valeter cancellations entitle you to a full refund</Text>
            <Text style={styles.bulletPoint}>• No-show charges may apply if valeter arrives and service cannot be performed</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>6. Limitation of Liability</Text>
          </View>
          <Text style={styles.sectionText}>
            Wish a Wash acts as an intermediary platform. We are not responsible for the quality of services provided by valeters, though we work to ensure high standards through our verification and rating systems.
          </Text>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  bulletList: {
    marginTop: 12,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
});



