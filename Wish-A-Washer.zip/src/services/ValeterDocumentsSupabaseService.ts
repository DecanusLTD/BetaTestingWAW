// src/services/ValeterDocumentsSupabaseService.ts

import { supabase } from '../lib/supabase';
import * as FileSystem from 'expo-file-system/legacy';
import { Buffer } from 'buffer';

export type VerificationStatus = 'pending' | 'approved' | 'rejected';

export interface UploadedDocument {
  id: string;
  userId: string;
  docTypeId: string; // DB: type
  name: string; // DB: name
  uri: string; // DB: file_url (public)
  type: 'photo';
  uploadDate: Date;
  verificationStatus: VerificationStatus;
  description?: string | null;
  rejectionReason?: string | null;
  approvedAt?: Date | null;
}

type DbRow = {
  id: string;
  user_id: string;
  type: string;
  name: string;
  description: string | null;
  status: VerificationStatus;
  file_url: string | null;
  uploaded_at: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
};

const TABLE = 'valeter_documents';
const BUCKET = 'valeter-documents';

function safeDate(v: string | null | undefined): Date {
  const d = new Date(v ?? Date.now());
  return isNaN(d.getTime()) ? new Date() : d;
}

function mapRow(row: DbRow): UploadedDocument {
  return {
    id: row.id,
    userId: row.user_id,
    docTypeId: row.type,
    name: row.name,
    uri: row.file_url ?? '',
    type: 'photo',
    uploadDate: safeDate(row.uploaded_at ?? row.created_at),
    verificationStatus: row.status ?? 'pending',
    description: row.description,
    rejectionReason: row.rejection_reason,
    approvedAt: row.approved_at ? safeDate(row.approved_at) : null,
  };
}

function extractStoragePathFromPublicUrl(fileUrl: string, bucket: string): string | null {
  try {
    const marker = `/storage/v1/object/public/${bucket}/`;
    const idx = fileUrl.indexOf(marker);
    if (idx === -1) return null;
    return fileUrl.substring(idx + marker.length);
  } catch {
    return null;
  }
}

/**
 * Normalize weird URIs your camera service might return.
 * We need something readable by expo-file-system:
 *  - file://...
 *  - content://...
 *
 * If we receive "/photo/abc.jpg", we try to map it into documentDirectory/cacheDirectory.
 */
function normalizeLocalUri(input: string): string {
  if (!input) return input;

  // already good
  if (
    input.startsWith('file://') ||
    input.startsWith('content://') ||
    input.startsWith('ph://')
  ) {
    return input;
  }

  // Some libs return "/photo/xyz.jpg" or "photo/xyz.jpg"
  const trimmed = input.replace(/^\/+/, ''); // remove leading slashes
  const docDir = FileSystem.documentDirectory ?? '';
  const cacheDir = FileSystem.cacheDirectory ?? '';

  // Prefer doc dir mapping first
  if (docDir) return `${docDir}${trimmed}`;
  if (cacheDir) return `${cacheDir}${trimmed}`;

  return input;
}

/**
 * Convert local image URI -> ArrayBuffer using expo-file-system legacy API.
 */
async function uriToArrayBuffer(localUri: string): Promise<ArrayBuffer> {
  let uri = normalizeLocalUri(localUri);

  // Android content:// needs copy into cache first
  if (uri.startsWith('content://')) {
    const cacheDir = FileSystem.cacheDirectory ?? FileSystem.documentDirectory ?? '';
    if (!cacheDir) throw new Error('No cache/document directory available on this device');

    const dest = `${cacheDir}valeter_${Date.now()}.jpg`;
    await FileSystem.copyAsync({ from: uri, to: dest });
    uri = dest;
  }

  // ph:// not supported by legacy readAsStringAsync
  if (uri.startsWith('ph://')) {
    throw new Error('Unsupported photo URI (ph://). Adjust camera to return file:// uri.');
  }

  // sanity: check file exists and is readable
  try {
    const info = await FileSystem.getInfoAsync(uri);
    if (!info.exists) {
      throw new Error(`Local file does not exist: ${uri}`);
    }
  } catch (e) {
    // getInfoAsync can fail on weird paths; carry on to get the real error below
  }

  // Read base64
  let base64: string;
  try {
    base64 = await FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
  } catch (e: any) {
    // If normalize mapped to documentDirectory but file actually lives in cacheDirectory, try the other.
    const original = localUri.replace(/^\/+/, '');
    const docDir = FileSystem.documentDirectory ?? '';
    const cacheDir = FileSystem.cacheDirectory ?? '';

    const altCandidates: string[] = [];
    if (docDir) altCandidates.push(`${docDir}${original}`);
    if (cacheDir) altCandidates.push(`${cacheDir}${original}`);

    // try alt candidates that differ from current uri
    for (const alt of altCandidates.filter((x) => x && x !== uri)) {
      try {
        const info = await FileSystem.getInfoAsync(alt);
        if (!info.exists) continue;
        base64 = await FileSystem.readAsStringAsync(alt, { encoding: 'base64' as any });
        const bufAlt = Buffer.from(base64, 'base64');
        return bufAlt.buffer.slice(bufAlt.byteOffset, bufAlt.byteOffset + bufAlt.byteLength);
      } catch {
        // continue trying
      }
    }

    // Final: throw a clean message
    throw new Error(
      `Photo file is not readable.\n` +
        `Received uri: ${localUri}\n` +
        `Tried: ${uri}\n` +
        `Make sure your camera returns a 'file://' uri (Expo Camera / ImagePicker usually does).`
    );
  }

  const buf = Buffer.from(base64, 'base64');
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

export const valeterDocumentsSupabaseService = {
  async listUserDocuments(userId: string): Promise<UploadedDocument[]> {
    const { data, error } = await supabase
      .from(TABLE)
      .select(
        'id,user_id,type,name,description,status,file_url,uploaded_at,approved_at,rejection_reason,created_at,updated_at'
      )
      .eq('user_id', userId)
      .order('uploaded_at', { ascending: false, nullsFirst: false });

    if (error) throw error;

    const rows = (data ?? []) as DbRow[];
    return rows.map(mapRow);
  },

  async uploadPhotoDocument(params: {
    userId: string;
    docTypeId: string;
    docName: string;
    description?: string;
    localUri: string;
  }): Promise<void> {
    const { userId, docTypeId, docName, description, localUri } = params;

    const arrayBuffer = await uriToArrayBuffer(localUri);

    const safeDocType = docTypeId.replace(/[^\w.\-]+/g, '_');
    const storagePath = `${userId}/${safeDocType}/${Date.now()}.jpg`;

    const { error: uploadError } = await supabase.storage.from(BUCKET).upload(storagePath, arrayBuffer, {
      contentType: 'image/jpeg',
      upsert: false,
    });
    if (uploadError) throw uploadError;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(storagePath);
    const fileUrl = pub?.publicUrl ?? null;
    if (!fileUrl) throw new Error('Failed to generate public URL for uploaded image');

    const { data: existing, error: findErr } = await supabase
      .from(TABLE)
      .select('id,file_url')
      .eq('user_id', userId)
      .eq('type', docTypeId)
      .maybeSingle();

    if (findErr) {
      console.warn('[ValeterDocs] Could not check existing row:', findErr);
    }

    const nowIso = new Date().toISOString();

    if (existing?.id) {
      const { error: updateErr } = await supabase
        .from(TABLE)
        .update({
          name: docName,
          description: description ?? null,
          status: 'pending',
          file_url: fileUrl,
          uploaded_at: nowIso,
          rejection_reason: null,
          approved_at: null,
          approved_by: null,
        } as any)
        .eq('id', existing.id);

      if (updateErr) throw updateErr;

      const oldPath = existing.file_url ? extractStoragePathFromPublicUrl(existing.file_url, BUCKET) : null;
      if (oldPath) {
        const { error: removeErr } = await supabase.storage.from(BUCKET).remove([oldPath]);
        if (removeErr) console.warn('[ValeterDocs] Failed to remove old file:', removeErr);
      }

      return;
    }

    const { error: insertErr } = await supabase.from(TABLE).insert({
      user_id: userId,
      type: docTypeId,
      name: docName,
      description: description ?? null,
      status: 'pending',
      file_url: fileUrl,
      uploaded_at: nowIso,
    } as any);

    if (insertErr) throw insertErr;
  },

  async deleteDocument(docId: string): Promise<void> {
    const { data, error } = await supabase.from(TABLE).select('file_url').eq('id', docId).single();
    if (error) throw error;

    const fileUrl = (data as { file_url: string | null }).file_url;

    const { error: delRowError } = await supabase.from(TABLE).delete().eq('id', docId);
    if (delRowError) throw delRowError;

    if (fileUrl) {
      const path = extractStoragePathFromPublicUrl(fileUrl, BUCKET);
      if (path) {
        const { error: delFileError } = await supabase.storage.from(BUCKET).remove([path]);
        if (delFileError) console.warn('[ValeterDocs] Storage delete failed:', delFileError);
      }
    }
  },

  subscribeToUserDocuments(userId: string, onChange: () => void) {
    const channel = supabase
      .channel(`valeter_docs_${userId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: TABLE, filter: `user_id=eq.${userId}` },
        () => onChange()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};
