import React, { useState, useEffect } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { PerformanceService } from '../services/PerformanceService';

export interface OfflineState {
  isOnline: boolean;
  isOffline: boolean;
  connectionType: string | null;
  isReconnecting: boolean;
}

/**
 * Hook for managing offline mode and network state
 */
export function useOfflineMode() {
  const [offlineState, setOfflineState] = useState<OfflineState>({
    isOnline: true,
    isOffline: false,
    connectionType: null,
    isReconnecting: false,
  });

  useEffect(() => {
    // Initialize cache
    PerformanceService.initializeCache();

    // Subscribe to network state changes
    const unsubscribe = NetInfo.addEventListener((state) => {
      const isOnline = state.isConnected ?? false;
      const wasOffline = offlineState.isOffline;

      setOfflineState({
        isOnline,
        isOffline: !isOnline,
        connectionType: state.type,
        isReconnecting: wasOffline && isOnline,
      });

      // Clear expired cache when coming back online
      if (wasOffline && isOnline) {
        PerformanceService.clearExpiredCache();
      }
    });

    // Get initial network state
    NetInfo.fetch().then((state) => {
      setOfflineState({
        isOnline: state.isConnected ?? false,
        isOffline: !(state.isConnected ?? false),
        connectionType: state.type,
        isReconnecting: false,
      });
    });

    return () => {
      unsubscribe();
    };
  }, []);

  return offlineState;
}

/**
 * Hook for offline-first data fetching
 */
export function useOfflineData<T>(
  fetchFn: () => Promise<T>,
  cacheKey: string,
  options: {
    enabled?: boolean;
    staleTime?: number;
    cacheTime?: number;
  } = {}
) {
  const { enabled = true, staleTime = 5 * 60 * 1000, cacheTime = 24 * 60 * 60 * 1000 } = options;
  const { isOnline } = useOfflineMode();
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const loadData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Try to get from cache first
        const cachedData = await PerformanceService.getCachedData<T>(cacheKey);
        if (cachedData) {
          setData(cachedData);
          setLoading(false);
        }

        // Fetch fresh data if online
        if (isOnline) {
          try {
            const freshData = await fetchFn();
            setData(freshData);
            await PerformanceService.cacheData(cacheKey, freshData, cacheTime);
          } catch (fetchError) {
            // If fetch fails but we have cached data, use that
            if (!cachedData) {
              throw fetchError;
            }
          }
        } else if (!cachedData) {
          throw new Error('No internet connection and no cached data available');
        }
      } catch (err) {
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [enabled, isOnline, cacheKey, staleTime, cacheTime]);

  const refetch = async () => {
    if (!isOnline) {
      throw new Error('Cannot refetch while offline');
    }
    try {
      setLoading(true);
      const freshData = await fetchFn();
      setData(freshData);
      await PerformanceService.cacheData(cacheKey, freshData, cacheTime);
    } catch (err) {
      setError(err as Error);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { data, loading, error, refetch };
}

