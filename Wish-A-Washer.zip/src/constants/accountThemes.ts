import { customerTheme } from './customerTheme';
import { colors } from './colors';

export type AccountType = 'customer' | 'valeter' | 'business';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
}

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: '#87CEEB',
    primaryAlt: '#5BA3C7',
    background: customerTheme.backgroundGradient,
    headerBackground: ['rgba(30,58,138,0.35)', 'rgba(30,58,138,0.25)'],
    glassBorder: 'rgba(135,206,235,0.3)',
    accent: '#87CEEB',
    accentAlt: '#5BA3C7',
  },

  valeter: {
    primary: '#10B981',
    primaryAlt: '#F59E0B',
    background: ['#0A1929', '#1E3A8A'],
    glassBorder: 'rgba(16,185,129,0.3)',
    glassBorderAlt: 'rgba(245,158,11,0.3)',
    accent: '#10B981',
    accentAlt: '#F59E0B',
  },

  business: {
    primary: '#87CEEB',
        primaryAlt: '#5BA3C7',
        background: customerTheme.backgroundGradient,
        headerBackground: ['rgba(30,58,138,0.35)', 'rgba(30,58,138,0.25)'],
        glassBorder: 'rgba(135,206,235,0.3)',
        accent: '#87CEEB',
        accentAlt: '#5BA3C7',
  },
};

export const getAccountTheme = (accountType: AccountType): AccountTheme => {
  return accountThemes[accountType];
};
