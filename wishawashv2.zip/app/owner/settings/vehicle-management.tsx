// app/owner/settings/vehicle-management.tsx

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import dvlaService from '../../../src/services/DVLAService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;

  mot_status?: string | null;
  mot_expiry_date?: string | null; // YYYY-MM-DD
  tax_status?: string | null;
  tax_due_date?: string | null; // YYYY-MM-DD
  dvla_last_checked_at?: string | null;

  // assumes you added these in Supabase (you said you did the Supabase part)
  image_url?: string | null;
  image_path?: string | null;
};

type AddMode = 'reg' | 'manual';

function pickFirstString(obj: any, keys: string[]) {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }
  return '';
}

function normaliseToDateOnly(input: any) {
  if (!input) return '';
  const s = String(input).trim();
  if (!s) return '';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function formatDatePretty(dateOnly: string | null | undefined) {
  if (!dateOnly) return '—';
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function cleanReg(input: string) {
  return input.replace(/\s/g, '').toUpperCase();
}

function badgeToneFromStatus(status?: string | null) {
  const s = String(status || '').toLowerCase();
  if (!s) return 'neutral';
  if (s.includes('valid') || s.includes('taxed') || s.includes('in force') || s.includes('yes')) return 'good';
  if (s.includes('no') || s.includes('expired') || s.includes('sorn') || s.includes('not')) return 'bad';
  return 'neutral';
}

function base64ToUint8Array(base64: string) {
  // atob exists in RN/Expo runtime
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export default function VehicleManagement() {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  const [showModal, setShowModal] = useState(false);
  const [addMode, setAddMode] = useState<AddMode>('reg');

  const [editingVehicleId, setEditingVehicleId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    type: '',
    make: '',
    model: '',
    color: '',
    registration: '',

    mot_status: '',
    mot_expiry_date: '',
    tax_status: '',
    tax_due_date: '',

    image_url: '',
    image_path: '',
  });

  const [dvlaLoading, setDvlaLoading] = useState(false);
  const [dvlaTouched, setDvlaTouched] = useState(false);

  const [busyId, setBusyId] = useState<string | null>(null); // delete/default actions
  const [uploadingImage, setUploadingImage] = useState(false);

  const lookupTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const resetForm = () => {
    setFormData({
      type: '',
      make: '',
      model: '',
      color: '',
      registration: '',

      mot_status: '',
      mot_expiry_date: '',
      tax_status: '',
      tax_due_date: '',

      image_url: '',
      image_path: '',
    });
    setDvlaLoading(false);
    setDvlaTouched(false);
    setAddMode('reg');
    setEditingVehicleId(null);
    setUploadingImage(false);

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }
  };

  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };

  const openEditModal = (vehicle: Vehicle) => {
    if (busyId) return;
    setEditingVehicleId(vehicle.id);

    setFormData({
      type: vehicle.type || 'Car',
      make: vehicle.make || '',
      model: vehicle.model || '',
      color: vehicle.color || '',
      registration: vehicle.registration || '',

      mot_status: vehicle.mot_status || '',
      mot_expiry_date: vehicle.mot_expiry_date || '',
      tax_status: vehicle.tax_status || '',
      tax_due_date: vehicle.tax_due_date || '',

      image_url: vehicle.image_url || '',
      image_path: vehicle.image_path || '',
    });

    // editing: usually manual unless they want DVLA refresh
    setAddMode('manual');
    setDvlaTouched(false);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    resetForm();
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles((data || []) as Vehicle[]);
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    return () => {
      if (lookupTimeoutRef.current) clearTimeout(lookupTimeoutRef.current);
    };
  }, []);

  const doDvlaLookup = async (registration: string) => {
    const reg = cleanReg(registration);
    const validation = dvlaService.validateRegistration(reg);
    if (!validation.isValid) return;

    setDvlaLoading(true);
    try {
      const result = await dvlaService.getVehicleDetails(reg);

      if (result?.success && result?.data) {
        const data = result.data;

        const vehicleType = dvlaService.inferVehicleType(data.make, data.model || '');

        const motStatus = pickFirstString(data, ['motStatus', 'mot_status']);
        const taxStatus = pickFirstString(data, ['taxStatus', 'tax_status']);

        const motExpiry = normaliseToDateOnly(
          pickFirstString(data, ['motExpiryDate', 'motExpiry', 'mot_expiry_date', 'motExpiryDateString'])
        );
        const taxDue = normaliseToDateOnly(
          pickFirstString(data, ['taxDueDate', 'taxDue', 'tax_due_date', 'taxDueDateString'])
        );

        setFormData((prev) => ({
          ...prev,
          registration: data.registrationNumber ? cleanReg(data.registrationNumber) : reg,
          make: data.make || prev.make,
          model: data.model || prev.model,
          color: data.colour || prev.color,
          type: vehicleType || prev.type || 'Car',

          mot_status: motStatus || prev.mot_status,
          mot_expiry_date: motExpiry || prev.mot_expiry_date,
          tax_status: taxStatus || prev.tax_status,
          tax_due_date: taxDue || prev.tax_due_date,
        }));

        setDvlaTouched(true);
      } else {
        if (result?.error && !String(result.error).toLowerCase().includes('mock')) {
          console.warn('[VehicleManagement] DVLA lookup failed:', result.error);
        }
      }
    } catch (error: any) {
      console.error('[VehicleManagement] DVLA lookup error:', error);
    } finally {
      setDvlaLoading(false);
    }
  };

  const handleRegistrationChange = async (registration: string) => {
    const reg = cleanReg(registration);

    setFormData((prev) => ({
      ...prev,
      registration: reg,
    }));

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }

    // Only auto-lookup in reg mode
    if (addMode !== 'reg') return;

    lookupTimeoutRef.current = setTimeout(async () => {
      await doDvlaLookup(reg);
    }, 900);
  };

  const uploadVehicleImage = async (uri: string) => {
    if (!user?.id) throw new Error('Not signed in');

    const bucket = 'vehicle-images';

    // Read file -> base64 -> bytes (reliable in RN)
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const bytes = base64ToUint8Array(base64);

    const extGuess = uri.split('.').pop()?.toLowerCase();
    const ext = extGuess && extGuess.length <= 5 ? extGuess : 'jpg';

    const contentType =
      ext === 'png'
        ? 'image/png'
        : ext === 'webp'
        ? 'image/webp'
        : ext === 'heic'
        ? 'image/heic'
        : 'image/jpeg';

    const fileName = `${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`;
    const path = `${user.id}/${fileName}`;

    const { error: upErr } = await supabase.storage.from(bucket).upload(path, bytes, {
      contentType,
      upsert: false,
    });
    if (upErr) throw upErr;

    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    const publicUrl = data?.publicUrl || '';

    return { publicUrl, path };
  };

  const pickAndUploadImage = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo access to upload a car picture.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaType.Images, // ✅ new API (no deprecation)
        quality: 0.9,
        allowsEditing: true,
        aspect: [4, 3],
      });

      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (!asset?.uri) return;

      setUploadingImage(true);
      const { publicUrl, path } = await uploadVehicleImage(asset.uri);

      setFormData((p) => ({
        ...p,
        image_url: publicUrl,
        image_path: path,
      }));
    } catch (e: any) {
      console.error('[VehicleManagement] image upload failed', e);
      Alert.alert('Upload failed', e?.message || 'Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const removeImageFromForm = async () => {
    Alert.alert('Remove picture?', 'This will remove the picture from this vehicle.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          setFormData((p) => ({ ...p, image_url: '', image_path: '' }));
        },
      },
    ]);
  };

  const handleSaveVehicle = async () => {
    if (!user?.id) return;

    const reg = cleanReg(formData.registration);
    if (!reg) {
      Alert.alert('Error', 'Registration is required (or switch to Manual entry and add details).');
      return;
    }

    const make = (formData.make || '').trim();
    const model = (formData.model || '').trim();
    if (!make || !model) {
      Alert.alert('Error', 'Please fill in Make and Model.');
      return;
    }

    try {
      await hapticFeedback('medium');

      const payload: any = {
        type: formData.type || 'Car',
        make,
        model,
        color: (formData.color || '').trim(),
        registration: reg,

        mot_status: formData.mot_status || null,
        mot_expiry_date: formData.mot_expiry_date || null,
        tax_status: formData.tax_status || null,
        tax_due_date: formData.tax_due_date || null,
        dvla_last_checked_at: dvlaTouched ? new Date().toISOString() : null,

        image_url: formData.image_url || null,
        image_path: formData.image_path || null,
      };

      if (editingVehicleId) {
        const { error } = await supabase
          .from('customer_vehicles')
          .update(payload)
          .eq('user_id', user.id)
          .eq('id', editingVehicleId);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('customer_vehicles').insert({
          user_id: user.id,
          ...payload,
          is_default: vehicles.length === 0,
        });

        if (error) throw error;
      }

      setShowModal(false);
      resetForm();
      await loadVehicles();
    } catch (error: any) {
      console.error('[VehicleManagement] save failed', error);
      Alert.alert('Error', error?.message || 'Failed to save vehicle');
    }
  };

  const setDefaultVehicle = async (vehicleId: string) => {
    if (!user?.id) return;
    if (busyId) return;

    setBusyId(vehicleId);
    try {
      await hapticFeedback('light');

      const { error: clearErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: false })
        .eq('user_id', user.id)
        .eq('is_default', true);

      if (clearErr) throw clearErr;

      const { error: setErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: true })
        .eq('user_id', user.id)
        .eq('id', vehicleId);

      if (setErr) throw setErr;

      setVehicles((prev) => prev.map((v) => ({ ...v, is_default: v.id === vehicleId })));
    } catch (e: any) {
      console.error('[VehicleManagement] set default failed', e);
      Alert.alert('Error', e?.message || 'Failed to set default vehicle');
    } finally {
      setBusyId(null);
    }
  };

  const deleteVehicle = async (vehicle: Vehicle) => {
    if (!user?.id) return;
    if (busyId) return;

    const isOnlyVehicle = vehicles.length === 1;
    const isDefault = !!vehicle.is_default;

    const doDelete = async () => {
      setBusyId(vehicle.id);
      try {
        await hapticFeedback('medium');

        const { error } = await supabase.from('customer_vehicles').delete().eq('user_id', user.id).eq('id', vehicle.id);
        if (error) throw error;

        setVehicles((prev) => prev.filter((v) => v.id !== vehicle.id));

        if (isDefault && !isOnlyVehicle) {
          setTimeout(async () => {
            const remaining = vehicles.filter((v) => v.id !== vehicle.id);
            const next = remaining[0];
            if (next) await setDefaultVehicle(next.id);
          }, 0);
        }
      } catch (e: any) {
        console.error('[VehicleManagement] delete failed', e);
        Alert.alert('Error', e?.message || 'Failed to delete vehicle');
      } finally {
        setBusyId(null);
      }
    };

    Alert.alert('Delete vehicle?', `This will remove ${vehicle.registration} from your account.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: doDelete },
    ]);
  };

  const MotPill = ({ v }: { v: Vehicle }) => {
    const tone = badgeToneFromStatus(v.mot_status);
    return (
      <View style={[styles.pill, tone === 'good' ? styles.pillGood : tone === 'bad' ? styles.pillBad : styles.pillNeutral]}>
        <Ionicons name="shield-checkmark-outline" size={14} color={SKY} />
        <Text style={styles.pillText}>
          MOT: {v.mot_status ? v.mot_status : '—'}
          {v.mot_expiry_date ? ` • ${formatDatePretty(v.mot_expiry_date)}` : ''}
        </Text>
      </View>
    );
  };

  const TaxPill = ({ v }: { v: Vehicle }) => {
    const tone = badgeToneFromStatus(v.tax_status);
    return (
      <View style={[styles.pill, tone === 'good' ? styles.pillGood : tone === 'bad' ? styles.pillBad : styles.pillNeutral]}>
        <Ionicons name="receipt-outline" size={14} color={SKY} />
        <Text style={styles.pillText}>
          TAX: {v.tax_status ? v.tax_status : '—'}
          {v.tax_due_date ? ` • ${formatDatePretty(v.tax_due_date)}` : ''}
        </Text>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="My Vehicles"
        rightAction={
          <TouchableOpacity onPress={openAddModal} style={styles.addButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {vehicles.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="car-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Vehicles</Text>
            <Text style={styles.emptySubtitle}>Add your first vehicle to get started</Text>

            <TouchableOpacity style={styles.addButtonCard} onPress={openAddModal} activeOpacity={0.85}>
              <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.addButtonGradient}>
                <Ionicons name="add" size={20} color={BG} />
                <Text style={styles.addButtonText}>Add Vehicle</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          vehicles.map((vehicle) => {
            const isBusy = busyId === vehicle.id;

            return (
              <View key={vehicle.id} style={styles.vehicleCard}>
                <View style={styles.vehicleIconWrapper}>
                  {vehicle.image_url ? (
                    <Image source={{ uri: vehicle.image_url }} style={styles.vehicleImage} />
                  ) : (
                    <Ionicons name="car" size={28} color={SKY} />
                  )}
                </View>

                <View style={styles.vehicleContent}>
                  <View style={styles.vehicleHeader}>
                    <Text style={styles.vehicleName} numberOfLines={1}>
                      {vehicle.make} {vehicle.model}
                    </Text>

                    {/* Edit */}
                    <TouchableOpacity
                      onPress={() => openEditModal(vehicle)}
                      disabled={!!busyId}
                      activeOpacity={0.85}
                      style={[styles.editPill, !!busyId && { opacity: 0.6 }]}
                    >
                      <Ionicons name="create-outline" size={16} color={SKY} />
                    </TouchableOpacity>

                    {/* Default */}
                    {vehicle.is_default ? (
                      <View style={styles.defaultBadge}>
                        <Ionicons name="star" size={12} color="#10B981" />
                        <Text style={styles.defaultText}>Default</Text>
                      </View>
                    ) : (
                      <TouchableOpacity
                        onPress={() => setDefaultVehicle(vehicle.id)}
                        disabled={!!busyId}
                        activeOpacity={0.85}
                        style={[styles.actionPill, !!busyId && { opacity: 0.6 }]}
                      >
                        {isBusy ? (
                          <ActivityIndicator size="small" color={SKY} />
                        ) : (
                          <>
                            <Ionicons name="star-outline" size={14} color={SKY} />
                            <Text style={styles.actionPillText}>Set default</Text>
                          </>
                        )}
                      </TouchableOpacity>
                    )}

                    {/* Delete */}
                    <TouchableOpacity
                      onPress={() => deleteVehicle(vehicle)}
                      disabled={!!busyId}
                      activeOpacity={0.85}
                      style={[styles.deletePill, !!busyId && { opacity: 0.6 }]}
                    >
                      {isBusy ? (
                        <ActivityIndicator size="small" color="#FCA5A5" />
                      ) : (
                        <Ionicons name="trash-outline" size={16} color="#FCA5A5" />
                      )}
                    </TouchableOpacity>
                  </View>

                  <Text style={styles.vehicleReg}>{vehicle.registration}</Text>

                  <Text style={styles.vehicleMeta}>
                    {vehicle.type}
                    {vehicle.color ? ` • ${vehicle.color}` : ''}
                  </Text>

                  <View style={styles.pillRow}>
                    <MotPill v={vehicle} />
                    <TaxPill v={vehicle} />
                  </View>

                  {!!vehicle.dvla_last_checked_at && (
                    <Text style={styles.dvlaChecked}>
                      DVLA checked:{' '}
                      {new Date(vehicle.dvla_last_checked_at).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </Text>
                  )}
                </View>
              </View>
            );
          })
        )}
      </ScrollView>

      {/* Add/Edit Vehicle Modal */}
      <Modal visible={showModal} animationType="slide" transparent onRequestClose={closeModal}>
        <View style={styles.modalOverlay}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{editingVehicleId ? 'Edit Vehicle' : 'Add Vehicle'}</Text>
                <TouchableOpacity onPress={closeModal}>
                  <Ionicons name="close" size={24} color="#F9FAFB" />
                </TouchableOpacity>
              </View>

              {/* Mode switch (only really relevant when adding) */}
              {!editingVehicleId && (
                <View style={styles.modeRow}>
                  <Pressable onPress={() => setAddMode('reg')} style={[styles.modePill, addMode === 'reg' && styles.modePillActive]}>
                    <Ionicons name="search" size={16} color={addMode === 'reg' ? BG : SKY} />
                    <Text style={[styles.modeText, addMode === 'reg' && styles.modeTextActive]}>Add with reg</Text>
                  </Pressable>

                  <Pressable onPress={() => setAddMode('manual')} style={[styles.modePill, addMode === 'manual' && styles.modePillActive]}>
                    <Ionicons name="create-outline" size={16} color={addMode === 'manual' ? BG : SKY} />
                    <Text style={[styles.modeText, addMode === 'manual' && styles.modeTextActive]}>Manual entry</Text>
                  </Pressable>
                </View>
              )}

              <ScrollView style={styles.modalBody} showsVerticalScrollIndicator={false}>
                {/* Picture */}
                <View style={styles.imageRow}>
                  <View style={styles.imagePreviewWrap}>
                    {formData.image_url ? (
                      <Image source={{ uri: formData.image_url }} style={styles.imagePreview} />
                    ) : (
                      <View style={styles.imagePlaceholder}>
                        <Ionicons name="image-outline" size={22} color="rgba(249,250,251,0.55)" />
                        <Text style={styles.imagePlaceholderText}>Add picture</Text>
                      </View>
                    )}
                  </View>

                  <View style={{ flex: 1, gap: 10 }}>
                    <TouchableOpacity
                      onPress={pickAndUploadImage}
                      disabled={uploadingImage}
                      activeOpacity={0.85}
                      style={[styles.imageBtn, uploadingImage && { opacity: 0.7 }]}
                    >
                      {uploadingImage ? (
                        <ActivityIndicator size="small" color={SKY} />
                      ) : (
                        <>
                          <Ionicons name="cloud-upload-outline" size={16} color={SKY} />
                          <Text style={styles.imageBtnText}>{formData.image_url ? 'Change picture' : 'Upload picture'}</Text>
                        </>
                      )}
                    </TouchableOpacity>

                    {!!formData.image_url && (
                      <TouchableOpacity onPress={removeImageFromForm} activeOpacity={0.85} style={styles.imageBtnDanger}>
                        <Ionicons name="trash-outline" size={16} color="#FCA5A5" />
                        <Text style={styles.imageBtnDangerText}>Remove</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>

                {/* Registration */}
                <View style={styles.inputGroup}>
                  <View style={styles.inputLabelRow}>
                    <Text style={styles.inputLabel}>Registration *</Text>
                    {dvlaLoading && (
                      <View style={styles.lookupIndicator}>
                        <ActivityIndicator size="small" color={SKY} />
                        <Text style={styles.lookupText}>Looking up…</Text>
                      </View>
                    )}
                  </View>

                  <TextInput
                    style={styles.input}
                    value={formData.registration}
                    onChangeText={handleRegistrationChange}
                    placeholder="Enter UK reg (e.g., AB12CDE)"
                    placeholderTextColor="rgba(249,250,251,0.45)"
                    autoCapitalize="characters"
                    editable={!dvlaLoading}
                  />

                  {addMode === 'reg' && !editingVehicleId ? (
                    <Text style={styles.inputHint}>Enter your reg and we’ll pull Make/Model/Colour + MOT/TAX from DVLA (when available).</Text>
                  ) : (
                    <Text style={styles.inputHint}>You can still refresh DVLA below any time.</Text>
                  )}
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Make *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.make}
                    onChangeText={(text) => setFormData((p) => ({ ...p, make: text }))}
                    placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA lookup' : 'e.g. Ford'}
                    placeholderTextColor="rgba(249,250,251,0.45)"
                    editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Model *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.model}
                    onChangeText={(text) => setFormData((p) => ({ ...p, model: text }))}
                    placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA lookup' : 'e.g. Fiesta'}
                    placeholderTextColor="rgba(249,250,251,0.45)"
                    editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Colour</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.color}
                    onChangeText={(text) => setFormData((p) => ({ ...p, color: text }))}
                    placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA lookup' : 'e.g. Blue'}
                    placeholderTextColor="rgba(249,250,251,0.45)"
                    editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                  />
                </View>

                {/* DVLA preview + refresh */}
                <View style={styles.dvlaRow}>
                  <View style={styles.dvlaBadge}>
                    <Ionicons name="shield-checkmark" size={14} color={SKY} />
                    <Text style={styles.dvlaBadgeText}>DVLA</Text>
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={styles.dvlaMiniText}>
                      MOT: {formData.mot_status ? formData.mot_status : '—'}
                      {formData.mot_expiry_date ? ` • ${formatDatePretty(formData.mot_expiry_date)}` : ''}
                    </Text>
                    <Text style={styles.dvlaMiniText}>
                      TAX: {formData.tax_status ? formData.tax_status : '—'}
                      {formData.tax_due_date ? ` • ${formatDatePretty(formData.tax_due_date)}` : ''}
                    </Text>
                  </View>

                  <TouchableOpacity
                    onPress={async () => {
                      const reg = cleanReg(formData.registration);
                      if (!reg) {
                        Alert.alert('Missing reg', 'Enter a registration first.');
                        return;
                      }
                      await doDvlaLookup(reg);
                    }}
                    style={styles.refreshPill}
                    activeOpacity={0.85}
                    disabled={dvlaLoading}
                  >
                    {dvlaLoading ? (
                      <ActivityIndicator size="small" color={SKY} />
                    ) : (
                      <>
                        <Ionicons name="refresh" size={16} color={SKY} />
                        <Text style={styles.refreshText}>Refresh</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>

                <TouchableOpacity style={styles.saveButton} onPress={handleSaveVehicle} activeOpacity={0.9} disabled={uploadingImage}>
                  <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveButtonGradient}>
                    <Text style={styles.saveButtonText}>{editingVehicleId ? 'Save Changes' : 'Save Vehicle'}</Text>
                  </LinearGradient>
                </TouchableOpacity>

                <View style={{ height: 18 }} />
              </ScrollView>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },

  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },

  emptyContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60 },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: { color: '#87CEEB', fontSize: 14, textAlign: 'center', marginBottom: 24 },

  addButtonCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  addButtonGradient: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 24, gap: 8 },
  addButtonText: { color: BG, fontSize: 16, fontWeight: '700' },

  vehicleCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },

  vehicleIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  vehicleImage: { width: 56, height: 56, resizeMode: 'cover' },

  vehicleContent: { flex: 1 },

  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 8,
  },

  vehicleName: { color: '#F9FAFB', fontSize: isSmallScreen ? 16 : 18, fontWeight: '700', flex: 1 },

  editPill: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },

  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.18)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.35)',
  },
  defaultText: { color: '#10B981', fontSize: 11, fontWeight: '900' },

  actionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  actionPillText: { color: SKY, fontSize: 12, fontWeight: '900' },

  deletePill: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(252,165,165,0.35)',
    backgroundColor: 'rgba(239,68,68,0.10)',
  },

  vehicleReg: { color: SKY, fontSize: 14, fontWeight: '800', marginBottom: 4 },
  vehicleMeta: { color: 'rgba(249,250,251,0.75)', fontSize: 13 },

  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },

  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  pillGood: { borderColor: 'rgba(16,185,129,0.35)', backgroundColor: 'rgba(16,185,129,0.10)' },
  pillBad: { borderColor: 'rgba(239,68,68,0.35)', backgroundColor: 'rgba(239,68,68,0.10)' },
  pillNeutral: {},

  pillText: { color: 'rgba(249,250,251,0.80)', fontSize: 12, fontWeight: '800' },

  dvlaChecked: { marginTop: 8, color: 'rgba(249,250,251,0.55)', fontSize: 11, fontWeight: '700' },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalContent: {
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 20,
    maxHeight: '92%',
  },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 12 },
  modalTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },

  modeRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, paddingBottom: 12 },
  modePill: {
    flex: 1,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  modePillActive: { backgroundColor: SKY, borderColor: 'rgba(135,206,235,0.40)' },
  modeText: { color: SKY, fontWeight: '900', fontSize: 13 },
  modeTextActive: { color: BG },

  modalBody: { paddingHorizontal: 20, paddingBottom: 40 },

  imageRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    marginBottom: 16,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    backgroundColor: 'rgba(135,206,235,0.06)',
  },
  imagePreviewWrap: {
    width: 92,
    height: 70,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  imagePreview: { width: '100%', height: '100%', resizeMode: 'cover' },
  imagePlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4 },
  imagePlaceholderText: { color: 'rgba(249,250,251,0.55)', fontSize: 12, fontWeight: '800' },
  imageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(135,206,235,0.08)',
    alignSelf: 'flex-start',
  },
  imageBtnText: { color: SKY, fontWeight: '900', fontSize: 12 },
  imageBtnDanger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(252,165,165,0.35)',
    backgroundColor: 'rgba(239,68,68,0.10)',
    alignSelf: 'flex-start',
  },
  imageBtnDangerText: { color: '#FCA5A5', fontWeight: '900', fontSize: 12 },

  inputGroup: { marginBottom: 16 },
  inputLabel: { color: 'rgba(249,250,251,0.85)', fontSize: 13, fontWeight: '800', marginBottom: 8 },
  inputLabelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },

  lookupIndicator: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  lookupText: { color: SKY, fontSize: 12, fontWeight: '700' },

  inputHint: { color: 'rgba(249,250,251,0.55)', fontSize: 12, marginTop: 6, lineHeight: 16 },

  input: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.22)',
  },

  dvlaRow: {
    marginTop: 6,
    marginBottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    backgroundColor: 'rgba(135,206,235,0.06)',
  },
  dvlaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    backgroundColor: 'rgba(135,206,235,0.10)',
  },
  dvlaBadgeText: { color: SKY, fontWeight: '900', fontSize: 12 },

  dvlaMiniText: { color: 'rgba(249,250,251,0.80)', fontSize: 12, fontWeight: '800', marginBottom: 4 },

  refreshPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  refreshText: { color: SKY, fontWeight: '900', fontSize: 12 },

  saveButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  saveButtonGradient: { paddingVertical: 16, alignItems: 'center' },
  saveButtonText: { color: BG, fontSize: 16, fontWeight: '900' },
});
