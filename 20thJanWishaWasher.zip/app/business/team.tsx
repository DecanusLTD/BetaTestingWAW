import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
  Modal,
  Alert,
  Platform,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusDot from '../../src/components/shared/StatusDot';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Valeter {
  id: string;
  name: string;
  email: string;
  phone?: string;
  is_online: boolean;
  total_jobs?: number;
  rating?: number;
  location_assignment?: string;
  role?: string;
  clocked_in?: boolean;
  created_at: string;
}

type ProfileRow = {
  id: string;
  name: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  created_at: string | null;
  user_type: string | null;
  organization_id: string | null;
};

type PresenceRow = {
  user_id: string;
  is_online: boolean | null;
};

type BookingStatRow = {
  id: string;
  rating: number | null;
};

export default function BusinessTeam() {
  const { user } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState<string | null>(null);

  // Local-only add valeter modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [addQuery, setAddQuery] = useState('');
  const [addingLoading, setAddingLoading] = useState(false);
  const [unassigned, setUnassigned] = useState<Valeter[]>([]);
  const [loadingUnassigned, setLoadingUnassigned] = useState(false);

  // Remove assigned valeter state
  const [removingId, setRemovingId] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      loadValeters();
    } else {
      setValeters([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const normalizeName = (v: ProfileRow) =>
    (v.full_name ?? '').trim() || (v.name ?? '').trim() || 'Valeter';

  const normalizeEmail = (v: ProfileRow) => (v.email ?? '').trim() || 'no-email@unknown';

  const mapProfileToValeter = async (v: ProfileRow): Promise<Valeter> => {
    const displayName = normalizeName(v);
    const email = normalizeEmail(v);

    const { data: presenceData } = await supabase
      .from('valeter_presence')
      .select('user_id, is_online')
      .eq('user_id', v.id)
      .maybeSingle();

    const presence = (presenceData as PresenceRow | null) ?? null;

    const { data: statsData } = await supabase
      .from('bookings')
      .select('id, rating')
      .eq('valeter_id', v.id)
      .eq('status', 'completed');

    const stats = (statsData || []) as BookingStatRow[];
    const totalJobs = stats.length;
    const avgRating =
      totalJobs > 0 ? stats.reduce((acc, s) => acc + (s.rating || 0), 0) / totalJobs : 0;

    return {
      id: v.id,
      name: displayName,
      email,
      phone: (v.phone ?? '').trim() || undefined,
      created_at: v.created_at ?? new Date().toISOString(),
      is_online: !!presence?.is_online,
      total_jobs: totalJobs,
      rating: avgRating,
      location_assignment: null,
      role: 'valeter',
      clocked_in: false,
    };
  };

  const loadValeters = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);

      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, full_name, email, phone, created_at, user_type, organization_id')
        .eq('organization_id', organizationId)
        .ilike('user_type', 'valeter%')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const rows = (data || []) as ProfileRow[];
      const valeterData: Valeter[] = await Promise.all(rows.map(mapProfileToValeter));
      setValeters(valeterData);
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUnassignedValeters = async () => {
    if (!isOrgUser) return;

    try {
      setLoadingUnassigned(true);

      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, full_name, email, phone, created_at, user_type, organization_id')
        .ilike('user_type', 'valeter%')
        .is('organization_id', null)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const rows = (data || []) as ProfileRow[];
      const mapped: Valeter[] = await Promise.all(rows.map(mapProfileToValeter));
      setUnassigned(mapped);
    } catch (error) {
      console.error('Error loading unassigned valeters:', error);
      setUnassigned([]);
    } finally {
      setLoadingUnassigned(false);
    }
  };

  const openAddModal = async () => {
    await hapticFeedback('light');
    setAddQuery('');
    setAddModalOpen(true);
    loadUnassignedValeters();
  };

  const closeAddModal = async () => {
    await hapticFeedback('light');
    setAddModalOpen(false);
  };

  const assignValeterToOrg = async (valeter: Valeter) => {
    if (!organizationId) return;

    Alert.alert(
      'Add valeter to team?',
      `${valeter.name}\n${valeter.email}`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Add',
          style: 'default',
          onPress: async () => {
            try {
              setAddingLoading(true);
              await hapticFeedback('light');

              const { error } = await supabase
                .from('profiles')
                .update({ organization_id: organizationId })
                .eq('id', valeter.id);

              if (error) throw error;

              await hapticFeedback('success');

              setUnassigned((prev) => prev.filter((v) => v.id !== valeter.id));
              await loadValeters();
              await loadUnassignedValeters();
            } catch (e) {
              console.error('Error assigning valeter:', e);
              await hapticFeedback('error');
              Alert.alert('Could not add valeter', 'Something went wrong. Please try again.');
            } finally {
              setAddingLoading(false);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  const removeValeterFromOrg = async (valeter: Valeter) => {
    if (!organizationId) return;

    Alert.alert(
      'Remove from team?',
      `${valeter.name}\nThis will unassign them from your business.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setRemovingId(valeter.id);
              await hapticFeedback('light');

              const { error } = await supabase
                .from('profiles')
                .update({ organization_id: null })
                .eq('id', valeter.id);

              if (error) throw error;

              await hapticFeedback('success');

              await loadValeters();
              await loadUnassignedValeters();
            } catch (e) {
              console.error('Error removing valeter:', e);
              await hapticFeedback('error');
              Alert.alert('Could not remove', 'Something went wrong. Please try again.');
            } finally {
              setRemovingId(null);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  const filteredValeters = valeters.filter((valeter) => {
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q || valeter.name.toLowerCase().includes(q) || valeter.email.toLowerCase().includes(q);

    const matchesLocation = !filterLocation || valeter.location_assignment === filterLocation;

    return matchesSearch && matchesLocation;
  });

  const filteredUnassigned = useMemo(() => {
    const q = addQuery.trim().toLowerCase();
    if (!q) return unassigned;
    return unassigned.filter(
      (v) => v.name.toLowerCase().includes(q) || v.email.toLowerCase().includes(q)
    );
  }, [addQuery, unassigned]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Team" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading team...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Team" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Team"
        rightAction={
          <TouchableOpacity onPress={openAddModal} style={styles.inviteButton}>
            <Ionicons name="person-add" size={24} color={SKY} />
          </TouchableOpacity>
        }
        scrollY={scrollY}
        enableScrollAnimation={true}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <GlassCard style={styles.searchCard} accountType="business">
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={18} color="#8B5CF6" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search team..."
              placeholderTextColor="rgba(249,250,251,0.5)"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </GlassCard>

        <View style={styles.quickActions}>
          <TouchableOpacity onPress={openAddModal} style={styles.quickActionButton}>
            <GlassCard onPress={undefined} style={styles.quickActionCard} accountType="business">
              <View style={styles.quickActionContent}>
                <Ionicons name="person-add" size={20} color="#8B5CF6" />
                <Text style={styles.quickActionText}>Add Valeter</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadValeters();
            }}
            style={styles.quickActionButton}
          >
            <GlassCard onPress={undefined} style={styles.quickActionCard} accountType="business">
              <View style={styles.quickActionContent}>
                <Ionicons name="refresh" size={20} color="#8B5CF6" />
                <Text style={styles.quickActionText}>Refresh</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>
        </View>

        <View style={styles.statsRow}>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total Valeters</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>{valeters.filter((v) => v.is_online).length}</Text>
            <Text style={styles.statLabel}>Online Now</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>{valeters.filter((v) => v.clocked_in).length}</Text>
            <Text style={styles.statLabel}>Clocked In</Text>
          </GlassCard>
        </View>

        {filteredValeters.length === 0 ? (
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>
                {searchQuery ? 'No valeters found' : 'No team members yet'}
              </Text>
              <Text style={styles.emptyText}>
                {searchQuery ? 'Try adjusting your search' : 'Add existing valeters to your business team'}
              </Text>

              {!searchQuery ? (
                <TouchableOpacity onPress={openAddModal} style={styles.primaryCta}>
                  <Ionicons name="person-add" size={18} color="#0B1220" />
                  <Text style={styles.primaryCtaText}>Add Valeter</Text>
                </TouchableOpacity>
              ) : null}
            </View>
          </GlassCard>
        ) : (
          <View style={styles.valetersList}>
            {filteredValeters.map((valeter, index) => (
              <Animated.View
                key={valeter.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateY: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [30 + index * 10, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.valeterCard} accountType="business">
                  <View style={styles.valeterHeader}>
                    <View style={styles.valeterAvatar}>
                      <Ionicons name="person" size={24} color={SKY} />
                    </View>

                    <View style={styles.valeterInfo}>
                      <View style={styles.valeterNameRow}>
                        <Text style={styles.valeterName}>{valeter.name}</Text>
                        {valeter.role && (
                          <View style={styles.roleBadge}>
                            <Text style={styles.roleText}>{valeter.role}</Text>
                          </View>
                        )}
                      </View>

                      <Text style={styles.valeterEmail}>{valeter.email}</Text>
                      {valeter.phone && <Text style={styles.valeterPhone}>{valeter.phone}</Text>}
                    </View>

                    <View style={styles.rightCluster}>
                      <View style={styles.statusContainer}>
                        <StatusDot
                          status={valeter.is_online ? 'available' : valeter.clocked_in ? 'busy' : 'offline'}
                          size={12}
                          pulseOnChange={true}
                        />
                      </View>

                      <TouchableOpacity
                        onPress={() => removeValeterFromOrg(valeter)}
                        disabled={removingId === valeter.id}
                        style={[styles.removeBtn, removingId === valeter.id && { opacity: 0.6 }]}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        {removingId === valeter.id ? (
                          <ActivityIndicator size="small" color="#FCA5A5" />
                        ) : (
                          <Ionicons name="trash-outline" size={18} color="#FCA5A5" />
                        )}
                      </TouchableOpacity>
                    </View>
                  </View>

                  <View style={styles.valeterStats}>
                    <View style={styles.statItem}>
                      <Ionicons name="car" size={14} color="#8B5CF6" />
                      <Text style={styles.statItemText}>{valeter.total_jobs || 0} jobs</Text>
                    </View>

                    {valeter.rating && valeter.rating > 0 ? (
                      <View style={styles.statItem}>
                        <Ionicons name="star" size={14} color="#8B5CF6" />
                        <Text style={styles.statItemText}>{valeter.rating.toFixed(1)}</Text>
                      </View>
                    ) : null}

                    <View style={styles.statItem}>
                      <Ionicons
                        name={valeter.clocked_in ? 'time' : 'time-outline'}
                        size={14}
                        color="#8B5CF6"
                      />
                      <Text style={styles.statItemText}>{valeter.clocked_in ? 'Clocked In' : 'Off'}</Text>
                    </View>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </View>
        )}
      </Animated.ScrollView>

      {/* Add Valeter Modal */}
      <Modal visible={addModalOpen} animationType="fade" transparent onRequestClose={closeAddModal}>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add a valeter</Text>

              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    loadUnassignedValeters();
                  }}
                  style={styles.modalIconBtn}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Ionicons name="refresh" size={20} color="#F9FAFB" />
                </TouchableOpacity>

                <TouchableOpacity onPress={closeAddModal} style={styles.modalClose}>
                  <Ionicons name="close" size={22} color="#F9FAFB" />
                </TouchableOpacity>
              </View>
            </View>

            <GlassCard style={styles.modalSearchCard} accountType="business">
              <View style={styles.searchContainer}>
                <Ionicons name="search" size={18} color="#8B5CF6" style={styles.searchIcon} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search unassigned valeters..."
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  value={addQuery}
                  onChangeText={setAddQuery}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
            </GlassCard>

            <Text style={styles.modalSubtle}>
              Showing {filteredUnassigned.length} of {unassigned.length} unassigned
            </Text>

            {/* FIX: Give this area real height and make the scroll view flex */}
            <View style={styles.modalBody}>
              {loadingUnassigned ? (
                <View style={styles.modalLoading}>
                  <ActivityIndicator size="large" color={SKY} />
                  <Text style={styles.loadingText}>Loading valeters...</Text>
                </View>
              ) : filteredUnassigned.length === 0 ? (
                <GlassCard style={styles.modalEmptyCard} accountType="business">
                  <View style={styles.emptyContent}>
                    <Ionicons name="person-outline" size={44} color={SKY} style={{ opacity: 0.5 }} />
                    <Text style={styles.emptyTitle}>No unassigned valeters</Text>
                    <Text style={styles.emptyText}>
                      {addQuery ? 'Try a different search.' : 'Everyone is already part of a business team.'}
                    </Text>
                  </View>
                </GlassCard>
              ) : (
                <ScrollView
                  style={styles.modalScroll}
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={styles.modalList}
                >
                  {filteredUnassigned.map((v) => (
                    <TouchableOpacity
                      key={v.id}
                      disabled={addingLoading}
                      onPress={() => assignValeterToOrg(v)}
                      activeOpacity={0.85}
                    >
                      <GlassCard style={styles.modalValeterCard} accountType="business">
                        <View style={styles.modalValeterRow}>
                          <View style={styles.valeterAvatar}>
                            <Ionicons name="person" size={22} color={SKY} />
                          </View>

                          <View style={{ flex: 1 }}>
                            <Text style={styles.modalValeterName}>{v.name}</Text>
                            <Text style={styles.modalValeterEmail}>{v.email}</Text>
                          </View>

                          <View style={styles.modalAddPill}>
                            {addingLoading ? (
                              <ActivityIndicator size="small" color="#0B1220" />
                            ) : (
                              <>
                                <Ionicons name="add" size={16} color="#0B1220" />
                                <Text style={styles.modalAddPillText}>Add</Text>
                              </>
                            )}
                          </View>
                        </View>
                      </GlassCard>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}
            </View>

            <TouchableOpacity onPress={closeAddModal} style={styles.modalFooterBtn}>
              <Text style={styles.modalFooterBtnText}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: { color: SKY, fontSize: 14 },

  inviteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  searchCard: { padding: 0, marginBottom: 20, overflow: 'hidden' },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchIcon: { marginRight: 12 },
  searchInput: { flex: 1, color: '#F9FAFB', fontSize: 16 },

  quickActions: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  quickActionButton: { flex: 1 },
  quickActionCard: { ...CARD_SIZES.small },
  quickActionContent: {
    padding: CARD_SIZES.small.padding,
    alignItems: 'center',
    gap: SPACING.sm,
  },
  quickActionText: { color: '#F9FAFB', fontSize: 12, fontWeight: '600' },

  statsRow: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  statCard: { flex: 1, ...CARD_SIZES.small, alignItems: 'center' },
  statValue: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginBottom: 4 },
  statLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '500' },

  valetersList: { gap: 12 },
  valeterCard: { ...CARD_SIZES.medium },
  valeterHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 12 },
  valeterAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(139,92,246,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterInfo: { flex: 1 },
  valeterNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  valeterName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  roleBadge: {
    backgroundColor: 'rgba(139,92,246,0.15)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  roleText: { color: '#8B5CF6', fontSize: 9, fontWeight: '600', textTransform: 'uppercase' },
  valeterEmail: { color: 'rgba(249,250,251,0.7)', fontSize: 13, marginBottom: 2 },
  valeterPhone: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },

  rightCluster: { alignItems: 'flex-end', gap: 8 },
  statusContainer: { justifyContent: 'center', alignItems: 'center' },
  removeBtn: {
    width: 34,
    height: 34,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(252, 165, 165, 0.10)',
    borderWidth: 1,
    borderColor: 'rgba(252, 165, 165, 0.22)',
  },

  valeterStats: {
    flexDirection: 'row',
    gap: SPACING.lg,
    paddingTop: SPACING.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.15)',
  },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statItemText: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },

  emptyCard: { ...CARD_SIZES.large },
  emptyContent: { alignItems: 'center' },
  emptyTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginTop: 16, marginBottom: 8 },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, textAlign: 'center' },
  primaryCta: {
    marginTop: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: SKY,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
  },
  primaryCtaText: { color: '#0B1220', fontSize: 13, fontWeight: '800' },

  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 14,
  },
  modalCard: {
    width: '100%',
    maxWidth: 560,
    borderRadius: 18,
    paddingTop: 12,
    paddingHorizontal: 16,
    paddingBottom: 14,
    backgroundColor: 'rgba(12, 18, 34, 0.94)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
    maxHeight: Platform.OS === 'ios' ? '80%' : '84%',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 10,
  },
  modalTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800' },
  modalIconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(249,250,251,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.12)',
  },
  modalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(249,250,251,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.12)',
  },
  modalSearchCard: { padding: 0, overflow: 'hidden', marginBottom: 8 },
  modalSubtle: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
    marginLeft: 2,
  },

  // KEY FIXES HERE
  modalBody: {
    flex: 1,
    minHeight: 220,
  },
  modalScroll: {
    flex: 1,
  },
  modalLoading: { paddingTop: 30, alignItems: 'center', gap: 10 },
  modalEmptyCard: { ...CARD_SIZES.large },
  modalList: {
    gap: 10,
    paddingBottom: 12,
  },

  modalValeterCard: { ...CARD_SIZES.medium },
  modalValeterRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  modalValeterName: { color: '#F9FAFB', fontSize: 14, fontWeight: '800', marginBottom: 2 },
  modalValeterEmail: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },
  modalAddPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: SKY,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
  },
  modalAddPillText: { color: '#0B1220', fontSize: 12, fontWeight: '900' },
  modalFooterBtn: {
    marginTop: 10,
    alignSelf: 'flex-end',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(249,250,251,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.12)',
  },
  modalFooterBtnText: { color: '#F9FAFB', fontSize: 13, fontWeight: '800' },
});
