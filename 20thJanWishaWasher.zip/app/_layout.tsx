// app/_layout.tsx (RootLayout)
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { useEffect, useRef, useState } from 'react';
import { LogBox, Platform } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import NavTabWrapper from './components/NavTabWrapper';

// Conditionally import Stripe only on native platforms
let StripeProvider: any = ({ children }: { children: React.ReactNode }) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    console.warn('Stripe not available:', e);
  }
}

// Make splash manual and guard errors
(async () => {
  try {
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('[Splash] preventAutoHideAsync error:', e);
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const startTime = Date.now();
        
        // If you load fonts/assets, await them here.
        // await Font.loadAsync(...)
        await new Promise(requestAnimationFrame);
        
        // Ensure splash screen shows for at least 3 seconds
        const minDisplayTime = 3000; // 3 seconds
        
        // Calculate remaining time to reach 3 seconds
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, minDisplayTime - elapsed);
        
        if (remaining > 0) {
          await new Promise(resolve => setTimeout(resolve, remaining));
        }
        
        setAppReady(true);
      } catch (e) {
        console.error('[RootLayout] boot error:', e);
        setAppReady(true); // don't deadlock the splash
      }
    })();
  }, []);

  useEffect(() => {
    const hide = async () => {
      if (appReady && !hideOnceRef.current) {
        hideOnceRef.current = true;
        try {
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn('[Splash] hideAsync error:', e);
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"  // <-- put your PK here
      merchantIdentifier="merchant.com.wishawash"                                   // Apple Pay (iOS)
      urlScheme="waw"                                                         // Optional: 3DS redirect on Android
    >
      <AuthProvider>
        <StatusBar style="light" backgroundColor="#1E3A8A" />
        <NavTabWrapper>
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: '#0A1929' },
              animation: Platform.OS === 'android' ? 'slide_from_right' : 'default',
              gestureEnabled: false,
            }}
          />
        </NavTabWrapper>
      </AuthProvider>
    </StripeProvider>
  );
}