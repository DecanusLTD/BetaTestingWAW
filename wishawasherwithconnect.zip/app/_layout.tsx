// app/_layout.tsx (RootLayout)
import { Stack, usePathname, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from '../src/providers/enhanced-auth-context';
import { useEffect, useRef, useState } from 'react';
import { LogBox, Platform, Image } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import {
  Rubik_400Regular,
  Rubik_500Medium,
  Rubik_600SemiBold,
  Rubik_700Bold,
} from '@expo-google-fonts/rubik';
import NavigationTab from './components/NavigationTab';
import { businessOnboardingService } from '../src/services/businessOnboardingService';

// Conditionally import Stripe only on native platforms
let StripeProvider: any = ({ children }: { children: React.ReactNode }) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    console.warn('Stripe not available:', e);
  }
}

// Make splash manual and guard errors
(async () => {
  try {
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('[Splash] preventAutoHideAsync error:', e);
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

function BusinessOnboardingGate() {
  const { user, authReady, isLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const lastRedirectRef = useRef<string | null>(null);

  useEffect(() => {
    let mounted = true;
    if (!authReady || isLoading || !user?.id) return;
    const userType = (user.userType || '').toLowerCase();
    if (userType !== 'organization' && userType !== 'business') return;

    const check = async () => {
      try {
        const status = await businessOnboardingService.getStatus(user.id);
        if (!mounted) return;

        const termsDeclined = status.termsStatus === 'declined';
        const termsAccepted = status.termsStatus === 'accepted';
        const stripeDone = status.stripeConnectStatus === 'completed';
        const stripeSkipped = Boolean(status.stripeDetails?.skipped_for_now);
        const onTermsPage = pathname === '/business/terms';
        const onStripePage = pathname === '/business/stripe-connect';
        const onTermsBlockedPage = pathname === '/business/terms-blocked';

        if (termsDeclined) {
          if (!onTermsBlockedPage && lastRedirectRef.current !== '/business/terms-blocked') {
            lastRedirectRef.current = '/business/terms-blocked';
            router.replace('/business/terms-blocked' as any);
          }
          return;
        }

        if (!termsAccepted) {
          if (!onTermsPage && lastRedirectRef.current !== '/business/terms') {
            lastRedirectRef.current = '/business/terms';
            router.replace('/business/terms' as any);
          }
          return;
        }

        if (!stripeDone && !stripeSkipped) {
          if (!onStripePage && lastRedirectRef.current !== '/business/stripe-connect') {
            lastRedirectRef.current = '/business/stripe-connect';
            router.replace('/business/stripe-connect' as any);
          }
          return;
        }

        if ((onTermsPage || onStripePage || onTermsBlockedPage) && lastRedirectRef.current !== '/business/dashboard') {
          lastRedirectRef.current = '/business/dashboard';
          router.replace('/business/dashboard' as any);
          return;
        }

        lastRedirectRef.current = null;
      } catch (e) {
        console.warn('[BusinessOnboardingGate] check failed', e);
      }
    };

    check();
    return () => {
      mounted = false;
    };
  }, [authReady, isLoading, user?.id, user?.userType, pathname, router]);

  return null;
}

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const startTime = Date.now();
        
        // Preload assets
        const imageAssets = [
          require('../assets/auth-page.png'),
        ];

        const cacheImages = imageAssets.map(image => {
          return Asset.fromModule(image).downloadAsync();
        });

        await Promise.all(cacheImages);
        
        // Load Rubik fonts
        await Font.loadAsync({
          Rubik_400Regular,
          Rubik_500Medium,
          Rubik_600SemiBold,
          Rubik_700Bold,
        });
        
        await new Promise(requestAnimationFrame);
        
        // Ensure splash screen shows for at least 3 seconds
        const minDisplayTime = 3000; // 3 seconds
        
        // Calculate remaining time to reach 3 seconds
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, minDisplayTime - elapsed);
        
        if (remaining > 0) {
          await new Promise(resolve => setTimeout(resolve, remaining));
        }
        
        setAppReady(true);
      } catch (e) {
        console.error('[RootLayout] boot error:', e);
        setAppReady(true); // don't deadlock the splash
      }
    })();
  }, []);

  useEffect(() => {
    const hide = async () => {
      if (appReady && !hideOnceRef.current) {
        hideOnceRef.current = true;
        try {
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn('[Splash] hideAsync error:', e);
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"  // <-- put your PK here
      merchantIdentifier="merchant.com.wishawash"                                   // Apple Pay (iOS)
      urlScheme="waw"                                                         // Optional: 3DS redirect on Android
    >
      <AuthProvider>
        <BusinessOnboardingGate />
        <StatusBar style="light" backgroundColor="#1E3A8A" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: '#0A1929' }, // Set a background color to prevent transparency glitches during fade
            animation: 'fade', // Smoother fade transition
            animationDuration: 400, // Slightly slower for smoothness (if supported by the specific navigator version, otherwise ignored)
            gestureEnabled: true, // Enable gestures for native feel
          }}
        />
        <NavigationTab />
      </AuthProvider>
    </StripeProvider>
  );
}
