import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { useAuth } from '../../src/providers/enhanced-auth-context';
import { businessOnboardingService } from '../../src/services/businessOnboardingService';

export default function BusinessTermsScreen() {
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const insets = useSafeAreaInsets();
  const termsVersion = 'v1.0';
  const summaryItems = [
    'You are responsible for the services delivered through your business account, including staff conduct, vehicle care, and customer communication.',
    'You must keep your business information, insurance, and any required legal or tax details accurate and up to date.',
    'Payouts are handled through Stripe Connect. You may be unable to receive payouts until onboarding is completed and Stripe approves the account.',
    'Platform misuse, fraudulent activity, or unsafe behaviour may lead to restrictions, suspension, or account removal.',
  ];

  const handleAccept = async () => {
    if (!user?.id || saving) return;
    try {
      setSaving(true);
      await businessOnboardingService.acceptTerms(user.id, termsVersion);
      router.replace('/business/stripe-connect' as any);
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to save terms acceptance.');
    } finally {
      setSaving(false);
    }
  };

  const handleDecline = async () => {
    if (!user?.id || saving) return;
    try {
      setSaving(true);
      await businessOnboardingService.declineTerms(user.id, termsVersion);
      router.replace('/business/terms-blocked' as any);
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to decline terms.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <LinearGradient colors={['#071321', '#123B67', '#1D5DA8']} style={StyleSheet.absoluteFill} />

      <View style={styles.backgroundOrbTop} />
      <View style={styles.backgroundOrbBottom} />

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        <View style={styles.heroCard}>
          <View style={styles.heroBadge}>
            <Ionicons name="document-text-outline" size={18} color="#9ED8FF" />
            <Text style={styles.heroBadgeText}>Business onboarding</Text>
          </View>

          <Text style={styles.title}>Business Terms & Conditions</Text>
          <Text style={styles.subtitle}>
            Review and accept these terms before using the business dashboard or receiving payouts.
          </Text>

          <View style={styles.versionPill}>
            <Text style={styles.versionLabel}>Current version</Text>
            <Text style={styles.versionValue}>{termsVersion}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>What you are agreeing to</Text>
          {summaryItems.map((item, index) => (
            <View key={index} style={styles.bulletRow}>
              <View style={styles.bulletNumber}>
                <Text style={styles.bulletNumberText}>{index + 1}</Text>
              </View>
              <Text style={styles.paragraph}>{item}</Text>
            </View>
          ))}
        </View>

        <View style={styles.infoRow}>
          <View style={styles.infoIconWrap}>
            <Ionicons name="shield-checkmark-outline" size={18} color="#9ED8FF" />
          </View>
          <View style={styles.infoTextWrap}>
            <Text style={styles.infoTitle}>Important</Text>
            <Text style={styles.infoText}>
              If you decline, the business account stays blocked until the terms are accepted.
            </Text>
          </View>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: 16 + insets.bottom }]}>
        <TouchableOpacity
          style={[styles.button, styles.declineButton]}
          onPress={handleDecline}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.declineButtonText}>Decline</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.acceptButton]}
          onPress={handleAccept}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#0A1929" />
          ) : (
            <Text style={styles.acceptButtonText}>Accept & Continue</Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 28 },
  backgroundOrbTop: {
    position: 'absolute',
    top: -40,
    right: -20,
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  backgroundOrbBottom: {
    position: 'absolute',
    bottom: 120,
    left: -50,
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: 'rgba(59,130,246,0.10)',
  },
  heroCard: {
    borderRadius: 24,
    padding: 22,
    marginBottom: 18,
    backgroundColor: 'rgba(4,16,30,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.18)',
  },
  heroBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: 'rgba(158,216,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.18)',
    marginBottom: 18,
  },
  heroBadgeText: {
    color: '#CFEFFF',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  title: { color: '#fff', fontSize: 30, fontWeight: '800', lineHeight: 36 },
  subtitle: { color: '#B8D7EE', fontSize: 15, lineHeight: 22, marginTop: 10 },
  versionPill: {
    marginTop: 18,
    alignSelf: 'flex-start',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  versionLabel: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.7,
    marginBottom: 2,
  },
  versionValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  card: {
    borderRadius: 22,
    padding: 20,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: '800', marginBottom: 14 },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 14,
  },
  bulletNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    marginTop: 1,
  },
  bulletNumberText: {
    color: '#D6F1FF',
    fontSize: 13,
    fontWeight: '800',
  },
  paragraph: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 21,
    flex: 1,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginTop: 16,
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(8,24,43,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.14)',
  },
  infoIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(158,216,255,0.10)',
  },
  infoTextWrap: {
    flex: 1,
  },
  infoTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 3,
  },
  infoText: {
    color: '#BCD9ED',
    fontSize: 13,
    lineHeight: 19,
  },
  footer: {
    padding: 16,
    flexDirection: 'row',
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.16)',
    backgroundColor: 'rgba(5,14,25,0.82)',
  },
  button: {
    flex: 1,
    borderRadius: 16,
    minHeight: 54,
    alignItems: 'center',
    justifyContent: 'center',
  },
  declineButton: {
    backgroundColor: 'rgba(239,68,68,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.28)',
  },
  acceptButton: {
    backgroundColor: '#9ED8FF',
  },
  declineButtonText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  acceptButtonText: { color: '#0A1929', fontSize: 14, fontWeight: '800' },
});
