import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  ScrollView,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { useAuth } from '../../src/providers/enhanced-auth-context';
import { businessOnboardingService, BusinessOnboardingStatus } from '../../src/services/businessOnboardingService';
import { stripeConnectService } from '../../src/services/stripeConnectService';

export default function BusinessStripeConnectScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<BusinessOnboardingStatus | null>(null);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [dialogType, setDialogType] = useState<'error' | 'warning' | 'info'>('info');
  const [dialogActions, setDialogActions] = useState<Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }>>([]);

  const openDialog = (
    title: string,
    message: string,
    type: 'error' | 'warning' | 'info' = 'info',
    actions: Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }> = [{ label: 'Close', kind: 'primary' }]
  ) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogType(type);
    setDialogActions(actions);
    setDialogVisible(true);
  };

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await businessOnboardingService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving) return;
    try {
      setSaving(true);
      if (user?.id) {
        await businessOnboardingService.setStripeSkipForNow(user.id, false);
      }
      const { url } = await stripeConnectService.createOnboardingLink();
      await Linking.openURL(url);
    } catch (error: any) {
      openDialog('Unable to start Stripe Connect', error?.message || 'Failed to start Stripe Connect.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckStatus = async (silent = false) => {
    if (saving) return;
    try {
      setSaving(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await load();
      if (result.stripeConnectStatus === 'completed') {
        router.replace('/business/dashboard' as any);
        return;
      }
      if (!silent) {
        openDialog(
          'Stripe setup still incomplete',
          'Please finish all required Stripe onboarding steps, then tap "Check Stripe Status" again.',
          'warning'
        );
      }
    } catch (error: any) {
      openDialog('Unable to check Stripe status', error?.message || 'Failed to check Stripe status.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSkipForNow = async () => {
    if (!user?.id || saving) return;

    openDialog(
      'Skip Stripe for now?',
      'You can enter the app, but parts of the business experience will stay restricted until Stripe Connect is completed. Payments for services provided through Wish a Washer may also be delayed.',
      'warning',
      [
        { label: 'Cancel', kind: 'secondary' },
        {
          label: 'Skip for now',
          kind: 'primary',
          onPress: async () => {
            try {
              setSaving(true);
              await businessOnboardingService.setStripeSkipForNow(user.id, true);
              router.replace('/business/dashboard' as any);
            } catch (error: any) {
              openDialog('Unable to skip right now', error?.message || 'Failed to update Stripe onboarding status.', 'error');
            } finally {
              setSaving(false);
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
        <LinearGradient colors={['#071321', '#123B67', '#1D5DA8']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingWrap}>
          <ActivityIndicator color="#87CEEB" />
          <Text style={styles.loadingText}>Loading Stripe setup...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <LinearGradient colors={['#071321', '#123B67', '#1D5DA8']} style={StyleSheet.absoluteFill} />
      <View style={styles.backgroundOrbTop} />
      <View style={styles.backgroundOrbBottom} />

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        <View style={styles.headerRow}>
          <View style={styles.headerSpacer} />
          <TouchableOpacity
            style={styles.settingsButton}
            onPress={() => router.push('/business/stripe-connect-test' as any)}
            activeOpacity={0.85}
          >
            <Ionicons name="settings-outline" size={20} color="#CFEFFF" />
          </TouchableOpacity>
        </View>

        <View style={styles.heroCard}>
          <View style={styles.heroBadge}>
            <Ionicons name="card-outline" size={18} color="#9ED8FF" />
            <Text style={styles.heroBadgeText}>Payout onboarding</Text>
          </View>

          <Text style={styles.title}>Stripe Connect Setup</Text>
          <Text style={styles.subtitle}>
            Connect your payout account so your business can receive earnings through the platform.
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Current setup</Text>

          <View style={styles.statusRow}>
            <Text style={styles.label}>Stripe status</Text>
            <View style={styles.statusPill}>
              <Text style={styles.statusPillText}>{status?.stripeConnectStatus || 'not_started'}</Text>
            </View>
          </View>

          <View style={styles.infoBlock}>
            <Text style={styles.label}>Connected account</Text>
            <Text style={styles.value}>{status?.stripeAccountId || 'Not linked yet'}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>How it works</Text>

          <View style={styles.stepRow}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>1</Text>
            </View>
            <Text style={styles.stepText}>Start onboarding and complete the Stripe-hosted setup form.</Text>
          </View>

          <View style={styles.stepRow}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>2</Text>
            </View>
            <Text style={styles.stepText}>Return to the app after Stripe redirects you back.</Text>
          </View>

          <View style={styles.stepRow}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>3</Text>
            </View>
            <Text style={styles.stepText}>Use the status check below to confirm payouts are fully enabled.</Text>
          </View>
        </View>

        <View style={styles.infoRow}>
          <View style={styles.infoIconWrap}>
            <Ionicons name="information-circle-outline" size={18} color="#9ED8FF" />
          </View>
          <View style={styles.infoTextWrap}>
            <Text style={styles.infoTitle}>Before you continue</Text>
            <Text style={styles.infoText}>
              Stripe may ask for business, identity, and banking information before payouts can be activated.
            </Text>
          </View>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: 16 + insets.bottom }]}>
        <TouchableOpacity style={styles.primaryButton} onPress={startConnect} disabled={saving}>
          {saving ? <ActivityIndicator color="#0A1929" /> : <Text style={styles.primaryText}>Start Stripe Connect</Text>}
        </TouchableOpacity>

        <TouchableOpacity style={styles.secondaryButton} onPress={() => handleCheckStatus(false)} disabled={saving}>
          <Text style={styles.secondaryText}>Check Stripe Status</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tertiaryButton} onPress={handleSkipForNow} disabled={saving}>
          <Text style={styles.tertiaryText}>Skip for now</Text>
        </TouchableOpacity>

        <Text style={styles.hintText}>
          After completing Stripe onboarding in your browser, come back here and check the status.
        </Text>
      </View>

      <Modal
        visible={dialogVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setDialogVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setDialogVisible(false)}>
          <Pressable style={styles.modalCard} onPress={() => {}}>
            <View style={[styles.modalIconWrap, dialogType === 'error' ? styles.modalIconError : dialogType === 'warning' ? styles.modalIconWarning : styles.modalIconInfo]}>
              <Ionicons
                name={dialogType === 'error' ? 'close-circle-outline' : dialogType === 'warning' ? 'alert-circle-outline' : 'information-circle-outline'}
                size={24}
                color="#FFFFFF"
              />
            </View>
            <Text style={styles.modalTitle}>{dialogTitle}</Text>
            <Text style={styles.modalMessage}>{dialogMessage}</Text>

            <View style={styles.modalActions}>
              {dialogActions.map((action, index) => (
                <TouchableOpacity
                  key={`${action.label}-${index}`}
                  style={[
                    styles.modalButton,
                    action.kind === 'secondary' && styles.modalButtonSecondary,
                    action.kind === 'danger' && styles.modalButtonDanger,
                    (!action.kind || action.kind === 'primary') && styles.modalButtonPrimary,
                  ]}
                  onPress={() => {
                    setDialogVisible(false);
                    action.onPress?.();
                  }}
                  activeOpacity={0.85}
                >
                  <Text
                    style={[
                      styles.modalButtonText,
                      action.kind === 'secondary' && styles.modalButtonTextSecondary,
                      action.kind === 'danger' && styles.modalButtonTextDanger,
                      (!action.kind || action.kind === 'primary') && styles.modalButtonTextPrimary,
                    ]}
                  >
                    {action.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
  loadingText: { color: '#fff' },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 28 },
  backgroundOrbTop: {
    position: 'absolute',
    top: -40,
    right: -20,
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  backgroundOrbBottom: {
    position: 'absolute',
    bottom: 140,
    left: -50,
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: 'rgba(59,130,246,0.10)',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  headerSpacer: {
    width: 42,
    height: 42,
  },
  settingsButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  heroCard: {
    borderRadius: 24,
    padding: 22,
    marginBottom: 18,
    backgroundColor: 'rgba(4,16,30,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.18)',
  },
  heroBadge: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: 'rgba(158,216,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.18)',
    marginBottom: 18,
  },
  heroBadgeText: {
    color: '#CFEFFF',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  title: { color: '#fff', fontSize: 30, fontWeight: '800', lineHeight: 36 },
  subtitle: { color: '#B8D7EE', fontSize: 15, lineHeight: 22, marginTop: 10 },
  card: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 22,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    padding: 20,
    marginBottom: 16,
  },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: '800', marginBottom: 14 },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 12,
  },
  label: { color: '#87CEEB', fontSize: 12, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  statusPill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(158,216,255,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.16)',
  },
  statusPillText: { color: '#DDF4FF', fontSize: 12, fontWeight: '800' },
  infoBlock: {
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  value: { color: '#fff', fontSize: 14, fontWeight: '700', marginTop: 6 },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 14,
  },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
    marginTop: 1,
  },
  stepNumberText: {
    color: '#D6F1FF',
    fontSize: 13,
    fontWeight: '800',
  },
  stepText: {
    flex: 1,
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 21,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginTop: 2,
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(8,24,43,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.14)',
  },
  infoIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(158,216,255,0.10)',
  },
  infoTextWrap: {
    flex: 1,
  },
  infoTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 3,
  },
  infoText: {
    color: '#BCD9ED',
    fontSize: 13,
    lineHeight: 19,
  },
  footer: {
    paddingTop: 16,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.16)',
    backgroundColor: 'rgba(5,14,25,0.82)',
  },
  primaryButton: {
    borderRadius: 16,
    minHeight: 54,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#9ED8FF',
    marginBottom: 12,
  },
  primaryText: { color: '#0A1929', fontSize: 14, fontWeight: '800' },
  secondaryButton: {
    borderRadius: 16,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.28)',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  secondaryText: { color: '#FFFFFF', fontWeight: '700', fontSize: 13 },
  tertiaryButton: {
    borderRadius: 16,
    minHeight: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  tertiaryText: {
    color: '#DDEAF4',
    fontWeight: '700',
    fontSize: 13,
  },
  hintText: { color: '#87CEEB', fontSize: 12, marginTop: 12, lineHeight: 17, textAlign: 'center' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(3,10,18,0.72)',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  modalCard: {
    borderRadius: 24,
    padding: 22,
    backgroundColor: '#0D1D2E',
    borderWidth: 1,
    borderColor: 'rgba(158,216,255,0.14)',
  },
  modalIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  modalIconError: {
    backgroundColor: 'rgba(239,68,68,0.75)',
  },
  modalIconWarning: {
    backgroundColor: 'rgba(245,158,11,0.75)',
  },
  modalIconInfo: {
    backgroundColor: 'rgba(59,130,246,0.75)',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 8,
  },
  modalMessage: {
    color: '#C7DCEA',
    fontSize: 15,
    lineHeight: 22,
  },
  modalActions: {
    marginTop: 20,
    gap: 10,
  },
  modalButton: {
    minHeight: 50,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  modalButtonPrimary: {
    backgroundColor: '#9ED8FF',
  },
  modalButtonSecondary: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  modalButtonDanger: {
    backgroundColor: 'rgba(239,68,68,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.28)',
  },
  modalButtonText: {
    fontSize: 14,
    fontWeight: '800',
  },
  modalButtonTextPrimary: {
    color: '#0A1929',
  },
  modalButtonTextSecondary: {
    color: '#FFFFFF',
  },
  modalButtonTextDanger: {
    color: '#FFFFFF',
  },
});
