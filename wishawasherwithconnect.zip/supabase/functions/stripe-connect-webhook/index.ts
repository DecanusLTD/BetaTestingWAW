// supabase/functions/stripe-connect-webhook/index.ts
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.25.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';
const STRIPE_WEBHOOK_SECRET = Deno.env.get('STRIPE_WEBHOOK_SECRET') ?? '';

const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
});

function statusFromAccount(account: Stripe.Account): 'in_progress' | 'completed' | 'restricted' {
  if (account.details_submitted && account.charges_enabled && account.payouts_enabled) {
    return 'completed';
  }
  if ((account.requirements?.disabled_reason || '').length > 0) return 'restricted';
  return 'in_progress';
}

Deno.serve(async (req) => {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !STRIPE_SECRET_KEY || !STRIPE_WEBHOOK_SECRET) {
    return new Response('Missing function environment variables.', { status: 500 });
  }

  try {
    const signature = req.headers.get('stripe-signature');
    if (!signature) return new Response('Missing stripe-signature header', { status: 400 });

    const rawBody = await req.text();
    const event = await stripe.webhooks.constructEventAsync(
      rawBody,
      signature,
      STRIPE_WEBHOOK_SECRET
    );

    if (event.type === 'account.updated') {
      const account = event.data.object as Stripe.Account;
      const userId = account.metadata?.user_id;
      if (!userId) return new Response('ok', { status: 200 });

      const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
      const nextStatus = statusFromAccount(account);
      const updatePayload: Record<string, unknown> = {
        stripe_connect_status: nextStatus,
        stripe_account_id: account.id,
        stripe_details: {
          account_country: account.country,
          account_email: account.email,
          business_type: account.business_type,
          requirements: account.requirements,
          updated_from_stripe_webhook_at: new Date().toISOString(),
        },
      };
      if (nextStatus === 'completed') {
        updatePayload.stripe_onboarding_completed_at = new Date().toISOString();
      }

      await admin
        .from('profiles')
        .update(updatePayload as any)
        .eq('id', userId);
    }

    return new Response('ok', { status: 200 });
  } catch (e: any) {
    return new Response(e?.message || 'Webhook error', { status: 400 });
  }
});

