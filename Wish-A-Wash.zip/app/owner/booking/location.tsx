import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region, MapPressEvent } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { 
  calculateDisplayPrice, 
  getVehicleSize, 
  mapServiceIdToWashId,
  FrontendPricingInput 
} from '../../../src/pricing/pricingEngine';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function BookingLocation() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;

  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [address, setAddress] = useState('');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [offersWater, setOffersWater] = useState(false);
  const [offersElectricity, setOffersElectricity] = useState(false);
  const [vehicle, setVehicle] = useState<{ make?: string; model?: string; type?: string } | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const panelSlideAnim = useRef(new Animated.Value(height)).current; // Start off-screen

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(mapAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    // Pulse animation for marker
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    getCurrentLocation();
    loadVehicle();
  }, [vehicleId, user?.id]);
  
  const loadVehicle = async () => {
    if (!vehicleId || !user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('make, model, type')
        .eq('id', vehicleId)
        .eq('user_id', user.id)
        .single();
      
      if (error) throw error;
      setVehicle(data || null);
    } catch (error) {
      console.error('Error loading vehicle:', error);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to find nearby valeters.');
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      
      setLocation(coords);
      setRegion({
        ...coords,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });

      // Reverse geocode
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        setAddress(addr);
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        // Slide panel up when location is loaded
        setTimeout(() => {
          Animated.spring(panelSlideAnim, {
            toValue: 0,
            tension: 50,
            friction: 8,
            useNativeDriver: true,
          }).start();
        }, 300);
      }
    } catch (error) {
      console.error('Error getting location:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coordinate = event?.nativeEvent?.coordinate;
    if (!coordinate) {
      return;
    }
    await hapticFeedback('light');
    const coords = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    };
    setLocation(coords);
    setRegion({
      ...coords,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        setAddress(addr);
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        // Slide panel up when location is selected
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    } catch (error) {
      console.error('Error reverse geocoding:', error);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    await getCurrentLocation();
    
    // If we get a location, trigger panel slide
    setTimeout(() => {
      if (selectedLocation || location) {
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    }, 300);
  };

  const handleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map.');
      return;
    }
    await hapticFeedback('medium');
    
    const serviceOption = serviceOptions.find(s => s.id === serviceId);
    const basePrice = serviceOption?.price || 0;
    const discountAmount = (offersWater || offersElectricity) ? basePrice * 0.25 : 0;
    
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId,
        vehicleId,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
        customerOffersWater: offersWater.toString(),
        customerOffersElectricity: offersElectricity.toString(),
        discountAmount: discountAmount.toString(),
        washType: washType || '',
      },
    });
  };

  // Calculate price using pricing engine
  const pricingBreakdown = serviceId && vehicle ? (() => {
    const washId = mapServiceIdToWashId(serviceId);
    if (!washId) return null;
    
    const vehicleSize = getVehicleSize(vehicle);
    const input: FrontendPricingInput = {
      washId,
      vehicleSize,
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(), // Will be recalculated when time is selected
    };
    
    return calculateDisplayPrice(input);
  })() : null;
  
  const basePrice = pricingBreakdown?.finalDisplayPriceGBP || serviceOptions.find(s => s.id === serviceId)?.price || 0;
  const discountAmount = (offersWater || offersElectricity) ? basePrice * 0.25 : 0;
  const finalPrice = basePrice - discountAmount;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Select Location"
        rightAction={
          <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
            <Ionicons name="locate" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ scale: mapAnim }],
          },
        ]}
      >
        {/* Map */}
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            region={region}
            onPress={handleMapPress}
            showsUserLocation={true}
            showsMyLocationButton={false}
          >
            {location && (
              <Marker coordinate={location}>
                <Animated.View
                  style={[
                    styles.markerContainer,
                    {
                      transform: [{ scale: markerPulse }],
                    },
                  ]}
                >
                  <View style={styles.markerPin}>
                    <Ionicons name="location" size={24} color="#EF4444" />
                  </View>
                  <View style={styles.markerPulse} />
                </Animated.View>
              </Marker>
            )}
          </MapView>
        </View>

        {/* Location Card - Slides up from bottom when location is selected */}
        <Animated.View
          style={[
            styles.cardContainer,
            {
              transform: [{ translateY: panelSlideAnim }],
            },
          ]}
        >
          <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollContainer}>
            <GlassCard style={styles.locationCard}>
              <View style={styles.locationHeader}>
                <Ionicons name="location" size={24} color={SKY} />
                <Text style={styles.locationTitle}>Selected Location</Text>
              </View>
              {selectedLocation ? (
                <View style={styles.locationInfo}>
                  <Text style={styles.locationAddress}>{selectedLocation.address}</Text>
                  <View style={styles.locationCoords}>
                    <Ionicons name="map-outline" size={12} color={SKY} />
                    <Text style={styles.coordsText}>
                      {selectedLocation.latitude.toFixed(4)}, {selectedLocation.longitude.toFixed(4)}
                    </Text>
                  </View>
                </View>
              ) : (
                <Text style={styles.locationPlaceholder}>Tap on the map to select location</Text>
              )}
            </GlassCard>

            {/* Water/Electricity Offers */}
            {selectedLocation && (
              <GlassCard style={styles.offersCard}>
                <View style={styles.offersHeader}>
                  <Ionicons name="gift-outline" size={20} color={SKY} />
                  <Text style={styles.offersTitle}>Offer Resources</Text>
                </View>
                <Text style={styles.offersSubtitle}>
                  Help valeters and save 25% on your service
                </Text>
                
                <View style={styles.toggleContainer}>
                  <View style={styles.toggleRow}>
                    <View style={styles.toggleLeft}>
                      <Ionicons name="water-outline" size={20} color={SKY} />
                      <View style={styles.toggleTextContainer}>
                        <Text style={styles.toggleLabel}>Offer Water</Text>
                        <Text style={styles.toggleDescription}>Provide access to water supply</Text>
                      </View>
                    </View>
                    <Switch
                      value={offersWater}
                      onValueChange={(value) => {
                        hapticFeedback('light');
                        setOffersWater(value);
                      }}
                      trackColor={{ false: 'rgba(135,206,235,0.3)', true: SKY }}
                      thumbColor="#FFFFFF"
                    />
                  </View>

                  <View style={styles.toggleRow}>
                    <View style={styles.toggleLeft}>
                      <Ionicons name="flash-outline" size={20} color={SKY} />
                      <View style={styles.toggleTextContainer}>
                        <Text style={styles.toggleLabel}>Offer Electricity</Text>
                        <Text style={styles.toggleDescription}>Provide access to power outlet</Text>
                      </View>
                    </View>
                    <Switch
                      value={offersElectricity}
                      onValueChange={(value) => {
                        hapticFeedback('light');
                        setOffersElectricity(value);
                      }}
                      trackColor={{ false: 'rgba(135,206,235,0.3)', true: SKY }}
                      thumbColor="#FFFFFF"
                    />
                  </View>
                </View>

                {(offersWater || offersElectricity) && (
                  <View style={styles.discountBadge}>
                    <Ionicons name="pricetag-outline" size={16} color="#10B981" />
                    <Text style={styles.discountText}>
                      You'll save £{discountAmount.toFixed(2)} (25% off)
                    </Text>
                  </View>
                )}

                <View style={styles.priceSummary}>
                  <Text style={styles.priceLabel}>Service Price</Text>
                  <View style={styles.priceRow}>
                    <Text style={styles.originalPrice}>£{basePrice.toFixed(2)}</Text>
                    {discountAmount > 0 && (
                      <>
                        <Text style={styles.discountPrice}>£{finalPrice.toFixed(2)}</Text>
                        <View style={styles.discountTag}>
                          <Text style={styles.discountTagText}>-25%</Text>
                        </View>
                      </>
                    )}
                  </View>
                  {pricingBreakdown && (
                    <View style={styles.priceBreakdown}>
                      {pricingBreakdown.vehicleSizeAdjustmentGBP > 0 && (
                        <Text style={styles.breakdownText}>
                          +£{pricingBreakdown.vehicleSizeAdjustmentGBP.toFixed(2)} vehicle size
                        </Text>
                      )}
                      {pricingBreakdown.surgeMultiplier > 1 && (
                        <View style={styles.surgeBadge}>
                          <Ionicons name="flash" size={12} color="#F59E0B" />
                          <Text style={styles.surgeBadgeText}>{pricingBreakdown.surgeLabel}</Text>
                        </View>
                      )}
                    </View>
                  )}
                </View>
              </GlassCard>
            )}
          </ScrollView>

          {/* Continue Button */}
          {selectedLocation && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#3B82F6']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color={colors.LIGHT_SKY} />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </Animated.View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  mapContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 0,
  },
  map: {
    flex: 1,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPin: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#EF4444',
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.65,
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 16,
    zIndex: 100,
  },
  scrollContainer: {
    padding: 16,
    paddingBottom: 20,
  },
  locationCard: {
    padding: 16,
    marginBottom: 12,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  locationTitle: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: 'bold',
  },
  locationInfo: {
    gap: 8,
  },
  locationAddress: {
    color: colors.LIGHT_SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  locationCoords: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  coordsText: {
    color: SKY,
    fontSize: 12,
  },
  locationPlaceholder: {
    color: '#9CA3AF',
    fontSize: 14,
    fontStyle: 'italic',
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: colors.LIGHT_SKY,
    fontSize: 18,
    fontWeight: 'bold',
  },
  offersCard: {
    padding: 16,
    marginTop: 8,
  },
  offersHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 2,
  },
  offersTitle: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: 'bold',
  },
  offersSubtitle: {
    color: SKY,
    fontSize: 11,
    marginBottom: 12,
    marginTop: 2,
  },
  toggleContainer: {
    gap: 12,
    marginBottom: 12,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  toggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  toggleTextContainer: {
    flex: 1,
  },
  toggleLabel: {
    color: colors.LIGHT_SKY,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  toggleDescription: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  discountBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16,185,129,0.15)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  discountText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  priceSummary: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  priceLabel: {
    color: '#9CA3AF',
    fontSize: 12,
    marginBottom: 8,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  originalPrice: {
    color: '#9CA3AF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  discountPrice: {
    color: '#10B981',
    fontSize: 20,
    fontWeight: 'bold',
  },
  discountTag: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  discountTagText: {
    color: colors.LIGHT_SKY,
    fontSize: 12,
    fontWeight: 'bold',
  },
  priceBreakdown: {
    marginTop: 8,
    gap: 4,
  },
  breakdownText: {
    color: '#9CA3AF',
    fontSize: 11,
  },
  surgeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  surgeBadgeText: {
    color: '#F59E0B',
    fontSize: 10,
    fontWeight: '600',
  },
});

