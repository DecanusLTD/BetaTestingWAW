import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { supabase } from '../../../../src/lib/supabase';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

type TierId = 'bronze-wash' | 'silver-wash' | 'gold-wash' | 'platinum-wash';

type ServiceUI = {
  id: TierId;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number; // base price for the tier
  is_enabled: boolean;
};

const TIERS: Array<{
  id: TierId;
  service_name: 'Bronze Wash' | 'Silver Wash' | 'Gold Wash' | 'Platinum Wash';
  defaultDesc: string;
  defaultMinutes: number;
}> = [
  {
    id: 'bronze-wash',
    service_name: 'Bronze Wash',
    defaultDesc: 'Quick wash to get you shining again.',
    defaultMinutes: 30,
  },
  {
    id: 'silver-wash',
    service_name: 'Silver Wash',
    defaultDesc: 'More detail, extra attention on finish.',
    defaultMinutes: 45,
  },
  {
    id: 'gold-wash',
    service_name: 'Gold Wash',
    defaultDesc: 'Deep clean with premium touches.',
    defaultMinutes: 60,
  },
  {
    id: 'platinum-wash',
    service_name: 'Platinum Wash',
    defaultDesc: 'Full works. Highest detail and finish.',
    defaultMinutes: 90,
  },
];

function money(n: any) {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;

  const [selectedService, setSelectedService] = useState<TierId | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadTierPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  const loadTierPrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      // Pull enabled tiers for this location
      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      // Map DB -> UI tiers
      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      // Build UI list, only show tiers that exist in DB (or fallback to showing all with 0?)
      const built: ServiceUI[] = TIERS.map((t) => {
        const hit = map.get(t.service_name);
        const minutes = hit?.minutes ? hit.minutes : t.defaultMinutes;
        const durText = `${minutes} min`;
        return {
          id: t.id,
          name: t.service_name,
          desc: t.defaultDesc,
          minutes,
          dur: durText,
          price: hit?.price ?? 0,
          is_enabled: hit?.enabled ?? false,
        };
      }).filter((s) => s.is_enabled); // only show enabled

      setServices(built);

      // If selected service got disabled, reset selection
      setSelectedService((prev) => {
        if (!prev) return prev;
        const stillThere = built.some((b) => b.id === prev);
        return stillThere ? prev : null;
      });
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadTierPrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: TierId) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    // Reset wash type when service changes
    if (serviceId !== 'bronze-wash') setWashType(null);
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  // Bronze wash type pricing rules (adjust to taste)
  const bronzeExteriorPrice = selectedServiceData?.price ?? 0;
  const bronzeInteriorPrice = selectedServiceData?.price ?? 0;
  const bronzeBothPrice = selectedServiceData?.price ? Math.round(selectedServiceData.price * 1.5 * 100) / 100 : 0;

  const canContinue =
    !!selectedService &&
    !!locationId &&
    !!vehicleId &&
    (selectedService !== 'bronze-wash' || !!washType);

  const handleContinue = async () => {
    if (!canContinue) return;

    // if somehow we don't have a price, stop them (so you don't create £0 bookings)
    if (!selectedServiceData || !Number.isFinite(selectedServiceData.price) || selectedServiceData.price <= 0) {
      Alert.alert('Unavailable', 'This service doesn’t have a price set yet. Please pick another option.');
      return;
    }

    await hapticFeedback('medium');

    // compute final price to pass forward (optional, but useful)
    let finalPrice = selectedServiceData.price;
    if (selectedService === 'bronze-wash') {
      if (washType === 'both') finalPrice = bronzeBothPrice;
      else if (washType === 'interior') finalPrice = bronzeInteriorPrice;
      else finalPrice = bronzeExteriorPrice;
    }

    router.push({
      pathname: '/owner/booking/physical/schedule',
      params: {
        serviceId: selectedService,
        vehicleId,
        locationId,
        washType: washType || '',
        price: String(finalPrice),
      },
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Select Service" />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Select Service" />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadTierPrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#3B82F6']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Select Service" />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn’t enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Select Service" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Service</Text>
            <Text style={styles.sectionSubtitle}>Prices are set by the business</Text>

            <View style={styles.serviceGrid}>
              {services.map((service, index) => {
                const isSelected = selectedService === service.id;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      {
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      accountType="customer"
                      borderColor={isSelected ? SKY : 'rgba(135,206,235,0.3)'}
                    >
                      <View style={styles.serviceContent}>
                        <View style={styles.serviceIconWrapper}>
                          <Ionicons name="water" size={26} color={SKY} />
                        </View>

                        <View style={styles.serviceDetails}>
                          <Text style={[styles.serviceName, isSelected && { color: SKY }]} numberOfLines={1}>
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={SKY} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>

                        <View style={styles.priceColumn}>
                          <Text style={styles.priceLabel}>Price</Text>
                          <Text style={[styles.servicePriceText, isSelected && { color: SKY }]}>
                            £{service.price.toFixed(2)}
                          </Text>
                        </View>

                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {/* Wash Type Selection for Bronze Wash */}
          {selectedService === 'bronze-wash' && selectedServiceData && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Select Wash Type</Text>
              <Text style={styles.sectionSubtitle}>Choose what you'd like cleaned</Text>

              <View style={styles.washTypeGrid}>
                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('exterior')}
                  style={[styles.washTypeCard, washType === 'exterior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'exterior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons
                      name="car-sport-outline"
                      size={32}
                      color={washType === 'exterior' ? SKY : '#9CA3AF'}
                    />
                    <Text style={[styles.washTypeTitle, washType === 'exterior' && { color: SKY }]}>
                      Exterior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{bronzeExteriorPrice.toFixed(2)}</Text>
                  </View>
                  {washType === 'exterior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('interior')}
                  style={[styles.washTypeCard, washType === 'interior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'interior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons name="home-outline" size={32} color={washType === 'interior' ? SKY : '#9CA3AF'} />
                    <Text style={[styles.washTypeTitle, washType === 'interior' && { color: SKY }]}>
                      Interior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{bronzeInteriorPrice.toFixed(2)}</Text>
                  </View>
                  {washType === 'interior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('both')}
                  style={[styles.washTypeCard, washType === 'both' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'both' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons
                      name="sparkles-outline"
                      size={32}
                      color={washType === 'both' ? SKY : '#9CA3AF'}
                    />
                    <Text style={[styles.washTypeTitle, washType === 'both' && { color: SKY }]}>Both</Text>
                    <Text style={styles.washTypePrice}>£{bronzeBothPrice.toFixed(2)}</Text>
                    <View style={styles.premiumBadge}>
                      <Text style={styles.premiumBadgeText}>Premium</Text>
                    </View>
                  </View>
                  {washType === 'both' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}

          {canContinue && (
            <Animated.View style={{ opacity: fadeAnim, transform: [{ scale: fadeAnim }] }}>
              <TouchableOpacity onPress={handleContinue} style={styles.continueButton} activeOpacity={0.8}>
                <LinearGradient colors={[SKY, '#3B82F6']} style={styles.continueGradient}>
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  content: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },

  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },

  section: { marginBottom: 32 },
  sectionTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
  sectionSubtitle: { color: SKY, fontSize: 14, marginBottom: 20, opacity: 0.8 },

  serviceGrid: { gap: 16 },
  serviceCardWrapper: { width: '100%' },
  serviceCard: { padding: 16 },
  serviceCardSelected: { elevation: 12, shadowColor: SKY, shadowOpacity: 0.4 },

  serviceContent: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  serviceIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceDetails: { flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'left', flexShrink: 1 },
  serviceDesc: { color: '#E5E7EB', fontSize: 12, marginBottom: 10, textAlign: 'left', lineHeight: 16, flexShrink: 1 },
  serviceMeta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 0 },
  serviceMetaText: { color: SKY, fontSize: 10 },

  priceColumn: { alignItems: 'flex-end', justifyContent: 'center', minWidth: 86 },
  priceLabel: { color: '#94A3B8', fontSize: 12, marginBottom: 4 },
  servicePriceText: { color: '#F9FAFB', fontSize: 16, fontWeight: 'bold' },

  selectedBadge: { position: 'absolute', top: 12, right: 12, width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },

  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, paddingHorizontal: 32, gap: 8 },
  continueText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },

  washTypeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  washTypeCard: {
    flex: 1,
    minWidth: (width - 52) / 3,
    borderRadius: 16,
    padding: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    position: 'relative',
  },
  washTypeCardSelected: { borderColor: SKY, elevation: 8, shadowColor: SKY, shadowOpacity: 0.4 },
  washTypeContent: { alignItems: 'center', gap: 8 },
  washTypeTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '600', textAlign: 'center' },
  washTypePrice: { color: SKY, fontSize: 16, fontWeight: 'bold' },

  premiumBadge: { marginTop: 4, backgroundColor: SKY + '20', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  premiumBadgeText: { color: SKY, fontSize: 10, fontWeight: '600' },
});
