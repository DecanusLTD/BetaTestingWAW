import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { colors } from '../../src/constants/colors';
import { customerTheme } from '../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'tipped'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'tipped',
  'closed',
  'archived',
  'complete',
]);

const ACTIVE_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

export default function WashHistory() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const [activeBookings, setActiveBookings] = useState<NormalizedCompletion[]>([]);
  const scrollY = useRef(new Animated.Value(0)).current;

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  // ✅ Schema-safe mapping for your `public.bookings`
  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null, // not in schema
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null, // not in schema
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // -------------------------
      // Completed bookings (history)
      // -------------------------
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `
          id,
          user_id,
          status,
          service_name,
          service_type,
          wash_type,
          price,
          scheduled_at,
          created_at,
          completed_at,
          valeter_name,
          location_address,
          location_lat,
          location_lng,
          rating,
          customer_review,
          tip_amount,
          special_instructions,
          cancelled_at
        `
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        // completed_at is the main signal, but allow status=completed too
        .or('completed_at.not.is.null,status.eq.completed')
        .order('completed_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const completedList = normalizeFromBookings(completedRows || [])
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);

      setWashCompletions(completedList);

      // -------------------------
      // Active bookings
      // -------------------------
      const { data: activeRows, error: activeError } = await supabase
        .from('bookings')
        .select(
          `
          id,
          user_id,
          status,
          service_name,
          service_type,
          wash_type,
          price,
          scheduled_at,
          created_at,
          valeter_name,
          location_address,
          location_lat,
          location_lng,
          special_instructions,
          cancelled_at,
          completed_at
        `
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .is('completed_at', null)
        .order('created_at', { ascending: false })
        .limit(50);

      if (activeError) throw activeError;

      const activeFiltered = (activeRows || []).filter((r: any) =>
        ACTIVE_STATUSES.includes(r.status)
      );

      setActiveBookings(normalizeFromBookings(activeFiltered));
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const formatStatusLabel = (status: string) =>
    (status || '')
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();

    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="History"
        scrollY={scrollY}
        rightAction={
          <TouchableOpacity onPress={() => router.push('/owner/booking')} style={styles.bookButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {activeBookings.length === 0 && washCompletions.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="time-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No bookings yet</Text>
            <Text style={styles.emptySubtitle}>Active and completed bookings will appear here.</Text>
            <TouchableOpacity style={styles.bookButtonCard} onPress={() => router.push('/owner/booking')}>
              <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.bookButtonGradient}>
                <Ionicons name="add" size={20} color={colors.LIGHT_SKY} />
                <Text style={styles.bookButtonText}>Book a Service</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {activeBookings.length > 0 && (
              <View style={{ width: '100%', marginBottom: 12 }}>
                <Text style={styles.sectionHeading}>Active bookings</Text>
                {activeBookings.map((booking) => {
                  const isHighlighted = highlightId === booking.id;
                  const serviceName = booking.serviceName ?? booking.service_type ?? 'Car Wash';
                  const occursAt = booking.scheduledAt ?? booking.createdAt;
                  const valeterName = booking.valeterName;
                  const address = booking.address;

                  return (
                    <View
                      key={`active-${booking.id}`}
                      style={[styles.bookingCard, styles.activeCard, isHighlighted && styles.highlightCard]}
                    >
                      <View style={styles.bookingContent}>
                        <View style={styles.bookingHeader}>
                          <View style={styles.bookingIconWrapper}>
                            <Ionicons name="time" size={20} color="#87CEEB" />
                          </View>
                          <View style={styles.bookingInfo}>
                            <Text style={styles.bookingService}>{serviceName}</Text>
                            <Text style={styles.bookingDate}>{formatDate(occursAt)}</Text>
                          </View>
                          <View style={styles.statusBadge}>
                            <Text style={styles.statusText}>{formatStatusLabel(booking.status)}</Text>
                          </View>
                        </View>

                        <View style={styles.bookingFooter}>
                          <View style={styles.bookingMeta}>
                            {valeterName && (
                              <View style={styles.metaItem}>
                                <Ionicons name="person" size={14} color="#87CEEB" />
                                <Text style={styles.metaText}>{valeterName}</Text>
                              </View>
                            )}
                            {address && (
                              <View style={styles.metaItem}>
                                <Ionicons name="location-outline" size={14} color="#87CEEB" />
                                <Text style={styles.metaText} numberOfLines={1}>
                                  {address}
                                </Text>
                              </View>
                            )}
                          </View>

                          <Text style={styles.bookingPrice}>{formatCurrency(booking.price)}</Text>
                        </View>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}

            {washCompletions.length > 0 && (
              <View style={{ width: '100%' }}>
                <Text style={styles.sectionHeading}>
                  {activeBookings.length > 0 ? 'Completed washes' : 'Completed history'}
                </Text>

                {washCompletions.map((completion) => {
                  const isHighlighted = highlightId === completion.id;
                  const serviceName = completion.serviceName ?? completion.service_type ?? 'Car Wash';
                  const price = completion.price ?? 0;
                  const valeterName = completion.valeterName;
                  const address = completion.address;

                  return (
                    <View key={completion.id} style={[styles.bookingCard, isHighlighted && styles.highlightCard]}>
                      <View style={styles.bookingContent}>
                        <View style={styles.bookingHeader}>
                          <View style={styles.bookingIconWrapper}>
                            <Ionicons name="car-sport" size={20} color="#87CEEB" />
                          </View>

                          <View style={styles.bookingInfo}>
                            <Text style={styles.bookingService}>{serviceName}</Text>
                            <Text style={styles.bookingDate}>
                              {formatDate(completion.completedAt ?? completion.createdAt)}
                            </Text>
                          </View>

                          {completion.rating != null && (
                            <View style={styles.ratingBadge}>
                              <Ionicons name="star" size={14} color="#F59E0B" />
                              <Text style={styles.ratingText}>{completion.rating}</Text>
                            </View>
                          )}
                        </View>

                        <View style={styles.bookingFooter}>
                          <View style={styles.bookingMeta}>
                            {valeterName && (
                              <View style={styles.metaItem}>
                                <Ionicons name="person" size={14} color="#87CEEB" />
                                <Text style={styles.metaText}>{valeterName}</Text>
                              </View>
                            )}
                            {address && (
                              <View style={styles.metaItem}>
                                <Ionicons name="location-outline" size={14} color="#87CEEB" />
                                <Text style={styles.metaText} numberOfLines={1}>
                                  {address}
                                </Text>
                              </View>
                            )}
                          </View>

                          <Text style={styles.bookingPrice}>{formatCurrency(price)}</Text>
                        </View>

                        <TouchableOpacity
                          style={styles.repeatButton}
                          onPress={() => handleRepeatBooking(completion)}
                          activeOpacity={0.7}
                        >
                          <Ionicons name="repeat" size={16} color="#10B981" />
                          <Text style={styles.repeatButtonText}>Repeat Booking</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },

  bookButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },

  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },

  sectionHeading: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },

  bookButtonCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  bookButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  bookButtonText: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: '700',
  },

  bookingCard: {
    borderRadius: 16,
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  activeCard: {
    borderColor: 'rgba(135,206,235,0.5)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  highlightCard: {
    borderColor: SKY,
    shadowColor: SKY,
    shadowOpacity: 0.45,
    shadowRadius: 10,
  },

  bookingContent: { padding: 16 },
  bookingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  bookingIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  bookingInfo: { flex: 1 },
  bookingService: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  bookingDate: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },

  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  ratingText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },

  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '700',
  },

  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookingMeta: {
    flexDirection: 'row',
    gap: 12,
    flex: 1,
    paddingRight: 10,
  },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4, flex: 1 },
  metaText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    flexShrink: 1,
  },

  bookingPrice: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
  },

  repeatButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginTop: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  repeatButtonText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '600',
  },
});