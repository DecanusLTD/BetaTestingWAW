export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'admin' | 'moderator';
  permissions: string[];
  organizationId?: string;
}

export interface DocumentApproval {
  id: string;
  valeterId: string;
  valeterName: string;
  documentType: string;
  documentName: string;
  submittedAt: Date;
  status: 'pending' | 'approved' | 'rejected';
  adminId?: string;
  adminName?: string;
  reviewedAt?: Date;
  rejectionReason?: string;
  fileUrl?: string;
}

export interface ValeterApprovalStatus {
  valeterId: string;
  valeterName: string;
  email: string;
  organizationName?: string;
  documentsPending: number;
  documentsApproved: number;
  documentsRejected: number;
  canGoOnline: boolean;
  isOnline: boolean;
  lastActivity: Date;
  overallStatus: 'pending' | 'approved' | 'rejected' | 'online';
}

export class AdminApprovalService {
  private static instance: AdminApprovalService;
  private adminUsers: Map<string, AdminUser> = new Map();
  private documentApprovals: Map<string, DocumentApproval> = new Map();
  private valeterApprovalStatuses: Map<string, ValeterApprovalStatus> = new Map();
  private adminsLoaded: boolean = false;

  static getInstance(): AdminApprovalService {
    if (!AdminApprovalService.instance) {
      AdminApprovalService.instance = new AdminApprovalService();
    }
    return AdminApprovalService.instance;
  }

  constructor() {
    // Load admins from database on first use
  }

  private async loadAdminUsers(): Promise<void> {
    if (this.adminsLoaded) return;

    try {
      const { supabase } = await import('../lib/supabase');
      const { data: users, error } = await supabase
        .from('users')
        .select('id, name, email, user_type, organization_id')
        .eq('user_type', 'super_admin');

      if (error) {
        console.warn('[AdminApprovalService] Error loading admins:', error);
        return;
      }

      if (users) {
        users.forEach(user => {
          const permissions = this.getPermissionsForRole(user.user_type as any);
          const admin: AdminUser = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.user_type === 'super_admin' ? 'super_admin' : 'admin',
            permissions,
            organizationId: user.organization_id || undefined,
          };
      this.adminUsers.set(admin.id, admin);
    });
        this.adminsLoaded = true;
      }
    } catch (error) {
      console.error('[AdminApprovalService] Error loading admins:', error);
    }
  }

  private getPermissionsForRole(role: string): string[] {
    if (role === 'super_admin') {
      return ['approve_documents', 'manage_valeters', 'view_all_organizations', 'system_settings'];
    }
    return ['approve_documents', 'manage_valeters'];
  }

  // Admin authentication
  async authenticateAdmin(email: string, password: string): Promise<AdminUser | null> {
    await this.loadAdminUsers();
    const admin = Array.from(this.adminUsers.values()).find(a => a.email === email);
    if (admin) {
      // Password verification should be handled by Supabase Auth
      // This method should be called after successful Supabase auth
      return admin;
    }
    return null;
  }

  // Get all pending document approvals
  getPendingApprovals(): DocumentApproval[] {
    return Array.from(this.documentApprovals.values())
      .filter(approval => approval.status === 'pending')
      .sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
  }

  // Get valeter approval status
  getValeterApprovalStatus(valeterId: string): ValeterApprovalStatus | null {
    return this.valeterApprovalStatuses.get(valeterId) || null;
  }

  // Get all valeter approval statuses
  getAllValeterApprovalStatuses(): ValeterApprovalStatus[] {
    return Array.from(this.valeterApprovalStatuses.values())
      .sort((a, b) => b.lastActivity.getTime() - a.lastActivity.getTime());
  }

  // Approve a document
  approveDocument(approvalId: string, adminId: string, adminName: string): boolean {
    const approval = this.documentApprovals.get(approvalId);
    if (!approval || approval.status !== 'pending') {
      return false;
    }

    approval.status = 'approved';
    approval.adminId = adminId;
    approval.adminName = adminName;
    approval.reviewedAt = new Date();

    // Update valeter approval status
    this.updateValeterApprovalStatus(approval.valeterId);

    return true;
  }

  // Reject a document
  rejectDocument(approvalId: string, adminId: string, adminName: string, reason: string): boolean {
    const approval = this.documentApprovals.get(approvalId);
    if (!approval || approval.status !== 'pending') {
      return false;
    }

    approval.status = 'rejected';
    approval.adminId = adminId;
    approval.adminName = adminName;
    approval.reviewedAt = new Date();
    approval.rejectionReason = reason;

    // Update valeter approval status
    this.updateValeterApprovalStatus(approval.valeterId);

    return true;
  }

  // Allow valeter to go online
  allowValeterOnline(valeterId: string, adminId: string, adminName: string): boolean {
    const status = this.valeterApprovalStatuses.get(valeterId);
    if (!status) {
      return false;
    }

    if (status.documentsPending > 0) {
      return false; // Cannot go online if documents are pending
    }

    status.canGoOnline = true;
    status.overallStatus = 'approved';
    status.lastActivity = new Date();

    return true;
  }

  // Force valeter offline
  forceValeterOffline(valeterId: string, adminId: string, adminName: string, reason?: string): boolean {
    const status = this.valeterApprovalStatuses.get(valeterId);
    if (!status) {
      return false;
    }

    status.canGoOnline = false;
    status.isOnline = false;
    status.overallStatus = 'rejected';
    status.lastActivity = new Date();

    return true;
  }

  // Submit document for approval
  submitDocumentForApproval(
    valeterId: string,
    valeterName: string,
    documentType: string,
    documentName: string,
    fileUrl: string
  ): string {
    const approvalId = `approval-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const approval: DocumentApproval = {
      id: approvalId,
      valeterId,
      valeterName,
      documentType,
      documentName,
      submittedAt: new Date(),
      status: 'pending',
      fileUrl
    };

    this.documentApprovals.set(approvalId, approval);
    this.updateValeterApprovalStatus(valeterId);

    return approvalId;
  }

  // Update valeter approval status
  private updateValeterApprovalStatus(valeterId: string) {
    const approvals = Array.from(this.documentApprovals.values())
      .filter(a => a.valeterId === valeterId);

    const pending = approvals.filter(a => a.status === 'pending').length;
    const approved = approvals.filter(a => a.status === 'approved').length;
    const rejected = approvals.filter(a => a.status === 'rejected').length;

    const canGoOnline = pending === 0 && approved > 0;
    const overallStatus = pending > 0 ? 'pending' : 
                         rejected > 0 ? 'rejected' : 
                         canGoOnline ? 'approved' : 'pending';

    const status: ValeterApprovalStatus = {
      valeterId,
      valeterName: approvals[0]?.valeterName || 'Unknown',
      email: '', // Would be populated from valeter profile
      documentsPending: pending,
      documentsApproved: approved,
      documentsRejected: rejected,
      canGoOnline,
      isOnline: false, // Would be updated from valeter profile
      lastActivity: new Date(),
      overallStatus
    };

    this.valeterApprovalStatuses.set(valeterId, status);
  }

  // Get admin permissions
  async getAdminPermissions(adminId: string): Promise<string[]> {
    await this.loadAdminUsers();
    const admin = this.adminUsers.get(adminId);
    return admin?.permissions || [];
  }

  // Check if admin can perform action
  async canPerformAction(adminId: string, action: string): Promise<boolean> {
    const permissions = await this.getAdminPermissions(adminId);
    return permissions.includes(action);
  }

  // Get admin by ID
  async getAdminById(adminId: string): Promise<AdminUser | null> {
    await this.loadAdminUsers();
    return this.adminUsers.get(adminId) || null;
  }

  // Get all admins
  async getAllAdmins(): Promise<AdminUser[]> {
    await this.loadAdminUsers();
    return Array.from(this.adminUsers.values());
  }
}
