import { supabase } from '../lib/supabase';

export interface ValeterPerformanceStats {
  totalJobs: number;
  experienceMonths: number;
  averageRating: number;
  totalEarnings: number;
  jobsThisMonth: number;
  customerReviews: number;
  onTimePercentage: number;
  cancellationRate: number;
}

export class ValeterStatsService {
  /**
   * Fetch real performance stats for a valeter from the database
   * Updated to work with actual valeter_profiles schema
   */
  static async getValeterStats(userId: string): Promise<ValeterPerformanceStats> {
    try {
      // Fetch all jobs for this valeter
      const { data: jobs, error: jobsError } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', userId)
        .in('status', ['completed', 'cancelled']);

      if (jobsError) throw jobsError;

      // Fetch valeter profile (removed total_earnings since it doesn't exist)
      const { data: valeterProfile, error: profileError } = await supabase
        .from('valeter_profiles')
        .select('created_at') // Only select fields that exist
        .eq('user_id', userId)
        .maybeSingle();

      // If no profile exists (e.g., customer account), return default stats
      if (profileError || !valeterProfile) {
        return {
          totalJobs: 0,
          experienceMonths: 1,
          averageRating: 0,
          totalEarnings: 0,
          jobsThisMonth: 0,
          customerReviews: 0,
          onTimePercentage: 100,
          cancellationRate: 0,
        };
      }

      // Calculate stats
      const completedJobs = jobs?.filter(job => job.status === 'completed') || [];
      const cancelledJobs = jobs?.filter(job => job.status === 'cancelled') || [];
      const totalJobs = completedJobs.length;

      // Calculate experience in months
      const startDate = new Date(valeterProfile?.created_at || Date.now());
      const now = new Date();
      const experienceMonths = Math.max(
        1,
        Math.round((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30))
      );

      // Calculate jobs this month
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const jobsThisMonth = completedJobs.filter(job => {
        const jobDate = new Date(job.completed_at || job.created_at);
        return jobDate >= firstDayOfMonth;
      }).length;

      // Get ratings and reviews from bookings table (rating and review columns)
      const jobsWithRatings = completedJobs.filter(job => job.rating != null);
      const customerReviews = jobsWithRatings.length;
      const averageRating = customerReviews > 0
        ? jobsWithRatings.reduce((sum, job) => sum + (Number(job.rating) || 0), 0) / customerReviews
        : 0;

      // Calculate on-time percentage
      const onTimeJobs = completedJobs.filter(job => {
        if (!job.scheduled_at || !job.completed_at) return true;
        const scheduledTime = new Date(job.scheduled_at);
        const completedTime = new Date(job.completed_at);
        // Consider on-time if completed within 15 minutes of scheduled time
        const diffMinutes = (completedTime.getTime() - scheduledTime.getTime()) / (1000 * 60);
        return Math.abs(diffMinutes) <= 15;
      }).length;

      const onTimePercentage = totalJobs > 0
        ? Math.round((onTimeJobs / totalJobs) * 100)
        : 100;

      // Calculate cancellation rate
      const totalBookings = jobs?.length || 0;
      const cancellationRate = totalBookings > 0
        ? Math.round((cancelledJobs.length / totalBookings) * 100)
        : 0;

      // Calculate total earnings from bookings price column
      const totalEarnings = completedJobs.reduce((sum, job) => {
        return sum + (Number(job.price) || 0);
      }, 0);

      return {
        totalJobs,
        experienceMonths,
        averageRating: Math.round(averageRating * 10) / 10, // Round to 1 decimal
        totalEarnings: Math.round(totalEarnings),
        jobsThisMonth,
        customerReviews,
        onTimePercentage,
        cancellationRate,
      };
    } catch (error) {
      console.error('Error fetching valeter stats:', error);
      // Return default values if error occurs
      return {
        totalJobs: 0,
        experienceMonths: 1,
        averageRating: 0,
        totalEarnings: 0,
        jobsThisMonth: 0,
        customerReviews: 0,
        onTimePercentage: 100,
        cancellationRate: 0,
      };
    }
  }

  /**
   * Update valeter earnings - removed since total_earnings column doesn't exist
   * If you want to track total earnings, you'll need to add this column:
   * ALTER TABLE valeter_profiles ADD COLUMN total_earnings DECIMAL(10,2) DEFAULT 0;
   */
  static async updateEarnings(userId: string, amount: number): Promise<void> {
    try {
      // Since total_earnings column doesn't exist, we can't update it
      // Earnings are calculated on-the-fly from bookings table
    } catch (error) {
      console.error('Error updating earnings:', error);
    }
  }

  /**
   * Record job completion for stats tracking
   * Note: job_completions table doesn't exist in schema, so we just update the booking status
   * The booking's completed_at timestamp is already tracked in the bookings table
   */
  static async recordJobCompletion(
    userId: string,
    bookingId: string,
    isOnTime: boolean
  ): Promise<void> {
    try {
      // Update booking with completion timestamp if not already set
      const { error } = await supabase
        .from('bookings')
        .update({ 
          completed_at: new Date().toISOString(),
          status: 'completed'
        })
        .eq('id', bookingId)
        .eq('valeter_id', userId);

      if (error) {
        console.warn('Error updating booking completion:', error);
      }
    } catch (error) {
      console.error('Error recording job completion:', error);
    }
  }
}