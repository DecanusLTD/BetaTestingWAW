import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Easing,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import BubbleBackground from './shared/BubbleBackground';
import { colors } from '../constants/colors';

const { width, height } = Dimensions.get('window');

interface LoadingScreenProps {
  message?: string;
}

export default function LoadingScreen({ message = "Loading..." }: LoadingScreenProps) {
  const logoScale = useRef(new Animated.Value(1)).current;
  const loadingBarProgress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Logo pulsing animation (scale from 1.0 to 1.1 and back)
    Animated.loop(
      Animated.sequence([
        Animated.timing(logoScale, {
          toValue: 1.1,
          duration: 1000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(logoScale, {
          toValue: 1.0,
          duration: 1000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Loading bar animation (0% to 100% over 2.5 seconds, then loop)
    const animateLoadingBar = () => {
      loadingBarProgress.setValue(0);
      Animated.timing(loadingBarProgress, {
        toValue: 1,
        duration: 2500,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: false, // width animation doesn't support native driver
      }).start(() => {
        animateLoadingBar();
      });
    };
    animateLoadingBar();
  }, [logoScale, loadingBarProgress]);

  const loadingBarWidth = loadingBarProgress.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      {/* Background gradient */}
      <LinearGradient
        colors={[colors.BG, colors.headerBg]}
        style={StyleSheet.absoluteFill}
      />
      
      {/* Bubble background */}
      <BubbleBackground accountType="customer" />

      {/* Main content */}
      <View style={styles.content}>
        {/* Pulsing logo */}
        <Animated.View
          style={[
            styles.logoContainer,
            {
              transform: [
                {
                  scale: logoScale,
                },
              ],
            },
          ]}
        >
          <Image
            source={require('../../assets/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </Animated.View>

        {/* Brand text */}
        <View style={styles.brandContainer}>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish Our Wash</Text>
        </View>

        {/* Loading bar */}
        <View style={styles.loadingBarContainer}>
          <View style={styles.loadingBarBackground}>
            <Animated.View
              style={[
                styles.loadingBarFill,
                {
                  width: loadingBarWidth,
                },
              ]}
            />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    zIndex: 10,
    justifyContent: 'center',
    flex: 1,
  },
  logoContainer: {
    marginBottom: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 120,
    height: 120,
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  brandTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.LIGHT_SKY,
    marginBottom: 8,
  },
  brandSubtitle: {
    fontSize: 14,
    color: colors.SKY,
    textAlign: 'center',
  },
  loadingBarContainer: {
    position: 'absolute',
    bottom: 60,
    width: width * 0.8,
    alignItems: 'center',
  },
  loadingBarBackground: {
    width: '100%',
    height: 4,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  loadingBarFill: {
    height: '100%',
    backgroundColor: colors.SKY,
    borderRadius: 2,
  },
});
