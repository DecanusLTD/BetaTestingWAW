import { supabase } from '../lib/supabase';

export type RadiusColumn = 'working_radius' | 'radius_coverage';

interface WorkingRadiusRow {
  working_radius?: number | null;
}

interface LegacyRadiusRow {
  radius_coverage?: number | null;
}

const LEGACY_COLUMN: RadiusColumn = 'radius_coverage';

async function fetchLegacyRadius(userId: string) {
  try {
    const { data, error } = await supabase
      .from('valeter_profiles')
      .select(`${LEGACY_COLUMN}`)
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      throw error;
    }

    const row = data as LegacyRadiusRow | null;
    const value =
      row && typeof row.radius_coverage === 'number' ? row.radius_coverage : null;
    return { value, column: LEGACY_COLUMN as RadiusColumn };
  } catch (legacyError: any) {
    if (legacyError?.code !== '42703') {
      console.warn('[radiusPreference] legacy fetch error', legacyError);
    }
    return { value: null, column: LEGACY_COLUMN as RadiusColumn };
  }
}

export async function fetchRadiusPreference(userId: string | undefined | null) {
  if (!userId) {
    return { value: null, column: 'working_radius' as RadiusColumn };
  }

  try {
    const { data, error } = await supabase
      .from('valeter_profiles')
      .select('working_radius')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) {
      if (error.code === '42703') {
        return await fetchLegacyRadius(userId);
      }
      throw error;
    }

    const row = data as WorkingRadiusRow | null;
    const value =
      row && typeof row.working_radius === 'number' ? row.working_radius : null;
    return { value, column: 'working_radius' as RadiusColumn };
  } catch (err: any) {
    if (err?.code === '42703') {
      return await fetchLegacyRadius(userId);
    }
    console.warn('[radiusPreference] fetch error', err);
    return { value: null, column: 'working_radius' as RadiusColumn };
  }
}

