// Wash Completion Service for Wish a Wash
export interface WashCompletion {
  id: string;
  bookingId: string;
  valeterId: string;
  customerId: string;
  completedAt: Date;
  photos: string[];
  notes?: string;
  rating?: number;
  tip?: number;
  tipAmount?: number;
  customerReview?: string;
  valeterNotes?: string;
  status: 'completed' | 'rated' | 'tipped';
}

export interface WashRating {
  id: string;
  washCompletionId: string;
  rating: number;
  review: string;
  tipAmount: number;
  createdAt: Date;
}

export class WashCompletionService {
  private static instance: WashCompletionService;
  private washCompletions: WashCompletion[] = [];
  private washRatings: WashRating[] = [];

  private constructor() {
    this.initializeMockData();
  }

  public static getInstance(): WashCompletionService {
    if (!WashCompletionService.instance) {
      WashCompletionService.instance = new WashCompletionService();
    }
    return WashCompletionService.instance;
  }

  private initializeMockData() {
    // Load actual wash completions and ratings from database
    // TODO: Implement actual data loading from Supabase
    this.washCompletions = [];
    this.washRatings = [];
  }

  // Upload wash completion photos
  async uploadWashCompletion(
    bookingId: string,
    valeterId: string,
    customerId: string,
    photos: string[],
    notes?: string
  ): Promise<WashCompletion> {
    const washCompletion: WashCompletion = {
      id: `wc_${Date.now()}`,
      bookingId,
      valeterId,
      customerId,
      completedAt: new Date(),
      photos,
      notes,
      status: 'completed'
    };

    this.washCompletions.push(washCompletion);
    return washCompletion;
  }

  // Get wash completions for a valeter
  async getValeterWashCompletions(valeterId: string): Promise<WashCompletion[]> {
    return this.washCompletions.filter(wc => wc.valeterId === valeterId);
  }

  // Get wash completions for a customer
  async getCustomerWashCompletions(customerId: string): Promise<WashCompletion[]> {
    return this.washCompletions.filter(wc => wc.customerId === customerId);
  }

  // Submit rating and tip
  async submitRating(
    washCompletionId: string,
    rating: number,
    review: string,
    tipAmount: number
  ): Promise<WashRating> {
    const washRating: WashRating = {
      id: `rating_${Date.now()}`,
      washCompletionId,
      rating,
      review,
      tipAmount,
      createdAt: new Date()
    };

    this.washRatings.push(washRating);

    // Update wash completion
    const washCompletion = this.washCompletions.find(wc => wc.id === washCompletionId);
    if (washCompletion) {
      washCompletion.rating = rating;
      washCompletion.tip = tipAmount;
      washCompletion.customerReview = review;
      washCompletion.status = 'tipped';
    }

    return washRating;
  }

  // Get wash completion by ID
  async getWashCompletion(id: string): Promise<WashCompletion | null> {
    return this.washCompletions.find(wc => wc.id === id) || null;
  }

  // Get average rating for a valeter
  async getValeterAverageRating(valeterId: string): Promise<number> {
    const valeterWashes = this.washCompletions.filter(wc => wc.valeterId === valeterId && wc.rating);
    if (valeterWashes.length === 0) return 0;
    
    const totalRating = valeterWashes.reduce((sum, wash) => sum + (wash.rating || 0), 0);
    return Math.round((totalRating / valeterWashes.length) * 10) / 10;
  }

  // Get total tips for a valeter
  async getValeterTotalTips(valeterId: string): Promise<number> {
    const valeterWashes = this.washCompletions.filter(wc => wc.valeterId === valeterId && wc.tipAmount);
    return valeterWashes.reduce((sum, wash) => sum + (wash.tipAmount || 0), 0);
  }
}

export const washCompletionService = WashCompletionService.getInstance();
