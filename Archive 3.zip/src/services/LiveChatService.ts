export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  message: string;
  timestamp: Date;
  type: 'text' | 'quick_reply' | 'system';
}

export interface QuickReply {
  id: string;
  text: string;
  category: string;
}

export interface ChatSession {
  id: string;
  userId: string;
  userType: 'customer' | 'valeter';
  messages: ChatMessage[];
  status: 'active' | 'resolved' | 'closed';
  createdAt: Date;
  resolvedAt?: Date;
  agentId?: string;
}

export class LiveChatService {
  private static instance: LiveChatService;
  private chatSessions: Map<string, ChatSession> = new Map();
  private agentOnline = true; // Simulate agent availability

  // Predefined questions for customers
  private customerQuestions: QuickReply[] = [
    { id: 'cust_1', text: 'How do I book a car wash?', category: 'booking' },
    { id: 'cust_2', text: 'How much does a car wash cost?', category: 'pricing' },
    { id: 'cust_3', text: 'Can I cancel my booking?', category: 'cancellation' },
    { id: 'cust_4', text: 'How do I track my valeter?', category: 'tracking' },
    { id: 'cust_5', text: 'What if I\'m not satisfied with the service?', category: 'complaints' },
    { id: 'cust_6', text: 'How do I add a payment method?', category: 'payment' },
    { id: 'cust_7', text: 'Can I tip my valeter?', category: 'tipping' },
    { id: 'cust_8', text: 'What areas do you cover?', category: 'coverage' },
    { id: 'cust_9', text: 'How long does a car wash take?', category: 'duration' },
    { id: 'cust_10', text: 'What if my valeter doesn\'t show up?', category: 'no_show' },
  ];

  // Predefined questions for valeters
  private valeterQuestions: QuickReply[] = [
    { id: 'val_1', text: 'How do I go online to receive jobs?', category: 'availability' },
    { id: 'val_2', text: 'How do I update my documents?', category: 'documents' },
    { id: 'val_3', text: 'How do I get paid?', category: 'payments' },
    { id: 'val_4', text: 'What if I can\'t complete a job?', category: 'job_issues' },
    { id: 'val_5', text: 'How do I handle difficult customers?', category: 'customer_service' },
    { id: 'val_6', text: 'What equipment do I need?', category: 'equipment' },
    { id: 'val_7', text: 'How do I report an issue with the app?', category: 'technical' },
    { id: 'val_8', text: 'What are the cancellation policies?', category: 'policies' },
    { id: 'val_9', text: 'How do I update my working hours?', category: 'schedule' },
    { id: 'val_10', text: 'What if my vehicle breaks down?', category: 'emergency' },
  ];

  // Predefined responses
  private responses: { [key: string]: string } = {
    // Customer responses
    'cust_1': 'To book a car wash:\n1. Open the app\n2. Tap "Book Service"\n3. Select your vehicle type and service\n4. Choose your location\n5. Add any extras\n6. Confirm booking and payment\n\nA valeter will be assigned to you shortly!',
    'cust_2': 'Our pricing varies based on:\n• Vehicle size (small: £12-£25, large: £20-£45)\n• Service type (exterior only or full valet)\n• Location and demand\n• Add-ons (wax, interior clean, etc.)\n\nPrices are clearly shown before booking!',
    'cust_3': 'Yes, you can cancel your booking:\n• Within 5 minutes: 100% refund\n• Within 15 minutes: 90% refund\n• Within 30 minutes: 75% refund\n• Within 1 hour: 50% refund\n• After 2 hours: No refund\n\nGo to your booking details to cancel.',
    'cust_4': 'Track your valeter:\n1. Open your active booking\n2. Tap "Track Service"\n3. You\'ll see their real-time location\n4. Estimated arrival time is shown\n5. You can call or message them directly',
    'cust_5': 'If you\'re not satisfied:\n1. Contact us immediately\n2. Take photos if possible\n3. We\'ll investigate and resolve\n4. Full refund if service was poor\n5. We may offer a free re-wash\n\nYour satisfaction is our priority!',
    'cust_6': 'Add payment method:\n1. Go to Profile → Payment Methods\n2. Tap "Add Payment Method"\n3. Enter card details\n4. Save for future bookings\n\nWe accept Visa, Mastercard, and Apple Pay.',
    'cust_7': 'Yes! You can tip your valeter:\n• After service completion\n• Rate your experience (1-5 stars)\n• Add a tip amount\n• Tips go directly to the valeter\n\nTipping is optional but appreciated!',
    'cust_8': 'We currently cover:\n• London (all areas)\n• Manchester\n• Birmingham\n• Liverpool\n• Leeds\n• Edinburgh\n• Glasgow\n• Bristol\n• Cardiff\n\nMore cities coming soon!',
    'cust_9': 'Service duration:\n• Quick wash: 15-20 minutes\n• Standard wash: 25-35 minutes\n• Full valet: 40-60 minutes\n• Luxury service: 45-90 minutes\n\nTimes may vary based on vehicle size.',
    'cust_10': 'If valeter doesn\'t show:\n1. Wait 15 minutes past scheduled time\n2. Contact us via chat or call\n3. We\'ll find you another valeter\n4. Or offer full refund\n5. Apologize for the inconvenience',

    // Valeter responses
    'val_1': 'To go online:\n1. Open the valeter app\n2. Tap "Go Online" button\n3. Ensure all documents are verified\n4. Set your working area\n5. You\'ll receive job notifications\n\nMake sure you\'re in your working area!',
    'val_2': 'Update documents:\n1. Go to Profile → Documents\n2. Tap the document to update\n3. Upload new file\n4. Wait for verification (24-48 hours)\n5. You\'ll be notified when approved\n\nKeep documents current to stay active!',
    'val_3': 'Payment process:\n• Payments processed weekly\n• Minimum £50 payout\n• Direct bank transfer\n• 80% of job price goes to you\n• 20% platform fee\n• Tips are 100% yours\n\nPayments arrive every Friday!',
    'val_4': 'If you can\'t complete:\n1. Contact customer immediately\n2. Explain the situation\n3. Contact support if needed\n4. We\'ll help resolve\n5. May need to cancel job\n\nCommunication is key!',
    'val_5': 'Difficult customers:\n1. Stay professional and calm\n2. Listen to their concerns\n3. Offer solutions\n4. Contact support if needed\n5. Document any issues\n\nWe\'re here to support you!',
    'val_6': 'Required equipment:\n• Professional car wash supplies\n• Microfiber cloths\n• Vacuum cleaner\n• Water source access\n• Mobile phone with app\n• Professional appearance\n\nQuality equipment = happy customers!',
    'val_7': 'Report app issues:\n1. Go to Profile → Help & Support\n2. Select "Report Issue"\n3. Describe the problem\n4. Include screenshots if possible\n5. We\'ll investigate quickly\n\nWe appreciate your feedback!',
    'val_8': 'Cancellation policies:\n• 30 minutes notice required\n• Emergency cancellations accepted\n• Too many cancellations may affect status\n• Communicate with customers\n• Contact support for issues\n\nBe reliable and professional!',
    'val_9': 'Update working hours:\n1. Go to Profile → Availability\n2. Set your preferred hours\n3. Update daily if needed\n4. Set your working radius\n5. Save changes\n\nFlexible scheduling available!',
    'val_10': 'Vehicle breakdown:\n1. Contact customer immediately\n2. Explain the situation\n3. Contact support\n4. We\'ll help reschedule\n5. May need to cancel job\n\nSafety and communication first!',
  };

  static getInstance(): LiveChatService {
    if (!LiveChatService.instance) {
      LiveChatService.instance = new LiveChatService();
    }
    return LiveChatService.instance;
  }

  // Start a new chat session
  startChat(userId: string, userType: 'customer' | 'valeter'): string {
    const sessionId = `chat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const session: ChatSession = {
      id: sessionId,
      userId,
      userType,
      messages: [
        {
          id: `msg_${Date.now()}`,
          sender: 'agent',
          message: `Hello! Welcome to Wish a Wash support. I'm here to help you with any questions about ${userType === 'customer' ? 'booking car wash services' : 'providing valeting services'}. How can I assist you today?`,
          timestamp: new Date(),
          type: 'text'
        }
      ],
      status: 'active',
      createdAt: new Date(),
      agentId: this.agentOnline ? 'agent_001' : undefined
    };

    this.chatSessions.set(sessionId, session);
    return sessionId;
  }

  // Get chat session
  getChatSession(sessionId: string): ChatSession | undefined {
    return this.chatSessions.get(sessionId);
  }

  // Send message
  sendMessage(sessionId: string, message: string): boolean {
    const session = this.chatSessions.get(sessionId);
    if (!session) return false;

    // Add user message
    session.messages.push({
      id: `msg_${Date.now()}`,
      sender: 'user',
      message,
      timestamp: new Date(),
      type: 'text'
    });

    // Simulate agent response
    setTimeout(() => {
      this.sendAgentResponse(sessionId, message);
    }, 1000);

    this.chatSessions.set(sessionId, session);
    return true;
  }

  // Send quick reply
  sendQuickReply(sessionId: string, questionId: string): boolean {
    const session = this.chatSessions.get(sessionId);
    if (!session) return false;

    const question = this.getQuestionById(questionId, session.userType);
    if (!question) return false;

    // Add user message
    session.messages.push({
      id: `msg_${Date.now()}`,
      sender: 'user',
      message: question.text,
      timestamp: new Date(),
      type: 'quick_reply'
    });

    // Send agent response
    setTimeout(() => {
      this.sendAgentResponse(sessionId, questionId);
    }, 1000);

    this.chatSessions.set(sessionId, session);
    return true;
  }

  // Get quick reply questions
  getQuickReplies(userType: 'customer' | 'valeter'): QuickReply[] {
    return userType === 'customer' ? this.customerQuestions : this.valeterQuestions;
  }

  // Get question by ID
  private getQuestionById(questionId: string, userType: 'customer' | 'valeter'): QuickReply | undefined {
    const questions = userType === 'customer' ? this.customerQuestions : this.valeterQuestions;
    return questions.find(q => q.id === questionId);
  }

  // Send agent response
  private sendAgentResponse(sessionId: string, userMessage: string): void {
    const session = this.chatSessions.get(sessionId);
    if (!session) return;

    let response = 'Thank you for your message. I\'ll help you with that.';

    // Check if it's a predefined question
    if (this.responses[userMessage]) {
      response = this.responses[userMessage];
    } else {
      // Generate generic response based on keywords
      const lowerMessage = userMessage.toLowerCase();
      if (lowerMessage.includes('payment') || lowerMessage.includes('money')) {
        response = 'For payment-related questions, please check our payment policies in the app. If you need specific help, I can connect you with our billing team.';
      } else if (lowerMessage.includes('cancel') || lowerMessage.includes('refund')) {
        response = 'For cancellations and refunds, please check our cancellation policy in the app. Most refunds are processed within 24-48 hours.';
      } else if (lowerMessage.includes('technical') || lowerMessage.includes('app')) {
        response = 'For technical issues, please try restarting the app. If the problem persists, I can escalate this to our technical team.';
      } else if (lowerMessage.includes('emergency') || lowerMessage.includes('urgent')) {
        response = 'For urgent matters, please call our emergency support line at 0800-WASH-HELP. We\'re available 24/7 for critical issues.';
      }
    }

    session.messages.push({
      id: `msg_${Date.now()}`,
      sender: 'agent',
      message: response,
      timestamp: new Date(),
      type: 'text'
    });

    this.chatSessions.set(sessionId, session);
  }

  // Close chat session
  closeChat(sessionId: string): boolean {
    const session = this.chatSessions.get(sessionId);
    if (!session) return false;

    session.status = 'closed';
    session.messages.push({
      id: `msg_${Date.now()}`,
      sender: 'agent',
      message: 'Thank you for contacting Wish a Wash support. If you have any more questions, feel free to start a new chat. Have a great day!',
      timestamp: new Date(),
      type: 'text'
    });

    this.chatSessions.set(sessionId, session);
    return true;
  }

  // Get user's chat history
  getUserChatHistory(userId: string): ChatSession[] {
    return Array.from(this.chatSessions.values())
      .filter(session => session.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Check if agent is online
  isAgentOnline(): boolean {
    return this.agentOnline;
  }

  // Get chat statistics
  getChatStats(): {
    totalSessions: number;
    activeSessions: number;
    resolvedSessions: number;
    averageResponseTime: number;
  } {
    const sessions = Array.from(this.chatSessions.values());
    const active = sessions.filter(s => s.status === 'active').length;
    const resolved = sessions.filter(s => s.status === 'resolved').length;

    return {
      totalSessions: sessions.length,
      activeSessions: active,
      resolvedSessions: resolved,
      averageResponseTime: 1.5 // Simulated average response time in seconds
    };
  }
}

export const liveChatService = LiveChatService.getInstance();

