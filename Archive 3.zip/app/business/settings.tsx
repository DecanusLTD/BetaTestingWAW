import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function BusinessSettings() {
  const { user, logout } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    setLoading(false);
  }, [user?.id]);

  const handleLogout = async () => {
    if (loggingOut) return;

    Alert.alert(
      'Log out?',
      'You’ll need to sign in again to access your business account.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log out',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoggingOut(true);
              await hapticFeedback('medium');
              await logout();
              // Take them back to standard login (adjust route if your app uses a different one)
              router.replace('/auth/login' as any);
            } catch (e: any) {
              console.error('[BusinessSettings] logout error:', e);
              Alert.alert('Error', e?.message || 'Failed to log out. Please try again.');
            } finally {
              setLoggingOut(false);
            }
          },
        },
      ]
    );
  };

  const settingsSections = [
    {
      title: 'Business Profile',
      items: [
        {
          id: 'profile',
          label: 'Business Information',
          icon: 'business',
          route: '/business/profile',
          color: '#3B82F6',
        },
        {
          id: 'locations',
          label: 'Manage Locations',
          icon: 'location',
          route: '/business/locations',
          color: '#10B981',
        },
        {
          id: 'services',
          label: 'Services Configuration',
          icon: 'construct',
          route: '/business/services',
          color: '#F59E0B',
        },
      ],
    },
    {
      title: 'Team & Operations',
      items: [
        {
          id: 'team',
          label: 'Team Management',
          icon: 'people',
          route: '/business/team',
          color: '#8B5CF6',
        },
        {
          id: 'time-tracking',
          label: 'Time Tracking',
          icon: 'time',
          route: '/business/time-tracking',
          color: '#EC4899',
        },
        {
          id: 'earnings',
          label: 'Earnings & Payouts',
          icon: 'cash',
          route: '/business/earnings',
          color: '#10B981',
        },
      ],
    },
    {
      title: 'Policies & Legal',
      items: [
        {
          id: 'terms',
          label: 'Terms Agreement',
          icon: 'document-text',
          route: '/auth/terms-agreement',
          color: '#6B7280',
        },
        {
          id: 'coverage',
          label: 'Damage Coverage Policy',
          icon: 'shield-checkmark',
          route: '/business/coverage',
          color: '#EF4444',
        },
        {
          id: 'issues',
          label: 'Reports & Issues',
          icon: 'alert-circle',
          route: '/business/issues',
          color: '#F59E0B',
        },
      ],
    },
    {
      title: 'Preferences',
      items: [
        {
          id: 'notifications',
          label: 'Notification Settings',
          icon: 'notifications',
          route: '/business/notifications',
          color: '#3B82F6',
        },
        {
          id: 'privacy',
          label: 'Privacy Settings',
          icon: 'lock-closed',
          route: '/business/privacy',
          color: '#8B5CF6',
        },
      ],
    },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Settings" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading settings...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Settings"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {settingsSections.map((section, sectionIndex) => (
          <Animated.View
            key={section.title}
            style={[
              styles.section,
              { opacity: fadeAnim },
              {
                transform: [
                  {
                    translateY: fadeAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [30 + sectionIndex * 10, 0],
                    }),
                  },
                ],
              },
            ]}
          >
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.itemsContainer}>
              {section.items.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push(item.route as any);
                  }}
                  style={styles.itemWrapper}
                  activeOpacity={0.9}
                >
                  <GlassCard style={styles.itemCard} borderColor={`${item.color}40`}>
                    <View style={styles.itemContent}>
                      <View style={[styles.itemIconWrapper, { backgroundColor: `${item.color}25` }]}>
                        <Ionicons name={item.icon as any} size={24} color={item.color} />
                      </View>
                      <Text style={styles.itemLabel}>{item.label}</Text>
                      <Ionicons name="chevron-forward" size={20} color={SKY} />
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        ))}

        {/* Logout */}
        <Animated.View
          style={[
            styles.section,
            { opacity: fadeAnim },
            {
              transform: [
                {
                  translateY: fadeAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [45, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <Text style={styles.sectionTitle}>Account</Text>

          <TouchableOpacity
            onPress={handleLogout}
            disabled={loggingOut}
            activeOpacity={0.9}
          >
            <GlassCard style={[styles.logoutCard, loggingOut && { opacity: 0.7 }]} borderColor="rgba(239,68,68,0.35)">
              <View style={styles.logoutContent}>
                <View style={styles.logoutIconWrapper}>
                  {loggingOut ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <Ionicons name="log-out-outline" size={22} color="#EF4444" />
                  )}
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.logoutTitle}>
                    {loggingOut ? 'Logging out…' : 'Log out'}
                  </Text>
                  <Text style={styles.logoutSubtitle}>
                    Sign out of this business account
                  </Text>
                </View>

                <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
              </View>
            </GlassCard>
          </TouchableOpacity>
        </Animated.View>

        <View style={{ height: 18 }} />
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  itemsContainer: {
    gap: 12,
  },
  itemWrapper: {
    marginBottom: 0,
  },
  itemCard: {
    padding: 16,
  },
  itemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  itemIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemLabel: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },

  // Logout
  logoutCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  logoutContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  logoutIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  logoutTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  logoutSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
});
