import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
  RefreshControl,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');
const SKY = colors.SKY;

type OrgRow = Record<string, any>;

function getMissingColumn(message?: string | null) {
  const m = (message || '').match(/column\s+organizations\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

export default function BusinessProfile() {
  const { user } = useAuth();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // form fields
  const [businessName, setBusinessName] = useState('');
  const [businessEmail, setBusinessEmail] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [taxId, setTaxId] = useState('');

  // keeps original values to detect changes + allow cancel
  const originalRef = useRef({
    businessName: '',
    businessEmail: '',
    businessPhone: '',
    businessAddress: '',
    businessDescription: '',
    taxId: '',
  });

  // ✅ Use org id, not user.id
  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const hasChanges = useMemo(() => {
    const o = originalRef.current;
    return (
      businessName !== o.businessName ||
      businessEmail !== o.businessEmail ||
      businessPhone !== o.businessPhone ||
      businessAddress !== o.businessAddress ||
      businessDescription !== o.businessDescription ||
      taxId !== o.taxId
    );
  }, [businessName, businessEmail, businessPhone, businessAddress, businessDescription, taxId]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadBusinessProfile();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  // reload when screen gains focus (handy after onboarding/organization changes)
  useFocusEffect(
    React.useCallback(() => {
      if (isOrgUser && organizationId) loadBusinessProfile(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [organizationId, isOrgUser])
  );

  const applyOrgToForm = (org: OrgRow | null) => {
    const nextName = (org?.name ?? '') as string;
    const nextEmail = ((org?.email ?? user?.email ?? '') as string) || '';
    const nextPhone = (org?.phone ?? '') as string;
    const nextAddress = (org?.address ?? '') as string;
    const nextDesc = (org?.description ?? '') as string;

    // some schemas use vat_number instead of tax_id, etc
    const nextTax =
      (org?.tax_id ?? org?.vat_number ?? org?.vat ?? org?.taxid ?? '') as string;

    setBusinessName(nextName);
    setBusinessEmail(nextEmail);
    setBusinessPhone(nextPhone);
    setBusinessAddress(nextAddress);
    setBusinessDescription(nextDesc);
    setTaxId(nextTax);

    originalRef.current = {
      businessName: nextName,
      businessEmail: nextEmail,
      businessPhone: nextPhone,
      businessAddress: nextAddress,
      businessDescription: nextDesc,
      taxId: nextTax,
    };
  };

  const loadBusinessProfile = async (showSpinner = true) => {
    if (!isOrgUser || !organizationId) return;

    try {
      if (showSpinner) setLoading(true);

      // Try a tolerant select: we’ll read what exists
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) throw error;

      applyOrgToForm(data || null);
    } catch (error: any) {
      console.error('Error loading business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to load business information');
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  const onRefresh = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      setRefreshing(true);
      await loadBusinessProfile(false);
    } finally {
      setRefreshing(false);
    }
  };

  const cancelEditing = async () => {
    await hapticFeedback('light');
    applyOrgToForm({
      name: originalRef.current.businessName,
      email: originalRef.current.businessEmail,
      phone: originalRef.current.businessPhone,
      address: originalRef.current.businessAddress,
      description: originalRef.current.businessDescription,
      tax_id: originalRef.current.taxId,
    });
    setIsEditing(false);
  };

  const handleSave = async () => {
    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    if (!businessName.trim()) {
      Alert.alert('Missing info', 'Business name is required.');
      return;
    }

    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      // payload (only include fields you’re actually editing)
      const payload: Record<string, any> = {
        id: organizationId,
        name: businessName.trim(),
        email: businessEmail.trim() || null,
        phone: businessPhone.trim() || null,
        address: businessAddress.trim() || null,
        description: businessDescription.trim() || null,
        updated_at: new Date().toISOString(),
      };

      // tax field name might differ across your schema
      // try tax_id first, fall back if missing
      let { error } = await supabase.from('organizations').upsert({ ...payload, tax_id: taxId.trim() || null });

      if (error) {
        const missing = getMissingColumn(error.message);
        // if organizations.tax_id doesn't exist, retry with vat_number
        if (missing === 'tax_id') {
          const retry = await supabase
            .from('organizations')
            .upsert({ ...payload, vat_number: taxId.trim() || null });
          error = retry.error;
        }
      }

      if (error) throw error;

      await loadBusinessProfile(false);
      Alert.alert('Success', 'Business information updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save business information');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Business Information" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // If they got here without an org context, show a clear message
  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Business Information" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Business Information"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
        rightAction={
          !isEditing ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setIsEditing(true);
              }}
              style={styles.editButton}
            >
              <Ionicons name="create-outline" size={20} color={SKY} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={cancelEditing}
              style={styles.editButton}
            >
              <Ionicons name="close" size={20} color={SKY} />
            </TouchableOpacity>
          )
        }
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
            {/* Business Name */}
            <View style={styles.section}>
              <Text style={styles.label}>Business Name</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessName}
                  onChangeText={setBusinessName}
                  placeholder="Enter business name"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Email */}
            <View style={styles.section}>
              <Text style={styles.label}>Email</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessEmail}
                  onChangeText={setBusinessEmail}
                  placeholder="Enter email"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Phone */}
            <View style={styles.section}>
              <Text style={styles.label}>Phone Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessPhone}
                  onChangeText={setBusinessPhone}
                  placeholder="Enter phone number"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="phone-pad"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Address */}
            <View style={styles.section}>
              <Text style={styles.label}>Business Address</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={businessAddress}
                  onChangeText={setBusinessAddress}
                  placeholder="Enter business address"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={3}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Description */}
            <View style={styles.section}>
              <Text style={styles.label}>Business Description</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea, { minHeight: 110 }]}
                  value={businessDescription}
                  onChangeText={setBusinessDescription}
                  placeholder="Describe your business"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={4}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Tax ID */}
            <View style={styles.section}>
              <Text style={styles.label}>Tax ID / VAT Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={taxId}
                  onChangeText={setTaxId}
                  placeholder="Enter tax ID"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* Save / Editing footer */}
            {isEditing ? (
              <View style={{ gap: 10, marginTop: SPACING.lg }}>
                <TouchableOpacity
                  style={[styles.saveButton, (!hasChanges || isSaving) && { opacity: 0.65 }]}
                  onPress={handleSave}
                  disabled={!hasChanges || isSaving}
                  activeOpacity={0.85}
                >
                  <View style={styles.saveButtonContent}>
                    {isSaving ? (
                      <ActivityIndicator size="small" color="#FFFFFF" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                        <Text style={styles.saveButtonText}>Save Changes</Text>
                      </>
                    )}
                  </View>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.secondaryButton, isSaving && { opacity: 0.7 }]}
                  onPress={cancelEditing}
                  disabled={isSaving}
                  activeOpacity={0.85}
                >
                  <View style={styles.secondaryButtonContent}>
                    <Ionicons name="close" size={18} color={SKY} />
                    <Text style={styles.secondaryButtonText}>Cancel</Text>
                  </View>
                </TouchableOpacity>

                {!hasChanges && (
                  <Text style={styles.hintText}>No changes to save.</Text>
                )}
              </View>
            ) : (
              <Text style={styles.hintText}>
                Tap the pencil icon to edit your business details.
              </Text>
            )}

            <View style={{ height: 24 }} />
          </Animated.View>
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },

  scrollView: { flex: 1 },
  scrollContent: { padding: isSmallScreen ? 16 : 20, paddingBottom: 100 },

  content: { gap: SPACING.lg },
  section: { gap: SPACING.sm },

  label: { color: '#F9FAFB', fontSize: 14, fontWeight: '600', marginBottom: 4 },

  inputCard: { ...CARD_SIZES.small },
  input: { color: '#F9FAFB', fontSize: 16, padding: 0 },
  textArea: { minHeight: 80, textAlignVertical: 'top' },

  editButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },

  saveButton: {
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#10B981',
    elevation: 4,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.28,
    shadowRadius: 8,
  },
  saveButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  saveButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },

  secondaryButton: {
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  secondaryButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 13,
    paddingHorizontal: 24,
  },
  secondaryButtonText: { color: SKY, fontSize: 15, fontWeight: '800' },

  hintText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, lineHeight: 18, marginTop: 6, textAlign: 'center' },
});
