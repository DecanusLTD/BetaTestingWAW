// app/business/locations/[id].tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Animated,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  Dimensions,
  Platform,
  KeyboardAvoidingView,
  Switch,
  ImageBackground,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';

import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type AnyRow = Record<string, any>;

interface LocationRow {
  id: string;
  organization_id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at?: string;

  // We don't know which one you’ve added (or will add), so we read dynamically.
  header_image_url?: string | null;
  photo_url?: string | null;
  image_url?: string | null;
}

interface LocationServiceRow {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
  created_at?: string;
}

const HERO_H = Math.round(width * 0.52);

// ✅ Fixed tier names (we store these into location_services.service_name)
const TIER_DEFS = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'medal-outline' as const },
  { key: 'silver', name: 'Silver Wash', icon: 'medal-outline' as const },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy-outline' as const },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond-outline' as const },
];

const STORAGE_BUCKET = 'location-photos'; // create this bucket in Supabase Storage

const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

function isMissingColumnErr(err: any) {
  return typeof err?.code === 'string' && err.code.startsWith('PGRST');
}

function normalizeServiceName(s: any) {
  return String(s || '').trim().toLowerCase();
}

export default function BusinessLocationDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [location, setLocation] = useState<LocationRow | null>(null);

  // header image
  const [headerImageUrl, setHeaderImageUrl] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // editable fields
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [isActive, setIsActive] = useState(true);

  // services (tiers)
  const [services, setServices] = useState<LocationServiceRow[]>([]);
  const [servicesTableOk, setServicesTableOk] = useState(true);
  const [seedingTiers, setSeedingTiers] = useState(false);

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!id || !isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isOrgUser, organizationId]);

  const loadAll = async () => {
    try {
      setLoading(true);
      await Promise.all([loadLocation(), loadServicesAndEnsureTiers()]);
    } catch (e) {
      console.error('[LocationDetails] loadAll error:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadLocation = async () => {
    if (!id || !organizationId) return;

    const { data, error } = await supabase.from('car_wash_locations').select('*').eq('id', id).maybeSingle();

    if (error) throw error;
    if (!data) {
      setLocation(null);
      return;
    }

    // Security: ensure org owns this location
    if ((data as AnyRow).organization_id !== organizationId) {
      setLocation(null);
      Alert.alert('Access denied', 'That location does not belong to this business.');
      router.back();
      return;
    }

    const row = data as LocationRow;
    setLocation(row);

    setName(row.name ?? '');
    setAddress(row.address ?? '');
    setStatus(((row.status ?? (row.is_active ? 'active' : 'inactive')) as any) === 'inactive' ? 'inactive' : 'active');
    setIsActive(row.is_active === null || row.is_active === undefined ? row.status !== 'inactive' : !!row.is_active);

    const photo =
      (row as any).header_image_url ??
      (row as any).photo_url ??
      (row as any).image_url ??
      null;

    setHeaderImageUrl(typeof photo === 'string' && photo.trim() ? photo : null);
  };

  const tryUpdatePhotoColumn = async (locationId: string, url: string) => {
    const candidates = ['header_image_url', 'photo_url', 'image_url'];

    let lastErr: any = null;
    for (const col of candidates) {
      const { error } = await supabase.from('car_wash_locations').update({ [col]: url }).eq('id', locationId);

      if (!error) return { ok: true, column: col };

      lastErr = error;

      // if column doesn't exist, try next
      if (isMissingColumnErr(error) && /column/i.test(String(error?.message || ''))) continue;

      break;
    }

    return { ok: false, error: lastErr };
  };

  const pickAndUploadHeaderPhoto = async () => {
    if (!location?.id || !organizationId) return;

    try {
      setUploadingPhoto(true);
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload a header photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaType.Images,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });

      if (result.canceled) return;

      const asset = result.assets?.[0];
      if (!asset?.uri) {
        Alert.alert('Error', 'Could not read that image.');
        return;
      }

      const ext = (asset.uri.split('.').pop() || 'jpg').toLowerCase();
      const fileName = `header_${Date.now()}.${ext}`;
      const filePath = `org_${organizationId}/locations/${location.id}/${fileName}`;

      const res = await fetch(asset.uri);
      const blob = await res.blob();

      const upload = await supabase.storage.from(STORAGE_BUCKET).upload(filePath, blob, {
        contentType: blob.type || `image/${ext}`,
        upsert: true,
      });

      if (upload.error) throw upload.error;

      const pub = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(filePath);
      const publicUrl = pub?.data?.publicUrl;

      if (!publicUrl) throw new Error('Upload succeeded but could not get public URL.');

      const upd = await tryUpdatePhotoColumn(location.id, publicUrl);

      if (!upd.ok) {
        console.error('[LocationDetails] photo url update failed:', upd.error);
        Alert.alert(
          'DB update needed',
          "The photo uploaded, but your 'car_wash_locations' table doesn't have a column to store the URL.\n\nRun this SQL in Supabase:\n\nALTER TABLE public.car_wash_locations ADD COLUMN IF NOT EXISTS header_image_url text NULL;",
        );
        setHeaderImageUrl(publicUrl);
        return;
      }

      setHeaderImageUrl(publicUrl);
      await loadLocation();
      Alert.alert('Updated', 'Header photo saved.');
    } catch (e: any) {
      console.error('[LocationDetails] upload photo error:', e);
      Alert.alert('Error', e?.message || 'Failed to upload photo');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSaveLocation = async () => {
    if (!location?.id) return;

    if (!name.trim()) {
      Alert.alert('Missing info', 'Location name is required.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const nextStatus = isActive ? 'active' : 'inactive';

      const { error } = await supabase
        .from('car_wash_locations')
        .update({
          name: name.trim(),
          address: address.trim() ? address.trim() : null,
          status: nextStatus,
          is_active: isActive,
        })
        .eq('id', location.id);

      if (error) throw error;

      await loadLocation();
      Alert.alert('Saved', 'Location updated.');
    } catch (e: any) {
      console.error('[LocationDetails] save error:', e);
      Alert.alert('Error', e?.message || 'Failed to save location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = async () => {
    if (!location?.id) return;

    Alert.alert('Delete location', 'Are you sure? This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setSaving(true);
            await hapticFeedback('medium');

            const { error } = await supabase.from('car_wash_locations').delete().eq('id', location.id);

            if (error) throw error;

            Alert.alert('Deleted', 'Location removed.');
            router.back();
          } catch (e: any) {
            console.error('[LocationDetails] delete error:', e);
            Alert.alert('Error', e?.message || 'Failed to delete location');
          } finally {
            setSaving(false);
          }
        },
      },
    ]);
  };

  /**
   * ✅ Load services and ensure the 4 tier rows exist.
   * We store tiers into location_services with service_name exactly as:
   * Bronze Wash, Silver Wash, Gold Wash, Platinum Wash
   */
  const loadServicesAndEnsureTiers = async () => {
    if (!id) return;

    const { data, error } = await supabase
      .from('location_services')
      .select('*')
      .eq('location_id', id)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[LocationDetails] location_services not available (or policy denied):', error.message);
      setServicesTableOk(false);
      setServices([]);
      return;
    }

    setServicesTableOk(true);

    const rows = (data || []) as LocationServiceRow[];
    const ensured = await ensureTierRows(rows);
    setServices(ensured);
  };

  const ensureTierRows = async (rows: LocationServiceRow[]) => {
    if (!id) return rows;

    const byName = new Map<string, LocationServiceRow>();
    rows.forEach((r) => byName.set(normalizeServiceName(r.service_name), r));

    const missingDefs = TIER_DEFS.filter((t) => !byName.has(normalizeServiceName(t.name)));

    if (missingDefs.length === 0) {
      // still want to show only tiers in UI, not random services
      return rows.filter((r) =>
        TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name))
      );
    }

    try {
      setSeedingTiers(true);

      // Insert missing tier rows with sensible defaults
      const inserts = missingDefs.map((t) => ({
        location_id: id,
        service_name: t.name,
        is_enabled: true,
        price: null,
        duration_minutes: null,
      }));

      const ins = await supabase.from('location_services').insert(inserts);

      if (ins.error) {
        console.error('[LocationDetails] ensureTierRows insert error:', ins.error);
        // don’t hard fail the screen — just keep what we had
        return rows.filter((r) =>
          TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name))
        );
      }

      // Reload to get IDs
      const { data: next, error: nextErr } = await supabase
        .from('location_services')
        .select('*')
        .eq('location_id', id);

      if (nextErr) throw nextErr;

      const nextRows = (next || []) as LocationServiceRow[];

      // Filter to tiers only
      return nextRows.filter((r) =>
        TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name))
      );
    } finally {
      setSeedingTiers(false);
    }
  };

  const getTierRow = (tierName: string) => {
    return services.find((s) => normalizeServiceName(s.service_name) === normalizeServiceName(tierName)) || null;
  };

  const updateTierRow = async (row: LocationServiceRow, patch: Partial<LocationServiceRow>) => {
    if (!servicesTableOk) return;

    try {
      const { error } = await supabase.from('location_services').update(patch).eq('id', row.id);
      if (error) throw error;

      setServices((prev) => prev.map((s) => (s.id === row.id ? { ...s, ...patch } : s)));
    } catch (e: any) {
      console.error('[LocationDetails] updateTierRow error:', e);
      Alert.alert('Error', e?.message || 'Failed to update tier');
    }
  };

  const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
    const t = (raw || '').trim();
    if (!t) return null;

    const v = Number(t);
    if (!Number.isFinite(v)) return null;

    if (v < 0) return null;

    if (kind === 'minutes') {
      // keep it an int
      return Math.round(v);
    }
    return v;
  };

  const renderTierCard = (tier: (typeof TIER_DEFS)[number]) => {
    const row = getTierRow(tier.name);

    // if seeding/reloading, show a placeholder
    if (!row) {
      return (
        <View key={tier.key} style={styles.serviceRow}>
          <View style={{ flex: 1 }}>
            <View style={styles.rowBetween}>
              <View style={styles.row}>
                <Ionicons name={tier.icon} size={18} color={SKY} />
                <Text style={styles.serviceName}>{tier.name}</Text>
              </View>
              <ActivityIndicator size="small" color={SKY} />
            </View>

            <Text style={styles.miniText} numberOfLines={2}>
              Setting up this tier...
            </Text>
          </View>
        </View>
      );
    }

    return (
      <View key={tier.key} style={styles.serviceRow}>
        <View style={{ flex: 1 }}>
          <View style={styles.rowBetween}>
            <View style={styles.row}>
              <Ionicons name={tier.icon} size={18} color={SKY} />
              <Text style={styles.serviceName} numberOfLines={1}>
                {tier.name}
              </Text>
            </View>

            <View style={{ alignItems: 'flex-end', gap: 6 }}>
              <Text style={styles.inlineLabel}>Available</Text>
              <Switch
                value={!!row.is_enabled}
                onValueChange={async (v) => {
                  await hapticFeedback('light');
                  updateTierRow(row, { is_enabled: v });
                }}
              />
            </View>
          </View>

          <View style={styles.serviceMetaRow}>
            <View style={styles.serviceChip}>
              <Text style={styles.serviceChipText}>£{money(row.price)}</Text>
            </View>
            <View style={styles.serviceChip}>
              <Text style={styles.serviceChipText}>
                {row.duration_minutes ? `${row.duration_minutes} min` : '— min'}
              </Text>
            </View>
          </View>

          {/* Inline edit */}
          <View style={styles.inlineEditRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.inlineLabel}>Price (£)</Text>
              <GlassCard style={styles.inlineInputCard} accountType="business">
                <TextInput
                  defaultValue={row.price === null || row.price === undefined ? '' : String(row.price)}
                  placeholder="0"
                  placeholderTextColor="rgba(249,250,251,0.45)"
                  keyboardType="decimal-pad"
                  style={styles.inlineInput}
                  onEndEditing={(e) => {
                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'price');
                    // invalid -> ignore silently
                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                    updateTierRow(row, { price: v });
                  }}
                />
              </GlassCard>
            </View>

            <View style={{ width: 110 }}>
              <Text style={styles.inlineLabel}>Minutes</Text>
              <GlassCard style={styles.inlineInputCard} accountType="business">
                <TextInput
                  defaultValue={
                    row.duration_minutes === null || row.duration_minutes === undefined ? '' : String(row.duration_minutes)
                  }
                  placeholder="—"
                  placeholderTextColor="rgba(249,250,251,0.45)"
                  keyboardType="number-pad"
                  style={styles.inlineInput}
                  onEndEditing={(e) => {
                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'minutes');
                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                    updateTierRow(row, { duration_minutes: v });
                  }}
                />
              </GlassCard>
            </View>
          </View>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading location...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!location) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={36} color={SKY} style={{ opacity: 0.8 }} />
          <Text style={styles.loadingText}>Location not found.</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={[styles.primaryBtn, { marginTop: 12 }]}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
              <Text style={styles.primaryBtnText}>Go back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={location.name || 'Location'}
        subtitle={location.address || 'Edit details & tier pricing'}
        accountType="business"
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              handleSaveLocation();
            }}
            style={styles.headerSaveBtn}
            disabled={saving}
          >
            <Ionicons name="save-outline" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* HEADER PHOTO */}
          <Animated.View style={[styles.heroWrap, { opacity: fadeAnim }]}>
            <ImageBackground
              source={headerImageUrl ? { uri: headerImageUrl } : undefined}
              style={styles.hero}
              imageStyle={styles.heroImg}
            >
              {!headerImageUrl && (
                <LinearGradient colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.65)']} style={StyleSheet.absoluteFill} />
              )}

              <View style={styles.heroTopRow}>
                <View style={styles.heroBadge}>
                  <Ionicons name="image-outline" size={16} color="#F9FAFB" />
                  <Text style={styles.heroBadgeText}>{headerImageUrl ? 'Header photo' : 'No header photo'}</Text>
                </View>

                <TouchableOpacity
                  onPress={pickAndUploadHeaderPhoto}
                  disabled={uploadingPhoto}
                  style={[styles.heroBtn, uploadingPhoto && { opacity: 0.75 }]}
                  activeOpacity={0.85}
                >
                  {uploadingPhoto ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name={headerImageUrl ? 'refresh' : 'add'} size={18} color="#fff" />
                      <Text style={styles.heroBtnText}>{headerImageUrl ? 'Change' : 'Add'}</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>

              <View style={styles.heroBottom}>
                <Text style={styles.heroTitle} numberOfLines={1}>
                  {name || location.name || 'Location'}
                </Text>
                <Text style={styles.heroSubtitle} numberOfLines={1}>
                  {address || location.address || 'Tap Add to upload a header image'}
                </Text>
              </View>
            </ImageBackground>
          </Animated.View>

          {/* DETAILS */}
          <Animated.View style={{ opacity: fadeAnim }}>
            <Text style={styles.sectionTitle}>Location Details</Text>

            <GlassCard style={styles.card} accountType="business">
              <View style={styles.field}>
                <Text style={styles.label}>Location name</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder="e.g., Main Car Wash Hub"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={styles.input}
                  />
                </GlassCard>
              </View>

              <View style={styles.field}>
                <Text style={styles.label}>Address</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={address}
                    onChangeText={setAddress}
                    placeholder="Enter full address"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={[styles.input, styles.textArea]}
                    multiline
                    numberOfLines={3}
                  />
                </GlassCard>
              </View>

              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Active</Text>
                  <Text style={styles.miniText}>If off, this location won’t show for bookings.</Text>
                </View>
                <Switch
                  value={isActive}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setIsActive(v);
                    setStatus(v ? 'active' : 'inactive');
                  }}
                />
              </View>

              <View style={styles.actionsRow}>
                <TouchableOpacity
                  onPress={handleSaveLocation}
                  disabled={saving}
                  style={[styles.primaryBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
                    {saving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#fff" />
                        <Text style={styles.primaryBtnText}>Save changes</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={handleDeleteLocation}
                  disabled={saving}
                  style={[styles.dangerBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <View style={styles.dangerBtnInner}>
                    <Ionicons name="trash-outline" size={18} color="#EF4444" />
                    <Text style={styles.dangerBtnText}>Delete</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Animated.View>

          {/* TIER PRICING */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Tier Pricing</Text>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadServicesAndEnsureTiers();
                }}
                style={styles.smallAddBtn}
                activeOpacity={0.85}
              >
                {seedingTiers ? (
                  <ActivityIndicator size="small" color={SKY} />
                ) : (
                  <Ionicons name="refresh" size={18} color={SKY} />
                )}
              </TouchableOpacity>
            </View>

            {!servicesTableOk ? (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 10 }}>
                  <View style={styles.row}>
                    <Ionicons name="information-circle-outline" size={18} color={SKY} />
                    <Text style={styles.infoText}>
                      Tier pricing isn’t available because <Text style={{ fontWeight: '900' }}>location_services</Text>{' '}
                      table/policy isn’t accessible.
                    </Text>
                  </View>
                  <Text style={styles.miniText}>
                    If you want, I’ll generate the SQL + RLS for the location_services table.
                  </Text>
                </View>
              </GlassCard>
            ) : (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 12 }}>
                  {TIER_DEFS.map(renderTierCard)}
                </View>

                <View style={{ height: 10 }} />

                <Text style={styles.miniText}>
                  These are the fixed tiers customers will see: Bronze, Silver, Gold, Platinum. Set price + duration per
                  location, and toggle availability.
                </Text>
              </GlassCard>
            )}
          </Animated.View>

          <View style={{ height: 28 }} />
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },

  heroWrap: {
    marginBottom: 18,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  hero: {
    height: HERO_H,
    width: '100%',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  heroImg: { borderRadius: 22 },
  heroTopRow: {
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBadgeText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  heroBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBtnText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  heroBottom: {
    padding: 14,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.10)',
  },
  heroTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '900' },
  heroSubtitle: { color: 'rgba(249,250,251,0.78)', fontSize: 12, marginTop: 4, fontWeight: '700' },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  card: { padding: 16 },

  field: { gap: 8, marginBottom: 12 },
  label: { color: 'rgba(249,250,251,0.85)', fontSize: 13, fontWeight: '700' },
  miniText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, lineHeight: 18 },

  inputCard: { padding: 0, overflow: 'hidden' },
  input: { color: '#F9FAFB', fontSize: 16, padding: 14, minHeight: 48 },
  textArea: { minHeight: 92, textAlignVertical: 'top' },

  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowBetween: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 },

  actionsRow: { flexDirection: 'row', gap: 12, marginTop: 6 },
  primaryBtn: { flex: 1, borderRadius: 16, overflow: 'hidden' },
  primaryBtnGrad: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  dangerBtn: {
    width: 110,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.35)',
    backgroundColor: 'rgba(239,68,68,0.12)',
    overflow: 'hidden',
    justifyContent: 'center',
  },
  dangerBtnInner: { paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  dangerBtnText: { color: '#EF4444', fontSize: 13, fontWeight: '800' },

  headerSaveBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  smallAddBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  infoText: { color: 'rgba(249,250,251,0.8)', fontSize: 13, fontWeight: '700', flex: 1 },

  serviceRow: {
    flexDirection: 'row',
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceName: { color: '#F9FAFB', fontSize: 15, fontWeight: '900', flexShrink: 1 },
  serviceMetaRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  serviceChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  serviceChipText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '800' },

  inlineEditRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inlineLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inlineInputCard: { padding: 0, overflow: 'hidden' },
  inlineInput: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },
});
