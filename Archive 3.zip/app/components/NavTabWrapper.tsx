import React from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import NavigationTab, { TAB_BAR_TOTAL_HEIGHT } from './NavigationTab';
import { useAuth } from '../../src/providers/enhanced-auth-context';

// Routes where tab bar should be hidden
const HIDDEN_ROUTES = [
  '/auth/login',
  '/auth/signup',
  '/auth/logout-test',
  '/customer-onboarding',
  '/onboarding',
  '/valeter/valeter-onboarding',
  '/organisation/organization-onboarding',
  '/business/onboarding',
];

export default function NavTabWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const shouldHideTab = (): boolean => {
    const currentPath = pathname || '';
    const isBusinessRoute =
      currentPath.includes('/business/') ||
      currentPath.includes('/organisation/') ||
      currentPath.includes('/organization/');
    
    // Always hide on auth and onboarding pages (check route first)
    if (HIDDEN_ROUTES.some(route => currentPath === route)) {
      return true;
    }
    
    // Only hide on auth and onboarding pages
    if (currentPath.includes('/auth/') || currentPath.includes('onboarding')) {
      return true;
    }
    
    // Hide tab bar on map view screens (booking location, tracking, etc.)
    if (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/jobs/tracking') ||
      currentPath.includes('/jobs/accept')
    ) {
      return true;
    }
    
    // Allow business dashboards to show tabs even if auth is still loading
    if (!user) {
      return !isBusinessRoute;
    }
    
    // Show navigation tab for all logged-in users (customers, valeters, and organizations)
    
    return false;
  };

  const shouldExcludePadding = (): boolean => {
    const currentPath = pathname || '';
    // Exclude booking pages with maps from padding to prevent map view issues
    return currentPath.toLowerCase().includes('/booking/location') || 
           currentPath.toLowerCase().includes('/booking/tracking') ||
           currentPath.toLowerCase().includes('/jobs/tracking');
  };

  const hideTab = shouldHideTab();
  const excludePadding = shouldExcludePadding();
  const bottomPadding = hideTab || excludePadding ? 0 : TAB_BAR_TOTAL_HEIGHT + Math.max(insets.bottom, 10);

  return (
    <View style={styles.container}>
      <View style={[styles.contentWrapper, { paddingBottom: bottomPadding }]}>
        {children}
      </View>
      {!hideTab && <NavigationTab />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
});

