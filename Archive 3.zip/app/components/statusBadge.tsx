import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

type Props = {
  status: string;
  size?: 'small' | 'medium' | 'large';
};

export default function StatusBadge({ status, size = 'medium' }: Props) {
  return (
    <View style={[styles.badge, styles[size]]}>
      <Text style={styles.text}>{status.replace('_', ' ')}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#2563EB',
  },
  text: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  small: {},
  medium: {},
  large: {},
});