import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Image,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useAuth } from "../../src/providers/enhanced-auth-context";
import { hapticFeedback } from "../../src/services/HapticFeedbackService";
import { supabase } from "../../src/lib/supabase";

const { width, height } = Dimensions.get("window");
const isSmallScreen = width < 375;

export default function BusinessLoginScreen() {
  const { login, logout } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const bubble2Anim = useRef(new Animated.Value(0)).current;

  // Initial fade in animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Start sea animations
  useEffect(() => {
    const loop = (anim: Animated.Value, duration: number) =>
      Animated.loop(
        Animated.timing(anim, { toValue: 1, duration, useNativeDriver: true })
      ).start();

    loop(wave1Anim, 5000);
    loop(wave2Anim, 4500);
    loop(wave3Anim, 5500);
    loop(bubbleAnim, 4000);
    loop(bubble2Anim, 3500);
  }, []);

  const finishRouting = () => {
    // TODO: update this to your real org dashboard route
    router.replace("/business/dashboard" as any);
  };

  const getEffectiveRole = async (): Promise<string> => {
    // Source-of-truth role check to avoid React state timing issues:
    // 1) auth.getUser() metadata
    // 2) profiles.user_type (preferred)
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;

    const sbUser = authData?.user;
    if (!sbUser?.id) return "";

    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("user_type")
      .eq("id", sbUser.id)
      .maybeSingle();

    if (profErr) throw profErr;

    const role =
      (profile?.user_type ??
        (sbUser.user_metadata as any)?.userType ??
        "") as string;

    return role.toLowerCase();
  };

  const isOrgRole = (role: string) => {
    // Be forgiving about UK/typo spellings so you don’t lock yourself out.
    return (
      role === "organization" ||
      role === "organisation" ||
      role === "organistion" // seen this typo in the wild 😅
    );
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert("Error", "Please enter both email and password");
      return;
    }

    await hapticFeedback("medium");
    setIsLoading(true);

    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert("Login Failed", "Invalid email or password.");
        return;
      }

      // ✅ DO NOT trust context user state here (can be stale).
      // Pull role from Supabase/profile directly.
      const role = await getEffectiveRole();

      if (!isOrgRole(role)) {
        await logout();
        Alert.alert(
          "Not a business account",
          "That login isn't registered as a business account. Use the standard login instead."
        );
        return;
      }

      finishRouting();
    } catch (e: any) {
      console.error("[BusinessLogin] error:", e);
      Alert.alert(
        "Login Failed",
        e?.message || "Something went wrong. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackToMainLogin = async () => {
    await hapticFeedback("light");
    router.back();
  };

  return (
    <View style={styles.root}>
      {/* Gradient Background */}
      <LinearGradient
        colors={["#0A1929", "#1E3A8A", "#1E40AF", "#1E293B"]}
        style={StyleSheet.absoluteFillObject}
      />

      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle="light-content"
      />

      {/* Animated Sea Background */}
      <View style={styles.seaBackground}>
        {/* Waves */}
        <Animated.View
          style={[
            styles.wave,
            styles.wave1,
            {
              transform: [
                {
                  translateX: wave1Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width, width],
                  }),
                },
              ],
              opacity: 0.1,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave2,
            {
              transform: [
                {
                  translateX: wave2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [width, -width],
                  }),
                },
              ],
              opacity: 0.08,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave3,
            {
              transform: [
                {
                  translateX: wave3Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width * 0.5, width * 0.5],
                  }),
                },
              ],
              opacity: 0.06,
            },
          ]}
        />

        {/* Floating Bubbles */}
        <Animated.View
          style={[
            styles.bubble,
            {
              left: "15%",
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.3, 0.3, 0],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble2,
            {
              right: "20%",
              transform: [
                {
                  translateY: bubble2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubble2Anim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.25, 0.25, 0],
              }),
            },
          ]}
        />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.contentContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Header/Logo Section */}
            <View style={styles.headerSection}>
              <Image
                source={require("../../assets/icon2.png")}
                style={styles.logoImage}
                resizeMode="contain"
              />
              <View style={styles.pageTitleRow}>
                <Ionicons
                  name="briefcase-outline"
                  size={18}
                  color="rgba(255,255,255,0.8)"
                />
                <Text style={styles.pageTitle}>Business Login</Text>
              </View>
              <Text style={styles.pageSubtitle}>
                For organizations & business accounts
              </Text>
            </View>

            {/* Login Form Card */}
            <View style={styles.formCard}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Ionicons
                    name="mail-outline"
                    size={20}
                    color="rgba(255,255,255,0.7)"
                  />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Business email address"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  onSubmitEditing={handleLogin}
                  editable={!isLoading}
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Ionicons
                    name="lock-closed-outline"
                    size={20}
                    color="rgba(255,255,255,0.7)"
                  />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Password"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  onSubmitEditing={handleLogin}
                  editable={!isLoading}
                />
              </View>

              <TouchableOpacity
                style={[
                  styles.loginButton,
                  isLoading && styles.loginButtonDisabled,
                ]}
                onPress={handleLogin}
                disabled={isLoading}
                activeOpacity={0.9}
              >
                <LinearGradient
                  colors={["#0EA5E9", "#2563EB"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.loginButtonGradient}
                >
                  <Text style={styles.loginButtonText}>
                    {isLoading ? "Signing in..." : "Sign in to Business"}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.backLink}
                onPress={handleBackToMainLogin}
                activeOpacity={0.8}
                disabled={isLoading}
              >
                <Ionicons
                  name="arrow-back"
                  size={16}
                  color="rgba(255,255,255,0.7)"
                />
                <Text style={styles.backLinkText}>
                  Back to standard login
                </Text>
              </TouchableOpacity>
            </View>

            {/* Footer */}
            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0</Text>
              <Text style={styles.footerText}>© 2025 All rights reserved</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#0A1929",
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === "ios" ? 60 : 40,
    paddingBottom: 40,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: {
    flex: 1,
    justifyContent: "center",
  },

  // Animated background
  seaBackground: {
    ...StyleSheet.absoluteFillObject,
    overflow: "hidden",
  },
  wave: {
    position: "absolute",
    height: 80,
    width: width * 2,
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: 40,
  },
  wave1: { top: "15%" },
  wave2: { top: "35%" },
  wave3: { top: "55%" },
  bubble: {
    position: "absolute",
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
  },
  bubble2: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },

  // Header Section
  headerSection: {
    alignItems: "center",
    marginBottom: 14,
  },
  logoImage: {
    width: width * 0.52,
    height: 200,
    maxWidth: 500,
  },
  pageTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: -8,
  },
  pageTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "rgba(255,255,255,0.92)",
  },
  pageSubtitle: {
    marginTop: 6,
    fontSize: 13,
    color: "rgba(255,255,255,0.65)",
    fontWeight: "600",
  },

  // Form Card
  formCard: {
    backgroundColor: "rgba(255, 255, 255, 0.08)",
    borderRadius: 20,
    padding: 24,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.1)",
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.15)",
    paddingLeft: 4,
  },
  inputIconContainer: {
    width: 48,
    height: 56,
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    flex: 1,
    paddingVertical: 16,
    paddingRight: 16,
    fontSize: 16,
    color: "#FFFFFF",
  },

  loginButton: {
    borderRadius: 14,
    overflow: "hidden",
    marginTop: 6,
    marginBottom: 14,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  loginButtonDisabled: {
    opacity: 0.6,
  },
  loginButtonGradient: {
    paddingVertical: 18,
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#FFFFFF",
  },

  backLink: {
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 999,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.18)",
  },
  backLinkText: {
    fontSize: 13,
    color: "rgba(255,255,255,0.82)",
    fontWeight: "700",
  },

  // Footer
  footer: {
    alignItems: "center",
    marginTop: 10,
  },
  footerText: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.5)",
    marginBottom: 4,
  },
});
