import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

type BookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type BookingRow = {
  id: string;
  status: BookingStatus;
  service_type: string;
  service_name?: string | null;
  price: number | string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  updated_at?: string;
  completed_at?: string | null;
};

export default function BookingTracking() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [status, setStatus] = useState<BookingStatus>('scheduled');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const [cancelling, setCancelling] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  // Channel refs so we can cleanly re-subscribe
  const bookingChannelRef = useRef<any>(null);
  const presenceChannelRef = useRef<any>(null);
  const presenceValeterIdRef = useRef<string | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;

    const start = async () => {
      await loadBooking();
      subscribeToBooking();
    };

    start();

    return () => {
      if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);
      if (presenceChannelRef.current) supabase.removeChannel(presenceChannelRef.current);

      bookingChannelRef.current = null;
      presenceChannelRef.current = null;
      presenceValeterIdRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', bookingId).single();
      if (error) throw error;

      const row = data as BookingRow;

      setBooking(row);
      setStatus(row.status);

      if (row.location_lat && row.location_lng) {
        setRegion({
          latitude: row.location_lat,
          longitude: row.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }

      if (row.valeter_id) {
        ensurePresenceSubscription(row.valeter_id);
        await loadValeterPresenceOnce(row.valeter_id);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);

    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;

          setBooking(updated);
          setStatus(updated.status);

          if (updated.valeter_id) {
            ensurePresenceSubscription(updated.valeter_id);
            await loadValeterPresenceOnce(updated.valeter_id);
          }

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/owner/booking/completion',
              params: { bookingId },
            });
          }

          // Optional: if cancelled, bounce back to dashboard after a moment
          if (updated.status === 'cancelled') {
            // keep them on screen so they can see it changed, then go home
            setTimeout(() => {
              router.replace('owner/owner-dashboard');
            }, 700);
          }
        }
      )
      .subscribe();

    bookingChannelRef.current = channel;
  };

  const ensurePresenceSubscription = (valeterId: string) => {
    if (presenceValeterIdRef.current === valeterId && presenceChannelRef.current) return;

    if (presenceChannelRef.current) {
      supabase.removeChannel(presenceChannelRef.current);
      presenceChannelRef.current = null;
    }

    presenceValeterIdRef.current = valeterId;

    const presenceChannel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            setValeterLocation({ latitude: updated.last_lat, longitude: updated.last_lng });
          }
        }
      )
      .subscribe();

    presenceChannelRef.current = presenceChannel;
  };

  const loadValeterPresenceOnce = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat,last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) return;

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ latitude: data.last_lat, longitude: data.last_lng });
      }
    } catch {}
  };

  const canCancel = status !== 'completed' && status !== 'cancelled';

  const cancelBooking = async () => {
    if (!bookingId || !user?.id) return;
    if (!canCancel) return;

    try {
      setCancelling(true);

      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer',
        })
        .eq('id', bookingId);

      if (error) throw error;

      // UI will update via realtime, but do this for instant feedback
      setStatus('cancelled');
    } catch (e) {
      console.warn('[BookingTracking] cancelBooking error', e);
      Alert.alert('Could not cancel', 'Please try again in a moment.');
    } finally {
      setCancelling(false);
    }
  };

  const onPressCancel = () => {
    Alert.alert(
      'Cancel booking?',
      'This will cancel your booking. If a valeter is already on the way, you may still be charged depending on your policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: cancelBooking },
      ]
    );
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'scheduled':
        return 35;
      case 'in_progress':
        return 75;
      case 'completed':
        return 100;
      case 'cancelled':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'scheduled':
        return 'Booked! Your valeter will start at the scheduled time';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      case 'cancelled':
        return 'This booking was cancelled';
      default:
        return 'Tracking your booking';
    }
  };

  const getStatusSteps = () => {
    return [
      { label: 'Booked', completed: ['scheduled', 'in_progress', 'completed', 'cancelled'].includes(status) },
      { label: 'In Progress', completed: ['in_progress', 'completed'].includes(status) },
      { label: 'Completed', completed: status === 'completed' },
    ];
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map (no gaps) */}
      <View style={StyleSheet.absoluteFill}>
        <MapView style={StyleSheet.absoluteFill} region={region} showsUserLocation>
          {!!booking?.location_lat && !!booking?.location_lng && (
            <Marker coordinate={{ latitude: booking.location_lat!, longitude: booking.location_lng! }}>
              <View style={styles.destinationMarker}>
                <Ionicons name="flag" size={24} color="#EF4444" />
              </View>
            </Marker>
          )}

          {!!valeterLocation && (
            <Marker coordinate={valeterLocation}>
              <Animated.View style={[styles.valeterMarkerContainer, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.valeterMarker}>
                  <Ionicons name="car" size={20} color="#FFFFFF" />
                </View>
                <View style={styles.valeterPulse} />
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader title="Live Tracking" />

      {/* Bottom card floating */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            paddingBottom: Math.max(insets.bottom, 14) + 14,
          },
        ]}
      >
        <GlassCard style={styles.trackingCard}>
          <View style={styles.trackingHeader}>
            <StatusBadge status={status} size="medium" />
            <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
          </View>

          <View style={styles.progressContainer}>
            <AnimatedProgress progress={getStatusProgress()} size={118} />
          </View>

          <View style={styles.stepsContainer}>
            {getStatusSteps().map((step, index) => (
              <View key={index} style={styles.stepItem}>
                <View style={[styles.stepDot, step.completed && styles.stepDotCompleted]}>
                  {step.completed && <Ionicons name="checkmark" size={12} color="#FFFFFF" />}
                </View>
                <Text style={[styles.stepLabel, step.completed && styles.stepLabelCompleted]}>{step.label}</Text>
              </View>
            ))}
          </View>

          {!!booking && (
            <View style={styles.bookingInfo}>
              <View style={styles.infoRow}>
                <Ionicons name="water-outline" size={16} color={SKY} />
                <Text style={styles.infoText}>
                  {getServiceDisplayName(booking.service_type, booking.service_name || undefined)}
                </Text>
              </View>

              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color={SKY} />
                <Text style={styles.infoText} numberOfLines={1}>
                  {booking.location_address || '—'}
                </Text>
              </View>

              <View style={styles.infoRow}>
                <Ionicons name="cash-outline" size={16} color={SKY} />
                <Text style={styles.infoText}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
              </View>
            </View>
          )}

          {/* Cancel button */}
          <View style={styles.actionsRow}>
            <TouchableOpacity
              activeOpacity={0.9}
              onPress={onPressCancel}
              disabled={!canCancel || cancelling}
              style={[styles.cancelBtn, (!canCancel || cancelling) && styles.cancelBtnDisabled]}
            >
              {cancelling ? (
                <ActivityIndicator size="small" color="#F9FAFB" />
              ) : (
                <>
                  <Ionicons name="close-circle-outline" size={18} color="#F9FAFB" />
                  <Text style={styles.cancelBtnText}>Cancel booking</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </GlassCard>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },

  destinationMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },

  valeterMarkerContainer: { alignItems: 'center', justifyContent: 'center' },
  valeterMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  valeterPulse: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: SKY,
    opacity: 0.28,
  },

  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },

  trackingCard: {
    padding: 18,
  },

  trackingHeader: { alignItems: 'center', marginBottom: 14 },
  statusMessage: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginTop: 10, textAlign: 'center' },

  progressContainer: { alignItems: 'center', marginBottom: 18 },

  stepsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16, paddingHorizontal: 8 },
  stepItem: { alignItems: 'center', flex: 1 },
  stepDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  stepDotCompleted: { backgroundColor: SKY },
  stepLabel: { color: '#9CA3AF', fontSize: 10, textAlign: 'center' },
  stepLabelCompleted: { color: SKY, fontWeight: '600' },

  bookingInfo: { gap: 10, paddingTop: 14, borderTopWidth: 1, borderTopColor: 'rgba(135,206,235,0.2)' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { color: '#E5E7EB', fontSize: 14, flex: 1 },

  actionsRow: {
    marginTop: 14,
  },
  cancelBtn: {
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.75)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.35)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  cancelBtnDisabled: {
    opacity: 0.5,
  },
  cancelBtnText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});
