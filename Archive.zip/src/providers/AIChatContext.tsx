import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Modal } from 'react-native';
import AIChatComponent from '../components/chat/AIChatComponent';
import { useAuth } from './enhanced-auth-context';

interface AIChatContextType {
  showAIChat: () => void;
  hideAIChat: () => void;
  isVisible: boolean;
}

const AIChatContext = createContext<AIChatContextType | undefined>(undefined);

export const AIChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [isVisible, setIsVisible] = useState(false);

  const showAIChat = () => setIsVisible(true);
  const hideAIChat = () => setIsVisible(false);

  const userType = user?.userType === 'valeter' ? 'valeter' : 'customer';

  return (
    <AIChatContext.Provider value={{ showAIChat, hideAIChat, isVisible }}>
      {children}
      <Modal visible={isVisible} animationType="slide" presentationStyle="fullScreen">
        <AIChatComponent userType={userType} onClose={hideAIChat} />
      </Modal>
    </AIChatContext.Provider>
  );
};

export const useAIChat = () => {
  const context = useContext(AIChatContext);
  if (!context) {
    throw new Error('useAIChat must be used within AIChatProvider');
  }
  return context;
};


