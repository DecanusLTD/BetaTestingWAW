import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Platform,
  Modal,
  Pressable,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';

type Props = Readonly<{
  visible: boolean;
  onClose: () => void;
  initialEmail?: string;
  onBackToSignIn?: () => void;
}>;

export default function ForgotPasswordSheet({
  visible,
  onClose,
  initialEmail = '',
  onBackToSignIn,
}: Props) {
  const insets = useSafeAreaInsets();
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState(initialEmail);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!visible) return;
    setEmail(initialEmail);
    setSent(false);
    setError(null);
    setSending(false);
  }, [visible, initialEmail]);

  const handleSend = async () => {
    await hapticFeedback('medium');
    const trimmed = email.trim().toLowerCase();
    if (!trimmed.includes('@')) {
      setError('Enter a valid email address.');
      return;
    }
    setError(null);
    setSending(true);
    try {
      await resetPassword(trimmed);
      setSent(true);
    } catch (e: any) {
      setError(
        e?.message ||
          'Couldn’t send reset email. Try again, or email Admin@wishawashapp.com for help.'
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboard}
        >
          <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation()}>
            <View style={styles.outer}>
              <BlurView
                intensity={Platform.OS === 'ios' ? 34 : 22}
                tint="dark"
                style={StyleSheet.absoluteFill}
                {...(Platform.OS === 'android'
                  ? { experimentalBlurMethod: 'dimezisBlurView' as const }
                  : {})}
              />
              <View style={styles.blueTint} pointerEvents="none" />
              <LinearGradient
                colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.02)', 'transparent']}
                style={styles.sheen}
                pointerEvents="none"
              />

              <View style={[styles.inner, { paddingBottom: Math.max(insets.bottom, 20) + 12 }]}>
                <View style={styles.handle} />
                <View style={styles.header}>
                  <Text style={styles.title}>Forgot password?</Text>
                  <TouchableOpacity
                    onPress={onClose}
                    hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  >
                    <BrandGlyph name="close" size={26} color="rgba(255,255,255,0.9)" />
                  </TouchableOpacity>
                </View>
                <Text style={styles.pill}>Car Care Pro</Text>

                <ScrollView
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={styles.scroll}
                >
                  <Text style={styles.subtitle}>
                    {sent
                      ? 'If an account exists for that address, we sent a reset link. Open it to choose a new password.'
                      : 'Enter the email on your CCP account and we’ll send a reset link.'}
                  </Text>

                  {sent ? (
                    <>
                      <View style={styles.successBox}>
                        <BrandGlyph name="mail-open-outline" size={20} color="#9EC9E0" />
                        <Text style={styles.successText}>{email.trim().toLowerCase()}</Text>
                      </View>
                      <TouchableOpacity
                        style={styles.secondaryBtn}
                        onPress={async () => {
                          await hapticFeedback('light');
                          setSent(false);
                          setError(null);
                        }}
                      >
                        <Text style={styles.secondaryText}>Use a different email</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.cta}
                        onPress={async () => {
                          await hapticFeedback('light');
                          onClose();
                          onBackToSignIn?.();
                        }}
                        activeOpacity={0.9}
                      >
                        <View style={styles.ctaInner}>
                          <BlurView
                            intensity={Platform.OS === 'ios' ? 40 : 28}
                            tint="light"
                            style={StyleSheet.absoluteFill}
                            {...(Platform.OS === 'android'
                              ? { experimentalBlurMethod: 'dimezisBlurView' as const }
                              : {})}
                          />
                          <View style={styles.ctaTint} pointerEvents="none" />
                          <View style={styles.ctaContent}>
                            <Text style={styles.ctaText}>Back to sign in</Text>
                          </View>
                        </View>
                      </TouchableOpacity>
                    </>
                  ) : (
                    <>
                      <View style={styles.inputWrapper}>
                        <View style={styles.inputIcon}>
                          <BrandGlyph name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                        </View>
                        <TextInput
                          style={styles.input}
                          placeholder="Email address"
                          placeholderTextColor="rgba(255,255,255,0.4)"
                          value={email}
                          onChangeText={(v) => {
                            setEmail(v);
                            if (error) setError(null);
                          }}
                          autoCapitalize="none"
                          keyboardType="email-address"
                          autoComplete="email"
                          autoFocus
                          returnKeyType="send"
                          onSubmitEditing={() => {
                            void handleSend();
                          }}
                        />
                      </View>

                      {error ? <Text style={styles.errorText}>{error}</Text> : null}

                      <TouchableOpacity
                        style={styles.cta}
                        onPress={() => {
                          void handleSend();
                        }}
                        disabled={sending}
                        activeOpacity={0.9}
                      >
                        <View style={styles.ctaInner}>
                          <BlurView
                            intensity={Platform.OS === 'ios' ? 40 : 28}
                            tint="light"
                            style={StyleSheet.absoluteFill}
                            {...(Platform.OS === 'android'
                              ? { experimentalBlurMethod: 'dimezisBlurView' as const }
                              : {})}
                          />
                          <View style={styles.ctaTint} pointerEvents="none" />
                          <LinearGradient
                            colors={['rgba(255,255,255,0.45)', 'rgba(255,255,255,0.08)', 'transparent']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 0, y: 1 }}
                            style={StyleSheet.absoluteFill}
                            pointerEvents="none"
                          />
                          <View style={styles.ctaContent}>
                            {sending ? (
                              <ActivityIndicator color="#F8FAFC" />
                            ) : (
                              <>
                                <Text style={styles.ctaText}>Send reset link</Text>
                                <BrandGlyph name="arrow-forward" size={18} color="#F8FAFC" />
                              </>
                            )}
                          </View>
                        </View>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={styles.helpLink}
                        onPress={async () => {
                          await hapticFeedback('light');
                          onClose();
                          onBackToSignIn?.();
                        }}
                      >
                        <Text style={styles.helpLinkText}>Remembered it? Sign in</Text>
                      </TouchableOpacity>
                    </>
                  )}
                </ScrollView>
              </View>
            </View>
          </Pressable>
        </KeyboardAvoidingView>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(10,35,55,0.55)',
    justifyContent: 'flex-end',
  },
  keyboard: {
    width: '100%',
    height: '92%',
    maxHeight: '92%',
  },
  sheet: {
    flex: 1,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
  },
  outer: {
    flex: 1,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.28)',
    backgroundColor: 'rgba(8,24,40,0.92)',
  },
  blueTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(12,42,72,0.28)',
  },
  sheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 48,
  },
  inner: {
    flex: 1,
    paddingHorizontal: 22,
    paddingTop: 10,
  },
  handle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.4)',
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
  },
  pill: {
    alignSelf: 'center',
    textAlign: 'center',
    marginBottom: 14,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    overflow: 'hidden',
    backgroundColor: 'rgba(158,201,224,0.22)',
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.4)',
    color: '#E8F4FA',
    fontSize: 12,
    fontWeight: '800',
  },
  scroll: { paddingBottom: 16, flexGrow: 1 },
  subtitle: {
    color: 'rgba(248,250,252,0.72)',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    marginBottom: 18,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  inputIcon: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    paddingRight: 12,
  },
  errorText: {
    color: '#FCA5A5',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 10,
  },
  successBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.35)',
    backgroundColor: 'rgba(158,201,224,0.12)',
    marginBottom: 16,
  },
  successText: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '700',
  },
  secondaryBtn: { alignItems: 'center', paddingVertical: 12, marginBottom: 8 },
  secondaryText: { color: '#9EC9E0', fontSize: 14, fontWeight: '700' },
  helpLink: { alignSelf: 'center', marginTop: 18, paddingVertical: 6 },
  helpLinkText: { color: '#9EC9E0', fontSize: 14, fontWeight: '700' },
  cta: {
    marginTop: 4,
    borderRadius: 18,
    shadowColor: '#9EC9E0',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  ctaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.42)',
    backgroundColor: 'rgba(158,201,224,0.18)',
  },
  ctaTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(158,201,224,0.22)',
  },
  ctaContent: {
    minHeight: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 18,
  },
  ctaText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
});
