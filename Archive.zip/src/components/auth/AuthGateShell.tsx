/**
 * Shared cinematic auth gate: video + brand hero + bottom actions sheet.
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
  StatusBar,
  Image,
  Modal,
  Pressable,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import * as AppleAuthentication from 'expo-apple-authentication';
import { AUTH_PAGES_VIDEO } from '../../../assets/authExports';
import { AUTH_GRADIENT_COLORS } from '../../constants/authStyles';
import { hapticFeedback } from '../../services/HapticFeedbackService';

const NEW_AUTH_LOGO = require('../../../assets/newauthlogo.png');
const STEEL = '#3A7AAD';
const BRAND_LABEL = 'Wish-a-Washer';
/** Light sky blue matching the logo title */
const BRAND_ARC_BLUE = '#9EC9E0';

function CurvedBrandTitle({
  text,
  color,
  size,
}: Readonly<{
  text: string;
  color: string;
  size: number;
}>) {
  const chars = Array.from(text);
  const logoHeight = size * (238 / 380);
  // Arc around the upper dome — wraps left & right of the bubble
  const sweep = 148;
  const radius = size * 0.5;
  const letterSize = Math.max(15, Math.round(size * 0.054));
  const cx = size / 2;
  const cy = logoHeight * 0.4;
  // Keep the "a" in Wish-a-Washer at the exact crown of the arc
  const aIndex = Math.max(0, text.indexOf('-a-') + 1);
  const leftCount = Math.max(aIndex, 1);
  const rightCount = Math.max(chars.length - 1 - aIndex, 1);
  const leftStep = sweep / 2 / leftCount;
  const rightStep = sweep / 2 / rightCount;

  return (
    <View style={[styles.curveLayer, { width: size, height: logoHeight }]} pointerEvents="none">
      {chars.map((char, index) => {
        const angle =
          index === aIndex
            ? 0
            : index < aIndex
              ? -leftStep * (aIndex - index)
              : rightStep * (index - aIndex);
        const rad = (angle * Math.PI) / 180;
        // Top arc: 0° at the crown, letters fan down the left/right flanks
        const x = cx + radius * Math.sin(rad);
        const y = cy - radius * Math.cos(rad);
        const isHyphen = char === '-';
        const isCenterA = index === aIndex;
        return (
          <Text
            key={`brand-char-${index}`}
            allowFontScaling={false}
            style={[
              styles.curveLetter,
              {
                left: x - letterSize * (isHyphen ? 0.35 : 0.52),
                top: y - letterSize * 0.55,
                width: letterSize * (isHyphen ? 0.7 : 1.12),
                fontSize: letterSize,
                color,
                opacity: isHyphen ? 0.9 : 1,
                fontWeight: isCenterA ? '600' : '500',
                transform: [{ rotate: `${angle}deg` }],
                textShadowColor: 'rgba(8, 28, 48, 0.55)',
                textShadowOffset: { width: 0, height: 1 },
                textShadowRadius: 3,
              },
            ]}
          >
            {char}
          </Text>
        );
      })}
    </View>
  );
}

export type AuthGateMode = 'login' | 'signup';

type AuthGateShellProps = Readonly<{
  mode: AuthGateMode;
  tagline: string;
  emailSheetTitle: string;
  emailSheetOpen: boolean;
  onOpenEmailSheet: () => void;
  onCloseEmailSheet: () => void;
  onApple: () => void;
  onGoogle: () => void;
  emailSheetChildren: React.ReactNode;
  loading?: boolean;
}>;

export default function AuthGateShell({
  mode,
  tagline,
  emailSheetTitle,
  emailSheetOpen,
  onOpenEmailSheet,
  onCloseEmailSheet,
  onApple,
  onGoogle,
  emailSheetChildren,
  loading = false,
}: AuthGateShellProps) {
  const insets = useSafeAreaInsets();
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [logoWidth, setLogoWidth] = useState(0);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(36)).current;
  const sheetSlide = useRef(new Animated.Value(48)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const logoGlow = useRef(new Animated.Value(0.92)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 720, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 720, useNativeDriver: true }),
      Animated.timing(sheetSlide, { toValue: 0, duration: 780, delay: 120, useNativeDriver: true }),
    ]).start();
  }, [fadeAnim, sheetSlide, slideAnim]);

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(logoGlow, { toValue: 1, duration: 2600, useNativeDriver: true }),
        Animated.timing(logoGlow, { toValue: 0.86, duration: 2600, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => {
      pulse.stop();
    };
  }, [logoGlow]);

  const handlePressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.98, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const goAlt = async () => {
    await hapticFeedback('light');
    if (mode === 'login') router.push('/auth/signup' as any);
    else router.replace('/auth/login');
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={StyleSheet.absoluteFill}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(12,42,72,0.35)', 'rgba(6,22,40,0.72)', 'rgba(3,12,24,0.97)']}
        locations={[0.18, 0.52, 1]}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.blueWash, StyleSheet.absoluteFill]} pointerEvents="none" />

      <View style={[styles.heroWrap, { paddingTop: insets.top + 36 }]}>
        <Animated.View
          style={[
            styles.brandBlock,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
          ]}
        >
          <View
            style={styles.logoStage}
            onLayout={(e) => setLogoWidth(e.nativeEvent.layout.width)}
          >
            <Animated.View style={[styles.logoGlow, { opacity: logoGlow }]}>
              <Image source={NEW_AUTH_LOGO} resizeMode="contain" style={styles.logo} />
            </Animated.View>
            {logoWidth > 0 ? (
              <CurvedBrandTitle text={BRAND_LABEL} color={BRAND_ARC_BLUE} size={logoWidth} />
            ) : null}
          </View>
          <Text style={styles.tagline}>{tagline}</Text>
        </Animated.View>
      </View>

      <Animated.View
        style={[
          styles.sheetWrap,
          {
            opacity: fadeAnim,
            transform: [{ translateY: sheetSlide }],
          },
        ]}
      >
        <View style={[styles.sheetOuter, { paddingBottom: Math.max(insets.bottom, 16) }]}>
          <BlurView
            intensity={Platform.OS === 'ios' ? 32 : 22}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <View style={styles.sheetBlueTint} pointerEvents="none" />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.02)', 'transparent']}
            style={styles.sheetSheen}
            pointerEvents="none"
          />
          <View style={styles.sheetContent}>
          <View style={styles.sheetHandle} />

          <TouchableOpacity
            style={styles.emailCta}
            onPress={onOpenEmailSheet}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
            activeOpacity={1}
            disabled={loading}
          >
            <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
              <View style={styles.emailCtaInner}>
                <BlurView
                  intensity={Platform.OS === 'ios' ? 40 : 28}
                  tint="light"
                  style={StyleSheet.absoluteFill}
                  {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                />
                <View style={styles.emailCtaTint} pointerEvents="none" />
                <LinearGradient
                  colors={['rgba(255,255,255,0.45)', 'rgba(255,255,255,0.08)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={styles.emailCtaSheen}
                  pointerEvents="none"
                />
                <View style={styles.emailCtaContent}>
                  <BrandGlyph name="mail-outline" size={18} color="#F8FAFC" />
                  <Text style={styles.emailCtaText}>Continue with Email</Text>
                </View>
              </View>
            </Animated.View>
          </TouchableOpacity>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or continue with</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.socialRow}>
            {isAppleAvailable ? (
              <TouchableOpacity
                style={[styles.socialBtn, styles.socialApple]}
                onPress={onApple}
                onPressIn={handlePressIn}
                onPressOut={handlePressOut}
                activeOpacity={0.9}
                accessibilityLabel="Continue with Apple"
              >
                <BrandGlyph name="logo-apple" size={24} color="#000000" />
              </TouchableOpacity>
            ) : null}
            <TouchableOpacity
              style={[styles.socialBtn, styles.socialGoogle]}
              onPress={onGoogle}
              onPressIn={handlePressIn}
              onPressOut={handlePressOut}
              activeOpacity={0.9}
              accessibilityLabel="Continue with Google"
            >
              <BrandGlyph name="logo-google" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>

          <Text style={styles.trustText}>
            By continuing, you agree to{' '}
            <Text style={styles.trustLink} onPress={() => router.push('/terms-of-service')}>
              Terms
            </Text>
            {' & '}
            <Text style={styles.trustLink} onPress={() => router.push('/privacy-policy')}>
              Privacy Policy
            </Text>
          </Text>

          <View style={styles.altRow}>
            <Text style={styles.altText}>
              {mode === 'login' ? 'New here? ' : 'Already have an account? '}
            </Text>
            <TouchableOpacity onPress={goAlt} activeOpacity={0.8}>
              <Text style={styles.altLink}>{mode === 'login' ? 'Create an account' : 'Sign in'}</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.footer}>{BRAND_LABEL}</Text>
          </View>
        </View>
      </Animated.View>

      <Modal
        visible={emailSheetOpen}
        animationType="slide"
        transparent
        onRequestClose={onCloseEmailSheet}
      >
        <Pressable style={styles.modalOverlay} onPress={onCloseEmailSheet}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboard}
          >
            <Pressable style={styles.modalSheet} onPress={(e) => e.stopPropagation()}>
              <View style={styles.modalOuter}>
                <BlurView
                  intensity={Platform.OS === 'ios' ? 32 : 22}
                  tint="dark"
                  style={StyleSheet.absoluteFill}
                  {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
                />
                <View style={styles.sheetBlueTint} pointerEvents="none" />
                <View style={[styles.modalInner, { paddingBottom: Math.max(insets.bottom, 20) + 12 }]}>
                  <View style={styles.sheetHandle} />
                  <View style={styles.modalHeader}>
                    <Text style={styles.modalTitle}>{emailSheetTitle}</Text>
                    <TouchableOpacity
                      onPress={onCloseEmailSheet}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <BrandGlyph name="close" size={26} color="rgba(255,255,255,0.9)" />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.accountPill}>Car Care Pro</Text>
                  <ScrollView
                    keyboardShouldPersistTaps="handled"
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={styles.modalScroll}
                  >
                    {emailSheetChildren}
                  </ScrollView>
                </View>
              </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#061525',
  },
  blueWash: {
    backgroundColor: 'rgba(10,40,72,0.28)',
  },
  heroWrap: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 28,
    paddingBottom: 220,
  },
  brandBlock: {
    alignItems: 'center',
  },
  logoStage: {
    width: '96%',
    maxWidth: 400,
    aspectRatio: 380 / 238,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'visible',
    marginBottom: 6,
  },
  logoGlow: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  curveLayer: {
    position: 'absolute',
    left: 0,
    top: 0,
    overflow: 'visible',
  },
  curveLetter: {
    position: 'absolute',
    fontWeight: '500',
    textAlign: 'center',
    letterSpacing: 0,
    includeFontPadding: false,
  },
  tagline: {
    marginTop: 4,
    color: '#E8C547',
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 21,
    paddingHorizontal: 12,
  },
  sheetWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'transparent',
  },
  sheetOuter: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  sheetBlueTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(12,42,72,0.22)',
  },
  sheetSheen: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 48,
  },
  sheetContent: {
    paddingHorizontal: 22,
    paddingTop: 10,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.4)',
    marginBottom: 16,
  },
  emailCta: {
    borderRadius: 18,
    shadowColor: '#9EC9E0',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 5,
  },
  emailCtaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.42)',
    backgroundColor: 'rgba(158,201,224,0.18)',
  },
  emailCtaTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(158,201,224,0.22)',
  },
  emailCtaSheen: {
    ...StyleSheet.absoluteFillObject,
  },
  emailCtaContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 17,
    paddingHorizontal: 18,
  },
  emailCtaText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 18,
    marginBottom: 14,
  },
  dividerLine: {
    flex: 1,
    height: StyleSheet.hairlineWidth,
    backgroundColor: 'rgba(255,255,255,0.28)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.62)',
    fontSize: 12,
    fontWeight: '700',
  },
  socialRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 14,
  },
  socialBtn: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  socialApple: {
    backgroundColor: '#FFFFFF',
  },
  socialGoogle: {
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  trustText: {
    marginTop: 18,
    color: 'rgba(255,255,255,0.62)',
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
  },
  trustLink: {
    color: STEEL,
    fontWeight: '800',
    textDecorationLine: 'underline',
  },
  altRow: {
    marginTop: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  altText: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 13,
    fontWeight: '600',
  },
  altLink: {
    color: STEEL,
    fontSize: 13,
    fontWeight: '900',
  },
  footer: {
    marginTop: 14,
    marginBottom: 2,
    textAlign: 'center',
    color: 'rgba(255,255,255,0.42)',
    fontSize: 11,
    fontWeight: '700',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,35,55,0.4)',
    justifyContent: 'flex-end',
  },
  modalKeyboard: {
    width: '100%',
    maxHeight: '92%',
  },
  modalSheet: {
    maxHeight: '92%',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
  },
  modalOuter: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.28)',
  },
  modalInner: {
    paddingHorizontal: 22,
    paddingTop: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  modalTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
  },
  accountPill: {
    alignSelf: 'center',
    textAlign: 'center',
    marginBottom: 14,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    overflow: 'hidden',
    backgroundColor: 'rgba(158,201,224,0.22)',
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.4)',
    color: '#E8F4FA',
    fontSize: 12,
    fontWeight: '800',
  },
  modalScroll: {
    paddingBottom: 8,
  },
});
