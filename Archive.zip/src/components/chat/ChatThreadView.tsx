/**
 * Shared WhatsApp-like chat thread UI for valeter and business.
 * Floating header (dashboard-style), floating input bar attached to keyboard,
 * theme-aware for light/dark mode.
 */
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import GradientIconBox from '../shared/GradientIconBox';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { useGlobalTheme } from '../shared/GlobalThemeContext';
import { colors } from '../../constants/colors';
import { supabase } from '../../lib/supabase';
import { parseBookingPaymentRequestPayload, type BookingPaymentRequestPayload } from '../../services/bookingPaymentRequestService';

const { width } = Dimensions.get('window');
const DEFAULT_ACCENT = colors.SKY;
const BUBBLE_RADIUS = 18;

// Dark mode defaults
const DARK_RECEIVED_BG = 'rgba(45,55,72,0.85)';
const DARK_SENT_BG = 'rgba(30,64,175,0.9)';
const DARK_HEADER_GRADIENT: [string, string] = ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'];
// Light mode
const LIGHT_RECEIVED_BG = 'rgba(148,163,184,0.28)';
const LIGHT_SENT_BG = 'rgba(30,64,175,0.75)';
const LIGHT_HEADER_GRADIENT: [string, string] = ['rgba(74,122,142,0.5)', 'rgba(21,34,56,0.4)'];

export type MessageType = 'text' | 'image' | 'voice' | 'payment_request';

export type ChatMessage = {
  id: string;
  isFromMe: boolean;
  type: MessageType;
  content?: string;
  mediaUri?: string;
  voiceDurationSeconds?: number;
  paymentRequest?: BookingPaymentRequestPayload | null;
  time: string;
};

export interface ChatThreadViewProps {
  bookingId?: string | null;
  currentUserId?: string | null;
  currentUserRole?: 'customer' | 'valeter' | 'business' | null;
  title: string;
  subtitle?: string;
  onBack: () => void;
  onCall: () => void;
  onAttachImage?: () => void;
  onVoiceNote?: () => void;
  onRequestPayment?: () => void;
  onPaymentRequestPay?: (request: BookingPaymentRequestPayload, messageId: string) => void;
  onDelete?: () => void;
  accentColor?: string;
  backgroundColor?: string;
  /** Initial messages (e.g. from DB). Omit or pass [] for no mock data. */
  initialMessages?: ChatMessage[];
  /** When true, hide composer (e.g. completed job until customer messages). */
  composerLocked?: boolean;
  composerLockHint?: string;
}

export default function ChatThreadView({
  bookingId,
  currentUserId,
  currentUserRole,
  title,
  subtitle,
  onBack,
  onCall,
  onAttachImage,
  onVoiceNote,
  onRequestPayment,
  onPaymentRequestPay,
  onDelete,
  accentColor,
  backgroundColor: backgroundColorProp,
  initialMessages = [],
  composerLocked = false,
  composerLockHint,
}: ChatThreadViewProps) {
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();
  const { theme } = useAccountTheme();
  const isLight = mode === 'light';

  const accent = accentColor ?? theme?.primary ?? DEFAULT_ACCENT;
  const bgGradient = (theme?.background || ['#132F4C', '#0F2847']) as [string, string];
  const backgroundColor = backgroundColorProp ?? bgGradient[0];

  const headerGradient = isLight ? LIGHT_HEADER_GRADIENT : (theme?.headerBackground as [string, string]) || DARK_HEADER_GRADIENT;
  const headerBorder = theme?.glassBorder || (isLight ? 'rgba(126,184,212,0.4)' : 'rgba(59,130,246,0.3)');
  const headerTitleColor = theme?.textPrimary ?? '#F1F5F9';
  const headerSubtitleColor = theme?.textSecondary ?? '#94A3B8';

  const bubbleSentBg = isLight ? LIGHT_SENT_BG : DARK_SENT_BG;
  const bubbleReceivedBg = isLight ? LIGHT_RECEIVED_BG : DARK_RECEIVED_BG;
  const bubbleTextColor = theme?.textPrimary ?? '#F1F5F9';
  const bubbleTimeColor = theme?.textOnBackground ?? 'rgba(241,245,249,0.7)';
  const bubbleTimeSentColor = isLight ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.75)';
  const bubbleTimeReceivedColor = isLight ? 'rgba(30,41,59,0.8)' : 'rgba(148,163,184,0.9)';

  const inputBarBg = isLight ? 'rgba(255,255,255,0.92)' : 'rgba(30,41,59,0.95)';
  const inputBg = isLight ? 'rgba(226,232,240,0.9)' : 'rgba(51,65,85,0.8)';
  const inputTextColor = isLight ? '#1E293B' : (theme?.textPrimary ?? '#F1F5F9');
  const inputPlaceholderColor = isLight ? '#64748B' : '#94A3B8';
  const actionBtnBg = isLight ? 'rgba(226,232,240,0.9)' : 'rgba(51,65,85,0.8)';
  const imagePlaceholderBg = isLight ? 'rgba(148,163,184,0.25)' : 'rgba(0,0,0,0.25)';
  const voiceBarReceived = isLight ? 'rgba(100,116,139,0.6)' : 'rgba(148,163,184,0.6)';

  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [loadingMessages, setLoadingMessages] = useState(Boolean(bookingId));
  const scrollRef = useRef<ScrollView>(null);
  const isBookingChat = Boolean(bookingId);

  const appendLocalMessage = (message: ChatMessage) => {
    setMessages((prev) => [...prev, message]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
  };

  const mapDbRowToMessage = (row: {
    id: string;
    sender_id?: string | null;
    message_type?: string | null;
    content?: string | null;
    media_url?: string | null;
    voice_duration_seconds?: number | null;
    created_at?: string | null;
  }): ChatMessage => {
    const created = row.created_at ? new Date(row.created_at) : new Date();
    const type = (row.message_type as MessageType) || 'text';
    const paymentRequest = type === 'payment_request' ? parseBookingPaymentRequestPayload(row.content ?? null) : null;
    return {
      id: row.id,
      isFromMe: !!currentUserId && row.sender_id === currentUserId,
      type,
      content: row.content ?? undefined,
      mediaUri: row.media_url ?? undefined,
      voiceDurationSeconds: row.voice_duration_seconds ?? undefined,
      paymentRequest,
      time: created.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    };
  };

  useEffect(() => {
    if (!isBookingChat) {
      setMessages(initialMessages);
      setLoadingMessages(false);
      return;
    }

    let mounted = true;
    (async () => {
      try {
        setLoadingMessages(true);
        setMessages(initialMessages);
        const { data, error } = await supabase
          .from('booking_messages')
          .select('id, sender_id, message_type, content, media_url, voice_duration_seconds, created_at')
          .eq('booking_id', bookingId)
          .order('created_at', { ascending: true });

        if (error) {
          if (__DEV__) {
            console.warn('[ChatThreadView] load messages error:', error.message);
          }
          return;
        }

        if (!mounted) return;
        const next = (data || []).map((row: any) => mapDbRowToMessage(row));
        setMessages(initialMessages.length > 0 ? [...initialMessages, ...next] : next);
      } catch (error) {
        if (__DEV__) {
          console.warn('[ChatThreadView] load messages exception:', error);
        }
      } finally {
        if (mounted) setLoadingMessages(false);
      }
    })();

    const channel = supabase
      .channel(`booking-messages-${bookingId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'booking_messages', filter: `booking_id=eq.${bookingId}` },
        (payload) => {
          const row = payload.new as any;
          if (!row?.id) return;
          const next = mapDbRowToMessage(row);
          setMessages((prev) => (prev.some((msg) => msg.id === next.id) ? prev : [...prev, next]));
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
    // We intentionally load once per booking and keep live inserts only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId, currentUserId, isBookingChat]);

  const handleAttachImage = () => onAttachImage?.();
  const handleVoiceNote = () => onVoiceNote?.();
  const handleRequestPayment = () => onRequestPayment?.();

  const handleSend = async () => {
    const text = inputText.trim();
    if (!text) return;

    if (!isBookingChat) {
      appendLocalMessage({
        id: String(Date.now()),
        isFromMe: true,
        type: 'text',
        content: text,
        time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      });
      setInputText('');
      return;
    }

    if (!currentUserId || !bookingId) return;
    try {
      const { data, error } = await supabase
        .from('booking_messages')
        .insert({
          booking_id: bookingId,
          sender_id: currentUserId,
          sender_role: currentUserRole ?? 'unknown',
          message_type: 'text',
          content: text,
        })
        .select('id, sender_id, message_type, content, media_url, voice_duration_seconds, created_at')
        .single();

      if (error) throw error;

      if (data?.id) {
        const next = mapDbRowToMessage(data as any);
        setMessages((prev) => (prev.some((msg) => msg.id === next.id) ? prev : [...prev, next]));
      }

      setInputText('');
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
    } catch (error: any) {
      Alert.alert('Message failed', error?.message || 'Could not send message right now.');
    }
  };

  const headerHeight = 56;
  const contentTop = Math.max(HEADER_CONTENT_OFFSET, insets.top + 8 + headerHeight + 12);
  const inputBarBottom = insets.bottom + 12;

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <AppHeader
        title={title}
        subtitle={subtitle}
        onBack={onBack}
        rightAction={
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            {onDelete ? (
              <TouchableOpacity onPress={onDelete} style={{ padding: 8, marginRight: 8 }} hitSlop={12}>
                <Ionicons name="trash-outline" size={22} color={accent} />
              </TouchableOpacity>
            ) : null}
            <TouchableOpacity onPress={onCall} style={{ padding: 8 }} hitSlop={12}>
              <Ionicons name="call" size={22} color={accent} />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Messages – full area, padding so content is below header and above input */}
      <ScrollView
        ref={scrollRef}
        style={styles.messagesArea}
        contentContainerStyle={[
          styles.messagesContent,
          { paddingTop: contentTop, paddingBottom: 100 },
        ]}
        keyboardShouldPersistTaps="handled"
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}
        showsVerticalScrollIndicator={false}
      >
        {loadingMessages ? (
          <View style={styles.emptyWrap}>
            <ActivityIndicator size="small" color={accent} />
            <Text style={[styles.emptySubtitle, { color: headerSubtitleColor, marginTop: 12 }]}>
              Loading conversation…
            </Text>
          </View>
        ) : messages.length === 0 ? (
          <View style={styles.emptyWrap}>
            <View style={styles.emptyIconWrap}>
              <GradientIconBox icon="chatbubbles-outline" preset="sky" boxSize={80} size={40} />
            </View>
            <Text style={[styles.emptyTitle, { color: headerTitleColor }]}>No messages yet</Text>
            <Text style={[styles.emptySubtitle, { color: headerSubtitleColor }]}>
              Send a message to start the conversation
            </Text>
          </View>
        ) : (
        messages.map((msg) => (
          <View
            key={msg.id}
            style={[styles.bubbleWrap, msg.isFromMe ? styles.bubbleWrapSent : styles.bubbleWrapReceived]}
          >
            {msg.type === 'text' && (
              <View style={[styles.bubble, { backgroundColor: msg.isFromMe ? bubbleSentBg : bubbleReceivedBg }, msg.isFromMe ? styles.bubbleSent : styles.bubbleReceived]}>
                <Text style={[styles.bubbleText, { color: bubbleTextColor }]}>{msg.content}</Text>
                <Text style={[styles.bubbleTime, { color: msg.isFromMe ? bubbleTimeSentColor : bubbleTimeReceivedColor }]}>
                  {msg.time}
                </Text>
              </View>
            )}
            {msg.type === 'image' && (
              <View style={[styles.bubble, styles.bubbleMedia, { backgroundColor: msg.isFromMe ? bubbleSentBg : bubbleReceivedBg }, msg.isFromMe ? styles.bubbleSent : styles.bubbleReceived]}>
                {msg.mediaUri ? (
                  <Image source={{ uri: msg.mediaUri }} style={styles.messageImage} resizeMode="cover" />
                ) : (
                  <View style={[styles.imagePlaceholder, { backgroundColor: imagePlaceholderBg }]}>
                    <Ionicons name="image-outline" size={40} color={msg.isFromMe ? '#fff' : headerSubtitleColor} />
                    <Text style={[styles.mediaLabel, { color: msg.isFromMe ? 'rgba(255,255,255,0.9)' : headerSubtitleColor }]}>Photo</Text>
                  </View>
                )}
                {msg.content ? (
                  <Text style={[styles.mediaCaption, { color: msg.isFromMe ? 'rgba(255,255,255,0.92)' : headerSubtitleColor }]}>
                    {msg.content}
                  </Text>
                ) : null}
                <Text style={[styles.bubbleTime, styles.bubbleTimeOverMedia, { color: msg.isFromMe ? bubbleTimeSentColor : bubbleTimeReceivedColor }]}>
                  {msg.time}
                </Text>
              </View>
            )}
            {msg.type === 'voice' && (
              <View style={[styles.bubble, styles.bubbleVoice, { backgroundColor: msg.isFromMe ? bubbleSentBg : bubbleReceivedBg }, msg.isFromMe ? styles.bubbleSent : styles.bubbleReceived]}>
                <View style={styles.voiceRow}>
                  <TouchableOpacity style={[styles.voicePlayBtn, { backgroundColor: isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)' }]}>
                    <Ionicons name="play" size={20} color={msg.isFromMe ? '#fff' : accent} />
                  </TouchableOpacity>
                  <View style={styles.voiceWave}>
                    {[1, 2, 3, 4, 5].map((i) => (
                      <View key={i} style={[styles.voiceBar, msg.isFromMe ? styles.voiceBarSent : { backgroundColor: voiceBarReceived }]} />
                    ))}
                  </View>
                  <Text style={[styles.voiceDuration, { color: msg.isFromMe ? bubbleTimeSentColor : bubbleTimeReceivedColor }]}>
                    {msg.voiceDurationSeconds ?? 0}s
                  </Text>
                </View>
                <Text style={[styles.bubbleTime, { color: msg.isFromMe ? bubbleTimeSentColor : bubbleTimeReceivedColor }]}>
                  {msg.time}
                </Text>
              </View>
            )}
            {msg.type === 'payment_request' && (
              <View style={[styles.bubble, styles.paymentBubble, { backgroundColor: msg.isFromMe ? bubbleSentBg : bubbleReceivedBg }, msg.isFromMe ? styles.bubbleSent : styles.bubbleReceived]}>
                <View style={styles.paymentHeader}>
                  <View style={styles.paymentIconWrap}>
                    <Ionicons name="cash-outline" size={22} color={msg.isFromMe ? '#fff' : accent} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.paymentTitle, { color: bubbleTextColor }]}>Extra charge request</Text>
                    <Text style={[styles.paymentAmount, { color: msg.isFromMe ? '#fff' : accent }]}>
                      {new Intl.NumberFormat('en-GB', {
                        style: 'currency',
                        currency: (msg.paymentRequest?.currency || 'gbp').toUpperCase(),
                      }).format(msg.paymentRequest?.amount ?? 0)}
                    </Text>
                  </View>
                  <View style={[styles.paymentStatusPill, { borderColor: msg.paymentRequest?.status === 'paid' ? '#34D399' : `${accent}55` }]}>
                    <Text style={[styles.paymentStatusPillText, { color: msg.paymentRequest?.status === 'paid' ? '#34D399' : accent }]}>
                      {msg.paymentRequest?.status === 'paid'
                        ? 'Paid'
                        : msg.paymentRequest?.status === 'failed'
                          ? 'Failed'
                          : 'Pending'}
                    </Text>
                  </View>
                </View>

                <Text style={[styles.paymentReason, { color: msg.isFromMe ? 'rgba(255,255,255,0.92)' : headerSubtitleColor }]}>
                  {msg.paymentRequest?.reason}
                </Text>
                {msg.paymentRequest?.note ? (
                  <Text style={[styles.paymentNote, { color: msg.isFromMe ? 'rgba(255,255,255,0.82)' : headerSubtitleColor }]}>
                    {msg.paymentRequest.note}
                  </Text>
                ) : null}

                <View style={styles.paymentSplitRow}>
                  <Text style={[styles.paymentSplitText, { color: msg.isFromMe ? 'rgba(255,255,255,0.88)' : headerSubtitleColor }]}>
                    Platform fee: {new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(msg.paymentRequest?.platformFee ?? 0)}
                  </Text>
                  <Text style={[styles.paymentSplitText, { color: msg.isFromMe ? 'rgba(255,255,255,0.88)' : headerSubtitleColor }]}>
                    Valeter share: {new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(msg.paymentRequest?.valeterShare ?? 0)}
                  </Text>
                </View>

                {!msg.isFromMe && msg.paymentRequest?.status === 'pending' && onPaymentRequestPay ? (
                  <TouchableOpacity
                    onPress={() => onPaymentRequestPay(msg.paymentRequest as BookingPaymentRequestPayload, msg.id)}
                    style={[styles.paymentPayButton, { backgroundColor: accent }]}
                    activeOpacity={0.86}
                  >
                    <Text style={styles.paymentPayButtonText}>Pay now</Text>
                  </TouchableOpacity>
                ) : null}

                <Text style={[styles.bubbleTime, styles.bubbleTimeOverMedia, { color: msg.isFromMe ? bubbleTimeSentColor : bubbleTimeReceivedColor }]}>
                  {msg.time}
                </Text>
              </View>
            )}
          </View>
        ))
        )}
      </ScrollView>

      {/* Floating input bar – moves with keyboard */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
        style={styles.keyboardWrap}
      >
        {composerLocked ? (
          <View
            style={[
              styles.composerLockedBar,
              {
                backgroundColor: inputBarBg,
                marginHorizontal: 12,
                marginBottom: inputBarBottom,
                borderColor: isLight ? 'rgba(148,163,184,0.25)' : 'rgba(148,163,184,0.15)',
              },
            ]}
          >
            <Ionicons name="lock-closed-outline" size={20} color={accent} style={{ marginRight: 10 }} />
            <Text style={[styles.composerLockedText, { color: headerSubtitleColor }]}>
              {composerLockHint ||
                'Messaging is locked until the customer sends a message for this completed job.'}
            </Text>
          </View>
        ) : (
          <View
            style={[
              styles.inputRow,
              {
                backgroundColor: inputBarBg,
                marginHorizontal: 12,
                marginBottom: inputBarBottom,
                paddingVertical: 10,
                paddingHorizontal: 12,
                borderRadius: 24,
                borderWidth: 1,
                borderColor: isLight ? 'rgba(148,163,184,0.25)' : 'rgba(148,163,184,0.15)',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: isLight ? 0.08 : 0.2,
                shadowRadius: 12,
                elevation: 8,
              },
            ]}
          >
            <TouchableOpacity onPress={handleAttachImage} style={[styles.inputActionBtn, { backgroundColor: actionBtnBg }]}>
              <Ionicons name="image-outline" size={24} color={accent} />
            </TouchableOpacity>
            {onRequestPayment ? (
              <TouchableOpacity onPress={handleRequestPayment} style={[styles.inputActionBtn, { backgroundColor: actionBtnBg }]}>
                <Ionicons name="cash-outline" size={24} color={accent} />
              </TouchableOpacity>
            ) : null}
            <TextInput
              style={[styles.input, { backgroundColor: inputBg, color: inputTextColor }]}
              placeholder="Message"
              placeholderTextColor={inputPlaceholderColor}
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
            />
            <TouchableOpacity onPress={handleVoiceNote} style={[styles.inputActionBtn, { backgroundColor: actionBtnBg }]}>
              <Ionicons name="mic-outline" size={24} color={accent} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.sendBtn, { backgroundColor: accent }, !inputText.trim() && styles.sendBtnDisabled]}
              onPress={handleSend}
              disabled={!inputText.trim() || (isBookingChat && !currentUserId)}
            >
              <Ionicons name="send" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
        )}
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  header: {
    width: width - 40,
    borderRadius: 24,
    marginHorizontal: 20,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 20,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  headerBack: { padding: 6, marginRight: 4 },
  headerCenter: { flex: 1, minWidth: 0 },
  headerTitle: { fontSize: 17, fontWeight: '700' },
  headerSubtitle: { fontSize: 12, marginTop: 2 },
  headerAction: { padding: 8 },

  messagesArea: { flex: 1 },
  messagesContent: { paddingHorizontal: 16, paddingBottom: 24 },
  bubbleWrap: { marginBottom: 8, maxWidth: '82%' },
  bubbleWrapSent: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  bubbleWrapReceived: { alignSelf: 'flex-start', alignItems: 'flex-start' },
  bubble: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: BUBBLE_RADIUS,
    borderBottomRightRadius: 4,
    maxWidth: '100%',
  },
  bubbleSent: { borderBottomRightRadius: 4, borderBottomLeftRadius: BUBBLE_RADIUS },
  bubbleReceived: { borderBottomLeftRadius: 4, borderBottomRightRadius: BUBBLE_RADIUS },
  bubbleText: { fontSize: 16, lineHeight: 22 },
  bubbleTime: { fontSize: 11, marginTop: 4, alignSelf: 'flex-end' },
  bubbleTimeOverMedia: { position: 'absolute', bottom: 8, right: 12 },
  bubbleMedia: { padding: 0, overflow: 'hidden', minWidth: 160, minHeight: 120 },
  messageImage: { width: 220, height: 170 },
  imagePlaceholder: {
    width: 160,
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mediaLabel: { fontSize: 12, marginTop: 4 },
  mediaCaption: { fontSize: 12, fontWeight: '700', paddingHorizontal: 12, paddingTop: 8, paddingBottom: 18 },
  bubbleVoice: { minWidth: 140 },
  paymentBubble: {
    gap: 10,
    minWidth: 220,
  },
  paymentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  paymentIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  paymentTitle: {
    fontSize: 14,
    fontWeight: '800',
  },
  paymentAmount: {
    marginTop: 2,
    fontSize: 20,
    fontWeight: '900',
  },
  paymentStatusPill: {
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  paymentStatusPillText: {
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  paymentReason: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
  },
  paymentNote: {
    fontSize: 13,
    lineHeight: 19,
  },
  paymentSplitRow: {
    gap: 4,
  },
  paymentSplitText: {
    fontSize: 12,
    lineHeight: 18,
    fontWeight: '600',
  },
  paymentPayButton: {
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  paymentPayButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '900',
  },
  voiceRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  voicePlayBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  voiceWave: { flexDirection: 'row', alignItems: 'center', gap: 3, flex: 1 },
  voiceBar: {
    width: 4,
    height: 20,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.5)',
  },
  voiceBarSent: { backgroundColor: 'rgba(255,255,255,0.6)' },
  voiceDuration: { fontSize: 12 },

  keyboardWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
  },
  inputActionBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 100,
    borderRadius: 22,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: { opacity: 0.5 },
  composerLockedBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 24,
    borderWidth: 1,
  },
  composerLockedText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
  },

  emptyWrap: {
    flex: 1,
    minHeight: 200,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  emptyIconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 6,
  },
  emptySubtitle: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
