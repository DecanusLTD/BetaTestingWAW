import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../shared/ChromeGlyph';
import { router } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { colors } from '../../constants/colors';
import type { DevWorkItem, DevWorkSection, DevWorkStatus } from '../../constants/devWorkChecklists';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';

const SKY = colors.SKY ?? '#38BDF8';

const STATUS_META: Record<
  DevWorkStatus,
  { label: string; icon: IconGlyphName; color: string; bg: string }
> = {
  works: { label: 'Works', icon: 'checkmark-circle', color: '#6EE7B7', bg: 'rgba(16,185,129,0.2)' },
  partial: {
    label: 'Partial',
    icon: 'warning',
    color: '#FBBF24',
    bg: 'rgba(245,158,11,0.18)',
  },
  not_wired: {
    label: 'Not wired',
    icon: 'construct-outline',
    color: '#F87171',
    bg: 'rgba(248,113,113,0.16)',
  },
};

type Props = {
  accountType: 'valeter' | 'business';
  title: string;
  intro: string;
  sections: DevWorkSection[];
  footerNote?: string;
};

export default function DevWorkAuditScreen({ accountType, title, intro, sections, footerNote }: Props) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const bg = (theme.background ?? ['#0A1929', '#152238']) as [string, string];
  const primary = accountType === 'valeter' ? SKY : (theme.primary ?? '#A78BFA');

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <LinearGradient colors={bg} style={StyleSheet.absoluteFill} />
      {accountType === 'valeter' ? <BubbleBackground accountType="valeter" /> : null}

      <AppHeader
        title={title}
        accountType={accountType}
        leftAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Go back"
          >
            <Ionicons name="chevron-back" size={26} color={primary} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET + 8,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.introCard, { borderColor: `${primary}44` }]}>
          <Ionicons name="hammer-outline" size={22} color={primary} />
          <Text style={styles.introTitle}>Internal dev checklist</Text>
          <Text style={styles.introBody}>{intro}</Text>
          <View style={styles.legendRow}>
            {(Object.keys(STATUS_META) as DevWorkStatus[]).map((k) => {
              const m = STATUS_META[k];
              return (
                <View key={k} style={[styles.legendChip, { backgroundColor: m.bg }]}>
                  <Ionicons name={m.icon} size={14} color={m.color} />
                  <Text style={[styles.legendChipText, { color: m.color }]}>{m.label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {sections.map((section) => (
          <View key={section.id} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: primary }]}>{section.title}</Text>
            {section.items.map((item, idx) => (
              <DevWorkRow key={`${section.id}-${idx}`} item={item} primary={primary} />
            ))}
          </View>
        ))}

        {footerNote ? (
          <View style={[styles.footerCard, { borderColor: 'rgba(148,163,184,0.35)' }]}>
            <Text style={styles.footerText}>{footerNote}</Text>
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function DevWorkRow({ item, primary }: { item: DevWorkItem; primary: string }) {
  const meta = STATUS_META[item.status];
  return (
    <View style={[styles.itemCard, { borderColor: 'rgba(148,163,184,0.28)' }]}>
      <View style={styles.itemTop}>
        <View style={[styles.statusPill, { backgroundColor: meta.bg }]}>
          <Ionicons name={meta.icon} size={12} color={meta.color} />
          <Text style={[styles.statusPillText, { color: meta.color }]}>{meta.label}</Text>
        </View>
      </View>
      <Text style={styles.itemTitle}>{item.title}</Text>
      <Text style={styles.itemDetail}>{item.detail}</Text>
      {item.route ? (
        <Text style={[styles.itemMeta, { color: `${primary}cc` }]}>Route: {item.route}</Text>
      ) : null}
      {item.fileHint ? (
        <Text style={styles.itemFile} numberOfLines={2}>
          {item.fileHint}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16 },
  introCard: {
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
    marginBottom: 20,
    backgroundColor: 'rgba(15,23,42,0.55)',
    gap: 8,
  },
  introTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800' },
  introBody: { color: 'rgba(249,250,251,0.72)', fontSize: 12, lineHeight: 18 },
  legendRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 },
  legendChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  legendChipText: { fontSize: 10, fontWeight: '700' },
  section: { marginBottom: 18 },
  sectionTitle: { fontSize: 13, fontWeight: '900', letterSpacing: 0.6, marginBottom: 10 },
  itemCard: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
    backgroundColor: 'rgba(15,23,42,0.42)',
  },
  itemTop: { flexDirection: 'row', justifyContent: 'flex-end', marginBottom: 6 },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
  },
  statusPillText: { fontSize: 10, fontWeight: '800' },
  itemTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '800', marginBottom: 6 },
  itemDetail: { color: 'rgba(249,250,251,0.7)', fontSize: 12, lineHeight: 17 },
  itemMeta: { fontSize: 11, marginTop: 8, fontWeight: '600' },
  itemFile: { fontSize: 10, color: 'rgba(148,163,184,0.95)', marginTop: 6, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  footerCard: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginTop: 4,
    backgroundColor: 'rgba(30,58,138,0.22)',
  },
  footerText: { color: 'rgba(191,219,254,0.95)', fontSize: 11, lineHeight: 16 },
});
