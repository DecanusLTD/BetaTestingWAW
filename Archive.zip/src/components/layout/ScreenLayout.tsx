/**
 * ScreenLayout – consistent positioning for all app screens.
 * Ensures content sits below the header with correct padding and above the tab bar.
 */
import React from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ViewStyle,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  CONTENT_TOP_WITHOUT_SAFE,
  SCREEN_PADDING_H,
  SCREEN_BOTTOM_WITHOUT_SAFE,
} from '../../constants/screenLayout';

export interface ScreenLayoutProps {
  /** Header (e.g. AppHeader). Rendered at top; content starts below it. */
  header?: React.ReactNode;
  /** Main content. */
  children: React.ReactNode;
  /** Background (e.g. LinearGradient). Default: transparent. */
  background?: React.ReactNode;
  /** Use ScrollView for content. Default true. */
  scroll?: boolean;
  /** Extra style for the content container. */
  contentStyle?: ViewStyle;
  /** Extra style for the inner scroll/content view. */
  innerStyle?: ViewStyle;
  /** Keyboard avoiding (only when scroll). Default false. */
  keyboardAvoid?: boolean;
  /** Safe area edges. Default [] – we apply insets manually so header + content align. */
  edges?: ('top' | 'bottom' | 'left' | 'right')[];
  /** Pull-to-refresh (only when scroll). */
  refreshControl?: React.ReactElement<React.ComponentProps<typeof RefreshControl>>;
}

export default function ScreenLayout({
  header,
  children,
  background,
  scroll = true,
  contentStyle,
  innerStyle,
  keyboardAvoid = false,
  edges = [],
  refreshControl,
}: ScreenLayoutProps) {
  const insets = useSafeAreaInsets();

  const paddingTop = insets.top + CONTENT_TOP_WITHOUT_SAFE;
  const paddingBottom = insets.bottom + SCREEN_BOTTOM_WITHOUT_SAFE;
  const paddingHorizontal = SCREEN_PADDING_H;

  const contentPadding = {
    paddingTop,
    paddingBottom,
    paddingHorizontal,
  };

  const scrollProps = {
    style: styles.scroll,
    contentContainerStyle: [styles.scrollContent, contentPadding, innerStyle],
    showsVerticalScrollIndicator: false,
    keyboardShouldPersistTaps: 'handled' as const,
    refreshControl: refreshControl ?? undefined,
  };

  return (
    <View style={styles.container}>
      {background ? <View style={StyleSheet.absoluteFill}>{background}</View> : null}
      <SafeAreaView style={styles.safe} edges={edges}>
        {header ?? null}
        {scroll ? (
          keyboardAvoid ? (
            <KeyboardAvoidingView
              style={styles.flex}
              behavior={Platform.OS === 'ios' ? 'padding' : undefined}
              keyboardVerticalOffset={0}
            >
              <ScrollView {...scrollProps}>{children}</ScrollView>
            </KeyboardAvoidingView>
          ) : (
            <ScrollView {...scrollProps}>{children}</ScrollView>
          )
        ) : (
          <View style={[styles.content, contentPadding, contentStyle, innerStyle]}>{children}</View>
        )}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safe: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  content: {
    flex: 1,
  },
});
