import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Pressable,
  Platform,
} from 'react-native';
import Svg, { Path, Defs, LinearGradient as SvgGradient, Stop, Line, Circle, Rect, Text as SvgText } from 'react-native-svg';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export type EarningsChartPoint = {
  date: Date;
  iso: string;
  value: number;
  jobs: number;
};

export type EarningsPeriod = '7D' | '30D' | '90D' | 'ALL';

type ValeterEarningsTradingChartProps = Readonly<{
  points: EarningsChartPoint[];
  period: EarningsPeriod;
  onPeriodChange: (period: EarningsPeriod) => void;
  accent: string;
}>;

const CHART_HEIGHT = 220;
const CHART_PAD_TOP = 18;
const CHART_PAD_BOTTOM = 28;
const POINT_SPACING = 16;
const PLOT_HEIGHT = CHART_HEIGHT - CHART_PAD_TOP - CHART_PAD_BOTTOM;

const PERIODS: EarningsPeriod[] = ['7D', '30D', '90D', 'ALL'];

const ANDROID_BLUR_METHOD =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};

function formatMoney(value: number): string {
  return `£${value.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatAxisDate(date: Date): string {
  return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

function formatTickerDate(date: Date): string {
  return date.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

function buildDailySeriesFromBookings(bookings: any[]): EarningsChartPoint[] {
  const completed = bookings.filter((b) => ['completed', 'rated', 'closed'].includes(b.status));
  if (completed.length === 0) return [];

  const byDay = new Map<string, { value: number; jobs: number }>();
  let minTime = Date.now();
  let maxTime = 0;

  for (const b of completed) {
    const raw = b.completed_at || b.updated_at || b.created_at;
    if (!raw) continue;
    const d = new Date(raw);
    const t = d.getTime();
    if (t < minTime) minTime = t;
    if (t > maxTime) maxTime = t;
    const key = d.toISOString().slice(0, 10);
    const cur = byDay.get(key) ?? { value: 0, jobs: 0 };
    cur.value += Number(b.price) || 0;
    cur.jobs += 1;
    byDay.set(key, cur);
  }

  const start = new Date(minTime);
  start.setHours(0, 0, 0, 0);
  const end = new Date(maxTime);
  end.setHours(0, 0, 0, 0);

  const points: EarningsChartPoint[] = [];
  const cursor = new Date(start);
  while (cursor <= end) {
    const iso = cursor.toISOString().slice(0, 10);
    const bucket = byDay.get(iso) ?? { value: 0, jobs: 0 };
    points.push({
      date: new Date(cursor),
      iso,
      value: Math.round(bucket.value * 100) / 100,
      jobs: bucket.jobs,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  return points;
}

export function buildEarningsChartSeries(bookings: any[]): EarningsChartPoint[] {
  return buildDailySeriesFromBookings(bookings);
}

function periodDayCount(period: EarningsPeriod): number {
  if (period === '7D') return 7;
  if (period === '30D') return 30;
  return 90;
}

export function sliceEarningsPeriod(points: EarningsChartPoint[], period: EarningsPeriod): EarningsChartPoint[] {
  if (points.length === 0) return [];
  if (period === 'ALL') return points;

  const days = periodDayCount(period);
  const lastPoint = points.at(-1);
  if (!lastPoint) return [];
  const end = lastPoint.date;
  const start = new Date(end);
  start.setDate(start.getDate() - (days - 1));
  start.setHours(0, 0, 0, 0);

  const sliced = points.filter((p) => p.date >= start);
  if (sliced.length >= 2) return sliced;

  // Pad leading zero days so short histories still scroll
  const padded: EarningsChartPoint[] = [];
  const padStart = new Date(start);
  while (padStart <= end) {
    const iso = padStart.toISOString().slice(0, 10);
    const existing = points.find((p) => p.iso === iso);
    padded.push(
      existing ?? {
        date: new Date(padStart),
        iso,
        value: 0,
        jobs: 0,
      }
    );
    padStart.setDate(padStart.getDate() + 1);
  }
  return padded;
}

function indexFromChartX(x: number, pointCount: number): number {
  if (pointCount <= 1) return 0;
  return Math.max(0, Math.min(pointCount - 1, Math.round(x / POINT_SPACING)));
}

function formatDeltaPctLabel(deltaPct: number | null): string {
  if (deltaPct == null) return '';
  const prefix = deltaPct >= 0 ? '+' : '';
  return ` (${prefix}${deltaPct.toFixed(1)}%)`;
}

function EarningsDeltaLine({
  prevPoint,
  delta,
  deltaPct,
}: Readonly<{ prevPoint: EarningsChartPoint | null; delta: number; deltaPct: number | null }>) {
  if (!prevPoint) return null;
  const color = delta >= 0 ? '#4ADE80' : '#F87171';
  const sign = delta >= 0 ? '+' : '';
  return (
    <Text style={[styles.deltaText, { color }]}>
      {sign}
      {formatMoney(delta)}
      {formatDeltaPctLabel(deltaPct)} vs prior day
    </Text>
  );
}

function EarningsTickerCard({
  accent,
  displayValue,
  displayLabel,
  prevPoint,
  delta,
  deltaPct,
  period,
  periodTotal,
  periodJobs,
}: Readonly<{
  accent: string;
  displayValue: number;
  displayLabel: string;
  prevPoint: EarningsChartPoint | null;
  delta: number;
  deltaPct: number | null;
  period: EarningsPeriod;
  periodTotal: number;
  periodJobs: number;
}>) {
  const jobsLabel = periodJobs === 1 ? 'job' : 'jobs';
  return (
    <View style={[styles.tickerCard, { borderColor: `${accent}30` }]}>
      <BlurView intensity={Platform.OS === 'ios' ? 48 : 64} tint="dark" style={StyleSheet.absoluteFill} {...ANDROID_BLUR_METHOD} />
      <LinearGradient
        colors={[`${accent}14`, 'rgba(10,25,41,0.55)', 'rgba(10,25,41,0.85)']}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.tickerTopRow}>
        <Text style={styles.tickerEyebrow}>Daily revenue</Text>
        <View style={[styles.livePill, { borderColor: `${accent}45` }]}>
          <View style={[styles.liveDot, { backgroundColor: accent }]} />
          <Text style={[styles.liveText, { color: accent }]}>LIVE</Text>
        </View>
      </View>
      <Text style={styles.tickerValue}>{formatMoney(displayValue)}</Text>
      <Text style={styles.tickerDate}>{displayLabel}</Text>
      <View style={styles.tickerMetaRow}>
        {prevPoint ? <EarningsDeltaLine prevPoint={prevPoint} delta={delta} deltaPct={deltaPct} /> : null}
        <Text style={styles.tickerSub}>
          {period} · {formatMoney(periodTotal)} · {periodJobs} {jobsLabel}
        </Text>
      </View>
    </View>
  );
}

function EarningsPeriodSelector({
  accent,
  period,
  onPeriodChange,
}: Readonly<{
  accent: string;
  period: EarningsPeriod;
  onPeriodChange: (period: EarningsPeriod) => void;
}>) {
  return (
    <View style={styles.periodRow}>
      {PERIODS.map((p) => {
        const selected = period === p;
        return (
          <Pressable
            key={p}
            style={[styles.periodPill, selected && { backgroundColor: `${accent}22`, borderColor: `${accent}55` }]}
            onPress={() => onPeriodChange(p)}
          >
            <Text style={[styles.periodPillText, selected && { color: accent }]}>{p}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function EarningsChartScrollPanel({
  accent,
  chartWidth,
  maxValue,
  linePath,
  areaPath,
  coords,
  crosshair,
  scrubbing,
  points,
  xLabels,
  scrollRef,
  onScroll,
  updateIndexFromTouch,
}: Readonly<{
  accent: string;
  chartWidth: number;
  maxValue: number;
  linePath: string;
  areaPath: string;
  coords: Array<{ x: number; y: number; point: EarningsChartPoint }>;
  crosshair: { x: number; y: number; point: EarningsChartPoint } | undefined;
  scrubbing: boolean;
  points: EarningsChartPoint[];
  xLabels: number[];
  scrollRef: React.RefObject<ScrollView | null>;
  onScroll: (e: NativeSyntheticEvent<NativeScrollEvent>) => void;
  updateIndexFromTouch: (localX: number) => void;
}>) {
  const gridLines = [0, 0.25, 0.5, 0.75, 1];
  return (
    <View style={[styles.chartShell, { borderColor: `${accent}22` }]}>
      <View style={styles.yAxis}>
        {gridLines
          .slice()
          .reverse()
          .map((pct) => (
            <Text key={pct} style={styles.yLabel}>
              £{Math.round(maxValue * pct)}
            </Text>
          ))}
      </View>

      <View style={styles.chartViewport}>
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          scrollEventThrottle={16}
          onScroll={onScroll}
          contentContainerStyle={{ width: chartWidth }}
          decelerationRate="fast"
        >
          <Pressable onPress={(e) => updateIndexFromTouch(e.nativeEvent.locationX)}>
            <Svg width={chartWidth} height={CHART_HEIGHT}>
              <Defs>
                <SvgGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <Stop offset="0%" stopColor={accent} stopOpacity="0.42" />
                  <Stop offset="100%" stopColor={accent} stopOpacity="0" />
                </SvgGradient>
                <SvgGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                  <Stop offset="0%" stopColor={accent} stopOpacity="0.35" />
                  <Stop offset="50%" stopColor={accent} stopOpacity="1" />
                  <Stop offset="100%" stopColor="#A5F3FC" stopOpacity="1" />
                </SvgGradient>
              </Defs>

              {gridLines.map((pct) => {
                const y = CHART_PAD_TOP + PLOT_HEIGHT * (1 - pct);
                return (
                  <Line
                    key={pct}
                    x1={0}
                    y1={y}
                    x2={chartWidth}
                    y2={y}
                    stroke="rgba(255,255,255,0.06)"
                    strokeWidth={1}
                    strokeDasharray="4 6"
                  />
                );
              })}

              {areaPath ? <Path d={areaPath} fill="url(#areaGrad)" /> : null}
              {linePath ? (
                <Path d={linePath} stroke="url(#lineGrad)" strokeWidth={2.5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
              ) : null}

              {crosshair ? (
                <>
                  <Line
                    x1={crosshair.x}
                    y1={CHART_PAD_TOP}
                    x2={crosshair.x}
                    y2={CHART_PAD_TOP + PLOT_HEIGHT}
                    stroke={accent}
                    strokeWidth={1}
                    strokeOpacity={scrubbing ? 0.85 : 0.35}
                    strokeDasharray={scrubbing ? undefined : '3 4'}
                  />
                  <Circle cx={crosshair.x} cy={crosshair.y} r={scrubbing ? 6 : 4} fill={accent} opacity={0.95} />
                  <Circle cx={crosshair.x} cy={crosshair.y} r={scrubbing ? 11 : 8} fill={accent} opacity={0.18} />
                </>
              ) : null}

              {xLabels.map((i) => {
                const x = i * POINT_SPACING;
                const label = points[i] ? formatAxisDate(points[i].date) : '';
                return (
                  <React.Fragment key={points[i]?.iso ?? i}>
                    <Rect x={x - 0.5} y={CHART_PAD_TOP + PLOT_HEIGHT} width={1} height={6} fill="rgba(255,255,255,0.2)" />
                    <SvgText x={x} y={CHART_HEIGHT - 8} fill="rgba(249,250,251,0.4)" fontSize={10} fontWeight="600" textAnchor="middle">
                      {label}
                    </SvgText>
                  </React.Fragment>
                );
              })}
            </Svg>
          </Pressable>
        </ScrollView>
      </View>
    </View>
  );
}

export default function ValeterEarningsTradingChart({
  points,
  period,
  onPeriodChange,
  accent,
}: ValeterEarningsTradingChartProps) {
  const scrollRef = useRef<ScrollView>(null);
  const scrollXRef = useRef(0);
  const [activeIndex, setActiveIndex] = useState(() => Math.max(0, points.length - 1));
  const [scrubbing, setScrubbing] = useState(false);

  const chartWidth = Math.max(SCREEN_WIDTH - 40, points.length * POINT_SPACING);

  const maxValue = useMemo(() => {
    const peak = points.reduce((m, p) => Math.max(m, p.value), 0);
    return peak > 0 ? peak * 1.12 : 1;
  }, [points]);

  const coords = useMemo(() => {
    return points.map((p, i) => {
      const x = i * POINT_SPACING;
      const y = CHART_PAD_TOP + PLOT_HEIGHT - (p.value / maxValue) * PLOT_HEIGHT;
      return { x, y, point: p };
    });
  }, [points, maxValue]);

  const linePath = useMemo(() => {
    if (coords.length === 0) return '';
    return coords.map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x} ${c.y}`).join(' ');
  }, [coords]);

  const areaPath = useMemo(() => {
    if (coords.length === 0) return '';
    const baseY = CHART_PAD_TOP + PLOT_HEIGHT;
    const first = coords[0];
    const last = coords.at(-1);
    if (!first || !last) return '';
    return `${linePath} L ${last.x} ${baseY} L ${first.x} ${baseY} Z`;
  }, [coords, linePath]);

  const periodTotal = useMemo(() => points.reduce((s, p) => s + p.value, 0), [points]);
  const periodJobs = useMemo(() => points.reduce((s, p) => s + p.jobs, 0), [points]);

  const activePoint = points[activeIndex] ?? points.at(-1);
  const prevPoint = activeIndex > 0 ? points[activeIndex - 1] : null;
  const delta = activePoint && prevPoint ? activePoint.value - prevPoint.value : 0;
  const deltaPct =
    prevPoint && prevPoint.value > 0 ? ((activePoint.value - prevPoint.value) / prevPoint.value) * 100 : null;

  useEffect(() => {
    setActiveIndex(Math.max(0, points.length - 1));
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ x: Math.max(0, chartWidth - SCREEN_WIDTH + 40), animated: false });
    });
  }, [period, points.length, chartWidth]);

  const updateIndexFromTouch = useCallback(
    (localX: number) => {
      const globalX = localX + scrollXRef.current;
      setActiveIndex(indexFromChartX(globalX, points.length));
      setScrubbing(true);
    },
    [points.length]
  );

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    scrollXRef.current = e.nativeEvent.contentOffset.x;
    if (points.length > 0) {
      const viewportCenter = scrollXRef.current + (SCREEN_WIDTH - 40) / 2 - 44;
      setActiveIndex(indexFromChartX(viewportCenter, points.length));
      setScrubbing(false);
    }
  };

  const crosshair = coords[activeIndex];

  const xLabels = useMemo(() => {
    if (points.length === 0) return [];
    const step = Math.max(1, Math.floor(points.length / 5));
    const indices: number[] = [];
    for (let i = 0; i < points.length; i += step) indices.push(i);
    if (indices.at(-1) !== points.length - 1) indices.push(points.length - 1);
    return indices;
  }, [points.length]);

  const displayValue = activePoint?.value ?? 0;
  const displayLabel = activePoint ? formatTickerDate(activePoint.date) : '—';

  return (
    <View style={styles.root}>
      <EarningsTickerCard
        accent={accent}
        displayValue={displayValue}
        displayLabel={displayLabel}
        prevPoint={prevPoint}
        delta={delta}
        deltaPct={deltaPct}
        period={period}
        periodTotal={periodTotal}
        periodJobs={periodJobs}
      />

      <EarningsPeriodSelector accent={accent} period={period} onPeriodChange={onPeriodChange} />

      <EarningsChartScrollPanel
        accent={accent}
        chartWidth={chartWidth}
        maxValue={maxValue}
        linePath={linePath}
        areaPath={areaPath}
        coords={coords}
        crosshair={crosshair}
        scrubbing={scrubbing}
        points={points}
        xLabels={xLabels}
        scrollRef={scrollRef}
        onScroll={onScroll}
        updateIndexFromTouch={updateIndexFromTouch}
      />

      <Text style={styles.hint}>Slide to explore · tap a point to inspect</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    gap: 14,
  },
  tickerCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 20,
    overflow: 'hidden',
  },
  tickerTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  tickerEyebrow: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  livePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.5)',
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  liveText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1,
  },
  tickerValue: {
    color: '#F9FAFB',
    fontSize: 38,
    fontWeight: '800',
    letterSpacing: -1,
    fontVariant: ['tabular-nums'],
  },
  tickerDate: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 4,
  },
  tickerMetaRow: {
    marginTop: 10,
    minHeight: 18,
  },
  tickerSub: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    fontWeight: '600',
  },
  deltaText: {
    fontSize: 13,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  periodRow: {
    flexDirection: 'row',
    gap: 8,
  },
  periodPill: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(15,23,42,0.45)',
  },
  periodPillText: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  chartShell: {
    flexDirection: 'row',
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(8,15,28,0.72)',
    overflow: 'hidden',
    paddingRight: 4,
  },
  yAxis: {
    width: 44,
    height: CHART_HEIGHT,
    justifyContent: 'space-between',
    paddingVertical: CHART_PAD_TOP - 4,
    paddingLeft: 8,
  },
  yLabel: {
    color: 'rgba(249,250,251,0.35)',
    fontSize: 9,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  chartViewport: {
    flex: 1,
    height: CHART_HEIGHT,
  },
  hint: {
    textAlign: 'center',
    color: 'rgba(249,250,251,0.35)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
});
