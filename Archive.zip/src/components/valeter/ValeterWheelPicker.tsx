import React, { useEffect, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
  ListRenderItemInfo,
} from 'react-native';
import { useAccountTheme } from '../shared/AccountThemeProvider';

const ITEM_HEIGHT = 44;
const VISIBLE_ROWS = 5;
const WHEEL_PAD = Math.floor(VISIBLE_ROWS / 2) * ITEM_HEIGHT;

type WheelColumnProps = Readonly<{
  values: number[];
  selected: number;
  onSelect: (value: number) => void;
  format: (value: number) => string;
  accent?: string;
  width?: number;
}>;

function WheelColumn({ values, selected, onSelect, format, accent = '#38BDF8', width }: WheelColumnProps) {
  const { theme } = useAccountTheme();
  const isLight = theme.mode === 'light';
  const listRef = useRef<FlatList<number>>(null);
  const selectedIndex = Math.max(0, values.indexOf(selected));

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        listRef.current?.scrollToOffset({ offset: selectedIndex * ITEM_HEIGHT, animated: false });
      } catch {
        /* list may not be ready */
      }
    }, 40);
    return () => clearTimeout(timer);
  }, [selectedIndex]);

  const handleScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    const index = Math.min(values.length - 1, Math.max(0, Math.round(offsetY / ITEM_HEIGHT)));
    const next = values[index];
    if (next != null && next !== selected) onSelect(next);
  };

  const renderItem = ({ item }: ListRenderItemInfo<number>) => {
    const active = item === selected;
    return (
      <View style={styles.item}>
        <Text style={[styles.itemText, active && { color: accent, fontWeight: '800', fontSize: 24 }]}>
          {format(item)}
        </Text>
      </View>
    );
  };

  return (
    <View style={[styles.columnWrap, width != null ? { width, flex: 0 } : null]}>
      <FlatList
        ref={listRef}
        data={values}
        keyExtractor={(v) => String(v)}
        renderItem={renderItem}
        showsVerticalScrollIndicator={false}
        snapToInterval={ITEM_HEIGHT}
        decelerationRate="fast"
        nestedScrollEnabled
        getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
        contentContainerStyle={{ paddingVertical: WHEEL_PAD }}
        onMomentumScrollEnd={handleScrollEnd}
        onScrollEndDrag={handleScrollEnd}
        initialScrollIndex={selectedIndex > 0 ? selectedIndex : 0}
        onScrollToIndexFailed={() => {
          listRef.current?.scrollToOffset({ offset: selectedIndex * ITEM_HEIGHT, animated: false });
        }}
      />
      <View
        style={[
          styles.selectionBand,
          {
            borderColor: `${accent}40`,
            backgroundColor: isLight ? 'rgba(158,201,224,0.12)' : 'rgba(255,255,255,0.06)',
          },
        ]}
        pointerEvents="none"
      />
    </View>
  );
}

export type ValeterPriceWheelPickerProps = Readonly<{
  value: number;
  onChange: (value: number) => void;
  accent?: string;
  /** Inclusive minimum price in £ (default 0). */
  minValue?: number;
  /** Inclusive maximum price in £ (default 500). */
  maxValue?: number;
  /** @deprecated Prefer maxValue */
  maxPounds?: number;
}>;

function clampPrice(n: number, min: number, max: number): number {
  if (!Number.isFinite(n)) return min;
  return Number(Math.min(max, Math.max(min, n)).toFixed(2));
}

export function ValeterPriceWheelPicker({
  value,
  onChange,
  accent,
  minValue = 0,
  maxValue,
  maxPounds = 500,
}: ValeterPriceWheelPickerProps) {
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F9FAFB';
  const textMuted = theme.textSecondary ?? 'rgba(148,163,184,0.85)';
  const min = Math.max(0, Number.isFinite(minValue) ? minValue : 0);
  const max = Math.max(min, Number.isFinite(maxValue) ? (maxValue as number) : maxPounds);
  const safe = clampPrice(value, min, max);
  let pounds = Math.floor(safe);
  let pence = Math.round((safe - pounds) * 100);
  if (pence >= 100) {
    pounds = Math.min(Math.floor(max), pounds + 1);
    pence = 0;
  }

  const minPound = Math.floor(min);
  const maxPound = Math.floor(max);
  const poundValues = useMemo(
    () => Array.from({ length: maxPound - minPound + 1 }, (_, i) => minPound + i),
    [minPound, maxPound]
  );

  const minPence = pounds === minPound ? Math.round((min - minPound) * 100) : 0;
  const maxPence = pounds === maxPound ? Math.round((max - maxPound) * 100) : 99;
  const penceValues = useMemo(
    () => Array.from({ length: Math.max(0, maxPence - minPence) + 1 }, (_, i) => minPence + i),
    [minPence, maxPence]
  );

  const setPounds = (nextPounds: number) => {
    onChange(clampPrice(nextPounds + pence / 100, min, max));
  };

  const setPence = (nextPence: number) => {
    onChange(clampPrice(pounds + nextPence / 100, min, max));
  };

  return (
    <View style={styles.priceWrap}>
      <Text style={[styles.preview, { color: accent ?? textMain }]}>
        £{pounds}.{String(pence).padStart(2, '0')}
      </Text>
      <View style={styles.priceRow}>
        <Text style={[styles.priceSymbol, { color: textMain }]}>£</Text>
        <WheelColumn
          values={poundValues}
          selected={pounds}
          onSelect={setPounds}
          format={(v) => String(v)}
          accent={accent}
          width={120}
        />
        <Text style={[styles.priceDot, { color: textMain }]}>.</Text>
        <WheelColumn
          values={penceValues}
          selected={Math.min(maxPence, Math.max(minPence, pence))}
          onSelect={setPence}
          format={(v) => String(v).padStart(2, '0')}
          accent={accent}
          width={88}
        />
      </View>
      <View style={styles.labelsRow}>
        <Text style={[styles.colLabel, { color: textMuted }]}>Pounds</Text>
        <Text style={[styles.colLabel, { color: textMuted }]}>Pence</Text>
      </View>
    </View>
  );
}

export type ValeterDurationWheelPickerProps = Readonly<{
  minutes: number;
  onChange: (minutes: number) => void;
  accent?: string;
  min?: number;
  max?: number;
  step?: number;
}>;

export function ValeterDurationWheelPicker({
  minutes,
  onChange,
  accent,
  min = 5,
  max = 480,
  step = 5,
}: ValeterDurationWheelPickerProps) {
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F9FAFB';
  const values = useMemo(
    () => Array.from({ length: Math.floor((max - min) / step) + 1 }, (_, i) => min + i * step),
    [min, max, step]
  );
  const selected = values.reduce((prev, cur) => (Math.abs(cur - minutes) < Math.abs(prev - minutes) ? cur : prev), values[0]);

  return (
    <View style={styles.durationWrap}>
      <Text style={[styles.preview, { color: accent ?? textMain }]}>{selected} min</Text>
      <View style={styles.durationRow}>
        <WheelColumn values={values} selected={selected} onSelect={onChange} format={(v) => `${v}`} accent={accent} width={140} />
        <Text style={[styles.durationSuffix, { color: textMain }]}>min</Text>
      </View>
    </View>
  );
}

export function formatExperienceLabel(years: number, months: number): string {
  const y = Math.max(0, Math.floor(years));
  const m = Math.max(0, Math.min(11, Math.floor(months)));
  if (y === 0 && m === 0) return 'Less than 1 month';
  const parts: string[] = [];
  if (y > 0) parts.push(y === 1 ? '1 year' : `${y} years`);
  if (m > 0) parts.push(m === 1 ? '1 month' : `${m} months`);
  return parts.join(' ');
}

export function parseExperienceLabel(raw: string | null | undefined): { years: number; months: number } {
  const t = (raw || '').trim().toLowerCase();
  if (!t || t === '—' || t === '-') return { years: 0, months: 0 };
  const yearMatch = t.match(/(\d+)\s*y/);
  const monthMatch = t.match(/(\d+)\s*m/);
  const years = yearMatch ? Number(yearMatch[1]) : 0;
  const months = monthMatch ? Number(monthMatch[1]) : 0;
  if (!yearMatch && !monthMatch) {
    const n = Number(t.replace(/[^\d]/g, ''));
    if (Number.isFinite(n) && n > 0) return { years: Math.min(40, n), months: 0 };
  }
  return { years: Math.min(40, years), months: Math.min(11, months) };
}

export type ValeterExperienceWheelPickerProps = Readonly<{
  years: number;
  months: number;
  onChange: (next: { years: number; months: number }) => void;
  accent?: string;
}>;

export function ValeterExperienceWheelPicker({ years, months, onChange, accent }: ValeterExperienceWheelPickerProps) {
  const { theme } = useAccountTheme();
  const textMain = theme.textPrimary ?? '#F9FAFB';
  const textMuted = theme.textSecondary ?? 'rgba(148,163,184,0.85)';
  const yearValues = useMemo(() => Array.from({ length: 41 }, (_, i) => i), []);
  const monthValues = useMemo(() => Array.from({ length: 12 }, (_, i) => i), []);
  const y = Math.min(40, Math.max(0, years));
  const m = Math.min(11, Math.max(0, months));

  return (
    <View style={styles.experienceWrap}>
      <Text style={[styles.preview, { color: accent ?? textMain }]}>{formatExperienceLabel(y, m)}</Text>
      <View style={styles.experienceRow}>
        <WheelColumn
          values={yearValues}
          selected={y}
          onSelect={(nextYears) => onChange({ years: nextYears, months: m })}
          format={(v) => String(v)}
          accent={accent}
          width={110}
        />
        <Text style={[styles.experienceUnit, { color: textMain }]}>yr</Text>
        <WheelColumn
          values={monthValues}
          selected={m}
          onSelect={(nextMonths) => onChange({ years: y, months: nextMonths })}
          format={(v) => String(v)}
          accent={accent}
          width={88}
        />
        <Text style={[styles.experienceUnit, { color: textMain }]}>mo</Text>
      </View>
      <View style={styles.labelsRow}>
        <Text style={[styles.colLabel, { color: textMuted }]}>Years</Text>
        <Text style={[styles.colLabel, { color: textMuted }]}>Months</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  columnWrap: {
    height: ITEM_HEIGHT * VISIBLE_ROWS,
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
  },
  item: {
    height: ITEM_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  itemText: {
    color: 'rgba(148,163,184,0.75)',
    fontSize: 20,
    fontWeight: '600',
  },
  selectionBand: {
    position: 'absolute',
    left: 4,
    right: 4,
    top: WHEEL_PAD,
    height: ITEM_HEIGHT,
    borderRadius: 12,
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  priceWrap: {
    paddingBottom: 12,
  },
  preview: {
    textAlign: 'center',
    fontSize: 28,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    gap: 6,
  },
  priceSymbol: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    width: 22,
    textAlign: 'center',
  },
  priceDot: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
  },
  labelsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 72,
    marginTop: 4,
  },
  colLabel: {
    color: 'rgba(148,163,184,0.8)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  durationWrap: {
    paddingBottom: 12,
  },
  durationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    gap: 12,
  },
  durationSuffix: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 18,
    fontWeight: '700',
    width: 40,
  },
  experienceWrap: {
    paddingBottom: 12,
  },
  experienceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    gap: 6,
  },
  experienceUnit: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 16,
    fontWeight: '700',
    width: 28,
  },
});
