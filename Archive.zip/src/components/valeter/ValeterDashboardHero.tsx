import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Platform,
  Easing,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { SCREEN_PADDING_H, HERO_NUMBER_SIZE } from '../../constants/premiumTokens';

const DAILY_EARNINGS_GOAL = 100;
const ANDROID_BLUR =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};

function AnimatedEarnings({ value, accent }: { value: number; accent: string }) {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = React.useState(0);

  useEffect(() => {
    anim.setValue(0);
    const listener = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, {
      toValue: value,
      duration: 700,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
    return () => anim.removeListener(listener);
  }, [anim, value]);

  return (
    <Text style={[styles.earningsValue, { color: accent }]}>
      £{display.toFixed(2)}
    </Text>
  );
}

export type ValeterDashboardHeroProps = Readonly<{
  earnings: number;
  jobsCompleted: number;
  jobRequestCount: number;
  isOnline: boolean;
  nearbyCustomerCount: number;
  accent: string;
  topOffset: number;
  loading?: boolean;
  toggling?: boolean;
  onToggleOnline: () => void;
}>;

export default function ValeterDashboardHero({
  earnings,
  jobsCompleted,
  jobRequestCount,
  isOnline,
  nearbyCustomerCount,
  accent,
  topOffset,
  loading = false,
  toggling = false,
  onToggleOnline,
}: ValeterDashboardHeroProps) {
  const goalProgress = Math.min(earnings / DAILY_EARNINGS_GOAL, 1);
  const remaining = Math.max(DAILY_EARNINGS_GOAL - earnings, 0);
  const busy = loading || toggling;

  const handleToggle = async () => {
    await hapticFeedback('medium');
    onToggleOnline();
  };

  if (isOnline) {
    return (
      <View style={[styles.compactWrap, { top: topOffset }]}>
        <BlurView intensity={Platform.OS === 'ios' ? 56 : 72} tint="dark" style={StyleSheet.absoluteFill} {...ANDROID_BLUR} />
        <LinearGradient
          colors={['rgba(16,185,129,0.14)', 'rgba(15,23,42,0.88)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={[styles.compactInner, { borderColor: `${accent}35` }]}>
          <View style={styles.compactLeft}>
            <Text style={[styles.compactEarnings, { color: accent }]}>£{earnings.toFixed(2)}</Text>
            <Text style={styles.compactMeta}>
              {jobsCompleted} job{jobsCompleted === 1 ? '' : 's'}
              {jobRequestCount > 0 ? ` · ${jobRequestCount} request${jobRequestCount === 1 ? '' : 's'}` : ''}
            </Text>
          </View>
          <TouchableOpacity
            style={[styles.compactOnlineBtn, jobRequestCount > 0 && styles.compactOnlineBtnAlert]}
            onPress={handleToggle}
            disabled={busy}
            activeOpacity={0.85}
          >
            {busy ? (
              <ActivityIndicator size="small" color="#4ADE80" />
            ) : (
              <>
                <View style={styles.onlineDotLive} />
                <Text style={styles.compactOnlineText}>Online</Text>
                <Ionicons name="pause" size={14} color="#4ADE80" />
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.heroWrap, { top: topOffset }]}>
      <BlurView intensity={Platform.OS === 'ios' ? 64 : 80} tint="dark" style={StyleSheet.absoluteFill} {...ANDROID_BLUR} />
      <LinearGradient
        colors={[`${accent}22`, 'rgba(15,23,42,0.92)', 'rgba(10,25,41,0.96)']}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.heroCard, { borderColor: `${accent}30` }]}>
        <View style={styles.heroTopRow}>
          <Text style={styles.heroEyebrow}>Today&apos;s earnings</Text>
          <View style={styles.offlinePill}>
            <View style={styles.offlineDot} />
            <Text style={styles.offlineLabel}>Offline</Text>
          </View>
        </View>

        <AnimatedEarnings value={earnings} accent={accent} />

        <View style={styles.goalBlock}>
          <View style={styles.goalTrack}>
            <View style={[styles.goalFill, { width: `${goalProgress * 100}%`, backgroundColor: accent }]} />
          </View>
          <Text style={styles.goalLabel}>
            {remaining > 0
              ? `£${remaining.toFixed(0)} to £${DAILY_EARNINGS_GOAL} daily goal`
              : `Daily goal reached — keep going`}
          </Text>
        </View>

        <View style={styles.statsMiniRow}>
          <View style={styles.statsMiniItem}>
            <Ionicons name="checkmark-done" size={14} color="rgba(249,250,251,0.55)" />
            <Text style={styles.statsMiniText}>{jobsCompleted} completed</Text>
          </View>
          {jobRequestCount > 0 ? (
            <View style={styles.statsMiniItem}>
              <Ionicons name="notifications" size={14} color={accent} />
              <Text style={[styles.statsMiniText, { color: accent }]}>{jobRequestCount} waiting</Text>
            </View>
          ) : null}
        </View>

        <TouchableOpacity
          style={[styles.goOnlineBtn, { backgroundColor: accent }]}
          onPress={handleToggle}
          disabled={busy}
          activeOpacity={0.88}
        >
          {busy ? (
            <ActivityIndicator size="small" color="#0A1929" />
          ) : (
            <>
              <Ionicons name="flash" size={20} color="#0A1929" />
              <View style={styles.goOnlineCopy}>
                <Text style={styles.goOnlineTitle}>Go online</Text>
                <Text style={styles.goOnlineSub}>
                  {nearbyCustomerCount > 0
                    ? `${nearbyCustomerCount} customer${nearbyCustomerCount === 1 ? '' : 's'} near you`
                    : 'Start accepting wash requests'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#0A1929" />
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  heroWrap: {
    position: 'absolute',
    left: SCREEN_PADDING_H,
    right: SCREEN_PADDING_H,
    zIndex: 12,
    borderRadius: 22,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 12,
  },
  heroCard: {
    padding: 18,
    borderWidth: 1,
    borderRadius: 22,
  },
  heroTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  heroEyebrow: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  offlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(248,113,113,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.3)',
  },
  offlineDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#F87171',
  },
  offlineLabel: {
    color: '#FCA5A5',
    fontSize: 11,
    fontWeight: '700',
  },
  earningsValue: {
    fontSize: HERO_NUMBER_SIZE,
    fontWeight: '800',
    letterSpacing: -1,
    marginBottom: 12,
  },
  goalBlock: {
    marginBottom: 12,
    gap: 6,
  },
  goalTrack: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  goalFill: {
    height: '100%',
    borderRadius: 3,
  },
  goalLabel: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '600',
  },
  statsMiniRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 14,
  },
  statsMiniItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  statsMiniText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  goOnlineBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 16,
  },
  goOnlineCopy: {
    flex: 1,
    minWidth: 0,
  },
  goOnlineTitle: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '800',
  },
  goOnlineSub: {
    color: 'rgba(10,25,41,0.65)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 1,
  },
  compactWrap: {
    position: 'absolute',
    left: SCREEN_PADDING_H,
    right: SCREEN_PADDING_H,
    zIndex: 12,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  compactInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderRadius: 16,
    gap: 12,
  },
  compactLeft: {
    flex: 1,
    minWidth: 0,
  },
  compactEarnings: {
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  compactMeta: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  compactOnlineBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(74,222,128,0.35)',
  },
  compactOnlineBtnAlert: {
    backgroundColor: 'rgba(245,158,11,0.18)',
    borderColor: 'rgba(251,191,36,0.45)',
  },
  onlineDotLive: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4ADE80',
  },
  compactOnlineText: {
    color: '#6EE7B7',
    fontSize: 13,
    fontWeight: '800',
  },
});
