import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { LocationStyleIconBox } from '../shared/GradientIconBox';
import ValeterTrackingProgressRing from './ValeterTrackingProgressRing';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { getStatusProgress } from '../../utils/trackingStatusHelpers';
import { CONTINUE_CTA_ICON_NAME } from '../../utils/bookingContinueStyle';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import type { ValeterJobRequest } from './ValeterJobRequestOverlay';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { lightMistPanel, lightMistElevated, lightMistInput } from '../../constants/accountThemes';

function useSheetCardTheme() {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const accentSoft = theme.primary ?? '#9EC9E0';
  const money = theme.accentAlt ?? '#E8C547';
  return {
    isLight,
    amber: money,
    textMain: theme.textPrimary ?? '#F8FAFC',
    textMuted: theme.textSecondary ?? 'rgba(248,250,252,0.7)',
    textSoft: 'rgba(248,250,252,0.5)',
    cardBg: isLight ? lightMistElevated : 'rgba(15,23,42,0.55)',
    cardBgSoft: isLight ? lightMistPanel : 'rgba(15,23,42,0.4)',
    cardBgStrong: isLight ? lightMistElevated : 'rgba(15,23,42,0.65)',
    chipBg: isLight ? lightMistInput : 'rgba(15,23,42,0.6)',
    footerBorder: isLight ? 'rgba(232,197,71,0.2)' : 'rgba(255,255,255,0.08)',
    declineBg: isLight ? lightMistPanel : 'rgba(255,255,255,0.08)',
    declineBorder: isLight ? 'rgba(158,201,224,0.3)' : 'rgba(255,255,255,0.12)',
    cardBorder: isLight ? 'rgba(158,201,224,0.36)' : undefined,
    moneyColor: money,
  };
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function statusRingColor(status: string): string {
  switch (status) {
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return '#38BDF8';
    default:
      return '#8B5CF6';
  }
}

export type ActiveJobCardProps = Readonly<{
  accent: string;
  serviceType?: string | null;
  serviceName?: string | null;
  customerName: string;
  address?: string | null;
  status: string;
  price: number;
  selected?: boolean;
  loading?: boolean;
  /** Hide the in-card Track CTA (e.g. when a full-width button sits under the card). */
  hideTrackCta?: boolean;
  onPress: () => void;
  onShowOnMap?: () => void;
}>;

export function ValeterActiveJobCard({
  accent,
  serviceType,
  serviceName,
  customerName,
  address,
  status,
  price,
  selected = false,
  loading = false,
  hideTrackCta = false,
  onPress,
  onShowOnMap,
}: ActiveJobCardProps) {
  const t = useSheetCardTheme();
  if (loading) {
    return (
      <View style={styles.loadingWrap}>
        <DefaultLoadingSkeleton message="Checking active job…" />
      </View>
    );
  }

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={onPress}
      style={[
        styles.card,
        styles.activeCard,
        {
          borderColor: selected ? accent : t.cardBorder ?? `${accent}35`,
          backgroundColor: selected ? `${accent}18` : t.cardBg,
        },
      ]}
    >
      <View style={styles.activeTop}>
        <View style={styles.ringWrap}>
          <ValeterTrackingProgressRing
            progress={getStatusProgress(status as any)}
            accent={statusRingColor(status)}
            size={52}
            pulse
          />
        </View>
        <View style={styles.activeCopy}>
          <View style={styles.badgeRow}>
            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          </View>
          <Text style={[styles.activeTitle, { color: t.textMain }]}>{getServiceDisplayName(serviceType, serviceName)}</Text>
          <Text style={[styles.activeCustomer, { color: t.textMuted }]} numberOfLines={1}>
            {customerName}
          </Text>
          {address ? (
            <View style={styles.addressRow}>
              <Ionicons name="location-outline" size={13} color={t.textSoft} />
              <Text style={[styles.addressText, { color: t.textSoft }]} numberOfLines={1}>
                {address}
              </Text>
            </View>
          ) : null}
        </View>
        {onShowOnMap ? (
          <TouchableOpacity
            onPress={(e) => {
              e.stopPropagation?.();
              onShowOnMap();
            }}
            style={[styles.mapPinBtn, { borderColor: `${accent}40`, backgroundColor: t.chipBg }]}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Ionicons name="map" size={18} color={accent} />
          </TouchableOpacity>
        ) : null}
      </View>
      <View style={[styles.activeFooter, { borderTopColor: t.footerBorder }]}>
        <View style={styles.priceRow}>
          <LocationStyleIconBox variant="micro" icon="wallet-outline" preset="green" />
          <Text style={[styles.price, { color: t.moneyColor }]}>£{price.toFixed(2)}</Text>
        </View>
        {hideTrackCta ? null : (
          <View style={styles.trackCta}>
            <Text style={[styles.trackCtaText, { color: accent }]}>Track job</Text>
            <Ionicons name={CONTINUE_CTA_ICON_NAME} size={16} color={accent} />
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

export type UpcomingJobCardProps = Readonly<{
  accent: string;
  serviceType?: string;
  serviceName?: string | null;
  whenLabel: string;
  price: number;
  address?: string | null;
  selected?: boolean;
  totalJobs?: number;
  jobIndex?: number;
  onPress: () => void;
}>;

export function ValeterUpcomingJobCard({
  accent,
  serviceType,
  serviceName,
  whenLabel,
  price,
  address,
  selected = false,
  totalJobs = 1,
  jobIndex = 0,
  onPress,
}: UpcomingJobCardProps) {
  const t = useSheetCardTheme();
  return (
    <TouchableOpacity
      activeOpacity={0.92}
      onPress={onPress}
      style={[
        styles.card,
        styles.scheduledCard,
        {
          borderColor: selected ? accent : t.cardBorder ?? `${accent}45`,
          backgroundColor: selected ? `${accent}18` : t.cardBgStrong,
        },
      ]}
    >
      <View style={styles.scheduledBody}>
        <View style={styles.scheduledHeader}>
          <View style={[styles.scheduledBadge, { backgroundColor: `${accent}22`, borderColor: `${accent}45` }]}>
            <Ionicons name="calendar" size={12} color={accent} />
            <Text style={[styles.scheduledBadgeText, { color: accent }]}>
              {totalJobs > 1 ? `Scheduled ${jobIndex + 1} of ${totalJobs}` : 'Scheduled'}
            </Text>
          </View>
          <View style={[styles.scheduledWhenChip, { backgroundColor: t.chipBg, borderColor: `${accent}30` }]}>
            <Ionicons name="time-outline" size={13} color={accent} />
            <Text style={[styles.scheduledWhenText, { color: t.textMain }]} numberOfLines={1}>
              {whenLabel}
            </Text>
          </View>
        </View>
        <Text style={[styles.scheduledTitle, { color: t.textMain }]} numberOfLines={1}>
          {getServiceDisplayName(serviceType, serviceName)}
        </Text>
        {address ? (
          <Text style={[styles.scheduledAddress, { color: t.textSoft }]} numberOfLines={2}>
            {address}
          </Text>
        ) : null}
        <View style={styles.scheduledMeta}>
          <View style={styles.scheduledPriceBlock}>
            <Text style={[styles.price, { color: t.moneyColor }]}>£{price.toFixed(2)}</Text>
          </View>
          <View style={styles.mapHintRow}>
            <Ionicons name="navigate-outline" size={12} color={accent} />
            <Text style={[styles.mapHint, { color: t.textSoft }]} numberOfLines={1}>
              {totalJobs > 1 ? 'Tap for map · Swipe for more' : 'Tap to show on map'}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export type JobRequestCardProps = Readonly<{
  accent: string;
  job: ValeterJobRequest;
  totalRequests: number;
  requestIndex?: number;
  selected?: boolean;
  /** Hide in-card Accept/Decline (render them under the card instead). */
  hideActions?: boolean;
  onFocusMap?: () => void;
  onAccept: (id: string) => void;
  onDecline: (id: string) => void;
}>;

export function ValeterJobRequestCard({
  accent,
  job,
  totalRequests,
  requestIndex = 0,
  selected = false,
  hideActions = false,
  onFocusMap,
  onAccept,
  onDecline,
}: JobRequestCardProps) {
  const t = useSheetCardTheme();
  return (
    <View
      style={[
        styles.card,
        styles.requestCard,
        {
          borderColor: selected ? '#FBBF24' : t.cardBorder ?? `${accent}45`,
          backgroundColor: selected ? (t.isLight ? 'rgba(245,158,11,0.18)' : 'rgba(245,158,11,0.08)') : t.cardBgStrong,
        },
      ]}
    >
      <TouchableOpacity activeOpacity={0.92} onPress={onFocusMap} style={styles.requestBody}>
        <View style={styles.requestHeader}>
          <View style={styles.requestBadge}>
            <View style={styles.requestDot} />
            <Text style={styles.requestBadgeText}>
              {totalRequests > 1 ? `Request ${requestIndex + 1} of ${totalRequests}` : 'New request'}
            </Text>
          </View>
          <View style={styles.timer}>
            <Ionicons name="time" size={13} color="#FBBF24" />
            <Text style={styles.timerText}>{formatTime(job.timeRemaining)}</Text>
          </View>
        </View>
        <Text style={[styles.requestTitle, { color: t.textMain }]}>{job.serviceName}</Text>
        <Text style={[styles.requestCustomer, { color: t.textMuted }]}>{job.customerName}</Text>
        <Text style={[styles.requestAddress, { color: t.textSoft }]} numberOfLines={2}>
          {job.address}
        </Text>
        <View style={styles.requestMeta}>
          <View style={styles.requestPriceBlock}>
            <Text style={[styles.price, { color: t.moneyColor }]}>£{job.price}</Text>
            {job.distance > 0 ? (
              <Text style={[styles.requestDistance, { color: t.textMuted }]}>
                {job.distance} mi
                {job.driveTimeMinutes != null ? ` · ~${job.driveTimeMinutes} min` : ''}
              </Text>
            ) : null}
          </View>
          <View style={styles.mapHintRow}>
            <Ionicons name="navigate-outline" size={12} color={accent} />
            <Text style={[styles.mapHint, { color: t.textSoft }]} numberOfLines={1}>
              {totalRequests > 1 ? 'Tap for map · Swipe for more' : 'Tap to show on map'}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
      {hideActions ? null : (
        <View style={styles.requestActions}>
          <TouchableOpacity
            style={[styles.acceptBtn, { backgroundColor: accent }]}
            onPress={() => onAccept(job.id)}
            activeOpacity={0.88}
          >
            <Text style={[styles.acceptText, t.isLight && { color: '#FFFFFF' }]}>Accept</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.declineBtn, { backgroundColor: t.declineBg, borderColor: t.declineBorder }]}
            onPress={() => onDecline(job.id)}
            activeOpacity={0.85}
          >
            <Text style={[styles.declineText, { color: t.textMuted }]}>Decline</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 18,
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  loadingWrap: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 120,
  },
  activeCard: {
    padding: 14,
    gap: 12,
  },
  activeTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  ringWrap: {
    width: 52,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCopy: {
    flex: 1,
    minWidth: 0,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: 'rgba(16,185,129,0.22)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  liveText: {
    color: '#6EE7B7',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.6,
  },
  activeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  activeCustomer: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
  },
  addressText: {
    flex: 1,
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    fontWeight: '500',
  },
  mapPinBtn: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1,
  },
  activeFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  price: {
    fontSize: 20,
    fontWeight: '800',
  },
  trackCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  trackCtaText: {
    fontSize: 14,
    fontWeight: '700',
  },
  scheduledCard: {},
  scheduledBody: {
    padding: 14,
    paddingBottom: 12,
  },
  scheduledHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
    gap: 8,
  },
  scheduledBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 20,
    borderWidth: 1,
    flexShrink: 0,
  },
  scheduledBadgeText: {
    fontSize: 11,
    fontWeight: '800',
  },
  scheduledWhenChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 10,
    borderWidth: 1,
    flexShrink: 1,
    minWidth: 0,
  },
  scheduledWhenText: {
    fontSize: 12,
    fontWeight: '700',
    flexShrink: 1,
  },
  scheduledTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
  },
  scheduledAddress: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    marginTop: 4,
    lineHeight: 17,
  },
  scheduledMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    marginTop: 10,
  },
  scheduledPriceBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  requestCard: {},
  requestBody: {
    padding: 14,
    paddingBottom: 10,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  requestBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.35)',
  },
  requestDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#F87171',
  },
  requestBadgeText: {
    color: '#FCA5A5',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  timer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(245,158,11,0.15)',
  },
  timerText: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '800',
  },
  requestTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
  },
  requestCustomer: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  requestAddress: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    marginTop: 4,
  },
  requestMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    marginTop: 10,
  },
  requestPriceBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  requestDistance: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '600',
  },
  mapHintRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flexShrink: 1,
    minWidth: 0,
  },
  mapHint: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 11,
    fontWeight: '600',
    flexShrink: 1,
  },
  requestActions: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 14,
    paddingBottom: 14,
    paddingTop: 2,
  },
  acceptBtn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 13,
    borderRadius: 14,
  },
  acceptText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  declineBtn: {
    paddingVertical: 13,
    paddingHorizontal: 18,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    justifyContent: 'center',
  },
  declineText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '700',
  },
});
