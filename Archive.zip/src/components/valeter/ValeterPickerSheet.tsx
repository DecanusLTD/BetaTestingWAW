import React from 'react';
import { View, Text, StyleSheet, Modal, Pressable, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { themeSheetGradient } from '../shared/BusinessSheetBackground';

type Props = Readonly<{
  visible: boolean;
  title: string;
  onClose: () => void;
  onDone: () => void;
  children: React.ReactNode;
  cardBackground?: string;
  accent?: string;
  cancelLabel?: string;
  doneLabel?: string;
  /** Use inside an existing Modal — nested RN Modals often fail to render. */
  presentation?: 'modal' | 'overlay';
}>;

/** Bottom sheet shell — matches working-hours time picker (Cancel · title · Done). */
export default function ValeterPickerSheet({
  visible,
  title,
  onClose,
  onDone,
  children,
  cardBackground,
  accent,
  cancelLabel = 'Cancel',
  doneLabel = 'Done',
  presentation = 'modal',
}: Props) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const sheetBg = cardBackground ?? themeSheetGradient(theme)[1];
  const accentColor = accent ?? theme.primary ?? '#38BDF8';
  const titleColor = theme.textPrimary ?? '#F9FAFB';
  const mutedColor = theme.textSecondary ?? 'rgba(148,163,184,0.95)';

  if (!visible) return null;

  const card = (
    <View
      style={[
        styles.card,
        {
          backgroundColor: sheetBg,
          borderColor: theme.glassBorder ?? 'rgba(255,255,255,0.12)',
          paddingBottom: Math.max(insets.bottom, Platform.OS === 'ios' ? 24 : 16),
        },
      ]}
    >
      <View style={[styles.accentLine, { backgroundColor: `${accentColor}55` }]} />
      <View style={styles.header}>
        <Pressable onPress={onClose} style={styles.headerBtn} hitSlop={8}>
          <Text style={[styles.headerBtnMuted, { color: mutedColor }]}>{cancelLabel}</Text>
        </Pressable>
        <Text style={[styles.title, { color: titleColor }]} numberOfLines={1}>
          {title}
        </Text>
        <Pressable onPress={onDone} style={styles.headerBtn} hitSlop={8}>
          <Text style={[styles.headerBtnAccent, { color: accentColor }]}>{doneLabel}</Text>
        </Pressable>
      </View>
      {children}
    </View>
  );

  if (presentation === 'overlay') {
    return (
      <View style={styles.overlayRoot} pointerEvents="box-none">
        <Pressable style={styles.overlayScrim} onPress={onClose} accessibilityLabel="Close picker" />
        {card}
      </View>
    );
  }

  return (
    <Modal transparent animationType="fade" visible={visible} onRequestClose={onClose}>
      <View style={styles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Close picker" />
        {card}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlayRoot: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 200,
    elevation: 200,
    justifyContent: 'flex-end',
  },
  overlayScrim: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  card: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderTopWidth: 1,
    overflow: 'hidden',
  },
  accentLine: {
    height: 2,
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 8,
  },
  headerBtn: {
    paddingVertical: 8,
    minWidth: 58,
  },
  headerBtnMuted: {
    fontSize: 14,
    fontWeight: '700',
  },
  headerBtnAccent: {
    fontSize: 14,
    fontWeight: '800',
    textAlign: 'right',
  },
  title: {
    flex: 1,
    textAlign: 'center',
    fontSize: 15,
    fontWeight: '800',
  },
});
