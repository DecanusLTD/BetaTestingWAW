import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Animated,
  PanResponder,
} from 'react-native';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import {
  ValeterJobRequestCard,
  ValeterUpcomingJobCard,
} from './ValeterSheetJobCards';
import type { ValeterJobRequest } from './ValeterJobRequestOverlay';
import ValeterDashboardChrome from './ValeterDashboardChrome';
import DefaultLoadingSkeleton from '../shared/DefaultLoadingSkeleton';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { CONTINUE_CTA_ICON_NAME } from '../../utils/bookingContinueStyle';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get('window');
/** Tall enough for request cards + Accept/Decline under them. */
const SHEET_HEIGHT_RATIO = 0.4;
const SHEET_PAD_H = 16;
const REQUEST_CARD_GAP = 10;
const REQUEST_CARD_WIDTH = Math.min(SCREEN_WIDTH - SHEET_PAD_H * 2 - 28, 340);

export const VALETER_SHEET_FIXED_HEIGHT = Math.round(SCREEN_HEIGHT * SHEET_HEIGHT_RATIO);
/** Fallback tracking height before content measures; sheet hugs measured content. */
export const VALETER_TRACKING_SHEET_HEIGHT = Math.round(SCREEN_HEIGHT * 0.32);
/** Handle + swipe-hint chrome above embedded tracking content. */
export const VALETER_TRACKING_SHEET_CHROME = 36;
/** Minimal sheet tabs — drag down hides this row, drag up reveals it. */
export const VALETER_SHEET_TAB_BAR_HEIGHT = 46;

export type DashboardSheetPanel = 'upcoming' | 'tracking' | 'request';

export type UpcomingJobRow = {
  id: string;
  service_type?: string;
  service_name?: string | null;
  scheduled_at?: string | null;
  price?: number;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  status?: string;
};

export type ActiveJobRow = Readonly<{
  id: string;
  status: string;
  service_type?: string | null;
  service_name?: string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  price: number;
}>;

type SheetTab = {
  id: DashboardSheetPanel;
  label: string;
  icon: IconGlyphName;
};

const SHEET_TABS: SheetTab[] = [
  { id: 'upcoming', label: 'Scheduled', icon: 'calendar-outline' },
  { id: 'tracking', label: 'Tracking', icon: 'navigate-outline' },
  { id: 'request', label: 'Live', icon: 'flash-outline' },
];

function formatUpcomingWhen(iso?: string | null): string {
  if (!iso) return 'Scheduled';
  const d = new Date(iso);
  const now = new Date();
  const isToday =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();
  const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (isToday) return `Today · ${time}`;
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const isTomorrow =
    d.getDate() === tomorrow.getDate() &&
    d.getMonth() === tomorrow.getMonth() &&
    d.getFullYear() === tomorrow.getFullYear();
  if (isTomorrow) return `Tomorrow · ${time}`;
  return d.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

type ValeterDashboardBottomSheetProps = Readonly<{
  accent: string;
  headerGradient?: readonly [string, string];
  panel?: DashboardSheetPanel;
  focusedJobId?: string | null;
  activeJob?: ActiveJobRow | null;
  activeJobLoading?: boolean;
  activeCustomerName?: string;
  jobRequests?: ValeterJobRequest[];
  jobRequestCount?: number;
  upcomingJobs: UpcomingJobRow[];
  /** Live tracking UI for the Tracking tab (embedded). */
  trackingContent?: React.ReactNode;
  /** Measured height of embedded tracking content (card + actions). */
  trackingContentHeight?: number | null;
  onPanelChange: (panel: DashboardSheetPanel) => void;
  onFocusJobOnMap: (jobId: string, lat: number, lng: number) => void;
  onActiveJobPress: () => void;
  onUpcomingJobPress: (job: UpcomingJobRow) => void;
  onAcceptJob: (jobId: string) => void;
  onDeclineJob: (jobId: string) => void;
  refreshing?: boolean;
  onRefresh?: () => void;
  /** Fired when tab bar snap changes — collapsed hides tabs (px offset from fully open). */
  onSheetCollapseOffsetChange?: (offset: number) => void;
  /** Swipe-down on tracking panel exits live tracking. */
  onTrackingDismiss?: () => void;
}>;

export default function ValeterDashboardBottomSheet({
  accent,
  headerGradient = HEADER_STYLE_CARD_GRADIENT,
  panel = 'upcoming',
  focusedJobId,
  activeJob,
  activeJobLoading = false,
  activeCustomerName = 'Customer',
  jobRequests = [],
  jobRequestCount = 0,
  upcomingJobs,
  trackingContent = null,
  trackingContentHeight = null,
  onPanelChange,
  onFocusJobOnMap,
  onActiveJobPress,
  onUpcomingJobPress,
  onAcceptJob,
  onDeclineJob,
  refreshing = false,
  onRefresh,
  onSheetCollapseOffsetChange,
  onTrackingDismiss,
}: ValeterDashboardBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const sheetMuted = theme.textSecondary ?? 'rgba(241,245,249,0.65)';
  const trackingBottomPad = Math.max(insets.bottom, 8);
  const trackingSheetHeight = useMemo(() => {
    const content =
      trackingContentHeight != null && trackingContentHeight > 0
        ? trackingContentHeight
        : VALETER_TRACKING_SHEET_HEIGHT - VALETER_TRACKING_SHEET_CHROME - trackingBottomPad;
    return Math.min(
      Math.round(SCREEN_HEIGHT * 0.48),
      Math.max(180, Math.round(content + VALETER_TRACKING_SHEET_CHROME + trackingBottomPad))
    );
  }, [trackingBottomPad, trackingContentHeight]);
  const sheetHeight = panel === 'tracking' ? trackingSheetHeight : VALETER_SHEET_FIXED_HEIGHT;
  const hasActive = !!activeJob;
  const requestBadge = Math.max(jobRequestCount, jobRequests.length);
  const requestScrollRef = useRef<ScrollView>(null);
  const scheduledScrollRef = useRef<ScrollView>(null);
  const collapseOffset = useRef(new Animated.Value(0)).current;
  const collapseOffsetValue = useRef(0);
  const [tabsCollapsed, setTabsCollapsed] = useState(false);

  const snapCollapse = useCallback(
    (collapsed: boolean) => {
      const toValue = collapsed ? VALETER_SHEET_TAB_BAR_HEIGHT : 0;
      collapseOffsetValue.current = toValue;
      setTabsCollapsed(collapsed);
      onSheetCollapseOffsetChange?.(toValue);
      Animated.spring(collapseOffset, {
        toValue,
        useNativeDriver: true,
        damping: 28,
        stiffness: 320,
        mass: 0.85,
      }).start();
    },
    [collapseOffset, onSheetCollapseOffsetChange]
  );

  useEffect(() => {
    onSheetCollapseOffsetChange?.(collapseOffsetValue.current);
  }, [onSheetCollapseOffsetChange]);

  /** Tracking mode: hide tabs entirely; size sheet to content and pin to footer. */
  useEffect(() => {
    if (panel === 'tracking') {
      if (tabsCollapsed) snapCollapse(false);
      onSheetCollapseOffsetChange?.(VALETER_SHEET_FIXED_HEIGHT - sheetHeight);
      return;
    }
    onSheetCollapseOffsetChange?.(collapseOffsetValue.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panel, sheetHeight]);

  const dismissDrag = useRef(new Animated.Value(0)).current;

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 4 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => {
          if (panel === 'tracking' && onTrackingDismiss) {
            dismissDrag.setValue(Math.max(0, g.dy));
            return;
          }
          const base = tabsCollapsed ? VALETER_SHEET_TAB_BAR_HEIGHT : 0;
          const next = Math.max(0, Math.min(VALETER_SHEET_TAB_BAR_HEIGHT, base + g.dy));
          collapseOffset.setValue(next);
        },
        onPanResponderRelease: (_, g) => {
          if (panel === 'tracking' && onTrackingDismiss) {
            const shouldDismiss = g.dy > 72 || (g.dy > 28 && g.vy > 0.35);
            if (shouldDismiss) {
              Animated.timing(dismissDrag, {
                toValue: sheetHeight,
                duration: 220,
                useNativeDriver: true,
              }).start(() => {
                dismissDrag.setValue(0);
                void hapticFeedback('light');
                onTrackingDismiss();
              });
              return;
            }
            Animated.spring(dismissDrag, {
              toValue: 0,
              useNativeDriver: true,
              damping: 26,
              stiffness: 320,
            }).start();
            return;
          }
          const base = tabsCollapsed ? VALETER_SHEET_TAB_BAR_HEIGHT : 0;
          const next = Math.max(0, Math.min(VALETER_SHEET_TAB_BAR_HEIGHT, base + g.dy));
          if (g.vy < -0.35 || next < VALETER_SHEET_TAB_BAR_HEIGHT * 0.4) {
            snapCollapse(false);
            return;
          }
          if (g.vy > 0.35 || next > VALETER_SHEET_TAB_BAR_HEIGHT * 0.55) {
            snapCollapse(true);
            return;
          }
          snapCollapse(tabsCollapsed);
        },
      }),
    [
      collapseOffset,
      dismissDrag,
      onTrackingDismiss,
      panel,
      sheetHeight,
      snapCollapse,
      tabsCollapsed,
    ]
  );

  useEffect(() => {
    if (panel !== 'request' || !focusedJobId || jobRequests.length === 0) return;
    const index = jobRequests.findIndex((j) => j.id === focusedJobId);
    if (index < 0) return;
    requestScrollRef.current?.scrollTo({
      x: index * (REQUEST_CARD_WIDTH + REQUEST_CARD_GAP),
      animated: true,
    });
  }, [focusedJobId, jobRequests, panel]);

  useEffect(() => {
    if (panel !== 'upcoming' || !focusedJobId || upcomingJobs.length === 0) return;
    const index = upcomingJobs.findIndex((j) => j.id === focusedJobId);
    if (index < 0) return;
    scheduledScrollRef.current?.scrollTo({
      x: index * (REQUEST_CARD_WIDTH + REQUEST_CARD_GAP),
      animated: true,
    });
  }, [focusedJobId, upcomingJobs, panel]);

  const selectPanel = async (next: DashboardSheetPanel) => {
    await hapticFeedback('light');
    if (tabsCollapsed) snapCollapse(false);
    onPanelChange(next);
  };

  const focusRequest = (job: ValeterJobRequest) => {
    if (job.location_lat != null && job.location_lng != null) {
      onFocusJobOnMap(job.id, job.location_lat, job.location_lng);
    }
  };

  const handleRequestScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (jobRequests.length === 0) return;
    const stride = REQUEST_CARD_WIDTH + REQUEST_CARD_GAP;
    const index = Math.min(
      jobRequests.length - 1,
      Math.max(0, Math.round(event.nativeEvent.contentOffset.x / stride))
    );
    const job = jobRequests[index];
    if (job) focusRequest(job);
  };

  const handleScheduledScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    if (upcomingJobs.length === 0) return;
    const stride = REQUEST_CARD_WIDTH + REQUEST_CARD_GAP;
    const index = Math.min(
      upcomingJobs.length - 1,
      Math.max(0, Math.round(event.nativeEvent.contentOffset.x / stride))
    );
    const job = upcomingJobs[index];
    if (!job) return;
    if (job.location_lat != null && job.location_lng != null) {
      onFocusJobOnMap(job.id, job.location_lat, job.location_lng);
    }
  };

  const tabHideTranslate = collapseOffset.interpolate({
    inputRange: [0, VALETER_SHEET_TAB_BAR_HEIGHT],
    outputRange: [0, -VALETER_SHEET_TAB_BAR_HEIGHT],
  });

  return (
    <Animated.View
      style={[
        styles.sheet,
        {
          height: sheetHeight,
          paddingBottom: panel === 'tracking' ? trackingBottomPad : 8,
          borderColor: `${accent}35`,
          // Keep tracking sheet flush to the screen footer (no collapse lift).
          justifyContent: panel === 'tracking' ? 'flex-end' : undefined,
          transform: [
            {
              translateY:
                panel === 'tracking'
                  ? dismissDrag
                  : collapseOffset,
            },
          ],
        },
      ]}
    >
      <ValeterDashboardChrome accent={accent} headerGradient={headerGradient} />

      <View style={styles.handleTouch} {...panResponder.panHandlers}>
        <View style={[styles.handle, { backgroundColor: `${accent}55` }]} />
        {panel === 'tracking' ? (
          <Text style={[styles.swipeHint, { color: sheetMuted }]}>Swipe down to exit</Text>
        ) : null}
      </View>

      {panel === 'tracking' ? null : (
        <View style={styles.tabBarClip}>
          <Animated.View
            style={[
              styles.tabBar,
              { borderBottomColor: `${accent}18`, transform: [{ translateY: tabHideTranslate }] },
            ]}
          >
            {SHEET_TABS.map((tab) => {
              const active = panel === tab.id;
              const color = active ? accent : 'rgba(241,245,249,0.45)';
              const showBadge = tab.id === 'request' && requestBadge > 0;
              return (
                <TouchableOpacity
                  key={tab.id}
                  style={styles.tabItem}
                  onPress={() => selectPanel(tab.id)}
                  activeOpacity={0.75}
                  accessibilityRole="tab"
                  accessibilityState={{ selected: active }}
                  accessibilityLabel={tab.label}
                >
                  <View style={[styles.tabIconWrap, active && { backgroundColor: `${accent}22` }]}>
                    <Ionicons name={tab.icon} size={18} color={color} />
                    {showBadge ? (
                      <View style={[styles.tabBadge, { backgroundColor: accent }]}>
                        <Text style={styles.tabBadgeText}>{requestBadge > 9 ? '9+' : requestBadge}</Text>
                      </View>
                    ) : null}
                  </View>
                  <Text style={[styles.tabLabel, { color }, active && styles.tabLabelActive]} numberOfLines={1}>
                    {tab.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </Animated.View>
        </View>
      )}

      <View style={styles.body}>
        {panel === 'request' ? (
          <View style={styles.panelFill}>
            {jobRequests.length > 0 ? (
              <ScrollView
                ref={requestScrollRef}
                horizontal
                nestedScrollEnabled
                style={styles.requestCarousel}
                showsHorizontalScrollIndicator={false}
                decelerationRate="fast"
                snapToInterval={REQUEST_CARD_WIDTH + REQUEST_CARD_GAP}
                snapToAlignment="start"
                disableIntervalMomentum
                contentContainerStyle={styles.requestCarouselContent}
                onMomentumScrollEnd={handleRequestScrollEnd}
                onScrollEndDrag={handleRequestScrollEnd}
              >
                {jobRequests.map((job, index) => {
                  const selected = focusedJobId === job.id;
                  return (
                    <View key={job.id} style={[styles.requestCardWrap, { width: REQUEST_CARD_WIDTH }]}>
                      <ValeterJobRequestCard
                        accent={accent}
                        job={job}
                        totalRequests={jobRequests.length}
                        requestIndex={index}
                        selected={selected}
                        hideActions
                        onFocusMap={() => focusRequest(job)}
                        onAccept={onAcceptJob}
                        onDecline={onDeclineJob}
                      />
                      <View style={styles.requestActionsBelow}>
                        <TouchableOpacity
                          style={[styles.acceptBtnBelow, { backgroundColor: accent }]}
                          onPress={() => onAcceptJob(job.id)}
                          activeOpacity={0.88}
                        >
                          <Text style={styles.acceptBtnBelowText}>Accept</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[styles.declineBtnBelow, { borderColor: `${accent}35` }]}
                          onPress={() => onDeclineJob(job.id)}
                          activeOpacity={0.85}
                        >
                          <Text style={[styles.declineBtnBelowText, { color: sheetMuted }]}>Decline</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </ScrollView>
            ) : (
              <View style={styles.emptyState}>
                <Ionicons name="flash-outline" size={28} color={sheetMuted} />
                <Text style={[styles.emptyText, { color: sheetMuted }]}>
                  No live offers right now — new job requests will show here
                </Text>
              </View>
            )}
          </View>
        ) : panel === 'tracking' ? (
          <View style={[styles.panelFill, styles.panelFillTracking]} {...panResponder.panHandlers}>
            {trackingContent ? (
              <View style={styles.trackingSlot}>{trackingContent}</View>
            ) : hasActive || activeJobLoading ? (
              <View style={styles.paddedBlock}>
                <DefaultLoadingSkeleton message="Opening tracking…" />
              </View>
            ) : (
              <View style={styles.emptyState}>
                <Ionicons name="navigate-outline" size={28} color={sheetMuted} />
                <Text style={[styles.emptyText, { color: sheetMuted }]}>
                  No active trip yet — tracking appears here once a live job is under way
                </Text>
              </View>
            )}
          </View>
        ) : (
          <View style={styles.panelFill}>
            {upcomingJobs.length > 0 ? (
              <ScrollView
                ref={scheduledScrollRef}
                horizontal
                nestedScrollEnabled
                style={styles.requestCarousel}
                showsHorizontalScrollIndicator={false}
                decelerationRate="fast"
                snapToInterval={REQUEST_CARD_WIDTH + REQUEST_CARD_GAP}
                snapToAlignment="start"
                disableIntervalMomentum
                contentContainerStyle={[styles.requestCarouselContent, styles.scheduledCarouselContent]}
                onMomentumScrollEnd={handleScheduledScrollEnd}
                onScrollEndDrag={handleScheduledScrollEnd}
              >
                {upcomingJobs.map((job, index) => (
                  <View key={job.id} style={[styles.requestCardWrap, { width: REQUEST_CARD_WIDTH }]}>
                    <ValeterUpcomingJobCard
                      accent={accent}
                      serviceType={job.service_type}
                      serviceName={job.service_name}
                      whenLabel={formatUpcomingWhen(job.scheduled_at)}
                      price={Number(job.price || 0)}
                      address={job.location_address}
                      selected={focusedJobId === job.id}
                      totalJobs={upcomingJobs.length}
                      jobIndex={index}
                      onPress={() => {
                        if (job.location_lat != null && job.location_lng != null) {
                          onFocusJobOnMap(job.id, job.location_lat, job.location_lng);
                        }
                      }}
                    />
                    <TouchableOpacity
                      onPress={() => onUpcomingJobPress(job)}
                      style={[styles.scheduledDetailsBtn, { backgroundColor: accent, borderColor: `${accent}80` }]}
                      activeOpacity={0.88}
                      accessibilityRole="button"
                      accessibilityLabel="View details"
                    >
                      <Text style={styles.scheduledDetailsBtnText}>View details</Text>
                      <Ionicons name={CONTINUE_CTA_ICON_NAME} size={18} color="#0A1929" />
                    </TouchableOpacity>
                  </View>
                ))}
              </ScrollView>
            ) : (
              <View style={styles.emptyState}>
                <Ionicons name="calendar-outline" size={28} color={sheetMuted} />
                <Text style={[styles.emptyText, { color: sheetMuted }]}>
                  No scheduled jobs yet — upcoming bookings will show here
                </Text>
              </View>
            )}
          </View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    overflow: 'hidden',
    zIndex: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 28,
  },
  handleTouch: {
    alignItems: 'center',
    paddingTop: 6,
    paddingBottom: 2,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
  },
  swipeHint: {
    marginTop: 4,
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  tabBarClip: {
    height: VALETER_SHEET_TAB_BAR_HEIGHT,
    overflow: 'hidden',
    marginBottom: 4,
  },
  body: {
    flex: 1,
    minHeight: 0,
    paddingBottom: 0,
  },
  panelFill: {
    flex: 1,
    minHeight: 0,
    justifyContent: 'flex-start',
  },
  panelFillTracking: {
    justifyContent: 'flex-end',
    paddingBottom: 0,
  },
  trackingSlot: {
    flexGrow: 0,
    flexShrink: 0,
    width: '100%',
    paddingTop: 0,
    paddingBottom: 0,
  },
  sheetScroll: {
    flex: 1,
  },
  sheetScrollContent: {
    paddingTop: 2,
    paddingBottom: 4,
    gap: 10,
  },
  requestCarousel: {
    flexGrow: 0,
    flexShrink: 1,
  },
  requestCarouselContent: {
    paddingHorizontal: SHEET_PAD_H,
    gap: REQUEST_CARD_GAP,
    paddingRight: SHEET_PAD_H + 20,
    alignItems: 'flex-start',
    paddingBottom: 0,
  },
  scheduledCarouselContent: {
    paddingTop: 14,
  },
  requestCardWrap: {
    flexGrow: 0,
    flexShrink: 0,
    gap: 10,
  },
  requestActionsBelow: {
    flexDirection: 'row',
    gap: 10,
  },
  acceptBtnBelow: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    borderRadius: 14,
  },
  acceptBtnBelowText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  declineBtnBelow: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    paddingHorizontal: 18,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  declineBtnBelowText: {
    fontSize: 14,
    fontWeight: '700',
  },
  paddedBlock: {
    paddingHorizontal: SHEET_PAD_H,
    gap: 10,
  },
  trackJobBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    minHeight: 48,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 16,
  },
  trackJobBtnText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  scheduledDetailsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    minHeight: 48,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 16,
  },
  scheduledDetailsBtnText: {
    color: '#0A1929',
    fontSize: 15,
    fontWeight: '800',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 28,
    paddingHorizontal: SHEET_PAD_H + 8,
    minHeight: 140,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 20,
  },
  tabBar: {
    height: VALETER_SHEET_TAB_BAR_HEIGHT,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 8,
    backgroundColor: 'transparent',
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    paddingVertical: 4,
  },
  tabIconWrap: {
    width: 34,
    height: 28,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
  },
  tabLabelActive: {
    fontWeight: '800',
  },
  tabBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 14,
    height: 14,
    borderRadius: 7,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  tabBadgeText: {
    color: '#0A1929',
    fontSize: 8,
    fontWeight: '800',
  },
});
