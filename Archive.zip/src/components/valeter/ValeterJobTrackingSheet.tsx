import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Animated,
  PanResponder,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import ValeterTrackingProgressRing from './ValeterTrackingProgressRing';
import InfoBottomSheet from '../shared/InfoBottomSheet';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import ValeterDashboardChrome from './ValeterDashboardChrome';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { openExternalDirections } from '../../utils/externalMaps';
import { colors } from '../../constants/colors';
import {
  HEADER_STYLE_CARD_GRADIENT,
  BOOKING_SHEET_DARK_OVERLAY,
} from '../../constants/bookingCardTheme';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  type ValeterTrackingJob,
  type ValeterTrackingStatus,
  type BookingVehicleItem,
} from '../../hooks/useValeterJobTracking';
import type { StageItem } from '../../utils/trackingStatusHelpers';
import { lightMistPanel, lightMistElevated } from '../../constants/accountThemes';
import BookingVehiclesInfoSheet from '../shared/BookingVehiclesInfoSheet';

const SKY = colors.SKY ?? '#38BDF8';
/** Content-only estimate for map padding when sheet height is not measured yet */
export const VALETER_TRACKING_SHEET_CONTENT_ESTIMATE = 270;
const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;
const MAX_PEEK_DRAG = 48;

export function valeterTrackingSheetTotalHeight(safeBottom: number, contentHeight = VALETER_TRACKING_SHEET_CONTENT_ESTIMATE) {
  return contentHeight + Math.max(safeBottom, 8);
}

type VehicleDetails = {
  registration?: string;
  make?: string;
  model?: string;
  photo?: string;
  colour?: string;
  summaryLine?: string;
} | null;

export type ValeterJobTrackingSheetProps = Readonly<{
  accent: string;
  sheetGradient?: readonly [string, string];
  job: ValeterTrackingJob;
  status: ValeterTrackingStatus;
  statusMessage: string;
  customerName: string;
  vehicleDetails: VehicleDetails;
  bookingVehicles?: BookingVehicleItem[];
  etaMinutes: number | null;
  distanceMi: number | null;
  stages: StageItem[];
  stageProgressPercent: number;
  nextAction: { label: string; action: () => void } | null;
  canCancel: boolean;
  cancelling: boolean;
  onCancel: () => void;
  onChat: () => void;
  onClose: () => void;
  infoSheetVisible: boolean;
  onOpenInfo: () => void;
  onCloseInfo: () => void;
  onMeasuredHeight?: (totalHeight: number) => void;
  /** Render inside the dashboard bottom sheet (no absolute overlay / drag-to-dismiss). */
  embedded?: boolean;
}>;

function TrackingStageDots({
  stages,
  accent,
  mutedColor,
}: Readonly<{ stages: StageItem[]; accent: string; mutedColor: string }>) {
  return (
    <>
      {stages.map((stage) => {
        let stageIconColor = mutedColor;
        if (stage.current) stageIconColor = accent;
        let stageIcon: React.ReactNode;
        if (stage.done) {
          stageIcon = <Ionicons name="checkmark" size={10} color="#FFFFFF" />;
        } else {
          const glyph = stage.icon === 'location' ? 'locate' : stage.icon;
          stageIcon = <Ionicons name={glyph} size={10} color={stageIconColor} />;
        }
        return (
          <View key={stage.label} style={styles.smallStageItem}>
            <View
              style={[
                styles.smallStageDot,
                stage.done && styles.smallStageDotDone,
                stage.current && [styles.smallStageDotCurrent, { borderColor: accent }],
              ]}
            >
              {stageIcon}
            </View>
            <Text
              style={[
                styles.smallStageLabel,
                { color: mutedColor },
                stage.done && styles.smallStageLabelDone,
                stage.current && { color: accent, fontWeight: '700' },
              ]}
              numberOfLines={1}
            >
              {stage.label}
            </Text>
          </View>
        );
      })}
    </>
  );
}

function VehicleInfoTrigger({
  accent,
  count,
  mutedColor,
  textMain,
  onPress,
}: Readonly<{
  accent: string;
  count: number;
  mutedColor: string;
  textMain: string;
  onPress: () => void;
}>) {
  return (
    <TouchableOpacity
      style={[styles.vehicleInfoTrigger, { borderColor: `${accent}40`, backgroundColor: `${accent}12` }]}
      onPress={async () => {
        await hapticFeedback('light');
        onPress();
      }}
      activeOpacity={0.85}
      accessibilityRole="button"
      accessibilityLabel="Vehicle info"
    >
      <View style={[styles.vehicleInfoIconWrap, { backgroundColor: `${accent}22` }]}>
        <Ionicons name="information-circle" size={18} color={accent} />
      </View>
      <View style={styles.vehicleInfoCopy}>
        <Text style={[styles.vehicleInfoTitle, { color: textMain }]}>Vehicle info</Text>
        <Text style={[styles.vehicleInfoSub, { color: mutedColor }]}>
          {count > 1 ? `${count} vehicles · tap to view` : 'Tap to view details & photos'}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={accent} />
    </TouchableOpacity>
  );
}

function TrackingVehicleSummary({
  accent,
  mutedColor,
  textMain,
  vehicleCount,
  onOpenVehicles,
}: Readonly<{
  accent: string;
  mutedColor: string;
  textMain: string;
  vehicleCount: number;
  onOpenVehicles: () => void;
}>) {
  if (vehicleCount <= 0) return null;
  return (
    <VehicleInfoTrigger
      accent={accent}
      count={vehicleCount}
      mutedColor={mutedColor}
      textMain={textMain}
      onPress={onOpenVehicles}
    />
  );
}

function TrackingCenterAction({
  nextAction,
  status,
  accent,
  sheetGradient,
  isLight,
}: Readonly<{
  nextAction: { label: string; action: () => void } | null;
  status: ValeterTrackingStatus;
  accent: string;
  sheetGradient: readonly [string, string];
  isLight: boolean;
}>) {
  const chrome = (
    <>
      <BlurView
        intensity={26}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient colors={[sheetGradient[0], sheetGradient[1]]} style={StyleSheet.absoluteFill} pointerEvents="none" />
      {!isLight ? <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" /> : null}
    </>
  );

  if (nextAction) {
    return (
      <TouchableOpacity
        onPress={nextAction.action}
        style={[
          styles.bookingInfoCard,
          styles.bookingInfoCardCompact,
          styles.bookingInfoActionCard,
          { borderColor: `${accent}55`, backgroundColor: isLight ? lightMistElevated : 'rgba(255,255,255,0.04)' },
        ]}
        activeOpacity={0.85}
      >
        {chrome}
        <Ionicons name="arrow-forward" size={20} color={accent} style={{ zIndex: 1 }} />
        <View style={styles.bookingInfoCardTextWrap}>
          <Text style={[styles.bookingInfoCardTextCompact, { color: accent }]} numberOfLines={1}>
            {nextAction.label}
          </Text>
        </View>
      </TouchableOpacity>
    );
  }
  if (status === 'pending_payment') {
    return (
      <View
        style={[
          styles.bookingInfoCard,
          styles.bookingInfoCardCompact,
          styles.bookingInfoActionCardDisabled,
          { borderColor: `${accent}35`, backgroundColor: isLight ? lightMistPanel : 'rgba(255,255,255,0.04)' },
        ]}
      >
        {chrome}
        <Ionicons name="wallet-outline" size={20} color="#F59E0B" style={{ zIndex: 1 }} />
        <View style={styles.bookingInfoCardTextWrap}>
          <Text style={[styles.bookingInfoCardTextCompact, styles.bookingInfoCardTextDisabled]} numberOfLines={1}>
            Awaiting payment
          </Text>
        </View>
      </View>
    );
  }
  return null;
}

function formatScheduledAt(iso?: string | null): string | null {
  if (!iso) return null;
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return null;
  }
}

function JobDetailRow({
  accent,
  icon,
  label,
  value,
  highlight,
  textMain,
  textMuted,
}: Readonly<{
  accent: string;
  icon: React.ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: string;
  highlight?: boolean;
  textMain: string;
  textMuted: string;
}>) {
  return (
    <View style={styles.jobDetailRow}>
      <View style={[styles.jobDetailRowIcon, { backgroundColor: `${accent}18` }]}>
        <Ionicons name={icon} size={17} color={accent} />
      </View>
      <View style={styles.jobDetailRowBody}>
        <Text style={[styles.jobDetailRowLabel, { color: textMuted }]}>{label}</Text>
        <Text
          style={[
            styles.jobDetailRowValue,
            { color: textMain },
            highlight && { color: accent, fontWeight: '800' },
          ]}
          numberOfLines={3}
        >
          {value}
        </Text>
      </View>
    </View>
  );
}

function JobDetailsContent({
  accent,
  customerName,
  job,
  status,
  statusMessage,
  bookingVehicles,
  etaMinutes,
  distanceMi,
  onChat,
  onOpenVehicles,
}: Readonly<{
  accent: string;
  customerName: string;
  job: ValeterTrackingJob;
  status: ValeterTrackingStatus;
  statusMessage: string;
  bookingVehicles: BookingVehicleItem[];
  etaMinutes: number | null;
  distanceMi: number | null;
  onChat: () => void;
  onOpenVehicles: () => void;
}>) {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.7)';
  const moneyColor = theme.accentAlt ?? '#E8C547';
  const vehicleCount = bookingVehicles.length;
  const scheduledLabel = formatScheduledAt(job.scheduled_at);
  const priceLabel = `£${Number(job.price ?? 0).toFixed(2)}`;
  const etaLabel =
    etaMinutes != null && distanceMi != null ? `~${etaMinutes} min · ${distanceMi} mi away` : null;

  const handleDirections = async () => {
    await hapticFeedback('light');
    try {
      await openExternalDirections({
        address: job.location_address,
        latitude: job.location_lat != null ? Number(job.location_lat) : null,
        longitude: job.location_lng != null ? Number(job.location_lng) : null,
        label: customerName,
      });
    } catch {
      /* no destination */
    }
  };

  return (
    <View style={styles.jobInfoProfile}>
      <View style={styles.jobInfoHero}>
        <View style={[styles.jobInfoAvatar, { borderColor: `${accent}70` }]}>
          <Ionicons name="person" size={32} color={accent} />
        </View>
        <Text style={[styles.jobInfoProfileName, { color: textMain }]}>{customerName}</Text>
        <Text style={[styles.jobInfoProfileHeadline, { color: accent }]}>
          {getServiceDisplayName(job.service_type, job.service_name)}
        </Text>
        <View style={[styles.jobInfoStatusPill, { backgroundColor: `${accent}18`, borderColor: `${accent}40` }]}>
          <View style={[styles.jobInfoStatusDot, { backgroundColor: accent }]} />
          <Text style={[styles.jobInfoStatusText, { color: accent }]}>{statusMessage}</Text>
        </View>
      </View>

      {vehicleCount > 0 ? (
        <VehicleInfoTrigger
          accent={accent}
          count={vehicleCount}
          mutedColor={textMuted}
          textMain={textMain}
          onPress={onOpenVehicles}
        />
      ) : null}

      <View style={[styles.jobInfoList, { borderColor: `${accent}22`, backgroundColor: isLight ? lightMistPanel : undefined }]}>
        {etaLabel && (status === 'en_route' || status === 'confirmed' || status === 'scheduled') ? (
          <JobDetailRow accent={accent} icon="navigate-outline" label="ETA" value={etaLabel} highlight textMain={textMain} textMuted={textMuted} />
        ) : null}
        {job.location_address ? (
          <JobDetailRow accent={accent} icon="location-outline" label="Location" value={job.location_address} textMain={textMain} textMuted={textMuted} />
        ) : null}
        <JobDetailRow accent={moneyColor} icon="wallet-outline" label="Price" value={priceLabel} highlight textMain={textMain} textMuted={textMuted} />
        {scheduledLabel ? (
          <JobDetailRow accent={accent} icon="calendar-outline" label="Scheduled" value={scheduledLabel} textMain={textMain} textMuted={textMuted} />
        ) : null}
      </View>

      <View style={styles.jobInfoQuickActions}>
        <TouchableOpacity
          onPress={async () => {
            await hapticFeedback('light');
            onChat();
          }}
          style={[styles.jobInfoQuickBtn, { borderColor: `${accent}45`, backgroundColor: isLight ? lightMistElevated : undefined }]}
          activeOpacity={0.85}
        >
          <Ionicons name="chatbubble-ellipses-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoQuickBtnText, { color: accent }]}>Message</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleDirections}
          style={[styles.jobInfoQuickBtn, styles.jobInfoQuickBtnPrimary, { backgroundColor: `${accent}20`, borderColor: `${accent}50` }]}
          activeOpacity={0.85}
        >
          <Ionicons name="navigate-outline" size={18} color={accent} />
          <Text style={[styles.jobInfoQuickBtnText, { color: accent }]}>Directions</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function ValeterJobTrackingSheet({
  accent,
  sheetGradient = HEADER_STYLE_CARD_GRADIENT,
  job,
  status,
  statusMessage,
  customerName,
  vehicleDetails,
  bookingVehicles = [],
  etaMinutes,
  distanceMi,
  stages,
  stageProgressPercent,
  nextAction,
  canCancel,
  cancelling,
  onCancel,
  onChat,
  onClose,
  infoSheetVisible,
  onOpenInfo,
  onCloseInfo,
  onMeasuredHeight,
  embedded = false,
}: ValeterJobTrackingSheetProps) {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.65)';
  const cardBorder = theme.glassBorder ?? theme.cardBorder ?? `${accent}40`;
  const chipBg = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const iconBtnBg = isLight ? lightMistElevated : 'rgba(15,23,42,0.45)';
  /** Keep a light inset only — parent sheet already sits on the home indicator. */
  const bottomPad = embedded ? 0 : Math.max(insets.bottom, 8);
  const [contentHeight, setContentHeight] = useState(VALETER_TRACKING_SHEET_CONTENT_ESTIMATE);
  const [vehiclesSheetVisible, setVehiclesSheetVisible] = useState(false);
  const sheetHeight = contentHeight + bottomPad;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const dragOffset = useRef(new Animated.Value(0)).current;

  const galleryVehicles = useMemo((): BookingVehicleItem[] => {
    if (bookingVehicles.length > 0) return bookingVehicles;
    const summary =
      vehicleDetails?.summaryLine ||
      (typeof job.vehicle_info === 'string' ? job.vehicle_info.trim() : '') ||
      null;
    if (summary) {
      return summary
        .split('·')
        .map((s) => s.trim())
        .filter(Boolean)
        .map((label, i) => ({ id: `fallback-${i}`, make: label }));
    }
    const make = vehicleDetails?.make ?? job.vehicle_make ?? undefined;
    const model = vehicleDetails?.model ?? job.vehicle_model ?? undefined;
    const registration = vehicleDetails?.registration ?? job.vehicle_registration ?? undefined;
    const photo = vehicleDetails?.photo ?? job.vehicle_photo ?? null;
    if (make || model || registration || photo) {
      return [
        {
          id: 'fallback-0',
          make,
          model,
          registration,
          colour: vehicleDetails?.colour ?? undefined,
          photo,
        },
      ];
    }
    return [];
  }, [bookingVehicles, vehicleDetails, job]);

  const openVehicles = () => setVehiclesSheetVisible(true);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => !embedded,
        onMoveShouldSetPanResponder: (_, g) => !embedded && Math.abs(g.dy) > 5,
        onPanResponderMove: (_, g) => {
          if (embedded) return;
          if (g.dy > 0) dragOffset.setValue(Math.min(g.dy, MAX_PEEK_DRAG));
        },
        onPanResponderRelease: (_, g) => {
          if (embedded) return;
          const shouldClose = g.dy > DRAG_CLOSE_THRESHOLD || (g.dy > 30 && g.vy > DRAG_VELOCITY_THRESHOLD);
          if (shouldClose) {
            Animated.timing(dragOffset, { toValue: sheetHeight, duration: 220, useNativeDriver: true }).start(() =>
              onClose()
            );
          } else {
            Animated.spring(dragOffset, { toValue: 0, useNativeDriver: true, damping: 25, stiffness: 300 }).start();
          }
        },
      }),
    [dragOffset, embedded, onClose, sheetHeight]
  );

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, [fadeAnim]);

  return (
    <>
      <Animated.View
        style={[
          embedded ? styles.containerEmbedded : styles.container,
          {
            borderColor: embedded ? 'transparent' : `${accent}35`,
            transform: embedded ? undefined : [{ translateY: dragOffset }],
            paddingBottom: bottomPad,
          },
        ]}
        onLayout={(e) => {
          const h = e.nativeEvent.layout.height;
          if (h > 0) {
            onMeasuredHeight?.(h);
            if (!embedded && Math.abs(h - sheetHeight) > 4) {
              setContentHeight(h - bottomPad);
            }
          }
        }}
      >
        {embedded ? null : <ValeterDashboardChrome accent={accent} headerGradient={sheetGradient} />}

        {!embedded ? (
          <View style={styles.topActions}>
            <View style={{ width: 1 }} />
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                onClose();
              }}
              style={[styles.collapseBtn, { backgroundColor: chipBg }]}
            >
              <Ionicons name="chevron-down" size={18} color={textMuted} />
              <Text style={[styles.collapseText, { color: textMuted }]}>Jobs list</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        <View style={styles.panel} {...(embedded ? {} : panResponder.panHandlers)}>
          {embedded ? null : <View style={[styles.handle, { backgroundColor: `${accent}55` }]} />}

          <Animated.View style={[styles.body, embedded && styles.bodyEmbedded, { opacity: fadeAnim }]}>
            <View style={[styles.trackingCard, { borderColor: cardBorder }]}>
                <ValeterDashboardChrome accent={accent} headerGradient={sheetGradient} />
                <View style={styles.cardRow}>
                  <View style={styles.cardBody}>
                    <Text style={[styles.cardService, { color: textMuted }]} numberOfLines={1}>
                      {getServiceDisplayName(job.service_type, job.service_name)}
                    </Text>
                    <Text style={[styles.cardStatus, { color: textMain }]} numberOfLines={1}>
                      {statusMessage}
                    </Text>
                  </View>
                  <ValeterTrackingProgressRing progress={stageProgressPercent} accent={accent} />
                </View>

                <View style={styles.progressWrap}>
                  <View style={[styles.progressTrack, { borderColor: `${accent}25`, backgroundColor: isLight ? 'rgba(158,201,224,0.12)' : 'rgba(255,255,255,0.04)' }]}>
                    <View
                      style={[styles.progressFill, { width: `${stageProgressPercent}%`, backgroundColor: accent }]}
                    />
                  </View>
                  <View style={styles.stagesRow}>
                    <TrackingStageDots stages={stages} accent={accent} mutedColor={textMuted} />
                  </View>
                </View>

                <TrackingVehicleSummary
                  accent={accent}
                  mutedColor={textMuted}
                  textMain={textMain}
                  vehicleCount={galleryVehicles.length}
                  onOpenVehicles={openVehicles}
                />
              </View>

            <View style={styles.actionsRow}>
              <TouchableOpacity
                onPress={onChat}
                style={[styles.iconBtn, { borderColor: `${accent}55`, backgroundColor: iconBtnBg }]}
                accessibilityLabel="Chat"
              >
                <Ionicons name="chatbubble-ellipses-outline" size={20} color={accent} />
              </TouchableOpacity>
              <View style={styles.centerAction}>
                <TrackingCenterAction
                  nextAction={nextAction}
                  status={status}
                  accent={accent}
                  sheetGradient={sheetGradient}
                  isLight={isLight}
                />
              </View>
              <TouchableOpacity
                onPress={onCancel}
                disabled={!canCancel || cancelling}
                style={[
                  styles.iconBtn,
                  styles.cancelIconBtn,
                  (!canCancel || cancelling) && styles.cancelIconBtnDisabled,
                ]}
                accessibilityLabel="Cancel job"
              >
                {cancelling ? (
                  <ActivityIndicator size="small" color="#FECACA" />
                ) : (
                  <Ionicons name="close" size={20} color={canCancel ? '#FEE2E2' : '#94A3B8'} />
                )}
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Animated.View>

      <InfoBottomSheet
        visible={infoSheetVisible}
        onClose={onCloseInfo}
        title="Job details"
        accentColor={accent}
        variant="header"
        contentMaxHeight="72%"
      >
        <JobDetailsContent
          accent={accent}
          customerName={customerName}
          job={job}
          status={status}
          statusMessage={statusMessage}
          bookingVehicles={galleryVehicles}
          etaMinutes={etaMinutes}
          distanceMi={distanceMi}
          onChat={onChat}
          onOpenVehicles={openVehicles}
        />
      </InfoBottomSheet>

      <BookingVehiclesInfoSheet
        visible={vehiclesSheetVisible}
        onClose={() => setVehiclesSheetVisible(false)}
        accent={accent}
        vehicles={galleryVehicles}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    overflow: 'hidden',
    zIndex: 45,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.35,
    shadowRadius: 20,
    elevation: 30,
  },
  containerEmbedded: {
    flexGrow: 0,
    flexShrink: 1,
    width: '100%',
    overflow: 'hidden',
    backgroundColor: 'transparent',
    justifyContent: 'flex-end',
  },
  topActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 4,
    paddingBottom: 0,
  },
  collapseBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  collapseText: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '700',
  },
  cancelTopBtn: {
    backgroundColor: '#DC2626',
    borderWidth: 1,
    borderColor: '#F87171',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    shadowColor: '#DC2626',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.45,
    shadowRadius: 6,
    elevation: 4,
  },
  cancelTopBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.35)',
    borderColor: 'rgba(148,163,184,0.35)',
    shadowOpacity: 0,
    elevation: 0,
    opacity: 1,
  },
  cancelTopText: {
    color: '#FEF2F2',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  cancelTopTextDisabled: {
    color: '#CBD5E1',
  },
  panel: {
    paddingHorizontal: 16,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 4,
  },
  body: {
    gap: 4,
  },
  bodyEmbedded: {
    paddingTop: 4,
    paddingBottom: 0,
  },
  trackingCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 10,
    overflow: 'hidden',
    position: 'relative',
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    zIndex: 1,
  },
  cardBody: { flex: 1, minWidth: 0 },
  cardService: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: 2,
  },
  cardStatus: { fontSize: 15, fontWeight: '800' },
  cardEta: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  progressWrap: { marginBottom: 0, zIndex: 1 },
  progressTrack: {
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 6,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  progressFill: { height: '100%', borderRadius: 2 },
  stagesRow: { flexDirection: 'row', justifyContent: 'space-between' },
  smallStageItem: { flex: 1, alignItems: 'center', minWidth: 0 },
  smallStageDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(100,116,139,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  smallStageDotDone: { backgroundColor: 'rgba(16,185,129,0.9)', borderColor: '#10B981' },
  smallStageDotCurrent: { backgroundColor: `${SKY}30`, borderWidth: 1.5 },
  smallStageLabel: { fontSize: 9, fontWeight: '600', color: '#94A3B8' },
  smallStageLabelDone: { color: '#34D399', fontWeight: '700' },
  cardVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.12)',
    gap: 8,
    zIndex: 1,
  },
  cardVehiclePhoto: { width: 56, height: 40, borderRadius: 8 },
  cardVehiclePhotoPlaceholder: {
    width: 56,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardVehicleInfo: { flex: 1, minWidth: 0 },
  cardVehicleReg: { fontSize: 12, fontWeight: '800' },
  cardVehicleMake: { fontSize: 10, color: '#94A3B8', fontWeight: '600' },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
    marginBottom: 0,
    zIndex: 1,
  },
  centerAction: { flex: 1, minWidth: 0 },
  iconBtn: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15,23,42,0.45)',
    flexShrink: 0,
  },
  cancelIconBtn: {
    backgroundColor: '#DC2626',
    borderColor: '#F87171',
  },
  cancelIconBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.35)',
    borderColor: 'rgba(148,163,184,0.35)',
  },
  bookingInfoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    gap: 10,
    overflow: 'hidden',
  },
  bookingInfoCardCompact: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 16,
    gap: 8,
    minHeight: 52,
  },
  bookingInfoActionCard: { position: 'relative' },
  bookingInfoActionCardDisabled: { position: 'relative', opacity: 0.9 },
  bookingInfoCardTextWrap: { flex: 1, minWidth: 0, zIndex: 1 },
  bookingInfoCardText: { fontSize: 15, fontWeight: '700' },
  bookingInfoCardTextCompact: { fontSize: 15, fontWeight: '800' },
  bookingInfoCardTextDisabled: { color: '#F59E0B', fontWeight: '700' },
  trackSheetDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  jobInfoProfile: { paddingBottom: 8 },
  jobInfoHero: {
    alignItems: 'center',
    paddingVertical: 12,
    marginBottom: 14,
  },
  jobInfoAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  jobInfoProfileName: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  jobInfoProfileHeadline: { fontSize: 13, fontWeight: '700', marginTop: 2, textAlign: 'center' },
  jobInfoStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
  },
  jobInfoStatusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  jobInfoStatusText: {
    fontSize: 12,
    fontWeight: '700',
  },
  vehicleInfoTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 10,
    marginBottom: 2,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 14,
    borderWidth: 1,
    zIndex: 1,
  },
  vehicleInfoIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vehicleInfoCopy: { flex: 1, minWidth: 0 },
  vehicleInfoTitle: { fontSize: 14, fontWeight: '800' },
  vehicleInfoSub: { fontSize: 12, fontWeight: '600', marginTop: 1 },
  jobInfoVehicleCard: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: 14,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  jobInfoVehiclePhoto: {
    width: '100%',
    height: 140,
    backgroundColor: 'rgba(15,23,42,0.5)',
  },
  jobInfoVehicleCaption: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 2,
  },
  jobInfoVehicleReg: { fontSize: 14, fontWeight: '800' },
  jobInfoVehicleMake: { fontSize: 12, color: '#94A3B8', fontWeight: '600' },
  jobInfoList: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.03)',
    marginBottom: 14,
    padding: 6,
    gap: 4,
  },
  jobDetailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.02)',
  },
  jobDetailRowIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  jobDetailRowBody: { flex: 1, minWidth: 0 },
  jobDetailRowLabel: {
    color: 'rgba(148,163,184,0.9)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 3,
  },
  jobDetailRowValue: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
  },
  jobInfoQuickActions: {
    flexDirection: 'row',
    gap: 10,
  },
  jobInfoQuickBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  jobInfoQuickBtnPrimary: {},
  jobInfoQuickBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
});
