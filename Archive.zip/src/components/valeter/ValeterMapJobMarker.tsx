import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { CAR_IMAGE } from '../../constants/washerAssets';

export type ValeterMapJobMarkerProps = Readonly<{
  accent: string;
  ringColor?: string;
  size?: 'sm' | 'md' | 'lg';
  focused?: boolean;
  etaMinutes?: number | null;
  distanceMi?: number | null;
  label?: string;
}>;

export function computeMapJobEta(
  originLat: number,
  originLng: number,
  jobLat: number,
  jobLng: number
): { distanceMi: number; etaMinutes: number } {
  const R = 3959;
  const dLat = ((jobLat - originLat) * Math.PI) / 180;
  const dLon = ((jobLng - originLng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((originLat * Math.PI) / 180) *
      Math.cos((jobLat * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceMi = Math.round(R * c * 10) / 10;
  const etaMinutes = Math.max(1, Math.round(distanceMi * 2));
  return { distanceMi, etaMinutes };
}

export default function ValeterMapJobMarker({
  accent,
  ringColor = 'rgba(56,189,248,0.35)',
  size = 'md',
  focused = false,
  etaMinutes,
  distanceMi,
  label,
}: ValeterMapJobMarkerProps) {
  return (
    <View style={styles.wrap}>
      <CustomerCarMapPin
        accent={accent}
        ringColor={ringColor}
        size={size}
        focused={focused}
        etaMinutes={etaMinutes}
        distanceMi={distanceMi}
        label={label}
      />
    </View>
  );
}

/** Compact car pin for owner/customer locations — always uses `car.png`. */
export function CustomerCarMapPin({
  accent = '#38BDF8',
  ringColor = 'rgba(56,189,248,0.35)',
  size = 'md',
  focused = false,
  etaMinutes,
  distanceMi,
  label,
}: ValeterMapJobMarkerProps) {
  const carSize = size === 'lg' ? 44 : size === 'sm' ? 30 : 36;
  const ringPad = size === 'lg' ? 8 : size === 'sm' ? 5 : 6;
  const ringSize = carSize + ringPad * 2;
  const showEta = distanceMi != null && distanceMi > 0 && etaMinutes != null;
  /** Keep image mounted so map markers don't blank on Android. */
  const [imageReady, setImageReady] = useState(false);
  useEffect(() => {
    setImageReady(false);
  }, [size, focused]);

  return (
    <View style={styles.wrap} collapsable={false}>
      {showEta ? (
        <View style={[styles.callout, { borderColor: `${accent}55`, backgroundColor: 'rgba(10,25,41,0.92)' }]}>
          {label ? (
            <Text style={[styles.calloutLabel, { color: accent }]} numberOfLines={1}>
              {label}
            </Text>
          ) : null}
          <Text style={[styles.calloutEta, { color: accent }]}>~{etaMinutes} min</Text>
          <Text style={styles.calloutDist}>{distanceMi} mi away</Text>
        </View>
      ) : label ? (
        <View style={[styles.callout, styles.calloutCompact, { borderColor: `${accent}55`, backgroundColor: 'rgba(10,25,41,0.92)' }]}>
          <Text style={[styles.calloutLabel, { color: accent }]} numberOfLines={1}>
            {label}
          </Text>
        </View>
      ) : null}

      <View
        collapsable={false}
        style={[
          styles.ring,
          {
            width: ringSize,
            height: ringSize,
            borderRadius: ringSize / 2,
            backgroundColor: ringColor,
            borderColor: focused ? '#fff' : `${accent}88`,
            borderWidth: focused ? 2.5 : 1.5,
            transform: [{ scale: focused ? 1.08 : 1 }],
            opacity: imageReady ? 1 : 0.99,
          },
        ]}
      >
        <Image
          source={CAR_IMAGE}
          style={{ width: carSize, height: carSize }}
          resizeMode="contain"
          onLoad={() => setImageReady(true)}
          onError={() => setImageReady(true)}
        />
      </View>
      <View style={[styles.shadowDot, { backgroundColor: accent }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
  },
  callout: {
    marginBottom: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    minWidth: 72,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 6,
  },
  calloutCompact: {
    paddingVertical: 4,
    minWidth: 56,
  },
  calloutLabel: {
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginBottom: 1,
    maxWidth: 120,
  },
  calloutEta: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  calloutDist: {
    fontSize: 10,
    fontWeight: '600',
    color: 'rgba(249,250,251,0.55)',
    marginTop: 1,
  },
  ring: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 5,
    elevation: 6,
  },
  shadowDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginTop: 2,
    opacity: 0.85,
  },
});
