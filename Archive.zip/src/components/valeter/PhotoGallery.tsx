import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, ScrollView, Dimensions, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

interface Photo {
  id: string;
  url: string;
  serviceType?: string;
  date?: string;
  isBefore?: boolean;
}

interface PhotoGalleryProps {
  photos: Photo[];
  serviceType?: string;
}

export default function PhotoGallery({ photos, serviceType }: PhotoGalleryProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [filter, setFilter] = useState<'all' | 'before' | 'after'>('all');

  const filteredPhotos = photos.filter(photo => {
    if (filter === 'all') return true;
    if (filter === 'before') return photo.isBefore === true;
    return photo.isBefore === false;
  });

  if (photos.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Ionicons name="images-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
        <Text style={styles.emptyText}>No photos available</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        {(['all', 'before', 'after'] as const).map((filterType) => (
          <TouchableOpacity
            key={filterType}
            onPress={() => setFilter(filterType)}
            style={[styles.filterButton, filter === filterType && styles.filterButtonActive]}
          >
            <Text style={[styles.filterText, filter === filterType && styles.filterTextActive]}>
              {filterType === 'all' ? 'All' : filterType === 'before' ? 'Before' : 'After'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Photo Grid */}
      <View style={styles.photoGrid}>
        {filteredPhotos.map((photo) => (
          <TouchableOpacity
            key={photo.id}
            style={styles.photoItem}
            onPress={() => setSelectedPhoto(photo)}
            activeOpacity={0.8}
          >
            <Image source={{ uri: photo.url }} style={styles.photo} />
            {photo.isBefore !== undefined && (
              <View style={[styles.badge, photo.isBefore ? styles.beforeBadge : styles.afterBadge]}>
                <Text style={styles.badgeText}>{photo.isBefore ? 'Before' : 'After'}</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      {/* Lightbox Modal */}
      <Modal
        visible={selectedPhoto !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setSelectedPhoto(null)}
      >
        <View style={styles.modalContainer}>
          <LinearGradient colors={['rgba(0,0,0,0.9)', 'rgba(0,0,0,0.95)']} style={StyleSheet.absoluteFill} />
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setSelectedPhoto(null)}
          >
            <Ionicons name="close" size={28} color="#FFFFFF" />
          </TouchableOpacity>
          {selectedPhoto && (
            <ScrollView
              contentContainerStyle={styles.modalContent}
              maximumZoomScale={3}
              minimumZoomScale={1}
            >
              <Image source={{ uri: selectedPhoto.url }} style={styles.modalPhoto} resizeMode="contain" />
              {selectedPhoto.serviceType && (
                <Text style={styles.modalServiceType}>{selectedPhoto.serviceType}</Text>
              )}
              {selectedPhoto.date && (
                <Text style={styles.modalDate}>{selectedPhoto.date}</Text>
              )}
            </ScrollView>
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  filterButtonActive: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderColor: SKY,
  },
  filterText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    fontWeight: '600',
  },
  filterTextActive: {
    color: SKY,
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  photoItem: {
    width: (width - 60) / 3,
    height: (width - 60) / 3,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  badge: {
    position: 'absolute',
    top: 8,
    right: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  beforeBadge: {
    backgroundColor: '#EF4444',
  },
  afterBadge: {
    backgroundColor: '#10B981',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    marginTop: 12,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 1,
    padding: 8,
  },
  modalContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalPhoto: {
    width: width - 40,
    height: width - 40,
  },
  modalServiceType: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
  },
  modalDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    marginTop: 8,
  },
});

