import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import Animated, {
  useAnimatedProps,
  useSharedValue,
  withSpring,
  withRepeat,
  withTiming,
  withSequence,
  useAnimatedReaction,
  useAnimatedStyle,
  Easing,
  runOnJS,
  interpolate,
} from 'react-native-reanimated';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

type Props = Readonly<{
  progress: number;
  accent: string;
  size?: number;
  /** Soft breathing pulse — for live active job cards */
  pulse?: boolean;
}>;

export default function ValeterTrackingProgressRing({
  progress,
  accent,
  size = 44,
  pulse = false,
}: Props) {
  const stroke = pulse ? 2.25 : 2.5;
  const radius = (size - stroke) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;

  const animatedProgress = useSharedValue(0);
  const pulseAnim = useSharedValue(0);
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    animatedProgress.value = withSpring(Math.min(100, Math.max(0, progress)), {
      damping: 16,
      stiffness: 90,
      mass: 0.8,
    });
  }, [progress, animatedProgress]);

  useEffect(() => {
    if (!pulse) {
      pulseAnim.value = 0;
      return;
    }
    pulseAnim.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.sin) }),
        withTiming(0, { duration: 1400, easing: Easing.inOut(Easing.sin) })
      ),
      -1,
      false
    );
  }, [pulse, pulseAnim]);

  useAnimatedReaction(
    () => animatedProgress.value,
    (value) => {
      runOnJS(setDisplay)(Math.round(value));
    },
    [animatedProgress]
  );

  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference - (animatedProgress.value / 100) * circumference,
  }));

  const pulseRingStyle = useAnimatedStyle(() => {
    if (!pulse) return { opacity: 0, transform: [{ scale: 1 }] };
    return {
      opacity: interpolate(pulseAnim.value, [0, 1], [0.2, 0.55]),
      transform: [{ scale: interpolate(pulseAnim.value, [0, 1], [1, 1.14]) }],
    };
  });

  const arcOpacityStyle = useAnimatedStyle(() => {
    if (!pulse) return { opacity: 0.92 };
    return {
      opacity: interpolate(pulseAnim.value, [0, 1], [0.75, 1]),
    };
  });

  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      {pulse ? (
        <Animated.View
          pointerEvents="none"
          style={[
            styles.pulseHalo,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderColor: accent,
            },
            pulseRingStyle,
          ]}
        />
      ) : null}

      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke="rgba(148,163,184,0.14)"
          strokeWidth={stroke}
          fill="transparent"
        />
      </Svg>

      <Animated.View style={[StyleSheet.absoluteFill, arcOpacityStyle]}>
        <Svg width={size} height={size}>
          <AnimatedCircle
            cx={center}
            cy={center}
            r={radius}
            stroke={accent}
            strokeWidth={stroke}
            fill="transparent"
            strokeDasharray={`${circumference}`}
            animatedProps={animatedProps}
            strokeLinecap="round"
            rotation="-90"
            origin={`${center}, ${center}`}
          />
        </Svg>
      </Animated.View>

      <View style={styles.labelWrap} pointerEvents="none">
        <Text
          allowFontScaling={false}
          {...(Platform.OS === 'android' && { includeFontPadding: false })}
          style={[styles.label, pulse && styles.labelLive, { color: accent }]}
        >
          {display}
          <Text style={styles.labelSuffix}>%</Text>
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseHalo: {
    position: 'absolute',
    borderWidth: 1,
  },
  labelWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  labelLive: {
    fontSize: 12,
    fontWeight: '800',
  },
  labelSuffix: {
    fontSize: 8,
    fontWeight: '600',
    opacity: 0.7,
  },
});
