import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, type Href } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { useValeterNav, VALETER_MAP_ROUTE } from './ValeterNavSidebar';

const APP_ICON = require('../../../assets/icon.png');

export type DockTabId = 'jobs' | 'messages' | 'vehicle' | 'pricing' | 'profile';

/** Visible dock row height (excluding safe-area inset). */
export const VALETER_DOCK_ROW_HEIGHT = 54;

type DockItem = {
  id: DockTabId;
  icon?: IconGlyphName;
  /** Use app mark instead of an Ionicons glyph (Jobs / home). */
  appIcon?: boolean;
  label: string;
  route?: string;
  action?: 'jobs';
  badge?: number;
};

export function resolveValeterDockTab(pathname: string): DockTabId | null {
  const p = pathname || '';
  if (p.includes('/valeter/inbox') || p.includes('/valeter/notifications')) return 'messages';
  if (p.includes('/valeter/profile/valeter-vehicle-info')) return 'vehicle';
  if (p.includes('/valeter/profile/valeter-services')) return 'pricing';
  if (
    p.includes('/valeter/profile/') ||
    p.includes('/valeter/settings/') ||
    p.includes('/valeter/stripe-connect') ||
    p.includes('/valeter/support/') ||
    p.includes('/valeter/features/') ||
    p.includes('/valeter/valeter-wash-history')
  ) {
    return 'profile';
  }
  if (p.includes('/valeter/valeter-dashboard') || p.includes('/valeter/jobs')) return 'jobs';
  return null;
}

export type ValeterDashboardFloatingDockProps = Readonly<{
  accent: string;
  /** `tabBar` = sheet footer. `global` = fixed bottom bar on other screens. */
  variant?: 'tabBar' | 'global';
  jobRequestCount?: number;
  activeTab?: DockTabId | null;
  onJobsPress?: () => void;
}>;

export default function ValeterDashboardFloatingDock({
  accent,
  variant = 'tabBar',
  jobRequestCount = 0,
  activeTab = null,
  onJobsPress,
}: ValeterDashboardFloatingDockProps) {
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isGlobal = variant === 'global';
  const idleColor = 'rgba(241,245,249,0.48)';
  const activeIdleBg = `${accent}20`;
  const resolvedActive = activeTab ?? resolveValeterDockTab(pathname || '');
  const bgTop = theme.background?.[0] ?? (mode === 'light' ? '#6A9BB0' : '#0B1F36');
  const bgBottom = theme.navBarBottomDark ?? theme.background?.[1] ?? (mode === 'light' ? '#2A4660' : '#071525');

  const items: DockItem[] = useMemo(
    () => [
      { id: 'jobs', appIcon: true, label: 'Home', action: 'jobs', badge: jobRequestCount },
      { id: 'messages', icon: 'chatbubble-ellipses-outline', label: 'Chat', route: '/valeter/inbox' },
      { id: 'vehicle', icon: 'car-sport-outline', label: 'Vehicle', route: '/valeter/profile/valeter-vehicle-info' },
      { id: 'pricing', icon: 'pricetag-outline', label: 'Pricing', route: '/valeter/profile/valeter-services' },
      { id: 'profile', icon: 'person-outline', label: 'Profile', route: '/valeter/profile/valeter-profile' },
    ],
    [jobRequestCount]
  );

  const handlePress = async (item: DockItem) => {
    await hapticFeedback('light');
    if (item.action === 'jobs' || item.id === 'jobs') {
      if (onJobsPress) {
        onJobsPress();
        return;
      }
      router.replace(VALETER_MAP_ROUTE as Href);
      return;
    }
    if (item.route) router.push(item.route as Href);
  };

  const tabs = (
    <View style={[styles.tabRow, isGlobal ? styles.tabRowGlobal : { borderTopColor: `${accent}14` }]}>
      {items.map((item) => {
        const active = resolvedActive === item.id;
        const color = active ? accent : idleColor;
        return (
          <TouchableOpacity
            key={item.id}
            style={styles.tabItem}
            onPress={() => handlePress(item)}
            activeOpacity={0.75}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            accessibilityLabel={item.label}
          >
            <View style={[styles.iconWrap, active && { backgroundColor: activeIdleBg }]}>
              {item.appIcon ? (
                <Image
                  source={APP_ICON}
                  style={[styles.appIcon, !active && styles.appIconIdle]}
                  resizeMode="contain"
                />
              ) : (
                <Ionicons name={item.icon!} size={20} color={color} />
              )}
              {item.badge != null && item.badge > 0 ? (
                <View style={[styles.badge, { backgroundColor: accent }]}>
                  <Text style={styles.badgeText}>{item.badge > 9 ? '9+' : item.badge}</Text>
                </View>
              ) : null}
            </View>
            <Text style={[styles.tabLabel, { color }, active && styles.tabLabelActive]} numberOfLines={1}>
              {item.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );

  if (!isGlobal) {
    return tabs;
  }

  return (
    <View style={[styles.globalWrap, { paddingBottom: Math.max(insets.bottom, 8), backgroundColor: bgBottom }]} pointerEvents="box-none">
      {/* Soft fade into page wash — same palette as screen gradient, no separate chrome. */}
      <LinearGradient
        colors={[`${bgTop}00`, `${bgBottom}CC`, bgBottom]}
        locations={[0, 0.45, 1]}
        style={styles.globalFade}
        pointerEvents="none"
      />
      {tabs}
    </View>
  );
}

/** Global dock for non-dashboard valeter screens (reads badge from nav context). */
export function ValeterGlobalDock() {
  const { theme } = useAccountTheme();
  const { jobRequestCount } = useValeterNav();
  const accent = theme.primary || '#9EC9E0';
  return (
    <ValeterDashboardFloatingDock
      variant="global"
      accent={accent}
      jobRequestCount={jobRequestCount}
    />
  );
}

const styles = StyleSheet.create({
  tabRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: 8,
    paddingBottom: 6,
    paddingHorizontal: 4,
    marginTop: 'auto',
    backgroundColor: 'transparent',
    minHeight: VALETER_DOCK_ROW_HEIGHT,
  },
  tabRowGlobal: {
    borderTopWidth: 0,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
    minWidth: 0,
  },
  iconWrap: {
    width: 40,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  appIcon: {
    width: 22,
    height: 22,
    borderRadius: 6,
  },
  appIconIdle: {
    opacity: 0.72,
  },
  tabLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.15,
  },
  tabLabelActive: {
    fontWeight: '800',
  },
  globalWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 40,
    overflow: 'visible',
  },
  globalFade: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: -28,
    bottom: 0,
  },
  badge: {
    position: 'absolute',
    top: -5,
    right: -4,
    minWidth: 15,
    height: 15,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: {
    color: '#0A1929',
    fontSize: 8,
    fontWeight: '800',
  },
});
