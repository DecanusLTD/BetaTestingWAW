import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Pressable,
  ScrollView,
  Platform,
  Dimensions,
  Image,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GradientIconBox, { LocationStyleIconBox } from '../shared/GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import type { IconGlyphName } from '../shared/iconGlyphTypes';
import { DASHBOARD_HEADER_HEIGHT } from '../shared/AppHeader';
import { isValeterDashboardRoute } from '../../utils/valeterNavigation';

const SIDEBAR_WIDTH = Math.min(300, Dimensions.get('window').width * 0.84);

export const VALETER_MAP_ROUTE = '/valeter/valeter-dashboard';

/** Bottom inset for valeter screens above the global sheet-style dock. */
export const VALETER_CONTENT_BOTTOM_PAD = 82;

type NavItem = {
  id: string;
  label: string;
  subtitle?: string;
  icon: IconGlyphName;
  route: string;
  tone?: 'default' | 'money' | 'alert';
  badgeCount?: number;
};

const GO_TO_NAV: NavItem[] = [
  { id: 'messages', label: 'Messages', icon: 'chatbubbles', route: '/valeter/inbox' },
  { id: 'job-requests', label: 'Job requests', icon: 'car', route: '/valeter/jobs', tone: 'alert' },
];

const ACCOUNT_SETTINGS: NavItem[] = [
  { id: 'profile', label: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
  { id: 'documents', label: 'Documents & verification', icon: 'document-text', route: '/valeter/profile/valeter-documents', tone: 'alert' },
  { id: 'personal', label: 'Personal info', icon: 'person-circle', route: '/valeter/profile/valeter-personal-info' },
  { id: 'vehicle', label: 'Vehicle', icon: 'car-sport', route: '/valeter/profile/valeter-vehicle-info' },
  { id: 'services', label: 'Services & pricing', icon: 'wallet-outline', route: '/valeter/profile/valeter-services', tone: 'money' },
];

const WORK_SETTINGS: NavItem[] = [
  { id: 'hours', label: 'Working hours', icon: 'calendar', route: '/valeter/settings/working-hours' },
  { id: 'radius', label: 'Service radius', icon: 'navigate', route: '/valeter/settings/distance-covering' },
  { id: 'notifications-prefs', label: 'Notifications', icon: 'notifications', route: '/valeter/profile/valeter-notification-preferences' },
];

const FINANCE_SETTINGS: NavItem[] = [
  { id: 'history', label: 'Job history', icon: 'time', route: '/valeter/features/job-history' },
  { id: 'wash-history', label: 'Earnings', icon: 'wallet-outline', route: '/valeter/valeter-wash-history', tone: 'money' },
  { id: 'stripe', label: 'Stripe payouts', icon: 'wallet-outline', route: '/valeter/stripe-connect', tone: 'money' },
];

const SUPPORT_SETTINGS: NavItem[] = [
  { id: 'terms', label: 'Terms', icon: 'document-text', route: '/terms-of-service' },
  { id: 'support', label: 'Help & support', icon: 'help-circle', route: '/valeter/support/help-support' },
];

type ValeterNavContextValue = {
  open: () => void;
  close: () => void;
  toggle: () => void;
  visible: boolean;
  jobRequestCount: number;
  setJobRequestCount: (count: number) => void;
  dashboardStats: ValeterNavDashboardStats;
  setDashboardStats: (stats: Partial<ValeterNavDashboardStats>) => void;
};

export type ValeterNavDashboardStats = {
  earningsToday: number;
  jobsToday: number;
  isOnline: boolean;
  verificationPercent: number;
  hasActiveJob: boolean;
};

const ValeterNavContext = createContext<ValeterNavContextValue | null>(null);

export function useValeterNav() {
  const ctx = useContext(ValeterNavContext);
  if (!ctx) {
    return {
      open: () => {},
      close: () => {},
      toggle: () => {},
      visible: false,
      jobRequestCount: 0,
      setJobRequestCount: () => {},
      dashboardStats: { earningsToday: 0, jobsToday: 0, isOnline: false, verificationPercent: 0, hasActiveJob: false },
      setDashboardStats: () => {},
    };
  }
  return ctx;
}

/** Sync live job-request count from the dashboard into the sidebar badges. */
export function useSyncValeterNavJobRequests(count: number) {
  const { setJobRequestCount } = useValeterNav();
  useEffect(() => {
    setJobRequestCount(count);
  }, [count, setJobRequestCount]);
}

export function useSyncValeterNavDashboardStats(stats: ValeterNavDashboardStats) {
  const { setDashboardStats } = useValeterNav();
  useEffect(() => {
    setDashboardStats(stats);
  }, [stats, setDashboardStats]);
}

export function ValeterMenuButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const { toggle } = useValeterNav();
  const accent = color ?? '#F9FAFB';

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={async () => {
          await hapticFeedback('light');
          toggle();
        }}
        style={styles.headerInlineBtn}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Open menu"
      >
        <LocationStyleIconBox variant="inline" icon="menu" colors={accentToGradient(accent)} />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        toggle();
      }}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Open menu"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Ionicons name="menu" size={22} color={accent} />
      </View>
    </TouchableOpacity>
  );
}

/** App mark — used as the header “home” control on valeter sub-pages. */
const APP_ICON = require('../../../assets/icon.png');

/** Return to map home — used in page headers on valeter sub-pages. */
export function ValeterMapHomeButton({ color, headerInline = false }: Readonly<{ color?: string; headerInline?: boolean }>) {
  const router = useRouter();
  const pathname = usePathname();
  const accent = color ?? '#F9FAFB';

  const goMap = async () => {
    await hapticFeedback('light');
    if (isValeterDashboardRoute(pathname || '')) return;
    router.replace(VALETER_MAP_ROUTE);
  };

  if (headerInline) {
    return (
      <TouchableOpacity
        onPress={goMap}
        style={styles.headerInlineBtn}
        hitSlop={12}
        accessibilityRole="button"
        accessibilityLabel="Back to home"
      >
        <Image source={APP_ICON} style={styles.headerAppIcon} resizeMode="contain" />
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      onPress={goMap}
      style={styles.menuBtn}
      hitSlop={12}
      accessibilityRole="button"
      accessibilityLabel="Back to home"
    >
      <BlurView
        intensity={Platform.OS === 'ios' ? 48 : 64}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={[styles.menuBtnInner, { borderColor: `${accent}44` }]}>
        <Image source={APP_ICON} style={styles.menuAppIcon} resizeMode="contain" />
      </View>
    </TouchableOpacity>
  );
}

/** Jobs + messages shortcuts on the map — right edge, outside the sidebar. */
export function ValeterMapQuickActions({
  accent,
  jobRequestCount = 0,
  messageCount = 0,
}: Readonly<{ accent: string; jobRequestCount?: number; messageCount?: number }>) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const go = async (route: string) => {
    await hapticFeedback('light');
    router.push(route);
  };

  const items = [
    { id: 'jobs', icon: 'car' as IconGlyphName, route: '/valeter/jobs', count: jobRequestCount, label: 'Job requests' },
    { id: 'messages', icon: 'chatbubbles' as IconGlyphName, route: '/valeter/inbox', count: messageCount, label: 'Messages' },
  ];

  return (
    <View style={[styles.mapQuickActions, { top: insets.top + DASHBOARD_HEADER_HEIGHT + 12 }]} pointerEvents="box-none">
      {items.map((item) => (
        <TouchableOpacity
          key={item.id}
          onPress={() => go(item.route)}
          style={[styles.mapQuickActionBtn, { borderColor: `${accent}40` }]}
          activeOpacity={0.88}
          accessibilityRole="button"
          accessibilityLabel={item.label}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 52 : 68}
            tint="dark"
            style={StyleSheet.absoluteFill}
            {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
          />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.04)']}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <Ionicons name={item.icon} size={22} color={accent} />
          {item.count > 0 ? (
            <View style={[styles.mapQuickBadge, { backgroundColor: accent }]}>
              <Text style={styles.mapQuickBadgeText}>{item.count > 9 ? '9+' : item.count}</Text>
            </View>
          ) : null}
        </TouchableOpacity>
      ))}
    </View>
  );
}

/** Top-left map home on valeter sub-pages. */
export function ValeterFloatingMapHomeButton() {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? '#38BDF8';
  return (
    <View style={[styles.floatingMenuWrap, { top: insets.top + 8 }]} pointerEvents="box-none">
      <ValeterMapHomeButton color={accent} />
    </View>
  );
}

function settingsRowPreset(tone?: NavItem['tone']): 'green' | 'amber' | 'sky' {
  if (tone === 'money') return 'green';
  if (tone === 'alert') return 'amber';
  return 'sky';
}

function SettingsRow({
  item,
  accent,
  onPress,
}: Readonly<{ item: NavItem; accent: string; onPress: () => void }>) {
  const preset = settingsRowPreset(item.tone);
  const badge = item.badgeCount && item.badgeCount > 0 ? item.badgeCount : 0;
  return (
    <TouchableOpacity onPress={onPress} style={styles.settingsRow} activeOpacity={0.85}>
      <LocationStyleIconBox icon={item.icon} preset={preset} variant="nav" />
      <Text style={styles.settingsRowLabel}>{item.label}</Text>
      {badge > 0 ? (
        <View style={[styles.navBadge, { backgroundColor: accent }]}>
          <Text style={styles.navBadgeText}>{badge > 9 ? '9+' : badge}</Text>
        </View>
      ) : null}
      <Ionicons name="chevron-forward" size={16} color="rgba(249,250,251,0.35)" />
    </TouchableOpacity>
  );
}

function QuickActionTile({
  icon,
  label,
  accent,
  badge,
  onPress,
}: Readonly<{
  icon: IconGlyphName;
  label: string;
  accent: string;
  badge?: number;
  onPress: () => void;
}>) {
  return (
    <TouchableOpacity style={[styles.quickTile, { borderColor: `${accent}30` }]} onPress={onPress} activeOpacity={0.88}>
      <LocationStyleIconBox icon={icon} preset="sky" variant="nav" />
      <Text style={styles.quickTileLabel} numberOfLines={2}>
        {label}
      </Text>
      {badge != null && badge > 0 ? (
        <View style={[styles.quickTileBadge, { backgroundColor: accent }]}>
          <Text style={styles.quickTileBadgeText}>{badge > 9 ? '9+' : badge}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );
}

function QuickActionsGrid({
  accent,
  jobRequestCount,
  onNavigate,
}: Readonly<{ accent: string; jobRequestCount: number; onNavigate: (route: string) => void }>) {
  const tiles = [
    { id: 'jobs', icon: 'car' as IconGlyphName, label: 'Jobs', route: '/valeter/jobs', badge: jobRequestCount },
    { id: 'inbox', icon: 'chatbubbles' as IconGlyphName, label: 'Messages', route: '/valeter/inbox' },
    { id: 'docs', icon: 'document-text' as IconGlyphName, label: 'Documents', route: '/valeter/profile/valeter-documents' },
    { id: 'earnings', icon: 'wallet-outline' as IconGlyphName, label: 'Earnings', route: '/valeter/valeter-wash-history' },
  ];
  return (
    <View style={styles.quickGrid}>
      {tiles.map((t) => (
        <QuickActionTile
          key={t.id}
          icon={t.icon}
          label={t.label}
          accent={accent}
          badge={t.badge}
          onPress={() => onNavigate(t.route)}
        />
      ))}
    </View>
  );
}

function SettingsGroup({
  title,
  items,
  accent,
  onNavigate,
}: Readonly<{
  title: string;
  items: NavItem[];
  accent: string;
  onNavigate: (route: string) => void;
}>) {
  return (
    <View style={styles.settingsGroup}>
      <Text style={styles.groupTitle}>{title}</Text>
      <View style={styles.groupCard}>
        {items.map((item, index) => (
          <View key={item.id}>
            {index > 0 ? <View style={styles.groupDivider} /> : null}
            <SettingsRow item={item} accent={accent} onPress={() => onNavigate(item.route)} />
          </View>
        ))}
      </View>
    </View>
  );
}

export function ValeterNavProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [jobRequestCount, setJobRequestCount] = useState(0);
  const [dashboardStats, setDashboardStatsState] = useState<ValeterNavDashboardStats>({
    earningsToday: 0,
    jobsToday: 0,
    isOnline: false,
    verificationPercent: 0,
    hasActiveJob: false,
  });
  const router = useRouter();

  const goProfile = useCallback(() => {
    router.push('/valeter/profile/valeter-profile' as any);
  }, [router]);

  const open = useCallback(() => {
    goProfile();
  }, [goProfile]);
  const close = useCallback(() => {}, []);
  const toggle = useCallback(() => {
    goProfile();
  }, [goProfile]);

  const setDashboardStats = useCallback((patch: Partial<ValeterNavDashboardStats>) => {
    setDashboardStatsState((prev) => ({ ...prev, ...patch }));
  }, []);

  const ctx = useMemo(
    () => ({
      open,
      close,
      toggle,
      visible: false,
      jobRequestCount,
      setJobRequestCount,
      dashboardStats,
      setDashboardStats,
    }),
    [open, close, toggle, jobRequestCount, dashboardStats, setDashboardStats]
  );

  return <ValeterNavContext.Provider value={ctx}>{children}</ValeterNavContext.Provider>;
}

const styles = StyleSheet.create({
  menuBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
  },
  menuBtnInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 14,
  },
  headerInlineBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    flexShrink: 0,
  },
  headerAppIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
  },
  menuAppIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
  },
  floatingMenuWrap: {
    position: 'absolute',
    left: 16,
    zIndex: 100,
  },
  mapQuickActions: {
    position: 'absolute',
    right: 16,
    zIndex: 30,
    gap: 10,
    alignItems: 'center',
  },
  mapQuickActionBtn: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapQuickBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  mapQuickBadgeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: '900',
  },
  modalRoot: {
    flex: 1,
    flexDirection: 'row',
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  panel: {
    height: '100%',
    borderRightWidth: 1,
    borderRightColor: 'rgba(255,255,255,0.1)',
    overflow: 'hidden',
  },
  panelAccentGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 180,
  },
  panelInner: {
    flex: 1,
    paddingHorizontal: 16,
  },
  panelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  panelEyebrow: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.55)',
    marginBottom: 18,
  },
  userAvatarWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    overflow: 'hidden',
  },
  userAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
  },
  userCopy: {
    flex: 1,
    minWidth: 0,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  userRole: {
    fontSize: 12,
    fontWeight: '600',
    marginTop: 3,
  },
  statsStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    marginBottom: 12,
    paddingVertical: 12,
  },
  statCell: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
  },
  statLabel: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 10,
    fontWeight: '700',
    marginTop: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  statDivider: {
    width: 1,
    height: 28,
  },
  smartCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 14,
  },
  smartCardMuted: {
    borderColor: 'rgba(148,163,184,0.2)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  smartCardCopy: {
    flex: 1,
    minWidth: 0,
  },
  smartCardTitle: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
  },
  smartCardSub: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
  scroll: {
    flex: 1,
  },
  quickGridTitle: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 10,
    marginTop: 4,
  },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 18,
  },
  quickTile: {
    width: '47%',
    flexGrow: 1,
    minHeight: 78,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.45)',
    padding: 10,
    gap: 6,
  },
  quickTileLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
  quickTileBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  quickTileBadgeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: '800',
  },
  groupTitle: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 4,
  },
  settingsGroup: {
    marginBottom: 16,
  },
  groupCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(15,23,42,0.45)',
    overflow: 'hidden',
  },
  groupDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginLeft: 56,
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
    paddingHorizontal: 14,
  },
  settingsRowLabel: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  navBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  navBadgeText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '900',
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
    marginBottom: 12,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.28)',
  },
  logoutText: {
    color: '#FCA5A5',
    fontSize: 15,
    fontWeight: '700',
  },
});
