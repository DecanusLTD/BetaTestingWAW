import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet,
  Animated,
  Easing,
  Modal,
  Pressable,
  Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { SCREEN_PADDING_H } from '../../constants/premiumTokens';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import ValeterDashboardChrome from './ValeterDashboardChrome';

const ICON_AUTH = require('../../../assets/icon-auth.png');

const ONLINE_BTN = 52;
const SPARKLE_ORBITS = [
  { dx: 38, dy: -38 },
  { dx: -40, dy: -26 },
  { dx: 44, dy: 22 },
  { dx: -28, dy: 40 },
  { dx: 0, dy: -48 },
  { dx: 0, dy: 50 },
] as const;

/** Total chrome below safe area (single header row). */
export const VALETER_MAP_HEADER_BODY = 56;

export function valeterMapHeaderTotalHeight(safeTop: number) {
  return safeTop + VALETER_MAP_HEADER_BODY;
}

export type ValeterMapHeaderProps = Readonly<{
  profileName: string;
  locationLabel: string;
  profilePictureUri?: string | null;
  earnings: number;
  jobsCompleted: number;
  jobRequestCount: number;
  isOnline: boolean;
  accent: string;
  headerGradient: readonly [string, string];
  loadingOnline?: boolean;
  togglingOnline?: boolean;
  onProfilePress: () => void;
  onLocationPress: () => void;
  onToggleOnline: () => void;
  onNotificationsPress: () => void;
  /** Live job header — replaces online toggle / valeter location with trip context. */
  trackingMode?: boolean;
  trackingCustomerName?: string;
  trackingLocationLabel?: string;
  /** Owner profile photo (left avatar during tracking). */
  trackingCustomerPhotoUri?: string | null;
  /** Kept for card/preview callers; not shown in the left avatar anymore. */
  trackingVehiclePhotoUri?: string | null;
  trackingEtaMinutes?: number | null;
  trackingPrice?: number | null;
}>;

export default function ValeterMapHeader({
  profileName,
  locationLabel,
  profilePictureUri,
  earnings,
  jobsCompleted,
  jobRequestCount,
  isOnline,
  accent,
  headerGradient,
  loadingOnline = false,
  togglingOnline = false,
  onProfilePress,
  onLocationPress,
  onToggleOnline,
  onNotificationsPress,
  trackingMode = false,
  trackingCustomerName,
  trackingLocationLabel,
  trackingCustomerPhotoUri,
  trackingVehiclePhotoUri: _trackingVehiclePhotoUri,
  trackingEtaMinutes,
  trackingPrice,
}: ValeterMapHeaderProps) {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F1F5F9';
  const textMuted = theme.textSecondary ?? 'rgba(241,245,249,0.55)';
  /** Brand gold — same yellow used across Wish-a-Wash headers (not amber/orange). */
  const moneyColor = '#E8C547';
  const busy = loadingOnline || togglingOnline;
  const [previewOpen, setPreviewOpen] = useState(false);

  const ringPulse = useRef(new Animated.Value(0)).current;
  const ringLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const spinAnim = useRef(new Animated.Value(0)).current;
  const spinScale = useRef(new Animated.Value(1)).current;
  const sparkleAnims = useRef(SPARKLE_ORBITS.map(() => new Animated.Value(0))).current;
  const wasOnlineRef = useRef(isOnline);

  useEffect(() => {
    if (trackingMode) {
      ringLoopRef.current?.stop();
      return;
    }
    ringLoopRef.current?.stop();
    ringPulse.setValue(0);
    ringLoopRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(ringPulse, {
          toValue: 1,
          duration: isOnline ? 1600 : 2000,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(ringPulse, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    ringLoopRef.current.start();
    return () => ringLoopRef.current?.stop();
  }, [isOnline, ringPulse, trackingMode]);

  const playSpinOut = () => {
    spinAnim.setValue(0);
    spinScale.setValue(0.65);
    Animated.parallel([
      Animated.timing(spinAnim, {
        toValue: 1,
        duration: 620,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.spring(spinScale, {
        toValue: 1,
        friction: 5,
        tension: 90,
        useNativeDriver: true,
      }),
    ]).start(() => spinAnim.setValue(0));

    sparkleAnims.forEach((anim, i) => {
      anim.setValue(0);
      Animated.timing(anim, {
        toValue: 1,
        duration: 720,
        delay: i * 35,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start(() => anim.setValue(0));
    });
  };

  useEffect(() => {
    if (trackingMode) return;
    if (!wasOnlineRef.current && isOnline && !loadingOnline) {
      playSpinOut();
    }
    wasOnlineRef.current = isOnline;
  }, [isOnline, loadingOnline, trackingMode]);

  const ringScale = ringPulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.45] });
  const ringOpacity = ringPulse.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0.5, 0.35, 0] });
  const spinRotate = spinAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const ringColor = isOnline ? 'rgba(74,222,128,0.75)' : 'rgba(248,113,113,0.7)';

  const handleOnlinePress = async () => {
    await hapticFeedback(isOnline ? 'light' : 'medium');
    if (!isOnline) playSpinOut();
    onToggleOnline();
  };

  const headerLocation = trackingMode
    ? trackingLocationLabel?.trim() || 'Customer location'
    : locationLabel;
  const headerName = trackingMode
    ? trackingCustomerName?.trim() || 'Customer'
    : profileName || 'Car Care Pro';
  const priceLabel =
    trackingPrice != null && Number.isFinite(Number(trackingPrice))
      ? `£${Number(trackingPrice).toFixed(2)}`
      : null;
  const etaLabel =
    trackingEtaMinutes == null || !Number.isFinite(trackingEtaMinutes)
      ? '—'
      : trackingEtaMinutes <= 0
        ? 'Here'
        : `${Math.max(1, Math.round(trackingEtaMinutes))} min`;

  return (
    <View style={[styles.wrap, { paddingTop: insets.top, borderBottomColor: isLight ? 'rgba(232,197,71,0.22)' : 'rgba(255,255,255,0.06)' }]}>
      <ValeterDashboardChrome accent={accent} headerGradient={headerGradient} />

      <View style={styles.row}>
        <View
          style={[
            styles.avatarBtn,
            { borderColor: `${accent}50` },
          ]}
          accessibilityLabel={trackingMode ? 'Customer profile photo' : 'Profile'}
        >
          {trackingMode ? (
            <TouchableOpacity
              onPress={async () => {
                if (!trackingCustomerPhotoUri) return;
                await hapticFeedback('light');
                setPreviewOpen(true);
              }}
              activeOpacity={trackingCustomerPhotoUri ? 0.88 : 1}
              disabled={!trackingCustomerPhotoUri}
              style={StyleSheet.absoluteFill}
              accessibilityRole="button"
              accessibilityLabel="Enlarge customer photo"
            >
              {trackingCustomerPhotoUri ? (
                <Image source={{ uri: trackingCustomerPhotoUri }} style={styles.avatarImg} resizeMode="cover" />
              ) : (
                <View style={[styles.avatarVehicleFallback, { backgroundColor: `${accent}18` }]}>
                  <Ionicons name="person" size={20} color={accent} />
                </View>
              )}
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                onProfilePress();
              }}
              activeOpacity={0.88}
              style={StyleSheet.absoluteFill}
              accessibilityRole="button"
              accessibilityLabel="Open menu"
            >
              {profilePictureUri ? (
                <Image source={{ uri: profilePictureUri }} style={styles.avatarImg} />
              ) : (
                <Image source={ICON_AUTH} style={styles.avatarImg} resizeMode="cover" />
              )}
            </TouchableOpacity>
          )}
          {!trackingMode ? (
            <View style={[styles.onlineDot, { backgroundColor: isOnline ? '#4ADE80' : '#F87171' }]} />
          ) : null}
        </View>

        <View style={[styles.sideCol, trackingMode && styles.sideColTracking]}>
          <Text style={[styles.name, { color: textMain }]} numberOfLines={1}>
            {headerName}
          </Text>
          <TouchableOpacity
            onPress={trackingMode ? undefined : onLocationPress}
            disabled={trackingMode}
            activeOpacity={0.75}
            style={styles.locationRow}
          >
            <Ionicons name="location-outline" size={11} color={accent} />
            <Text style={[styles.location, { color: accent }]} numberOfLines={1}>
              {headerLocation}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.onlineCenter, trackingMode && styles.onlineCenterTracking]} pointerEvents="box-none">
          {trackingMode ? (
            <View style={styles.trackingEtaWrap}>
              <Text style={[styles.trackingEtaValue, { color: accent }]} numberOfLines={1}>
                {etaLabel}
              </Text>
              <Text style={[styles.trackingEtaCaption, { color: textMuted }]}>ETA</Text>
            </View>
          ) : (
            <>
              {sparkleAnims.map((anim, i) => {
                const orbit = SPARKLE_ORBITS[i];
                const tx = anim.interpolate({ inputRange: [0, 1], outputRange: [0, orbit.dx] });
                const ty = anim.interpolate({ inputRange: [0, 1], outputRange: [0, orbit.dy] });
                const opacity = anim.interpolate({ inputRange: [0, 0.15, 0.85, 1], outputRange: [0, 1, 0.6, 0] });
                const scale = anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.2, 1, 0.4] });
                return (
                  <Animated.View
                    key={`spark-${i}`}
                    pointerEvents="none"
                    style={[
                      styles.sparkle,
                      {
                        backgroundColor: isOnline ? '#86EFAC' : accent,
                        opacity,
                        transform: [{ translateX: tx }, { translateY: ty }, { scale }],
                      },
                    ]}
                  />
                );
              })}

              <Animated.View
                pointerEvents="none"
                style={[
                  styles.pulseRing,
                  { borderColor: ringColor, opacity: ringOpacity, transform: [{ scale: ringScale }] },
                ]}
              />

              <TouchableOpacity
                onPress={handleOnlinePress}
                disabled={busy}
                activeOpacity={0.9}
                style={styles.onlineBtnOuter}
                accessibilityRole="button"
                accessibilityLabel={isOnline ? 'Go offline' : 'Go online'}
              >
                <Animated.View
                  style={[
                    styles.onlineBtn,
                    {
                      borderColor: isOnline ? '#4ADE80' : `${accent}80`,
                      backgroundColor: isOnline ? 'rgba(16,185,129,0.18)' : `${accent}22`,
                      transform: [{ scale: spinScale }, { rotate: spinRotate }],
                    },
                  ]}
                >
                  {busy ? (
                    <ActivityIndicator size="small" color={isOnline ? '#4ADE80' : accent} />
                  ) : (
                    <Image source={ICON_AUTH} style={styles.onlineMascot} resizeMode="cover" />
                  )}
                </Animated.View>
              </TouchableOpacity>

              <Text style={[styles.onlineLabel, { color: isOnline ? '#6EE7B7' : textMuted }]}>
                {isOnline ? 'Online' : 'Go online'}
              </Text>
            </>
          )}
        </View>

        <View style={[styles.sideColRight, trackingMode && styles.sideColRightTracking]}>
          {trackingMode ? (
            <Text style={[styles.earnings, styles.trackingPrice, { color: moneyColor }]} numberOfLines={1}>
              {priceLabel ?? '—'}
            </Text>
          ) : (
            <>
              <Text style={[styles.earnings, { color: moneyColor }]}>£{earnings.toFixed(2)}</Text>
              <Text style={[styles.jobsMeta, { color: textMuted }]}>
                {jobsCompleted} job{jobsCompleted === 1 ? '' : 's'}
              </Text>
              <TouchableOpacity onPress={onNotificationsPress} style={styles.bellWrap}>
                <GradientNotificationBell count={jobRequestCount} onPress={onNotificationsPress} />
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>

      <Modal
        visible={previewOpen && !!trackingCustomerPhotoUri}
        transparent
        animationType="fade"
        onRequestClose={() => setPreviewOpen(false)}
      >
        <Pressable style={styles.previewOverlay} onPress={() => setPreviewOpen(false)}>
          <Pressable style={styles.previewCard} onPress={(e) => e.stopPropagation()}>
            {trackingCustomerPhotoUri ? (
              <Image
                source={{ uri: trackingCustomerPhotoUri }}
                style={styles.previewImage}
                resizeMode="contain"
              />
            ) : null}
            <TouchableOpacity
              style={[styles.previewClose, { backgroundColor: accent }]}
              onPress={() => setPreviewOpen(false)}
              activeOpacity={0.88}
            >
              <Text style={styles.previewCloseText}>Close</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
    paddingHorizontal: SCREEN_PADDING_H,
    paddingBottom: 6,
    overflow: 'visible',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  previewOverlay: {
    flex: 1,
    backgroundColor: 'rgba(2,8,18,0.88)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  previewCard: {
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
    gap: 14,
  },
  previewImage: {
    width: Dimensions.get('window').width - 40,
    height: Math.min(Dimensions.get('window').width - 40, Dimensions.get('window').height * 0.55),
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.9)',
  },
  previewClose: {
    paddingHorizontal: 22,
    paddingVertical: 12,
    borderRadius: 999,
  },
  previewCloseText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '800',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    minHeight: 56,
  },
  avatarBtn: {
    width: 40,
    height: 40,
    borderRadius: 13,
    overflow: 'hidden',
    borderWidth: 1.5,
    marginTop: 4,
  },
  avatarBtnVehicle: {
    width: 48,
    height: 40,
    borderRadius: 12,
  },
  avatarImg: {
    width: '100%',
    height: '100%',
  },
  avatarVehicleFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  onlineDot: {
    position: 'absolute',
    bottom: 1,
    right: 1,
    width: 9,
    height: 9,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  sideCol: {
    flex: 1,
    minWidth: 0,
    paddingTop: 6,
    paddingHorizontal: 6,
  },
  sideColTracking: {
    flex: 1.15,
  },
  sideColRight: {
    flex: 1,
    minWidth: 0,
    alignItems: 'flex-end',
    paddingTop: 6,
    paddingHorizontal: 6,
  },
  sideColRightTracking: {
    flex: 0.7,
    justifyContent: 'center',
    paddingTop: 10,
  },
  name: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 2,
  },
  location: {
    fontSize: 10,
    fontWeight: '600',
    flexShrink: 1,
  },
  onlineCenter: {
    width: ONLINE_BTN + 24,
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 0,
    zIndex: 5,
  },
  onlineCenterTracking: {
    width: 88,
    paddingTop: 2,
  },
  pulseRing: {
    position: 'absolute',
    top: 4,
    width: ONLINE_BTN,
    height: ONLINE_BTN,
    borderRadius: ONLINE_BTN / 2,
    borderWidth: 2,
  },
  sparkle: {
    position: 'absolute',
    top: ONLINE_BTN / 2 + 4,
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  onlineBtnOuter: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  onlineBtn: {
    width: ONLINE_BTN,
    height: ONLINE_BTN,
    borderRadius: ONLINE_BTN / 2,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 8,
  },
  onlineMascot: {
    width: ONLINE_BTN - 8,
    height: ONLINE_BTN - 8,
    borderRadius: (ONLINE_BTN - 8) / 2,
  },
  onlineLabel: {
    fontSize: 9,
    fontWeight: '800',
    marginTop: 3,
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  trackingEtaWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 78,
    paddingHorizontal: 4,
  },
  trackingEtaValue: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.4,
    textAlign: 'center',
  },
  trackingEtaCaption: {
    marginTop: 2,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
  },
  trackingPrice: {
    fontSize: 16,
    textAlign: 'right',
  },
  earnings: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.5,
    textAlign: 'right',
  },
  jobsMeta: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 9,
    fontWeight: '700',
    marginTop: 1,
    textAlign: 'right',
  },
  bellWrap: {
    marginTop: 4,
    alignSelf: 'flex-end',
  },
});
