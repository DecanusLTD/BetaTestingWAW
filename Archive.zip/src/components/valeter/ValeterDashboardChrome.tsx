import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useAccountTheme } from '../shared/AccountThemeProvider';

const ANDROID_BLUR =
  Platform.OS === 'android' ? ({ experimentalBlurMethod: 'dimezisBlurView' as const } as const) : {};

/** Append hex alpha only when the stop is a plain #RRGGBB (rgba stays untouched). */
export function headerChromeStop(color: string, hexAlpha: string): string {
  const c = (color || '').trim();
  if (/^#[0-9A-Fa-f]{6}$/.test(c)) return `${c}${hexAlpha}`;
  return c;
}

type Props = Readonly<{
  accent: string;
  headerGradient: readonly [string, string];
}>;

/**
 * Shared frosted chrome for map header + dashboard bottom sheet.
 * Light mode: lighter steel-blue frost with a soft gold edge wash.
 */
export default function ValeterDashboardChrome({ accent, headerGradient }: Props) {
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const gold = theme.accentAlt ?? '#E8C547';
  const top = headerChromeStop(headerGradient[0], 'EE');
  const bottom = headerChromeStop(headerGradient[1] ?? headerGradient[0], 'F0');

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <BlurView
        intensity={Platform.OS === 'ios' ? (isLight ? 52 : 64) : isLight ? 66 : 80}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...ANDROID_BLUR}
      />
      {isLight ? (
        <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(42,70,96,0.32)' }]} />
      ) : null}
      <LinearGradient colors={[top, bottom]} style={StyleSheet.absoluteFill} />
      {isLight ? (
        <LinearGradient
          colors={[`${gold}22`, 'transparent', `${accent}18`]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      ) : null}
      <LinearGradient colors={[`${accent}30`, 'transparent']} style={styles.accentLine} />
      {isLight ? (
        <LinearGradient colors={[`${gold}55`, 'transparent']} style={styles.goldEdge} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  accentLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
  },
  goldEdge: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '42%',
    height: 2,
  },
});
