import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { CustomerCarMapPin } from './ValeterMapJobMarker';
import { VALETER_MAP_IMAGE } from '../../constants/washerAssets';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import GradientIconBox from '../shared/GradientIconBox';
import { SCREEN_PADDING_H } from '../../constants/premiumTokens';
import { DARK_MAP_STYLE } from '../../constants/mapStyles';
import { MAP_LOCKED_DARK } from '../../constants/mapConstants';

export type ValeterJobRequest = Readonly<{
  id: string;
  serviceName: string;
  distance: number;
  driveTimeMinutes?: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
  location_lat: number | null;
  location_lng: number | null;
}>;

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatDistanceLine(distance: number, driveTimeMinutes?: number): string {
  if (distance <= 0) return '';
  if (driveTimeMinutes != null) return `${distance} mi · ~${driveTimeMinutes} min`;
  return `${distance} mi`;
}

export type ValeterJobRequestOverlayProps = Readonly<{
  job: ValeterJobRequest;
  mapRegion: Region | null;
  valeterLat?: number | null;
  valeterLng?: number | null;
  accent: string;
  totalRequests: number;
  bottomInset: number;
  onAccept: (jobId: string) => void;
  onDecline: (jobId: string) => void;
}>;

export default function ValeterJobRequestOverlay({
  job,
  mapRegion,
  valeterLat,
  valeterLng,
  accent,
  totalRequests,
  bottomInset,
  onAccept,
  onDecline,
}: ValeterJobRequestOverlayProps) {
  return (
    <View style={[styles.wrap, { bottom: bottomInset + 12 }]}>
      <View style={[styles.card, { borderColor: `${accent}45` }]}>
        {mapRegion ? (
          <>
            <MapView
              style={styles.map}
              region={mapRegion}
              scrollEnabled={false}
              zoomEnabled={false}
              pitchEnabled={false}
              rotateEnabled={false}
              customMapStyle={DARK_MAP_STYLE}
              userInterfaceStyle={MAP_LOCKED_DARK}
            >
              {valeterLat != null && valeterLng != null ? (
                <Marker coordinate={{ latitude: valeterLat, longitude: valeterLng }} title="You" anchor={{ x: 0.5, y: 0.5 }}>
                  <Image source={VALETER_MAP_IMAGE} style={styles.markerValeter} resizeMode="contain" />
                </Marker>
              ) : null}
              {job.location_lat != null && job.location_lng != null ? (
                <Marker
                  coordinate={{ latitude: job.location_lat, longitude: job.location_lng }}
                  title={job.serviceName}
                  anchor={{ x: 0.5, y: 1 }}
                  tracksViewChanges
                >
                  <CustomerCarMapPin
                    accent={accent}
                    ringColor="rgba(245,158,11,0.38)"
                    size="sm"
                    etaMinutes={job.driveTimeMinutes}
                    distanceMi={job.distance > 0 ? job.distance : null}
                    label="Owner"
                  />
                </Marker>
              ) : null}
            </MapView>
            <LinearGradient
              colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.55)', 'rgba(10,25,41,0.92)']}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
          </>
        ) : null}

        <View style={styles.content}>
          <View style={styles.badgeRow}>
            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>New request</Text>
            </View>
            <View style={styles.timer}>
              <Ionicons name="time" size={13} color="#FBBF24" />
              <Text style={styles.timerText}>{formatTime(job.timeRemaining)}</Text>
            </View>
          </View>

          <Text style={styles.serviceName}>{job.serviceName}</Text>
          <Text style={styles.customer}>{job.customerName}</Text>
          <Text style={styles.address} numberOfLines={2}>
            {job.address}
          </Text>

          <View style={styles.metaRow}>
            <Text style={[styles.price, { color: accent }]}>£{job.price}</Text>
            {job.distance > 0 ? (
              <Text style={styles.distance}>
                {formatDistanceLine(job.distance, job.driveTimeMinutes)}
              </Text>
            ) : null}
            {totalRequests > 1 ? (
              <Text style={styles.more}>+{totalRequests - 1} more</Text>
            ) : null}
          </View>

          <View style={styles.actions}>
            <TouchableOpacity
              style={[styles.acceptBtn, { backgroundColor: accent }]}
              onPress={() => onAccept(job.id)}
              activeOpacity={0.88}
            >
              <GradientIconBox
                icon="checkmark"
                borderless
                boxSize={28}
                size={16}
                colors={['rgba(10,25,41,0.25)', 'rgba(10,25,41,0.08)']}
              />
              <Text style={styles.acceptText}>Accept job</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.declineBtn} onPress={() => onDecline(job.id)} activeOpacity={0.85}>
              <Text style={styles.declineText}>Decline</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: SCREEN_PADDING_H,
    right: SCREEN_PADDING_H,
    zIndex: 35,
  },
  card: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1.5,
    backgroundColor: 'rgba(10,25,41,0.95)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 20,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
    height: '100%',
  },
  content: {
    padding: 16,
    minHeight: 180,
    justifyContent: 'flex-end',
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.4)',
  },
  liveDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#F87171',
  },
  liveText: {
    color: '#FCA5A5',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  timer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(245,158,11,0.15)',
  },
  timerText: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 2,
  },
  customer: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    fontWeight: '600',
  },
  address: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 4,
    marginBottom: 12,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  price: {
    fontSize: 22,
    fontWeight: '800',
  },
  distance: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 13,
    fontWeight: '600',
  },
  more: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 12,
    fontWeight: '700',
    marginLeft: 'auto',
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
  },
  acceptBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
  acceptText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '800',
  },
  declineBtn: {
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    justifyContent: 'center',
  },
  declineText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '700',
  },
  markerValeter: {
    width: 32,
    height: 32,
  },
});
