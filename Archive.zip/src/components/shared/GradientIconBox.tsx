import React from 'react';
import { View, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  CONTINUE_CTA_ICON_NAME,
  bookingContinueIconColor,
} from '../../utils/bookingContinueStyle';
import type { IconGlyphName } from './iconGlyphTypes';

export const GRADIENT_PRESETS = {
  sky: ['#38BDF8', '#0EA5E9'] as [string, string],
  emerald: ['#34D399', '#059669'] as [string, string],
  green: ['#10B981', '#059669'] as [string, string],
  amber: ['#F59E0B', '#D97706'] as [string, string],
  cyan: ['#06B6D4', '#0891B2'] as [string, string],
  pink: ['#EC4899', '#DB2777'] as [string, string],
  gray: ['#6B7280', '#4B5563'] as [string, string],
  teal: ['#14B8A6', '#0D9488'] as [string, string],
  red: ['#EF4444', '#DC2626'] as [string, string],
  blue: ['#3B82F6', '#2563EB'] as [string, string],
  purple: ['#8B5CF6', '#7C3AED'] as [string, string],
} as const;

export interface GradientIconBoxProps {
  /** Glyph to render. Omit to use the default trailing CTA chevron. */
  icon?: IconGlyphName;
  colors?: [string, string];
  preset?: keyof typeof GRADIENT_PRESETS;
  size?: number;
  boxSize?: number;
  /** Kept for API compatibility; no longer drawn (icons are flat/borderless). */
  borderRadius?: number;
  elevated?: boolean;
  borderless?: boolean;
  style?: ViewStyle;
}

function isSolidColorStop(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0;
}

function resolveGradientTuple(
  colors: [string, string] | undefined,
  preset: keyof typeof GRADIENT_PRESETS | undefined
): [string, string] {
  const presetKey =
    preset && typeof preset === 'string' && preset in GRADIENT_PRESETS ? preset : 'sky';
  const fallback = GRADIENT_PRESETS[presetKey] ?? GRADIENT_PRESETS.sky;
  if (colors && Array.isArray(colors) && colors.length >= 2) {
    const a = colors[0];
    const b = colors[1];
    if (isSolidColorStop(a) && isSolidColorStop(b)) {
      return [a.trim(), b.trim()];
    }
  }
  return [fallback[0], fallback[1]];
}

function accentKey(tuple: [string, string]): string {
  const raw = tuple[0].trim();
  if (/^#[0-9A-F]{6}$/i.test(raw)) return raw;
  if (/^#[0-9A-F]{8}$/i.test(raw)) return raw.slice(0, 7);
  return raw;
}

function defaultIconSize(boxSize: number): number {
  if (boxSize <= 36) return 18;
  if (boxSize <= 44) return 20;
  return 24;
}

/**
 * Flat icon. Previously rendered a frosted gradient "chrome" tile (blur + gradient +
 * border); now renders a plain borderless glyph tinted with the accent color so icons
 * look clean and consistent app-wide. The `boxSize` footprint is preserved so existing
 * layouts/spacing stay intact.
 */
export default function GradientIconBox({
  icon,
  colors: colorsProp,
  preset = 'sky',
  size,
  boxSize = 42,
  style,
}: Readonly<GradientIconBoxProps>) {
  const tuple = resolveGradientTuple(colorsProp, preset);
  const accent = accentKey(tuple);
  const iconSize = size ?? defaultIconSize(boxSize);
  const iconCol = bookingContinueIconColor(accent);
  const glyph = icon ?? CONTINUE_CTA_ICON_NAME;

  return (
    <View
      style={[
        { width: boxSize, height: boxSize, alignItems: 'center', justifyContent: 'center' },
        style,
      ]}
      pointerEvents="none"
    >
      <Ionicons name={glyph} size={iconSize} color={iconCol} />
    </View>
  );
}

/** Matches “Your Locations” horizontal cards on the business dashboard. */
export const LOCATION_CARD_ICON_BOX = 36;
export const LOCATION_CARD_ICON_GLYPH = 18;

export type LocationStyleIconVariant = 'card' | 'inline' | 'nav' | 'hero' | 'micro';

const LOCATION_STYLE_DIMS: Record<LocationStyleIconVariant, { boxSize: number; size: number }> = {
  card: { boxSize: LOCATION_CARD_ICON_BOX, size: LOCATION_CARD_ICON_GLYPH },
  inline: { boxSize: 28, size: 14 },
  /** Tab bar */
  nav: { boxSize: 32, size: 18 },
  /** Empty states / hero spots (e.g. “no locations”) */
  hero: { boxSize: 56, size: 28 },
  /** Dense meta rows (location card stats, captions) */
  micro: { boxSize: 22, size: 11 },
};

export type LocationStyleIconBoxProps = Omit<GradientIconBoxProps, 'boxSize' | 'size'> & {
  variant?: LocationStyleIconVariant;
};

export function LocationStyleIconBox({ variant = 'card', ...rest }: Readonly<LocationStyleIconBoxProps>) {
  const d = LOCATION_STYLE_DIMS[variant];
  return <GradientIconBox {...rest} boxSize={d.boxSize} size={d.size} />;
}
