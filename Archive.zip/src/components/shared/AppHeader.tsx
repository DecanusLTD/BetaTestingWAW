import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Platform,
  Dimensions,
  Image,
  Animated,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { LocationStyleIconBox } from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { router } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';

const { width } = Dimensions.get('window');
const HEADER_MARGIN_H = 20;
const HEADER_RADIUS = 24;

// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = 64;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 88;
// Total header heights including padding (for calculating page padding)
// Formula: top padding (12/16) + content height + bottom padding (16/20)
export const HEADER_HEIGHT = 12 + HEADER_CONTENT_HEIGHT + 16; // = 92
export const DASHBOARD_HEADER_HEIGHT = 16 + DASHBOARD_HEADER_CONTENT_HEIGHT + 20; // = 124

// Standard spacing to position content directly beneath the header.
// Account for floating header: safe area + margin (8) + header height + spacing (40)
// Keep default offset aligned with dashboard-style chrome to prevent content
// from peeking under header edges on valeter screens that use the shared constant.
export const HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40;
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40; // Safe area + 8 margin + header + 40 spacing

/** Blur strength: high default so content scrolling under the absolute header reads as frosted glass */
const BLUR_IOS = { rest: 78, scrollMax: 100 };
const BLUR_ANDROID = { rest: 60, scrollMax: 85 };
/** Tint overlays sit above the native blur; keep light so scroll content still reads “blurred” */
const CHROME_TINT_OPACITY = 0.52;

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  dashboardFlat?: boolean;
  dashboardInlineRightAction?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  showOnlineStatus?: boolean;
  onlineStatusAnim?: Animated.Value;
  profilePicture?: string | null;
  notificationCount?: number;
  onNotificationPress?: () => void;
  todayRevenue?: number;
  todayJobs?: number;
  lastJob?: string | null;
  isOnline?: boolean;
  AnimatedCounter?: React.ComponentType<{ value: number; style?: any }>;
  onSubtitlePress?: () => void;
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
}

function DashboardHeaderLeft({
  profilePicture,
  showBack,
  themePrimary,
  onNotificationPress,
  handleBack,
  notificationCount,
}: {
  profilePicture?: string | null;
  showBack: boolean;
  themePrimary: string;
  onNotificationPress?: () => void;
  handleBack: () => void | Promise<void>;
  notificationCount?: number;
}) {
  if (profilePicture) {
    return (
      <TouchableOpacity onPress={onNotificationPress || handleBack} activeOpacity={0.8} style={styles.profilePictureWrapper}>
        <View style={styles.profilePictureContainer}>
          <LinearGradient colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']} style={styles.profileGradient} />
          <Image source={{ uri: profilePicture }} style={styles.profilePicture} resizeMode="cover" />
          <View style={styles.profilePictureBorder} />
          {notificationCount !== undefined && notificationCount > 0 && (
            <View style={styles.headerBellBadge}>
              <Text style={styles.headerBellBadgeText}>{notificationCount > 99 ? '99+' : notificationCount}</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  }
  if (showBack) {
    return (
      <TouchableOpacity onPress={handleBack} style={styles.backButton} activeOpacity={0.7}>
        <LocationStyleIconBox variant="inline" icon="chevron-back" colors={accentToGradient(themePrimary)} />
      </TouchableOpacity>
    );
  }
  return null;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  leftAction,
  rightAction,
  variant = 'default',
  dashboardFlat = false,
  dashboardInlineRightAction = false,
  accountType: _accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating,
  showOnlineStatus: _showOnlineStatus = false,
  onlineStatusAnim,
  profilePicture,
  notificationCount,
  onNotificationPress,
  todayRevenue,
  todayJobs,
  lastJob,
  isOnline,
  AnimatedCounter,
  onSubtitlePress,
  scrollY,
  enableScrollAnimation,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const [blurIntensity, setBlurIntensity] = useState(
    Platform.OS === 'ios' ? BLUR_IOS.rest : BLUR_ANDROID.rest
  );

  const contextTheme = useAccountTheme();
  const theme = contextTheme.theme;

  // Ramp blur further as content scrolls under the fixed header (stronger frosted edge)
  useEffect(() => {
    if (!enableScrollAnimation || !scrollY) return;
    const isIos = Platform.OS === 'ios';
    const rest = isIos ? BLUR_IOS.rest : BLUR_ANDROID.rest;
    const mx = isIos ? BLUR_IOS.scrollMax : BLUR_ANDROID.scrollMax;
    const listenerId = scrollY.addListener(({ value }) => {
      const y = Math.max(0, value);
      if (y <= 0) {
        setBlurIntensity(rest);
      } else if (y >= 96) {
        setBlurIntensity(mx);
      } else {
        const t = y / 96;
        setBlurIntensity(rest + t * (mx - rest));
      }
    });
    return () => scrollY.removeListener(listenerId);
  }, [scrollY, enableScrollAnimation]);

  // Get header background colors (matching nav tab logic)
  const headerBackground = theme.headerBackground || theme.background || ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];
  const accent = theme.primary || colors.navActive;

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
      return;
    }
    if ((router as any).canGoBack?.()) {
      router.back();
    } else {
      router.replace('/');
    }
  };

  const isDashboard = variant === 'dashboard';
  const headerContentHeight = isDashboard ? DASHBOARD_HEADER_CONTENT_HEIGHT : HEADER_CONTENT_HEIGHT;

  const headerWidth = width - HEADER_MARGIN_H * 2;
  // Dashboard variant gets more rounded corners and is full width (not floating)
  const borderRadius = isDashboard ? 28 : HEADER_RADIUS;
  const finalWidth = isDashboard ? width : headerWidth;
  const finalMarginTop = isDashboard ? insets.top : insets.top + 8;
  const finalMarginHorizontal = isDashboard ? 0 : HEADER_MARGIN_H;

  const dashboardLeftProps: React.ComponentProps<typeof DashboardHeaderLeft> = {
    profilePicture: profilePicture ?? null,
    showBack,
    themePrimary: theme.primary,
    handleBack,
  };
  if (onNotificationPress !== undefined) {
    dashboardLeftProps.onNotificationPress = onNotificationPress;
  }
  if (notificationCount !== undefined) {
    dashboardLeftProps.notificationCount = notificationCount;
  }

  return (
    <>
      <StatusBar barStyle={theme.mode === 'light' ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <View style={[styles.wrapper, { marginHorizontal: finalMarginHorizontal }]}>
        <View
          style={[
            styles.container,
            isDashboard && dashboardFlat && styles.containerFlat,
            { 
              width: finalWidth,
              borderRadius: borderRadius,
              marginTop: finalMarginTop,
              marginHorizontal: finalMarginHorizontal,
            },
          ]}
        >
          {isDashboard && dashboardFlat ? (
            <BlurView
              intensity={Platform.OS === 'ios' ? 28 : 42}
              tint={theme.mode === 'light' ? 'light' : 'dark'}
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
          ) : (
            <BlurView
              intensity={blurIntensity}
              tint={theme.mode === 'light' ? 'light' : 'dark'}
              style={StyleSheet.absoluteFill}
            >
              {/* Light tint on top of native blur — keep translucent so scrolled content stays visibly frosted */}
              <View style={[StyleSheet.absoluteFill, { opacity: CHROME_TINT_OPACITY }]} pointerEvents="none">
                <LinearGradient
                  colors={[`${headerBackground[0]}FF`, `${headerBackground[1] || headerBackground[0]}EE`]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
                <LinearGradient
                  colors={[`${accent}28`, 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
              </View>
            </BlurView>
          )}

          {!isDashboard && (
            <>
              {/* Glass stroke with theme border (matching nav tab) */}
              <View style={[styles.glassStroke, { 
                borderColor: theme.glassBorder || 'rgba(255,255,255,0.14)',
                borderRadius: borderRadius,
              }]} />

              {/* Glow line at top (matching nav tab) */}
              <View style={[styles.glowLine, { 
                backgroundColor: `${accent}70`,
                shadowColor: accent,
              }]} />
            </>
          )}

          <View style={[styles.content, { 
            paddingTop: isDashboard ? (dashboardFlat ? 18 : 16) : 12,
            minHeight: headerContentHeight,
            paddingBottom: isDashboard ? (dashboardFlat ? 24 : 20) : 16,
          }]}>
            {isDashboard ? (
              <>
                <View style={[styles.leftSection, { flex: 1, justifyContent: 'flex-start' }]}>
                  <DashboardHeaderLeft {...dashboardLeftProps} />
                </View>

                {dashboardFlat && rightAction && !dashboardInlineRightAction && (
                  <View style={styles.dashboardTopRightAction}>
                    {rightAction}
                  </View>
                )}

                <View
                  pointerEvents="box-none"
                  style={[
                    styles.titleContainer,
                    dashboardInlineRightAction && styles.titleContainerDashboardInline,
                    {
                      flex: 3,
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginTop: dashboardFlat ? 12 : 0,
                    },
                  ]}
                >
                  <Text style={[styles.title, styles.titleDashboard, { color: '#FFFFFF', textAlign: 'center' }]} numberOfLines={1}>
                    {title || businessName || ' '}
                  </Text>
                  {(subtitle || businessAddress) && (
                    <TouchableOpacity onPress={onSubtitlePress} disabled={!onSubtitlePress} activeOpacity={0.7}>
                      <Text style={[styles.subtitle, { color: theme.primary, textAlign: 'center' }]} numberOfLines={1}>
                        {subtitle || businessAddress}
                        {onSubtitlePress ? ' ▾' : ''}
                      </Text>
                    </TouchableOpacity>
                  )}
                  {isOnline !== undefined && (
                    <View style={[styles.statusBadge, isOnline && styles.statusBadgeOnline, { alignSelf: 'center', marginTop: 4 }]}>
                      {onlineStatusAnim && (
                        <Animated.View
                          style={[
                            styles.statusDot,
                            {
                              backgroundColor: isOnline ? '#10B981' : '#EF4444',
                              transform: [{ scale: onlineStatusAnim }],
                              opacity: onlineStatusAnim.interpolate({ inputRange: [1, 1.3], outputRange: [1, 0.4] }),
                            },
                          ]}
                        />
                      )}
                      <Text style={styles.statusText}>{isOnline ? 'Open for bookings' : 'Offline'}</Text>
                    </View>
                  )}
                </View>

                <View style={[styles.rightSection, { flex: 1, justifyContent: 'flex-end' }]}>
                  {points !== undefined && (
                    <View style={styles.pointsBadge}>
                      <Ionicons name="trophy" size={14} color="#FFD700" />
                      <Text style={styles.pointsText}>{points} pts</Text>
                    </View>
                  )}
                  {rightAction && (!dashboardFlat || dashboardInlineRightAction) && (
                    <View style={styles.rightActionContainer}>{rightAction}</View>
                  )}
                </View>
              </>
            ) : (
            <View style={styles.leftSection}>
            {leftAction ?? (showBack ? (
              <TouchableOpacity
                onPress={handleBack}
                style={styles.backButton}
                activeOpacity={0.7}
              >
                <LocationStyleIconBox variant="inline" icon="chevron-back" colors={accentToGradient(theme.primary)} />
              </TouchableOpacity>
            ) : null)}
            <View style={styles.titleContainer}>
              <Text 
                style={[
                  styles.title,
                  isDashboard && styles.titleDashboard,
                  { color: '#FFFFFF' }
                ]} 
                numberOfLines={1} 
                ellipsizeMode="tail"
              >
                {title || ' '}
              </Text>
              {subtitle && (
                <TouchableOpacity onPress={onSubtitlePress} disabled={!onSubtitlePress} activeOpacity={0.7}>
                  <Text 
                    style={[styles.subtitle, { color: theme.primary }]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {subtitle}
                    {onSubtitlePress ? ' ▾' : ''}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
            </View>
            )}

            {!isDashboard && (
            <View style={styles.rightSection}>
            {profilePicture ? (
              <TouchableOpacity
                onPress={onNotificationPress || handleBack}
                activeOpacity={0.8}
                style={styles.profilePictureWrapper}
              >
                <View style={styles.profilePictureContainer}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
                    style={styles.profileGradient}
                  />
                  <Image 
                    source={{ uri: profilePicture }} 
                    style={styles.profilePicture}
                    resizeMode="cover"
                  />
                  <View style={styles.profilePictureBorder} />
                  {notificationCount !== undefined && notificationCount > 0 && (
                    <View style={styles.headerBellBadge}>
                      <Text style={styles.headerBellBadgeText}>
                        {notificationCount > 99 ? '99+' : notificationCount}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ) : null}
            {rightAction && (
              <View style={styles.rightActionContainer}>
                {rightAction}
              </View>
            )}
            </View>
            )}
          </View>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  container: {
    overflow: 'hidden',
    backgroundColor: 'transparent',
    marginHorizontal: HEADER_MARGIN_H,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  containerFlat: {
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
    backgroundColor: 'transparent',
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    zIndex: 200,
    elevation: 12,
    position: 'relative',
  },
  leftSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    minWidth: 0,
    zIndex: 200,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexShrink: 0,
  },
  titleContainer: {
    flex: 1,
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
  },
  titleContainerDashboardInline: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    zIndex: 150,
    elevation: 0,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    includeFontPadding: false,
    lineHeight: 24,
  },
  titleDashboard: {
    fontSize: 28,
    lineHeight: 32,
    fontWeight: '600',
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
    marginTop: 1,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginLeft: 12,
    zIndex: 200,
    elevation: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  businessInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  businessAddress: {
    fontSize: 12,
    fontWeight: '500',
    opacity: 0.9,
    flex: 1,
  },
  businessRating: {
    fontSize: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    gap: 6,
    flexWrap: 'wrap',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },
  statValue: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  statSeparator: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
    marginHorizontal: 2,
  },
  statWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  lastJobText: {
    fontSize: 11,
    fontWeight: '500',
    color: 'rgba(255,255,255,0.7)',
    marginTop: 4,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(107,114,128,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(107,114,128,0.3)',
    alignSelf: 'flex-start',
  },
  statusBadgeOnline: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },
  onlineStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
    position: 'relative',
    overflow: 'visible',
    marginRight: 8,
  },
  onlineStatusDot: {
    position: 'absolute',
    left: 6,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  onlineStatusIcon: {
    marginLeft: 2,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
  },
  profilePictureWrapper: {
    position: 'relative',
    borderRadius: 20,
    overflow: 'visible',
  },
  profilePictureContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  profileGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    opacity: 0.3,
  },
  profilePicture: {
    width: '100%',
    height: '100%',
    borderRadius: 20,
  },
  profilePictureBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    pointerEvents: 'none',
  },
  headerBellBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: 'rgba(0,0,0,0.3)',
    zIndex: 10,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
    elevation: 6,
  },
  headerBellBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  rightActionContainer: {
    // Spacing handled by rightSection gap
  },
  dashboardTopRightAction: {
    position: 'absolute',
    top: 8,
    right: 20,
    zIndex: 250,
    elevation: 20,
  },
});
