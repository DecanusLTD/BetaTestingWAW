import React, { useEffect, useRef, useMemo } from 'react';
import { View, StyleSheet, Animated, Dimensions } from 'react-native';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';
import { useAccountTheme } from './AccountThemeProvider';

const { width, height } = Dimensions.get('window');

interface BubbleBackgroundProps {
  accountType?: AccountType;
  bubbleCount?: number;
}

interface Bubble {
  translateY: Animated.Value;
  translateX: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  size: number;
  leftPosition: number;
  duration: number;
  delay: number;
}

export default function BubbleBackground({
  accountType = 'valeter',
  bubbleCount = 3
}: Readonly<BubbleBackgroundProps>) {
  const accountContext = useAccountTheme();
  const bubbleColor = useMemo(() => {
    const theme = accountContext.theme ?? getAccountTheme(accountType, accountContext.mode);
    return theme.primary || colors.SKY || '#38BDF8';
  }, [accountType, accountContext.theme, accountContext.mode]);
  const amberColor = useMemo(() => {
    const theme = accountContext.theme ?? getAccountTheme(accountType, accountContext.mode);
    return theme.accentAlt || '#E8C547';
  }, [accountType, accountContext.theme, accountContext.mode]);
  const isLight = accountContext.mode === 'light';
  
  const bubbles = useRef<Bubble[]>(
    Array.from({ length: bubbleCount }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value((isLight ? 0.06 : 0.08) + Math.random() * (isLight ? 0.08 : 0.12)),
      scale: new Animated.Value(1),
      size: 25 + Math.random() * 25,
      leftPosition: Math.random() * width,
      duration: 12000 + Math.random() * 8000, // 12-20 seconds (slower = less CPU)
      delay: i * 1500,
    }))
  ).current;

  useEffect(() => {
    const animationRefs: Animated.CompositeAnimation[] = [];
    const timeoutRefs: Array<ReturnType<typeof setTimeout>> = [];

    bubbles.forEach((bubble) => {
      const animateBubble = () => {
        // Simplified: Only vertical floating animation for better performance
        const verticalAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.translateY, {
              toValue: -height * 0.2 - bubble.size,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: 0,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        );

        // Light opacity variation only
        const opacityAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.2,
              duration: bubble.duration * 0.8,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.05,
              duration: bubble.duration * 0.8,
              useNativeDriver: true,
            }),
          ])
        );

        const animation = Animated.parallel([
          verticalAnim,
          opacityAnim,
        ]);
        
        animation.start();
        animationRefs.push(animation);
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);
      
      timeoutRefs.push(timeout);
    });

    return () => {
      // Cleanup all animations
      animationRefs.forEach(anim => anim.stop());
      timeoutRefs.forEach((timeout) => clearTimeout(timeout));
    };
  }, []);

  return (
    <View style={styles.container} pointerEvents="none">
      {bubbles.map((bubble, index) => {
        const bubbleStyle = {
          position: 'absolute' as const,
          left: bubble.leftPosition,
          bottom: -bubble.size,
          width: bubble.size,
          height: bubble.size,
          borderRadius: bubble.size / 2,
          backgroundColor: isLight && index === 1 ? amberColor : bubbleColor,
          transform: [
            { translateY: bubble.translateY },
          ],
          opacity: bubble.opacity,
        };

        return <Animated.View key={`${bubble.leftPosition}-${bubble.delay}`} style={bubbleStyle} />;
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
});


