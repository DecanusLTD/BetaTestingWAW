/**
 * Shared fill for bottom sheets — opaque account theme background (never translucent header wash).
 * Translucent headerBackground over a Modal shows system light chrome; always paint solid first.
 */
import React from 'react';
import { StyleSheet, Platform, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useAccountTheme } from './AccountThemeProvider';
import { colors } from '../../constants/colors';

const FALLBACK: [string, string] = ['#0B1F36', '#071525'];

/** Force a usable opaque stop (hex stays hex; rgba → rgb). */
export function toOpaqueSheetColor(color: string, fallback = FALLBACK[0]): string {
  const c = (color || '').trim();
  if (!c) return fallback;
  if (c.startsWith('#')) {
    if (c.length === 9) return c.slice(0, 7);
    return c;
  }
  const rgba = c.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i);
  if (rgba) return `rgb(${rgba[1]}, ${rgba[2]}, ${rgba[3]})`;
  return c;
}

export function themeSheetGradient(theme: {
  background?: readonly string[];
  navBarBottomDark?: string;
} | null | undefined): [string, string] {
  const top = toOpaqueSheetColor(theme?.background?.[0] ?? FALLBACK[0], FALLBACK[0]);
  const bottom = toOpaqueSheetColor(
    theme?.navBarBottomDark ?? theme?.background?.[1] ?? theme?.background?.[0] ?? FALLBACK[1],
    FALLBACK[1]
  );
  return [top, bottom];
}

export default function BusinessSheetBackground() {
  const { theme, mode } = useAccountTheme();
  const [top, bottom] = themeSheetGradient(theme);
  const accent = theme.primary || colors.navActive;

  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: bottom }]} pointerEvents="none">
      <BlurView
        intensity={Platform.OS === 'ios' ? 36 : 28}
        tint="dark"
        style={StyleSheet.absoluteFill}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[top, bottom]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <LinearGradient
        colors={[`${accent}28`, 'transparent']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
    </View>
  );
}
