import { Ionicons } from '@expo/vector-icons';

/** Valid Ionicons glyph names — shared so `ChromeGlyph` / `GradientIconBox` stay aligned. */
export type IconGlyphName = keyof typeof Ionicons.glyphMap;
