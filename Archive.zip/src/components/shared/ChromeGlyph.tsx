import React from 'react';
import { View, type ViewStyle } from 'react-native';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import type { IconGlyphName } from './iconGlyphTypes';

export type { IconGlyphName };

export type ChromeGlyphProps = {
  name: IconGlyphName;
  size?: number;
  color?: string;
  style?: ViewStyle;
};

/**
 * Drop-in replacement for `<Ionicons />` that draws the same glyph inside Continue-style
 * frosted chrome (`GradientIconBox`). Use as `ChromeGlyph` or `import { ChromeGlyph as Ionicons }`.
 */
export function ChromeGlyph({ name, size = 20, color = '#F9FAFB', style }: ChromeGlyphProps) {
  const boxSize = Math.min(96, Math.max(20, Math.round(size * 1.72)));
  const glyphSize = Math.min(44, Math.max(10, Math.round(size * 0.9)));

  return (
    <View style={[{ alignItems: 'center', justifyContent: 'center' }, style]} pointerEvents="none">
      <GradientIconBox
        icon={name}
        colors={accentToGradient(color)}
        boxSize={boxSize}
        size={glyphSize}
        borderless={boxSize <= 30}
      />
    </View>
  );
}
