import { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { useGlobalTheme } from './GlobalThemeContext';

/** Light mode = muted blue–navy background with dark status bar content; dark mode = navy with light bar. */
export default function StatusBarThemeSync() {
  const { mode } = useGlobalTheme();
  const isLight = mode === 'light';
  return (
    <StatusBar
      style={isLight ? 'dark' : 'light'}
      backgroundColor={isLight ? '#4A7A8E' : '#0A1929'}
    />
  );
}
