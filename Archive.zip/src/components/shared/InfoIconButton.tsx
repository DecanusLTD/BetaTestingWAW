import React from 'react';
import { TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import type { IconGlyphName } from './iconGlyphTypes';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';
import { BOOKING_CONTINUE_RADIUS } from '../../utils/bookingContinueStyle';

const SIZE = 32;
const ICON_SIZE = 20;

export interface InfoIconButtonProps {
  onPress: () => void;
  accentColor: string;
  style?: ViewStyle;
  hitSlop?: number;
  icon?: IconGlyphName;
}

/** Compact info affordance using Archive 4–style Continue chrome (`GradientIconBox`). */
export default function InfoIconButton({
  onPress,
  accentColor,
  style,
  hitSlop = 14,
  icon = 'information-circle',
}: Readonly<InfoIconButtonProps>) {
  return (
    <TouchableOpacity
      onPress={onPress}
      hitSlop={{ top: hitSlop, bottom: hitSlop, left: hitSlop, right: hitSlop }}
      style={[styles.wrap, style]}
      activeOpacity={0.8}
    >
      <GradientIconBox
        icon={icon}
        colors={accentToGradient(accentColor)}
        boxSize={SIZE}
        size={ICON_SIZE}
        borderRadius={Math.min(BOOKING_CONTINUE_RADIUS, 12)}
        elevated
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginLeft: 4,
  },
});
