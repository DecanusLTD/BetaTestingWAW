import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Modal,
  Pressable,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { useAuth } from '../../providers/enhanced-auth-context';
import { useAccountTheme } from './AccountThemeProvider';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import {
  termsAgreementService,
  type TermsAccountType,
  type TermsMode,
  type TermsRecord,
} from '../../services/termsAgreementService';
import AppHeader, { HEADER_CONTENT_OFFSET } from './AppHeader';
import ValeterScreenHeader from '../valeter/ValeterScreenHeader';
import {
  showValeterInsuranceRequiredAlert,
  valeterInsuranceDetailsComplete,
} from '../../utils/valeterInsuranceQuestionnaire';
import { themeBackgroundGradient } from '../../utils/themeGradient';

type Props = {
  accountType: TermsAccountType;
  title: string;
  subtitle: string;
  version: string;
  continuePath: string;
  blockedPath: string;
  onDeclineBlocked?: boolean;
  footerNote?: string;
};

type QuestionnaireAnswers = {
  keepCustomers: 'yes' | 'no' | null;
  keepCalendarAvailability: 'yes' | 'no' | null;
  shareContactDetails: 'yes' | 'no' | null;
  accountMode: TermsMode;
  hasBusinessInsurance: 'yes' | 'no' | null;
  insuranceProvider: string;
  insuranceType: string;
  policyNumber: string;
};

const DEFAULT_ANSWERS: QuestionnaireAnswers = {
  keepCustomers: null,
  keepCalendarAvailability: null,
  shareContactDetails: null,
  accountMode: 'mobile_based',
  hasBusinessInsurance: null,
  insuranceProvider: '',
  insuranceType: '',
  policyNumber: '',
};

const MODE_OPTIONS: Array<{ value: TermsMode; label: string; description: string }> = [
  { value: 'mobile_based', label: 'Mobile based', description: 'You operate from a vehicle or mobile unit.' },
  { value: 'physical', label: 'Physical location', description: 'You operate from a fixed site or wash bay.' },
];

function toQuestionnaireAnswers(details: Record<string, any> | null | undefined): QuestionnaireAnswers {
  return {
    keepCustomers: details?.keepCustomers === 'yes' || details?.keepCustomers === 'no' ? details.keepCustomers : null,
    keepCalendarAvailability:
      details?.keepCalendarAvailability === 'yes' || details?.keepCalendarAvailability === 'no'
        ? details.keepCalendarAvailability
        : null,
    shareContactDetails:
      details?.shareContactDetails === 'yes' || details?.shareContactDetails === 'no'
        ? details.shareContactDetails
        : null,
    accountMode: details?.account_mode === 'physical' ? 'physical' : 'mobile_based',
    hasBusinessInsurance:
      details?.hasBusinessInsurance === 'yes' || details?.hasBusinessInsurance === 'no'
        ? details.hasBusinessInsurance
        : null,
    insuranceProvider: typeof details?.insuranceProvider === 'string' ? details.insuranceProvider : '',
    insuranceType: typeof details?.insuranceType === 'string' ? details.insuranceType : '',
    policyNumber: typeof details?.policyNumber === 'string' ? details.policyNumber : '',
  };
}

export default function TermsAgreementScreen({
  accountType,
  title,
  subtitle,
  version,
  continuePath,
  blockedPath,
  onDeclineBlocked = true,
  footerNote,
}: Readonly<Props>) {
  const { user } = useAuth();
  const { theme, mode } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const isLight = mode === 'light';

  const primary = theme.primary ?? (accountType === 'valeter' ? '#38BDF8' : '#7EB8D4');
  const bg = themeBackgroundGradient(theme.background, ['#0A1929', '#123B67']);
  const cardBg = isLight ? 'rgba(255,255,255,0.1)' : 'rgba(4,16,30,0.55)';
  const cardBorder = isLight ? 'rgba(30,41,59,0.12)' : 'rgba(158,216,255,0.18)';
  const textPrimary = theme.textPrimary ?? '#FFFFFF';
  const textSecondary = theme.textSecondary ?? 'rgba(191,219,254,0.9)';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [record, setRecord] = useState<TermsRecord | null>(null);
  const [modePickerVisible, setModePickerVisible] = useState(false);
  const [answers, setAnswers] = useState<QuestionnaireAnswers>(DEFAULT_ANSWERS);
  const autoContinuedRef = useRef(false);

  useEffect(() => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    let cancelled = false;
    (async () => {
      try {
        const next = await termsAgreementService.load(accountType, user.id);
        if (cancelled) return;
        setRecord(next);
        setAnswers(toQuestionnaireAnswers(next.details));
      } catch (e) {
        if (!cancelled) {
          console.warn('[TermsAgreementScreen] load error:', e);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [accountType, user?.id]);

  useEffect(() => {
    if (loading || saving) return;
    if (record?.status !== 'accepted') {
      autoContinuedRef.current = false;
      return;
    }
    if (autoContinuedRef.current) return;
    autoContinuedRef.current = true;
    router.replace(continuePath);
  }, [continuePath, loading, record?.status, saving]);

  const statusLabel = useMemo(() => {
    if (record?.status === 'accepted') return 'Completed';
    if (record?.status === 'declined') return 'Declined';
    return 'Pending';
  }, [record?.status]);

  const questionnaireCanSubmit = () => {
    const a = answers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    const insuranceDetailsComplete = valeterInsuranceDetailsComplete(
      a.hasBusinessInsurance,
      a.insuranceProvider,
      a.insuranceType,
      a.policyNumber
    );
    const insuranceChoiceComplete = a.hasBusinessInsurance !== null;
    return (
      yesNoComplete &&
      a.accountMode !== null &&
      insuranceChoiceComplete &&
      insuranceDetailsComplete
    );
  };

  const questionnaireCanAttemptContinue = () => {
    const a = answers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    if (!yesNoComplete || a.accountMode === null || a.hasBusinessInsurance === null) return false;
    if (a.hasBusinessInsurance === 'no') return true;
    return questionnaireCanSubmit();
  };

  const saveAndContinue = async () => {
    if (answers.hasBusinessInsurance !== 'yes') {
      await hapticFeedback('medium');
      showValeterInsuranceRequiredAlert();
      return;
    }
    if (!user?.id || saving || !questionnaireCanSubmit()) return;
    try {
      setSaving(true);
      await hapticFeedback('medium');
      await termsAgreementService.saveQuestionnaire(accountType, user.id, version, {
        questionnaire_type: 'account_setup_questionnaire',
        account_mode: answers.accountMode,
        keepCustomers: answers.keepCustomers,
        keepCalendarAvailability: answers.keepCalendarAvailability,
        shareContactDetails: answers.shareContactDetails,
        hasBusinessInsurance: answers.hasBusinessInsurance,
        insuranceProvider: answers.insuranceProvider.trim(),
        insuranceType: answers.insuranceType.trim(),
        policyNumber: answers.policyNumber.trim(),
      });
      router.replace(continuePath);
    } catch (error: any) {
      console.warn('[TermsAgreementScreen] save error:', error);
    } finally {
      setSaving(false);
    }
  };

  const decline = async () => {
    if (!user?.id || saving) return;
    try {
      setSaving(true);
      await hapticFeedback('light');
      await termsAgreementService.decline(accountType, user.id, version, {
        questionnaire_type: 'account_setup_questionnaire',
        account_mode: answers.accountMode,
      });
      if (onDeclineBlocked) {
        router.replace(blockedPath);
      }
    } catch (error: any) {
      console.warn('[TermsAgreementScreen] decline error:', error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <LinearGradient colors={bg} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingWrap}>
          <ActivityIndicator color={primary} />
        </View>
      </SafeAreaView>
    );
  }

  const selectedMode = MODE_OPTIONS.find((opt) => opt.value === answers.accountMode);

  return (
    <SafeAreaView style={styles.safe} edges={[]}>
      <LinearGradient colors={bg} style={StyleSheet.absoluteFill} />

      {accountType === 'valeter' ? (
        <ValeterScreenHeader title={title} subtitle={subtitle} />
      ) : (
        <AppHeader title={title} subtitle={subtitle} accountType="business" fullWidth flushTop />
      )}

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 24 + insets.bottom }]}
      >
        <View style={styles.headerCopy}>
          <View style={styles.headerBadgesRow}>
            <View style={[styles.badge, { borderColor: `${primary}44`, backgroundColor: `${primary}14` }]}>
              <Ionicons name="document-text-outline" size={16} color={primary} />
              <Text style={[styles.badgeText, { color: primary }]}>
                {accountType === 'valeter' ? 'Valeter questionnaire' : 'Business questionnaire'}
              </Text>
            </View>
            <View
              style={[
                styles.badge,
                { borderColor: 'rgba(255,255,255,0.16)', backgroundColor: 'rgba(255,255,255,0.06)' },
              ]}
            >
              <Text style={[styles.badgeText, { color: textSecondary }]}>{statusLabel}</Text>
            </View>
          </View>
          <Text style={[styles.versionLine, { color: textSecondary }]}>Current version {version}</Text>
        </View>

        <View style={[styles.card, { borderColor: cardBorder, backgroundColor: cardBg }]}>
          <Text style={[styles.sectionTitle, { color: textPrimary }]}>How this account works</Text>

          <View style={styles.questionBlock}>
            <Text style={[styles.questionText, { color: textPrimary }]}>
              Do you agree to keep all customers you gain from Wish a Washer on the Wish a Washer app?
            </Text>
            <View style={styles.yesNoRow}>
              {(['yes', 'no'] as const).map((choice) => (
                <TouchableOpacity
                  key={choice}
                  onPress={() => setAnswers((prev) => ({ ...prev, keepCustomers: choice }))}
                  style={[
                    styles.choiceButton,
                    answers.keepCustomers === choice && { borderColor: `${primary}66`, backgroundColor: `${primary}18` },
                  ]}
                >
                  <Text
                    style={[
                      styles.choiceButtonText,
                      answers.keepCustomers === choice && { color: textPrimary },
                    ]}
                  >
                    {choice === 'yes' ? 'Yes' : 'No'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.questionBlock}>
            <Text style={[styles.questionText, { color: textPrimary }]}>
              It is your responsibility to keep your calendar availability up to date. Do you accept this responsibility?
            </Text>
            <View style={styles.yesNoRow}>
              {(['yes', 'no'] as const).map((choice) => (
                <TouchableOpacity
                  key={choice}
                  onPress={() => setAnswers((prev) => ({ ...prev, keepCalendarAvailability: choice }))}
                  style={[
                    styles.choiceButton,
                    answers.keepCalendarAvailability === choice && { borderColor: `${primary}66`, backgroundColor: `${primary}18` },
                  ]}
                >
                  <Text
                    style={[
                      styles.choiceButtonText,
                      answers.keepCalendarAvailability === choice && { color: textPrimary },
                    ]}
                  >
                    {choice === 'yes' ? 'Yes' : 'No'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.questionBlock}>
            <Text style={[styles.questionText, { color: textPrimary }]}>
              Do you agree to not share or promote your personal contact details to customers on the Wish a Washer app?
            </Text>
            <View style={styles.yesNoRow}>
              {(['yes', 'no'] as const).map((choice) => (
                <TouchableOpacity
                  key={choice}
                  onPress={() => setAnswers((prev) => ({ ...prev, shareContactDetails: choice }))}
                  style={[
                    styles.choiceButton,
                    answers.shareContactDetails === choice && { borderColor: `${primary}66`, backgroundColor: `${primary}18` },
                  ]}
                >
                  <Text
                    style={[
                      styles.choiceButtonText,
                      answers.shareContactDetails === choice && { color: textPrimary },
                    ]}
                  >
                    {choice === 'yes' ? 'Yes' : 'No'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.questionBlock}>
            <Text style={[styles.questionText, { color: textPrimary }]}>How does this account operate? *</Text>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setModePickerVisible(true);
              }}
              style={[styles.selectButton, { borderColor: `${primary}33`, backgroundColor: 'rgba(255,255,255,0.05)' }]}
              activeOpacity={0.9}
            >
              <View style={{ flex: 1 }}>
                <Text style={[styles.selectButtonText, { color: textPrimary }]}>{selectedMode?.label}</Text>
                <Text style={[styles.helpText, { color: textSecondary, marginTop: 4 }]}>{selectedMode?.description}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={textSecondary} />
            </TouchableOpacity>
            <Text style={[styles.helpText, { color: textSecondary }]}>
              This keeps the same questionnaire flow for both mobile-based and physical accounts.
            </Text>
          </View>

          <View style={styles.questionBlock}>
            <Text style={[styles.questionText, { color: textPrimary }]}>Do you have business insurance? *</Text>
            <View style={styles.yesNoRow}>
              {(['yes', 'no'] as const).map((choice) => (
                <TouchableOpacity
                  key={choice}
                  onPress={() => setAnswers((prev) => ({ ...prev, hasBusinessInsurance: choice }))}
                  style={[
                    styles.choiceButton,
                    answers.hasBusinessInsurance === choice && { borderColor: `${primary}66`, backgroundColor: `${primary}18` },
                  ]}
                >
                  <Text
                    style={[
                      styles.choiceButtonText,
                      answers.hasBusinessInsurance === choice && { color: textPrimary },
                    ]}
                  >
                    {choice === 'yes' ? 'Yes' : 'No'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {answers.hasBusinessInsurance === 'yes' ? (
            <>
              <View style={styles.questionBlock}>
                <Text style={[styles.questionText, { color: textPrimary }]}>Who is your insurance provider? *</Text>
                <TextInput
                  value={answers.insuranceProvider}
                  onChangeText={(value) => setAnswers((prev) => ({ ...prev, insuranceProvider: value }))}
                  placeholder="Insurance Provider"
                  placeholderTextColor="rgba(10,25,41,0.38)"
                  style={styles.textInput}
                />
              </View>

              <View style={styles.questionBlock}>
                <Text style={[styles.questionText, { color: textPrimary }]}>What type of insurance do you have? *</Text>
                <TextInput
                  value={answers.insuranceType}
                  onChangeText={(value) => setAnswers((prev) => ({ ...prev, insuranceType: value }))}
                  placeholder="Insurance Type"
                  placeholderTextColor="rgba(10,25,41,0.38)"
                  style={styles.textInput}
                />
              </View>

              <View style={styles.questionBlock}>
                <Text style={[styles.questionText, { color: textPrimary }]}>What is your insurance policy number? *</Text>
                <TextInput
                  value={answers.policyNumber}
                  onChangeText={(value) => setAnswers((prev) => ({ ...prev, policyNumber: value }))}
                  placeholder="Policy Number"
                  placeholderTextColor="rgba(10,25,41,0.38)"
                  style={styles.textInput}
                />
              </View>
            </>
          ) : null}
        </View>

        {footerNote ? (
          <View style={[styles.notice, { borderColor: `${primary}2E`, backgroundColor: `${primary}12` }]}>
            <Ionicons name="shield-checkmark-outline" size={18} color={primary} />
            <Text style={[styles.noticeText, { color: textSecondary }]}>{footerNote}</Text>
          </View>
        ) : null}
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: 16 + insets.bottom }]}>
        <TouchableOpacity style={[styles.secondaryBtn, { borderColor: `${primary}40` }]} onPress={decline} disabled={saving}>
          {saving ? (
            <ActivityIndicator color={textPrimary} />
          ) : (
            <Text style={[styles.secondaryBtnText, { color: textPrimary }]}>Decline</Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.primaryBtn, { backgroundColor: primary }, !questionnaireCanAttemptContinue() && styles.primaryBtnDisabled]}
          onPress={saveAndContinue}
          disabled={saving || !questionnaireCanAttemptContinue()}
        >
          {saving ? <ActivityIndicator color="#0A1929" /> : <Text style={styles.primaryBtnText}>Save & Continue</Text>}
        </TouchableOpacity>
      </View>

      <Modal transparent visible={modePickerVisible} animationType="fade" onRequestClose={() => setModePickerVisible(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setModePickerVisible(false)}>
          <View style={[styles.modalCard, { borderColor: `${primary}40` }]}>
            <Text style={[styles.modalTitle, { color: textPrimary }]}>Choose account type</Text>
            {MODE_OPTIONS.map((opt) => {
              const selected = opt.value === answers.accountMode;
              return (
                <TouchableOpacity
                  key={opt.value}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setAnswers((prev) => ({ ...prev, accountMode: opt.value }));
                    setModePickerVisible(false);
                  }}
                  style={[
                    styles.modalOption,
                    selected && { borderColor: `${primary}55`, backgroundColor: `${primary}14` },
                  ]}
                  activeOpacity={0.85}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.modalOptionLabel, { color: textPrimary }]}>{opt.label}</Text>
                    <Text style={[styles.modalOptionSub, { color: textSecondary }]}>{opt.description}</Text>
                  </View>
                  {selected ? <Ionicons name="checkmark-circle" size={20} color={primary} /> : null}
                </TouchableOpacity>
              );
            })}
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { paddingHorizontal: 20, paddingTop: 16, gap: 16 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  headerCopy: {
    gap: 12,
    paddingTop: 4,
  },
  headerBadgesRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
  badgeText: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  headerTitle: { fontSize: 30, lineHeight: 36, fontWeight: '800' },
  headerSubtitle: { fontSize: 15, lineHeight: 22 },
  versionLine: { fontSize: 12, fontWeight: '600', letterSpacing: 0.1 },
  card: { borderWidth: 1, borderRadius: 22, padding: 20, gap: 16 },
  sectionTitle: { fontSize: 18, lineHeight: 24, fontWeight: '800' },
  questionBlock: { gap: 12 },
  questionText: { fontSize: 14, lineHeight: 20, fontWeight: '600' },
  yesNoRow: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  choiceButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    minWidth: 74,
    alignItems: 'center',
  },
  choiceButtonText: { fontSize: 14, fontWeight: '800', color: 'rgba(255,255,255,0.75)' },
  selectButton: {
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  selectButtonText: { fontSize: 16, fontWeight: '800' },
  helpText: { fontSize: 12, lineHeight: 18 },
  textInput: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    color: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 14,
  },
  notice: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 14,
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
  },
  noticeText: { flex: 1, fontSize: 12, lineHeight: 18 },
  footer: { paddingHorizontal: 20, gap: 10 },
  primaryBtn: { borderRadius: 16, paddingVertical: 14, alignItems: 'center' },
  primaryBtnDisabled: { opacity: 0.45 },
  primaryBtnText: { color: '#0A1929', fontSize: 15, fontWeight: '800' },
  secondaryBtn: {
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryBtnText: { fontSize: 15, fontWeight: '800' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalCard: {
    margin: 16,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.96)',
    padding: 18,
    gap: 12,
  },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 4 },
  modalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    padding: 14,
  },
  modalOptionLabel: { fontSize: 15, fontWeight: '800' },
  modalOptionSub: { fontSize: 12, lineHeight: 17, marginTop: 3 },
});
