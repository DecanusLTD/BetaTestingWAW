import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Image, Easing, Dimensions } from 'react-native';

const LOGO = require('../../../assets/icon.png');

const { width: SCREEN_W } = Dimensions.get('window');

export type DefaultLoadingSkeletonProps = Readonly<{
  message?: string;
  /** More rows / taller block */
  variant?: 'compact' | 'default' | 'rich';
}>;

/**
 * Standard in-layout loading state: small pulsing app mark + shimmer bars.
 * Use instead of ad-hoc placeholders or embedded full splash blocks.
 */
export default function DefaultLoadingSkeleton({
  message = 'Loading…',
  variant = 'default',
}: DefaultLoadingSkeletonProps) {
  const pulse = useRef(new Animated.Value(1)).current;
  const shimmer = useRef(new Animated.Value(0)).current;

  const rowCount = variant === 'compact' ? 3 : variant === 'rich' ? 8 : 5;

  useEffect(() => {
    const p = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1.08,
          duration: 700,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 1,
          duration: 700,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    );
    p.start();
    const s = Animated.loop(
      Animated.timing(shimmer, {
        toValue: 1,
        duration: 1400,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    s.start();
    return () => {
      p.stop();
      s.stop();
    };
  }, [pulse, shimmer]);

  const translateX = shimmer.interpolate({
    inputRange: [0, 1],
    outputRange: [-SCREEN_W * 0.35, SCREEN_W * 0.35],
  });

  const shimmerOpacity = shimmer.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [0.35, 0.85, 0.35],
  });

  return (
    <View style={styles.root} accessibilityRole="progressbar" accessibilityLabel={message}>
      <Animated.View style={[styles.markWrap, { transform: [{ scale: pulse }] }]}>
        <Image source={LOGO} style={styles.mark} resizeMode="cover" accessibilityLabel="" />
      </Animated.View>
      <View style={styles.rows}>
        {Array.from({ length: rowCount }).map((_, i) => {
          const w = i === 0 ? '72%' : i === rowCount - 1 ? '45%' : '100%';
          return (
            <View key={i} style={[styles.rowTrack, { width: w }]}>
              <Animated.View
                style={[
                  styles.rowShimmer,
                  {
                    opacity: shimmerOpacity,
                    transform: [{ translateX }],
                  },
                ]}
              />
            </View>
          );
        })}
      </View>
      {message ? (
        <Text style={styles.caption} numberOfLines={2}>
          {message}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    width: '100%',
    minHeight: 160,
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  markWrap: {
    width: 52,
    height: 52,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 20,
    borderWidth: 1.5,
    borderColor: 'rgba(125,211,252,0.35)',
    backgroundColor: 'rgba(15,23,42,0.5)',
  },
  mark: {
    width: 52,
    height: 52,
    borderRadius: 12,
  },
  rows: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
    gap: 12,
  },
  rowTrack: {
    height: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(148,163,184,0.12)',
    overflow: 'hidden',
  },
  rowShimmer: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 8,
    backgroundColor: 'rgba(125,211,252,0.35)',
    width: '42%',
  },
  caption: {
    marginTop: 18,
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(248,250,252,0.65)',
    textAlign: 'center',
  },
});
