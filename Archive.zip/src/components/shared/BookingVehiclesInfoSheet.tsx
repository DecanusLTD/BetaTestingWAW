import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  Image,
  Dimensions,
  FlatList,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from './ChromeGlyph';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { useAccountTheme } from './AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../constants/accountThemes';
import { resolveCustomerProfilePictureUrl } from '../../utils/customerProfiles';

export type BookingVehicleGalleryItem = {
  id: string;
  make?: string | null;
  model?: string | null;
  registration?: string | null;
  colour?: string | null;
  photo?: string | null;
};

const { width: SCREEN_W } = Dimensions.get('window');
const CARD_W = Math.min(SCREEN_W - 48, 360);

function titleForVehicle(v: BookingVehicleGalleryItem): string {
  const name = [v.make, v.model].filter(Boolean).join(' ').trim();
  return name || v.registration || 'Vehicle';
}

export default function BookingVehiclesInfoSheet({
  visible,
  onClose,
  accent,
  vehicles,
}: Readonly<{
  visible: boolean;
  onClose: () => void;
  accent: string;
  vehicles: BookingVehicleGalleryItem[];
}>) {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const textMain = theme.textPrimary ?? '#F8FAFC';
  const textMuted = theme.textSecondary ?? 'rgba(248,250,252,0.7)';
  const panel = isLight ? lightMistPanel : 'rgba(15,23,42,0.96)';
  const elevated = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const list = useMemo(() => (vehicles.length > 0 ? vehicles : []), [vehicles]);
  const [index, setIndex] = useState(0);
  const listRef = useRef<FlatList<BookingVehicleGalleryItem>>(null);

  useEffect(() => {
    if (visible) setIndex(0);
  }, [visible]);

  if (!visible) return null;

  const onScrollEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = e.nativeEvent.contentOffset.x;
    const next = Math.round(x / (CARD_W + 12));
    if (next !== index) {
      setIndex(Math.max(0, Math.min(list.length - 1, next)));
      void hapticFeedback('light');
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable
          style={[
            styles.sheet,
            {
              backgroundColor: panel,
              borderColor: `${accent}40`,
              paddingBottom: Math.max(18, insets.bottom + 12),
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.handleRow}>
            <View style={[styles.handle, { backgroundColor: `${accent}55` }]} />
          </View>

          <View style={styles.header}>
            <View style={[styles.headerIcon, { backgroundColor: `${accent}22`, borderColor: `${accent}45` }]}>
              <Ionicons name="car-sport" size={18} color={accent} />
            </View>
            <View style={styles.headerCopy}>
              <Text style={[styles.headerTitle, { color: textMain }]}>Vehicle info</Text>
              <Text style={[styles.headerSub, { color: textMuted }]}>
                {list.length <= 1 ? 'Swipe isn’t needed — one vehicle on this job' : `Swipe · ${list.length} vehicles on this job`}
              </Text>
            </View>
            <Pressable
              onPress={onClose}
              hitSlop={12}
              style={[styles.closeBtn, { backgroundColor: elevated }]}
              accessibilityLabel="Close"
            >
              <Ionicons name="close" size={18} color={textMuted} />
            </Pressable>
          </View>

          {list.length === 0 ? (
            <View style={[styles.empty, { backgroundColor: elevated }]}>
              <Ionicons name="car-outline" size={36} color={accent} />
              <Text style={[styles.emptyText, { color: textMuted }]}>No vehicle details yet</Text>
            </View>
          ) : (
            <>
              <FlatList
                ref={listRef}
                data={list}
                keyExtractor={(item) => item.id}
                horizontal
                pagingEnabled={false}
                decelerationRate="fast"
                snapToInterval={CARD_W + 12}
                snapToAlignment="start"
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.galleryContent}
                onMomentumScrollEnd={onScrollEnd}
                renderItem={({ item, index: i }) => {
                  const photo =
                    resolveCustomerProfilePictureUrl(item.photo) || item.photo || null;
                  const active = i === index;
                  return (
                    <View
                      style={[
                        styles.vehicleCard,
                        {
                          width: CARD_W,
                          borderColor: active ? `${accent}70` : `${accent}28`,
                          backgroundColor: elevated,
                        },
                      ]}
                    >
                      <View style={styles.photoWrap}>
                        {photo ? (
                          <Image source={{ uri: photo }} style={styles.photo} resizeMode="cover" />
                        ) : (
                          <LinearGradient
                            colors={[`${accent}55`, `${accent}18`, 'rgba(10,25,41,0.9)']}
                            style={styles.photoFallback}
                          >
                            <Ionicons name="car-sport" size={54} color="#F8FAFC" />
                            <Text style={styles.photoFallbackText}>No photo</Text>
                          </LinearGradient>
                        )}
                        <View style={[styles.badge, { backgroundColor: accent }]}>
                          <Text style={styles.badgeText}>
                            {i + 1}/{list.length}
                          </Text>
                        </View>
                      </View>
                      <Text style={[styles.vehicleTitle, { color: textMain }]} numberOfLines={2}>
                        {titleForVehicle(item)}
                      </Text>
                      {item.registration ? (
                        <Text style={[styles.vehicleReg, { color: accent }]}>{item.registration}</Text>
                      ) : null}
                      {item.colour ? (
                        <Text style={[styles.vehicleMeta, { color: textMuted }]}>{item.colour}</Text>
                      ) : null}
                    </View>
                  );
                }}
              />

              {list.length > 1 ? (
                <View style={styles.dots}>
                  {list.map((v, i) => (
                    <Pressable
                      key={v.id}
                      onPress={() => {
                        listRef.current?.scrollToOffset({ offset: i * (CARD_W + 12), animated: true });
                        setIndex(i);
                        void hapticFeedback('light');
                      }}
                      style={[
                        styles.dot,
                        {
                          backgroundColor: i === index ? accent : `${accent}35`,
                          width: i === index ? 18 : 8,
                        },
                      ]}
                    />
                  ))}
                </View>
              ) : null}
            </>
          )}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(2, 10, 22, 0.72)',
    justifyContent: 'flex-end',
  },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    paddingTop: 8,
    maxHeight: '88%',
  },
  handleRow: { alignItems: 'center', paddingBottom: 8 },
  handle: { width: 42, height: 4, borderRadius: 2 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 18,
    marginBottom: 14,
  },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCopy: { flex: 1, minWidth: 0 },
  headerTitle: { fontSize: 20, fontWeight: '900', letterSpacing: -0.3 },
  headerSub: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  closeBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  galleryContent: {
    paddingHorizontal: 18,
    gap: 12,
    paddingBottom: 8,
  },
  vehicleCard: {
    borderRadius: 22,
    borderWidth: 1.5,
    overflow: 'hidden',
    paddingBottom: 14,
  },
  photoWrap: {
    width: '100%',
    height: 210,
    backgroundColor: 'rgba(0,0,0,0.25)',
  },
  photo: { width: '100%', height: '100%' },
  photoFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  photoFallbackText: {
    color: 'rgba(248,250,252,0.85)',
    fontSize: 13,
    fontWeight: '700',
  },
  badge: {
    position: 'absolute',
    top: 12,
    right: 12,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  badgeText: { color: '#0A1929', fontSize: 12, fontWeight: '900' },
  vehicleTitle: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
    marginTop: 14,
    paddingHorizontal: 14,
  },
  vehicleReg: {
    fontSize: 15,
    fontWeight: '800',
    marginTop: 4,
    paddingHorizontal: 14,
  },
  vehicleMeta: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 4,
    paddingHorizontal: 14,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    paddingTop: 10,
    paddingBottom: 4,
  },
  dot: {
    height: 8,
    borderRadius: 999,
  },
  empty: {
    marginHorizontal: 18,
    borderRadius: 18,
    minHeight: 160,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginBottom: 8,
  },
  emptyText: { fontSize: 14, fontWeight: '700' },
});
