import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Modal,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../shared/ChromeGlyph';
import { useAuth } from '../../providers/enhanced-auth-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import GlassCard from '../booking/GlassCard';
import GradientIconBox from '../shared/GradientIconBox';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';

type Props = {
  visible: boolean;
  onClose: () => void;
  primaryColor: string;
  primaryAlt?: string;
};

export default function InviteWasherSheet({ visible, onClose, primaryColor, primaryAlt }: Props) {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('valeter');
  const [sending, setSending] = useState(false);

  const roles = [
    { id: 'valeter', label: 'Car Care Pro', icon: 'person-outline' as const },
    { id: 'senior_valeter', label: 'Senior Car Care Pro', icon: 'star-outline' as const },
    { id: 'location_manager', label: 'Location Manager', icon: 'business-outline' as const },
    { id: 'staff', label: 'Staff', icon: 'people-outline' as const },
  ];

  const handleSendInvite = async () => {
    if (!email.trim()) {
      Alert.alert('Error', 'Please enter an email address');
      return;
    }
    if (!user?.id) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }
    try {
      setSending(true);
      await hapticFeedback('medium');
      Alert.alert('Invite sent', `Invitation sent to ${email}`, [
        {
          text: 'OK',
          onPress: () => {
            setEmail('');
            setRole('valeter');
            onClose();
          },
        },
      ]);
    } catch (error: any) {
      console.error('Error sending invite:', error);
      Alert.alert('Error', error.message || 'Failed to send invite');
    } finally {
      setSending(false);
    }
  };

  const gradEnd = primaryAlt || SKY;

  return (
    <Modal visible={visible} animationType="slide" transparent statusBarTranslucent onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.modalRoot}
      >
        <Pressable style={styles.backdrop} onPress={onClose} />
        <View style={[styles.sheet, { paddingBottom: Math.max(20, insets.bottom + 12) }]}>
          <BusinessSheetBackground />
          <View style={styles.handleWrap}>
            <View style={[styles.handle, { backgroundColor: `${primaryColor}99` }]} />
          </View>
          <Text style={styles.sheetTitle}>Invite a Car Care Pro</Text>
          <Text style={styles.sheetSubtitle}>They’ll receive a link to join your roster.</Text>

          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            <GlassCard style={styles.introCard} accountType="business">
              <View style={styles.introRow}>
                <GradientIconBox icon="person-add" preset="sky" boxSize={40} size={20} />
                <View style={styles.introTextWrap}>
                  <Text style={styles.introTitle}>Add by email</Text>
                  <Text style={styles.introSubtitle}>Role and location can be refined after they accept.</Text>
                </View>
              </View>
            </GlassCard>

            <Text style={styles.sectionLabel}>EMAIL</Text>
            <GlassCard style={styles.inputCard} accountType="business">
              <View style={styles.inputRow}>
                <GradientIconBox icon="mail-open-outline" preset="sky" boxSize={32} size={16} />
                <TextInput
                  style={styles.textInput}
                  placeholder="Email address"
                  placeholderTextColor="rgba(249,250,251,0.45)"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
            </GlassCard>

            <Text style={styles.sectionLabel}>ROLE</Text>
            <View style={styles.rolesWrap}>
              {roles.map((roleOption) => (
                <TouchableOpacity
                  key={roleOption.id}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setRole(roleOption.id);
                  }}
                  activeOpacity={0.85}
                  style={[
                    styles.roleChip,
                    role === roleOption.id && { borderColor: `${primaryColor}55`, backgroundColor: `${primaryColor}18` },
                  ]}
                >
                  <Ionicons
                    name={roleOption.icon}
                    size={16}
                    color={role === roleOption.id ? primaryColor : MUTED_TEXT}
                  />
                  <Text style={[styles.roleChipText, role === roleOption.id && { color: LIGHT_TEXT, fontWeight: '800' }]}>
                    {roleOption.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity
              onPress={handleSendInvite}
              style={styles.sendButton}
              disabled={sending || !email.trim()}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={email.trim() ? [primaryColor, gradEnd] : ['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)']}
                style={styles.sendButtonGradient}
              >
                {sending ? (
                  <ActivityIndicator size="small" color={email.trim() ? LIGHT_TEXT : MUTED_TEXT} />
                ) : (
                  <>
                    <Ionicons name="send" size={16} color={email.trim() ? LIGHT_TEXT : MUTED_TEXT} />
                    <Text style={[styles.sendButtonText, !email.trim() && styles.sendButtonTextDisabled]}>
                      Send invitation
                    </Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalRoot: { flex: 1, justifyContent: 'flex-end' },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,13,20,0.72)',
  },
  sheet: {
    position: 'relative' as const,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.28)',
    paddingHorizontal: 20,
    paddingTop: 0,
    maxHeight: '88%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  handleWrap: { alignItems: 'center', marginTop: 8, marginBottom: 8 },
  handle: { width: 36, height: 4, borderRadius: 2 },
  sheetTitle: { color: LIGHT_TEXT, fontSize: 18, fontWeight: '800', letterSpacing: -0.4 },
  sheetSubtitle: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    marginBottom: 10,
    marginTop: 2,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  introCard: { padding: 12, marginBottom: 10 },
  introRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  introTextWrap: { flex: 1, minWidth: 0 },
  introTitle: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '800', marginBottom: 2 },
  introSubtitle: { color: MUTED_TEXT, fontSize: 11 },
  sectionLabel: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  inputCard: { paddingVertical: 10, paddingHorizontal: 12, marginBottom: 10 },
  inputRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  textInput: { flex: 1, color: LIGHT_TEXT, fontSize: 15, paddingVertical: 4 },
  rolesWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 12 },
  roleChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  roleChipText: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600' },
  sendButton: { borderRadius: 12, overflow: 'hidden', marginBottom: 8 },
  sendButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
  },
  sendButtonText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '800' },
  sendButtonTextDisabled: { color: MUTED_TEXT },
});
