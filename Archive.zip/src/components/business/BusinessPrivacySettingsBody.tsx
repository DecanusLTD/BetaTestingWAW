import React from 'react';
import { View } from 'react-native';

/**
 * Optional extract target for business privacy UI.
 * The live implementation is inlined in `app/business/profile.tsx` (Privacy & security tab).
 * This module exists so Metro can resolve the path if an older import is still present.
 */
export default function BusinessPrivacySettingsBody() {
  return <View />;
}
