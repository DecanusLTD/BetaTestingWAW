import React, { useRef, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity, Animated, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import {
  PREMIUM_CARD,
  CARD_GAP,
  BUTTON_PRESS_SCALE,
  BUTTON_ANIM_DURATION,
  MOTION,
} from '../../constants/premiumTokens';

interface PremiumCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  useGradient?: boolean;
  /** Optional: stagger delay for entrance (ms). */
  entranceDelay?: number;
}

export default function PremiumCard({
  children,
  onPress,
  style,
  useGradient = true,
  entranceDelay = 0,
}: PremiumCardProps) {
  const { theme } = useAccountTheme();
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const opacityAnim = useRef(new Animated.Value(entranceDelay ? 0 : 1)).current;
  const translateY = useRef(new Animated.Value(entranceDelay ? 12 : 0)).current;

  useEffect(() => {
    if (entranceDelay === 0) return;
    const timer = setTimeout(() => {
      Animated.parallel([
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: MOTION.entranceMs,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, {
          toValue: 0,
          duration: MOTION.entranceMs,
          useNativeDriver: true,
        }),
      ]).start();
    }, entranceDelay);
    return () => clearTimeout(timer);
  }, [entranceDelay, opacityAnim, translateY]);

  const gradientColors = (theme.cardBackgroundGradient ?? [
    'rgba(255,255,255,0.1)',
    'rgba(255,255,255,0.04)',
  ]) as [string, string];

  const handlePressIn = () => {
    if (!onPress) return;
    Animated.timing(scaleAnim, {
      toValue: BUTTON_PRESS_SCALE,
      duration: BUTTON_ANIM_DURATION,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleAnim, {
      toValue: 1,
      duration: BUTTON_ANIM_DURATION,
      useNativeDriver: true,
    }).start();
  }

  const cardContent = (
    <View style={styles.inner}>
      {useGradient ? (
        <LinearGradient
          colors={gradientColors}
          style={StyleSheet.absoluteFill}
        />
      ) : null}
      {children}
    </View>
  );

  const wrapped = onPress ? (
    <TouchableOpacity
      activeOpacity={1}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
        {cardContent}
      </Animated.View>
    </TouchableOpacity>
  ) : (
    cardContent
  );

  return (
    <Animated.View
      style={[
        styles.card,
        style,
        {
          opacity: opacityAnim,
          transform: [{ translateY }],
        },
      ]}
    >
      {wrapped}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: CARD_GAP,
    borderRadius: PREMIUM_CARD.borderRadius,
    overflow: 'hidden',
    padding: 0,
    minHeight: PREMIUM_CARD.minHeight,
    shadowColor: PREMIUM_CARD.shadowColor,
    shadowOffset: PREMIUM_CARD.shadowOffset,
    shadowOpacity: PREMIUM_CARD.shadowOpacity,
    shadowRadius: PREMIUM_CARD.shadowRadius,
    elevation: PREMIUM_CARD.elevation,
  },
  inner: {
    flex: 1,
    borderRadius: PREMIUM_CARD.borderRadius,
    overflow: 'hidden',
    padding: PREMIUM_CARD.padding,
  },
});
