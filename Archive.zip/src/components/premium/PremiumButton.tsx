import React from 'react';
import { ViewStyle, TextStyle } from 'react-native';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { GRADIENT_PRIMARY } from '../../constants/premiumTokens';
import ContinueCTAButton from '../ui/ContinueCTAButton';

interface PremiumButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  variant?: 'primary' | 'secondary';
  icon?: React.ReactNode;
  /** @default true — Continue row chevron */
  showTrailingChevron?: boolean;
}

/**
 * Account-themed Continue CTA (same chrome as auth `WWPrimaryButton` / Archive 4).
 */
export default function PremiumButton({
  title,
  onPress,
  disabled = false,
  loading = false,
  style,
  textStyle,
  variant = 'primary',
  icon,
  showTrailingChevron = true,
}: PremiumButtonProps) {
  const { theme } = useAccountTheme();
  const raw = theme?.primary ?? GRADIENT_PRIMARY[1];
  const accentColor = typeof raw === 'string' && raw.length > 0 ? raw : '#7EB8D4';

  return (
    <ContinueCTAButton
      accentColor={accentColor}
      title={title}
      onPress={onPress}
      disabled={disabled}
      loading={loading}
      style={style}
      textStyle={textStyle}
      variant={variant}
      leading={icon}
      showTrailingChevron={showTrailingChevron}
    />
  );
}
