import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType } from '../../constants/accountThemes';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  accountType?: AccountType;
  /** Use header-style gradient (same as AppHeader) and solid background */
  variant?: 'card' | 'header';
}

export default function GlassCard({ 
  children, 
  onPress, 
  style, 
  intensity = 40,
  tint,
  borderColor,
  accountType,
  variant = 'card',
}: GlassCardProps) {
  const contextTheme = useAccountTheme();
  const theme = contextTheme.theme;
  const isLight = theme.mode === 'light';
  const resolvedTint = tint ?? 'dark';
  const headerBg = (theme.headerBackground ?? theme.background) as [string, string];
  const headerGradient = [`${headerBg[0]}FF`, `${headerBg[1] || headerBg[0]}EE`] as [string, string];
  const gradientColors = variant === 'header'
    ? headerGradient
    : (theme.cardBackgroundGradient
      ? theme.cardBackgroundGradient
      : ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']);

  const content = variant === 'header' ? (
    <View style={[styles.blurContainer, style]}>
      <LinearGradient
        colors={gradientColors as [string, string]}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </View>
  ) : (
    <BlurView intensity={isLight ? 28 : intensity} tint={resolvedTint} style={[styles.blurContainer, style]}>
      <LinearGradient
        colors={gradientColors as [string, string]}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0,
    shadowRadius: 12,
  },
});

