import { getServiceDisplayName } from './serviceNameMapper';

export function bookingDurationMinutes(serviceType?: string, serviceName?: string): number {
  const name = getServiceDisplayName(serviceType, serviceName).toLowerCase();
  if (name.includes('detail') || name.includes('ceramic') || name.includes('full')) return 120;
  return 60;
}

/** Match calendar sync: prefer scheduled_at, then request_sent_at; else next half-hour. */
export function parseBookingWindowStart(scheduledAt?: string | null, requestSentAt?: string | null): Date {
  const candidates = [scheduledAt, requestSentAt].filter(Boolean) as string[];
  for (const src of candidates) {
    const d = new Date(src);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const now = new Date();
  now.setMinutes(Math.ceil(now.getMinutes() / 30) * 30, 0, 0);
  if (now.getTime() <= Date.now()) {
    now.setMinutes(now.getMinutes() + 30);
  }
  return now;
}

export type TimeWindowMs = { startMs: number; endMs: number };

export function getBookingTimeWindow(
  scheduledAt?: string | null,
  requestSentAt?: string | null,
  serviceType?: string,
  serviceName?: string
): TimeWindowMs {
  const start = parseBookingWindowStart(scheduledAt, requestSentAt);
  const durMin = bookingDurationMinutes(serviceType, serviceName);
  const end = new Date(start.getTime() + durMin * 60 * 1000);
  return { startMs: start.getTime(), endMs: end.getTime() };
}

export function intervalsOverlap(a: TimeWindowMs, b: TimeWindowMs): boolean {
  return a.startMs < b.endMs && b.startMs < a.endMs;
}

export function windowOverlapsAny(job: TimeWindowMs, blocks: TimeWindowMs[]): boolean {
  return blocks.some((b) => intervalsOverlap(job, b));
}
