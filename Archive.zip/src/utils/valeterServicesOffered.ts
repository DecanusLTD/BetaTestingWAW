/**
 * Derives the list of "services offered" display names from valeter_service_settings
 * so profile and personal info show real wash tiers (Bronze, Silver, Gold, etc.)
 * and detailing / repair options instead of mock data.
 */

export type TierKey =
  | 'bronze'
  | 'silver'
  | 'gold'
  | 'platinum'
  | 'emerald';

export type DetailingKey =
  | 'ceramic-coating'
  | 'machine-polishing'
  | 'soft-top-restoration'
  | 'mould-removal';

export type RepairKey =
  | 'headlight-restoration'
  | 'scratch-removal'
  | 'paint-chip-repair'
  | 'trim-restoration'
  | 'leather-repair'
  | 'maintenance-check';

const TIER_DISPLAY_NAMES: Record<TierKey, string> = {
  bronze: 'Bronze Wash',
  silver: 'Silver Wash',
  gold: 'Gold Wash',
  platinum: 'Platinum Wash',
  emerald: 'Diamond Wash',
};

const DETAILING_DISPLAY_NAMES: Record<DetailingKey, string> = {
  'ceramic-coating': 'Ceramic Coating',
  'machine-polishing': 'Machine Polishing',
  'soft-top-restoration': 'Soft Top Restoration',
  'mould-removal': 'Mould Removal',
};

const REPAIR_DISPLAY_NAMES: Record<RepairKey, string> = {
  'headlight-restoration': 'Headlight Restoration',
  'scratch-removal': 'Scratch Removal',
  'paint-chip-repair': 'Paint Chip Repair',
  'trim-restoration': 'Trim Restoration',
  'leather-repair': 'Leather Repair',
  'maintenance-check': 'Maintenance Check',
};

const ALL_TIER_KEYS: TierKey[] = [
  'bronze',
  'silver',
  'gold',
  'platinum',
  'emerald',
];

export interface ValeterServiceSettingsRow {
  tier_pricing?: Record<
    string,
    { prices?: Record<string, number | null>; minutes?: number | null; enabled?: boolean }
  > | null;
  detailing_offered?: boolean | null;
  detailing_menu?: { items?: Array<{ key: string; enabled?: boolean }> } | null;
  repairs_offered?: boolean | null;
  repair_menu?: { items?: Array<{ key: string; enabled?: boolean }> } | null;
}

/**
 * Returns display names for wash tiers, detailing, and repair services that the valeter
 * has enabled (or has any price set) in valeter_service_settings.
 */
export function getServicesOfferedFromSettings(settings: ValeterServiceSettingsRow | null): string[] {
  const names: string[] = [];
  if (!settings) return names;

  const tierPricing = settings.tier_pricing;
  if (tierPricing && typeof tierPricing === 'object') {
    for (const key of ALL_TIER_KEYS) {
      const tier = tierPricing[key];
      if (!tier) continue;
      const enabled = tier.enabled !== false;
      const hasPrice =
        tier.prices &&
        Object.values(tier.prices).some((v) => v != null && Number.isFinite(v) && (v as number) > 0);
      if (enabled || hasPrice) {
        const display = TIER_DISPLAY_NAMES[key as TierKey];
        if (display && !names.includes(display)) names.push(display);
      }
    }
  }

  if (settings.detailing_offered && settings.detailing_menu?.items) {
    for (const item of settings.detailing_menu.items) {
      if (item.enabled && item.key in DETAILING_DISPLAY_NAMES) {
        const display = DETAILING_DISPLAY_NAMES[item.key as DetailingKey];
        if (display && !names.includes(display)) names.push(display);
      }
    }
  }

  if (settings.repairs_offered && settings.repair_menu?.items) {
    for (const item of settings.repair_menu.items) {
      if (item.enabled && item.key in REPAIR_DISPLAY_NAMES) {
        const display = REPAIR_DISPLAY_NAMES[item.key as RepairKey];
        if (display && !names.includes(display)) names.push(display);
      }
    }
  }

  return names;
}
