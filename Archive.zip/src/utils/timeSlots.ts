/**
 * Generates time slots starting from 30 minutes from now
 * @param count - Number of time slots to generate (default: 8)
 * @returns Array of ISO string timestamps
 */
export const generateTimeSlots = (count = 8): string[] => {
  const slots: string[] = [];
  const now = new Date();
  now.setMinutes(now.getMinutes() + 30);
  now.setSeconds(0, 0);
  for (let i = 0; i < count; i += 1) {
    const slot = new Date(now.getTime() + i * 60 * 60 * 1000);
    slots.push(slot.toISOString());
  }
  return slots;
};

