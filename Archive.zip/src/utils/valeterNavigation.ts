import {
  isValeterRoutePath,
} from './authRole';

export const VALETER_SETTINGS_HUB_ROUTE = '/valeter/profile/valeter-profile?tab=settings';

/** Map home — bottom tabs hidden; sidebar menu used instead. */
export function isValeterDashboardRoute(pathname: string): boolean {
  const p = pathname.replace(/\/$/, '');
  return p === '/valeter/valeter-dashboard' || p.endsWith('/valeter/valeter-dashboard');
}

/** Valeter screens with an inline map-home control in their own header chrome. */
export function isValeterInlineMapHomeRoute(pathname: string): boolean {
  const p = pathname.replace(/\/$/, '');
  return (
    p === '/valeter/jobs' ||
    p === '/valeter/inbox' ||
    p === '/valeter/notifications' ||
    p === '/valeter/profile/valeter-profile'
  );
}

/**
 * Profile → Settings children. Back should return to the settings hub,
 * not jump straight to the map dashboard.
 */
export function isValeterSettingsChildRoute(pathname: string): boolean {
  const p = pathname.replace(/\/$/, '');
  return (
    p.includes('/valeter/settings/') ||
    p.includes('/valeter/profile/valeter-documents') ||
    p.includes('/valeter/profile/valeter-personal-info') ||
    p.includes('/valeter/profile/valeter-notification-preferences') ||
    p.includes('/valeter/profile/valeter-services') ||
    p.includes('/valeter/profile/valeter-vehicle-info') ||
    p.includes('/valeter/profile/valeter-detail-profile') ||
    p.includes('/valeter/stripe-connect') ||
    p.includes('/valeter/support/') ||
    p.includes('/valeter/features/job-history') ||
    p.includes('/valeter/valeter-wash-history') ||
    p.includes('/valeter/valeter-analytics') ||
    p.includes('/valeter/valeter-rewards') ||
    p.includes('/valeter/features/referral') ||
    p === '/terms-of-service' ||
    p.endsWith('/terms-of-service') ||
    p === '/privacy-policy' ||
    p.endsWith('/privacy-policy') ||
    p === '/account-deletion' ||
    p.endsWith('/account-deletion')
  );
}

/** Full-screen flows — no floating menu (tracking, trip, accept, chat, radius map). */
export function isValeterImmersiveRoute(pathname = ''): boolean {
  const p = pathname;
  return (
    p.includes('/jobs/tracking') ||
    p.includes('/valeter/trips') ||
    p.includes('/jobs/accept') ||
    p.includes('/jobs/complete') ||
    p.includes('/settings/distance-covering') ||
    (p.includes('/valeter/') && p.includes('/chat'))
  );
}

/** Valeter sub-pages that use map-home instead of a back chevron (floating or inline). */
export function hasValeterMapHomeNavigation(pathname: string): boolean {
  if (!isValeterRoutePath(pathname)) return false;
  if (isValeterDashboardRoute(pathname)) return false;
  if (isValeterImmersiveRoute(pathname)) return false;
  if (isValeterSettingsChildRoute(pathname)) return false;
  return true;
}
