/**
 * Format a display name for UI (trim, fallback).
 */
export function formatDisplayName(name: string | null | undefined, fallback = 'Customer'): string {
  if (name == null) return fallback;
  const s = String(name).trim();
  return s.length > 0 ? s : fallback;
}
