import { Linking, Platform } from 'react-native';

function encodeDestination(address: string | null | undefined, latitude?: number | null, longitude?: number | null) {
  if (latitude != null && longitude != null && Number.isFinite(latitude) && Number.isFinite(longitude)) {
    return `${latitude},${longitude}`;
  }
  return String(address || '').trim();
}

export async function openExternalDirections(params: {
  address?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  label?: string | null;
}): Promise<void> {
  const destination = encodeDestination(params.address, params.latitude, params.longitude);
  if (!destination) {
    throw new Error('No destination available for navigation.');
  }

  const label = encodeURIComponent(params.label || 'Destination');

  if (Platform.OS === 'ios') {
    const appleUrl = `maps://?daddr=${encodeURIComponent(destination)}&dirflg=d`;
    if (await Linking.canOpenURL(appleUrl)) {
      await Linking.openURL(appleUrl);
      return;
    }

    await Linking.openURL(`https://maps.apple.com/?daddr=${encodeURIComponent(destination)}&dirflg=d&q=${label}`);
    return;
  }

  if (Platform.OS === 'android') {
    const googleNavUrl = `google.navigation:q=${encodeURIComponent(destination)}&mode=d`;
    if (await Linking.canOpenURL(googleNavUrl)) {
      await Linking.openURL(googleNavUrl);
      return;
    }

    await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`);
    return;
  }

  await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`);
}
