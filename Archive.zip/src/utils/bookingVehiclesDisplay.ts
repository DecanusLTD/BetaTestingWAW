/**
 * Prefer booking.vehicle_info (supports multi-vehicle "A · B · C") over single garage fields.
 */
export function bookingVehiclesDisplayLine(args: {
  vehicleInfo?: string | null;
  registration?: string | null;
  make?: string | null;
  model?: string | null;
}): string | null {
  const info = typeof args.vehicleInfo === 'string' ? args.vehicleInfo.trim() : '';
  if (info) return info;
  const parts = [args.registration, args.make, args.model]
    .map((p) => (typeof p === 'string' ? p.trim() : ''))
    .filter(Boolean);
  return parts.length > 0 ? parts.join(' ') : null;
}

export function bookingVehicleCountFromInfo(vehicleInfo?: string | null): number {
  const info = typeof vehicleInfo === 'string' ? vehicleInfo.trim() : '';
  if (!info) return 0;
  return info.split('·').map((s) => s.trim()).filter(Boolean).length;
}
