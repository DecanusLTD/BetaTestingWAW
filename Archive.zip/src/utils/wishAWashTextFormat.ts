/**
 * Wish a Wash copy standards — align custom location services with standard / eco tier naming
 * and “Includes”-style bullet lists.
 */

const BULLET_PREFIX = /^[•\-\*\u2022]\s*/;

function capitalizeSentenceLine(line: string): string {
  const t = line.trim();
  if (!t) return '';
  return t.charAt(0).toUpperCase() + t.slice(1);
}

/**
 * Service title: title case, single spaces (matches e.g. "Eco Silver Wash", "Diamond Wash").
 */
export function formatWishAWashServiceName(input: string): string {
  const s = String(input || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!s) return '';
  return s
    .split(' ')
    .filter(Boolean)
    .map((word) => {
      const lower = word.toLowerCase();
      if (lower === 'suv') return 'SUV';
      if (lower === 'ev') return 'EV';
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(' ');
}

/**
 * Customer-facing list: one bullet per line, same idea as tier `includes[]`.
 * Strips existing • / - markers, trims, capitalises each line. Split on newlines or `;`.
 */
export function normalizeWishAWashDescriptionLines(input: string): string {
  const raw = String(input || '').replace(/\r\n/g, '\n').trim();
  if (!raw) return '';

  let segments: string[] = [];

  if (raw.includes('\n')) {
    segments = raw.split('\n');
  } else if (raw.includes(';')) {
    segments = raw.split(';');
  } else {
    segments = [raw];
  }

  const lines = segments
    .map((line) => line.replace(BULLET_PREFIX, '').trim())
    .map(capitalizeSentenceLine)
    .filter(Boolean);

  return lines.join('\n');
}

/** For customer UI: render stored lines with a leading bullet on each line. */
export function formatDescriptionLinesAsBulletText(stored: string): string {
  const norm = normalizeWishAWashDescriptionLines(stored);
  if (!norm) return '';
  return norm
    .split('\n')
    .filter(Boolean)
    .map((line) => `• ${line}`)
    .join('\n');
}
