/** Resolve account theme background to a two-stop gradient tuple for LinearGradient. */
export function themeBackgroundGradient(
  background: readonly string[] | undefined,
  fallback: [string, string]
): [string, string] {
  if (background && background.length > 0) {
    const first = background[0];
    const second = background[1] ?? first;
    return [first, second];
  }
  return fallback;
}
