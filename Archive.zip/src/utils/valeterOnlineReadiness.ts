import { Alert } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '../lib/supabase';

export type ValeterOnlineGapId =
  | 'vehicle'
  | 'profile_picture'
  | 'bio'
  | 'experience'
  | 'pricing';

export type ValeterOnlineGap = Readonly<{
  id: ValeterOnlineGapId;
  title: string;
  detail: string;
  route: string;
}>;

const VEHICLE_SIZES = ['small', 'medium', 'large', 'xl', 'xxl'] as const;
const TIER_KEYS = ['bronze', 'silver', 'gold', 'platinum', 'emerald'] as const;

function isFilledPrice(value: unknown): boolean {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) && n > 0;
}

function hasCompleteTierPricing(tier: any, tierKey?: string): boolean {
  if (!tier || typeof tier !== 'object') return false;
  if (tier.enabled === false) return false;
  const minutesOk = tier.minutes == null || (Number.isFinite(Number(tier.minutes)) && Number(tier.minutes) > 0);

  if (tierKey === 'bronze' || tier.pricesExterior || tier.pricesInterior) {
    const exterior = tier.pricesExterior ?? tier.prices;
    const interior = tier.pricesInterior ?? tier.prices;
    if (!exterior || typeof exterior !== 'object' || !interior || typeof interior !== 'object') return false;
    const exteriorOk = VEHICLE_SIZES.every((size) => isFilledPrice(exterior[size]));
    const interiorOk = VEHICLE_SIZES.every((size) => isFilledPrice(interior[size]));
    return exteriorOk && interiorOk && minutesOk;
  }

  const prices = tier.prices;
  if (!prices || typeof prices !== 'object') return false;
  const allSizes = VEHICLE_SIZES.every((size) => isFilledPrice(prices[size]));
  return allSizes && minutesOk;
}

function hasAnySizedAddonPricing(menu: any): boolean {
  const items = menu?.items;
  if (!Array.isArray(items)) return false;
  return items.some((item: any) => {
    if (!item?.enabled) return false;
    const prices = item.prices;
    if (prices && typeof prices === 'object') {
      return Object.values(prices).some((v) => isFilledPrice(v));
    }
    return isFilledPrice(item.price);
  });
}

function bioLooksComplete(bio: string | null | undefined): boolean {
  // Default bio is intentional display copy — counts as set
  return (bio || '').trim().length >= 8;
}

function experienceLooksComplete(experience: string | null | undefined): boolean {
  const t = (experience || '').trim();
  if (!t || t === '—' || t === '-') return false;
  if (/^0\s*years?$/i.test(t)) return false;
  return true;
}

/**
 * Checks whether a valeter has the minimum profile/vehicle/pricing setup to go online.
 */
export async function getValeterOnlineGaps(userId: string): Promise<ValeterOnlineGap[]> {
  const gaps: ValeterOnlineGap[] = [];

  const [vpRes, profileRes, settingsRes] = await Promise.all([
    supabase
      .from('valeter_profiles')
      .select('vehicle_registration, vehicle_make, vehicle_model, bio, experience')
      .eq('user_id', userId)
      .maybeSingle(),
    supabase.from('profiles').select('profile_picture').eq('id', userId).maybeSingle(),
    supabase
      .from('valeter_service_settings')
      .select('tier_pricing, detailing_offered, detailing_menu, repairs_offered, repair_menu')
      .eq('valeter_id', userId)
      .maybeSingle(),
  ]);

  const vp = vpRes.data;
  const registration = (vp?.vehicle_registration || '').trim();
  const make = (vp?.vehicle_make || '').trim();
  const model = (vp?.vehicle_model || '').trim();
  if (!registration || (!make && !model)) {
    gaps.push({
      id: 'vehicle',
      title: 'Vehicle details',
      detail: 'Add your registration and vehicle so customers know who’s arriving.',
      route: '/valeter/profile/valeter-vehicle-info',
    });
  }

  const picture = (profileRes.data?.profile_picture || '').trim();
  if (!picture) {
    gaps.push({
      id: 'profile_picture',
      title: 'Profile photo',
      detail: 'Upload a clear photo of yourself for your valeter profile.',
      route: '/valeter/profile/valeter-profile',
    });
  }

  if (!bioLooksComplete(vp?.bio)) {
    gaps.push({
      id: 'bio',
      title: 'Profile bio',
      detail: 'Write a short bio so customers know who you are.',
      route: '/valeter/profile/valeter-personal-info',
    });
  }

  if (!experienceLooksComplete(vp?.experience)) {
    gaps.push({
      id: 'experience',
      title: 'Experience',
      detail: 'Add your valeting experience (e.g. “2 years”).',
      route: '/valeter/profile/valeter-personal-info',
    });
  }

  const settings = settingsRes.data;
  const tierPricing = settings?.tier_pricing;
  let pricingOk = false;
  if (tierPricing && typeof tierPricing === 'object') {
    pricingOk = TIER_KEYS.some((key) => hasCompleteTierPricing((tierPricing as any)[key], key));
  }
  if (!pricingOk && settings?.detailing_offered) {
    pricingOk = hasAnySizedAddonPricing(settings.detailing_menu);
  }
  if (!pricingOk && settings?.repairs_offered) {
    pricingOk = hasAnySizedAddonPricing(settings.repair_menu);
  }

  if (!pricingOk) {
    gaps.push({
      id: 'pricing',
      title: 'Services & pricing',
      detail: 'Enable at least one wash package and set prices for every vehicle size.',
      route: '/valeter/profile/valeter-services',
    });
  }

  return gaps;
}

/** Prompt the valeter with what’s missing before going online. Returns true if they can proceed. */
export async function ensureValeterOnlineReady(userId: string): Promise<boolean> {
  let gaps: ValeterOnlineGap[] = [];
  try {
    gaps = await getValeterOnlineGaps(userId);
  } catch (e) {
    console.warn('[online-readiness] check failed', e);
    // Fail open on unexpected fetch errors so Stripe/location gates still apply.
    return true;
  }

  if (gaps.length === 0) return true;

  const first = gaps[0];
  const list = gaps.map((g) => `• ${g.title}`).join('\n');
  const message =
    gaps.length === 1
      ? `${first.detail}`
      : `Finish these before going online:\n\n${list}\n\n${first.detail}`;

  return await new Promise((resolve) => {
    Alert.alert('Complete your profile', message, [
      { text: 'Not now', style: 'cancel', onPress: () => resolve(false) },
      {
        text: 'Fix now',
        onPress: () => {
          router.push(first.route as any);
          resolve(false);
        },
      },
    ]);
  });
}
