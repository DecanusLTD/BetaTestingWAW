export type CanonicalUserType = 'customer' | 'valeter' | 'organization';

const ORGANIZATION_ALIASES = new Set([
  'organization',
  'organisation',
  'business',
  'business_account',
  'business-owner',
  'business_owner',
  'org',
  'company',
]);

const VALETER_ALIASES = new Set([
  'valeter',
  'valetor',
  'valeter_account',
  'car_care_pro',
  'carcarepro',
  'ccp',
]);

const CUSTOMER_ALIASES = new Set([
  'customer',
  'client',
  'consumer',
  'owner',
  'car_owner',
  'vehicle_owner',
  'owner_account',
]);

export function normalizeUserType(
  input: unknown,
  fallback: CanonicalUserType | null = 'customer'
): CanonicalUserType | null {
  const value = String(input ?? '').trim().toLowerCase();
  if (!value) return fallback;

  if (ORGANIZATION_ALIASES.has(value)) return 'organization';
  if (VALETER_ALIASES.has(value)) return 'valeter';
  if (CUSTOMER_ALIASES.has(value)) return 'customer';

  return fallback;
}

export function isOrganizationRole(input: unknown): boolean {
  return normalizeUserType(input, null) === 'organization';
}

export function isValeterRole(input: unknown): boolean {
  return normalizeUserType(input, null) === 'valeter';
}

export function isCustomerRole(input: unknown): boolean {
  return normalizeUserType(input, null) === 'customer';
}

/** True for any non-valeter account (owner/customer or business). */
export function isNonValeterRole(input: unknown): boolean {
  const role = normalizeUserType(input, null);
  return role !== 'valeter';
}

export function isBusinessRoutePath(pathname: string): boolean {
  return (
    pathname.includes('/business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/organization/')
  );
}

export function isValeterRoutePath(pathname: string): boolean {
  return pathname.includes('/valeter/');
}
