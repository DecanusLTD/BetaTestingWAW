import { supabase } from '../lib/supabase';

type LocationLike = {
  id: string;
  name?: string | null;
};

type OpeningHourRow = {
  location_id: string;
  day_of_week: number;
  is_open: boolean;
  open_time: string | null;
  close_time: string | null;
};

export type LocationOpenBlockReason = {
  locationId: string;
  locationName: string;
  reason: string;
};

const isValidHHMM = (value: string) => /^([01]\d|2[0-3]):([0-5]\d)$/.test((value || '').trim());

const hhmmToMinutes = (value: string) => {
  if (!isValidHHMM(value)) return null;
  const [hours, minutes] = value.split(':').map(Number);
  return hours * 60 + minutes;
};

const formatTime = (value: string | null | undefined) => {
  if (!value) return 'unknown time';
  return value;
};

const currentDayVariants = (): number[] => {
  const jsDay = new Date().getDay(); // 0 (Sun) ... 6 (Sat)
  const mondayZero = (jsDay + 6) % 7; // 0 (Mon) ... 6 (Sun)
  const isoDay = jsDay === 0 ? 7 : jsDay; // 1 (Mon) ... 7 (Sun)
  return Array.from(new Set([jsDay, mondayZero, isoDay]));
};

export async function getLocationOpenBlockReasons(locations: LocationLike[]): Promise<LocationOpenBlockReason[]> {
  const ids = locations.map((loc) => loc.id).filter(Boolean);
  if (ids.length === 0) return [];

  const dayVariants = currentDayVariants();
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const { data, error } = await supabase
    .from('location_opening_hours')
    .select('location_id, day_of_week, is_open, open_time, close_time')
    .in('location_id', ids)
    .in('day_of_week', dayVariants);

  if (error || !data) {
    return locations.map((loc) => ({
      locationId: loc.id,
      locationName: loc.name ?? 'This location',
      reason: 'Opening hours could not be checked right now.',
    }));
  }

  const rows = data as OpeningHourRow[];
  const grouped = new Map<string, OpeningHourRow[]>();
  rows.forEach((row) => {
    const list = grouped.get(row.location_id) ?? [];
    list.push(row);
    grouped.set(row.location_id, list);
  });

  const reasons: LocationOpenBlockReason[] = [];

  locations.forEach((loc) => {
    const hours = grouped.get(loc.id) ?? [];
    if (hours.length === 0) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: 'No opening hours are set for today.',
      });
      return;
    }

    const openShift = hours.find((row) => row.is_open);
    if (!openShift) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: 'This location is marked closed in today’s opening hours.',
      });
      return;
    }

    const openMinutes = openShift.open_time ? hhmmToMinutes(openShift.open_time) : null;
    const closeMinutes = openShift.close_time ? hhmmToMinutes(openShift.close_time) : null;
    if (openMinutes === null || closeMinutes === null) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: 'Today’s opening hours are incomplete.',
      });
      return;
    }

    if (closeMinutes <= openMinutes) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: 'Today’s closing time must be after the opening time.',
      });
      return;
    }

    if (currentMinutes < openMinutes) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: `This location opens at ${formatTime(openShift.open_time)} today.`,
      });
      return;
    }

    if (currentMinutes >= closeMinutes) {
      reasons.push({
        locationId: loc.id,
        locationName: loc.name ?? 'This location',
        reason: `This location closes at ${formatTime(openShift.close_time)} today.`,
      });
    }
  });

  return reasons;
}
