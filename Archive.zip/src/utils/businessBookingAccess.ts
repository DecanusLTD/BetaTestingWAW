/**
 * Business-side rules for tracking and chat (aligned with dashboard / booking UI).
 */

const TERMINAL = new Set(['completed', 'cancelled']);
const LIVE = new Set(['in_progress', 'en_route', 'arrived']);

export function canTrackBookingStatus(status: string): boolean {
  return !TERMINAL.has(String(status).toLowerCase());
}

/** True when the job is not live yet and scheduled start is more than 30 minutes away. */
export function isPreJobTrackingWindowLocked(scheduledAt: string | null | undefined, status: string): boolean {
  const s = String(status).toLowerCase();
  if (!canTrackBookingStatus(s)) return true;
  if (LIVE.has(s)) return false;
  if (!scheduledAt) return false;
  const t = new Date(scheduledAt).getTime();
  if (!Number.isFinite(t)) return false;
  return t - Date.now() > 30 * 60 * 1000;
}

export function canOpenLiveTracking(scheduledAt: string | null | undefined, status: string): boolean {
  return canTrackBookingStatus(status) && !isPreJobTrackingWindowLocked(scheduledAt, status);
}
