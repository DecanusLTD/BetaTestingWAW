/**
 * Service Name Mapper
 * Maps legacy service types and service IDs to display names (mirrors customer app so bookings match).
 */

export const SERVICE_NAME_MAP: Record<string, string> = {
  // Legacy service types → New service names
  'instant_wash': 'Bronze Wash',
  'priority_wash': 'Silver Wash',
  'emerald_wash': 'Diamond Wash',
  'eco_emerald_wash': 'Diamond Wash',
  'full_valet': 'Gold Wash',
  'premium_detail': 'Platinum Wash',
  'wash': 'Bronze Wash',
  'valet': 'Gold Wash',
  'basic-wash': 'Bronze Wash',
  'premium-wash': 'Silver Wash',

  // Wash service IDs
  'bronze-wash': 'Bronze Wash',
  'silver-wash': 'Silver Wash',
  'emerald-wash': 'Diamond Wash',
  'gold-wash': 'Gold Wash',
  'platinum-wash': 'Platinum Wash',

  // Legacy eco IDs map to standard tiers
  'eco-bronze-wash': 'Bronze Wash',
  'eco-silver-wash': 'Silver Wash',
  'eco-emerald-wash': 'Diamond Wash',
  'eco-gold-wash': 'Gold Wash',
  'eco-platinum-wash': 'Platinum Wash',

  // Detailing service IDs
  'ceramic-coating': 'Ceramic Coating',
  'machine-polishing': 'Machine Polishing',
  'soft-top-restoration': 'Soft Top Restoration',
  'mould-removal': 'Mould Removal',

  // Repair service IDs
  'maintenance-check': 'Maintenance Check',
  'headlight-restoration': 'Headlight Restoration',
  'scratch-removal': 'Scratch Removal',
  'paint-chip-repair': 'Paint Chip Repair',
  'trim-restoration': 'Trim Restoration',
  'leather-repair': 'Leather Repair',
};

export const REVERSE_SERVICE_MAP: Record<string, string> = {
  'Bronze Wash': 'instant_wash',
  'Silver Wash': 'priority_wash',
  'Diamond Wash': 'emerald_wash',
  'Gold Wash': 'full_valet',
  'Platinum Wash': 'premium_detail',
  'Ceramic Coating': 'ceramic_coating',
  'Machine Polishing': 'machine_polishing',
  'Soft Top Restoration': 'soft_top_restoration',
  'Mould Removal': 'mould_removal',
  'Headlight Restoration': 'headlight_restoration',
  'Maintenance Check': 'maintenance_check',
  'Scratch Removal': 'scratch_removal',
  'Paint Chip Repair': 'paint_chip_repair',
  'Trim Restoration': 'trim_restoration',
  'Leather Repair': 'leather_repair',
};

const KNOWN_DISPLAY_NAMES = [
  'Bronze Wash', 'Silver Wash', 'Diamond Wash', 'Gold Wash', 'Platinum Wash',
  'Ceramic Coating', 'Machine Polishing', 'Soft Top Restoration', 'Mould Removal',
  'Headlight Restoration', 'Scratch Removal', 'Paint Chip Repair', 'Trim Restoration', 'Leather Repair',
  'Maintenance Check',
];

/** Detailing service IDs – used to show correct booking copy and styling. */
const DETAILING_SERVICE_IDS = new Set([
  'ceramic-coating',
  'machine-polishing',
  'soft-top-restoration',
  'mould-removal',
]);

/** Repair service IDs – separate category from detailing. */
const REPAIR_SERVICE_IDS = new Set([
  'maintenance-check',
  'headlight-restoration',
  'scratch-removal',
  'paint-chip-repair',
  'trim-restoration',
  'leather-repair',
]);

export function getServiceDisplayName(
  serviceType?: string | null,
  serviceName?: string | null
): string {
  if (serviceName && KNOWN_DISPLAY_NAMES.includes(serviceName)) {
    return serviceName;
  }
  if (serviceType && SERVICE_NAME_MAP[serviceType]) {
    return SERVICE_NAME_MAP[serviceType];
  }
  if (serviceName) {
    return serviceName;
  }
  return serviceType || 'Service';
}

export function isDetailingService(
  serviceType?: string | null,
  serviceName?: string | null
): boolean {
  if (serviceType && DETAILING_SERVICE_IDS.has(serviceType)) return true;
  const name = getServiceDisplayName(serviceType, serviceName);
  return [
    'Ceramic Coating', 'Machine Polishing', 'Soft Top Restoration', 'Mould Removal',
  ].includes(name);
}

export function isRepairService(
  serviceType?: string | null,
  serviceName?: string | null
): boolean {
  if (serviceType && REPAIR_SERVICE_IDS.has(serviceType)) return true;
  const name = getServiceDisplayName(serviceType, serviceName);
  return [
    'Maintenance Check', 'Headlight Restoration', 'Scratch Removal', 'Paint Chip Repair',
    'Trim Restoration', 'Leather Repair',
  ].includes(name);
}

export function getServiceDescription(serviceName: string): string {
  const descriptions: Record<string, string> = {
    'Bronze Wash': 'Interior OR exterior refresh',
    'Silver Wash': 'Interior + exterior clean',
    'Gold Wash': 'Interior deep clean',
    'Platinum Wash': 'Full valet',
    'Diamond Wash': 'Premium full detail',
    'Ceramic Coating': 'Long-lasting paint protection',
    'Machine Polishing': 'Paint correction',
    'Soft Top Restoration': 'Convertible roof care',
    'Mould Removal': 'Mould and odour treatment',
    'Headlight Restoration': 'Lens clarity restoration',
    'Scratch Removal': 'Paint rescue',
    'Paint Chip Repair': 'Touch-in and seal',
    'Trim Restoration': 'Faded plastic revived',
    'Leather Repair': 'Seat and trim repair',
    'Maintenance Check': 'Vehicle health check',
  };
  return descriptions[serviceName] || 'Car care service';
}
