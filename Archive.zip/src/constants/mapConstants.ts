import type { Region } from 'react-native-maps';
import {
  DARK_MAP_STYLE,
} from './mapStyles';

/** Same zoom as booking and tracking maps (street-level, zoomed in on customer). */
export const MAP_ZOOM_DELTA = 0.001;

/** Duration for smooth camera animations (user location, valeter selected, booking confirmed). */
export const MAP_CAMERA_ANIMATION_DURATION = 800;

/** Default map region when user location is not yet available (UK - London area). */
export const DEFAULT_MAP_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: MAP_ZOOM_DELTA,
  longitudeDelta: MAP_ZOOM_DELTA,
};

/** Lock map to dark style regardless of device Light/Dark system appearance. */
export const MAP_LOCKED_DARK = 'dark' as const;

/** Shared dark map style used by map-first views. */
export { DARK_MAP_STYLE };

