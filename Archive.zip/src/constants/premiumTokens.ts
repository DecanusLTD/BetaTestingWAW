/**
 * Premium UI design system – 8pt grid, floating cards, hero metrics.
 * Use for valeter & business screens. No business logic.
 */

// 8-point grid (industry standard)
export const GRID = {
  8: 8,
  16: 16,
  24: 24,
  32: 32,
  40: 40,
  48: 48,
  64: 64,
} as const;

// Screen layout
export const SCREEN_PADDING_H = 20;
export const SECTION_GAP = 24;   // Header → Hero
export const CARD_GAP = 16;     // Between cards
export const SECTION_GAP_LG = 32; // Before secondary content

// Motion (consistent, subtle)
export const MOTION = {
  entranceMs: 400,
  entranceStagger: 60,
  pressMs: 120,
  springDamping: 0.85,
  springStiffness: 200,
} as const;

// Premium card (Uber-style floating, enhanced depth)
export const PREMIUM_CARD = {
  borderRadius: 22,
  padding: 18,
  minHeight: 80,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 6 },
  shadowOpacity: 0.18,
  shadowRadius: 24,
  elevation: 8,
} as const;

// Elevated shadow for hero / primary actions
export const SHADOW_ELEVATED = {
  shadowColor: '#0B3D91',
  shadowOffset: { width: 0, height: 8 },
  shadowOpacity: 0.2,
  shadowRadius: 28,
  elevation: 12,
} as const;

// Hero metrics (Stripe-style)
export const HERO_TITLE_SIZE = 14;
export const HERO_NUMBER_SIZE = 38;
export const HERO_SUBTITLE_SIZE = 13;

// Buttons — match Archive 4 / booking Continue CTAs (`BOOKING_CONTINUE_RADIUS`)
export const BUTTON_HEIGHT = 52;
export const BUTTON_RADIUS = 18;
export const BUTTON_PRESS_SCALE = 0.96;
export const BUTTON_ANIM_DURATION = 120;

// Bottom sheet (Apple Maps style)
export const BOTTOM_SHEET = {
  borderTopLeftRadius: 26,
  borderTopRightRadius: 26,
  handleBarWidth: 36,
  handleBarHeight: 4,
} as const;

// Icons
export const ICON_SIZE = 24;
export const ICON_SIZE_SM = 20;
export const ICON_GAP = 12;

// Primary gradient (Navy → Wish Blue) – for buttons/hero
export const GRADIENT_PRIMARY = ['#0B3D91', '#237AE6'] as const;

// Hero card gradient (slightly brighter for emphasis)
export const GRADIENT_HERO = ['#0F2847', '#1E3A5F', 'rgba(35,122,230,0.25)'] as const;
