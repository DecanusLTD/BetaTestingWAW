import type { AccountTheme } from './accountThemes';
import { colors } from './colors';
import { textStyles } from './typography';

/** Icon accent palette – light theme uses light blue icons; dark uses colors.iconAccent. */
export const getIconAccentColors = (theme?: AccountTheme | null) => {
  if (theme?.mode === 'light') {
    const iconPrimary = theme.iconPrimary ?? theme.primary ?? '#7DD3FC';
    return {
      primary: iconPrimary,
      success: theme.statusOnlineAccent ?? '#22C55E',
      money: theme.iconHighlight ?? iconPrimary,
      highlight: theme.iconHighlight ?? iconPrimary,
      warning: '#F59E0B',
      destructive: '#EF4444',
    };
  }
  return { ...colors.iconAccent };
};

/** Text colors. Light theme = muted blue–navy (reference UI) → light text; dark = light text on dark. */
export const getTextColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    primary: isLight ? (theme.textPrimary ?? '#F1F5F9') : '#F9FAFB',
    secondary: isLight ? (theme.textSecondary ?? 'rgba(241,245,249,0.88)') : 'rgba(249,250,251,0.88)',
    tertiary: isLight ? (theme.textOnBackground ?? 'rgba(241,245,249,0.7)') : 'rgba(249,250,251,0.75)',
    muted: isLight ? '#94A3B8' : 'rgba(249,250,251,0.68)',
    disabled: isLight ? 'rgba(241,245,249,0.5)' : 'rgba(249,250,251,0.48)',
    placeholder: isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.4)',
  };
};

/** High-contrast icon colors – WCAG AA compliant; light = light blue, inactive = softer light blue */
export const getIconColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  const primary = theme.iconPrimary ?? theme.accent;
  const highlight = theme.iconHighlight ?? primary;
  const inactiveLight = primary ? `${primary}CC` : '#93C5FD';
  return {
    primary: isLight ? primary : theme.accent,
    secondary: isLight ? (theme.textSecondary ?? 'rgba(249,250,251,0.9)') : 'rgba(255,255,255,0.88)',
    active: isLight ? primary : theme.accent,
    inactive: isLight ? inactiveLight : 'rgba(255,255,255,0.72)',
    highlight: isLight ? highlight : theme.accent,
  };
};

/** Full text styles with theme colors – use for consistent typography across all pages */
export const getTextStylesWithColors = (theme: AccountTheme) => {
  const tc = getTextColors(theme);
  return {
    pageTitle: { ...textStyles.pageTitle, color: tc.primary },
    pageSubtitle: { ...textStyles.pageSubtitle, color: tc.secondary },
    sectionTitle: { ...textStyles.sectionTitle, color: tc.primary },
    sectionSubtitle: { ...textStyles.sectionSubtitle, color: tc.secondary },
    body: { ...textStyles.body, color: tc.primary },
    bodyMedium: { ...textStyles.bodyMedium, color: tc.primary },
    bodySemiBold: { ...textStyles.bodySemiBold, color: tc.primary },
    bodySmall: { ...textStyles.bodySmall, color: tc.secondary },
    bodySmallMedium: { ...textStyles.bodySmallMedium, color: tc.secondary },
    caption: { ...textStyles.caption, color: tc.tertiary },
    captionMedium: { ...textStyles.captionMedium, color: tc.tertiary },
    captionSemiBold: { ...textStyles.captionSemiBold, color: tc.tertiary },
    cardTitle: { ...textStyles.cardTitle, color: tc.primary },
    button: { ...textStyles.button, color: tc.primary },
    buttonLarge: { ...textStyles.buttonLarge, color: tc.primary },
    statValue: { ...textStyles.statValue, color: tc.primary },
    statLabel: { ...textStyles.statLabel, color: tc.tertiary },
    tabLabel: { ...textStyles.tabLabel, color: tc.primary },
    modalTitle: { ...textStyles.modalTitle, color: tc.primary },
    modalSubtitle: { ...textStyles.modalSubtitle, color: tc.secondary },
    emptyTitle: { ...textStyles.emptyTitle, color: tc.primary },
  };
};

export const getBackgroundColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    card: isLight ? (theme.cardBackground ?? '#F8FBFF') : 'rgba(10,25,41,0.4)',
    cardBorder: isLight ? (theme.cardBorder ?? '#E3EEF9') : (theme.glassBorder || 'rgba(125,211,252,0.4)'),
  };
};
