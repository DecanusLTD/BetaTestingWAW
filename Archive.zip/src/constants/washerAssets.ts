/**
 * Central exports for washer app assets. Re-exports from src/constants/appAssetExports.
 * Use CAR_IMAGE for customer/job map markers, VALETER_IMAGE for valeter "You" marker.
 */
export {
  CAR_IMAGE,
  VALETER_IMAGE,
  VALETER_MAP_IMAGE,
  CARWASH_IMAGE,
  ICON,
  ICON_AUTH,
  WASHER_IMAGE,
  BRONZE_IMAGE,
  SILVER_IMAGE,
  GOLD_IMAGE,
  PLATINUM_IMAGE,
  EMERALD_IMAGE,
  DETAILING_HUB_IMAGE,
  ONBOARDING_VIDEO,
} from './appAssetExports';

// Optional assets – use existing app assets (auth-page.png / icon2.png not present)
export const AUTH_PAGE_IMAGE = require('../../assets/icon-auth.png');
export const ICON2_IMAGE = require('../../assets/icon.png');
