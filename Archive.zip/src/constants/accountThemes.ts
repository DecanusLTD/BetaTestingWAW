export type AccountType = 'valeter' | 'business';

export type ThemeMode = 'light' | 'dark';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
  cardBackground?: string;
  cardBackgroundGradient?: [string, string];
  cardBorder?: string;
  textPrimary?: string;
  textSecondary?: string;
  textOnBackground?: string;
  iconPrimary?: string;
  mode?: ThemeMode;
  statusOnlineCardBg?: string;
  statusOnlineAccent?: string;
  navBarBackground?: string;
  navBarBottomDark?: string;
  navActiveGlow?: string;
  iconHighlight?: string;
  shadowColor?: string;
  shadowOpacity?: number;
  shadowRadius?: number;
  iconCircleBg?: string;
  iconCircleBgHighlight?: string;
}

const SKY_BLUE = '#38BDF8';
const SKY_BLUE_ALT = '#0EA5E9';
const VALETER_BLUE = '#38BDF8';
const VALETER_BLUE_ALT = '#0EA5E9';
const AMBER_ACCENT = '#F59E0B';

/**
 * Light theme — lighter steel-blue wash blended with soft yellow-gold.
 * Same family as the original muted navy, just lifted and warmer.
 */
const LIGHT_PRIMARY = '#9EC9E0';
const LIGHT_SKY = '#7EB8D4';
const LIGHT_GOLD = '#E8C547';
const LIGHT_GOLD_DEEP = '#D4A017';
const LIGHT_GRADIENT: [string, string] = ['#6A9BB0', '#2A4660'];
const LIGHT_NAV_BASE = '#2A4660';

/** Frosted glass panels — soft blue glass with a hint of gold warmth. */
export const lightMistPanel = 'rgba(255,255,255,0.1)';
export const lightMistInput = 'rgba(255,255,255,0.13)';
export const lightMistElevated = 'rgba(255,255,255,0.16)';
export const lightMistPanelSoft = 'rgba(42,70,96,0.48)';
export const lightAmber = LIGHT_GOLD_DEEP;
export const lightAmberSoft = LIGHT_GOLD;
export const lightMoneyGold = LIGHT_GOLD;

export const valeterLightTheme: AccountTheme = {
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  background: LIGHT_GRADIENT,
  headerBackground: ['rgba(158,201,224,0.38)', 'rgba(42,70,96,0.78)'],
  glassBorder: 'rgba(158,201,224,0.42)',
  glassBorderAlt: 'rgba(232,197,71,0.32)',
  cardBorder: 'rgba(158,201,224,0.34)',
  cardBackground: 'rgba(255,255,255,0.1)',
  cardBackgroundGradient: ['rgba(255,248,230,0.1)', 'rgba(158,201,224,0.1)'],
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_GOLD,
  textPrimary: '#F8FAFC',
  textSecondary: 'rgba(248,250,252,0.8)',
  textOnBackground: 'rgba(248,250,252,0.66)',
  iconPrimary: LIGHT_PRIMARY,
  mode: 'light',
  statusOnlineCardBg: 'rgba(16,185,129,0.2)',
  statusOnlineAccent: '#10B981',
  navBarBackground: 'rgba(42,70,96,0.52)',
  navBarBottomDark: LIGHT_NAV_BASE,
  navActiveGlow: LIGHT_PRIMARY,
  iconHighlight: LIGHT_GOLD,
  shadowColor: 'rgba(15,30,48,0.35)',
  shadowOpacity: 0.2,
  shadowRadius: 10,
  iconCircleBg: 'rgba(158,201,224,0.26)',
  iconCircleBgHighlight: 'rgba(232,197,71,0.2)',
};

export const businessLightTheme: AccountTheme = {
  ...valeterLightTheme,
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_GOLD,
  iconPrimary: LIGHT_PRIMARY,
  iconHighlight: LIGHT_GOLD,
};

/** Dark surfaces — steel navy matched to sky (#38BDF8) + amber (#F59E0B) icons. */
const DARK_BG_TOP = '#0B1F36';
const DARK_BG_BOTTOM = '#071525';
const DARK_NAV_BOTTOM = '#0E2740';
const DARK_CARD = '#0E2740';

export const accountThemes: Record<AccountType, AccountTheme> = {
  valeter: {
    primary: VALETER_BLUE,
    primaryAlt: VALETER_BLUE_ALT,
    background: [DARK_BG_TOP, DARK_BG_BOTTOM],
    headerBackground: ['rgba(56,189,248,0.26)', 'rgba(7,21,37,0.96)'],
    glassBorder: 'rgba(56,189,248,0.35)',
    cardBorder: 'rgba(56,189,248,0.28)',
    cardBackground: DARK_CARD,
    cardBackgroundGradient: ['rgba(56,189,248,0.12)', 'rgba(14,39,64,0.92)'],
    accent: VALETER_BLUE,
    accentAlt: AMBER_ACCENT,
    textPrimary: '#F9FAFB',
    textSecondary: 'rgba(249,250,251,0.78)',
    iconPrimary: VALETER_BLUE,
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(11,31,54,0.94)',
    navBarBottomDark: DARK_NAV_BOTTOM,
    navActiveGlow: VALETER_BLUE,
    iconHighlight: VALETER_BLUE,
    shadowColor: 'rgba(0,0,0,0.4)',
    shadowOpacity: 0.24,
    shadowRadius: 10,
    iconCircleBg: 'rgba(56,189,248,0.2)',
    iconCircleBgHighlight: 'rgba(245,158,11,0.18)',
  },

  business: {
    primary: SKY_BLUE,
    primaryAlt: SKY_BLUE_ALT,
    background: [DARK_BG_TOP, DARK_BG_BOTTOM],
    headerBackground: ['rgba(56,189,248,0.24)', 'rgba(7,21,37,0.96)'],
    glassBorder: 'rgba(56,189,248,0.38)',
    cardBorder: 'rgba(56,189,248,0.3)',
    cardBackground: DARK_CARD,
    cardBackgroundGradient: ['rgba(56,189,248,0.12)', 'rgba(14,39,64,0.92)'],
    accent: SKY_BLUE,
    accentAlt: AMBER_ACCENT,
    textPrimary: '#F9FAFB',
    textSecondary: 'rgba(249,250,251,0.78)',
    iconPrimary: SKY_BLUE,
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(11,31,54,0.94)',
    navBarBottomDark: DARK_NAV_BOTTOM,
    navActiveGlow: SKY_BLUE,
    iconHighlight: SKY_BLUE,
    shadowColor: 'rgba(0,0,0,0.4)',
    shadowOpacity: 0.24,
    shadowRadius: 10,
    iconCircleBg: 'rgba(56,189,248,0.2)',
    iconCircleBgHighlight: 'rgba(245,158,11,0.18)',
  },
};

/** Returns theme for account; valeter and business support light mode. */
export const getAccountTheme = (accountType: AccountType, mode?: ThemeMode): AccountTheme => {
  if (mode === 'light') {
    if (accountType === 'valeter') return valeterLightTheme;
    if (accountType === 'business') return businessLightTheme;
  }
  return accountThemes[accountType];
};
