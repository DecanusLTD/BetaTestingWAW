export type AccountType = 'valeter' | 'business';

export type ThemeMode = 'light' | 'dark';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
  cardBackground?: string;
  cardBackgroundGradient?: [string, string];
  cardBorder?: string;
  textPrimary?: string;
  textSecondary?: string;
  textOnBackground?: string;
  iconPrimary?: string;
  mode?: ThemeMode;
  statusOnlineCardBg?: string;
  statusOnlineAccent?: string;
  navBarBackground?: string;
  navBarBottomDark?: string;
  navActiveGlow?: string;
  iconHighlight?: string;
  shadowColor?: string;
  shadowOpacity?: number;
  shadowRadius?: number;
  iconCircleBg?: string;
  iconCircleBgHighlight?: string;
}

const SKY_BLUE = '#7DD3FC';
const VALETER_BLUE = '#5B9FC9';
const VALETER_BLUE_ALT = '#4A8BB0';
const VALETER_HEADER_BACKGROUND: [string, string] = ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'];
const VALETER_NAV_BLUE_BORDER = 'rgba(59,130,246,0.5)';
const VALETER_NAV_BLUE_CARD_GRADIENT: [string, string] = ['rgba(37,99,235,0.5)', 'rgba(30,58,138,0.45)'];

/** Light theme shared by valeter/business surfaces. */
const LIGHT_PRIMARY = '#7EB8D4';
const LIGHT_SKY = '#6B9AAA';
const LIGHT_GRADIENT: [string, string] = ['#4A7A8E', '#152238'];
const LIGHT_HEADER_BG = 'rgba(26,47,74,0.2)';
export const valeterLightTheme: AccountTheme = {
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  background: LIGHT_GRADIENT,
  headerBackground: ['rgba(74,122,142,0.48)', 'rgba(21,34,56,0.42)'],
  glassBorder: 'rgba(126,184,212,0.5)',
  cardBorder: 'rgba(126,184,212,0.5)',
  cardBackground: 'rgba(255,255,255,0.06)',
  cardBackgroundGradient: ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)'],
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_SKY,
  textPrimary: '#F1F5F9',
  textSecondary: 'rgba(241,245,249,0.88)',
  textOnBackground: 'rgba(241,245,249,0.7)',
  iconPrimary: LIGHT_PRIMARY,
  mode: 'light',
  statusOnlineCardBg: 'rgba(16,185,129,0.2)',
  statusOnlineAccent: '#10B981',
  navBarBackground: 'rgba(26,47,74,0.22)',
  navBarBottomDark: '#152238',
  navActiveGlow: LIGHT_PRIMARY,
  iconHighlight: LIGHT_PRIMARY,
  shadowColor: 'rgba(0,0,0,0.2)',
  shadowOpacity: 0.18,
  shadowRadius: 6,
  iconCircleBg: 'rgba(126,184,212,0.28)',
  iconCircleBgHighlight: 'rgba(126,184,212,0.22)',
};

export const businessLightTheme: AccountTheme = {
  ...valeterLightTheme,
  primary: LIGHT_PRIMARY,
  primaryAlt: LIGHT_SKY,
  accent: LIGHT_PRIMARY,
  accentAlt: LIGHT_SKY,
  iconPrimary: LIGHT_PRIMARY,
  iconHighlight: LIGHT_PRIMARY,
};

/** Dark surfaces — blue-tinted navy aligned with icon primaries (not pitch black). */
const DARK_BG_TOP = '#0F2847';
const DARK_BG_BOTTOM = '#0A2238';
const DARK_NAV_BOTTOM = '#0C2744';

export const accountThemes: Record<AccountType, AccountTheme> = {
  valeter: {
    primary: VALETER_BLUE,
    primaryAlt: VALETER_BLUE_ALT,
    background: [DARK_BG_TOP, DARK_BG_BOTTOM],
    headerBackground: ['rgba(91,159,201,0.32)', 'rgba(15,40,71,0.92)'],
    glassBorder: 'rgba(91,159,201,0.45)',
    cardBorder: 'rgba(91,159,201,0.35)',
    cardBackgroundGradient: ['rgba(91,159,201,0.14)', 'rgba(15,40,71,0.55)'],
    accent: VALETER_BLUE,
    accentAlt: VALETER_BLUE_ALT,
    textPrimary: '#F9FAFB',
    textSecondary: 'rgba(249,250,251,0.78)',
    iconPrimary: VALETER_BLUE,
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(15,40,71,0.92)',
    navBarBottomDark: DARK_NAV_BOTTOM,
    navActiveGlow: VALETER_BLUE,
    iconHighlight: VALETER_BLUE,
    shadowColor: 'rgba(0,0,0,0.35)',
    shadowOpacity: 0.22,
    shadowRadius: 10,
    iconCircleBg: 'rgba(91,159,201,0.22)',
    iconCircleBgHighlight: 'rgba(91,159,201,0.16)',
  },

  business: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: [DARK_BG_TOP, DARK_BG_BOTTOM],
    headerBackground: ['rgba(125,211,252,0.26)', 'rgba(15,40,71,0.92)'],
    glassBorder: 'rgba(125,211,252,0.48)',
    cardBorder: 'rgba(125,211,252,0.36)',
    cardBackgroundGradient: ['rgba(125,211,252,0.12)', 'rgba(15,40,71,0.55)'],
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    textPrimary: '#F9FAFB',
    textSecondary: 'rgba(249,250,251,0.78)',
    iconPrimary: SKY_BLUE,
    mode: 'dark',
    statusOnlineCardBg: 'rgba(16,185,129,0.2)',
    statusOnlineAccent: '#10B981',
    navBarBackground: 'rgba(15,40,71,0.92)',
    navBarBottomDark: DARK_NAV_BOTTOM,
    navActiveGlow: SKY_BLUE,
    iconHighlight: SKY_BLUE,
    shadowColor: 'rgba(0,0,0,0.35)',
    shadowOpacity: 0.22,
    shadowRadius: 10,
    iconCircleBg: 'rgba(125,211,252,0.22)',
    iconCircleBgHighlight: 'rgba(125,211,252,0.16)',
  },
};

/** Returns theme for account; valeter and business support light mode. */
export const getAccountTheme = (accountType: AccountType, mode?: ThemeMode): AccountTheme => {
  if (mode === 'light') {
    if (accountType === 'valeter') return valeterLightTheme;
    if (accountType === 'business') return businessLightTheme;
  }
  return accountThemes[accountType];
};
