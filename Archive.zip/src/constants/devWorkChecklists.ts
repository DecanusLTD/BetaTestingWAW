/**
 * Living checklist for internal dev/QA: what works, what is partial, what still needs backend wiring.
 * Used by Valeter and Business "Dev work" screens (not shown to end customers in production builds unless they navigate manually).
 */

export type DevWorkStatus = 'works' | 'partial' | 'not_wired';

export type DevWorkItem = {
  title: string;
  detail: string;
  status: DevWorkStatus;
  /** Related app route if any */
  route?: string;
  /** Helpful file path for implementers */
  fileHint?: string;
};

export type DevWorkSection = {
  id: string;
  title: string;
  items: DevWorkItem[];
};

export const VALETER_DEV_WORK_INTRO =
  'This page tracks valeter-facing surfaces: dashboard quick actions, jobs, profile, services, availability, calendar, privacy, and integrations. Status is a snapshot from the codebase—verify against your Supabase project and RLS.';

export const BUSINESS_DEV_WORK_INTRO =
  'This page tracks organisation (business) surfaces: dashboard quick actions, team, locations, bookings, services, inbox, payouts, and profile. Cross-check Stripe Connect and org-scoped tables in your environment.';

export const VALETER_DEV_WORK_SECTIONS: DevWorkSection[] = [
  {
    id: 'dashboard',
    title: 'Dashboard & quick actions',
    items: [
      {
        title: 'Valeter home (PowerfulDriverDashboard)',
        detail:
          'Active job card, map preview, job requests, stats. Depends on bookings/jobs queries and auth session. Confirm statuses match your schema.',
        status: 'partial',
        route: '/valeter/valeter-dashboard',
        fileHint: 'src/components/dashboard/PowerfulDriverDashboard.tsx',
      },
      {
        title: 'Quick action: Availability',
        detail:
          'Working hours + weekly grid persist to `valeter_profiles` (Supabase). Calendar sync toggles and device export live in `bookingCalendarSync` + AsyncStorage settings.',
        status: 'partial',
        route: '/valeter/settings/working-hours',
        fileHint: 'app/valeter/settings/working-hours.tsx, src/services/bookingCalendarSync.ts',
      },
      {
        title: 'Quick action: Radius',
        detail:
          'Service radius writes to `valeter_profiles` (with legacy column fallbacks in code). Requires correct column existence in DB.',
        status: 'partial',
        route: '/valeter/settings/distance-covering',
        fileHint: 'app/valeter/settings/distance-covering.tsx',
      },
      {
        title: 'Quick action: Vehicle',
        detail: 'Vehicle info screen; persistence depends on profile fields / table used in that screen.',
        status: 'partial',
        route: '/valeter/profile/valeter-vehicle-info',
      },
      {
        title: 'Quick action: History',
        detail: 'Wash/history views rely on booking or job history queries—confirm RLS allows valeter to read own rows.',
        status: 'partial',
        route: '/valeter/valeter-wash-history',
      },
    ],
  },
  {
    id: 'jobs',
    title: 'Jobs pipeline',
    items: [
      {
        title: 'Jobs list, accept, tracking, complete',
        detail:
          'Core valeter job flow screens exist; full behaviour depends on bookings table, realtime, and notifications.',
        status: 'partial',
        route: '/valeter/jobs',
        fileHint: 'app/valeter/jobs/',
      },
      {
        title: 'Job chat',
        detail: 'In-job messaging—confirm backend channel + auth match production design.',
        status: 'partial',
        route: '/valeter/jobs/chat',
      },
    ],
  },
  {
    id: 'services',
    title: 'Services, pricing & custom offer',
    items: [
      {
        title: 'Valeter services & tiers',
        detail:
          'Upserts to `valeter_service_settings`; large tier matrix UI. Verify columns and RLS for valeter-owned rows.',
        status: 'partial',
        route: '/valeter/profile/valeter-services',
        fileHint: 'app/valeter/profile/valeter-services.tsx',
      },
      {
        title: 'Self-sufficient / eco toggles',
        detail:
          'Same screen: toggles should persist via the same Supabase upsert path—if a toggle appears broken, check payload shape vs table definition.',
        status: 'partial',
        route: '/valeter/profile/valeter-services',
      },
    ],
  },
  {
    id: 'calendar',
    title: 'Calendar & busy time',
    items: [
      {
        title: 'Export bookings to device calendar',
        detail: 'Uses Expo Calendar + local mapping in AsyncStorage. No server required for export itself.',
        status: 'works',
        fileHint: 'src/services/bookingCalendarSync.ts',
      },
      {
        title: 'Sync external busy blocks to Supabase',
        detail:
          'Requires `valeter_profiles.external_calendar_busy` (see docs/SUPABASE_VALETER_EXTERNAL_CALENDAR_BUSY.sql). Without migration, writes may fail or clash logic may skip.',
        status: 'partial',
        fileHint: 'docs/SUPABASE_VALETER_EXTERNAL_CALENDAR_BUSY.sql, src/services/valeterExternalCalendarBusy.ts',
      },
    ],
  },
  {
    id: 'profile_docs',
    title: 'Profile, documents, verification',
    items: [
      {
        title: 'Valeter profile & menu',
        detail: 'Navigation hub; sub-screens vary in persistence depth.',
        status: 'works',
        route: '/valeter/profile/valeter-profile',
      },
      {
        title: 'Documents upload',
        detail: 'Uses upload services + Supabase storage; depends on buckets and policies.',
        status: 'partial',
        route: '/valeter/profile/valeter-documents',
        fileHint: 'src/services/DocumentUploadService.ts',
      },
      {
        title: 'Verification badges',
        detail: 'Often driven by verification services + profile flags—align with admin review workflow.',
        status: 'partial',
        fileHint: 'src/services/ValeterVerificationService.ts',
      },
    ],
  },
  {
    id: 'notifications_privacy',
    title: 'Notifications, privacy, settings',
    items: [
      {
        title: 'Notification centre',
        detail: 'Reads dismissals / feeds where implemented; some feeds warn if tables (e.g. team_requests) missing.',
        status: 'partial',
        route: '/valeter/notifications',
        fileHint: 'src/services/valeterNotificationDismissals.ts',
      },
      {
        title: 'Notification preferences screen',
        detail:
          'Job/sound/vibration/email toggles persist with AsyncStorage per user only. Push routing and server-side prefs are not implemented here.',
        status: 'not_wired',
        route: '/valeter/profile/valeter-notification-preferences',
      },
    ],
  },
  {
    id: 'extras',
    title: 'Analytics, rewards, support, AI',
    items: [
      {
        title: 'Analytics / earnings views',
        detail: 'Often aggregate or placeholder without full analytics pipeline—treat as partial until metrics API exists.',
        status: 'partial',
        route: '/valeter/valeter-analytics',
      },
      {
        title: 'Rewards / referrals',
        detail: 'Gamification screens; wire to ledger or promos backend when ready.',
        status: 'partial',
        fileHint: 'app/valeter/valeter-rewards-system.tsx',
      },
      {
        title: 'Help & AI chat',
        detail: 'Support copy and AI paths may use static or mock responses—verify API keys and policies before production.',
        status: 'partial',
        route: '/valeter/support/help-support',
      },
    ],
  },
];

export const BUSINESS_DEV_WORK_SECTIONS: DevWorkSection[] = [
  {
    id: 'dashboard',
    title: 'Business dashboard & quick actions',
    items: [
      {
        title: 'Org dashboard shell',
        detail:
          'Live bookings strip, org presence, metrics—data from org-scoped queries. Validate `isOrgUser` gating matches your auth roles.',
        status: 'partial',
        route: '/business/dashboard',
        fileHint: 'app/business/dashboard.tsx',
      },
      {
        title: 'Quick action: Team',
        detail: 'Roster / requests; depends on org membership tables and invite flow.',
        status: 'partial',
        route: '/business/team',
      },
      {
        title: 'Quick action: Locations',
        detail: '`car_wash_locations` (and related) CRUD; confirm multi-location RLS.',
        status: 'partial',
        route: '/business/locations',
      },
      {
        title: 'Quick action: Bookings',
        detail: 'Org booking list and detail; tie to same booking model as valeter/customer.',
        status: 'partial',
        route: '/business/bookings',
      },
      {
        title: 'Quick action: Services',
        detail: 'Location services / menus—align with customer booking service IDs.',
        status: 'partial',
        route: '/business/services',
      },
      {
        title: 'Quick action: Inbox',
        detail: 'Messages / operational inbox—confirm thread storage and push.',
        status: 'partial',
        route: '/business/inbox',
      },
      {
        title: 'Quick action: Payouts',
        detail:
          'Routes to Stripe Connect flow. `payment.tsx` explicitly states frontend preview: no real payout link until backend + Connect onboarding.',
        status: 'not_wired',
        route: '/business/stripe-connect',
        fileHint: 'app/business/stripe-connect.tsx',
      },
    ],
  },
  {
    id: 'bookings_ops',
    title: 'Bookings, tracking, status',
    items: [
      {
        title: 'Booking detail & tracking URLs',
        detail: 'Business-facing booking screens should mirror status enums used by valeter and customer apps.',
        status: 'partial',
        fileHint: 'app/business/bookings/',
      },
      {
        title: 'Team requests (valeter side)',
        detail: 'Valeter Business page consumes `team_requests`. Ensure org can approve and schema matches filters.',
        status: 'partial',
        fileHint: 'docs/BUSINESS_VALETER_PAGE_FOR_DEAN.md',
      },
    ],
  },
  {
    id: 'profile_brand',
    title: 'Business profile & storefront',
    items: [
      {
        title: 'Profile sheets (details, hours)',
        detail: 'Edits should persist to `organizations` / related; verify save handlers hit API.',
        status: 'partial',
        route: '/business/profile',
        fileHint: 'app/business/profile.tsx',
      },
      {
        title: 'Account deletion',
        detail: 'UI may reference delete-account flow—code notes TODO for API when available.',
        status: 'not_wired',
        fileHint: 'app/business/profile.tsx',
      },
    ],
  },
  {
    id: 'settings',
    title: 'Settings & other routes',
    items: [
      {
        title: 'Business settings screen',
        detail: 'Org preferences; confirm each toggle maps to a column or feature flag.',
        status: 'partial',
        route: '/business/settings',
      },
    ],
  },
];
