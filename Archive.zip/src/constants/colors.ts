// Standardized color scheme – toned down (matches IpadFixedWishAWashWithUIFixes light mode UI)
// Reduced brightness, better contrast, muted blue–navy palette

export const colors = {
  // Headers/Footers – toned-down glassmorphism
  headerBg: '#1E3A8A',
  headerBgSecondary: 'rgba(135,206,235,0.12)',
  headerGradient: ['rgba(135,206,235,0.14)', 'rgba(191,219,254,0.1)'],
  headerBorder: 'rgba(148,163,184,0.35)',
  headerText: '#F1F5F9',
  headerSubtext: '#94A3B8',

  // Glassmorphism – reduced intensity
  headerGlassBg: 'rgba(135,206,235,0.12)',
  headerGlassBorder: 'rgba(148,163,184,0.35)',
  headerGlassShadow: 'rgba(135,206,235,0.15)',
  headerGlassOverlay: 'rgba(30,58,138,0.08)',

  // Navigation Tab
  navBg: 'rgba(30,58,138,0.22)',
  navBorder: 'rgba(148,163,184,0.25)',
  navGlassBg: 'rgba(30,58,138,0.22)',
  navGlassBorder: 'rgba(148,163,184,0.25)',
  navActive: '#94A3B8',
  navInactive: '#64748B',

  // Accents – toned down
  accentLight: '#CBD5E1',
  accentMedium: '#94A3B8',
  accentDark: '#1E293B',
  greyLight: '#E2E8F0',
  greyMedium: '#94A3B8',
  greyDark: '#64748B',

  // Surfaces / text on dark
  surfaceOverlay: 'rgba(255,255,255,0.04)',
  surfaceOverlayMid: 'rgba(255,255,255,0.06)',
  surfaceOverlayStrong: 'rgba(255,255,255,0.08)',
  textOnDarkPrimary: '#F1F5F9',
  textOnDarkSecondary: 'rgba(241,245,249,0.88)',
  textOnDarkTertiary: 'rgba(241,245,249,0.7)',

  // Inputs (auth and forms)
  inputPlaceholder: 'rgba(255,255,255,0.5)',
  inputText: '#FFFFFF',
  inputBorder: 'rgba(148,163,184,0.25)',
  inputBorderFocused: 'rgba(135,206,235,0.6)',

  // Background (dark mode – a few shades lighter for premium feel)
  bgPrimary: '#0F2847',
  bgSecondary: '#1E3A5F',

  // Service-specific
  ecoGreen: '#10B981',
  premiumPurple: '#8B5CF6',

  // Legacy / compatibility
  SKY: '#87CEEB',
  BG: '#0F2847',
  LIGHT_SKY: '#F1F5F9',
  ECO_GREEN: '#10B981',
  PREMIUM_PURPLE: '#8B5CF6',

  iconAccent: {
    primary: '#7EB8D4',
    success: '#34D399',
    money: '#FBBF24',
    highlight: '#A78BFA',
    warning: '#FB923C',
    destructive: '#F87171',
  },
};

