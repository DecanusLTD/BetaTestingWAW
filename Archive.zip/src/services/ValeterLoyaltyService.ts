import { supabase } from '../lib/supabase';

export const VALETER_POINTS_PER_JOB = 25;
export const VALETER_POINTS_FIVE_STAR = 50;
export const VALETER_REFERRAL_BONUS_POINTS = 100;
export const VALETER_REFERRAL_CODE_PREFIX = 'WAW-V-';

export type ValeterReward = {
  id: string;
  title: string;
  description: string;
  points: number;
  icon: string;
};

export const VALETER_REWARDS: ValeterReward[] = [
  { id: 'v-bonus-payment', title: 'Bonus Payment', description: '£50 direct bonus to your account', points: 500, icon: 'wallet' },
  { id: 'v-free-training', title: 'Free Training', description: 'Advanced detailing workshop', points: 750, icon: 'school' },
  { id: 'v-premium-tools', title: 'Premium Tools', description: 'Professional grade polisher kit', points: 1000, icon: 'construct' },
  { id: 'v-equipment-upgrade', title: 'Equipment Upgrade', description: 'Complete van setup refresh', points: 1500, icon: 'hardware-chip' },
  { id: 'v-extra-commission', title: 'Extra Commission', description: '+5% on all washes for 30 days', points: 2000, icon: 'wallet' },
];

export type ValeterTierName = 'Bronze' | 'Silver' | 'Gold' | 'Platinum';

export const VALETER_TIER_THRESHOLDS: Record<ValeterTierName, { min: number; max: number | null; color: string; label: string }> = {
  Bronze:   { min: 0,    max: 500,  color: '#D97706', label: 'Getting started' },
  Silver:   { min: 501,  max: 1000, color: '#CBD5E1', label: 'Building momentum' },
  Gold:     { min: 1001, max: 2000, color: '#FBBF24', label: 'Top performer' },
  Platinum: { min: 2001, max: null, color: '#67E8F9', label: 'Elite valeter' },
};

export function getValeterTier(points: number): ValeterTierName {
  if (points >= 2001) return 'Platinum';
  if (points >= 1001) return 'Gold';
  if (points >= 501)  return 'Silver';
  return 'Bronze';
}

export function getValeterTierProgress(points: number): { tier: ValeterTierName; progress: number; pointsToNext: number; nextTier: ValeterTierName | null; color: string } {
  const tier = getValeterTier(points);
  const config = VALETER_TIER_THRESHOLDS[tier];
  const tiers: ValeterTierName[] = ['Bronze', 'Silver', 'Gold', 'Platinum'];
  const idx = tiers.indexOf(tier);
  const nextTier = idx < tiers.length - 1 ? tiers[idx + 1]! : null;

  if (!nextTier || config.max == null) {
    return { tier, progress: 100, pointsToNext: 0, nextTier: null, color: config.color };
  }

  const nextMin = VALETER_TIER_THRESHOLDS[nextTier].min;
  const span = nextMin - config.min;
  const earned = Math.max(0, points - config.min);
  return {
    tier,
    progress: Math.min(100, Math.max(0, (earned / span) * 100)),
    pointsToNext: Math.max(0, nextMin - points),
    nextTier,
    color: config.color,
  };
}

export function generateValeterReferralCode(userId: string): string {
  const compact = userId.replace(/-/g, '').slice(0, 8).toUpperCase();
  return `${VALETER_REFERRAL_CODE_PREFIX}${compact || '00000000'}`;
}

type ProfileRow = { id: string; full_name?: string | null; email?: string | null; referral_code?: string | null; referred_by?: string | null; tier_points?: number | null };

async function fetchProfile(userId: string): Promise<ProfileRow | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, email, referral_code, referred_by, tier_points')
    .eq('id', userId)
    .maybeSingle();
  if (error) console.warn('[ValeterLoyalty] fetchProfile failed:', error.message);
  return (data as ProfileRow | null) ?? null;
}

async function ensureValeterReferralCode(userId: string): Promise<string> {
  const profile = await fetchProfile(userId);
  if (profile?.referral_code) return profile.referral_code.trim().toUpperCase();
  const code = generateValeterReferralCode(userId);
  await supabase.from('profiles').update({ referral_code: code }).eq('id', userId);
  return code;
}

export async function getValeterLoyaltyBalance(userId: string): Promise<{ points: number; completedJobs: number }> {
  const [profile, jobsResult] = await Promise.all([
    fetchProfile(userId),
    supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('valeter_id', userId).eq('status', 'completed'),
  ]);
  const points = Number(profile?.tier_points ?? 0);
  const completedJobs = jobsResult.count ?? 0;
  return { points, completedJobs };
}

export async function getValeterLoyaltyActivity(userId: string): Promise<Array<{ id: string; label: string; pointsLabel: string; date: string; kind: 'earn' | 'redeem' }>> {
  const [jobsRes, redemptionsRes] = await Promise.all([
    supabase
      .from('bookings')
      .select('id, service_name, service_type, loyalty_reward_processed_at, completed_at')
      .eq('valeter_id', userId)
      .not('loyalty_reward_processed_at', 'is', null)
      .order('loyalty_reward_processed_at', { ascending: false })
      .limit(6),
    supabase
      .from('reward_redemptions')
      .select('id, reward_title, points_spent, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(4),
  ]);

  const earned = (jobsRes.data ?? []).map((row: any) => ({
    id: `earn-${row.id}`,
    label: row.service_name || row.service_type || 'Job completed',
    pointsLabel: `+${VALETER_POINTS_PER_JOB}`,
    date: row.loyalty_reward_processed_at || row.completed_at || new Date().toISOString(),
    kind: 'earn' as const,
  }));

  const redeemed = (redemptionsRes.data ?? []).map((row: any) => ({
    id: `redeem-${row.id}`,
    label: row.reward_title || 'Reward redeemed',
    pointsLabel: `-${Number(row.points_spent ?? 0)}`,
    date: row.created_at || new Date().toISOString(),
    kind: 'redeem' as const,
  }));

  return [...earned, ...redeemed]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 8);
}

export async function redeemValeterReward(userId: string, reward: ValeterReward): Promise<number> {
  const profile = await fetchProfile(userId);
  const current = Number(profile?.tier_points ?? 0);
  if (current < reward.points) throw new Error('Insufficient points to redeem this reward.');
  const next = current - reward.points;

  const { error: profileErr } = await supabase.from('profiles').update({ tier_points: next }).eq('id', userId);
  if (profileErr) throw profileErr;

  const { error: insertErr } = await supabase.from('reward_redemptions').insert({
    user_id: userId,
    reward_id: reward.id,
    reward_title: reward.title,
    points_spent: reward.points,
    status: 'redeemed',
  });
  if (insertErr) console.warn('[ValeterLoyalty] redemption insert failed:', insertErr.message);

  return next;
}

export type ValeterReferralRow = { id: string; refereeName: string; status: 'pending' | 'completed' | 'rewarded'; rewardAmount: number; createdAt: string };

export async function getValeterReferralSummary(userId: string): Promise<{ referralCode: string; referredBy: boolean; referrals: ValeterReferralRow[] }> {
  const profile = await fetchProfile(userId);
  const referralCode = profile?.referral_code
    ? profile.referral_code.trim().toUpperCase()
    : await ensureValeterReferralCode(userId);
  const referredBy = !!profile?.referred_by;

  const { data: rows, error } = await supabase
    .from('referrals')
    .select('id, referee_id, status, reward_amount, created_at')
    .eq('referrer_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    console.warn('[ValeterLoyalty] referral query failed:', error.message);
    return { referralCode, referredBy, referrals: [] };
  }

  const refereeIds = (rows ?? []).map((r: any) => r.referee_id);
  const nameMap = new Map<string, string>();

  if (refereeIds.length > 0) {
    const { data: profiles } = await supabase.from('profiles').select('id, full_name, email').in('id', refereeIds);
    (profiles ?? []).forEach((p: any) => {
      nameMap.set(p.id, p.full_name || p.email || 'Wish a Wash member');
    });
  }

  const referrals: ValeterReferralRow[] = (rows ?? []).map((row: any) => ({
    id: row.id,
    refereeName: nameMap.get(row.referee_id) ?? 'Wish a Wash member',
    status: (row.status ?? 'pending') as ValeterReferralRow['status'],
    rewardAmount: Number(row.reward_amount ?? VALETER_REFERRAL_BONUS_POINTS),
    createdAt: row.created_at ?? new Date().toISOString(),
  }));

  return { referralCode, referredBy, referrals };
}

export async function applyValeterReferralCode(userId: string, code: string): Promise<boolean> {
  const normalized = code.trim().toUpperCase();
  if (!normalized) return false;

  const profile = await fetchProfile(userId);
  if (!profile || profile.referred_by) return true;

  const { data: referrer, error } = await supabase
    .from('profiles')
    .select('id, referral_code')
    .eq('referral_code', normalized)
    .maybeSingle();

  if (error || !referrer?.id || referrer.id === userId) return false;

  const { error: updateErr } = await supabase.from('profiles').update({ referred_by: referrer.id }).eq('id', userId);
  if (updateErr) return false;

  await supabase.from('referrals').upsert(
    { referrer_id: referrer.id, referee_id: userId, referral_code: normalized, status: 'pending', reward_amount: VALETER_REFERRAL_BONUS_POINTS },
    { onConflict: 'referee_id', ignoreDuplicates: true },
  );

  return true;
}

export function formatRelativeDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const days = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
  if (days <= 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}
