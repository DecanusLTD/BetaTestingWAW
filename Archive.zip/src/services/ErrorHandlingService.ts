export interface AppError {
  id: string;
  type: 'network' | 'validation' | 'authentication' | 'payment' | 'booking' | 'system';
  message: string;
  userMessage: string;
  timestamp: Date;
  retryCount: number;
  maxRetries: number;
  context?: any;
}

export interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: any;
}

export class ErrorHandlingService {
  private static instance: ErrorHandlingService;
  private errors: Map<string, AppError> = new Map();
  private errorListeners: ((error: AppError) => void)[] = [];

  static getInstance(): ErrorHandlingService {
    if (!ErrorHandlingService.instance) {
      ErrorHandlingService.instance = new ErrorHandlingService();
    }
    return ErrorHandlingService.instance;
  }

  createError(
    type: AppError['type'],
    message: string,
    userMessage: string,
    context?: any,
    maxRetries: number = 3
  ): AppError {
    const error: AppError = {
      id: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      message,
      userMessage,
      timestamp: new Date(),
      retryCount: 0,
      maxRetries,
      context
    };

    this.errors.set(error.id, error);
    this.notifyListeners(error);
    return error;
  }

  handleNetworkError(error: any, operation: string): AppError {
    const userMessage = this.getNetworkErrorMessage(error);
    return this.createError('network', error.message, userMessage, { operation });
  }

  handleValidationError(field: string, value: any, rule: string): AppError {
    const userMessage = this.getValidationErrorMessage(field, rule);
    return this.createError('validation', `Validation failed for ${field}`, userMessage, { field, value, rule });
  }

  handleAuthenticationError(error: any): AppError {
    const userMessage = this.getAuthenticationErrorMessage(error);
    return this.createError('authentication', error.message, userMessage);
  }

  handlePaymentError(error: any, amount: number): AppError {
    const userMessage = this.getPaymentErrorMessage(error);
    return this.createError('payment', error.message, userMessage, { amount });
  }

  handleBookingError(error: any, bookingType: string): AppError {
    const userMessage = this.getBookingErrorMessage(error);
    return this.createError('booking', error.message, userMessage, { bookingType });
  }

  handleSystemError(error: any): AppError {
    const userMessage = this.getSystemErrorMessage(error);
    return this.createError('system', error.message, userMessage);
  }

  retryOperation(errorId: string): boolean {
    const error = this.errors.get(errorId);
    if (!error || error.retryCount >= error.maxRetries) {
      return false;
    }

    error.retryCount++;
    this.errors.set(errorId, error);
    this.notifyListeners(error);
    return true;
  }

  getError(errorId: string): AppError | undefined {
    return this.errors.get(errorId);
  }

  getAllErrors(): AppError[] {
    return Array.from(this.errors.values());
  }

  getErrorsByType(type: AppError['type']): AppError[] {
    return this.getAllErrors().filter(error => error.type === type);
  }

  clearError(errorId: string): boolean {
    return this.errors.delete(errorId);
  }

  clearAllErrors(): void {
    this.errors.clear();
  }

  addErrorListener(listener: (error: AppError) => void): void {
    this.errorListeners.push(listener);
  }

  removeErrorListener(listener: (error: AppError) => void): void {
    const index = this.errorListeners.indexOf(listener);
    if (index > -1) {
      this.errorListeners.splice(index, 1);
    }
  }

  private notifyListeners(error: AppError): void {
    this.errorListeners.forEach(listener => {
      try {
        listener(error);
      } catch (listenerError) {
        console.error('Error in error listener:', listenerError);
      }
    });
  }

  private getNetworkErrorMessage(error: any): string {
    if (error.code === 'NETWORK_ERROR') {
      return 'Please check your internet connection and try again.';
    }
    if (error.code === 'TIMEOUT') {
      return 'The request took too long. Please try again.';
    }
    if (error.status === 404) {
      return 'The requested service is not available.';
    }
    if (error.status >= 500) {
      return 'Our servers are experiencing issues. Please try again later.';
    }
    return 'A network error occurred. Please try again.';
  }

  private getValidationErrorMessage(field: string, rule: string): string {
    const fieldNames: { [key: string]: string } = {
      email: 'Email address',
      password: 'Password',
      phone: 'Phone number',
      registration: 'Registration number',
      make: 'Vehicle make',
      model: 'Vehicle model'
    };

    const fieldName = fieldNames[field] || field;
    
    switch (rule) {
      case 'required':
        return `${fieldName} is required.`;
      case 'email':
        return 'Please enter a valid email address.';
      case 'phone':
        return 'Please enter a valid phone number.';
      case 'minLength':
        return `${fieldName} must be at least 3 characters.`;
      case 'maxLength':
        return `${fieldName} must be less than 50 characters.`;
      case 'registration':
        return 'Please enter a valid UK registration number.';
      default:
        return `${fieldName} is invalid.`;
    }
  }

  private getAuthenticationErrorMessage(error: any): string {
    if (error.code === 'INVALID_CREDENTIALS') {
      return 'Email or password is incorrect.';
    }
    if (error.code === 'ACCOUNT_LOCKED') {
      return 'Your account has been locked. Please contact support.';
    }
    if (error.code === 'EMAIL_NOT_VERIFIED') {
      return 'Please verify your email address before logging in.';
    }
    return 'Authentication failed. Please try again.';
  }

  private getPaymentErrorMessage(error: any): string {
    if (error.code === 'CARD_DECLINED') {
      return 'Your card was declined. Please try a different payment method.';
    }
    if (error.code === 'INSUFFICIENT_FUNDS') {
      return 'Insufficient funds. Please try a different payment method.';
    }
    if (error.code === 'EXPIRED_CARD') {
      return 'Your card has expired. Please update your payment method.';
    }
    if (error.code === 'INVALID_CVC') {
      return 'Invalid security code. Please check and try again.';
    }
    return 'Payment failed. Please try again or use a different payment method.';
  }

  private getBookingErrorMessage(error: any): string {
    if (error.code === 'SERVICE_UNAVAILABLE') {
      return 'This service is currently unavailable in your area.';
    }
    if (error.code === 'NO_VALETERS') {
      return 'No valeters are available at the moment. Please try again later.';
    }
    if (error.code === 'BOOKING_CONFLICT') {
      return 'You have a conflicting booking. Please check your schedule.';
    }
    if (error.code === 'PAYMENT_REQUIRED') {
      return 'Please add a payment method to complete your booking.';
    }
    return 'Booking failed. Please try again.';
  }

  private getSystemErrorMessage(error: any): string {
    return 'Something went wrong. Please try again or contact support if the problem persists.';
  }

  // Retry mechanism for async operations
  async retryAsyncOperation<T>(
    operation: () => Promise<T>,
    maxRetries: number = 3,
    delay: number = 1000
  ): Promise<T> {
    let lastError: any;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        if (attempt === maxRetries) {
          throw error;
        }

        // Exponential backoff
        const waitTime = delay * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }

    throw lastError;
  }

  // Error boundary helper
  static getErrorBoundaryState(error: Error, errorInfo: any): ErrorBoundaryState {
    return {
      hasError: true,
      error,
      errorInfo
    };
  }

  // Log error for analytics
  logError(error: AppError): void {
    // In a real app, this would send to analytics service
    console.error('App Error:', {
      id: error.id,
      type: error.type,
      message: error.message,
      timestamp: error.timestamp,
      context: error.context
    });
  }

  // Get error statistics
  getErrorStats(): {
    total: number;
    byType: { [key in AppError['type']]: number };
    recent: number;
  } {
    const allErrors = this.getAllErrors();
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);

    const byType = allErrors.reduce((acc, error) => {
      acc[error.type] = (acc[error.type] || 0) + 1;
      return acc;
    }, {} as { [key in AppError['type']]: number });

    const recent = allErrors.filter(error => error.timestamp > oneHourAgo).length;

    return {
      total: allErrors.length,
      byType,
      recent
    };
  }
}

export const errorHandlingService = ErrorHandlingService.getInstance();
