import { supabase } from '../lib/supabase';

const BOOKING_PAYMENT_FUNCTION_URL =
  'https://rmhlnfqgjipeawaddwor.supabase.co/functions/v1/booking-extra-charge';

export type BookingPaymentRequestStatus = 'pending' | 'paid' | 'failed' | 'declined' | 'cancelled';

export type BookingPaymentRequestPayload = {
  kind: 'booking_payment_request';
  amount: number;
  currency: string;
  reason: string;
  note?: string;
  platformFee: number;
  valeterShare: number;
  status: BookingPaymentRequestStatus;
  paymentIntentId?: string | null;
  paymentIntentClientSecret?: string | null;
  requestedAt?: string | null;
  paidAt?: string | null;
  requestedBy?: string | null;
  requestedByRole?: string | null;
};

type BookingMessageRow = {
  id: string;
  booking_id: string;
  sender_id: string;
  sender_role: string;
  message_type: string;
  content: string | null;
  media_url: string | null;
  voice_duration_seconds: number | null;
  created_at: string;
};

function nowIso() {
  return new Date().toISOString();
}

export function buildBookingPaymentRequestPayload(params: {
  amount: number;
  currency?: string;
  reason: string;
  note?: string;
  platformFee?: number;
  valeterShare?: number;
  status?: BookingPaymentRequestStatus;
  paymentIntentId?: string | null;
  paymentIntentClientSecret?: string | null;
  requestedBy?: string | null;
  requestedByRole?: string | null;
}): BookingPaymentRequestPayload {
  const amount = Number(params.amount || 0);
  const currency = String(params.currency || 'gbp').toLowerCase();
  const platformFee = Number(params.platformFee ?? Math.max(0, amount * 0.05));
  const valeterShare = Number(params.valeterShare ?? Math.max(0, amount - platformFee));
  return {
    kind: 'booking_payment_request',
    amount,
    currency,
    reason: params.reason.trim(),
    note: params.note?.trim() || undefined,
    platformFee,
    valeterShare,
    status: params.status ?? 'pending',
    paymentIntentId: params.paymentIntentId ?? null,
    paymentIntentClientSecret: params.paymentIntentClientSecret ?? null,
    requestedAt: nowIso(),
    paidAt: null,
    requestedBy: params.requestedBy ?? null,
    requestedByRole: params.requestedByRole ?? null,
  };
}

export function parseBookingPaymentRequestPayload(content?: string | null): BookingPaymentRequestPayload | null {
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as Partial<BookingPaymentRequestPayload>;
    if (parsed?.kind !== 'booking_payment_request') return null;
    const amount = Number(parsed.amount || 0);
    return {
      kind: 'booking_payment_request',
      amount,
      currency: String(parsed.currency || 'gbp').toLowerCase(),
      reason: String(parsed.reason || ''),
      note: parsed.note || undefined,
      platformFee: Number(parsed.platformFee || 0),
      valeterShare: Number(parsed.valeterShare || Math.max(0, amount - Number(parsed.platformFee || 0))),
      status: (parsed.status as BookingPaymentRequestStatus) || 'pending',
      paymentIntentId: parsed.paymentIntentId ?? null,
      paymentIntentClientSecret: parsed.paymentIntentClientSecret ?? null,
      requestedAt: parsed.requestedAt ?? null,
      paidAt: parsed.paidAt ?? null,
      requestedBy: parsed.requestedBy ?? null,
      requestedByRole: parsed.requestedByRole ?? null,
    };
  } catch {
    return null;
  }
}

export async function sendBookingPaymentRequest(params: {
  bookingId: string;
  senderId: string;
  senderRole: string;
  amount: number;
  reason: string;
  note?: string;
  currency?: string;
}): Promise<BookingMessageRow> {
  const payload = buildBookingPaymentRequestPayload({
    amount: params.amount,
    currency: params.currency,
    reason: params.reason,
    note: params.note,
    requestedBy: params.senderId,
    requestedByRole: params.senderRole,
  });

  const { data, error } = await supabase
    .from('booking_messages')
    .insert({
      booking_id: params.bookingId,
      sender_id: params.senderId,
      sender_role: params.senderRole,
      message_type: 'payment_request',
      content: JSON.stringify(payload),
    })
    .select('id, booking_id, sender_id, sender_role, message_type, content, media_url, voice_duration_seconds, created_at')
    .single();

  if (error) throw error;
  if (!data) throw new Error('Failed to send payment request.');
  return data as BookingMessageRow;
}

export async function createBookingPaymentIntent(params: {
  bookingId: string;
  requestMessageId: string;
}): Promise<{ clientSecret: string; paymentIntentId: string; amount: number; currency: string }> {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session?.access_token) {
    throw new Error('No active session.');
  }

  const response = await fetch(BOOKING_PAYMENT_FUNCTION_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.access_token}`,
      apikey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '',
    },
    body: JSON.stringify({
      action: 'create_payment_intent',
      bookingId: params.bookingId,
      requestMessageId: params.requestMessageId,
    }),
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(data?.error || 'Failed to create payment intent.');
  }
  if (!data?.clientSecret || !data?.paymentIntentId) {
    throw new Error('Payment intent response was incomplete.');
  }
  return {
    clientSecret: String(data.clientSecret),
    paymentIntentId: String(data.paymentIntentId),
    amount: Number(data.amount || 0),
    currency: String(data.currency || 'gbp'),
  };
}
