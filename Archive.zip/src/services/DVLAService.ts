// DVLA Vehicle Enquiry Service
// Fetches vehicle details from UK DVLA API using registration number
import { DVLA_CONFIG } from '../config/dvla';

export interface DVLAVehicleDetails {
  registrationNumber: string;
  make: string;
  model?: string;
  colour: string;
  fuelType?: string;
  firstRegistrationDate?: string;
  yearOfManufacture?: number;
  co2Emissions?: number;
  engineCapacity?: number;
  taxStatus?: string;
  motStatus?: string;
  taxDueDate?: string;
  motExpiryDate?: string;
}

export interface DVLAResponse {
  success: boolean;
  data?: DVLAVehicleDetails;
  error?: string;
}

class DVLAService {
  private static instance: DVLAService;
  private apiKey: string | null = null;
  private baseUrl = 'https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles';

  private constructor() {
    // Get API key from config file (which reads from environment or hardcoded value)
    this.apiKey = DVLA_CONFIG.apiKey;
  }

  public static getInstance(): DVLAService {
    if (!DVLAService.instance) {
      DVLAService.instance = new DVLAService();
    }
    return DVLAService.instance;
  }

  /**
   * Set the DVLA API key
   */
  public setApiKey(apiKey: string): void {
    this.apiKey = apiKey;
  }

  /**
   * Validate UK registration number format
   */
  public validateRegistration(registration: string): { isValid: boolean; error?: string } {
    if (!registration || registration.trim().length === 0) {
      return { isValid: false, error: 'Registration number is required' };
    }

    // Remove spaces and convert to uppercase
    const cleanReg = registration.replace(/\s/g, '').toUpperCase();

    // UK registration formats:
    // Current format: AB12 CDE (2 letters, 2 numbers, space, 3 letters)
    // Older formats: A123 BCD, ABC 123D, etc.
    const ukFormats = [
      /^[A-Z]{2}[0-9]{2}[A-Z]{3}$/, // Current format without space
      /^[A-Z]{1}[0-9]{3}[A-Z]{3}$/, // Older format
      /^[A-Z]{3}[0-9]{3}$/, // Very old format
      /^[0-9]{1,3}[A-Z]{1,3}[0-9]{1,3}$/, // Pre-1963 format
    ];

    const isValid = ukFormats.some(format => format.test(cleanReg));

    if (!isValid) {
      return {
        isValid: false,
        error: 'Invalid UK registration format. Please enter a valid registration number.',
      };
    }

    return { isValid: true };
  }

  /**
   * Fetch vehicle details from DVLA API
   */
  public async getVehicleDetails(registration: string): Promise<DVLAResponse> {
    // Validate registration format first
    const validation = this.validateRegistration(registration);
    if (!validation.isValid) {
      return {
        success: false,
        error: validation.error || 'Invalid registration number',
      };
    }

    // Check if API key is set
    if (!this.apiKey) {
      return {
        success: false,
        error: 'DVLA API key not configured. Please configure the API key to fetch vehicle details.',
      };
    }

    try {
      // Clean registration number (remove spaces, uppercase)
      const cleanReg = registration.replace(/\s/g, '').toUpperCase();

      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          registrationNumber: cleanReg,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        let errorMessage = 'Failed to fetch vehicle details';

        if (response.status === 404) {
          errorMessage = 'Vehicle not found. Please check the registration number.';
        } else if (response.status === 401 || response.status === 403) {
          errorMessage = 'DVLA API authentication failed. Please check API key.';
        } else if (response.status === 429) {
          errorMessage = 'Too many requests. Please try again later.';
        } else if (errorData.message) {
          errorMessage = errorData.message;
        }

        return {
          success: false,
          error: errorMessage,
        };
      }

      const data = await response.json();

      // Map DVLA response to our format
      const vehicleDetails: DVLAVehicleDetails = {
        registrationNumber: data.registrationNumber || cleanReg,
        make: data.make || '',
        model: data.model || '',
        colour: data.colour || '',
        fuelType: data.fuelType || '',
        firstRegistrationDate: data.firstRegistrationDate || '',
        yearOfManufacture: data.yearOfManufacture || undefined,
        co2Emissions: data.co2Emissions || undefined,
        engineCapacity: data.engineCapacity || undefined,
        taxStatus: data.taxStatus || '',
        motStatus: data.motStatus || '',
        taxDueDate: data.taxDueDate || '',
        motExpiryDate: data.motExpiryDate || '',
      };

      return {
        success: true,
        data: vehicleDetails,
      };
    } catch (error: any) {
      console.error('[DVLA Service] Error fetching vehicle details:', error);
      return {
        success: false,
        error: error.message || 'Network error. Please check your connection and try again.',
      };
    }
  }


  /**
   * Extract vehicle type from make/model (heuristic approach)
   */
  public inferVehicleType(make: string, model: string): string {
    const makeLower = make.toLowerCase();
    const modelLower = model.toLowerCase();

    // Check for van indicators
    if (
      modelLower.includes('van') ||
      modelLower.includes('transit') ||
      modelLower.includes('vivaro') ||
      modelLower.includes('sprinter') ||
      makeLower.includes('ldv')
    ) {
      return 'Van';
    }

    // Check for motorcycle indicators
    if (
      modelLower.includes('bike') ||
      modelLower.includes('motorcycle') ||
      makeLower.includes('yamaha') ||
      makeLower.includes('honda') ||
      makeLower.includes('kawasaki') ||
      makeLower.includes('suzuki')
    ) {
      return 'Motorcycle';
    }

    // Check for truck/lorry indicators
    if (
      modelLower.includes('truck') ||
      modelLower.includes('lorry') ||
      modelLower.includes('hgv')
    ) {
      return 'Truck';
    }

    // Default to Car
    return 'Car';
  }
}

export default DVLAService.getInstance();

