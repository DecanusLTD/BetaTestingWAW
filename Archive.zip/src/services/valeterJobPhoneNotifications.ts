import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import type { Router } from 'expo-router';
import { supabase } from '../lib/supabase';

let configured = false;
const recentlyNotified = new Map<string, number>();
const DEDUPE_WINDOW_MS = 30_000;

function shouldNotify(key: string): boolean {
  const now = Date.now();
  const last = recentlyNotified.get(key) ?? 0;
  if (now - last < DEDUPE_WINDOW_MS) return false;
  recentlyNotified.set(key, now);

  if (recentlyNotified.size > 200) {
    const cutoff = now - DEDUPE_WINDOW_MS;
    for (const [id, ts] of recentlyNotified.entries()) {
      if (ts < cutoff) recentlyNotified.delete(id);
    }
  }
  return true;
}

export async function preparePhoneNotifications() {
  if (configured) return;

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowAlert: true,
    }),
  });

  const perms = await Notifications.getPermissionsAsync();
  if (!perms.granted) {
    const requested = await Notifications.requestPermissionsAsync();
    if (!requested.granted) return;
  }

  if (Platform.OS === 'android') {
    await Promise.all([
      Notifications.setNotificationChannelAsync('jobs', {
        name: 'Job Alerts',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 200, 250],
        sound: 'default',
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      }),
      Notifications.setNotificationChannelAsync('chat', {
        name: 'Chat Messages',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 180, 120, 180],
        sound: 'default',
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      }),
      Notifications.setNotificationChannelAsync('tracking', {
        name: 'Job Tracking',
        importance: Notifications.AndroidImportance.DEFAULT,
        vibrationPattern: [0, 200, 100, 200],
        sound: 'default',
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      }),
    ]);
  }

  configured = true;
}

export async function areValeterJobAlertsEnabled(userId: string): Promise<boolean> {
  if (!userId) return true;
  try {
    const { data } = await supabase
      .from('valeter_profiles')
      .select('notification_preferences')
      .eq('user_id', userId)
      .maybeSingle();
    const prefs = data?.notification_preferences as { jobAlerts?: boolean } | null;
    if (prefs && typeof prefs.jobAlerts === 'boolean') return prefs.jobAlerts;
  } catch {
    // default on
  }
  return true;
}

async function scheduleLocalNotification(params: {
  key: string;
  title: string;
  body: string;
  channelId: 'jobs' | 'chat' | 'tracking';
  data: Record<string, string>;
}) {
  if (!shouldNotify(params.key)) return;
  await preparePhoneNotifications();

  await Notifications.scheduleNotificationAsync({
    content: {
      title: params.title,
      body: params.body,
      sound: true,
      ...(Platform.OS === 'android' ? { channelId: params.channelId } : {}),
      data: params.data,
    },
    trigger: null,
  });
}

export async function notifyValeterJobRequest(params: {
  bookingId: string;
  serviceName?: string | null;
  price?: number | null;
  locationAddress?: string | null;
  userId?: string | null;
}) {
  const { bookingId, serviceName, price, locationAddress, userId } = params;
  if (!bookingId) return;
  if (userId && !(await areValeterJobAlertsEnabled(userId))) return;

  const service = (serviceName || 'Car Wash').trim();
  const priceText = Number.isFinite(Number(price)) ? `£${Number(price).toFixed(2)}` : null;
  const location = (locationAddress || '').trim();
  const bodyParts = [service, priceText, location].filter(Boolean);

  await scheduleLocalNotification({
    key: `job:${bookingId}`,
    title: 'New Job Request',
    body: bodyParts.length > 0 ? bodyParts.join(' • ') : 'A new booking is waiting for your response.',
    channelId: 'jobs',
    data: {
      type: 'job_request',
      bookingId,
      route: '/valeter/valeter-dashboard',
    },
  });
}

export async function notifyValeterChatMessage(params: {
  bookingId: string;
  messageId: string;
  preview?: string | null;
  senderLabel?: string | null;
}) {
  const { bookingId, messageId, preview, senderLabel } = params;
  if (!bookingId || !messageId) return;

  const body = (preview || 'New message').trim().slice(0, 140);
  await scheduleLocalNotification({
    key: `chat:${messageId}`,
    title: senderLabel?.trim() || 'New message',
    body,
    channelId: 'chat',
    data: {
      type: 'chat_message',
      bookingId,
      route: '/valeter/jobs/chat',
    },
  });
}

const TRACKING_STATUS_COPY: Record<string, { title: string; body: string }> = {
  pending_payment: {
    title: 'Waiting for payment',
    body: 'Customer needs to complete payment for this job.',
  },
  confirmed: {
    title: 'Job confirmed',
    body: 'Payment received — this job is confirmed.',
  },
  scheduled: {
    title: 'Job scheduled',
    body: 'This booking is on your schedule.',
  },
  cancelled: {
    title: 'Job cancelled',
    body: 'A job assigned to you was cancelled.',
  },
  completed: {
    title: 'Job completed',
    body: 'This job is marked complete.',
  },
  en_route: {
    title: 'En route',
    body: 'Tracking updated — heading to the customer.',
  },
  arrived: {
    title: 'Arrived',
    body: 'Tracking updated — you’ve arrived.',
  },
  in_progress: {
    title: 'Service in progress',
    body: 'Tracking updated — wash in progress.',
  },
};

export async function notifyValeterTrackingUpdate(params: {
  bookingId: string;
  status: string;
  serviceName?: string | null;
}) {
  const { bookingId, status, serviceName } = params;
  if (!bookingId || !status) return;
  // Job offers use the dedicated job-request alert.
  if (status === 'pending_valeter_acceptance') return;

  const copy = TRACKING_STATUS_COPY[status];
  if (!copy) return;

  const service = (serviceName || '').trim();
  await scheduleLocalNotification({
    key: `tracking:${bookingId}:${status}`,
    title: copy.title,
    body: service ? `${service} — ${copy.body}` : copy.body,
    channelId: 'tracking',
    data: {
      type: 'tracking_update',
      bookingId,
      status,
      route: '/valeter/valeter-dashboard',
    },
  });
}

export function openValeterNotificationRoute(
  router: Router,
  data: Record<string, unknown> | undefined
) {
  if (!data || typeof data !== 'object') return;
  const bookingId =
    (typeof data.bookingId === 'string' && data.bookingId) ||
    (typeof data.booking_id === 'string' && data.booking_id) ||
    '';
  const type = typeof data.type === 'string' ? data.type : '';

  if (type === 'chat_message' && bookingId) {
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId } } as any);
    return;
  }

  if (type === 'job_request') {
    router.push('/valeter/valeter-dashboard' as any);
    return;
  }

  if ((type === 'tracking_update' || bookingId) && bookingId) {
    router.push({
      pathname: '/valeter/valeter-dashboard',
      params: { trackingJobId: bookingId },
    } as any);
    return;
  }

  const route = typeof data.route === 'string' ? data.route : '';
  if (route) router.push(route as any);
}

export function subscribeValeterNotificationResponses(router: Router): () => void {
  const sub = Notifications.addNotificationResponseReceivedListener((response) => {
    const data = response.notification.request.content.data as Record<string, unknown> | undefined;
    openValeterNotificationRoute(router, data);
  });
  return () => sub.remove();
}
