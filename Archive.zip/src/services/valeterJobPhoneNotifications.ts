import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

let configured = false;
const recentlyNotified = new Map<string, number>();
const DEDUPE_WINDOW_MS = 30_000;

function shouldNotify(bookingId: string): boolean {
  const now = Date.now();
  const last = recentlyNotified.get(bookingId) ?? 0;
  if (now - last < DEDUPE_WINDOW_MS) return false;
  recentlyNotified.set(bookingId, now);

  // Keep map bounded
  if (recentlyNotified.size > 200) {
    const cutoff = now - DEDUPE_WINDOW_MS;
    for (const [id, ts] of recentlyNotified.entries()) {
      if (ts < cutoff) recentlyNotified.delete(id);
    }
  }
  return true;
}

export async function preparePhoneNotifications() {
  if (configured) return;

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });

  const perms = await Notifications.getPermissionsAsync();
  if (!perms.granted) {
    const requested = await Notifications.requestPermissionsAsync();
    if (!requested.granted) return;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('jobs', {
      name: 'Job Alerts',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 200, 250],
      sound: 'default',
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    });
  }

  configured = true;
}

export async function notifyValeterJobRequest(params: {
  bookingId: string;
  serviceName?: string | null;
  price?: number | null;
  locationAddress?: string | null;
}) {
  const { bookingId, serviceName, price, locationAddress } = params;
  if (!bookingId || !shouldNotify(bookingId)) return;

  await preparePhoneNotifications();

  const title = 'New Job Request';
  const service = (serviceName || 'Car Wash').trim();
  const priceText = Number.isFinite(Number(price)) ? `£${Number(price).toFixed(2)}` : null;
  const location = (locationAddress || '').trim();

  const bodyParts = [service, priceText, location].filter(Boolean);
  const body = bodyParts.length > 0 ? bodyParts.join(' • ') : 'A new booking is waiting for your response.';

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: true,
      ...(Platform.OS === 'android' ? { channelId: 'jobs' } : {}),
      data: {
        type: 'job_request',
        bookingId,
        route: '/valeter/jobs',
      },
    },
    trigger: null,
  });
}
