import * as Linking from 'expo-linking';
import { supabase, supabaseAnonKey, supabaseUrl } from '../lib/supabase';

const STRIPE_CONNECT_FUNCTION_URL = `${supabaseUrl}/functions/v1/stripe-connect`;

export type StripeConnectSyncResult = {
  stripeConnectStatus: 'not_started' | 'in_progress' | 'completed' | 'restricted' | 'rejected';
  stripeAccountId: string | null;
  detailsSubmitted?: boolean;
  chargesEnabled?: boolean;
  payoutsEnabled?: boolean;
};

function getReturnUrl() {
  return Linking.createURL('/valeter/stripe-connect', { queryParams: { stripe_return: '1' } });
}

function getRefreshUrl() {
  return Linking.createURL('/valeter/stripe-connect', { queryParams: { stripe_refresh: '1' } });
}

export function getStripeAppReturnDeepLink() {
  return Linking.createURL('/valeter/stripe-connect', { queryParams: { stripe_return: '1' } });
}

export function getStripeAppRefreshDeepLink() {
  return Linking.createURL('/valeter/stripe-connect', { queryParams: { stripe_refresh: '1' } });
}

async function invokeStripeConnect(body: Record<string, unknown>) {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session?.access_token) {
    throw new Error('No active session for Stripe Connect request.');
  }

  const response = await fetch(STRIPE_CONNECT_FUNCTION_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.access_token}`,
      apikey: supabaseAnonKey,
    },
    body: JSON.stringify(body),
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const diagnostics = data?.diagnostics
      ? ` diagnostics=${JSON.stringify(data.diagnostics)}`
      : '';
    throw new Error(`${data?.error || 'Stripe Connect request failed.'}${diagnostics}`);
  }

  return data;
}

export const stripeConnectService = {
  async createOnboardingLink(): Promise<{ url: string; stripeAccountId: string }> {
    const data = await invokeStripeConnect({
      action: 'create_onboarding_link',
      returnUrl: getReturnUrl(),
      refreshUrl: getRefreshUrl(),
    });
    if (!data?.url || !data?.stripeAccountId) {
      throw new Error('Stripe onboarding link was not returned by backend.');
    }

    return { url: data.url as string, stripeAccountId: data.stripeAccountId as string };
  },

  async syncStatusFromStripe(): Promise<StripeConnectSyncResult> {
    const data = await invokeStripeConnect({
      action: 'get_status',
    });
    if (!data) {
      throw new Error('No Stripe status response from backend.');
    }

    return {
      stripeConnectStatus: data.stripeConnectStatus,
      stripeAccountId: data.stripeAccountId ?? null,
      detailsSubmitted: data.detailsSubmitted,
      chargesEnabled: data.chargesEnabled,
      payoutsEnabled: data.payoutsEnabled,
    };
  },
};
