import { supabase } from '../lib/supabase';

export type TermsAccountType = 'business' | 'valeter';
export type TermsStatus = 'pending' | 'accepted' | 'declined';
export type TermsMode = 'mobile_based' | 'physical';
export type QuestionnaireDetails = {
  questionnaire_type?: string;
  account_mode?: TermsMode;
  keepCustomers?: 'yes' | 'no' | null;
  keepCalendarAvailability?: 'yes' | 'no' | null;
  shareContactDetails?: 'yes' | 'no' | null;
  hasBusinessInsurance?: 'yes' | 'no' | null;
  insuranceProvider?: string;
  insuranceType?: string;
  policyNumber?: string;
  [key: string]: any;
};

export type TermsRecord = {
  status: TermsStatus;
  version: string | null;
  acceptedAt: string | null;
  declinedAt: string | null;
  details: QuestionnaireDetails;
};

const DEFAULT_RECORD: TermsRecord = {
  status: 'pending',
  version: null,
  acceptedAt: null,
  declinedAt: null,
  details: {},
};

const TABLE_BY_TYPE: Record<TermsAccountType, string> = {
  business: 'profiles',
  valeter: 'valeter_profiles',
};

const USER_ID_COLUMN_BY_TYPE: Record<TermsAccountType, string> = {
  business: 'id',
  valeter: 'user_id',
};

function tableClient(accountType: TermsAccountType) {
  return supabase.from(TABLE_BY_TYPE[accountType] as any) as any;
}

const nowIso = () => new Date().toISOString();

async function writeAcceptedQuestionnaire(
  accountType: TermsAccountType,
  userId: string,
  termsVersion: string,
  details: Record<string, any>
) {
  const now = nowIso();
  const { error } = await tableClient(accountType)
    .update({
      terms_status: 'accepted',
      terms_version: termsVersion,
      terms_accepted_at: now,
      terms_declined_at: null,
      terms_details: {
        ...(details || {}),
        accepted_at: now,
        version: termsVersion,
        account_type: accountType,
        questionnaire_saved_at: now,
        questionnaire_type: details?.questionnaire_type || 'account_setup_questionnaire',
      },
    } as any)
    .eq(USER_ID_COLUMN_BY_TYPE[accountType] as any, userId);

  if (error) throw error;
}

const normalize = (row: any): TermsRecord => ({
  status: (row?.terms_status || 'pending') as TermsStatus,
  version: row?.terms_version ?? null,
  acceptedAt: row?.terms_accepted_at ?? null,
  declinedAt: row?.terms_declined_at ?? null,
  details: row?.terms_details && typeof row.terms_details === 'object' ? row.terms_details : {},
});

export const termsAgreementService = {
  async load(accountType: TermsAccountType, userId: string): Promise<TermsRecord> {
    const { data, error } = await tableClient(accountType)
      .select('terms_status,terms_version,terms_accepted_at,terms_declined_at,terms_details')
      .eq(USER_ID_COLUMN_BY_TYPE[accountType] as any, userId)
      .maybeSingle();

    if (error) throw error;
    if (!data) return DEFAULT_RECORD;
    return normalize(data);
  },

  async accept(
    accountType: TermsAccountType,
    userId: string,
    termsVersion: string,
    details: Record<string, any> = {}
  ): Promise<void> {
    await writeAcceptedQuestionnaire(accountType, userId, termsVersion, details);
  },

  async saveQuestionnaire(
    accountType: TermsAccountType,
    userId: string,
    termsVersion: string,
    details: Record<string, any> = {}
  ): Promise<void> {
    await writeAcceptedQuestionnaire(accountType, userId, termsVersion, details);
  },

  async decline(
    accountType: TermsAccountType,
    userId: string,
    termsVersion: string,
    details: Record<string, any> = {}
  ): Promise<void> {
    const now = nowIso();
    const { error } = await tableClient(accountType)
      .update({
        terms_status: 'declined',
        terms_version: termsVersion,
        terms_declined_at: now,
        terms_details: {
          ...(details || {}),
          declined_at: now,
          version: termsVersion,
          account_type: accountType,
        },
      } as any)
      .eq(USER_ID_COLUMN_BY_TYPE[accountType] as any, userId);

    if (error) throw error;
  },
};
