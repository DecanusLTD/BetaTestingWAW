export interface UploadedDocument {
  id: string;
  userId: string;
  type: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  uploadDate: Date;
  status: 'pending' | 'uploading' | 'completed' | 'failed' | 'verified' | 'rejected';
  progress: number;
  verificationNotes?: string;
  documentUrl?: string;
}

export interface UploadProgress {
  documentId: string;
  progress: number;
  status: 'uploading' | 'completed' | 'failed';
  error?: string;
}

export interface CameraOptions {
  quality: number;
  allowsEditing: boolean;
  aspect: [number, number];
  mediaTypes: 'photo' | 'video' | 'all';
}

export interface FilePickerOptions {
  type: 'document' | 'image' | 'all';
  multiple: boolean;
  maxFiles: number;
  maxSize: number; // in bytes
}

export class DocumentUploadService {
  private static instance: DocumentUploadService;
  private uploads: Map<string, UploadedDocument> = new Map();
  private uploadProgress: Map<string, UploadProgress> = new Map();
  private listeners: ((progress: UploadProgress) => void)[] = [];

  static getInstance(): DocumentUploadService {
    if (!DocumentUploadService.instance) {
      DocumentUploadService.instance = new DocumentUploadService();
    }
    return DocumentUploadService.instance;
  }

  // Simulate camera access
  async takePhoto(options: Partial<CameraOptions> = {}): Promise<UploadedDocument | null> {
    const defaultOptions: CameraOptions = {
      quality: 0.8,
      allowsEditing: true,
      aspect: [1, 1],
      mediaTypes: 'photo',
      ...options
    };

    try {
      // Simulate camera delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const document: UploadedDocument = {
        id: `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        userId: 'current_user', // Will be set by calling code
        type: 'profile_photo',
        fileName: `profile_photo_${Date.now()}.jpg`,
        filePath: `file:///photos/profile_photo_${Date.now()}.jpg`,
        fileSize: 1024 * 1024, // 1MB
        mimeType: 'image/jpeg',
        uploadDate: new Date(),
        status: 'completed',
        progress: 100,
        documentUrl: `https://example.com/photos/profile_photo_${Date.now()}.jpg`
      };

      this.uploads.set(document.id, document);
      return document;
    } catch (error) {
      console.error('Camera error:', error);
      return null;
    }
  }

  // Pick document using actual file picker
  async pickDocument(options: Partial<FilePickerOptions> = {}): Promise<UploadedDocument[]> {
    const defaultOptions: FilePickerOptions = {
      type: 'document',
      multiple: false,
      maxFiles: 1,
      maxSize: 10 * 1024 * 1024, // 10MB
      ...options
    };

    try {
      // TODO: Implement actual file picker using expo-document-picker or similar
      // This should open the device's file picker and return selected files
      console.warn('Document picker not yet implemented - needs expo-document-picker integration');
      return [];
    } catch (error) {
      console.error('File picker error:', error);
      return [];
    }
  }

  // Upload document with progress tracking
  async uploadDocument(
    document: UploadedDocument,
    onProgress?: (progress: number) => void
  ): Promise<boolean> {
    try {
      // Update status to uploading
      document.status = 'uploading';
      document.progress = 0;
      this.uploads.set(document.id, document);

      // Simulate upload progress
      for (let progress = 0; progress <= 100; progress += 10) {
        document.progress = progress;
        this.uploads.set(document.id, document);
        
        const uploadProgress: UploadProgress = {
          documentId: document.id,
          progress,
          status: progress === 100 ? 'completed' : 'uploading'
        };
        
        this.uploadProgress.set(document.id, uploadProgress);
        this.notifyListeners(uploadProgress);
        
        if (onProgress) {
          onProgress(progress);
        }
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      // Update final status
      document.status = 'completed';
      document.progress = 100;
      this.uploads.set(document.id, document);
      
      return true;
    } catch (error) {
      console.error('Upload error:', error);
      document.status = 'failed';
      this.uploads.set(document.id, document);
      
      const uploadProgress: UploadProgress = {
        documentId: document.id,
        progress: 0,
        status: 'failed',
        error: error.message
      };
      
      this.uploadProgress.set(document.id, uploadProgress);
      this.notifyListeners(uploadProgress);
      
      return false;
    }
  }

  // Upload multiple documents
  async uploadMultipleDocuments(
    documents: UploadedDocument[],
    onProgress?: (documentId: string, progress: number) => void
  ): Promise<{ success: string[], failed: string[] }> {
    const success: string[] = [];
    const failed: string[] = [];

    for (const document of documents) {
      const result = await this.uploadDocument(document, (progress) => {
        if (onProgress) {
          onProgress(document.id, progress);
        }
      });
      
      if (result) {
        success.push(document.id);
      } else {
        failed.push(document.id);
      }
    }

    return { success, failed };
  }

  // Get user's uploaded documents
  getUserDocuments(userId: string): UploadedDocument[] {
    return Array.from(this.uploads.values()).filter(doc => doc.userId === userId);
  }

  // Get document by ID
  getDocument(documentId: string): UploadedDocument | undefined {
    return this.uploads.get(documentId);
  }

  // Get upload progress
  getUploadProgress(documentId: string): UploadProgress | undefined {
    return this.uploadProgress.get(documentId);
  }

  // Delete document
  deleteDocument(documentId: string): boolean {
    const document = this.uploads.get(documentId);
    if (document) {
      this.uploads.delete(documentId);
      this.uploadProgress.delete(documentId);
      return true;
    }
    return false;
  }

  // Update document status (for verification)
  updateDocumentStatus(documentId: string, status: UploadedDocument['status'], notes?: string): boolean {
    const document = this.uploads.get(documentId);
    if (document) {
      document.status = status;
      if (notes) {
        document.verificationNotes = notes;
      }
      this.uploads.set(documentId, document);
      return true;
    }
    return false;
  }

  // Add progress listener
  addProgressListener(listener: (progress: UploadProgress) => void): void {
    this.listeners.push(listener);
  }

  // Remove progress listener
  removeProgressListener(listener: (progress: UploadProgress) => void): void {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }

  // Validate file
  validateFile(file: any, maxSize: number = 10 * 1024 * 1024): { valid: boolean; error?: string } {
    if (!file) {
      return { valid: false, error: 'No file provided' };
    }

    if (file.size > maxSize) {
      return { valid: false, error: `File size exceeds ${maxSize / (1024 * 1024)}MB limit` };
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      return { valid: false, error: 'File type not supported' };
    }

    return { valid: true };
  }

  // Get file size in human readable format
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Get MIME type from file extension
  private getMimeType(extension: string): string {
    const mimeTypes: { [key: string]: string } = {
      'pdf': 'application/pdf',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'doc': 'application/msword',
      'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    };
    return mimeTypes[extension.toLowerCase()] || 'application/octet-stream';
  }

  private notifyListeners(progress: UploadProgress): void {
    this.listeners.forEach(listener => {
      try {
        listener(progress);
      } catch (error) {
        console.error('Error in upload progress listener:', error);
      }
    });
  }

  // Clear all uploads (for testing)
  clearAll(): void {
    this.uploads.clear();
    this.uploadProgress.clear();
  }
}

export const documentUploadService = DocumentUploadService.getInstance();
