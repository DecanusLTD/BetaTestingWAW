// src/services/HapticFeedbackService.ts
import * as Haptics from 'expo-haptics';

type Impact = 'light' | 'medium' | 'heavy' | 'soft' | 'rigid';
type NotificationKind = 'success' | 'warning' | 'error';
type HapticKind = Impact | NotificationKind;

const map: Record<Impact, Haptics.ImpactFeedbackStyle> = {
  light: Haptics.ImpactFeedbackStyle.Light,
  medium: Haptics.ImpactFeedbackStyle.Medium,
  heavy: Haptics.ImpactFeedbackStyle.Heavy,
  soft: Haptics.ImpactFeedbackStyle.Soft,
  rigid: Haptics.ImpactFeedbackStyle.Rigid,
};

export async function hapticFeedback(kind: HapticKind = 'light') {
  if (kind === 'success') {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    return;
  }
  if (kind === 'warning') {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    return;
  }
  if (kind === 'error') {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    return;
  }
  await Haptics.impactAsync(map[kind]);
}
