import { supabase } from '../lib/supabase';

/**
 * Lifetime stats (total jobs, rating, earnings) are stored on valeter_profiles so they
 * are not lost when the valeter deletes job history. Run this SQL once to add columns:
 *
 * ALTER TABLE valeter_profiles
 *   ADD COLUMN IF NOT EXISTS total_jobs_completed INTEGER DEFAULT 0,
 *   ADD COLUMN IF NOT EXISTS total_earnings DECIMAL(12,2) DEFAULT 0,
 *   ADD COLUMN IF NOT EXISTS rating_sum DECIMAL(10,2) DEFAULT 0,
 *   ADD COLUMN IF NOT EXISTS rating_count INTEGER DEFAULT 0;
 */

export interface ValeterPerformanceStats {
  totalJobs: number;
  experienceMonths: number;
  averageRating: number;
  totalEarnings: number;
  jobsThisMonth: number;
  customerReviews: number;
  onTimePercentage: number;
  cancellationRate: number;
}

export class ValeterStatsService {
  /**
   * Fetch performance stats. Uses persistent lifetime stats from valeter_profiles
   * (total_jobs_completed, total_earnings, rating_sum, rating_count) so that jobs
   * completed and rating are not lost when job history is deleted.
   */
  static async getValeterStats(userId: string): Promise<ValeterPerformanceStats> {
    try {
      // Fetch valeter profile including lifetime stats (if columns exist)
      const { data: valeterProfile, error: profileError } = await supabase
        .from('valeter_profiles')
        .select('created_at, total_jobs_completed, total_earnings, rating_sum, rating_count')
        .eq('user_id', userId)
        .maybeSingle();

      if (profileError || !valeterProfile) {
        return this.getDefaultStats();
      }

      // Fetch bookings for jobs-this-month, on-time %, cancellation %, and to backfill lifetime stats
      const { data: jobs, error: jobsError } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', userId)
        .in('status', ['completed', 'cancelled']);

      if (jobsError) throw jobsError;

      const completedJobs = jobs?.filter(job => job.status === 'completed') || [];
      const cancelledJobs = jobs?.filter(job => job.status === 'cancelled') || [];
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      // Lifetime stats: prefer stored values so deleting history doesn't reduce them
      const storedTotalJobs = (valeterProfile as any).total_jobs_completed;
      const storedTotalEarnings = (valeterProfile as any).total_earnings;
      const storedRatingSum = (valeterProfile as any).rating_sum;
      const storedRatingCount = (valeterProfile as any).rating_count;

      const computedTotalJobs = completedJobs.length;
      const computedTotalEarnings = completedJobs.reduce((sum, job) => sum + (Number(job.price) || 0), 0);
      const jobsWithRatings = completedJobs.filter(job => job.rating != null);
      const computedRatingCount = jobsWithRatings.length;
      const computedRatingSum = jobsWithRatings.reduce((sum, job) => sum + (Number(job.rating) || 0), 0);

      let totalJobs: number;
      let totalEarnings: number;
      let averageRating: number;

      if (typeof storedTotalJobs === 'number' && storedTotalJobs >= 0) {
        totalJobs = storedTotalJobs;
      } else {
        totalJobs = computedTotalJobs;
        await this.backfillTotalJobsAndEarnings(userId, computedTotalJobs, computedTotalEarnings);
      }

      if (typeof storedTotalEarnings === 'number' && storedTotalEarnings >= 0) {
        totalEarnings = Math.round(storedTotalEarnings);
      } else {
        totalEarnings = Math.round(computedTotalEarnings);
        await this.backfillTotalJobsAndEarnings(userId, computedTotalJobs, computedTotalEarnings);
      }

      if (typeof storedRatingCount === 'number' && storedRatingCount > 0 && typeof storedRatingSum === 'number') {
        averageRating = Math.round((storedRatingSum / storedRatingCount) * 10) / 10;
      } else {
        averageRating = computedRatingCount > 0
          ? Math.round((computedRatingSum / computedRatingCount) * 10) / 10
          : 0;
        if (computedRatingCount > 0) {
          await this.backfillRating(userId, computedRatingSum, computedRatingCount);
        }
      }

      // If we have more rating data from current bookings than stored, update stored (never decrease)
      const storedCount = typeof storedRatingCount === 'number' ? storedRatingCount : 0;
      if (computedRatingCount > storedCount && computedRatingCount > 0) {
        await this.backfillRating(userId, computedRatingSum, computedRatingCount);
        averageRating = Math.round((computedRatingSum / computedRatingCount) * 10) / 10;
      }

      const experienceMonths = Math.max(
        1,
        Math.round((now.getTime() - new Date(valeterProfile?.created_at || Date.now()).getTime()) / (1000 * 60 * 60 * 24 * 30))
      );

      const jobsThisMonth = completedJobs.filter(job => {
        const jobDate = new Date(job.completed_at || job.created_at);
        return jobDate >= firstDayOfMonth;
      }).length;

      const onTimeJobs = completedJobs.filter(job => {
        if (!job.scheduled_at || !job.completed_at) return true;
        const scheduledTime = new Date(job.scheduled_at);
        const completedTime = new Date(job.completed_at);
        const diffMinutes = (completedTime.getTime() - scheduledTime.getTime()) / (1000 * 60);
        return Math.abs(diffMinutes) <= 15;
      }).length;

      const onTimePercentage = totalJobs > 0 ? Math.round((onTimeJobs / totalJobs) * 100) : 100;
      const totalBookings = jobs?.length || 0;
      const cancellationRate = totalBookings > 0 ? Math.round((cancelledJobs.length / totalBookings) * 100) : 0;

      return {
        totalJobs,
        experienceMonths,
        averageRating,
        totalEarnings,
        jobsThisMonth,
        customerReviews: typeof storedRatingCount === 'number' ? storedRatingCount : computedRatingCount,
        onTimePercentage,
        cancellationRate,
      };
    } catch (error) {
      console.error('Error fetching valeter stats:', error);
      return this.getDefaultStats();
    }
  }

  private static getDefaultStats(): ValeterPerformanceStats {
    return {
      totalJobs: 0,
      experienceMonths: 1,
      averageRating: 0,
      totalEarnings: 0,
      jobsThisMonth: 0,
      customerReviews: 0,
      onTimePercentage: 100,
      cancellationRate: 0,
    };
  }

  private static async backfillTotalJobsAndEarnings(userId: string, totalJobs: number, totalEarnings: number): Promise<void> {
    try {
      await supabase
        .from('valeter_profiles')
        .update({
          total_jobs_completed: totalJobs,
          total_earnings: totalEarnings,
        } as any)
        .eq('user_id', userId);
    } catch (e) {
      console.warn('ValeterStatsService backfill total_jobs/earnings failed (columns may not exist):', e);
    }
  }

  private static async backfillRating(userId: string, ratingSum: number, ratingCount: number): Promise<void> {
    try {
      await supabase
        .from('valeter_profiles')
        .update({
          rating_sum: ratingSum,
          rating_count: ratingCount,
        } as any)
        .eq('user_id', userId);
    } catch (e) {
      console.warn('ValeterStatsService backfill rating failed (columns may not exist):', e);
    }
  }

  static async updateEarnings(userId: string, amount: number): Promise<void> {
    try {
      const { data } = await supabase.from('valeter_profiles').select('total_earnings').eq('user_id', userId).maybeSingle();
      const current = (data as any)?.total_earnings ?? 0;
      await supabase.from('valeter_profiles').update({ total_earnings: Number(current) + amount } as any).eq('user_id', userId);
    } catch (e) {
      console.warn('ValeterStatsService updateEarnings failed:', e);
    }
  }

  /**
   * Call when a job is marked completed. Increments total_jobs_completed and adds
   * job price to total_earnings on valeter_profiles so these stats persist if job history is deleted.
   * Does not update the booking; the caller should set status and completed_at on the booking.
   */
  static async recordJobCompletion(userId: string, bookingId: string, _isOnTime?: boolean): Promise<void> {
    try {
      const { data: booking, error: fetchErr } = await supabase
        .from('bookings')
        .select('price')
        .eq('id', bookingId)
        .eq('valeter_id', userId)
        .maybeSingle();

      if (fetchErr || !booking) return;

      const price = Number(booking.price) || 0;

      const { data: profile } = await supabase
        .from('valeter_profiles')
        .select('total_jobs_completed, total_earnings')
        .eq('user_id', userId)
        .maybeSingle();

      const currentJobs = (profile as any)?.total_jobs_completed ?? 0;
      const currentEarnings = (profile as any)?.total_earnings ?? 0;

      await supabase
        .from('valeter_profiles')
        .update({
          total_jobs_completed: currentJobs + 1,
          total_earnings: currentEarnings + price,
        } as any)
        .eq('user_id', userId);
    } catch (e) {
      console.warn('ValeterStatsService recordJobCompletion failed:', e);
    }
  }

  /**
   * Call when a customer submits a rating for a completed job. Updates rating_sum and
   * rating_count on valeter_profiles so average rating persists when job history is deleted.
   */
  static async recordRating(userId: string, rating: number): Promise<void> {
    try {
      const { data } = await supabase
        .from('valeter_profiles')
        .select('rating_sum, rating_count')
        .eq('user_id', userId)
        .maybeSingle();

      const sum = (data as any)?.rating_sum ?? 0;
      const count = (data as any)?.rating_count ?? 0;

      await supabase
        .from('valeter_profiles')
        .update({
          rating_sum: sum + rating,
          rating_count: count + 1,
        } as any)
        .eq('user_id', userId);
    } catch (e) {
      console.warn('ValeterStatsService recordRating failed:', e);
    }
  }
}