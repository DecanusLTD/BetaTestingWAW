import { supabase } from '../lib/supabase';

export interface WeatherData {
  condition: 'sunny' | 'cloudy' | 'rainy' | 'snowy';
  temperature: number;
  humidity: number;
  windSpeed: number;
  isGoodForWash: boolean;
  confidence: number;
}

export interface SchedulingSuggestion {
  date: string;
  timeSlot: string;
  confidence: number;
  reason: string;
  weatherScore: number;
  demandScore: number;
  overallScore: number;
}

export interface DemandForecast {
  date: string;
  expectedDemand: 'low' | 'medium' | 'high';
  confidence: number;
  recommendedPriceMultiplier: number;
  peakHours: string[];
}

/**
 * AI-powered scheduling service that suggests optimal booking times
 * based on weather, historical demand, and valeter availability
 */
export class AISchedulingService {
  /**
   * Get weather-based scheduling suggestions
   */
  static async getSchedulingSuggestions(
    location: { latitude: number; longitude: number },
    daysAhead: number = 7
  ): Promise<SchedulingSuggestion[]> {
    try {
      // Simulate weather API call (in production, use actual weather service)
      const weatherData = await this.getWeatherForecast(location, daysAhead);
      
      // Get historical demand data
      const demandData = await this.getHistoricalDemand(location, daysAhead);
      
      // Get valeter availability
      const availabilityData = await this.getValeterAvailability(location, daysAhead);
      
      // Generate suggestions
      const suggestions: SchedulingSuggestion[] = [];
      const timeSlots = ['09:00', '11:00', '13:00', '15:00', '17:00'];
      
      for (let i = 0; i < daysAhead; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayWeather = weatherData[i] || weatherData[0];
        const dayDemand = demandData[dateStr] || { level: 'medium', multiplier: 1.0 };
        
        for (const timeSlot of timeSlots) {
          const weatherScore = dayWeather.isGoodForWash ? 100 : 30;
          const demandScore = dayDemand.level === 'high' ? 80 : dayDemand.level === 'low' ? 40 : 60;
          const availabilityScore = availabilityData[dateStr]?.[timeSlot] ? 70 : 50;
          
          const overallScore = (weatherScore * 0.4) + (demandScore * 0.3) + (availabilityScore * 0.3);
          
          let reason = '';
          if (dayWeather.isGoodForWash) {
            reason += 'Perfect weather conditions. ';
          } else {
            reason += 'Weather may affect service quality. ';
          }
          
          if (dayDemand.level === 'high') {
            reason += 'High demand expected. ';
          } else if (dayDemand.level === 'low') {
            reason += 'Lower demand, better availability. ';
          }
          
          if (overallScore >= 70) {
            suggestions.push({
              date: dateStr,
              timeSlot,
              confidence: Math.min(overallScore / 100, 0.95),
              reason: reason.trim(),
              weatherScore,
              demandScore,
              overallScore,
            });
          }
        }
      }
      
      // Sort by overall score (best first)
      return suggestions.sort((a, b) => b.overallScore - a.overallScore).slice(0, 10);
    } catch (error) {
      console.error('Error getting scheduling suggestions:', error);
      return [];
    }
  }

  /**
   * Get demand forecast for a location
   */
  static async getDemandForecast(
    location: { latitude: number; longitude: number },
    daysAhead: number = 14
  ): Promise<DemandForecast[]> {
    try {
      const forecasts: DemandForecast[] = [];
      
      // Get historical booking data
      const { data: historicalBookings } = await supabase
        .from('bookings')
        .select('scheduled_at, time_slot, status')
        .not('scheduled_at', 'is', null)
        .gte('scheduled_at', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString())
        .limit(1000);
      
      // Analyze patterns
      const dayOfWeekPatterns: Record<string, number[]> = {};
      const hourPatterns: Record<string, number> = {};
      
      historicalBookings?.forEach((booking) => {
        if (booking.scheduled_at) {
          const date = new Date(booking.scheduled_at);
          const dayOfWeek = date.getDay();
          const hour = date.getHours();
          
          if (!dayOfWeekPatterns[dayOfWeek]) {
            dayOfWeekPatterns[dayOfWeek] = [];
          }
          dayOfWeekPatterns[dayOfWeek].push(1);
          
          const hourKey = `${hour}:00`;
          hourPatterns[hourKey] = (hourPatterns[hourKey] || 0) + 1;
        }
      });
      
      // Generate forecasts
      for (let i = 0; i < daysAhead; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        const dateStr = date.toISOString().split('T')[0];
        const dayOfWeek = date.getDay();
        
        const historicalCount = dayOfWeekPatterns[dayOfWeek]?.length || 0;
        const avgCount = Object.values(dayOfWeekPatterns).reduce((sum, arr) => sum + arr.length, 0) / 7;
        
        let expectedDemand: 'low' | 'medium' | 'high';
        let confidence = 0.7;
        
        if (historicalCount > avgCount * 1.3) {
          expectedDemand = 'high';
          confidence = 0.8;
        } else if (historicalCount < avgCount * 0.7) {
          expectedDemand = 'low';
          confidence = 0.75;
        } else {
          expectedDemand = 'medium';
          confidence = 0.7;
        }
        
        // Find peak hours
        const sortedHours = Object.entries(hourPatterns)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3)
          .map(([hour]) => hour);
        
        // Price multiplier based on demand
        const recommendedPriceMultiplier = expectedDemand === 'high' ? 1.15 : expectedDemand === 'low' ? 0.9 : 1.0;
        
        forecasts.push({
          date: dateStr,
          expectedDemand,
          confidence,
          recommendedPriceMultiplier,
          peakHours: sortedHours,
        });
      }
      
      return forecasts;
    } catch (error) {
      console.error('Error getting demand forecast:', error);
      return [];
    }
  }

  /**
   * Get optimal price suggestion for a valeter
   */
  static async getPriceOptimization(
    valeterId: string,
    serviceType: string,
    location: { latitude: number; longitude: number },
    scheduledAt?: string
  ): Promise<{
    basePrice: number;
    suggestedPrice: number;
    multiplier: number;
    factors: Array<{ name: string; impact: number; description: string }>;
  }> {
    try {
      // Get base price for service
      const basePrice = this.getBasePriceForService(serviceType);
      
      // Get valeter stats
      const { data: valeterProfile } = await supabase
        .from('valeter_profiles')
        .select('rating, total_jobs_completed')
        .eq('user_id', valeterId)
        .maybeSingle();
      
      // Get demand forecast
      const forecasts = await this.getDemandForecast(location, 7);
      const scheduledDate = scheduledAt ? new Date(scheduledAt).toISOString().split('T')[0] : null;
      const forecast = scheduledDate ? forecasts.find(f => f.date === scheduledDate) : forecasts[0];
      
      const factors: Array<{ name: string; impact: number; description: string }> = [];
      let multiplier = 1.0;
      
      // Factor 1: Valeter rating
      const rating = valeterProfile?.rating || 4.0;
      if (rating >= 4.8) {
        multiplier += 0.15;
        factors.push({ name: 'High Rating', impact: 0.15, description: `Rating: ${rating.toFixed(1)}/5.0` });
      } else if (rating >= 4.5) {
        multiplier += 0.08;
        factors.push({ name: 'Good Rating', impact: 0.08, description: `Rating: ${rating.toFixed(1)}/5.0` });
      }
      
      // Factor 2: Experience
      const totalJobs = valeterProfile?.total_jobs_completed || 0;
      if (totalJobs >= 100) {
        multiplier += 0.1;
        factors.push({ name: 'Experienced', impact: 0.1, description: `${totalJobs}+ jobs completed` });
      } else if (totalJobs >= 50) {
        multiplier += 0.05;
        factors.push({ name: 'Experienced', impact: 0.05, description: `${totalJobs}+ jobs completed` });
      }
      
      // Factor 3: Demand forecast
      if (forecast) {
        if (forecast.expectedDemand === 'high') {
          multiplier += 0.1;
          factors.push({ name: 'High Demand', impact: 0.1, description: 'Peak booking period' });
        } else if (forecast.expectedDemand === 'low') {
          multiplier -= 0.1;
          factors.push({ name: 'Low Demand', impact: -0.1, description: 'Quieter period' });
        }
        
        multiplier *= forecast.recommendedPriceMultiplier;
      }
      
      // Factor 4: Time of day
      if (scheduledAt) {
        const hour = new Date(scheduledAt).getHours();
        if (hour >= 9 && hour <= 11) {
          multiplier += 0.05;
          factors.push({ name: 'Peak Hours', impact: 0.05, description: 'Morning rush' });
        } else if (hour >= 17 && hour <= 19) {
          multiplier += 0.08;
          factors.push({ name: 'Peak Hours', impact: 0.08, description: 'Evening rush' });
        }
      }
      
      // Clamp multiplier between 0.8 and 1.5
      multiplier = Math.max(0.8, Math.min(1.5, multiplier));
      
      const suggestedPrice = Math.round(basePrice * multiplier);
      
      return {
        basePrice,
        suggestedPrice,
        multiplier,
        factors,
      };
    } catch (error) {
      console.error('Error getting price optimization:', error);
      return {
        basePrice: this.getBasePriceForService(serviceType),
        suggestedPrice: this.getBasePriceForService(serviceType),
        multiplier: 1.0,
        factors: [],
      };
    }
  }

  /**
   * Get weather forecast from actual weather API
   * TODO: Implement with OpenWeatherMap or similar weather service
   */
  private static async getWeatherForecast(
    location: { latitude: number; longitude: number },
    days: number
  ): Promise<WeatherData[]> {
    // Return empty array - weather API integration needed
    // In production, this would call OpenWeatherMap or similar service
    return [];
  }

  /**
   * Get historical demand patterns
   */
  private static async getHistoricalDemand(
    location: { latitude: number; longitude: number },
    days: number
  ): Promise<Record<string, { level: 'low' | 'medium' | 'high'; multiplier: number }>> {
    const demand: Record<string, { level: 'low' | 'medium' | 'high'; multiplier: number }> = {};
    
    // Get bookings in the area
    const { data: bookings } = await supabase
      .from('bookings')
      .select('scheduled_at')
      .not('scheduled_at', 'is', null)
      .gte('scheduled_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .limit(500);
    
    // Group by date
    const bookingsByDate: Record<string, number> = {};
    bookings?.forEach((booking) => {
      if (booking.scheduled_at) {
        const date = booking.scheduled_at.split('T')[0];
        bookingsByDate[date] = (bookingsByDate[date] || 0) + 1;
      }
    });
    
    const avgBookings = Object.values(bookingsByDate).reduce((sum, count) => sum + count, 0) / Math.max(Object.keys(bookingsByDate).length, 1);
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      
      // Predict based on day of week
      const dayOfWeek = date.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const expectedCount = isWeekend ? avgBookings * 1.3 : avgBookings * 0.9;
      
      let level: 'low' | 'medium' | 'high';
      let multiplier: number;
      
      if (expectedCount > avgBookings * 1.2) {
        level = 'high';
        multiplier = 1.15;
      } else if (expectedCount < avgBookings * 0.8) {
        level = 'low';
        multiplier = 0.9;
      } else {
        level = 'medium';
        multiplier = 1.0;
      }
      
      demand[dateStr] = { level, multiplier };
    }
    
    return demand;
  }

  /**
   * Get valeter availability
   */
  private static async getValeterAvailability(
    location: { latitude: number; longitude: number },
    days: number
  ): Promise<Record<string, Record<string, boolean>>> {
    const availability: Record<string, Record<string, boolean>> = {};
    
    // Get active valeters in the area
    const { data: valeters } = await supabase
      .from('valeter_profiles')
      .select('user_id, is_online')
      .eq('is_online', true)
      .limit(50);
    
    // Simulate availability (in production, check actual schedules)
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      availability[dateStr] = {};
      
      const timeSlots = ['09:00', '11:00', '13:00', '15:00', '17:00'];
      timeSlots.forEach((slot) => {
        // More valeters available = higher availability
        availability[dateStr][slot] = (valeters?.length || 0) > 5;
      });
    }
    
    return availability;
  }

  /**
   * Get base price for service type
   */
  private static getBasePriceForService(serviceType: string): number {
    const prices: Record<string, number> = {
      'bronze-wash': 15,
      'silver-wash': 25,
      'gold-wash': 40,
      'platinum-wash': 60,
      'eco-bronze-wash': 18,
      'eco-silver-wash': 28,
      'eco-gold-wash': 45,
      'detailing': 60,
      'ceramic-coating': 200,
      'ppf': 500,
    };
    
    return prices[serviceType] || 25;
  }
}

