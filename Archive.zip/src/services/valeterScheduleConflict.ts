import { supabase } from '../lib/supabase';
import {
  getBookingTimeWindow,
  windowOverlapsAny,
  type TimeWindowMs,
} from '../utils/bookingTimeWindow';
import { profileJsonToWindows, syncValeterExternalCalendarBusyToSupabase } from './valeterExternalCalendarBusy';

/** Active pipeline: valeter is committed to this slot. */
export const VALETER_COMMITMENT_STATUSES = [
  'pending_payment',
  'confirmed',
  'scheduled',
  'en_route',
  'arrived',
  'in_progress',
] as const;

/** Mid-job until complete/cancelled — blocks instant “jobs now”, not future scheduled offers. */
export const LIVE_JOB_STATUSES = ['en_route', 'arrived', 'in_progress'] as const;

export function isLiveJobStatus(status: string | null | undefined): boolean {
  return !!status && (LIVE_JOB_STATUSES as readonly string[]).includes(status);
}

/** Instant / “jobs now” offer — no future scheduled_at. */
export function isInstantBookingOffer(
  scheduledAt: string | null | undefined,
  now = Date.now()
): boolean {
  if (scheduledAt == null || String(scheduledAt).trim() === '') return true;
  const t = new Date(scheduledAt).getTime();
  return !Number.isFinite(t) || t <= now;
}

export async function valeterHasLiveJob(userId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('bookings')
    .select('id')
    .eq('valeter_id', userId)
    .in('status', [...LIVE_JOB_STATUSES])
    .limit(1)
    .maybeSingle();
  if (error) {
    // Fail closed so we do not offer instant jobs while status is unknown
    return true;
  }
  return !!data?.id;
}

export function commitmentWindowsFromBookingRows(
  rows: Array<{
    scheduled_at?: string | null;
    request_sent_at?: string | null;
    service_type?: string | null;
    service_name?: string | null;
  }>
): TimeWindowMs[] {
  return rows.map((r) =>
    getBookingTimeWindow(
      r.scheduled_at,
      r.request_sent_at ?? null,
      r.service_type ?? undefined,
      r.service_name ?? undefined
    )
  );
}

export function offerOverlapsSchedule(
  scheduledAt: string | null | undefined,
  requestSentAt: string | null | undefined,
  serviceType: string | undefined,
  serviceName: string | undefined,
  commitmentWindows: TimeWindowMs[],
  externalBusy: TimeWindowMs[]
): boolean {
  const job = getBookingTimeWindow(scheduledAt, requestSentAt, serviceType, serviceName);
  if (windowOverlapsAny(job, commitmentWindows)) return true;
  if (windowOverlapsAny(job, externalBusy)) return true;
  return false;
}

/**
 * True if a hypothetical “book now” job (next slot from this moment) clashes with this valeter’s
 * Wish a Wash commitments or device calendar busy windows — used for customer availability lists.
 */
export function isValeterBlockedForInstantBooking(
  commitmentRowsForValeter: Array<{
    scheduled_at?: string | null;
    request_sent_at?: string | null;
    service_type?: string | null;
    service_name?: string | null;
  }>,
  externalBusyJson: unknown
): boolean {
  const requestSentAt = new Date().toISOString();
  return offerOverlapsSchedule(
    null,
    requestSentAt,
    undefined,
    undefined,
    commitmentWindowsFromBookingRows(commitmentRowsForValeter),
    profileJsonToWindows(externalBusyJson)
  );
}

/**
 * Throttled calendar upload + load commitment and external busy windows from Supabase.
 */
export async function loadValeterScheduleBlocks(userId: string): Promise<{
  commitmentWindows: TimeWindowMs[];
  externalBusy: TimeWindowMs[];
}> {
  await syncValeterExternalCalendarBusyToSupabase(userId);
  const [commitRes, profileRes] = await Promise.all([
    supabase
      .from('bookings')
      .select('scheduled_at, request_sent_at, service_type, service_name')
      .eq('valeter_id', userId)
      .in('status', [...VALETER_COMMITMENT_STATUSES]),
    supabase.from('valeter_profiles').select('external_calendar_busy').eq('user_id', userId).maybeSingle(),
  ]);
  return {
    commitmentWindows: commitmentWindowsFromBookingRows(commitRes.data || []),
    externalBusy: profileJsonToWindows(profileRes.data?.external_calendar_busy),
  };
}

/**
 * Fresh calendar read + DB check before accepting a job (force=true sync).
 */
export async function assertNoScheduleConflictForOffer(
  userId: string,
  offer: {
    scheduled_at?: string | null;
    request_sent_at?: string | null;
    service_type?: string | null;
    service_name?: string | null;
  }
): Promise<{ ok: true } | { ok: false; message: string }> {
  if (isInstantBookingOffer(offer.scheduled_at) && (await valeterHasLiveJob(userId))) {
    return {
      ok: false,
      message:
        'Finish or cancel your current job before accepting jobs now. You can still take scheduled bookings when that time is free on your calendar.',
    };
  }

  await syncValeterExternalCalendarBusyToSupabase(userId, true);
  const [commitRes, profileRes] = await Promise.all([
    supabase
      .from('bookings')
      .select('scheduled_at, request_sent_at, service_type, service_name')
      .eq('valeter_id', userId)
      .in('status', [...VALETER_COMMITMENT_STATUSES]),
    supabase.from('valeter_profiles').select('external_calendar_busy').eq('user_id', userId).maybeSingle(),
  ]);
  const commitmentWindows = commitmentWindowsFromBookingRows(commitRes.data || []);
  const externalBusy = profileJsonToWindows(profileRes.data?.external_calendar_busy);
  if (
    offerOverlapsSchedule(
      offer.scheduled_at,
      offer.request_sent_at,
      offer.service_type ?? undefined,
      offer.service_name ?? undefined,
      commitmentWindows,
      externalBusy
    )
  ) {
    return {
      ok: false,
      message:
        'You already have a Wish a Wash booking or another calendar event at this time. Finish or reschedule before accepting.',
    };
  }
  return { ok: true };
}

/** True if push/UI should show this offer (no schedule clash with WAW jobs + device calendar). */
export async function valeterScheduleAllowsJobOffer(
  userId: string,
  booking: {
    scheduled_at?: string | null;
    request_sent_at?: string | null;
    created_at?: string | null;
    service_type?: string | null;
    service_name?: string | null;
  }
): Promise<boolean> {
  const r = await assertNoScheduleConflictForOffer(userId, {
    scheduled_at: booking.scheduled_at ?? null,
    request_sent_at: booking.request_sent_at ?? booking.created_at ?? null,
    service_type: booking.service_type ?? null,
    service_name: booking.service_name ?? null,
  });
  return r.ok;
}
