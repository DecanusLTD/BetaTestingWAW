import AsyncStorage from '@react-native-async-storage/async-storage';

export interface ValeterDocuments {
  idProof: {
    uploaded: boolean;
    verified: boolean;
    fileUrl?: string;
    uploadedAt?: string;
  };
  selfie: {
    uploaded: boolean;
    verified: boolean;
    fileUrl?: string;
    uploadedAt?: string;
  };
  profilePhoto: {
    uploaded: boolean;
    verified: boolean;
    fileUrl?: string;
    uploadedAt?: string;
  };
  disclaimerSigned: {
    signed: boolean;
    signedAt?: string;
  };
}

export interface ValeterStatus {
  valeterId: string;
  isOnline: boolean;
  documentsComplete: boolean;
  documentsVerified: boolean;
  canGoOnline: boolean;
  lastOnlineAt?: string;
  lastOfflineAt?: string;
  workingArea?: {
    latitude: number;
    longitude: number;
    radius: number;
  };
}

class ValeterStatusService {
  private static instance: ValeterStatusService;
  private listeners: Map<string, (status: ValeterStatus) => void> = new Map();

  static getInstance(): ValeterStatusService {
    if (!ValeterStatusService.instance) {
      ValeterStatusService.instance = new ValeterStatusService();
    }
    return ValeterStatusService.instance;
  }

  // Get valeter status
  async getValeterStatus(valeterId: string): Promise<ValeterStatus> {
    try {
      const statusJson = await AsyncStorage.getItem(`valeter_status_${valeterId}`);
      if (statusJson) {
        return JSON.parse(statusJson);
      }
      
      // Return default status
      return {
        valeterId,
        isOnline: false,
        documentsComplete: false,
        documentsVerified: false,
        canGoOnline: false,
      };
    } catch (error) {
      console.error('Error loading valeter status:', error);
      return {
        valeterId,
        isOnline: false,
        documentsComplete: false,
        documentsVerified: false,
        canGoOnline: false,
      };
    }
  }

  // Get valeter documents
  async getValeterDocuments(valeterId: string): Promise<ValeterDocuments> {
    try {
      const documentsJson = await AsyncStorage.getItem(`valeter_documents_${valeterId}`);
      if (documentsJson) {
        return JSON.parse(documentsJson);
      }
      
      // Return default documents
      return {
        idProof: { uploaded: false, verified: false },
        selfie: { uploaded: false, verified: false },
        profilePhoto: { uploaded: false, verified: false },
        disclaimerSigned: { signed: false },
      };
    } catch (error) {
      console.error('Error loading valeter documents:', error);
      return {
        idProof: { uploaded: false, verified: false },
        selfie: { uploaded: false, verified: false },
        profilePhoto: { uploaded: false, verified: false },
        disclaimerSigned: { signed: false },
      };
    }
  }

  // Upload document
  async uploadDocument(
    valeterId: string, 
    documentType: keyof ValeterDocuments, 
    fileUrl: string
  ): Promise<boolean> {
    try {
      const documents = await this.getValeterDocuments(valeterId);
      
      if (documentType === 'disclaimerSigned') {
        documents.disclaimerSigned = {
          signed: true,
          signedAt: new Date().toISOString(),
        };
      } else {
        const docKey = documentType as keyof Omit<ValeterDocuments, 'disclaimerSigned'>;
        documents[docKey] = {
          uploaded: true,
          verified: false,
          fileUrl,
          uploadedAt: new Date().toISOString(),
        };
      }

      await AsyncStorage.setItem(`valeter_documents_${valeterId}`, JSON.stringify(documents));
      
      // Update status after document upload
      await this.updateValeterStatus(valeterId);
      
      return true;
    } catch (error) {
      console.error('Error uploading document:', error);
      return false;
    }
  }

  // Verify documents (admin function)
  async verifyDocuments(valeterId: string): Promise<boolean> {
    try {
      const documents = await this.getValeterDocuments(valeterId);
      
      // Check if all required documents are uploaded
      const allUploaded = documents.idProof.uploaded && 
                         documents.selfie.uploaded && 
                         documents.profilePhoto.uploaded && 
                         documents.disclaimerSigned.signed;

      if (allUploaded) {
        // Mark all documents as verified
        documents.idProof.verified = true;
        documents.selfie.verified = true;
        documents.profilePhoto.verified = true;
        
        await AsyncStorage.setItem(`valeter_documents_${valeterId}`, JSON.stringify(documents));
        
        // Update status after verification
        await this.updateValeterStatus(valeterId);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error verifying documents:', error);
      return false;
    }
  }

  // Update valeter status based on documents
  async updateValeterStatus(valeterId: string): Promise<void> {
    try {
      const documents = await this.getValeterDocuments(valeterId);
      const currentStatus = await this.getValeterStatus(valeterId);
      
      // Check if all documents are complete
      const documentsComplete = documents.idProof.uploaded && 
                               documents.selfie.uploaded && 
                               documents.profilePhoto.uploaded && 
                               documents.disclaimerSigned.signed;
      
      // Check if all documents are verified
      const documentsVerified = documents.idProof.verified && 
                               documents.selfie.verified && 
                               documents.profilePhoto.verified;
      
      // Can go online if documents are complete and verified
      const canGoOnline = documentsComplete && documentsVerified;
      
      const updatedStatus: ValeterStatus = {
        ...currentStatus,
        documentsComplete,
        documentsVerified,
        canGoOnline,
      };
      
      await AsyncStorage.setItem(`valeter_status_${valeterId}`, JSON.stringify(updatedStatus));
      this.notifyListeners(valeterId, updatedStatus);
    } catch (error) {
      console.error('Error updating valeter status:', error);
    }
  }

  // Go online
  async goOnline(valeterId: string): Promise<boolean> {
    try {
      const status = await this.getValeterStatus(valeterId);
      
      if (!status.canGoOnline) {
        return false;
      }
      
      const updatedStatus: ValeterStatus = {
        ...status,
        isOnline: true,
        lastOnlineAt: new Date().toISOString(),
      };
      
      await AsyncStorage.setItem(`valeter_status_${valeterId}`, JSON.stringify(updatedStatus));
      this.notifyListeners(valeterId, updatedStatus);
      
      return true;
    } catch (error) {
      console.error('Error going online:', error);
      return false;
    }
  }

  // Go offline
  async goOffline(valeterId: string): Promise<boolean> {
    try {
      const status = await this.getValeterStatus(valeterId);
      
      const updatedStatus: ValeterStatus = {
        ...status,
        isOnline: false,
        lastOfflineAt: new Date().toISOString(),
      };
      
      await AsyncStorage.setItem(`valeter_status_${valeterId}`, JSON.stringify(updatedStatus));
      this.notifyListeners(valeterId, updatedStatus);
      
      return true;
    } catch (error) {
      console.error('Error going offline:', error);
      return false;
    }
  }

  // Set working area
  async setWorkingArea(
    valeterId: string, 
    latitude: number, 
    longitude: number, 
    radius: number
  ): Promise<boolean> {
    try {
      const status = await this.getValeterStatus(valeterId);
      
      const updatedStatus: ValeterStatus = {
        ...status,
        workingArea: { latitude, longitude, radius },
      };
      
      await AsyncStorage.setItem(`valeter_status_${valeterId}`, JSON.stringify(updatedStatus));
      this.notifyListeners(valeterId, updatedStatus);
      
      return true;
    } catch (error) {
      console.error('Error setting working area:', error);
      return false;
    }
  }

  // Subscribe to status updates
  subscribeToStatus(valeterId: string, callback: (status: ValeterStatus) => void): () => void {
    this.listeners.set(valeterId, callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners.delete(valeterId);
    };
  }

  // Notify listeners of status updates
  private notifyListeners(valeterId: string, status: ValeterStatus): void {
    const callback = this.listeners.get(valeterId);
    if (callback) {
      callback(status);
    }
  }

  // Delete valeter data (for account deletion)
  async deleteValeterData(valeterId: string): Promise<boolean> {
    try {
      // Remove all valeter data from storage
      await AsyncStorage.multiRemove([
        `valeter_status_${valeterId}`,
        `valeter_documents_${valeterId}`,
        `current_job_${valeterId}`,
        `recent_jobs_${valeterId}`,
      ]);
      
      // Remove from listeners
      this.listeners.delete(valeterId);
      
      return true;
    } catch (error) {
      console.error('Error deleting valeter data:', error);
      return false;
    }
  }

  // Get all online valeters (for job assignment)
  async getOnlineValeters(): Promise<string[]> {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const valeterStatusKeys = keys.filter(key => key.startsWith('valeter_status_'));
      
      const onlineValeters: string[] = [];
      
      for (const key of valeterStatusKeys) {
        const statusJson = await AsyncStorage.getItem(key);
        if (statusJson) {
          const status: ValeterStatus = JSON.parse(statusJson);
          if (status.isOnline && status.canGoOnline) {
            onlineValeters.push(status.valeterId);
          }
        }
      }
      
      return onlineValeters;
    } catch (error) {
      console.error('Error getting online valeters:', error);
      return [];
    }
  }
}

export const valeterStatusService = ValeterStatusService.getInstance();
