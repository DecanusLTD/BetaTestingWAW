import AsyncStorage from '@react-native-async-storage/async-storage';

export type CalendarSyncSettings = {
  enabled: boolean;
  reminderMinutes: number[];
};

const DEFAULT_SETTINGS: CalendarSyncSettings = {
  enabled: true,
  reminderMinutes: [30, 10],
};

function settingsKey(userId: string): string {
  return `@waw_calendar_sync_settings_${userId}`;
}

export async function loadCalendarSyncSettings(userId: string): Promise<CalendarSyncSettings> {
  try {
    const raw = await AsyncStorage.getItem(settingsKey(userId));
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<CalendarSyncSettings>;
    const reminderMinutes = Array.isArray(parsed.reminderMinutes)
      ? parsed.reminderMinutes.filter((v): v is number => Number.isFinite(v) && v > 0)
      : DEFAULT_SETTINGS.reminderMinutes;
    return {
      enabled: parsed.enabled !== false,
      reminderMinutes: reminderMinutes.length > 0 ? reminderMinutes : DEFAULT_SETTINGS.reminderMinutes,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export async function saveCalendarSyncSettings(userId: string, settings: CalendarSyncSettings): Promise<void> {
  await AsyncStorage.setItem(settingsKey(userId), JSON.stringify(settings));
}

