import { supabase } from '../lib/supabase';

/** PostgREST PGRST205: table missing from schema — log at most once per session */
let teamRequestsTableMissingLogged = false;

function isTeamRequestsTableMissing(err: { code?: string; message?: string } | null | undefined): boolean {
  if (!err) return false;
  const msg = String(err.message || '');
  if (err.code === 'PGRST205' && /team_requests/i.test(msg)) return true;
  return /Could not find the table.*team_requests/i.test(msg);
}

export type NotificationType = 'booking' | 'team_request' | 'team_update' | 'booking_update';
export type NotificationPriority = 'low' | 'medium' | 'high';

export interface BusinessNotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: string;
  priority: NotificationPriority;
  route?: string;
  bookingId?: string;
  requestId?: string;
  createdAt: string;
}

export type BusinessNotificationFeedOptions = {
  bookingLimit?: number;
  teamRequestLimit?: number;
  /** Team pseudo-notifications: only if profile `updated_at` is newer than this many ms ago */
  teamUpdateMaxAgeMs?: number;
};

const FULL_PAGE_DEFAULTS: Required<BusinessNotificationFeedOptions> = {
  bookingLimit: 40,
  teamRequestLimit: 20,
  teamUpdateMaxAgeMs: 24 * 60 * 60 * 1000,
};

/** Matches previous dashboard / header dropdown windows */
export const DROPDOWN_FEED_DEFAULTS: Required<BusinessNotificationFeedOptions> = {
  bookingLimit: 20,
  teamRequestLimit: 10,
  teamUpdateMaxAgeMs: 5 * 60 * 1000,
};

function getPriority(type: NotificationType, status?: string): NotificationPriority {
  if (type === 'booking_update' && (status === 'cancelled' || status === 'in_progress')) {
    return 'high';
  }
  if (type === 'team_request') return 'high';
  if (type === 'booking' && (status === 'pending_business_acceptance' || status === 'confirmed')) {
    return 'medium';
  }
  if (type === 'team_update') return 'medium';
  return 'low';
}

function formatTime(dateString: string) {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
}

/**
 * Build the same business “notification” list used in the app (derived from bookings, team requests, profiles).
 */
export async function fetchBusinessNotificationFeed(
  organizationId: string,
  options?: BusinessNotificationFeedOptions
): Promise<BusinessNotificationItem[]> {
  const bookingLimit = options?.bookingLimit ?? FULL_PAGE_DEFAULTS.bookingLimit;
  const teamRequestLimit = options?.teamRequestLimit ?? FULL_PAGE_DEFAULTS.teamRequestLimit;
  const teamUpdateMaxAgeMs = options?.teamUpdateMaxAgeMs ?? FULL_PAGE_DEFAULTS.teamUpdateMaxAgeMs;

  const { data: valeters, error: valetersError } = await supabase
    .from('profiles')
    .select('id, full_name, name, updated_at')
    .eq('organization_id', organizationId)
    .eq('user_type', 'valeter');

  if (valetersError) {
    console.error('[BusinessNotificationsFeed] valeters:', valetersError);
  }

  const notificationItems: BusinessNotificationItem[] = [];
  const valeterIds = (valeters || []).map((v: { id: string }) => v.id);

  if (valeterIds.length > 0) {
    const { data: bookings, error: bookingsError } = await supabase
      .from('bookings')
      .select('id, status, service_name, created_at, updated_at')
      .in('valeter_id', valeterIds)
      .in('status', [
        'pending',
        'pending_valeter_acceptance',
        'pending_payment',
        'confirmed',
        'in_progress',
        'completed',
        'cancelled',
        'valeter_assigned',
      ])
      .order('updated_at', { ascending: false })
      .limit(bookingLimit);

    if (bookingsError) {
      console.error('[BusinessNotificationsFeed] bookings:', bookingsError);
    }

    (bookings || []).forEach((booking: any) => {
      const isNew =
        new Date(booking.created_at).getTime() === new Date(booking.updated_at).getTime();

      const type: NotificationType = isNew ? 'booking' : 'booking_update';

      let title = 'New Booking';
      let message = '';

      if (type === 'booking_update') {
        switch (booking.status) {
          case 'confirmed':
            title = 'Booking Confirmed';
            message = 'A booking has been confirmed';
            break;
          case 'in_progress':
            title = 'Booking In Progress';
            message = 'A service is now in progress';
            break;
          case 'completed':
            title = 'Booking Completed';
            message = 'A booking has been completed';
            break;
          case 'cancelled':
            title = 'Booking Cancelled';
            message = 'A booking has been cancelled';
            break;
          default:
            title = 'Booking Updated';
            message = 'A booking has been updated';
        }
      } else {
        message = booking.service_name || 'New booking received';
      }

      notificationItems.push({
        id: `booking-${booking.id}-${booking.updated_at}`,
        type,
        title,
        message,
        time: formatTime(booking.updated_at || booking.created_at),
        priority: getPriority(type, booking.status),
        route: `/business/bookings/${booking.id}`,
        bookingId: booking.id,
        createdAt: booking.updated_at || booking.created_at,
      });
    });
  }

  const { data: teamRequests, error: teamErr } = await supabase
    .from('team_requests')
    .select('id, valeter_name, valeter_email, created_at, status')
    .eq('organization_id', organizationId)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })
    .limit(teamRequestLimit);

  if (teamErr) {
    if (isTeamRequestsTableMissing(teamErr)) {
      if (__DEV__ && !teamRequestsTableMissingLogged) {
        teamRequestsTableMissingLogged = true;
        console.warn(
          '[BusinessNotificationsFeed] team_requests table is not in the Supabase schema (skipping). Expose or create the table if you need team request notifications.'
        );
      }
    } else {
      console.warn('[BusinessNotificationsFeed] team_requests:', teamErr);
    }
  }

  (teamRequests || []).forEach((request: any) => {
    notificationItems.push({
      id: `request-${request.id}`,
      type: 'team_request',
      title: 'Team Request',
      message: request.valeter_name
        ? `${request.valeter_name} wants to join your team`
        : request.valeter_email || 'New team request',
      time: formatTime(request.created_at),
      priority: 'high',
      route: '/business/team/requests',
      requestId: request.id,
      createdAt: request.created_at,
    });
  });

  const cutoff = Date.now() - teamUpdateMaxAgeMs;
  (valeters || []).forEach((valeter: any) => {
    if (!valeter.updated_at) return;
    const updateTime = new Date(valeter.updated_at).getTime();
    if (updateTime > cutoff) {
      notificationItems.push({
        id: `team-update-${valeter.id}-${valeter.updated_at}`,
        type: 'team_update',
        title: 'Team Member Update',
        message: `${valeter.full_name || valeter.name || 'A team member'}'s profile was recently updated`,
        time: formatTime(valeter.updated_at),
        priority: 'medium',
        route: '/business/team',
        createdAt: valeter.updated_at,
      });
    }
  });

  notificationItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return notificationItems;
}
