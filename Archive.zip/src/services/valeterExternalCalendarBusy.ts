import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import * as Calendar from 'expo-calendar';
import { supabase } from '../lib/supabase';
import type { TimeWindowMs } from '../utils/bookingTimeWindow';

const LAST_SYNC_KEY = '@waw_ext_cal_busy_sync';
const COLUMN_MISSING_KEY = '@waw_ext_cal_busy_col_missing';
const SYNC_INTERVAL_MS = 5 * 60 * 1000;
const DAYS_AHEAD = 21;
const MAX_BLOCKS = 400;

/** Once we know the DB column is absent, skip further writes this session. */
let columnMissingCached: boolean | null = null;

async function isExternalBusyColumnMissing(): Promise<boolean> {
  if (columnMissingCached != null) return columnMissingCached;
  try {
    const raw = await AsyncStorage.getItem(COLUMN_MISSING_KEY);
    columnMissingCached = raw === '1';
  } catch {
    columnMissingCached = false;
  }
  return columnMissingCached;
}

async function markExternalBusyColumnMissing(): Promise<void> {
  columnMissingCached = true;
  try {
    await AsyncStorage.setItem(COLUMN_MISSING_KEY, '1');
  } catch {
    /* ignore */
  }
}

function isMissingColumnError(message?: string | null): boolean {
  if (!message) return false;
  return /external_calendar_busy|schema cache|does not exist|could not find/i.test(message);
}

function eventsToWindows(events: Calendar.Event[]): TimeWindowMs[] {
  const out: TimeWindowMs[] = [];
  for (const ev of events) {
    if (ev.status === Calendar.EventStatus.CANCELED) continue;
    const s = new Date(ev.startDate as string | Date).getTime();
    const e = new Date(ev.endDate as string | Date).getTime();
    if (Number.isNaN(s) || Number.isNaN(e) || e <= s) continue;
    out.push({ startMs: s, endMs: e });
  }
  return out;
}

/**
 * Read busy intervals from all device calendars in [now, now + DAYS_AHEAD].
 */
export async function fetchDeviceCalendarBusyWindows(): Promise<TimeWindowMs[]> {
  if (Platform.OS !== 'ios' && Platform.OS !== 'android') return [];

  try {
    let perm = await Calendar.getCalendarPermissionsAsync();
    if (perm.status !== 'granted') {
      perm = await Calendar.requestCalendarPermissionsAsync();
    }
    if (perm.status !== 'granted') return [];

    const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
    const ids = calendars.map((c) => c.id).filter(Boolean);
    if (!ids.length) return [];

    const start = new Date();
    const end = new Date();
    end.setDate(end.getDate() + DAYS_AHEAD);

    const events = await Calendar.getEventsAsync(ids, start, end);
    return eventsToWindows(events).slice(0, MAX_BLOCKS);
  } catch (e) {
    console.warn('[ExternalCalBusy] fetch device events:', e);
    return [];
  }
}

export function profileJsonToWindows(json: unknown): TimeWindowMs[] {
  if (!Array.isArray(json)) return [];
  const out: TimeWindowMs[] = [];
  for (const item of json) {
    if (!item || typeof item !== 'object') continue;
    const rec = item as Record<string, unknown>;
    const startRaw = rec.start;
    const endRaw = rec.end;
    if (typeof startRaw !== 'string' || typeof endRaw !== 'string') continue;
    const startMs = new Date(startRaw).getTime();
    const endMs = new Date(endRaw).getTime();
    if (Number.isNaN(startMs) || Number.isNaN(endMs) || endMs <= startMs) continue;
    out.push({ startMs, endMs });
  }
  return out;
}

export function windowsToJsonPayload(windows: TimeWindowMs[]): { start: string; end: string }[] {
  return windows.slice(0, MAX_BLOCKS).map((w) => ({
    start: new Date(w.startMs).toISOString(),
    end: new Date(w.endMs).toISOString(),
  }));
}

/**
 * Snap device busy windows to `valeter_profiles.external_calendar_busy` (throttled unless force).
 */
export async function syncValeterExternalCalendarBusyToSupabase(userId: string, force = false): Promise<void> {
  if (!userId) return;
  try {
    if (await isExternalBusyColumnMissing()) return;

    if (!force) {
      const raw = await AsyncStorage.getItem(LAST_SYNC_KEY);
      if (raw) {
        const t = Number(raw);
        if (Number.isFinite(t) && Date.now() - t < SYNC_INTERVAL_MS) return;
      }
    }
    const windows = await fetchDeviceCalendarBusyWindows();
    const payload = windowsToJsonPayload(windows);
    const { error } = await supabase.from('valeter_profiles').update({ external_calendar_busy: payload }).eq('user_id', userId);
    if (error) {
      if (isMissingColumnError(error.message)) {
        await markExternalBusyColumnMissing();
        // Avoid hammering the API / console when the migration hasn't been applied.
        if (__DEV__) {
          console.warn(
            '[ExternalCalBusy] Skipping sync — run docs/SUPABASE_VALETER_EXTERNAL_CALENDAR_BUSY.sql'
          );
        }
        return;
      }
      console.warn('[ExternalCalBusy] profile update:', error.message);
      return;
    }
    await AsyncStorage.setItem(LAST_SYNC_KEY, String(Date.now()));
  } catch (e) {
    console.warn('[ExternalCalBusy] sync failed:', e);
  }
}
