import { supabase } from '../lib/supabase';

export type StripeConnectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'restricted'
  | 'rejected';

export type ValeterStripeConnectStatus = {
  stripeConnectStatus: StripeConnectStatus;
  stripeAccountId: string | null;
  stripeOnboardingStartedAt: string | null;
  stripeOnboardingCompletedAt: string | null;
  stripeDetails: Record<string, any>;
};

const DEFAULT_STATUS: ValeterStripeConnectStatus = {
  stripeConnectStatus: 'not_started',
  stripeAccountId: null,
  stripeOnboardingStartedAt: null,
  stripeOnboardingCompletedAt: null,
  stripeDetails: {},
};

const nowIso = () => new Date().toISOString();

const normalize = (row: any): ValeterStripeConnectStatus => ({
  stripeConnectStatus: (row?.stripe_connect_status || 'not_started') as StripeConnectStatus,
  stripeAccountId: row?.stripe_account_id ?? null,
  stripeOnboardingStartedAt: row?.stripe_onboarding_started_at ?? null,
  stripeOnboardingCompletedAt: row?.stripe_onboarding_completed_at ?? null,
  stripeDetails: row?.stripe_details && typeof row.stripe_details === 'object' ? row.stripe_details : {},
});

export const valeterStripeConnectService = {
  async getStatus(userId: string): Promise<ValeterStripeConnectStatus> {
    const { data, error } = await supabase
      .from('profiles')
      .select('stripe_connect_status,stripe_account_id,stripe_onboarding_started_at,stripe_onboarding_completed_at,stripe_details')
      .eq('id', userId)
      .maybeSingle();

    if (error) throw error;
    if (!data) return DEFAULT_STATUS;
    return normalize(data);
  },

  async setStripeStatus(
    userId: string,
    patch: Partial<ValeterStripeConnectStatus> & { stripeDetails?: Record<string, any> }
  ): Promise<void> {
    const status = await this.getStatus(userId);
    const nextDetails = { ...(status.stripeDetails || {}), ...(patch.stripeDetails || {}) };

    const { error } = await supabase
      .from('profiles')
      .update({
        stripe_connect_status: patch.stripeConnectStatus ?? status.stripeConnectStatus,
        stripe_account_id: patch.stripeAccountId ?? status.stripeAccountId,
        stripe_onboarding_started_at: patch.stripeOnboardingStartedAt ?? status.stripeOnboardingStartedAt,
        stripe_onboarding_completed_at: patch.stripeOnboardingCompletedAt ?? status.stripeOnboardingCompletedAt,
        stripe_details: nextDetails,
      } as any)
      .eq('id', userId);

    if (error) throw error;
  },

  async startStripeConnect(userId: string, details?: Record<string, any>): Promise<void> {
    const status = await this.getStatus(userId);
    await this.setStripeStatus(userId, {
      stripeConnectStatus: 'in_progress',
      stripeOnboardingStartedAt: status.stripeOnboardingStartedAt || nowIso(),
      stripeDetails: details || {},
    });
  },

  async completeStripeConnect(
    userId: string,
    params: { stripeAccountId: string; details?: Record<string, any> }
  ): Promise<void> {
    const status = await this.getStatus(userId);
    await this.setStripeStatus(userId, {
      stripeConnectStatus: 'completed',
      stripeAccountId: params.stripeAccountId,
      stripeOnboardingStartedAt: status.stripeOnboardingStartedAt || nowIso(),
      stripeOnboardingCompletedAt: nowIso(),
      stripeDetails: params.details || {},
    });
  },

  async setStripeSkipForNow(userId: string, skipped: boolean): Promise<void> {
    const status = await this.getStatus(userId);
    await this.setStripeStatus(userId, {
      stripeDetails: {
        skipped_for_now: skipped,
        skipped_for_now_at: skipped ? nowIso() : null,
      },
      stripeConnectStatus: skipped ? status.stripeConnectStatus : status.stripeConnectStatus,
    });
  },
};
