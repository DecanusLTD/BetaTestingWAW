/**
 * Frontend-Only Pricing Engine
 * 
 * This module provides a centralized pricing calculation system for mobile wash services.
 * All pricing logic is frontend-only and used for UI display. The backend continues to
 * accept price values as-is without any changes.
 * 
 * To adjust prices in the future:
 * - Update basePriceSmallGBP in WASH_DEFINITIONS array
 * - Modify getVehicleSizeAdjustmentGBP() for size adjustments
 * 
 * To change surge rules:
 * - Modify getSurgeInfo() function (weekday peak hours, weekend multipliers)
 * 
 * To tweak distance logic:
 * - Modify getDistanceSurchargeGBP() (included miles, per-mile rate)
 */

export type VehicleSize = 'SMALL' | 'MEDIUM' | 'LARGE' | 'XL' | 'XXL';

export type WashTier = 'BRONZE' | 'SILVER' | 'DIAMOND' | 'GOLD' | 'PLATINUM';

export interface WashDefinition {
  id: string;
  label: string;
  description: string;
  tier: WashTier;
  isMobile: boolean;
  isPhysicalLocation: boolean;
  basePriceSmallGBP: number;
}

export interface SurgeInfo {
  multiplier: number;   // 1.0 = no surge, 1.10 = 10% extra
  label?: string;
}

export interface FrontendPricingInput {
  washId: string;
  vehicleSize: VehicleSize;
  isMobile: boolean;
  isPhysicalLocation: boolean;
  distanceMiles?: number;
  scheduledDateTime: Date;
}

export interface FrontendPricingBreakdown {
  basePriceGBP: number;
  vehicleSizeAdjustmentGBP: number;
  distanceSurchargeGBP: number;
  surgeMultiplier: number;
  surgeLabel?: string;
  finalDisplayPriceGBP: number;
}

/**
 * Single source of truth for all wash service definitions.
 * Base prices are for SMALL vehicles in mobile valet service.
 * Eco tiers have been retired — legacy eco bookings map to their standard counterparts.
 */
export const WASH_DEFINITIONS: WashDefinition[] = [
  {
    id: 'MOBILE_BRONZE',
    label: 'Bronze Wash',
    description: 'Interior OR exterior refresh. Quick and affordable.',
    tier: 'BRONZE',
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 15,
  },
  {
    id: 'MOBILE_SILVER',
    label: 'Silver Wash',
    description: 'Interior + exterior. Balanced inside-and-out clean.',
    tier: 'SILVER',
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 25,
  },
  {
    id: 'MOBILE_GOLD',
    label: 'Gold Wash',
    description: 'Interior deep clean — cabin restoration focus.',
    tier: 'GOLD',
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 55,
  },
  {
    id: 'MOBILE_PLATINUM',
    label: 'Platinum Wash',
    description: 'Full valet — interior + exterior with finishing touches.',
    tier: 'PLATINUM',
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 70,
  },
  {
    id: 'MOBILE_DIAMOND',
    label: 'Diamond Wash',
    description: 'Premium full detail — near showroom finish.',
    tier: 'DIAMOND',
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 85,
  },
];

/**
 * Vehicle size adjustment pricing
 * Adjustments are added to base price
 */
export function getVehicleSizeAdjustmentGBP(size: VehicleSize): number {
  switch (size) {
    case 'SMALL':
      return 0;
    case 'MEDIUM':
      return 2;
    case 'LARGE':
      return 4;
    case 'XL':
      return 7;
    case 'XXL':
      return 11;
  }
}

/**
 * Surge pricing calculation
 * Weekday peak (Mon-Fri, 16:00-19:00): +10%
 * Weekends (Sat/Sun): +15%
 */
export function getSurgeInfo(dateTime: Date): SurgeInfo {
  const day = dateTime.getDay(); // 0 = Sun, 6 = Sat
  const hour = dateTime.getHours();

  const isWeekend = day === 0 || day === 6;
  if (isWeekend) {
    return { multiplier: 1.15, label: 'Weekend demand' };
  }

  const isPeakWeekday = hour >= 16 && hour < 19;
  if (isPeakWeekday) {
    return { multiplier: 1.1, label: 'Peak time pricing' };
  }

  return { multiplier: 1, label: undefined };
}

/**
 * Distance surcharge calculation
 * First 4 miles included, then £0.50 per additional mile
 */
export function getDistanceSurchargeGBP(distanceMiles: number | undefined): number {
  if (!distanceMiles) return 0;
  const includedMiles = 4;
  if (distanceMiles <= includedMiles) return 0;
  const extraMiles = Math.max(0, distanceMiles - includedMiles);
  return extraMiles * 0.5;
}

/**
 * Infer vehicle size from DVLA make/model data
 * Uses heuristics based on common vehicle makes/models
 */
export function inferVehicleSizeFromDVLA(make: string, model: string): VehicleSize {
  const makeLower = make.toLowerCase();
  const modelLower = model.toLowerCase();

  // XL vehicles (large vans, trucks)
  if (
    modelLower.includes('transit') ||
    modelLower.includes('sprinter') ||
    modelLower.includes('vivaro') ||
    modelLower.includes('master') ||
    modelLower.includes('crafter') ||
    makeLower.includes('ldv') ||
    modelLower.includes('boxer')
  ) {
    return 'XL';
  }

  // LARGE vehicles (SUVs, large cars)
  if (
    modelLower.includes('range rover') ||
    modelLower.includes('discovery') ||
    modelLower.includes('x5') ||
    modelLower.includes('x7') ||
    modelLower.includes('q7') ||
    modelLower.includes('q8') ||
    modelLower.includes('gle') ||
    modelLower.includes('gls') ||
    modelLower.includes('cayenne') ||
    modelLower.includes('macan') ||
    modelLower.includes('touareg') ||
    modelLower.includes('suv') ||
    makeLower.includes('land rover')
  ) {
    return 'LARGE';
  }

  // MEDIUM vehicles (mid-size sedans, estates)
  if (
    modelLower.includes('5 series') ||
    modelLower.includes('e-class') ||
    modelLower.includes('a6') ||
    modelLower.includes('a4') ||
    modelLower.includes('passat') ||
    modelLower.includes('mondeo') ||
    modelLower.includes('insignia') ||
    modelLower.includes('octavia') ||
    modelLower.includes('superb')
  ) {
    return 'MEDIUM';
  }

  // Default to SMALL (hatchbacks, small cars)
  return 'SMALL';
}

/**
 * Infer vehicle size from vehicle type string (fallback)
 */
export function inferVehicleSizeFromType(vehicleType: string): VehicleSize {
  const typeLower = vehicleType.toLowerCase();

  if (typeLower.includes('van') || typeLower.includes('truck') || typeLower.includes('lorry')) {
    return 'XL';
  }

  if (typeLower.includes('suv') || typeLower.includes('4x4')) {
    return 'LARGE';
  }

  if (typeLower.includes('estate') || typeLower.includes('saloon') || typeLower.includes('sedan')) {
    return 'MEDIUM';
  }

  // Default to SMALL for cars, motorcycles, etc.
  return 'SMALL';
}

/**
 * Get vehicle size from vehicle data
 * Prefers DVLA make/model, falls back to vehicle type
 */
export function getVehicleSize(vehicle: { make?: string; model?: string; type?: string; size?: string }): VehicleSize {
  const stored = String(vehicle.size || '').toLowerCase();
  if (stored === 'small') return 'SMALL';
  if (stored === 'medium') return 'MEDIUM';
  if (stored === 'large') return 'LARGE';
  if (stored === 'xl') return 'XL';
  if (stored === 'xxl') return 'XXL';

  if (vehicle.make && vehicle.model) {
    return inferVehicleSizeFromDVLA(vehicle.make, vehicle.model);
  }
  
  if (vehicle.type) {
    return inferVehicleSizeFromType(vehicle.type);
  }

  // Default fallback
  return 'SMALL';
}

/**
 * Main pricing calculator
 * Calculates final display price with all adjustments
 */
export function calculateDisplayPrice(input: FrontendPricingInput): FrontendPricingBreakdown {
  const wash = WASH_DEFINITIONS.find(w => w.id === input.washId);
  if (!wash) {
    // Fallback – no wash found, return zeros
    return {
      basePriceGBP: 0,
      vehicleSizeAdjustmentGBP: 0,
      distanceSurchargeGBP: 0,
      surgeMultiplier: 1,
      finalDisplayPriceGBP: 0,
    };
  }

  // Start with base price (SMALL car baseline)
  let price = wash.basePriceSmallGBP;
  const vehicleSizeAdjustmentGBP = getVehicleSizeAdjustmentGBP(input.vehicleSize);
  price += vehicleSizeAdjustmentGBP;

  let distanceSurchargeGBP = 0;
  if (wash.isMobile && input.isMobile) {
    distanceSurchargeGBP = getDistanceSurchargeGBP(input.distanceMiles);
    price += distanceSurchargeGBP;
  }

  let surgeMultiplier = 1;
  let surgeLabel: string | undefined = undefined;
  if (wash.isMobile && input.isMobile) {
    const surge = getSurgeInfo(input.scheduledDateTime);
    surgeMultiplier = surge.multiplier;
    surgeLabel = surge.label;
    price *= surgeMultiplier;
  }

  const finalDisplayPriceGBP = Number(price.toFixed(2));

  return {
    basePriceGBP: wash.basePriceSmallGBP,
    vehicleSizeAdjustmentGBP,
    distanceSurchargeGBP,
    surgeMultiplier,
    surgeLabel,
    finalDisplayPriceGBP,
  };
}

/** Legacy eco ids → standard wash tier id (eco tiers retired). */
const LEGACY_ECO_TO_STANDARD: Record<string, string> = {
  'eco-bronze-wash': 'bronze-wash',
  'eco-silver-wash': 'silver-wash',
  'eco-gold-wash': 'gold-wash',
  'eco-platinum-wash': 'platinum-wash',
  'eco-emerald-wash': 'emerald-wash',
};

/**
 * Map service ID to wash definition ID.
 * Handles legacy eco-* IDs by routing through to their standard counterpart.
 */
export function mapServiceIdToWashId(serviceId: string): string | null {
  const resolved = LEGACY_ECO_TO_STANDARD[serviceId] ?? serviceId;
  const mapping: Record<string, string> = {
    'bronze-wash': 'MOBILE_BRONZE',
    'silver-wash': 'MOBILE_SILVER',
    'gold-wash': 'MOBILE_GOLD',
    'platinum-wash': 'MOBILE_PLATINUM',
    'emerald-wash': 'MOBILE_DIAMOND',
  };
  return mapping[resolved] ?? null;
}


