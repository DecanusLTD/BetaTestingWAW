/**
 * Service ID Mapper
 * 
 * Maps existing service IDs from serviceOptions.ts to WASH_DEFINITIONS IDs.
 * Legacy eco-* IDs route through to their standard wash counterparts.
 */

import { WASH_DEFINITIONS, WashDefinition } from './pricingEngine';

const SERVICE_ID_MAPPING: Record<string, string> = {
  'bronze-wash': 'MOBILE_BRONZE',
  'silver-wash': 'MOBILE_SILVER',
  'emerald-wash': 'MOBILE_DIAMOND',
  'gold-wash': 'MOBILE_GOLD',
  'platinum-wash': 'MOBILE_PLATINUM',
};

/** Legacy eco wash ids map to their standard counterparts. */
const LEGACY_ECO_MAPPING: Record<string, string> = {
  'eco-bronze-wash': 'bronze-wash',
  'eco-silver-wash': 'silver-wash',
  'eco-emerald-wash': 'emerald-wash',
  'eco-gold-wash': 'gold-wash',
  'eco-platinum-wash': 'platinum-wash',
};

/**
 * Get wash definition from existing service ID.
 * Handles legacy eco-* IDs by mapping through to standard wash tier.
 */
export function getWashDefinitionFromServiceId(serviceId: string): WashDefinition | null {
  const resolved = LEGACY_ECO_MAPPING[serviceId] ?? serviceId;
  const washId = SERVICE_ID_MAPPING[resolved];
  if (!washId) return null;
  return WASH_DEFINITIONS.find(w => w.id === washId) ?? null;
}

export function isMobileWashService(serviceId: string): boolean {
  const resolved = LEGACY_ECO_MAPPING[serviceId] ?? serviceId;
  return resolved in SERVICE_ID_MAPPING;
}

export function getMappedServiceIds(): string[] {
  return Object.keys(SERVICE_ID_MAPPING);
}
