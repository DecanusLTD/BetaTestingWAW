import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '../lib/supabase';
import { hapticFeedback } from '../services/HapticFeedbackService';
import { ValeterStatsService } from '../services/Valeterstatsservice';
import { getCustomerDisplayName, fetchProfileById, resolveCustomerAvatarFromProfileRowAsync, resolveCustomerMediaUrlAsync } from '../utils/customerProfiles';
import { releaseBookingValeterPayout } from '../services/bookingPaymentRequestService';
import { promptAndSendBookingPhotoMessage } from '../services/bookingChatMediaService';
import { getStages, getStageProgressPercent, getValeterJobStatusMessage } from '../utils/trackingStatusHelpers';
import {
  getServiceTrackingCategory,
  getStartServiceActionLabel,
} from '../utils/serviceNameMapper';
import { fetchDrivingRoute } from '../utils/drivingRoute';

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 3958.8;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export type ValeterTrackingStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'scheduled'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export type ValeterTrackingJob = {
  id: string;
  status: ValeterTrackingStatus;
  user_id?: string | null;
  service_type?: string | null;
  service_name?: string | null;
  location_lat?: number | string | null;
  location_lng?: number | string | null;
  location_address?: string | null;
  price?: number | string | null;
  scheduled_at?: string | null;
  vehicle_id?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_photo?: string | null;
};

export type BookingVehicleItem = {
  id: string;
  make?: string;
  model?: string;
  registration?: string;
  colour?: string;
  photo?: string | null;
};

type VehicleDetails = {
  registration?: string;
  make?: string;
  model?: string;
  colour?: string;
  photo?: string;
  /** Full booking vehicle line (supports multiple cars). */
  summaryLine?: string;
} | null;

async function resolveValeterOrigin(
  valeterId: string,
  liveOrigin?: { lat?: number | null; lng?: number | null }
): Promise<{ lat: number; lng: number } | null> {
  const liveLat = liveOrigin?.lat;
  const liveLng = liveOrigin?.lng;
  if (liveLat != null && liveLng != null && Number.isFinite(liveLat) && Number.isFinite(liveLng)) {
    return { lat: liveLat, lng: liveLng };
  }
  const { data } = await supabase
    .from('valeter_presence')
    .select('last_lat, last_lng')
    .eq('user_id', valeterId)
    .maybeSingle();
  if (data?.last_lat == null || data?.last_lng == null) return null;
  return { lat: Number(data.last_lat), lng: Number(data.last_lng) };
}

export function getValeterJobProgress(status: ValeterTrackingStatus): number {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
      return 10;
    case 'confirmed':
    case 'scheduled':
      return 25;
    case 'en_route':
      return 50;
    case 'arrived':
      return 70;
    case 'in_progress':
      return 90;
    case 'completed':
      return 100;
    default:
      return 20;
  }
}

function vehicleLabel(row: {
  make?: string | null;
  model?: string | null;
  registration?: string | null;
}): string {
  const name = [row.make, row.model].filter(Boolean).join(' ').trim();
  const reg = row.registration ? ` (${row.registration})` : '';
  return `${name}${reg}`.trim();
}

function matchVehiclesToBookingInfo(
  rows: Array<{
    id: string;
    make?: string | null;
    model?: string | null;
    registration?: string | null;
    colour?: string | null;
    color?: string | null;
    photo?: string | null;
  }>,
  vehicleInfo?: string | null,
  primaryVehicleId?: string | null
): typeof rows {
  if (!rows.length) return [];
  const info = typeof vehicleInfo === 'string' ? vehicleInfo.trim() : '';
  if (!info) {
    const primary = primaryVehicleId ? rows.find((r) => r.id === primaryVehicleId) : null;
    return primary ? [primary] : rows.slice(0, 1);
  }

  const segments = info.split('·').map((s) => s.trim().toLowerCase()).filter(Boolean);
  const matched: typeof rows = [];
  const used = new Set<string>();

  for (const segment of segments) {
    const byReg = rows.find((r) => {
      if (!r.registration || used.has(r.id)) return false;
      return segment.includes(String(r.registration).trim().toLowerCase());
    });
    if (byReg) {
      matched.push(byReg);
      used.add(byReg.id);
      continue;
    }
    const byName = rows.find((r) => {
      if (used.has(r.id)) return false;
      const label = vehicleLabel(r).toLowerCase();
      return Boolean(label && (segment.includes(label) || label.includes(segment)));
    });
    if (byName) {
      matched.push(byName);
      used.add(byName.id);
    }
  }

  if (matched.length > 0) return matched;
  const primary = primaryVehicleId ? rows.find((r) => r.id === primaryVehicleId) : null;
  return primary ? [primary] : rows.slice(0, 1);
}

async function loadVehicleDetails(
  userId: string | null,
  booking: { vehicle_id?: string | null; vehicle_info?: string | null } | null,
  setVehicleDetails: (v: VehicleDetails) => void,
  setBookingVehicles: (v: BookingVehicleItem[]) => void
) {
  const summaryLine =
    typeof booking?.vehicle_info === 'string' && booking.vehicle_info.trim()
      ? booking.vehicle_info.trim()
      : undefined;

  if (!userId && !summaryLine) {
    setBookingVehicles([]);
    return;
  }

  try {
    const selectCols = 'id, registration, make, model, colour, color, photo';
    let rows: Array<{
      id: string;
      make?: string | null;
      model?: string | null;
      registration?: string | null;
      colour?: string | null;
      color?: string | null;
      photo?: string | null;
    }> = [];

    if (userId) {
      let res = await supabase.from('customer_vehicles').select(selectCols).eq('user_id', userId);
      if (res.error && /colour|color|schema cache|does not exist/i.test(res.error.message || '')) {
        const fallback = await supabase
          .from('customer_vehicles')
          .select('id, registration, make, model, photo')
          .eq('user_id', userId);
        rows = ((fallback.data as typeof rows | null) || []).map((r) => ({
          ...r,
          colour: null,
          color: null,
        }));
      } else {
        rows = (res.data as typeof rows) || [];
      }
    } else if (booking?.vehicle_id) {
      const { data } = await supabase
        .from('customer_vehicles')
        .select(selectCols)
        .eq('id', booking.vehicle_id)
        .maybeSingle();
      if (data) rows = [data as (typeof rows)[0]];
    }

    const matched = matchVehiclesToBookingInfo(rows, booking?.vehicle_info, booking?.vehicle_id);
    const withPhotos: BookingVehicleItem[] = await Promise.all(
      matched.map(async (row) => ({
        id: row.id,
        make: row.make ?? undefined,
        model: row.model ?? undefined,
        registration: row.registration ?? undefined,
        colour: row.colour || row.color || undefined,
        photo: row.photo ? (await resolveCustomerMediaUrlAsync(row.photo)) || null : null,
      }))
    );

    if (withPhotos.length === 0 && summaryLine) {
      const parts = summaryLine.split('·').map((s) => s.trim()).filter(Boolean);
      setBookingVehicles(
        parts.map((label, i) => {
          const regMatch = /\(([^)]+)\)\s*$/.exec(label);
          const registration = regMatch?.[1]?.trim();
          const name = label.replace(/\s*\([^)]+\)\s*$/, '').trim();
          const [make, ...rest] = name.split(/\s+/);
          return {
            id: `info-${i}`,
            make: make || name || 'Vehicle',
            model: rest.join(' ') || undefined,
            registration,
            photo: null,
          };
        })
      );
    } else {
      setBookingVehicles(withPhotos);
    }

    const primary = withPhotos[0];
    setVehicleDetails({
      registration: primary?.registration,
      make: primary?.make,
      model: primary?.model,
      colour: primary?.colour,
      photo: primary?.photo || undefined,
      summaryLine,
    });
  } catch {
    if (summaryLine) {
      setVehicleDetails({ summaryLine });
      const parts = summaryLine.split('·').map((s) => s.trim()).filter(Boolean);
      setBookingVehicles(
        parts.map((label, i) => ({
          id: `info-${i}`,
          make: label,
          photo: null,
        }))
      );
    } else {
      setBookingVehicles([]);
    }
  }
}

export function useValeterJobTracking(
  jobId: string | null,
  valeterId: string | null,
  options?: {
    onClose?: () => void;
    onJobUpdated?: () => void;
    originLat?: number | null;
    originLng?: number | null;
  }
) {
  const onCloseRef = useRef(options?.onClose);
  const onJobUpdatedRef = useRef(options?.onJobUpdated);
  onCloseRef.current = options?.onClose;
  onJobUpdatedRef.current = options?.onJobUpdated;
  const [job, setJob] = useState<ValeterTrackingJob | null>(null);
  const [status, setStatus] = useState<ValeterTrackingStatus>('pending_payment');
  const [customerName, setCustomerName] = useState('Customer');
  const [customerPhotoUrl, setCustomerPhotoUrl] = useState<string | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<VehicleDetails>(null);
  const [bookingVehicles, setBookingVehicles] = useState<BookingVehicleItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [infoSheetVisible, setInfoSheetVisible] = useState(false);
  const [etaMinutes, setEtaMinutes] = useState<number | null>(null);
  const [distanceMi, setDistanceMi] = useState<number | null>(null);
  const [routeCoordinates, setRouteCoordinates] = useState<{ latitude: number; longitude: number }[] | null>(null);

  const loadJob = useCallback(async (id: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
      if (error || !data) {
        Alert.alert('Error', 'Job not found');
        onCloseRef.current?.();
        return;
      }
      const row = data as ValeterTrackingJob;
      setJob({
        ...row,
        vehicle_photo: (await resolveCustomerMediaUrlAsync(row.vehicle_photo)) || row.vehicle_photo,
      });
      setStatus(row.status);
      if (row.user_id) {
        setCustomerName(await getCustomerDisplayName(row.user_id));
        const profile = await fetchProfileById(row.user_id);
        setCustomerPhotoUrl(await resolveCustomerAvatarFromProfileRowAsync(profile));
      } else {
        setCustomerName('Customer');
        setCustomerPhotoUrl(null);
      }
      await loadVehicleDetails(row.user_id ?? null, row, setVehicleDetails, setBookingVehicles);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to load job');
      onCloseRef.current?.();
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!jobId) {
      setJob(null);
      setRouteCoordinates(null);
      setCustomerPhotoUrl(null);
      setVehicleDetails(null);
      setBookingVehicles([]);
      return;
    }
    loadJob(jobId);
  }, [jobId, loadJob]);

  useEffect(() => {
    if (!jobId) return;
    const ch = supabase
      .channel(`valeter-dash-tracking-${jobId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${jobId}` },
        (payload) => {
          const next = (payload.new as { status?: unknown })?.status;
          if (next) {
            setStatus(next as ValeterTrackingStatus);
            setJob((prev) => (prev ? { ...prev, status: next as ValeterTrackingStatus } : prev));
          }
          if (next === 'completed') {
            router.push({ pathname: '/valeter/jobs/complete', params: { jobId } } as any);
          }
          if (next === 'cancelled') {
            onCloseRef.current?.();
          }
          onJobUpdatedRef.current?.();
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [jobId]);

  useEffect(() => {
    if (!valeterId || !job?.location_lat || !job?.location_lng) {
      setEtaMinutes(null);
      setDistanceMi(null);
      setRouteCoordinates(null);
      return;
    }

    // Keep an ETA on the header for any pre-arrival live status.
    const shouldRoute =
      status === 'en_route' ||
      status === 'confirmed' ||
      status === 'scheduled' ||
      status === 'pending_payment' ||
      status === 'arrived';

    if (!shouldRoute) {
      setEtaMinutes(null);
      setDistanceMi(null);
      setRouteCoordinates(null);
      return;
    }

    let cancelled = false;
    (async () => {
      const origin = await resolveValeterOrigin(valeterId, {
        lat: options?.originLat,
        lng: options?.originLng,
      });
      if (cancelled || !origin) {
        setRouteCoordinates(null);
        setEtaMinutes(null);
        setDistanceMi(null);
        return;
      }

      const destLat = Number(job.location_lat);
      const destLng = Number(job.location_lng);

      if (status === 'arrived') {
        const mi = haversineMi(origin.lat, origin.lng, destLat, destLng);
        if (!cancelled) {
          setRouteCoordinates(null);
          setDistanceMi(Math.round(mi * 10) / 10);
          setEtaMinutes(0);
        }
        return;
      }

      const route = await fetchDrivingRoute(origin.lat, origin.lng, destLat, destLng);
      if (cancelled) return;

      if (route && route.coordinates.length > 1) {
        setRouteCoordinates(route.coordinates);
        setDistanceMi(route.distanceMi);
        setEtaMinutes(route.durationMinutes);
        return;
      }

      // Fallback when routing API is unavailable.
      const mi = haversineMi(origin.lat, origin.lng, destLat, destLng);
      const mins = Math.max(1, Math.round((mi / 18) * 60));
      setRouteCoordinates(null);
      setDistanceMi(Math.round(mi * 10) / 10);
      setEtaMinutes(mins);
    })();

    return () => {
      cancelled = true;
    };
  }, [valeterId, job?.id, job?.location_lat, job?.location_lng, status, options?.originLat, options?.originLng]);

  const updateStatus = useCallback(
    async (newStatus: ValeterTrackingStatus) => {
      if (!jobId || !valeterId) return;
      await hapticFeedback('medium');
      try {
        const payload: { status: string; completed_at?: string } = { status: newStatus };
        if (newStatus === 'completed') payload.completed_at = new Date().toISOString();

        const { error } = await supabase.from('bookings').update(payload).eq('id', jobId);
        if (error) throw error;

        setStatus(newStatus);
        if (newStatus === 'completed') {
          await ValeterStatsService.recordJobCompletion(valeterId, jobId);
          try {
            await releaseBookingValeterPayout({ bookingId: jobId });
          } catch (releaseError: any) {
            Alert.alert(
              'Job completed',
              releaseError?.message || 'Job marked complete; payout release pending.'
            );
          }
          router.push({ pathname: '/valeter/jobs/complete', params: { jobId } } as any);
        }
        onJobUpdatedRef.current?.();
      } catch (e: any) {
        Alert.alert('Error', e?.message ?? 'Failed to update');
      }
    },
    [jobId, valeterId]
  );

  const startWashWithPhoto = useCallback(async () => {
    if (!jobId || !valeterId) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: jobId,
        senderId: valeterId,
        senderRole: 'valeter',
        content: 'BEFORE IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before starting.',
      });
      if (!sent) return;
      await updateStatus('in_progress');
    } catch (e: any) {
      Alert.alert('Photo required', e?.message ?? 'Could not take or send the photo.');
    }
  }, [jobId, valeterId, updateStatus]);

  const completeWashWithPhoto = useCallback(async () => {
    if (!jobId || !valeterId) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: jobId,
        senderId: valeterId,
        senderRole: 'valeter',
        content: 'Finished IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before finishing.',
      });
      if (!sent) return;
      await updateStatus('completed');
    } catch (e: any) {
      Alert.alert('Photo required', e?.message ?? 'Could not take or send the photo.');
    }
  }, [jobId, valeterId, updateStatus]);

  const serviceCategory = getServiceTrackingCategory(job?.service_type, job?.service_name);

  const nextAction = useMemo(() => {
    const startLabel = getStartServiceActionLabel(serviceCategory);
    switch (status) {
      case 'pending_valeter_acceptance':
        return { label: 'Accept job', action: () => updateStatus('pending_payment') };
      case 'pending_payment':
        return null;
      case 'confirmed':
      case 'scheduled':
        return { label: 'Start journey', action: () => updateStatus('en_route') };
      case 'en_route':
        return { label: 'Mark arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: startLabel, action: () => startWashWithPhoto() };
      case 'in_progress':
        return { label: 'Mark complete', action: () => completeWashWithPhoto() };
      default:
        return null;
    }
  }, [status, updateStatus, startWashWithPhoto, completeWashWithPhoto, serviceCategory]);

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';

  const handleCancel = useCallback(() => {
    if (!canCancel || !jobId) return;
    hapticFeedback('light');
    Alert.alert('Cancel job', 'Cancel this job? The customer will be notified.', [
      { text: 'No', style: 'cancel' },
      {
        text: 'Yes, cancel',
        style: 'destructive',
        onPress: () => {
          (async () => {
            setCancelling(true);
            const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', jobId);
            if (error) Alert.alert('Error', error.message);
            else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Job cancelled.', [{ text: 'OK', onPress: () => onCloseRef.current?.() }]);
            }
            setCancelling(false);
            onJobUpdatedRef.current?.();
          })();
        },
      },
    ]);
  }, [canCancel, jobId]);

  const handleChat = useCallback(() => {
    if (!jobId) return;
    hapticFeedback('light');
    router.push({ pathname: '/valeter/jobs/chat', params: { bookingId: jobId } } as any);
  }, [jobId]);

  const customerCoords = useMemo(() => {
    if (!job?.location_lat || !job?.location_lng) return null;
    return { latitude: Number(job.location_lat), longitude: Number(job.location_lng) };
  }, [job?.location_lat, job?.location_lng]);

  const stages = getStages(status, serviceCategory, true);
  const stageProgressPercent = getStageProgressPercent(status, serviceCategory, true);
  const statusMessage = useMemo(() => getValeterJobStatusMessage(status), [status]);

  return {
    job,
    status,
    customerName,
    customerPhotoUrl,
    vehicleDetails,
    bookingVehicles,
    loading,
    cancelling,
    infoSheetVisible,
    setInfoSheetVisible,
    etaMinutes,
    distanceMi,
    routeCoordinates,
    customerCoords,
    nextAction,
    canCancel,
    handleCancel,
    handleChat,
    stages,
    stageProgressPercent,
    statusMessage,
    reload: () => jobId && loadJob(jobId),
  };
}
