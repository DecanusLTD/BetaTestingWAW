import { useEffect, useRef } from 'react';
import { useGlobalSearchParams, usePathname, useRouter } from 'expo-router';
import { supabase } from '../lib/supabase';
import { useAuth } from '../providers/enhanced-auth-context';
import {
  notifyValeterChatMessage,
  notifyValeterTrackingUpdate,
  preparePhoneNotifications,
  subscribeValeterNotificationResponses,
} from '../services/valeterJobPhoneNotifications';
import { getCustomerDisplayName } from '../utils/customerProfiles';

/**
 * Global valeter popup alerts: chat messages, tracking status changes, and
 * notification tap routing. Job-request alerts stay on the dashboard realtime path.
 */
export function useValeterAlertNotifications() {
  const { user } = useAuth();
  const pathname = usePathname() || '';
  const router = useRouter();
  const params = useGlobalSearchParams<{ bookingId?: string | string[] }>();
  const pathnameRef = useRef(pathname);
  const activeChatBookingIdRef = useRef<string | null>(null);

  const bookingParam = Array.isArray(params.bookingId) ? params.bookingId[0] : params.bookingId;
  pathnameRef.current = pathname;
  activeChatBookingIdRef.current =
    pathname.includes('/valeter/jobs/chat') && bookingParam ? String(bookingParam) : null;

  useEffect(() => {
    if (user?.userType !== 'valeter' || !user?.id) return;
    preparePhoneNotifications().catch(() => undefined);
    return subscribeValeterNotificationResponses(router);
  }, [user?.id, user?.userType, router]);

  useEffect(() => {
    if (user?.userType !== 'valeter' || !user?.id) return;
    const userId = user.id;

    const channel = supabase
      .channel(`valeter-alerts:${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'booking_messages',
        },
        (payload) => {
          void (async () => {
            const row = payload.new as {
              id?: string;
              booking_id?: string;
              sender_id?: string | null;
              message_type?: string | null;
              content?: string | null;
              media_url?: string | null;
            };
            const messageId = row.id;
            const bookingId = row.booking_id;
            const senderId = row.sender_id;
            if (!messageId || !bookingId || !senderId) return;
            if (senderId === userId) return;
            if (activeChatBookingIdRef.current === bookingId) return;

            const { data: booking } = await supabase
              .from('bookings')
              .select('id, valeter_id, user_id, service_name')
              .eq('id', bookingId)
              .maybeSingle();

            if (!booking || booking.valeter_id !== userId) return;

            let senderLabel = 'Customer';
            try {
              if (booking.user_id) {
                senderLabel = await getCustomerDisplayName(booking.user_id);
              }
            } catch {
              // keep default
            }

            let preview = 'Sent you a message';
            if (row.message_type === 'image') preview = 'Sent a photo';
            else if (row.message_type === 'voice') preview = 'Sent a voice message';
            else if (row.message_type === 'payment_request') preview = 'Sent a payment request';
            else if (row.content?.trim()) preview = row.content.trim();

            await notifyValeterChatMessage({
              bookingId,
              messageId,
              preview,
              senderLabel,
            });
          })();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${userId}`,
        },
        (payload) => {
          void (async () => {
            const next = payload.new as {
              id?: string;
              status?: string;
              service_name?: string | null;
            };
            const prev = payload.old as { status?: string } | undefined;
            const bookingId = next.id;
            const status = next.status;
            if (!bookingId || !status) return;
            if (prev?.status && prev.status === status) return;
            if (status === 'pending_valeter_acceptance') return;

            const path = pathnameRef.current;
            const onTrackingUi =
              path.includes('/valeter/valeter-dashboard') || path.includes('/valeter/jobs/tracking');
            const selfDriven = ['en_route', 'arrived', 'in_progress', 'completed'].includes(status);
            if (onTrackingUi && selfDriven) return;

            await notifyValeterTrackingUpdate({
              bookingId,
              status,
              serviceName: next.service_name,
            });
          })();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, user?.userType]);
}
