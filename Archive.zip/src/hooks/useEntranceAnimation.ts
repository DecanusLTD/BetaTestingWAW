import { useRef, useEffect } from 'react';
import { Animated } from 'react-native';
import { MOTION } from '../constants/premiumTokens';

/**
 * Returns animated values for a staggered entrance (fade + slide up).
 * Use for list items or sections that should animate in on mount.
 */
export function useEntranceAnimation(delayMs: number = 0) {
  const opacity = useRef(new Animated.Value(delayMs > 0 ? 0 : 1)).current;
  const translateY = useRef(new Animated.Value(delayMs > 0 ? 14 : 0)).current;

  useEffect(() => {
    if (delayMs <= 0) return;
    const timer = setTimeout(() => {
      Animated.parallel([
        Animated.timing(opacity, {
          toValue: 1,
          duration: MOTION.entranceMs,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, {
          toValue: 0,
          duration: MOTION.entranceMs,
          useNativeDriver: true,
        }),
      ]).start();
    }, delayMs);
    return () => clearTimeout(timer);
  }, [delayMs, opacity, translateY]);

  return { opacity, translateY };
}
