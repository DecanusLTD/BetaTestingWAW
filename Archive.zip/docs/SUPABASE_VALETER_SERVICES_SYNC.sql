alter table public.valeter_profiles
  add column if not exists services_offered text[] not null default '{}'::text[];

create or replace function public.sync_valeter_services_offered()
returns trigger
language plpgsql
as $$
declare
  offered text[] := '{}'::text[];
  tier_key text;
  tier_value jsonb;
  item jsonb;
  has_price boolean;
begin
  if tg_op = 'DELETE' then
    update public.valeter_profiles
      set services_offered = '{}'::text[],
          updated_at = now()
    where user_id = old.valeter_id;
    return old;
  end if;

  if new.tier_pricing is not null then
    for tier_key, tier_value in
      select key, value from jsonb_each(new.tier_pricing)
    loop
      has_price := exists (
        select 1
        from jsonb_each_text(coalesce(tier_value->'prices', '{}'::jsonb)) as p(size_key, price_text)
        where nullif(trim(p.price_text), '') is not null
          and (p.price_text)::numeric > 0
      );

      if coalesce((tier_value->>'enabled')::boolean, true) or has_price then
        offered := array_append(
          offered,
          case tier_key
            when 'bronze' then 'Bronze Wash'
            when 'silver' then 'Silver Wash'
            when 'gold' then 'Gold Wash'
            when 'platinum' then 'Platinum Wash'
            when 'emerald' then 'Diamond Wash'
            else null
          end
        );
      end if;
    end loop;
  end if;

  if coalesce(new.detailing_offered, false) and new.detailing_menu ? 'items' then
    for item in
      select * from jsonb_array_elements(coalesce(new.detailing_menu->'items', '[]'::jsonb))
    loop
      if coalesce((item->>'enabled')::boolean, false) then
        offered := array_append(
          offered,
          case item->>'key'
            when 'ceramic-coating' then 'Ceramic Coating'
            when 'machine-polishing' then 'Machine Polishing'
            when 'soft-top-restoration' then 'Soft Top Restoration'
            when 'mould-removal' then 'Mould Removal'
            else null
          end
        );
      end if;
    end loop;
  end if;

  if coalesce(new.repairs_offered, false) and new.repair_menu ? 'items' then
    for item in
      select * from jsonb_array_elements(coalesce(new.repair_menu->'items', '[]'::jsonb))
    loop
      if coalesce((item->>'enabled')::boolean, false) then
        offered := array_append(
          offered,
          case item->>'key'
            when 'headlight-restoration' then 'Headlight Restoration'
            when 'scratch-removal' then 'Scratch Removal'
            when 'paint-chip-repair' then 'Paint Chip Repair'
            when 'trim-restoration' then 'Trim Restoration'
            when 'leather-repair' then 'Leather Repair'
            else null
          end
        );
      end if;
    end loop;
  end if;

  offered := array_remove(offered, null);

  update public.valeter_profiles
    set services_offered = coalesce(offered, '{}'::text[]),
        updated_at = now()
  where user_id = new.valeter_id;

  return new;
end;
$$;

drop trigger if exists trg_valeter_service_settings_sync_services on public.valeter_service_settings;
create trigger trg_valeter_service_settings_sync_services
after insert or update or delete on public.valeter_service_settings
for each row execute function public.sync_valeter_services_offered();

update public.valeter_service_settings
set updated_at = updated_at;
