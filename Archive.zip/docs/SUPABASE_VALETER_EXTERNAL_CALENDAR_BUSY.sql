-- Busy windows copied from the valeter's device calendar (see valeterExternalCalendarBusy.ts).
-- Run in Supabase SQL editor so schedule clash checks work across sessions / devices.

ALTER TABLE valeter_profiles
  ADD COLUMN IF NOT EXISTS external_calendar_busy JSONB NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN valeter_profiles.external_calendar_busy IS
  'Array of {start,end} ISO timestamps from device calendar; used with accepted bookings to avoid double-booking.';
