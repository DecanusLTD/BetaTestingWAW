-- Run in Supabase SQL editor (once) to support:
-- • Location site type: fixed unit vs mobile operation
-- • Up to 6 custom service names per location (JSON array)
-- • Valeter work mode: mobile fleet vs assigned to one location

-- Location: how the site operates
ALTER TABLE public.car_wash_locations
  ADD COLUMN IF NOT EXISTS site_type text NOT NULL DEFAULT 'unit';

COMMENT ON COLUMN public.car_wash_locations.site_type IS 'unit = fixed physical site; mobile = mobile / roaming operation for this listing';

-- Optional: enforce allowed values (uncomment if you want a DB constraint)
-- ALTER TABLE public.car_wash_locations DROP CONSTRAINT IF EXISTS car_wash_locations_site_type_check;
-- ALTER TABLE public.car_wash_locations ADD CONSTRAINT car_wash_locations_site_type_check
--   CHECK (site_type IN ('unit', 'mobile'));

-- Custom services (max 6 strings; app enforces length)
ALTER TABLE public.car_wash_locations
  ADD COLUMN IF NOT EXISTS custom_services jsonb NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.car_wash_locations.custom_services IS 'JSON array (max 6) of custom services: { name, enabled, description, price_by_size {small,medium,large,xl,xxl}, duration_minutes }. Legacy: array of strings (names only) still supported.';

-- Valeter assignment (profiles.user_type = valeter)
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS valeter_work_mode text NOT NULL DEFAULT 'mobile';

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS assigned_location_id uuid NULL REFERENCES public.car_wash_locations(id) ON DELETE SET NULL;

COMMENT ON COLUMN public.profiles.valeter_work_mode IS 'mobile = fleet / any site; location = primarily assigned to assigned_location_id';
COMMENT ON COLUMN public.profiles.assigned_location_id IS 'When valeter_work_mode = location, primary car_wash_locations row';

-- Optional check (uncomment to enforce)
-- ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_valeter_work_mode_check;
-- ALTER TABLE public.profiles ADD CONSTRAINT profiles_valeter_work_mode_check
--   CHECK (valeter_work_mode IN ('mobile', 'location'));
