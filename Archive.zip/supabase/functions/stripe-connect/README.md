# Stripe Connect Edge Function

This function handles:

1. Creating/reusing a Stripe Express account for the logged-in business user
2. Generating an onboarding account link
3. Syncing Stripe account status back into `public.profiles`

Related webhook function:

1. `supabase/functions/stripe-connect-webhook/index.ts`
2. Handles `account.updated` events from Stripe and keeps `profiles` in sync

## Required Supabase function secrets

Set these in your Supabase project before deploying:

1. `SUPABASE_URL`
2. `SUPABASE_SERVICE_ROLE_KEY`
3. `STRIPE_SECRET_KEY`
4. `STRIPE_WEBHOOK_SECRET` (for webhook function)

Example:

```bash
supabase secrets set \
  SUPABASE_URL="https://<your-project>.supabase.co" \
  SUPABASE_SERVICE_ROLE_KEY="<service-role-key>" \
  STRIPE_SECRET_KEY="sk_live_or_test_..."
```

## Deploy

```bash
supabase functions deploy stripe-connect
supabase functions deploy stripe-connect-webhook --no-verify-jwt
```

## App calls

The app invokes this function with:

1. `action: "create_onboarding_link"` (requires `returnUrl`, `refreshUrl`)
2. `action: "get_status"`

## Stripe webhook endpoint

After deploy, configure Stripe webhook to:

```text
https://<your-project-ref>.functions.supabase.co/stripe-connect-webhook
```

Subscribe to at least:

1. `account.updated`
