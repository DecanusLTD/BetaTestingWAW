// supabase/functions/stripe-connect/index.ts
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.25.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function profileDebugPayload(
  userId: string,
  scope: { table: StripeProfileTable; rowMatchKey: 'id' | 'user_id'; rowMatchValue: string; roleLabel: 'business' | 'valeter' },
  businessProfile: StripeProfileRow | null,
  valeterProfile: StripeProfileRow | null
) {
  return {
    userId,
    scope,
    found: {
      businessProfile: !!businessProfile,
      valeterProfile: !!valeterProfile,
    },
    ids: {
      businessProfileId: businessProfile?.id ?? null,
      valeterUserId: valeterProfile?.user_id ?? null,
    },
    profileTypes: {
      businessUserType: businessProfile?.user_type ?? null,
      businessRole: businessProfile?.role ?? null,
      valeterUserType: valeterProfile?.user_type ?? null,
      valeterRole: valeterProfile?.role ?? null,
    },
  };
}

async function getAuthedUserId(req: Request): Promise<string | null> {
  const authHeader = req.headers.get('Authorization') ?? '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (!token) return null;

  const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user?.id) return null;
  return data.user.id;
}

type StripeProfileTable = 'profiles' | 'valeter_profiles';

type StripeProfileRow = {
  id?: string | null;
  user_id?: string | null;
  email?: string | null;
  full_name?: string | null;
  user_type?: string | null;
  role?: string | null;
  terms_status?: string | null;
  terms_version?: string | null;
  terms_accepted_at?: string | null;
  terms_declined_at?: string | null;
  terms_details?: Record<string, unknown> | null;
  stripe_account_id?: string | null;
  stripe_connect_status?: string | null;
  stripe_details?: Record<string, unknown> | null;
  stripe_onboarding_started_at?: string | null;
  stripe_onboarding_completed_at?: string | null;
};

function getStripeProfileScope(profile: StripeProfileRow): {
  table: StripeProfileTable;
  rowMatchKey: 'id' | 'user_id';
  rowMatchValue: string;
  roleLabel: 'business' | 'valeter';
} {
  const userType = String(profile.user_type || '').toLowerCase();
  const role = String(profile.role || '').toLowerCase();
  const isBusiness = userType === 'organization' || role === 'organization' || userType === 'business' || role === 'business';
  if (isBusiness) {
    return {
      table: 'profiles',
      rowMatchKey: 'id',
      rowMatchValue: String(profile.id || ''),
      roleLabel: 'business',
    };
  }

  return {
    table: 'profiles',
    rowMatchKey: 'id',
    rowMatchValue: String(profile.id || profile.user_id || ''),
    roleLabel: 'valeter',
  };
}

async function ensureValeterProfilesRow(
  admin: ReturnType<typeof createClient>,
  userId: string,
  seed: StripeProfileRow | null
): Promise<StripeProfileRow | null> {
  const { data: existing } = await admin
    .from('profiles')
    .select(
      'id,email,full_name,user_type,role,terms_status,terms_version,terms_accepted_at,terms_declined_at,terms_details,stripe_account_id,stripe_connect_status,stripe_details'
    )
    .eq('id', userId)
    .maybeSingle();
  if (existing) return existing as StripeProfileRow;

  const insertPayload = {
    id: userId,
    email: seed?.email ?? null,
    full_name: seed?.full_name ?? null,
    user_type: seed?.user_type || 'valeter',
    role: seed?.role || 'valeter',
    stripe_connect_status: 'not_started',
  };

  const { data: created, error } = await admin
    .from('profiles')
    .upsert(insertPayload as any, { onConflict: 'id' })
    .select(
      'id,email,full_name,user_type,role,terms_status,terms_version,terms_accepted_at,terms_declined_at,terms_details,stripe_account_id,stripe_connect_status,stripe_details'
    )
    .maybeSingle();

  if (error) {
    console.error('[stripe-connect] ensureValeterProfilesRow', error.message);
    return null;
  }
  return (created as StripeProfileRow | null) ?? null;
}

async function loadStripeProfile(admin: ReturnType<typeof createClient>, userId: string) {
  const [{ data: businessProfile }, { data: valeterProfile }] = await Promise.all([
    admin
      .from('profiles')
      .select('id,email,full_name,user_type,role,terms_status,terms_version,terms_accepted_at,terms_declined_at,terms_details,stripe_account_id,stripe_connect_status,stripe_details')
      .eq('id', userId)
      .maybeSingle(),
    admin
      .from('valeter_profiles')
      .select('user_id,email,full_name,user_type,role,terms_status,terms_version,terms_accepted_at,terms_declined_at,terms_details')
      .eq('user_id', userId)
      .maybeSingle(),
  ]);

  let profile = (businessProfile as StripeProfileRow | null) ?? null;
  const valeter = valeterProfile as StripeProfileRow | null;

  // Valeter Stripe fields live on `profiles`. New signups often only have `valeter_profiles`.
  if (!profile && valeter) {
    profile = await ensureValeterProfilesRow(admin, userId, valeter);
  }

  const scope = getStripeProfileScope(profile ?? valeter ?? { id: userId, user_id: userId, user_type: 'valeter' });
  return { scope, profile };
}

function toStripeConnectStatus(account: Stripe.Account): 'in_progress' | 'completed' | 'restricted' {
  if (account.details_submitted && account.charges_enabled && account.payouts_enabled) {
    return 'completed';
  }
  if ((account.requirements?.disabled_reason || '').length > 0) {
    return 'restricted';
  }
  return 'in_progress';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !STRIPE_SECRET_KEY) {
    return json(500, { error: 'Missing function environment variables.' });
  }

  try {
    const userId = await getAuthedUserId(req);
    if (!userId) return json(401, { error: 'Unauthorized' });

    const body = await req.json().catch(() => ({}));
    const action = String(body?.action || '');

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { scope, profile } = await loadStripeProfile(admin, userId);
    const { data: businessProfileForDebug } = await admin
      .from('profiles')
      .select('id,user_type,role')
      .eq('id', userId)
      .maybeSingle();
    const { data: valeterProfileForDebug } = await admin
      .from('valeter_profiles')
      .select('user_id,user_type,role')
      .eq('user_id', userId)
      .maybeSingle();

    if (!profile) {
      return json(404, {
        error: 'Profile not found.',
        diagnostics: profileDebugPayload(
          userId,
          scope,
          (businessProfileForDebug as StripeProfileRow | null) ?? null,
          (valeterProfileForDebug as StripeProfileRow | null) ?? null
        ),
      });
    }


    if (action === 'create_onboarding_link') {
      const returnUrl = String(body?.returnUrl || '');
      const refreshUrl = String(body?.refreshUrl || '');
      if (!returnUrl || !refreshUrl) {
        return json(400, { error: 'returnUrl and refreshUrl are required.' });
      }

      let stripeAccountId = profile.stripe_account_id as string | null;

      if (!stripeAccountId) {
        const account = await stripe.accounts.create({
          type: 'express',
          email: profile.email || undefined,
          metadata: {
            user_id: userId,
          },
        });
        stripeAccountId = account.id;
      }

      const link = await stripe.accountLinks.create({
        account: stripeAccountId,
        type: 'account_onboarding',
        return_url: returnUrl,
        refresh_url: refreshUrl,
      });

      const nextDetails = {
        ...(profile.stripe_details || {}),
        last_onboarding_link_created_at: new Date().toISOString(),
      };

      const updatePayload: Record<string, unknown> = {
        stripe_account_id: stripeAccountId,
        stripe_connect_status: 'in_progress',
        stripe_onboarding_started_at: new Date().toISOString(),
        stripe_details: nextDetails,
      };

      const { error: updateErr } = await admin
        .from(scope.table)
        .update(updatePayload as any)
        .eq(scope.rowMatchKey, scope.rowMatchValue);

      if (updateErr) return json(500, { error: updateErr.message });

      return json(200, {
        url: link.url,
        stripeAccountId,
        stripeConnectStatus: 'in_progress',
      });
    }

    if (action === 'get_status') {
      const stripeAccountId = (profile.stripe_account_id as string | null) ?? null;
      if (!stripeAccountId) {
        return json(200, {
          stripeConnectStatus: 'not_started',
          stripeAccountId: null,
          detailsSubmitted: false,
          chargesEnabled: false,
          payoutsEnabled: false,
        });
      }

      const account = await stripe.accounts.retrieve(stripeAccountId);
      const nextStatus = toStripeConnectStatus(account);

      const nextDetails = {
        ...(profile.stripe_details || {}),
        account_country: account.country,
        account_email: account.email,
        business_type: account.business_type,
        requirements: account.requirements,
        updated_from_stripe_at: new Date().toISOString(),
      };

      const updatePayload: Record<string, unknown> = {
        stripe_connect_status: nextStatus,
        stripe_details: nextDetails,
      };
      if (nextStatus === 'completed') {
        updatePayload.stripe_onboarding_completed_at = new Date().toISOString();
      }

      const { error: updateErr } = await admin
        .from(scope.table)
        .update(updatePayload as any)
        .eq(scope.rowMatchKey, scope.rowMatchValue);

      if (updateErr) return json(500, { error: updateErr.message });

      return json(200, {
        stripeConnectStatus: nextStatus,
        stripeAccountId,
        detailsSubmitted: account.details_submitted,
        chargesEnabled: account.charges_enabled,
        payoutsEnabled: account.payouts_enabled,
      });
    }

    return json(400, { error: 'Unsupported action.' });
  } catch (e: any) {
    return json(500, { error: e?.message || 'Unexpected server error.' });
  }
});
