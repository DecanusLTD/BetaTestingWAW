import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.25.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
});

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

async function getAuthedUserId(req: Request): Promise<string | null> {
  const authHeader = req.headers.get('Authorization') ?? '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (!token) return null;

  const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user?.id) return null;
  return data.user.id;
}

function parseRequestPayload(content: string | null) {
  if (!content) return null;
  try {
    const parsed = JSON.parse(content) as Record<string, any>;
    if (parsed?.kind !== 'booking_payment_request') return null;
    return parsed;
  } catch {
    return null;
  }
}

async function resolveValeterStripeAccount(admin: ReturnType<typeof createClient>, valeterId: string) {
  if (!valeterId) return null;

  const { data, error } = await admin
    .from('profiles')
    .select('id,stripe_account_id,stripe_connect_status')
    .eq('id', valeterId)
    .maybeSingle();

  if (error || !data) return null;

  const stripeAccountId = String((data as any).stripe_account_id || '');
  if (!stripeAccountId) return null;

  return {
    profileId: String((data as any).id || valeterId),
    stripeAccountId,
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !STRIPE_SECRET_KEY) {
    return json(500, { error: 'Missing function environment variables.' });
  }

  try {
    const userId = await getAuthedUserId(req);
    if (!userId) return json(401, { error: 'Unauthorized' });

    const body = await req.json().catch(() => ({}));
    const bookingId = String(body?.bookingId || '');
    if (!bookingId) {
      return json(400, { error: 'bookingId is required.' });
    }

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: booking, error: bookingErr } = await admin
      .from('bookings')
      .select('id, user_id, valeter_id, status')
      .eq('id', bookingId)
      .maybeSingle();

    if (bookingErr || !booking) {
      return json(404, { error: 'Booking not found.' });
    }

    if (String(booking.valeter_id || '') !== userId) {
      return json(403, { error: 'Only the assigned valeter can release this payout.' });
    }

    if (String(booking.status || '') !== 'completed') {
      return json(409, { error: 'Payout can only be released after the job is completed.' });
    }

    const { data: message, error: messageErr } = await admin
      .from('booking_messages')
      .select('id, content, created_at')
      .eq('booking_id', bookingId)
      .eq('message_type', 'payment_request')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (messageErr || !message) {
      return json(404, { error: 'Payment request not found for booking.' });
    }

    const currentContent = parseRequestPayload((message as any).content ?? null);
    if (!currentContent) {
      return json(400, { error: 'Payment request payload is invalid.' });
    }

    if (currentContent.status !== 'paid') {
      const paymentIntentId = String(currentContent.paymentIntentId || '');
      if (!paymentIntentId) {
        return json(409, { error: 'Payment has not completed yet.' });
      }

      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      if (paymentIntent.status !== 'succeeded') {
        return json(409, { error: 'Payment has not completed yet.' });
      }

      currentContent.status = 'paid';
      currentContent.paidAt = currentContent.paidAt ?? new Date().toISOString();
    }

    if (currentContent.payoutStatus === 'released' && currentContent.stripeTransferId) {
      return json(200, {
        transferId: currentContent.stripeTransferId,
        amount: Math.round(Number(currentContent.valeterShare || 0) * 100),
        currency: String(currentContent.currency || 'gbp'),
        alreadyReleased: true,
      });
    }

    const recipientStripeAccountId = String(currentContent.recipientStripeAccountId || '');
    const resolvedRecipient =
      recipientStripeAccountId
        ? { stripeAccountId: recipientStripeAccountId, profileId: String(currentContent.recipientProfileId || booking.valeter_id || userId) }
        : await resolveValeterStripeAccount(admin, String(booking.valeter_id || ''));

    if (!resolvedRecipient?.stripeAccountId) {
      return json(409, { error: 'No connected Stripe account found for the valeter.' });
    }

    const amount = Number(currentContent.valeterShare || 0);
    const amountCents = Math.round(amount * 100);
    const currency = String(currentContent.currency || 'gbp').toLowerCase();

    if (!Number.isFinite(amount) || amountCents <= 0) {
      return json(400, { error: 'Valeter payout amount is invalid.' });
    }

    const transfer = await stripe.transfers.create({
      amount: amountCents,
      currency,
      destination: resolvedRecipient.stripeAccountId,
      metadata: {
        booking_id: bookingId,
        booking_message_id: String(message.id),
        valeter_id: String(booking.valeter_id || ''),
        customer_id: String(booking.user_id || ''),
        payout_kind: 'delayed_valeter_payout',
      },
    });

    const nextContent = {
      ...currentContent,
      payoutStatus: 'released',
      payoutReleasedAt: new Date().toISOString(),
      stripeTransferId: transfer.id,
      recipientStripeAccountId: resolvedRecipient.stripeAccountId,
      recipientProfileId: resolvedRecipient.profileId,
    };

    await admin
      .from('booking_messages')
      .update({
        content: JSON.stringify(nextContent),
      } as any)
      .eq('id', message.id);

    return json(200, {
      transferId: transfer.id,
      amount: amountCents,
      currency,
    });
  } catch (e: any) {
    return json(500, { error: e?.message || 'Unexpected server error.' });
  }
});
