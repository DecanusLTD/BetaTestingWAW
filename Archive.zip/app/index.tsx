// app/index.tsx
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useRouter, useRootNavigationState } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../src/providers/enhanced-auth-context';
import LoadingScreen from '../src/components/LoadingScreen';

type UserType = 'customer' | 'valeter' | 'business' | undefined;

function isOnboarded(user: any, userType: UserType, seen: string | null) {
  // Backend flags (whatever you set in your profiles or metadata)
  const flags = {
    generic: Boolean(user?.onboarded || user?.isOnboarded),
    customer: Boolean(user?.customerOnboarded || user?.isCustomerOnboarded),
    valeter:  Boolean(user?.valeterOnboarded  || user?.isValeterOnboarded),
    business: Boolean(user?.businessOnboarded || user?.isBusinessOnboarded),
  };

  // Local flag (null means "not seen")
  const seenGeneric = seen === 'true' || seen === '1';
  const seenCustomer = seen === 'customer' || seenGeneric;
  const seenValeter  = seen === 'valeter'  || seenGeneric;
  const seenBusiness = seen === 'business' || seenGeneric;

  if (userType === 'customer')      return flags.generic || flags.customer      || seenCustomer;
  if (userType === 'valeter')       return flags.generic || flags.valeter       || seenValeter;
  if (userType === 'business')      return flags.generic || flags.business       || seenBusiness;
  return flags.generic || seenGeneric;
}

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady } = useAuth();

  const [seenOnboarding, setSeenOnboarding] = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem('onboarding_seen')
      .then((v) => setSeenOnboarding(v ?? null))
      .catch(() => setSeenOnboarding(null));
  }, []);

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;

    // 1) Not logged in → auth flow
    if (!user) {
      router.replace('/auth/login');
      return;
    }

    const userType = user?.userType as UserType;
    
    // 2) Needs onboarding?
    if (!isOnboarded(user, userType, seenOnboarding)) {
      if (userType === 'valeter') {
        router.replace('/valeter/valeter-onboarding');
        return;
      }
      if (userType === 'customer') {
        router.replace('/owner/customer-onboarding');
        return;
      }
      if (userType === 'business') {
        router.replace('/business/onboarding');
        return;
      }
      router.replace('/onboarding');
      return;
    }

    // 3) Onboarded → dashboards
    if (userType === 'valeter') {
      router.replace('/valeter/valeter-dashboard');
      return;
    }
    if (userType === 'customer') {
      router.replace('/owner/owner-dashboard');
      return;
    }
    if (userType === 'business') {
      router.replace('/business/dashboard');
      return;
    }

    // 4) Fallback
    router.replace('/onboarding');
  }, [navReady, authReady, isLoading, user, seenOnboarding, router]);

  return <LoadingScreen />;
}