// app/index.tsx
import React, { useEffect, useState } from 'react';
import { useRouter, useRootNavigationState } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import LoadingScreen from '../src/components/LoadingScreen';
import { isValeterRole, isOrganizationRole, normalizeUserType } from '../src/utils/authRole';
import { termsAgreementService, type TermsStatus } from '../src/services/termsAgreementService';
import { businessOnboardingService } from '../src/services/businessOnboardingService';
import { stripeConnectService } from '../src/services/stripeConnectService';
import { valeterStripeConnectService } from '../src/services/valeterStripeConnectService';

type StripeConnectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'restricted'
  | 'rejected';

type StripeGateStatus = {
  stripeConnectStatus: StripeConnectStatus;
  stripeAccountId: string | null;
};

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady, logout } = useAuth();

  const [termsStatus, setTermsStatus] = useState<TermsStatus | null>(null);
  const [stripeStatus, setStripeStatus] = useState<StripeGateStatus | null>(null);
  const stripeRefreshAttemptedRef = React.useRef(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!user || !authReady || isLoading) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      const userType = normalizeUserType(user?.userType, null) ?? undefined;

      // Owner/customer accounts cannot use this CCP/valeter app.
      if (userType && !isValeterRole(userType) && !isOrganizationRole(userType)) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      const accountType = userType === 'organization' ? 'business' : userType === 'valeter' ? 'valeter' : null;
      if (!accountType) {
        setTermsStatus(null);
        setStripeStatus(null);
        return;
      }

      try {
        const [rec, stripeRec] = await Promise.all([
          termsAgreementService.load(accountType, user.id),
          accountType === 'business'
            ? businessOnboardingService.getStatus(user.id)
            : valeterStripeConnectService.getStatus(user.id),
        ]);
        if (!cancelled) setTermsStatus(rec.status);
        if (!cancelled) {
          setStripeStatus({
            stripeConnectStatus: stripeRec.stripeConnectStatus,
            stripeAccountId: stripeRec.stripeAccountId,
          });
        }
      } catch {
        if (!cancelled) {
          setTermsStatus('pending');
          setStripeStatus({
            stripeConnectStatus: 'not_started',
            stripeAccountId: null,
          });
        }
      }
    })();
    return () => {
      cancelled = true;
      stripeRefreshAttemptedRef.current = false;
    };
  }, [authReady, isLoading, user?.id, user?.userType]);

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;
    const userType = normalizeUserType(user?.userType, null) ?? undefined;

    // 1) Not logged in → auth flow
    if (!user) {
      router.replace('/auth/login');
      return;
    }

    // Owner / customer accounts cannot enter the valeter (CCP) app.
    if (!isValeterRole(userType) && !isOrganizationRole(userType)) {
      void (async () => {
        try {
          if (typeof logout === 'function') await logout();
        } catch {
          // ignore
        } finally {
          router.replace('/auth/login');
        }
      })();
      return;
    }

    if (termsStatus === null || stripeStatus === null) {
      return;
    }

    if (termsStatus === 'declined') {
      if (userType === 'organization') {
        router.replace('/business/terms-blocked');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/terms-blocked');
        return;
      }
    }

    if (termsStatus !== 'accepted') {
      if (userType === 'organization') {
        router.replace('/business/terms');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/terms');
        return;
      }
    }

    const shouldRefreshStripe =
      stripeStatus.stripeConnectStatus !== 'completed' &&
      !!stripeStatus.stripeAccountId &&
      !stripeRefreshAttemptedRef.current;

    if (shouldRefreshStripe) {
      stripeRefreshAttemptedRef.current = true;
      void (async () => {
        try {
          const live = await stripeConnectService.syncStatusFromStripe();
          setStripeStatus({
            stripeConnectStatus: live.stripeConnectStatus,
            stripeAccountId: live.stripeAccountId,
          });
        } catch {
          // Keep the locally cached status if Stripe is temporarily unavailable.
        }
      })();
      return;
    }

    if (
      stripeStatus.stripeConnectStatus === 'not_started' ||
      stripeStatus.stripeConnectStatus === 'restricted' ||
      stripeStatus.stripeConnectStatus === 'rejected'
    ) {
      if (userType === 'organization') {
        router.replace('/business/stripe-connect');
        return;
      }
      if (userType === 'valeter') {
        router.replace('/valeter/stripe-connect');
        return;
      }
      router.replace('/auth/login');
      return;
    }

    // 3) Ready → dashboards (valeter / business only)
    if (userType === 'valeter') {
      router.replace('/valeter/valeter-dashboard');
      return;
    }
    if (userType === 'organization') {
      router.replace('/business/dashboard');
      return;
    }

    // 4) Fallback — never send owner/customer into valeter
    router.replace('/auth/login');
  }, [navReady, authReady, isLoading, user, termsStatus, stripeStatus, router, logout]);

  return <LoadingScreen overlay={false} />;
}
