import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

export default function BusinessProfile() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [businessEmail, setBusinessEmail] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [taxId, setTaxId] = useState('');

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadBusinessProfile();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadBusinessProfile = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setBusinessName(data.name || '');
        setBusinessEmail(data.email || user.email || '');
        setBusinessPhone(data.phone || '');
        setBusinessAddress(data.address || '');
        setBusinessDescription(data.description || '');
        setTaxId(data.tax_id || '');
      } else {
        setBusinessEmail(user.email || '');
      }
    } catch (error) {
      console.error('Error loading business profile:', error);
      Alert.alert('Error', 'Failed to load business information');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('organizations')
        .upsert({
          id: user.id,
          name: businessName,
          email: businessEmail,
          phone: businessPhone,
          address: businessAddress,
          description: businessDescription,
          tax_id: taxId,
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;

      Alert.alert('Success', 'Business information updated successfully');
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving business profile:', error);
      Alert.alert('Error', 'Failed to save business information');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Business Information" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Business Information"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
        rightAction={
          !isEditing ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setIsEditing(true);
              }}
              style={styles.editButton}
            >
              <Ionicons name="create-outline" size={20} color="#8B5CF6" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setIsEditing(false);
                loadBusinessProfile();
              }}
              style={styles.editButton}
            >
              <Ionicons name="close" size={20} color="#8B5CF6" />
            </TouchableOpacity>
          )
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {/* Business Name */}
          <View style={styles.section}>
            <Text style={styles.label}>Business Name</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessName}
                  onChangeText={setBusinessName}
                  placeholder="Enter business name"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{businessName || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Email */}
          <View style={styles.section}>
            <Text style={styles.label}>Email</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessEmail}
                  onChangeText={setBusinessEmail}
                  placeholder="Enter email"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{businessEmail || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Phone */}
          <View style={styles.section}>
            <Text style={styles.label}>Phone Number</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessPhone}
                  onChangeText={setBusinessPhone}
                  placeholder="Enter phone number"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="phone-pad"
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{businessPhone || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Address */}
          <View style={styles.section}>
            <Text style={styles.label}>Business Address</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={businessAddress}
                  onChangeText={setBusinessAddress}
                  placeholder="Enter business address"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={3}
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{businessAddress || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Description */}
          <View style={styles.section}>
            <Text style={styles.label}>Business Description</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={businessDescription}
                  onChangeText={setBusinessDescription}
                  placeholder="Describe your business"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={4}
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{businessDescription || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Tax ID */}
          <View style={styles.section}>
            <Text style={styles.label}>Tax ID / VAT Number</Text>
            {isEditing ? (
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={taxId}
                  onChangeText={setTaxId}
                  placeholder="Enter tax ID"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                />
              </GlassCard>
            ) : (
              <GlassCard style={styles.infoCard} accountType="business">
                <Text style={styles.infoText}>{taxId || 'Not set'}</Text>
              </GlassCard>
            )}
          </View>

          {/* Save Button */}
          {isEditing && (
            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSave}
              disabled={isSaving}
            >
              <View style={styles.saveButtonContent}>
                {isSaving ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                    <Text style={styles.saveButtonText}>Save Changes</Text>
                  </>
                )}
              </View>
            </TouchableOpacity>
          )}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.lg,
  },
  section: {
    gap: SPACING.sm,
  },
  label: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  inputCard: {
    ...CARD_SIZES.small,
  },
  input: {
    color: '#F9FAFB',
    fontSize: 16,
    padding: 0,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  infoCard: {
    ...CARD_SIZES.small,
  },
  infoText: {
    color: '#F9FAFB',
    fontSize: 16,
    lineHeight: 22,
  },
  editButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(139,92,246,0.15)',
  },
  saveButton: {
    marginTop: SPACING.lg,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#8B5CF6',
    elevation: 4,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  saveButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

