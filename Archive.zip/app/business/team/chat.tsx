/**
 * Business → team roster → chat with a washer (UI-first; local send works, sync TBD).
 */
import React, { useMemo } from 'react';
import { Alert, Linking } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import ChatThreadView, { type ChatMessage } from '../../../src/components/chat/ChatThreadView';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';

function firstParam(v: string | string[] | undefined): string {
  if (v == null) return '';
  return Array.isArray(v) ? (v[0] ?? '') : v;
}

export default function BusinessTeamWasherChatScreen() {
  const params = useLocalSearchParams<{
    valeterId?: string | string[];
    valeterName?: string | string[];
    phone?: string | string[];
  }>();
  const valeterId = firstParam(params.valeterId);
  const valeterName = firstParam(params.valeterName).trim();
  const phone = firstParam(params.phone).trim();

  const title = valeterName || 'Washer';
  const subtitle = 'Team roster';

  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? '#7EB8D4';
  const bg = Array.isArray(theme?.background) ? theme.background[0] : '#0F172A';

  const initialMessages = useMemo((): ChatMessage[] => {
    if (!valeterId) return [];
    const t = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    return [
      {
        id: 'team-chat-preview',
        isFromMe: false,
        type: 'text',
        content:
          'Team chat preview — your messages stay on this device until live sync is connected. You can still draft and try the flow.',
        time: t,
      },
    ];
  }, [valeterId]);

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    hapticFeedback('light');
    if (phone) {
      const url = `tel:${phone.replace(/\s/g, '')}`;
      Linking.canOpenURL(url).then((ok) => {
        if (ok) void Linking.openURL(url);
        else Alert.alert('Call', 'Could not open the phone app.');
      });
      return;
    }
    Alert.alert('Call', 'No number on file for this car care pro yet.');
  };

  const handleAttachImage = () => {
    hapticFeedback('light');
    Alert.alert('Photo', 'Sending images will be available when team chat is connected to the server.');
  };

  const handleVoiceNote = () => {
    hapticFeedback('light');
    Alert.alert('Voice note', 'Voice messages will be available when team chat is connected to the server.');
  };

  const handleDelete = () => {
    hapticFeedback('light');
    Alert.alert('Close chat?', 'You can open this thread again from the team roster.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Close', onPress: () => router.back() },
    ]);
  };

  if (!valeterId) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: bg }} edges={[]}>
        <ChatThreadView
          title="Chat"
          subtitle="Missing car care pro"
          onBack={handleBack}
          onCall={handleCall}
          accentColor={accent}
          backgroundColor={bg}
          initialMessages={[]}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: bg }} edges={[]}>
      <ChatThreadView
        title={title}
        subtitle={subtitle}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onVoiceNote={handleVoiceNote}
        onDelete={handleDelete}
        accentColor={accent}
        backgroundColor={bg}
        initialMessages={initialMessages}
      />
    </SafeAreaView>
  );
}
