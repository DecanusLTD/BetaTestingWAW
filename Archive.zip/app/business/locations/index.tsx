import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  ScrollView,
  RefreshControl,
  Alert,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { Region, Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { textStyles } from '../../../src/constants/typography';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { MAP_LOCKED_DARK } from '../../../src/constants/mapConstants';
import ActiveBookingsSheet, { type ActiveBookingItem } from '../../../src/components/business/ActiveBookingsSheet';
import { loadActiveBookingsForOrganization } from '../../../src/services/BusinessBookingsService';
import { getLocationOpenBlockReasons } from '../../../src/utils/locationOpenValidation';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
/** For StyleSheet only (avoids theme load-order issues). */
const BUSINESS_PRIMARY = '#7DD3FC';

/** Match business bookings (index) bottom sheet */
const HANDLE_H = 24;

/** Card width fits the bottom-sheet inner width once horizontal padding + margins are applied. */
const LOCATION_CARD_WIDTH = width - 56;
const LOCATION_CARD_GAP = 14;

type AnyRow = Record<string, unknown>;

interface Location {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at: string;
  site_type?: string | null;
  // Performance stats (computed)
  rating?: number;
  washesThisWeek?: number;
  revenueThisWeek?: number;
}

type LocationOpeningHourRow = {
  location_id: string;
  day_of_week: number;
  is_open: boolean;
  open_time: string | null;
  close_time: string | null;
};

function mergeLocationStats(
  prev: Location[],
  statsRows: Array<{ id: string; rating: number; washesThisWeek: number; revenueThisWeek: number }>
): Location[] {
  const statsById = new Map(statsRows.map((row) => [row.id, row] as const));
  return prev.map((loc) => {
    const row = statsById.get(loc.id);
    if (!row) return loc;
    return {
      ...loc,
      rating: row.rating,
      washesThisWeek: row.washesThisWeek,
      revenueThisWeek: row.revenueThisWeek,
    };
  });
}

export default function BusinessLocations() {
  const { user } = useAuth();
  const { theme: businessTheme } = useAccountTheme();
  const insets = useSafeAreaInsets();

  const locationsSheetHeight = useMemo(() => {
    const bottomPad = Math.max(12, insets.bottom);
    const handleAndHeader = 8 + 8 + 4 + 8 + 76;
    const actionsRow = 52;
    const minCardBlock = 146;
    const needed = bottomPad + handleAndHeader + actionsRow + minCardBlock;
    return Math.min(height * 0.52, Math.max(height * 0.39, needed));
  }, [insets.bottom]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);
  /** Invalidates in-flight fetches when org context changes or a new load starts. */
  const locationsFetchGen = useRef(0);

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLocationIndex, setSelectedLocationIndex] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [newLocationName, setNewLocationName] = useState('');
  const [newLocationAddress, setNewLocationAddress] = useState('');
  const [saving, setSaving] = useState(false);
  const [initialRegion, setInitialRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [showBookingsSheet, setShowBookingsSheet] = useState(false);
  const [liveBookings, setLiveBookings] = useState<ActiveBookingItem[]>([]);
  const [bookingsSheetLoading, setBookingsSheetLoading] = useState(false);
  const [activeWashersLocation, setActiveWashersLocation] = useState<Location | null>(null);

  const [siteWashersModalOpen, setSiteWashersModalOpen] = useState(false);
  const [siteWashersLoading, setSiteWashersLoading] = useState(false);
  const [siteWashers, setSiteWashers] = useState<
    Array<{ id: string; name: string; email: string; photoUrl: string | null }>
  >([]);

  const cardWidth = LOCATION_CARD_WIDTH;
  const cardSpacing = LOCATION_CARD_GAP;

  // ✅ Use the org id, not the user id
  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  // Sync map with selected location
  useEffect(() => {
    if (locations.length > 0 && selectedLocationIndex < locations.length) {
      const selectedLocation = locations[selectedLocationIndex];
      if (selectedLocation.latitude && selectedLocation.longitude) {
        const newRegion: Region = {
          latitude: selectedLocation.latitude,
          longitude: selectedLocation.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedLocationIndex, locations]);

  // Scroll to selected location when index changes
  useEffect(() => {
    if (scrollViewRef.current && locations.length > 0 && selectedLocationIndex < locations.length) {
      const scrollX = selectedLocationIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedLocationIndex, locations.length, cardWidth, cardSpacing]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Only load locations when we have a valid org context
    if (isOrgUser && organizationId) {
      loadLocations();
    } else {
      setLocations([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const getValeterIds = async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valErr) throw valErr;
      return (valeters || []).map((v: any) => v.id) as string[];
    } catch (error) {
      console.error('Error loading valeter IDs:', error);
      return [];
    }
  };

  const loadBookingsForSheet = useCallback(async (locationId?: string | null) => {
    if (!organizationId) return [];
    setBookingsSheetLoading(true);
    try {
      let list = await loadActiveBookingsForOrganization(organizationId);
      list = list.filter((b: any) => b.status !== 'completed' && b.status !== 'cancelled');
      let filtered = list;
      if (locationId) {
        const loc = locations.find((l) => l.id === locationId);
        filtered = list.filter((b: any) => {
          if (b.location_id === locationId) return true;
          if (loc?.address && b.location_address?.toLowerCase().includes(loc.address.toLowerCase())) return true;
          return false;
        });
      }
      return filtered.map((b: any) => ({
        id: b.id,
        time: b.scheduled_at ? new Date(b.scheduled_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—',
        service: getServiceDisplayName(b.service_type, b.service_name),
        price: Number(b.price ?? 0),
        status: b.status,
        customerName: b.customer_name,
        customer_profile_picture: b.customer_profile_picture ?? null,
        customer_id: b.customer_id ?? null,
        customer_email: b.customer_email ?? null,
        customer_phone: b.customer_phone ?? null,
        location_address: b.location_address,
        assigned_valeter_name: b.assigned_valeter_name,
        assigned_valeter_photo: b.assigned_valeter_photo ?? null,
        vehicle_info: b.vehicle_info ?? null,
        vehicle_registration: b.vehicle_registration ?? null,
        vehicle_make: b.vehicle_make ?? null,
        vehicle_model: b.vehicle_model ?? null,
        scheduled_at: b.scheduled_at ?? null,
      })) as ActiveBookingItem[];
    } catch (e) {
      console.warn('Locations loadBookingsForSheet:', e);
      return [];
    } finally {
      setBookingsSheetLoading(false);
    }
  }, [organizationId, locations]);

  const handleViewBookings = useCallback(async (locationId?: string | null) => {
    await hapticFeedback('light');
    const list = await loadBookingsForSheet(locationId ?? locations[selectedLocationIndex]?.id);
    setLiveBookings(list);
    setShowBookingsSheet(true);
  }, [locations, selectedLocationIndex, loadBookingsForSheet]);

  const loadLocationStats = async (locationId: string): Promise<{ rating: number; washesThisWeek: number; revenueThisWeek: number }> => {
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) {
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get bookings for this location (we'll need to match by address or location_id if available)
      // For now, we'll get all bookings and filter by location if we have location_id in bookings
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);

      // Try to get bookings by location_id first, then fallback to address matching
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, price, status, rating, location_address, location_id')
        .in('valeter_id', valeterIds)
        .gte('created_at', weekAgo.toISOString());

      if (bookingsError) {
        console.warn('Error loading location stats:', bookingsError);
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get location details to match by address
      const { data: locationData } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('id', locationId)
        .maybeSingle();

      const locationAddress = locationData?.address;

      // Filter bookings for this location (by location_id or address match)
      const normalizedAddress = locationAddress?.toLowerCase();
      const locationBookings = (bookings || []).filter((b: any) => {
        if (b.location_id === locationId) return true;
        if (normalizedAddress && b.location_address?.toLowerCase().includes(normalizedAddress)) {
          return true;
        }
        return false;
      });

      const completed = locationBookings.filter((b: any) => b.status === 'completed');
      const washesThisWeek = completed.length;
      
      const revenueThisWeek = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price || 0);
        return sum + (Number.isFinite(price) ? price : 0);
      }, 0);

      // Calculate average rating
      const ratings = completed
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);
      
      const rating = ratings.length > 0
        ? ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length
        : 0;

      return {
        rating: Math.round(rating * 10) / 10,
        washesThisWeek,
        revenueThisWeek: Math.round(revenueThisWeek),
      };
    } catch (error) {
      console.error('Error loading location stats:', error);
      return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
    }
  };

  const loadLocations = async () => {
    if (!isOrgUser || !organizationId) return;

    const gen = ++locationsFetchGen.current;

    try {
      setLoading(true);
      let locRes: any = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude, status, is_active, created_at, site_type')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (locRes.error?.code === '42703') {
        locRes = await supabase
          .from('car_wash_locations')
          .select('id, name, address, latitude, longitude, status, is_active, created_at')
          .eq('organization_id', organizationId)
          .order('created_at', { ascending: false });
      }

      const { data, error } = locRes;
      if (error) throw error;
      if (gen !== locationsFetchGen.current) return;

      const loadedLocations = (data as Location[]) || [];

      const withPlaceholderStats: Location[] = loadedLocations.map((loc) => ({
        ...loc,
        rating: loc.rating ?? 0,
        washesThisWeek: loc.washesThisWeek ?? 0,
        revenueThisWeek: loc.revenueThisWeek ?? 0,
      }));

      setLocations(withPlaceholderStats);

      const locationsWithCoords = loadedLocations.filter((l) => l.latitude && l.longitude);
      if (locationsWithCoords.length > 0) {
        const lats = locationsWithCoords.map((l) => l.latitude!);
        const lngs = locationsWithCoords.map((l) => l.longitude!);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);

        const newRegion = {
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.05),
          longitudeDelta: Math.max((maxLng - minLng) * 1.5, 0.05),
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }

      void (async () => {
        const statsGen = gen;
        try {
          const statsRows = await Promise.all(
            loadedLocations.map(async (location) => {
              const stats = await loadLocationStats(location.id);
              return { id: location.id, ...stats };
            })
          );
          if (statsGen !== locationsFetchGen.current) return;
          setLocations((prev) => mergeLocationStats(prev, statsRows));
        } catch (statsErr) {
          console.warn('[Locations] background stats failed:', statsErr);
        }
      })();
    } catch (error: any) {
      console.error('Error loading locations:', error);
      if (gen === locationsFetchGen.current) {
        Alert.alert('Error', error?.message || 'Failed to load locations');
      }
    } finally {
      if (gen === locationsFetchGen.current) {
        setLoading(false);
      }
    }
  };

  const parseTimeToMinutes = (value: string | null | undefined): number | null => {
    if (!value) return null;
    const [hours, minutes] = value.split(':');
    const h = Number(hours);
    const m = Number(minutes);
    if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
    return h * 60 + m;
  };

  const getCurrentDayVariants = (): number[] => {
    const jsDay = new Date().getDay(); // 0 (Sun) ... 6 (Sat)
    const mondayZero = (jsDay + 6) % 7; // 0 (Mon) ... 6 (Sun)
    const isoDay = jsDay === 0 ? 7 : jsDay; // 1 (Mon) ... 7 (Sun)
    return Array.from(new Set([jsDay, mondayZero, isoDay]));
  };

  const autoCloseExpiredLocations = useCallback(
    async (loadedLocations: Location[]) => {
      if (!organizationId || loadedLocations.length === 0) return;
      try {
        const locationIds = loadedLocations.map((l) => l.id);
        const dayVariants = getCurrentDayVariants();
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();

        const { data: rows, error } = await supabase
          .from('location_opening_hours')
          .select('location_id, day_of_week, is_open, open_time, close_time')
          .in('location_id', locationIds)
          .in('day_of_week', dayVariants);

        if (error || !rows) return;
        const byLocation = new Map<string, LocationOpeningHourRow[]>();
        (rows as LocationOpeningHourRow[]).forEach((row) => {
          const list = byLocation.get(row.location_id) ?? [];
          list.push(row);
          byLocation.set(row.location_id, list);
        });

        const idsToClose: string[] = [];
        loadedLocations.forEach((loc) => {
          if (loc.is_active === false) return;
          const hours = byLocation.get(loc.id) ?? [];
          const activeShift = hours.find((h) => h.is_open && parseTimeToMinutes(h.close_time) !== null);
          if (!activeShift) return;
          const closeMinutes = parseTimeToMinutes(activeShift.close_time);
          if (closeMinutes === null) return;
          if (currentMinutes >= closeMinutes) idsToClose.push(loc.id);
        });

        if (idsToClose.length === 0) return;

        const { error: updateError } = await supabase
          .from('car_wash_locations')
          .update({ is_active: false, status: 'inactive' })
          .in('id', idsToClose)
          .eq('organization_id', organizationId);

        if (updateError) return;

        setLocations((prev) =>
          prev.map((loc) =>
            idsToClose.includes(loc.id) ? { ...loc, is_active: false, status: 'inactive' } : loc
          )
        );
      } catch (error) {
        console.warn('autoCloseExpiredLocations failed:', error);
      }
    },
    [organizationId]
  );

  useEffect(() => {
    if (locations.length === 0) return;
    void autoCloseExpiredLocations(locations);
  }, [locations, autoCloseExpiredLocations]);

  const headerBackgroundForFab =
    businessTheme.headerBackground || businessTheme.background || ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];

  const loadSiteWashersForModal = useCallback(async () => {
    const locId = activeWashersLocation?.id ?? locations[selectedLocationIndex]?.id;
    if (!locId || !organizationId) {
      setSiteWashers([]);
      return;
    }
    setSiteWashersLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, full_name, email, profile_picture, user_type, valeter_work_mode, assigned_location_id')
        .eq('organization_id', organizationId)
        .eq('assigned_location_id', locId);

      if (error) throw error;

      const rows = (data || []).filter((r: AnyRow) => {
        const ut = typeof r.user_type === 'string' ? r.user_type.toLowerCase() : '';
        return ut === 'valeter' || ut.startsWith('valeter');
      });

      const ids = rows.map((r: AnyRow) => r.id as string);
      const vpMap = new Map<string, string | null>();
      if (ids.length > 0) {
        const { data: vpRows } = await supabase
          .from('valeter_profiles')
          .select('user_id, profile_photo_url')
          .in('user_id', ids);
        for (const row of vpRows || []) {
          const r = row as { user_id?: string; profile_photo_url?: string | null };
          if (r.user_id) vpMap.set(r.user_id, r.profile_photo_url ?? null);
        }
      }

      setSiteWashers(
        rows.map((r: AnyRow) => ({
          id: String(r.id),
          name:
            (typeof r.full_name === 'string' && r.full_name.trim()) ||
            (typeof r.name === 'string' && r.name.trim()) ||
            'Car Care Pro',
          email: typeof r.email === 'string' ? r.email : '',
          photoUrl:
            vpMap.get(String(r.id)) ??
            (typeof r.profile_picture === 'string' ? r.profile_picture : null),
        }))
      );
    } catch (e) {
      console.warn('[Locations] site car care pros:', e);
      setSiteWashers([]);
    } finally {
      setSiteWashersLoading(false);
    }
  }, [activeWashersLocation, locations, selectedLocationIndex, organizationId]);

  const showEmptyLocationsSheet = !loading && locations.length === 0;
  const showNoSiteWashers = !siteWashersLoading && siteWashers.length === 0;
  const shouldShowLoadingSheet = loading && Boolean(isOrgUser && organizationId);
  const locationSheetContent = (() => {
    if (shouldShowLoadingSheet) {
      return (
        <View style={styles.emptyContainer}>
          <View style={styles.emptySheet}>
            <BusinessSheetBackground />
            <View style={[styles.sheetHandle, { backgroundColor: 'rgba(125,211,252,0.6)' }]} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetHeaderTitle}>Your locations</Text>
            </View>
            <Text style={styles.sheetHeaderSubtitle}>Fetching your sites…</Text>
            <View style={styles.locationsLoadingSheetBody}>
              <Text style={styles.locationsLoadingSheetHint}>Map above shows when data is ready</Text>
            </View>
          </View>
        </View>
      );
    }
    if (showEmptyLocationsSheet) {
      return (
        <View style={styles.emptyContainer}>
          <View style={styles.emptySheet}>
            <BusinessSheetBackground />
            <View style={[styles.sheetHandle, { backgroundColor: 'rgba(125,211,252,0.6)' }]} />
            <View style={styles.sheetHeaderRow}>
              <Text style={styles.sheetHeaderTitle}>Your locations</Text>
            </View>
            <Text style={styles.sheetHeaderSubtitle}>Add a location to accept bookings</Text>
            <View style={styles.emptyContent}>
              <GlassCard style={styles.emptyCardInner} accountType="business" intensity={52} tint="dark">
                <GradientIconBox icon="location-outline" preset="sky" boxSize={56} size={28} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings at your business
                </Text>
              </GlassCard>
            </View>
          </View>
        </View>
      );
    }
    return null;
  })();

  // If they somehow reached this screen without an org context, give a clear message
  if (!isOrgUser || !organizationId) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
          <View style={styles.pageShell}>
            <View style={styles.pageHeader}>
              <View style={styles.pageHeaderActions}>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.back();
                  }}
                  style={styles.pageHeaderFab}
                  activeOpacity={0.85}
                >
                  <Ionicons name="arrow-back" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.loadingContainer}>
              <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
              <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
                If you think this is wrong, log out and back in.
              </Text>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.back();
                }}
                style={[styles.addButton, { marginTop: 10 }]}
              >
                <Ionicons name="arrow-back" size={20} color={SKY} />
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const handleToggleLocationStatus = async (locationId: string, currentStatus: boolean) => {
    try {
      await hapticFeedback('medium');
      const newStatus = !currentStatus;

      if (!organizationId) return;
      if (newStatus) {
        const location = locations.find((loc) => loc.id === locationId);
        const blocked = await getLocationOpenBlockReasons([{ id: locationId, name: location?.name ?? 'This location' }]);
        if (blocked.length > 0) {
          Alert.alert(
            'Could not open location',
            blocked.map((item) => `${item.locationName}: ${item.reason}`).join('\n\n')
          );
          return;
        }
      }
      const { error } = await supabase
        .from('car_wash_locations')
        .update({ 
          is_active: newStatus,
          status: newStatus ? 'active' : 'inactive'
        })
        .eq('id', locationId)
        .eq('organization_id', organizationId);

      if (error) throw error;

      // Update local state
      setLocations(prev => prev.map(loc => 
        loc.id === locationId ? { ...loc, is_active: newStatus, status: newStatus ? 'active' : 'inactive' } : loc
      ));
      
      Alert.alert(
        newStatus ? 'Location Opened' : 'Location Closed',
        newStatus 
          ? 'This location is now open for bookings.'
          : 'This location is now closed. Customers cannot book at this location.'
      );
    } catch (error: any) {
      console.error('Error toggling location status:', error);
      Alert.alert('Error', error?.message || 'Failed to update location status');
    }
  };

  // Render location card (cards only – View Bookings / Manage are fixed below)
  const renderLocationCard = (location: Location, index: number) => {
    const isOpen = location.is_active !== false;
    const addressParts = location.address?.split(',') || [];
    const streetName = addressParts[0]?.trim() || location.address || 'Address not set';
    const weeklyBookings = Number(location.washesThisWeek ?? 0);
    const weeklyRevenue = Number(location.revenueThisWeek ?? 0);

    return (
      <View style={styles.locationCardWrapper}>
        <GlassCard style={styles.sheetCard} accountType="business" intensity={52} tint="dark">
          <View style={styles.sheetCardRow}>
            <GradientIconBox icon="location" preset="sky" boxSize={38} size={19} />
            <View style={styles.sheetCardBody}>
              <View style={styles.sheetCardTitleRow}>
                <Text style={styles.sheetCardTitle} numberOfLines={1}>
                  {location.name}
                </Text>
                <View
                  style={[
                    styles.siteTypePill,
                    String(location.site_type ?? 'unit').toLowerCase() === 'mobile'
                      ? styles.siteTypePillMobile
                      : styles.siteTypePillUnit,
                  ]}
                >
                  <Text style={styles.siteTypePillText}>
                    {String(location.site_type ?? 'unit').toLowerCase() === 'mobile' ? 'Mobile' : 'Unit'}
                  </Text>
                </View>
              </View>
              <Text style={styles.sheetCardSubtitle} numberOfLines={1}>{streetName}</Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => handleToggleLocationStatus(location.id, isOpen)}
            style={styles.sheetStatusWrap}
            activeOpacity={0.8}
          >
            <View style={[styles.statusPill, isOpen && styles.statusPillOpen]}>
              <View style={[styles.statusDot, isOpen && styles.statusDotOpen]} />
              <Text style={[styles.statusText, isOpen && styles.statusTextOpen]}>
                {isOpen ? 'OPEN' : 'CLOSED'}
              </Text>
            </View>
          </TouchableOpacity>
          <View style={styles.locationStatsRow}>
            <View style={styles.locationStatItem}>
              <GradientIconBox icon="calendar-outline" preset="sky" boxSize={20} size={11} />
              <Text style={styles.locationStatValue}>{weeklyBookings}</Text>
              <Text style={styles.locationStatLabel}>bookings</Text>
            </View>
            <View style={styles.locationStatItem}>
              <GradientIconBox icon="wallet-outline" preset="emerald" boxSize={20} size={11} />
              <Text style={styles.locationStatValue}>£{Math.round(weeklyRevenue)}</Text>
              <Text style={styles.locationStatLabel}>this week</Text>
            </View>
          </View>
          <View style={styles.cardActionsBelow}>
            <TouchableOpacity
              onPress={() => void handleViewBookings(location.id)}
              style={styles.sheetPrimaryBtn}
              activeOpacity={0.8}
            >
              <Ionicons name="calendar-outline" size={18} color={SKY} />
              <Text style={[styles.sheetPrimaryBtnText, { color: '#FFFFFF' }]}>View bookings</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setSelectedLocationIndex(index);
                router.push(`/business/locations/${location.id}` as any);
              }}
              style={styles.sheetSecondaryBtn}
              activeOpacity={0.8}
            >
              <Ionicons name="settings-outline" size={20} color={SKY} />
            </TouchableOpacity>
          </View>
        </GlassCard>
      </View>
    );
  };

  const selectedLocation = locations.length > 0 && selectedLocationIndex < locations.length ? locations[selectedLocationIndex] : null;

  const openSiteWashersModal = async (location?: Location, index?: number) => {
    const targetLocation = location ?? locations[selectedLocationIndex];
    if (!targetLocation?.id) return;
    await hapticFeedback('light');
    if (typeof index === 'number') {
      setSelectedLocationIndex(index);
    } else if (location) {
      const locIndex = locations.findIndex((loc) => loc.id === location.id);
      if (locIndex >= 0) setSelectedLocationIndex(locIndex);
    }
    setActiveWashersLocation(targetLocation);
    setSiteWashersModalOpen(true);
    await loadSiteWashersForModal();
  };

  const locWasherSheetBackdrop = 'rgba(0,0,0,0.82)';
  const locWasherTitle = '#FFFFFF';
  const locWasherMuted = 'rgba(255,255,255,0.85)';
  const locWasherBorder = 'rgba(255,255,255,0.12)';
  const locWasherCloseBg = 'rgba(255,255,255,0.18)';
  const activeLocationName = activeWashersLocation?.name ?? locations[selectedLocationIndex]?.name ?? '';
  const siteWashersBody = (() => {
    if (siteWashersLoading) {
      return (
        <View style={styles.locWasherLoadingWrap}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={[styles.locWasherLoadingText, { color: locWasherMuted }]}>Loading…</Text>
        </View>
      );
    }
    if (showNoSiteWashers) {
      return (
        <View style={styles.locWasherEmptyWrap}>
          <Ionicons name="people-outline" size={40} color={locWasherMuted} style={{ marginBottom: 12 }} />
          <Text style={[styles.locWasherEmptyTitle, { color: locWasherTitle }]}>No current car care pros found</Text>
          <Text style={[styles.locWasherEmptySub, { color: locWasherMuted }]}>
            No car care pros are assigned to this site yet. Set fixed-site assignment in Team for a car care pro to
            see them
            here.
          </Text>
        </View>
      );
    }
    return null;
  })();
  const locWasherHandleBg = 'rgba(255,255,255,0.35)';

  // Render map with location markers
  const renderMap = () => {
    if (loading) {
      return (
        <View style={styles.mapContainer}>
          <DefaultLoadingSkeleton message="Loading locations…" variant="rich" />
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
          customMapStyle={DARK_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          showsUserLocation={false}
          showsMyLocationButton={false}
          showsCompass={false}
          mapType="standard"
          mapPadding={{ top: 112, bottom: Math.max(insets.bottom, 24), left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={SKY}
          followsUserLocation={false}
        >
          {locations.filter(l => l.latitude && l.longitude).map((location, index) => {
            const isSelected = index === selectedLocationIndex;
            return (
              <Marker
                key={location.id}
                coordinate={{
                  latitude: location.latitude!,
                  longitude: location.longitude!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={[styles.locationMarker, isSelected && styles.locationMarkerSelected]}>
                  <View style={[styles.markerGlow, isSelected && styles.markerGlowActive]} />
                  <View style={[styles.markerCore, isSelected && styles.markerCoreSelected]}>
                    <Ionicons name="location" size={22} color={isSelected ? '#0f172a' : SKY} />
                  </View>
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < locations.length && newIndex !== selectedLocationIndex) {
      setSelectedLocationIndex(newIndex);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    }
  };

  const handleAddLocation = async () => {
    if (!newLocationName.trim() || !newLocationAddress.trim()) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const { error } = await supabase.from('car_wash_locations').insert({
        name: newLocationName.trim(),
        address: newLocationAddress.trim(),
        organization_id: organizationId,
        latitude: null,
        longitude: null,
        is_active: true,
        status: 'active',
      });

      if (error) throw error;

      setShowAddModal(false);
      setNewLocationName('');
      setNewLocationAddress('');
      await loadLocations();
      Alert.alert('Success', 'Location added successfully');
    } catch (error: any) {
      console.error('Error adding location:', error);
      Alert.alert('Error', error?.message || 'Failed to add location');
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <View style={styles.pageShell}>
          <View style={styles.pageHeader}>
            <View style={styles.pageHeaderActions}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setShowMapModal(true);
                }}
                style={styles.pageHeaderFab}
                activeOpacity={0.85}
              >
                <Ionicons name="map-outline" size={20} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setShowAddModal(true);
                }}
                style={styles.pageHeaderFab}
                activeOpacity={0.85}
              >
                <Ionicons name="add" size={24} color={SKY} />
              </TouchableOpacity>
            </View>
          </View>

          <Animated.ScrollView
            style={styles.locationsScroll}
            contentContainerStyle={[
              styles.locationsScrollContent,
              { paddingBottom: Math.max(insets.bottom, 24) + TAB_BAR_TOTAL_HEIGHT + 20 },
            ]}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={false}
                onRefresh={() => {
                  void loadLocations();
                }}
                tintColor={SKY}
              />
            }
          >
            {loading ? (
              <View style={styles.listLoadingWrap}>
                <DefaultLoadingSkeleton message="Loading locations…" variant="rich" />
              </View>
            ) : locations.length === 0 ? (
              <GlassCard style={styles.emptyListCard} accountType="business" intensity={52} tint="dark">
                <GradientIconBox icon="location-outline" preset="sky" boxSize={56} size={28} />
                <Text style={styles.emptyListTitle}>No locations yet</Text>
                <Text style={styles.emptyListText}>
                  Add your first site to manage bookings, hours, and the map pin from one place.
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowAddModal(true);
                  }}
                  style={styles.emptyListButton}
                  activeOpacity={0.85}
                >
                  <Text style={styles.emptyListButtonText}>Add location</Text>
                </TouchableOpacity>
              </GlassCard>
            ) : (
              <View style={styles.locationsList}>
                {(locations ?? []).map((location, index) => (
                  <View key={location.id} style={styles.locationListItem}>
                    {renderLocationCard(location, index)}
                  </View>
                ))}
              </View>
            )}
          </Animated.ScrollView>
        </View>
      </SafeAreaView>

      <Modal
        visible={showMapModal}
        animationType="fade"
        transparent={false}
        onRequestClose={() => setShowMapModal(false)}
      >
        <View style={styles.mapModalRoot}>
          <LinearGradient colors={['#08111c', '#0f172a', '#08111c']} style={StyleSheet.absoluteFill} />
          <BubbleBackground accountType="business" />
          <View style={[styles.mapModalHeader, { paddingTop: insets.top + 20 }]}>
            <View style={styles.mapModalHeaderText}>
              <Text style={styles.mapModalTitle}>Map view</Text>
              <Text style={styles.mapModalSubtitle}>See every location on the map</Text>
            </View>
            <Pressable
              onPress={() => setShowMapModal(false)}
              style={({ pressed }) => [styles.mapModalClose, pressed && { opacity: 0.85 }]}
              hitSlop={12}
            >
              <Ionicons name="close" size={22} color="#F9FAFB" />
            </Pressable>
          </View>
          {renderMap()}
          {locations.length > 0 ? (
            <View style={[styles.locationCardContainer, { height: locationsSheetHeight }]}>
              <View
                style={[
                  styles.locationBottomSheet,
                  {
                    borderColor: businessTheme.glassBorder ?? 'rgba(125,211,252,0.28)',
                    paddingBottom: Math.max(10, insets.bottom),
                  },
                ]}
              >
                <BusinessSheetBackground />
                <View style={[styles.sheetHandle, { backgroundColor: 'rgba(125,211,252,0.6)' }]} />
                <View style={styles.sheetHeaderRowWithFab}>
                  <View style={styles.sheetHeaderTitleCol}>
                    <Text style={styles.sheetHeaderTitle}>Your locations</Text>
                    <Text style={styles.sheetHeaderSubtitle}>Swipe to switch · tap people to see car care pros at this site</Text>
                  </View>
                  <TouchableOpacity
                    style={[
                      styles.locationsWashersFab,
                      { borderColor: businessTheme.glassBorder ?? 'rgba(125,211,252,0.35)' },
                    ]}
                    onPress={() => void openSiteWashersModal()}
                    activeOpacity={0.88}
                    accessibilityLabel="Car care pros at selected location"
                  >
                    <LinearGradient
                      colors={[`${headerBackgroundForFab[0]}F0`, `${headerBackgroundForFab[1] || headerBackgroundForFab[0]}D8`]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                    />
                    <Ionicons name="people-outline" size={22} color="#F9FAFB" style={styles.locationsWashersFabIcon} />
                  </TouchableOpacity>
                </View>
                <View style={styles.sheetContentWrap}>
                  <View style={styles.sheetCardsScrollWrap}>
                    <ScrollView
                      ref={scrollViewRef}
                      horizontal
                      pagingEnabled={false}
                      showsHorizontalScrollIndicator={false}
                      onScroll={handleScroll}
                      scrollEventThrottle={16}
                      contentContainerStyle={styles.sheetCardsScrollContent}
                      snapToInterval={cardWidth + cardSpacing}
                      decelerationRate="fast"
                      snapToAlignment="start"
                      nestedScrollEnabled
                    >
                      {(locations ?? []).map((location) => (
                        <View key={location.id} style={[styles.locationCardScrollItem, { width: cardWidth }]}>
                          {renderLocationCard(location, locations.findIndex((loc) => loc.id === location.id))}
                        </View>
                      ))}
                    </ScrollView>
                  </View>
                </View>
              </View>
            </View>
          ) : null}
        </View>
      </Modal>

        <ActiveBookingsSheet
          visible={showBookingsSheet}
          onClose={() => setShowBookingsSheet(false)}
          bookings={liveBookings}
          loading={bookingsSheetLoading}
          onRefresh={async () => {
            const loc = locations[selectedLocationIndex];
            const list = await loadBookingsForSheet(loc?.id);
            setLiveBookings(list);
          }}
          onViewAll={() => {
            setShowBookingsSheet(false);
            router.push('/business/bookings/activity');
          }}
        />

        {/* Washers at selected location (fixed-site assignments) */}
        <Modal
          visible={siteWashersModalOpen}
          transparent
          animationType="slide"
          onRequestClose={() => setSiteWashersModalOpen(false)}
        >
          <View style={styles.locWasherModalRoot}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setSiteWashersModalOpen(false)}>
              <View style={[StyleSheet.absoluteFill, { backgroundColor: locWasherSheetBackdrop }]} />
            </Pressable>
            <View
              style={[
                styles.locWasherBottomSheet,
                {
                  paddingBottom: Math.max(insets.bottom, 24),
                  borderColor: businessTheme.glassBorder ?? 'rgba(125,211,252,0.35)',
                  maxHeight: '78%',
                },
              ]}
              pointerEvents="box-none"
            >
              <BusinessSheetBackground />
              <View style={[styles.locWasherHandle, { backgroundColor: locWasherHandleBg }]} />
              <View style={[styles.locWasherHeaderRow, { borderBottomColor: locWasherBorder }]}>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={[styles.locWasherSheetTitle, { color: locWasherTitle }]} numberOfLines={2}>
                    Car Care Pros at this location
                  </Text>
                  {activeLocationName ? (
                    <Text style={[styles.locWasherSheetSub, { color: locWasherMuted }]} numberOfLines={1}>
                      {activeLocationName}
                    </Text>
                  ) : null}
                </View>
                <Pressable
                  onPress={() => setSiteWashersModalOpen(false)}
                  style={({ pressed }) => [
                    styles.locWasherCloseBtn,
                    { backgroundColor: locWasherCloseBg },
                    pressed && { opacity: 0.85 },
                  ]}
                  hitSlop={12}
                >
                  <Ionicons name="close" size={22} color={locWasherTitle} />
                </Pressable>
              </View>
              {siteWashersBody || (
                <ScrollView
                  style={styles.locWasherScroll}
                  contentContainerStyle={styles.locWasherScrollContent}
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                >
                  {siteWashers.map((w) => (
                    <View key={w.id} style={[styles.locWasherRow, { borderBottomColor: locWasherBorder }]}>
                      {w.photoUrl ? (
                        <Image source={{ uri: w.photoUrl }} style={styles.locWasherAvatar} resizeMode="cover" />
                      ) : (
                        <LinearGradient
                          colors={[businessTheme.primary, businessTheme.primaryAlt || SKY]}
                          style={styles.locWasherAvatar}
                        >
                          <Text style={styles.locWasherAvatarLetter}>{w.name.trim().slice(0, 1).toUpperCase()}</Text>
                        </LinearGradient>
                      )}
                      <View style={styles.locWasherTextCol}>
                        <Text style={[styles.locWasherName, { color: locWasherTitle }]} numberOfLines={1}>
                          {w.name}
                        </Text>
                        {w.email ? (
                          <Text style={[styles.locWasherEmail, { color: locWasherMuted }]} numberOfLines={1}>
                            {w.email}
                          </Text>
                        ) : null}
                      </View>
                    </View>
                  ))}
                </ScrollView>
              )}
              <TouchableOpacity
                style={styles.locWasherDoneBtn}
                activeOpacity={0.85}
                onPress={async () => {
                  await hapticFeedback('light');
                  setSiteWashersModalOpen(false);
                }}
              >
                <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={StyleSheet.absoluteFill} />
                <Text style={styles.locWasherDoneText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Add location — bottom sheet (matches business location / team sheets) */}
        <Modal
          visible={showAddModal}
          animationType="slide"
          transparent
          onRequestClose={() => setShowAddModal(false)}
        >
          <KeyboardAvoidingView
            style={styles.addSheetKeyboardRoot}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <View style={styles.addSheetRoot}>
              <Pressable
                style={StyleSheet.absoluteFill}
                onPress={() => {
                  void hapticFeedback('light');
                  setShowAddModal(false);
                }}
              >
                <View style={[StyleSheet.absoluteFill, styles.addSheetBackdrop]} />
              </Pressable>
              <View
                style={[
                  styles.addBottomSheet,
                  {
                    paddingBottom: Math.max(insets.bottom, 20),
                    borderColor: businessTheme.glassBorder ?? 'rgba(125,211,252,0.28)',
                  },
                ]}
                pointerEvents="box-none"
              >
                <BusinessSheetBackground />
                <View style={[styles.addSheetHandle, { backgroundColor: `${businessTheme.primary ?? SKY}99` }]} />
                <View style={styles.addSheetHeaderRow}>
                  <View style={styles.addSheetHeaderText}>
                    <Text style={styles.addSheetKicker}>NEW SITE</Text>
                    <Text style={styles.addSheetTitle}>Add location</Text>
                    <Text style={styles.addSheetSubtitle} numberOfLines={2}>
                      Name and full address — open the location after saving to set hours, services, and map pin.
                    </Text>
                  </View>
                  <Pressable
                    onPress={() => {
                      void hapticFeedback('light');
                      setShowAddModal(false);
                    }}
                    style={({ pressed }) => [styles.addSheetCloseBtn, pressed && { opacity: 0.85 }]}
                    hitSlop={12}
                  >
                    <Ionicons name="close" size={22} color="#FFFFFF" />
                  </Pressable>
                </View>

                <ScrollView
                  style={styles.addSheetScroll}
                  contentContainerStyle={styles.addSheetScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <Text style={styles.addFieldLabel}>Location name</Text>
                  <GlassCard style={styles.addFieldCard} accountType="business" variant="header">
                    <TextInput
                      style={styles.addFieldInput}
                      placeholder="e.g. Main Car Wash Hub"
                      placeholderTextColor="rgba(249,250,251,0.4)"
                      value={newLocationName}
                      onChangeText={setNewLocationName}
                      autoCapitalize="words"
                      autoFocus
                    />
                  </GlassCard>

                  <Text style={[styles.addFieldLabel, { marginTop: 16 }]}>Full address</Text>
                  <Text style={styles.addFieldHint}>Street, city, postcode</Text>
                  <GlassCard style={styles.addFieldCard} accountType="business" variant="header">
                    <TextInput
                      style={[styles.addFieldInput, styles.addFieldInputMultiline]}
                      placeholder="Start typing…"
                      placeholderTextColor="rgba(249,250,251,0.4)"
                      value={newLocationAddress}
                      onChangeText={setNewLocationAddress}
                      multiline
                      textAlignVertical="top"
                      autoCapitalize="words"
                    />
                  </GlassCard>
                </ScrollView>

                <ContinueCTAButton
                  title="Add location"
                  onPress={() => void handleAddLocation()}
                  accentColor={businessTheme.primary ?? SKY}
                  disabled={saving}
                  loading={saving}
                  style={styles.addSheetPrimaryBtn}
                />
              </View>
            </View>
          </KeyboardAvoidingView>
        </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  pageShell: {
    flex: 1,
    paddingHorizontal: 20,
  },
  pageHeader: {
    paddingTop: 8,
    paddingBottom: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pageHeaderActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  pageHeaderFab: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  locationsScroll: {
    flex: 1,
  },
  locationsScrollContent: {
    paddingBottom: 16,
  },
  listLoadingWrap: {
    minHeight: 280,
    justifyContent: 'center',
  },
  emptyListCard: {
    padding: 22,
    alignItems: 'center',
    gap: 12,
    borderRadius: 22,
  },
  emptyListTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
    textAlign: 'center',
  },
  emptyListText: {
    color: 'rgba(249,250,251,0.72)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  emptyListButton: {
    marginTop: 6,
    backgroundColor: SKY,
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 14,
  },
  emptyListButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '800',
  },
  locationListItem: {
    marginBottom: 14,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: {
    ...textStyles.bodySmall,
    color: SKY,
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.24)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.22,
    shadowRadius: 10,
    elevation: 6,
  },
  legacyScrollView: {
    flex: 1,
  },
  legacyScrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 400,
  },
  legacyEmptyCard: {
    padding: 40,
  },
  emptyContent: {
    paddingHorizontal: 0,
    paddingTop: 8,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#F9FAFB',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: 'rgba(249,250,251,0.7)',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 8,
  },
  addFirstButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addFirstButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  locationsList: {
    gap: 16,
  },
  locationCard: {
    padding: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 6,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  legacyDeleteButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteButtonInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legacyStatusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legacyStatusText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  legacyModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'flex-end',
  },
  legacyModalContentWrapper: {
    width: '100%',
    maxHeight: '90%',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    overflow: 'hidden',
  },
  legacyModalContent: {
    width: '100%',
    padding: 0,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    position: 'relative',
  },
  legacyModalScrollView: {
    maxHeight: 500,
  },
  modalScrollContent: {
    paddingBottom: 20,
  },
  legacyModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 28,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    flex: 1,
  },
  modalIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  modalIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalTitleContainer: {
    flex: 1,
    gap: 4,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  modalSubtitle: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 14,
    fontWeight: '500',
    marginTop: 2,
  },
  modalCloseButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(249,250,251,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBody: {
    padding: 28,
    gap: 28,
    paddingBottom: 32,
  },
  inputGroup: {
    gap: 12,
  },
  inputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  inputHint: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 13,
    fontWeight: '500',
    marginTop: -4,
    marginBottom: 4,
  },
  inputContainerBlur: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  inputInner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 18,
    gap: 14,
  },
  inputIcon: {
    marginTop: 2,
  },
  textInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    padding: 0,
    minHeight: 24,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
    paddingTop: 0,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 14,
    marginTop: 12,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    backgroundColor: 'rgba(249,250,251,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButtonText: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    flex: 1.5,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: BUSINESS_PRIMARY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  saveButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
    fontWeight: '600',
  },
  mapModalRoot: {
    flex: 1,
    backgroundColor: '#08111c',
  },
  mapModalHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingTop: 14,
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  mapModalHeaderText: {
    flex: 1,
    paddingRight: 12,
  },
  mapModalTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: -0.4,
  },
  mapModalSubtitle: {
    marginTop: 4,
    fontSize: 13,
    color: 'rgba(249,250,251,0.72)',
  },
  mapModalClose: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  locationsLoadingSheetBody: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 24,
  },
  locationsLoadingSheetHint: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  locationMarker: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerGlow: {
    position: 'absolute',
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(125,211,252,0.25)',
    borderWidth: 2,
    borderColor: 'rgba(125,211,252,0.5)',
  },
  markerGlowActive: {
    backgroundColor: 'rgba(125,211,252,0.45)',
    borderColor: SKY,
    borderWidth: 3,
  },
  markerCore: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15,23,42,0.92)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  markerCoreSelected: {
    backgroundColor: SKY,
    borderColor: '#fff',
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 10,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  locationCardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  locationBottomSheet: {
    flex: 1,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: 'hidden',
    paddingTop: 2,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.36)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -10 },
    shadowOpacity: 0.34,
    shadowRadius: 26,
    elevation: 22,
  },
  bottomSheetBlur: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
  },
  handle: {
    position: 'absolute',
    top: 10,
    left: (width - 36) / 2,
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(125,211,252,0.5)',
  },
  sheetHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  sheetHeaderRow: { marginBottom: 0 },
  sheetHeaderRowWithFab: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 10,
    marginBottom: 0,
  },
  sheetHeaderTitleCol: { flex: 1, minWidth: 0 },
  sheetHeaderTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', letterSpacing: -0.4 },
  sheetHeaderSubtitle: { fontSize: 11, color: 'rgba(249,250,251,0.68)', marginBottom: 4, letterSpacing: 0.2 },
  locationsWashersFab: {
    width: 44,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    marginTop: 2,
    flexShrink: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
  },
  locationsWashersFabIcon: { zIndex: 2 },
  locWasherModalRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  locWasherBottomSheet: {
    overflow: 'hidden',
    width: '100%',
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 10,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -8 },
    shadowOpacity: 0.24,
    shadowRadius: 18,
    elevation: 20,
  },
  locWasherHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  locWasherHeaderRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    gap: 12,
  },
  locWasherSheetTitle: { fontSize: 20, fontWeight: '600', flex: 1 },
  locWasherSheetSub: { fontSize: 13, fontWeight: '600', marginTop: 4 },
  locWasherCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  locWasherLoadingWrap: {
    paddingVertical: 36,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  locWasherLoadingText: { fontSize: 13, fontWeight: '600' },
  locWasherEmptyWrap: {
    paddingVertical: 28,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  locWasherEmptyTitle: { fontSize: 17, fontWeight: '800', textAlign: 'center', marginBottom: 8 },
  locWasherEmptySub: { fontSize: 13, lineHeight: 19, textAlign: 'center', fontWeight: '600' },
  locWasherScroll: { maxHeight: 340, marginBottom: 16 },
  locWasherScrollContent: { paddingBottom: 8 },
  locWasherRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  locWasherAvatar: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  locWasherAvatarLetter: { color: '#0f172a', fontSize: 18, fontWeight: '900' },
  locWasherTextCol: { flex: 1, minWidth: 0 },
  locWasherName: { fontSize: 16, fontWeight: '800' },
  locWasherEmail: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  locWasherDoneBtn: {
    borderRadius: 24,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  locWasherDoneText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  sheetContentWrap: {
    flex: 1,
    minHeight: 0,
    marginTop: 6,
    justifyContent: 'flex-start',
  },
  sheetCardsScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  sheetCardsScrollContent: {
    paddingHorizontal: 0,
    paddingVertical: 4,
    paddingBottom: 4,
    flexGrow: 1,
    alignItems: 'stretch',
  },
  locationCardScrollItem: { marginHorizontal: 7 },
  locationCardWrapper: {
    width: '100%',
    overflow: 'visible',
  },
  sheetCard: {
    padding: 12,
    borderRadius: 20,
    gap: 8,
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.24,
    shadowRadius: 14,
    elevation: 8,
  },
  sheetCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 0,
  },
  sheetCardIconWrap: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sheetCardBody: {
    flex: 1,
    minWidth: 0,
  },
  sheetCardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 2,
    flexWrap: 'wrap',
  },
  sheetCardTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
    flex: 1,
    minWidth: 100,
  },
  siteTypePill: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 7,
    borderWidth: 1,
  },
  siteTypePillUnit: {
    backgroundColor: 'rgba(125,211,252,0.15)',
    borderColor: 'rgba(125,211,252,0.35)',
  },
  siteTypePillMobile: {
    backgroundColor: 'rgba(168,85,247,0.18)',
    borderColor: 'rgba(168,85,247,0.4)',
  },
  siteTypePillText: {
    fontSize: 9,
    fontWeight: '900',
    color: '#F9FAFB',
    letterSpacing: 0.35,
  },
  sheetCardSubtitle: {
    fontSize: 12,
    color: 'rgba(249,250,251,0.84)',
  },
  sheetStatusWrap: {
    alignSelf: 'flex-start',
    marginTop: 2,
    marginBottom: 2,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  statusPillOpen: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#EF4444',
  },
  statusDotOpen: {
    backgroundColor: '#10B981',
  },
  statusText: {
    color: '#EF4444',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.25,
  },
  statusTextOpen: {
    color: '#10B981',
  },
  locationStatsRow: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 0,
  },
  locationStatItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    backgroundColor: 'rgba(15,23,42,0.34)',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 6,
  },
  locationStatValue: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '800',
  },
  locationStatLabel: {
    color: 'rgba(241,245,249,0.7)',
    fontSize: 10,
    fontWeight: '600',
  },
  cardActionsBelow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.12)',
    marginBottom: 2,
  },
  sheetPrimaryBtn: {
    flex: 1,
    borderRadius: 15,
    height: 42,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
    backgroundColor: 'rgba(255,255,255,0.09)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  },
  sheetPrimaryBtnText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  sheetSecondaryBtn: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  emptySheet: {
    paddingTop: 12,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    overflow: 'hidden',
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.28)',
    minHeight: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  emptyCardInner: {
    alignItems: 'center',
    padding: 24,
    borderRadius: 20,
  },
  emptyIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  headerIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.38)',
  },
  headerIndicatorDotActive: {
    width: 26,
    backgroundColor: SKY,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  headerActionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.24)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.22,
    shadowRadius: 10,
    elevation: 6,
  },
  locationMarkerSelected: {
    transform: [{ scale: 1.08 }],
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContentWrapper: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 24,
    overflow: 'hidden',
  },
  modalContent: {
    padding: 0,
    borderRadius: 24,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  modalScrollView: {
    maxHeight: 500,
  },
  inputContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 50,
  },
  emptyContainerBottom: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 20,
    minHeight: 220,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  popupContent: {
    width: '100%',
    maxWidth: 400,
    maxHeight: '80%',
    borderRadius: 24,
    overflow: 'hidden',
  },
  popupBlur: {
    padding: 0,
    borderRadius: 24,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 24,
  },
  popupCloseButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  popupCoverContainer: {
    width: '100%',
    height: 200,
    overflow: 'hidden',
  },
  popupCoverImage: {
    width: '100%',
    height: '100%',
  },
  popupBody: {
    padding: 24,
    gap: 16,
  },
  popupTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  popupDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  popupDetailText: {
    color: '#E5E7EB',
    fontSize: 15,
    flex: 1,
  },
  popupStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  popupStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  popupStatusText: {
    color: '#9CA3AF',
    fontSize: 14,
    fontWeight: '600',
  },
  popupViewButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    marginTop: 8,
  },
  popupViewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  popupViewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },

  addSheetKeyboardRoot: {
    flex: 1,
  },
  addSheetRoot: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  addSheetBackdrop: {
    backgroundColor: 'rgba(5, 12, 24, 0.82)',
  },
  addBottomSheet: {
    width: '100%',
    maxHeight: '88%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderWidth: 1,
    borderBottomWidth: 0,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
    elevation: 20,
  },
  addSheetHandle: {
    alignSelf: 'center',
    width: 36,
    height: 4,
    borderRadius: 2,
    marginBottom: 14,
  },
  addSheetHeaderRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    paddingBottom: 16,
    marginBottom: 4,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.12)',
  },
  addSheetHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  addSheetKicker: {
    color: 'rgba(125,211,252,0.88)',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  addSheetTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    marginTop: 4,
  },
  addSheetSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 6,
    lineHeight: 17,
  },
  addSheetCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 2,
  },
  addSheetScroll: {
    maxHeight: 340,
  },
  addSheetScrollContent: {
    paddingBottom: 12,
  },
  addFieldLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
    marginBottom: 8,
  },
  addFieldHint: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: -4,
    marginBottom: 8,
  },
  addFieldCard: {
    paddingVertical: 4,
    paddingHorizontal: 4,
    borderRadius: 16,
  },
  addFieldInput: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    paddingHorizontal: 14,
    paddingVertical: 12,
    minHeight: 48,
  },
  addFieldInputMultiline: {
    minHeight: 96,
    paddingTop: 12,
  },
  addSheetPrimaryBtn: {
    marginTop: 8,
    borderRadius: 24,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  addSheetPrimaryBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
});
