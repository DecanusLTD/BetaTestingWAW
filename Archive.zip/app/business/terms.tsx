import React from 'react';
import TermsAgreementScreen from '../../src/components/shared/TermsAgreementScreen';

export default function BusinessTermsScreen() {
  return (
    <TermsAgreementScreen
      accountType="business"
      title="Business questionnaire"
      subtitle="Tell us how your business operates so we can keep your account setup in sync."
      version="v1.0"
      continuePath="/business/stripe-connect?mode=onboarding"
      blockedPath="/business/terms-blocked"
      footerNote="The same questionnaire record is used for both mobile-based and physical business accounts."
    />
  );
}
