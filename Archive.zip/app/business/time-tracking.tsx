import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface TimeEntry {
  id: string;
  valeterName: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  totalHours?: number;
  status: 'active' | 'completed';
}

export default function BusinessTimeTracking() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadTimeEntries();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadTimeEntries = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load time tracking entries from database
      const { data, error } = await supabase
        .from('time_tracking')
        .select('*')
        .eq('organization_id', user.id)
        .order('date', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error loading time entries:', error);
        setTimeEntries([]);
        return;
      }

      // Transform database records to TimeEntry format
      const entries: TimeEntry[] = (data || []).map((entry: any) => ({
        id: entry.id,
        valeterName: entry.valeter_name || 'Unknown',
        date: entry.date || new Date().toISOString().split('T')[0],
        clockIn: entry.clock_in || '',
        clockOut: entry.clock_out || undefined,
        totalHours: entry.total_hours || undefined,
        status: entry.status || 'completed',
      }));

      setTimeEntries(entries);
    } catch (error) {
      console.error('Error loading time entries:', error);
      setTimeEntries([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Time Tracking" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Time Tracking"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Today's Time Entries</Text>
          <Text style={styles.sectionSubtitle}>
            Monitor valeter attendance and working hours
          </Text>

          {timeEntries.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="time-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
                <Text style={styles.emptyTitle}>No time entries yet</Text>
                <Text style={styles.emptyText}>
                  Time tracking data will appear here when valeters clock in
                </Text>
              </View>
            </GlassCard>
          ) : (
            <View style={styles.entriesList}>
              {timeEntries.map((entry) => (
                <GlassCard key={entry.id} style={styles.entryCard} accountType="business">
                  <View style={styles.entryContent}>
                    <View style={styles.entryHeader}>
                      <View style={styles.entryInfo}>
                        <Text style={styles.valeterName}>{entry.valeterName}</Text>
                        <Text style={styles.entryDate}>{entry.date}</Text>
                      </View>
                      <View
                        style={[
                          styles.statusBadge,
                          { backgroundColor: entry.status === 'active' ? 'rgba(16,185,129,0.15)' : 'rgba(139,92,246,0.15)' },
                        ]}
                      >
                        <Text
                          style={[
                            styles.statusText,
                            { color: entry.status === 'active' ? '#10B981' : '#8B5CF6' },
                          ]}
                        >
                          {entry.status === 'active' ? 'Active' : 'Completed'}
                        </Text>
                      </View>
                    </View>
                    <View style={styles.timeRow}>
                      <View style={styles.timeItem}>
                        <Ionicons name="log-in-outline" size={16} color="#8B5CF6" />
                        <Text style={styles.timeLabel}>Clock In</Text>
                        <Text style={styles.timeValue}>{entry.clockIn}</Text>
                      </View>
                      {entry.clockOut && (
                        <View style={styles.timeItem}>
                          <Ionicons name="log-out-outline" size={16} color="#8B5CF6" />
                          <Text style={styles.timeLabel}>Clock Out</Text>
                          <Text style={styles.timeValue}>{entry.clockOut}</Text>
                        </View>
                      )}
                      {entry.totalHours && (
                        <View style={styles.timeItem}>
                          <Ionicons name="time" size={16} color="#8B5CF6" />
                          <Text style={styles.timeLabel}>Total</Text>
                          <Text style={styles.timeValue}>{entry.totalHours}h</Text>
                        </View>
                      )}
                    </View>
                  </View>
                </GlassCard>
              ))}
            </View>
          )}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.lg,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: SPACING.xl,
  },
  entriesList: {
    gap: SPACING.md,
  },
  entryCard: {
    ...CARD_SIZES.medium,
  },
  entryContent: {
    padding: CARD_SIZES.medium.padding,
    gap: SPACING.md,
  },
  entryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  entryInfo: {
    flex: 1,
    gap: 2,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  entryDate: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  timeRow: {
    flexDirection: 'row',
    gap: SPACING.lg,
    paddingTop: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.15)',
  },
  timeItem: {
    flex: 1,
    gap: 4,
  },
  timeLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
  },
  timeValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
    padding: CARD_SIZES.large.padding,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});

