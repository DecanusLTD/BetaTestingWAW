import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GradientNotificationBell from '../../src/components/shared/GradientNotificationBell';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
}

export default function BusinessDashboard() {
  const { user } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessName, setBusinessName] = useState<string>('');
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [businessRating, setBusinessRating] = useState<number>(0);
  const [notificationCount, setNotificationCount] = useState<number>(0);
  const [stats, setStats] = useState({
    totalLocations: 0,
    activeBookings: 0,
    valetersOnline: 0,
    todayRevenue: 0,
    totalRevenue: 0,
    completionRate: 0,
    averageRating: 0,
    bookingsThisWeek: 0,
  });

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadData();
      fetchNotificationCount();
      // Refresh notification count every 45 seconds
      const interval = setInterval(fetchNotificationCount, 45000);
      return () => clearInterval(interval);
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadData = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const [locationsData, orgData, rating] = await Promise.all([
        loadLocations(),
        loadOrganizationData(),
        calculateBusinessRating(),
      ]);
      
      // Calculate completion rate (placeholder logic)
      const totalBookings = stats.activeBookings + 10; // Placeholder
      const completed = totalBookings - stats.activeBookings;
      const completionRate = totalBookings > 0 ? (completed / totalBookings) * 100 : 0;

      if (orgData) {
        setBusinessName(orgData.name || '');
        setBusinessAddress(orgData.address || '');
      }
      setBusinessRating(rating);

      setStats({
        totalLocations: locationsData?.length || 0,
        activeBookings: 0,
        valetersOnline: 0,
        todayRevenue: 0,
        totalRevenue: 0,
        completionRate: Math.round(completionRate),
        averageRating: rating,
        bookingsThisWeek: 0,
      });
    } catch (error) {
      console.error('Error loading business data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadLocations = async (): Promise<Location[]> => {
    if (!user?.id) return [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address')
        .eq('organization_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const list = data || [];
      setLocations(list);
      return list;
    } catch (error) {
      console.error('Error loading locations:', error);
      return [];
    }
  };

  const loadOrganizationData = async () => {
    if (!user?.id) return null;
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('name, address')
        .eq('id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    } catch (error) {
      console.error('Error loading organization data:', error);
      return null;
    }
  };

  const fetchNotificationCount = async () => {
    if (!user?.id) return;
    try {
      // Get all valeters belonging to this organization
      const { data: valeters } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', user.id)
        .eq('user_type', 'valeter');

      const valeterIds = valeters?.map(v => v.id) || [];

      // Count bookings assigned to organization valeters that need attention
      let newBookingsCount = 0;
      if (valeterIds.length > 0) {
        const { count } = await supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .in('valeter_id', valeterIds)
          .in('status', ['pending', 'pending_valeter_acceptance', 'pending_payment', 'confirmed', 'valeter_assigned']);
        newBookingsCount = count || 0;
      }

      // Count team join requests
      const { count: teamRequestsCount } = await supabase
        .from('team_requests')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', user.id)
        .eq('status', 'pending');

      const totalCount = newBookingsCount + (teamRequestsCount || 0);
      setNotificationCount(totalCount);
    } catch (error) {
      console.error('Error fetching notification count:', error);
      setNotificationCount(0);
    }
  };

  const calculateBusinessRating = async (): Promise<number> => {
    if (!user?.id) return 0;
    try {
      // Get all valeters belonging to this organization
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', user.id)
        .eq('user_type', 'valeter');

      if (valetersError) throw valetersError;
      if (!valeters || valeters.length === 0) return 0;

      const valeterIds = valeters.map(v => v.id);

      // Get all completed bookings with ratings for these valeters
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('rating')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('rating', 'is', null);

      if (bookingsError) throw bookingsError;
      if (!bookings || bookings.length === 0) return 0;

      // Calculate average rating
      const ratings = bookings
        .map(b => Number(b.rating))
        .filter(r => !isNaN(r) && r > 0);
      
      if (ratings.length === 0) return 0;
      
      const average = ratings.reduce((sum, r) => sum + r, 0) / ratings.length;
      return Math.round(average * 10) / 10; // Round to 1 decimal place
    } catch (error) {
      console.error('Error calculating business rating:', error);
      return 0;
    }
  };

  const quickActions = [
    {
      id: 'bookings',
      title: 'View Bookings',
      subtitle: 'Manage all',
      icon: 'calendar',
      gradient: ['#3B82F6', '#2563EB'],
      route: '/business/bookings',
    },
    {
      id: 'services',
      title: 'Services & Pricing',
      subtitle: 'View options',
      icon: 'list',
      gradient: ['#8B5CF6', '#7C3AED'],
      route: '/business/services',
    },
    {
      id: 'locations',
      title: 'Locations',
      subtitle: 'Manage sites',
      icon: 'location',
      gradient: ['#10B981', '#059669'],
      route: '/business/locations',
    },
    {
      id: 'team',
      title: 'Team',
      subtitle: 'Manage staff',
      icon: 'people',
      gradient: ['#F59E0B', '#D97706'],
      route: '/business/team',
    },
    {
      id: 'analytics',
      title: 'Analytics',
      subtitle: 'View insights',
      icon: 'stats-chart',
      gradient: [businessTheme.primary, businessTheme.primaryAlt],
      route: '/business/analytics',
    },
    {
      id: 'settings',
      title: 'Settings',
      subtitle: 'Configure',
      icon: 'settings',
      gradient: [businessTheme.primaryAlt, businessTheme.primary],
      route: '/business/settings',
    },
  ];

  const scaleFor = () => new Animated.Value(1);
  const pressIn = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 0.97, useNativeDriver: true }).start();
  const pressOut = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 1, friction: 3, useNativeDriver: true }).start();

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Dashboard" showBack={false} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading business data...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader
        title={businessName || "Business Overview"}
        subtitle={businessAddress || `${getGreeting()}${user?.name ? `, ${user.name.split(' ')[0]}` : ''}`}
        variant="dashboard"
        accountType="business"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        businessName={businessName}
        businessAddress={businessAddress}
        businessRating={businessRating}
        rightAction={
          <GradientNotificationBell
            count={notificationCount}
            onPress={() => router.push('/business/notifications')}
            accentColor={businessTheme.primary}
          />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET },
        ]}
      >

        {/* Key Metrics - Cards with Charts */}
        <View style={styles.metricsSection}>
          <Text style={styles.sectionTitle}>Key Metrics</Text>
          <View style={styles.metricsGrid}>
            {/* Revenue Card */}
            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="cash" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>£{stats.todayRevenue}</Text>
                      <Text style={styles.metricLabel}>Today's Revenue</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: `${Math.min(stats.todayRevenue / 500 * 100, 100)}%`, backgroundColor: businessTheme.primary }]} />
                    </View>
                    <Text style={styles.progressText}>Target: £500</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            {/* Bookings Card */}
            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="calendar" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.activeBookings}</Text>
                      <Text style={styles.metricLabel}>Active Bookings</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: `${Math.min((stats.activeBookings / 20) * 100, 100)}%`, backgroundColor: businessTheme.primaryAlt }]} />
                    </View>
                    <Text style={styles.progressText}>{stats.bookingsThisWeek} this week</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            {/* Team Card */}
            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="people" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.valetersOnline}</Text>
                      <Text style={styles.metricLabel}>Online Now</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: `${Math.min((stats.valetersOnline / 10) * 100, 100)}%`, backgroundColor: businessTheme.primary }]} />
                    </View>
                    <Text style={styles.progressText}>Total team: {stats.valetersOnline}</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            {/* Performance Card */}
            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="trending-up" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.completionRate}%</Text>
                      <Text style={styles.metricLabel} numberOfLines={1}>Completion Rate</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: `${Math.min(stats.completionRate, 100)}%`, backgroundColor: businessTheme.primary }]} />
                    </View>
                    <Text style={styles.progressText}>Target: 100%</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>
          </View>
        </View>

        {/* Quick Actions - Horizontal Scroll */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsContainer}
          >
            {quickActions.map((action) => {
              const s = scaleFor();
              return (
                <Animated.View
                  key={action.id}
                  style={{ transform: [{ scale: s }], marginRight: 12 }}
                >
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPressIn={() => pressIn(s)}
                    onPressOut={() => pressOut(s)}
                    onPress={async () => {
                      await hapticFeedback('light');
                      router.push(action.route as any);
                    }}
                    style={styles.quickActionCard}
                  >
                    <View style={styles.quickActionContent}>
                      <View style={styles.quickActionIconWrapper}>
                        <Ionicons name={action.icon as any} size={18} color={businessTheme.primary} />
                      </View>
                      <View style={styles.quickActionTextContainer}>
                        <Text style={styles.quickActionTitle}>{action.title}</Text>
                        <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                </Animated.View>
              );
            })}
          </ScrollView>
        </View>

        {/* Business Overview Card */}
        <View style={styles.overviewSection}>
          <Text style={styles.sectionTitle}>Business Overview</Text>
          <GlassCard style={styles.overviewCard} accountType="business">
            <View style={styles.overviewContent}>
              <View style={styles.overviewHeader}>
                <View style={styles.overviewIconWrapper}>
                  <Ionicons name="business" size={22} color={businessTheme.primary} />
                </View>
                <View style={styles.overviewTextContainer}>
                  <Text style={styles.overviewTitle}>Your Business</Text>
                  <Text style={styles.overviewSubtitle}>Performance metrics and insights</Text>
                </View>
              </View>

              <View style={styles.overviewStats}>
                <View style={styles.overviewStatItem}>
                  <Text style={styles.overviewStatValue}>{stats.totalLocations}</Text>
                  <Text style={styles.overviewStatLabel}>Locations</Text>
                </View>
                <View style={styles.overviewDivider} />
                <View style={styles.overviewStatItem}>
                  <Text style={styles.overviewStatValue}>£{stats.totalRevenue}</Text>
                  <Text style={styles.overviewStatLabel}>Total Revenue</Text>
                </View>
                <View style={styles.overviewDivider} />
                <View style={styles.overviewStatItem}>
                  <Text style={styles.overviewStatValue}>
                    {stats.averageRating > 0 ? stats.averageRating.toFixed(1) : '0.0'}
                  </Text>
                  <Text style={styles.overviewStatLabel}>Avg Rating</Text>
                </View>
              </View>

              <View style={styles.overviewProgressContainer}>
                <View style={styles.overviewProgressHeader}>
                  <Text style={styles.overviewProgressLabel}>Overall Performance</Text>
                  <Text style={styles.overviewProgressValue}>{stats.completionRate}%</Text>
                </View>
                <View style={styles.overviewProgressBar}>
                  <View style={[styles.overviewProgressFill, { width: `${stats.completionRate}%`, backgroundColor: businessTheme.primary }]} />
                </View>
              </View>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/analytics');
                }}
                style={styles.overviewAction}
              >
                <Text style={styles.overviewActionText}>View Detailed Analytics</Text>
                <Ionicons name="chevron-forward" size={16} color={businessTheme.primary} />
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>

        {/* Locations Summary */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Locations</Text>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/locations');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {locations.length === 0 ? (
            <GlassCard style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    router.push('/business/locations');
                  }}
                  style={styles.addButton}
                >
                  <LinearGradient
                    colors={['#10B981', '#059669']}
                    style={styles.addButtonGradient}
                  >
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          ) : (
            <View style={styles.locationsList}>
              {locations.slice(0, 3).map((location, index) => (
                <Animated.View
                  key={location.id}
                  style={[
                    { opacity: fadeAnim },
                    {
                      transform: [
                        {
                          translateY: fadeAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: [30 + index * 10, 0],
                          }),
                        },
                      ],
                    },
                  ]}
                >
                  <GlassCard
                    onPress={async () => {
                      await hapticFeedback('light');
                      router.push(`/business/locations/${location.id}` as any);
                    }}
                    style={styles.locationCard}
                    accountType="business"
                  >
                    <View style={styles.locationContent}>
                      <View style={styles.locationIconWrapper}>
                        <Ionicons name="location" size={20} color={businessTheme.primary} />
                      </View>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationAddress} numberOfLines={1}>
                          {location.address || 'Address not set'}
                        </Text>
                      </View>
                      <Ionicons name="chevron-forward" size={18} color={businessTheme.primary} />
                    </View>
                  </GlassCard>
                </Animated.View>
              ))}
              {locations.length > 3 && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push('/business/locations');
                  }}
                  style={styles.viewMoreButton}
                >
                  <Text style={styles.viewMoreText}>
                    View {locations.length - 3} more location{locations.length - 3 !== 1 ? 's' : ''}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        {/* Powered By */}
        <View style={styles.poweredBySection}>
          <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100, // Extra padding for navigation tab
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  glowLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: `${businessTheme.primary}66`,
    shadowColor: businessTheme.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 4,
  },
  headerContent: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
    minHeight: 56,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  headerLeft: {
    flex: 1,
  },
  greeting: {
    color: businessTheme.primary,
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
    opacity: 0.95,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  metricsSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  metricCard: {
    width: getMetricCardWidth(2, SPACING.md),
    ...CARD_SIZES.small,
  },
  metricContent: {
    padding: CARD_SIZES.small.padding,
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    marginBottom: SPACING.lg,
  },
  metricIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: `${businessTheme.primary}26`,
  },
  metricText: {
    flex: 1,
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 2,
  },
  metricLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
    flexShrink: 0,
  },
  metricProgressContainer: {
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 9,
    fontWeight: '500',
  },
  quickActionsSection: {
    marginBottom: 32,
  },
  quickActionsContainer: {
    paddingRight: isSmallScreen ? 16 : 20,
  },
  quickActionCard: {
    borderRadius: 16,
    backgroundColor: `${businessTheme.primary}1A`,
    borderWidth: 1,
    borderColor: `${businessTheme.primary}33`,
    width: 130,
  },
  quickActionContent: {
    padding: SPACING.md,
    gap: SPACING.sm,
  },
  quickActionIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  quickActionTextContainer: {
    gap: 2,
  },
  quickActionTitle: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  quickActionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },
  overviewSection: {
    marginBottom: 32,
  },
  overviewCard: {
    ...CARD_SIZES.medium,
  },
  overviewContent: {
    padding: CARD_SIZES.medium.padding,
  },
  overviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.lg,
    marginBottom: SPACING.xl,
  },
  overviewIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overviewTextContainer: {
    flex: 1,
  },
  overviewTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  overviewSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
  },
  overviewStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: SPACING.xl,
    paddingVertical: SPACING.lg,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(139,92,246,0.15)',
  },
  overviewStatItem: {
    alignItems: 'center',
  },
  overviewStatValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  overviewStatLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  overviewDivider: {
    width: 1,
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  overviewProgressContainer: {
    marginBottom: 16,
  },
  overviewProgressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  overviewProgressLabel: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    fontWeight: '600',
  },
  overviewProgressValue: {
    color: businessTheme.primary,
    fontSize: 14,
    fontWeight: '700',
  },
  overviewProgressBar: {
    width: '100%',
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  overviewProgressFill: {
    height: '100%',
    borderRadius: 3,
  },
  overviewAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingTop: SPACING.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.15)',
  },
  overviewActionText: {
    color: businessTheme.primary,
    fontSize: 13,
    fontWeight: '600',
  },
  section: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  viewAllText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  locationsList: {
    gap: 12,
  },
  locationCard: {
    ...CARD_SIZES.small,
  },
  locationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.lg,
    padding: CARD_SIZES.small.padding,
  },
  locationIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    lineHeight: 18,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  addButton: {
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#8B5CF6',
    elevation: 4,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  addButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  viewMoreButton: {
    padding: 12,
    alignItems: 'center',
  },
  viewMoreText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  poweredBySection: {
    alignItems: 'center',
    paddingVertical: 24,
    marginTop: 8,
  },
  poweredByText: {
    color: SKY,
    fontSize: 12,
    opacity: 0.8,
    fontWeight: '600',
  },
});