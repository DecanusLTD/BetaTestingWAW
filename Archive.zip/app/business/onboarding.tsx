import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Image,
  Modal,
  Pressable,
  TextInput,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { termsAgreementService } from '../../src/services/termsAgreementService';
import {
  showValeterInsuranceRequiredAlert,
  valeterInsuranceDetailsComplete,
} from '../../src/utils/valeterInsuranceQuestionnaire';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;

const onboardingSlides = [
  {
    id: 1,
    title: 'Welcome to Wish a Wash for Businesses',
    description:
      'Manage your physical car wash locations, accept bookings, and grow your business with ease.',
    icon: 'business',
    color: '#3B82F6',
  },
  {
    id: 2,
    title: 'Add Your Locations',
    description:
      'Start by adding your physical car wash locations. Each location can accept bookings independently.',
    icon: 'location',
    color: '#10B981',
  },
  {
    id: 3,
    title: 'Invite Car Care Pros to Your Team',
    description:
      'Build your team by inviting car care pros to work at your locations. They can accept bookings and clock in/out.',
    icon: 'people',
    color: '#F59E0B',
  },
  {
    id: 4,
    title: 'Accept and Manage Bookings',
    description:
      'Receive booking requests, accept or reject them, and assign car care pros. Track everything in real-time.',
    icon: 'calendar',
    color: '#87CEEB',
  },
  {
    id: 5,
    title: 'Use AI Car Care Hub',
    description:
      'Access tips and guides on repair services, learn how to grow your business, and discover free marketing opportunities.',
    icon: 'bulb',
    color: '#EC4899',
  },
  {
    id: 6,
    title: 'Repair Services Benefits',
    description:
      'Offer repair services and benefit from free marketing. Attract environmentally conscious customers.',
    icon: 'leaf',
    color: '#10B981',
  },
  {
    id: 7,
    title: 'Terms & Policies',
    description:
      'Please review and agree to our Terms of Service and Privacy Policy to continue.',
    icon: 'document-text',
    color: '#87CEEB',
  },
];

const QUESTIONNAIRE_STORAGE_KEY = 'business_onboarding_questionnaire_complete';

type YesNo = 'yes' | 'no';
type UnitBased = 'mobile_unit_based' | 'mobile' | 'unit';

type QuestionnaireAnswers = {
  keepCustomers: YesNo | null;
  keepCalendarAvailability: YesNo | null;
  shareContactDetails: YesNo | null;
  unitBased: UnitBased | null;
  hasBusinessInsurance: YesNo | null;
  insuranceProvider: string;
  insuranceType: string;
  policyNumber: string;
};

function resolveUnitBasedFromDetails(details: Record<string, unknown>, fallback: UnitBased): UnitBased {
  const ub = details.unitBased;
  if (ub === 'mobile_unit_based' || ub === 'mobile' || ub === 'unit') return ub;
  if (details.account_mode === 'physical') return 'unit';
  return fallback;
}

function onboardingNextButtonLabel(isLastSlide: boolean, questionnaireComplete: boolean): string {
  if (isLastSlide) {
    return questionnaireComplete ? 'Continue to Stripe Connect' : 'Complete questionnaire first';
  }
  return 'Next';
}

function onboardingNextButtonIcon(
  isLastSlide: boolean,
  questionnaireComplete: boolean
): 'checkmark' | 'lock-closed' | 'chevron-forward' {
  if (isLastSlide) {
    return questionnaireComplete ? 'checkmark' : 'lock-closed';
  }
  return 'chevron-forward';
}

function unitBasedLabel(value: UnitBased | null): string {
  if (value === 'mobile') return 'Mobile Based';
  if (value === 'unit') return 'Unit Based';
  if (value === 'mobile_unit_based') return 'Mobile + Unit Based';
  return 'Mobile + Unit Based';
}

export default function BusinessOnboarding() {
  const { user, updateUser } = useAuth();
  const scrollViewRef = useRef<ScrollView>(null);
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [questionnaireVisible, setQuestionnaireVisible] = useState(false);
  const [questionnaireComplete, setQuestionnaireComplete] = useState(false);
  const [questionnaireAnswers, setQuestionnaireAnswers] = useState<QuestionnaireAnswers>({
    keepCustomers: null,
    keepCalendarAvailability: null,
    shareContactDetails: null,
    unitBased: 'mobile_unit_based',
    hasBusinessInsurance: null,
    insuranceProvider: '',
    insuranceType: '',
    policyNumber: '',
  });
  const fadeAnim = useRef(new Animated.Value(1)).current;

  React.useEffect(() => {
    let cancelled = false;

    const loadQuestionnaireState = async () => {
      try {
        if (!user?.id) {
          if (!cancelled) setQuestionnaireComplete(false);
          return;
        }

        const record = await termsAgreementService.load('business', user.id);
        const details = record.details || {};
        const completed = record.status === 'accepted';
        if (cancelled) return;
        setQuestionnaireComplete(completed);
        if (completed) {
          setQuestionnaireAnswers((prev) => ({
            ...prev,
            keepCustomers:
              details.keepCustomers === 'yes' || details.keepCustomers === 'no' ? details.keepCustomers : prev.keepCustomers,
            keepCalendarAvailability:
              details.keepCalendarAvailability === 'yes' || details.keepCalendarAvailability === 'no'
                ? details.keepCalendarAvailability
                : prev.keepCalendarAvailability,
            shareContactDetails:
              details.shareContactDetails === 'yes' || details.shareContactDetails === 'no'
                ? details.shareContactDetails
                : prev.shareContactDetails,
            unitBased: resolveUnitBasedFromDetails(details, prev.unitBased ?? 'mobile_unit_based'),
            hasBusinessInsurance:
              details.hasBusinessInsurance === 'yes' || details.hasBusinessInsurance === 'no'
                ? details.hasBusinessInsurance
                : prev.hasBusinessInsurance,
            insuranceProvider: typeof details.insuranceProvider === 'string' ? details.insuranceProvider : prev.insuranceProvider,
            insuranceType: typeof details.insuranceType === 'string' ? details.insuranceType : prev.insuranceType,
            policyNumber: typeof details.policyNumber === 'string' ? details.policyNumber : prev.policyNumber,
          }));
          await AsyncStorage.setItem(QUESTIONNAIRE_STORAGE_KEY, 'true');
        } else {
          await AsyncStorage.removeItem(QUESTIONNAIRE_STORAGE_KEY);
        }
      } catch (error) {
        console.warn('[BusinessOnboarding] questionnaire load error:', error);
      }
    };

    void loadQuestionnaireState();

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const handleScroll = (event: any) => {
    const slideIndex = Math.round(event.nativeEvent.contentOffset.x / width);
    if (slideIndex !== currentSlide) {
      setCurrentSlide(slideIndex);
      hapticFeedback('light');
      Animated.sequence([
        Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      ]).start();
    }
  };

  const goToSlide = (index: number) => {
    scrollViewRef.current?.scrollTo({ x: index * width, animated: true });
    setCurrentSlide(index);
    hapticFeedback('light');
  };

  const handleNext = () => {
    if (currentSlide < onboardingSlides.length - 1) {
      goToSlide(currentSlide + 1);
    } else {
      handleGetStarted();
    }
  };

  const markBusinessOnboardingComplete = async () => {
    try {
      await updateUser({ businessOnboarded: true });
      await AsyncStorage.setItem('onboarding_seen', 'business');
    } catch (e) {
      console.warn('[BusinessOnboarding] persist error:', e);
      await AsyncStorage.setItem('onboarding_seen', 'business');
    }
  };

  const handleGetStarted = async () => {
    if (!questionnaireComplete) {
      await hapticFeedback('light');
      setQuestionnaireVisible(true);
      return;
    }
    await hapticFeedback('medium');
    await markBusinessOnboardingComplete();
    router.replace('/business/stripe-connect?mode=onboarding');
  };

  const handleSkip = async () => {
    if (!questionnaireComplete) {
      await hapticFeedback('light');
      goToSlide(onboardingSlides.length - 1);
      return;
    }
    await handleGetStarted();
  };

  const handleOpenQuestionnaire = async () => {
    await hapticFeedback('light');
    setQuestionnaireVisible(true);
  };

  const updateQuestionnaire = <K extends keyof QuestionnaireAnswers>(
    key: K,
    value: QuestionnaireAnswers[K]
  ) => {
    setQuestionnaireAnswers((prev) => ({ ...prev, [key]: value }));
  };

  const questionnaireCanSubmit = () => {
    const a = questionnaireAnswers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    const unitBasedComplete = a.unitBased !== null;
    const insuranceDetailsComplete = valeterInsuranceDetailsComplete(
      a.hasBusinessInsurance,
      a.insuranceProvider,
      a.insuranceType,
      a.policyNumber
    );
    return yesNoComplete && unitBasedComplete && insuranceDetailsComplete;
  };

  const questionnaireCanAttemptContinue = () => {
    const a = questionnaireAnswers;
    const yesNoComplete =
      a.keepCustomers !== null && a.keepCalendarAvailability !== null && a.shareContactDetails !== null;
    if (!yesNoComplete || a.unitBased === null || a.hasBusinessInsurance === null) return false;
    if (a.hasBusinessInsurance === 'yes') {
      return valeterInsuranceDetailsComplete(
        a.hasBusinessInsurance,
        a.insuranceProvider,
        a.insuranceType,
        a.policyNumber
      );
    }
    return true;
  };

  const handleCompleteQuestionnaire = async () => {
    if (questionnaireAnswers.hasBusinessInsurance !== 'yes') {
      await hapticFeedback('medium');
      showValeterInsuranceRequiredAlert();
      return;
    }
    if (!questionnaireCanSubmit()) return;
    await hapticFeedback('medium');
    const questionnairePayload = {
      questionnaire_type: 'business_onboarding_questionnaire',
      account_mode: questionnaireAnswers.unitBased === 'unit' ? 'physical' : 'mobile_based',
      keepCustomers: questionnaireAnswers.keepCustomers,
      keepCalendarAvailability: questionnaireAnswers.keepCalendarAvailability,
      shareContactDetails: questionnaireAnswers.shareContactDetails,
      unitBased: questionnaireAnswers.unitBased,
      hasBusinessInsurance: questionnaireAnswers.hasBusinessInsurance,
      insuranceProvider: questionnaireAnswers.insuranceProvider,
      insuranceType: questionnaireAnswers.insuranceType,
      policyNumber: questionnaireAnswers.policyNumber,
    };
    if (user?.id) {
      await termsAgreementService.saveQuestionnaire('business', user.id, 'v1.0', questionnairePayload);
    }
    await AsyncStorage.setItem(QUESTIONNAIRE_STORAGE_KEY, 'true');
    await AsyncStorage.setItem(
      'business_onboarding_questionnaire_answers',
      JSON.stringify(questionnaireAnswers)
    );
    setQuestionnaireComplete(true);
    setQuestionnaireVisible(false);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      {/* Floating Header */}
      <AppHeader
        title="Welcome to Wish a Wash"
        showBack={false}
        rightAction={
          currentSlide < onboardingSlides.length - 1 ? (
            <TouchableOpacity
              onPress={handleSkip}
              style={styles.skipButton}
            >
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          ) : null
        }
        accountType="business"
      />

      <View style={styles.contentWrapper}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.slidesContainer}
        >
          {onboardingSlides.map((slide) => (
            <View key={slide.id} style={styles.slide}>
              <Animated.View style={[styles.slideContent, { opacity: fadeAnim }]}>
                <View style={styles.slideCard}>
                  <View style={styles.slideCardTopRow}>
                    <View style={styles.slidePill}>
                      <Ionicons name="sparkles-outline" size={14} color={SKY} />
                      <Text style={styles.slidePillText}>{`Slide ${slide.id} of ${onboardingSlides.length}`}</Text>
                    </View>
                    <View style={styles.slidePillAlt}>
                      <Text style={styles.slidePillAltText}>Business onboarding</Text>
                    </View>
                  </View>

                  <View style={styles.iconContainer}>
                    {slide.id === 1 ? (
                      <Image 
                        source={require('../../assets/icon.png')} 
                        style={styles.logoImage} 
                        resizeMode="contain" 
                      />
                    ) : (
                      <View style={styles.iconWrapper}>
                        <Ionicons name={slide.icon as any} size={64} color={slide.color} />
                      </View>
                    )}
                  </View>

                  <Text style={styles.slideTitle}>{slide.title}</Text>
                  <Text style={styles.slideDescription}>{slide.description}</Text>
                </View>

                {slide.id === 7 ? (
                  <TouchableOpacity
                    onPress={handleOpenQuestionnaire}
                    style={styles.questionnaireButton}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.questionnaireButtonText}>
                      Onboarding questionnaire
                    </Text>
                    <Ionicons name="create-outline" size={18} color={SKY} />
                  </TouchableOpacity>
                ) : null}
              </Animated.View>
            </View>
          ))}
        </ScrollView>

        {/* Pagination Dots */}
        <View style={styles.pagination}>
          {onboardingSlides.map((slide, index) => (
            <TouchableOpacity
              key={`pagination-${slide.id}`}
              onPress={() => goToSlide(index)}
              style={[
                styles.dot,
                currentSlide === index && styles.dotActive,
                { backgroundColor: currentSlide === index ? SKY : 'rgba(135,206,235,0.3)' },
              ]}
            />
          ))}
        </View>

        {/* Navigation Buttons */}
        <View style={[styles.navigation, { paddingBottom: insets.bottom + 20 }]}>
          {currentSlide > 0 && (
            <TouchableOpacity
              onPress={() => goToSlide(currentSlide - 1)}
              style={styles.backButton}
            >
              <GlassCard style={styles.navButtonCard}>
                <Ionicons name="chevron-back" size={24} color={SKY} />
              </GlassCard>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            onPress={handleNext}
            style={[
              styles.nextButton,
              currentSlide === 0 && styles.nextButtonFull,
              currentSlide === onboardingSlides.length - 1 && !questionnaireComplete && styles.nextButtonDisabled,
            ]}
            disabled={currentSlide === onboardingSlides.length - 1 && !questionnaireComplete}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.nextButtonGradient}
            >
              <Text style={styles.nextButtonText}>
                {onboardingNextButtonLabel(currentSlide === onboardingSlides.length - 1, questionnaireComplete)}
              </Text>
              <Ionicons
                name={onboardingNextButtonIcon(currentSlide === onboardingSlides.length - 1, questionnaireComplete)}
                size={20}
                color="#FFFFFF"
              />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>

      <Modal
        visible={questionnaireVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setQuestionnaireVisible(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setQuestionnaireVisible(false)} />
          <ScrollView contentContainerStyle={styles.modalScrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.modalCard}>
              <View style={styles.modalHandle} />
              <Text style={styles.modalTitle}>Terms and conditions</Text>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  Do you agree to keep all customers you gain from Wish a Washer on the Wish a Washer app?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('keepCustomers', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.keepCustomers === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.keepCustomers === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  It is your responsibility to keep your calendars availability up to date. Do you accept this responsibility?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('keepCalendarAvailability', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.keepCalendarAvailability === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.keepCalendarAvailability === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>
                  Do you agree to not share or promote your personal contact details to customers on the Wish a Washer app?
                </Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('shareContactDetails', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.shareContactDetails === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.shareContactDetails === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>Are you unit based? *</Text>
                <TouchableOpacity
                  onPress={() => updateQuestionnaire('unitBased', 'mobile_unit_based')}
                  style={styles.selectButton}
                  activeOpacity={0.9}
                >
                  <Text style={styles.selectButtonText}>
                    {unitBasedLabel(questionnaireAnswers.unitBased)}
                  </Text>
                  <Ionicons name="chevron-forward" size={20} color="rgba(34,34,34,0.45)" />
                </TouchableOpacity>
                <Text style={styles.helpText}>
                  Tap to keep the default selection for now. We can turn this into a picker later.
                </Text>
              </View>

              <View style={styles.questionBlock}>
                <Text style={styles.questionText}>Do you have business insurance? *</Text>
                <View style={styles.yesNoRow}>
                  {(['yes', 'no'] as YesNo[]).map((choice) => (
                    <TouchableOpacity
                      key={choice}
                      onPress={() => updateQuestionnaire('hasBusinessInsurance', choice)}
                      style={[
                        styles.choiceButton,
                        questionnaireAnswers.hasBusinessInsurance === choice && styles.choiceButtonActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.choiceButtonText,
                          questionnaireAnswers.hasBusinessInsurance === choice && styles.choiceButtonTextActive,
                        ]}
                      >
                        {choice === 'yes' ? 'Yes' : 'No'}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {questionnaireAnswers.hasBusinessInsurance === 'yes' ? (
                <>
                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>Who is your insurance provider? *</Text>
                    <TextInput
                      value={questionnaireAnswers.insuranceProvider}
                      onChangeText={(value) => updateQuestionnaire('insuranceProvider', value)}
                      placeholder="Insurance Provider"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>

                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>What type of insurance do you have? *</Text>
                    <TextInput
                      value={questionnaireAnswers.insuranceType}
                      onChangeText={(value) => updateQuestionnaire('insuranceType', value)}
                      placeholder="Insurance Type"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>

                  <View style={styles.questionBlock}>
                    <Text style={styles.questionText}>What is your insurance policy number? *</Text>
                    <TextInput
                      value={questionnaireAnswers.policyNumber}
                      onChangeText={(value) => updateQuestionnaire('policyNumber', value)}
                      placeholder="Policy Number"
                      placeholderTextColor="rgba(10,25,41,0.38)"
                      style={styles.textInput}
                    />
                  </View>
                </>
              ) : null}

              <Text style={styles.termsFootnote}>
                By signing up you have read and are agreeable to our
                {'\n'}
                <Text style={styles.termsFootnoteLink}>Terms of Service & Privacy Policy</Text>
              </Text>

              <TouchableOpacity
                onPress={handleCompleteQuestionnaire}
                style={[
                  styles.modalPrimaryButton,
                  !questionnaireCanAttemptContinue() && styles.modalPrimaryButtonDisabled,
                ]}
                activeOpacity={0.9}
                disabled={!questionnaireCanAttemptContinue()}
              >
                <Text style={styles.modalPrimaryButtonText}>Continue</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setQuestionnaireVisible(false)}
                style={styles.modalSecondaryButton}
                activeOpacity={0.85}
              >
                <Text style={styles.modalSecondaryButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  contentWrapper: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET, // AppHeader is already floating
  },
  skipButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  skipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slidesContainer: {
    flex: 1,
  },
  slide: {
    width,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  slideContent: {
    alignItems: 'center',
    maxWidth: 400,
    width: '100%',
  },
  slideCard: {
    width: '100%',
    borderRadius: 30,
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 20,
    backgroundColor: 'rgba(15,23,42,0.58)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    gap: 14,
  },
  slideCardTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
  },
  slidePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  slidePillText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
  slidePillAlt: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  slidePillAltText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  iconContainer: {
    marginBottom: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoImage: {
    width: 92,
    height: 92,
  },
  iconWrapper: {
    width: 88,
    height: 88,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: -0.3,
    lineHeight: 34,
  },
  slideDescription: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 17,
    textAlign: 'center',
    lineHeight: 26,
    paddingHorizontal: 10,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  dotActive: {
    width: 24,
    height: 8,
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 12,
  },
  backButton: {
    width: 50,
  },
  navButtonCard: {
    width: 50,
    height: 50,
    borderRadius: 25,
    padding: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  nextButtonFull: {
    marginLeft: 0,
  },
  nextButtonDisabled: {
    opacity: 0.45,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  questionnaireButton: {
    marginTop: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(8,24,43,0.45)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  questionnaireButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(2, 6, 23, 0.82)',
    justifyContent: 'flex-end',
  },
  modalScrollContent: {
    paddingTop: 80,
  },
  modalCard: {
    backgroundColor: 'rgba(10, 18, 32, 0.98)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 24,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  modalHandle: {
    alignSelf: 'center',
    width: 42,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.18)',
    marginBottom: 14,
  },
  modalTitle: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 8,
  },
  modalBody: {
    color: 'rgba(248,250,252,0.68)',
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 16,
  },
  modalPlaceholderList: {
    gap: 10,
    marginBottom: 18,
  },
  modalPlaceholderItem: {
    color: '#D6EFFF',
    fontSize: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  questionBlock: {
    marginBottom: 18,
  },
  questionText: {
    color: '#F8FAFC',
    fontSize: 18,
    lineHeight: 26,
    fontWeight: '600',
    marginBottom: 14,
  },
  yesNoRow: {
    flexDirection: 'row',
    gap: 12,
  },
  choiceButton: {
    flex: 1,
    minHeight: 58,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  choiceButtonActive: {
    backgroundColor: 'rgba(16,185,129,0.92)',
    borderColor: 'rgba(16,185,129,1)',
  },
  choiceButtonText: {
    color: '#E2E8F0',
    fontSize: 18,
    fontWeight: '500',
  },
  choiceButtonTextActive: {
    color: '#08131F',
    fontWeight: '600',
  },
  selectButton: {
    minHeight: 60,
    borderRadius: 16,
    paddingHorizontal: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectButtonText: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '500',
  },
  helpText: {
    marginTop: 10,
    color: 'rgba(248,250,252,0.6)',
    fontSize: 12,
    lineHeight: 18,
  },
  textInput: {
    minHeight: 60,
    borderRadius: 16,
    paddingHorizontal: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    color: '#F8FAFC',
    fontSize: 18,
  },
  termsFootnote: {
    marginTop: 2,
    marginBottom: 18,
    color: 'rgba(248,250,252,0.68)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  termsFootnoteLink: {
    color: '#FDB022',
    fontWeight: '600',
  },
  modalPrimaryButton: {
    minHeight: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FDE047',
    marginBottom: 10,
  },
  modalPrimaryButtonDisabled: {
    backgroundColor: 'rgba(253,224,71,0.42)',
  },
  modalPrimaryButtonText: {
    color: '#111827',
    fontSize: 15,
    fontWeight: '800',
  },
  modalSecondaryButton: {
    minHeight: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  modalSecondaryButtonText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
  },
});
