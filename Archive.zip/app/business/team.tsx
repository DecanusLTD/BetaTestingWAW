import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  TextInput,
  Alert,
  ScrollView,
  RefreshControl,
  ActionSheetIOS,
  Platform,
  Modal,
  Pressable,
  Animated,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useRouter, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import StatusDot from '../../src/components/shared/StatusDot';
import InviteWasherSheet from '../../src/components/business/InviteWasherSheet';
import { colors } from '../../src/constants/colors';
import { DARK_MAP_STYLE } from '../../src/constants/mapStyles';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../src/components/LoadingScreen';
import EmptyState from '../../src/components/shared/EmptyState';
import BusinessSheetBackground from '../../src/components/shared/BusinessSheetBackground';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';

/** Must match `sheetShell.paddingHorizontal` so cards sit inside the roster strip (no horizontal clip). */
const SHEET_HORIZONTAL_PAD = 20;
const CARD_WIDTH = width - SHEET_HORIZONTAL_PAD * 2;
/** Space between peeking cards in the horizontal roster */
const CARD_GAP = 12;
const HEADER_MARGIN_H = 20;
const HEADER_RADIUS = 24;
const SEARCH_CARD_HEIGHT = 56;
const SEARCH_HEADER_GAP = 12;
const MAP_SIDE_RAIL_WIDTH = 52;

type TabFilter = 'all' | 'online' | 'pending';

interface Valeter {
  id: string;
  name: string;
  email: string;
  phone?: string;
  photoUrl?: string | null;
  is_online: boolean;
  total_jobs?: number;
  rating?: number;
  location_assignment?: string;
  role?: string;
  clocked_in?: boolean;
  created_at: string;
  /** mobile = fleet; location = tied to assigned_location_id */
  valeter_work_mode?: 'mobile' | 'location';
  assigned_location_id?: string | null;
}

type ProfileRow = {
  id: string;
  name: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  created_at: string | null;
  user_type: string | null;
  organization_id: string | null;
  avatar_url?: string | null;
  profile_picture?: string | null;
  valeter_work_mode?: string | null;
  assigned_location_id?: string | null;
};

type PresenceRow = {
  user_id: string;
  is_online: boolean | null;
};

type BookingStatRow = {
  id: string;
  rating: number | null;
};

function offsetFromCenter(lat: number, lng: number, index: number, total: number) {
  const t = Math.max(total, 1);
  const angle = (index / t) * Math.PI * 2;
  const r = 0.0042;
  return {
    latitude: lat + Math.sin(angle) * r * 0.85,
    longitude: lng + Math.cos(angle) * r * 0.85,
  };
}

export default function BusinessTeam() { // NOSONAR - Screen orchestrates map, filters, modals and team actions in one container
  const { user } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ invite?: string | string[] }>();
  const { theme: businessTheme, mode } = useAccountTheme();
  const primaryColor = businessTheme.primary || SKY;
  const headerBackground =
    businessTheme.headerBackground || businessTheme.background || ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];
  const headerAccent = businessTheme.primary || colors.navActive;

  const sheetHeight = useMemo(() => {
    const bottomPad = Math.max(12, insets.bottom);
    const handleAndHeader = 8 + 8 + 4 + 6 + 84;
    const dotsRow = 32;
    const minCardViewport = 168;
    const needed = bottomPad + handleAndHeader + dotsRow + minCardViewport;
    return Math.min(height * 0.58, Math.max(height * 0.42, needed));
  }, [insets.bottom]);

  const mapRef = useRef<MapView>(null);
  const cardScrollRef = useRef<ScrollView>(null);
  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<TabFilter>('all');
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 51.5074, lng: -0.1278 });
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.08,
    longitudeDelta: 0.08,
  });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [detailMember, setDetailMember] = useState<Valeter | null>(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [mapToolsOpen, setMapToolsOpen] = useState(false);
  const mapToolsAnim = useRef(new Animated.Value(0)).current;
  const [orgDisplayName, setOrgDisplayName] = useState('');
  const [orgLocations, setOrgLocations] = useState<{ id: string; name: string }[]>([]);
  const [savingAssignment, setSavingAssignment] = useState(false);
  const [assignmentLocPicker, setAssignmentLocPicker] = useState(false);
  const [draftWorkMode, setDraftWorkMode] = useState<'mobile' | 'location'>('mobile');
  const [draftLocationId, setDraftLocationId] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    if (isOrgUser && organizationId) {
      void loadMapCenter();
      loadValeters();
    } else {
      setValeters([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [activeTab, searchQuery]);

  useEffect(() => {
    const raw = params?.invite;
    let v: string | undefined;
    if (typeof raw === 'string') {
      v = raw;
    } else if (Array.isArray(raw)) {
      v = raw[0];
    }
    if (v === '1' || v === 'true') {
      setInviteOpen(true);
    }
  }, [params?.invite]);

  useEffect(() => {
    Animated.spring(mapToolsAnim, {
      toValue: mapToolsOpen ? 1 : 0,
      useNativeDriver: true,
      friction: 9,
      tension: 78,
    }).start();
  }, [mapToolsOpen, mapToolsAnim]);

  useEffect(() => {
    if (!organizationId) {
      setOrgDisplayName('');
      return;
    }
    let cancelled = false;
    (async () => {
      const { data } = await supabase.from('organizations').select('name').eq('id', organizationId).maybeSingle();
      if (!cancelled && data?.name != null) {
        const n = String(data.name).trim();
        if (n) setOrgDisplayName(n);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [organizationId]);

  useEffect(() => {
    if (!organizationId) {
      setOrgLocations([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name')
        .eq('organization_id', organizationId)
        .order('name', { ascending: true });
      if (error) {
        console.warn('[Team] car_wash_locations:', error.message || error);
      }
      if (!cancelled) {
        setOrgLocations(
          (data || []).map((r: { id: string; name?: string | null }) => ({
            id: r.id,
            name: (r.name ?? '').trim() || 'Location',
          }))
        );
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [organizationId]);

  const locationNameById = useMemo(() => {
    const m = new Map<string, string>();
    orgLocations.forEach((l) => m.set(l.id, l.name));
    return m;
  }, [orgLocations]);

  const loadMapCenter = async () => {
    if (!organizationId) return;
    try {
      const { data } = await supabase
        .from('car_wash_locations')
        .select('latitude, longitude')
        .eq('organization_id', organizationId)
        .not('latitude', 'is', null)
        .not('longitude', 'is', null);
      const rows = (data || []).filter((l: any) => l.latitude != null && l.longitude != null);
      if (rows.length) {
        const lat = rows.reduce((a: number, l: any) => a + Number(l.latitude), 0) / rows.length;
        const lng = rows.reduce((a: number, l: any) => a + Number(l.longitude), 0) / rows.length;
        setMapCenter({ lat, lng });
        const next: Region = { latitude: lat, longitude: lng, latitudeDelta: 0.07, longitudeDelta: 0.07 };
        setRegion(next);
        mapRef.current?.animateToRegion(next, 400);
      }
    } catch (e) {
      console.warn('[Team] map center', e);
    }
  };

  const normalizeName = (v: ProfileRow) =>
    (v.full_name ?? '').trim() || (v.name ?? '').trim() || 'Car Care Pro';

  const normalizeEmail = (v: ProfileRow) => (v.email ?? '').trim() || 'no-email@unknown';

  const mapProfileToValeter = async (
    v: ProfileRow,
    vpPhotoByUserId: Map<string, string | null> | undefined
  ): Promise<Valeter> => {
    const displayName = normalizeName(v);
    const email = normalizeEmail(v);
    const vpMap = vpPhotoByUserId instanceof Map ? vpPhotoByUserId : new Map<string, string | null>();
    const vpExtra = vpMap.get(v.id);
    const photoUrl =
      [v.avatar_url, v.profile_picture, vpExtra].find((x) => typeof x === 'string' && x.trim().length > 0)?.trim() ??
      null;

    const { data: presenceData } = await supabase
      .from('valeter_presence')
      .select('user_id, is_online')
      .eq('user_id', v.id)
      .maybeSingle();

    const presence = (presenceData as PresenceRow | null) ?? null;

    const { data: statsData } = await supabase
      .from('bookings')
      .select('id, rating')
      .eq('valeter_id', v.id)
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(50);

    const stats = (statsData || []) as BookingStatRow[];
    const totalJobs = stats.length;
    const avgRating =
      totalJobs > 0 ? stats.reduce((acc, s) => acc + (s.rating || 0), 0) / totalJobs : 0;

    const modeRaw = (v.valeter_work_mode ?? 'mobile').toLowerCase();
    const valeter_work_mode: 'mobile' | 'location' = modeRaw === 'location' ? 'location' : 'mobile';
    const assigned_location_id =
      typeof v.assigned_location_id === 'string' && v.assigned_location_id.length > 0
        ? v.assigned_location_id
        : null;

    return {
      id: v.id,
      name: displayName,
      email,
      phone: (v.phone ?? '').trim() || undefined,
      photoUrl,
      created_at: v.created_at ?? new Date().toISOString(),
      is_online: !!presence?.is_online,
      total_jobs: totalJobs,
      rating: avgRating,
      location_assignment:
        valeter_work_mode === 'location' && assigned_location_id
          ? assigned_location_id
          : undefined,
      role: 'valeter',
      clocked_in: false,
      valeter_work_mode,
      assigned_location_id,
    };
  };

  const loadValeters = useCallback(
    async (isRefresh = false) => {
      if (!isOrgUser || !organizationId) return;

      try {
        if (isRefresh) {
          setLoading(false);
        } else {
          setLoading(true);
        }

        let data: ProfileRow[] | null = null;
        let error: any = null;

        const PROFILE_SELECT_WITH_PIC =
          'id, name, full_name, email, phone, created_at, user_type, organization_id, profile_picture';
        const PROFILE_SELECT_BASE =
          'id, name, full_name, email, phone, created_at, user_type, organization_id';
        const PROFILE_SELECT_TEAM =
          'id, name, full_name, email, phone, created_at, user_type, organization_id, profile_picture, valeter_work_mode, assigned_location_id';

        const fetchRows = async (columns: string) => {
          const { data: d1, error: e1 } = await supabase
            .from('profiles')
            .select(columns)
            .eq('organization_id', organizationId)
            .or('user_type.eq.valeter,user_type.ilike.valeter%')
            .order('created_at', { ascending: false });

          if (e1?.code === '42703') {
            return { rows: null as ProfileRow[] | null, err: e1 };
          }
          if (!e1 && d1?.length) {
            return { rows: d1 as unknown as ProfileRow[], err: null as any };
          }
          const { data: d2, error: e2 } = await supabase
            .from('profiles')
            .select(columns)
            .eq('organization_id', organizationId)
            .eq('user_type', 'valeter')
            .order('created_at', { ascending: false });
          return { rows: (d2 || []) as unknown as ProfileRow[], err: e2 || e1 };
        };

        let cols = PROFILE_SELECT_TEAM;
        ({ rows: data, err: error } = await fetchRows(cols));
        if (error?.code === '42703') {
          cols = PROFILE_SELECT_WITH_PIC;
          ({ rows: data, err: error } = await fetchRows(cols));
        }
        if (error?.code === '42703') {
          cols = PROFILE_SELECT_BASE;
          ({ rows: data, err: error } = await fetchRows(cols));
        }

        if (error) throw error;

        const rows = data || [];
        const vpPhotoByUserId = new Map<string, string | null>();
        const ids = rows.map((r) => r.id);
        if (ids.length > 0) {
          const { data: vpRows } = await supabase
            .from('valeter_profiles')
            .select('user_id, profile_photo_url')
            .in('user_id', ids);
          for (const row of vpRows || []) {
            const r = row as { user_id?: string; profile_photo_url?: string | null };
            if (r.user_id) vpPhotoByUserId.set(r.user_id, r.profile_photo_url ?? null);
          }
        }

        const valeterData: Valeter[] = await Promise.all(rows.map((r) => mapProfileToValeter(r, vpPhotoByUserId)));
        setValeters(valeterData);
      } catch (error) {
        console.error('Error loading valeters:', error);
        Alert.alert('Couldn’t load team', 'Pull down to try again.');
      } finally {
        setLoading(false);
      }
    },
    [isOrgUser, organizationId]
  );

  const removeValeterFromOrg = async (valeter: Valeter) => {
    if (!organizationId) return;

    Alert.alert(
      'Remove from team?',
      `${valeter.name}\nThis will unassign them from your business.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                setRemovingId(valeter.id);
                await hapticFeedback('light');

                const { error } = await supabase
                  .from('profiles')
                  .update({ organization_id: null })
                  .eq('id', valeter.id);

                if (error) throw error;

                await hapticFeedback('success');
                setDetailMember(null);
                await loadValeters();
              } catch (e) {
                console.error('Error removing valeter:', e);
                await hapticFeedback('error');
                Alert.alert('Could not remove', 'Something went wrong. Please try again.');
              } finally {
                setRemovingId(null);
              }
            })();
          },
        },
      ],
      { cancelable: true }
    );
  };

  const filteredValeters = useMemo(() => {
    return valeters.filter((valeter) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q || valeter.name.toLowerCase().includes(q) || valeter.email.toLowerCase().includes(q);
      if (!matchesSearch) return false;
      if (activeTab === 'online') return valeter.is_online;
      if (activeTab === 'pending') return false;
      return true;
    });
  }, [valeters, searchQuery, activeTab]);
  const hasSearchQuery = searchQuery.trim().length > 0;
  let emptyStateTitle = 'No team yet';
  if (hasSearchQuery) {
    emptyStateTitle = 'No matches';
  } else if (activeTab === 'online') {
    emptyStateTitle = 'No one online';
  }
  const emptyStateSubtitle = hasSearchQuery ? 'Try another search' : 'Invite car care pros to populate the map';
  const emptyStateActionLabel = hasSearchQuery ? undefined : 'Invite';

  const onlineCount = valeters.filter((v) => v.is_online).length;

  const valeterCoords = useMemo(() => {
    const n = filteredValeters.length;
    return filteredValeters.map((v, i) => ({
      valeter: v,
      ...offsetFromCenter(mapCenter.lat, mapCenter.lng, i, Math.max(n, 1)),
    }));
  }, [filteredValeters, mapCenter]);

  useEffect(() => {
    if (filteredValeters.length === 0) return;
    if (selectedIndex >= filteredValeters.length) {
      setSelectedIndex(0);
    }
  }, [filteredValeters.length, selectedIndex]);

  useEffect(() => {
    if (filteredValeters.length === 0) return;
    const i = Math.min(selectedIndex, filteredValeters.length - 1);
    const coord = offsetFromCenter(mapCenter.lat, mapCenter.lng, i, filteredValeters.length);
    const next: Region = {
      latitude: coord.latitude,
      longitude: coord.longitude,
      latitudeDelta: 0.035,
      longitudeDelta: 0.035,
    };
    setRegion(next);
    mapRef.current?.animateToRegion(next, 350);
  }, [selectedIndex, filteredValeters.length, mapCenter.lat, mapCenter.lng]);

  useEffect(() => {
    if (!cardScrollRef.current || filteredValeters.length === 0) return;
    const x = selectedIndex * (CARD_WIDTH + CARD_GAP);
    cardScrollRef.current.scrollTo({ x, animated: true });
  }, [selectedIndex, filteredValeters.length]);

  const onCardScroll = (e: any) => {
    const x = e.nativeEvent.contentOffset.x;
    const idx = Math.round(x / (CARD_WIDTH + CARD_GAP));
    if (idx >= 0 && idx < filteredValeters.length && idx !== selectedIndex) {
      setSelectedIndex(idx);
    }
  };

  const openInvite = async () => {
    await hapticFeedback('light');
    setInviteOpen(true);
  };
  const emptyStateAction = hasSearchQuery ? undefined : openInvite;

  const openWasherChat = async (v: Valeter) => {
    await hapticFeedback('light');
    router.push({
      pathname: '/business/team/chat',
      params: {
        valeterId: v.id,
        valeterName: v.name ?? '',
        ...(v.phone ? { phone: String(v.phone) } : {}),
      },
    } as any);
  };

  useEffect(() => {
    if (!detailMember) return;
    setDraftWorkMode(detailMember.valeter_work_mode === 'location' ? 'location' : 'mobile');
    setDraftLocationId(detailMember.assigned_location_id ?? null);
  }, [detailMember?.id]);

  const saveValeterAssignment = async () => {
    if (!detailMember || !organizationId) return;
    if (draftWorkMode === 'location' && !draftLocationId) {
      Alert.alert('Choose a location', 'Pick which site this car care pro is assigned to, or switch to Mobile fleet.');
      return;
    }
    try {
      setSavingAssignment(true);
      await hapticFeedback('medium');
      const { error } = await supabase
        .from('profiles')
        .update({
          valeter_work_mode: draftWorkMode,
          assigned_location_id: draftWorkMode === 'location' ? draftLocationId : null,
        })
        .eq('id', detailMember.id)
        .eq('organization_id', organizationId);
      if (error) {
        if (error.code === '42703') {
          Alert.alert(
            'Database update',
            'Add car care pro assignment columns in Supabase. Open docs/SUPABASE_LOCATION_VALETER_FIELDS.sql and run the SQL there.'
          );
        } else {
          Alert.alert('Could not save', error.message || 'Try again.');
        }
        return;
      }
      await hapticFeedback('success');
      setDetailMember({
        ...detailMember,
        valeter_work_mode: draftWorkMode,
        assigned_location_id: draftWorkMode === 'location' ? draftLocationId : null,
        location_assignment: draftWorkMode === 'location' ? draftLocationId ?? undefined : undefined,
      });
      await loadValeters(true);
      Alert.alert('Saved', 'Work assignment updated.');
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to save assignment');
    } finally {
      setSavingAssignment(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading team…" />;
  }

  if (!isOrgUser || !organizationId) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.safeContent} edges={['top', 'bottom']}>
          <AppHeader title="Team" accountType="business" />
          <View style={styles.emptyStateWrap}>
            <Ionicons name="alert-circle-outline" size={48} color={primaryColor} style={{ opacity: 0.9 }} />
            <Text style={styles.emptyStateTitle}>Not linked to an organization</Text>
            <Text style={styles.emptyStateSubtitle}>
              This business account isn’t linked to an organization yet.{'\n'}Log out and back in, or contact support.
            </Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <SafeAreaView style={styles.safeContent} edges={['top', 'bottom']}>
        <View style={styles.teamPageShell}>
          <View style={styles.teamHeaderRow}>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setShowMapModal(true);
              }}
              style={styles.headerIconBtn}
              activeOpacity={0.85}
              accessibilityLabel="Open map"
            >
              <Ionicons name="map-outline" size={22} color={primaryColor} />
            </TouchableOpacity>
            <View style={styles.teamSearchBar}>
              <Ionicons name="search" size={18} color={MUTED_TEXT} />
              <TextInput
                style={styles.searchHeaderInput}
                placeholder="Search name or email"
                placeholderTextColor="rgba(249,250,251,0.42)"
                value={searchQuery}
                onChangeText={setSearchQuery}
                returnKeyType="search"
                autoCorrect={false}
                autoCapitalize="none"
                {...(Platform.OS === 'ios' ? { clearButtonMode: 'while-editing' as const } : {})}
              />
              {searchQuery.length > 0 ? (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setSearchQuery('');
                  }}
                  style={styles.teamSearchClearBtn}
                  activeOpacity={0.75}
                  accessibilityLabel="Clear search"
                >
                  <Ionicons name="close-circle" size={18} color="rgba(249,250,251,0.52)" />
                </TouchableOpacity>
              ) : null}
            </View>
            <TouchableOpacity onPress={openInvite} style={styles.headerInviteBtn} activeOpacity={0.85}>
              <Ionicons name="person-add" size={22} color={primaryColor} />
            </TouchableOpacity>
          </View>

          <View style={styles.teamListHeader}>
            <View style={styles.teamListHeaderText}>
              <Text style={styles.teamKicker}>LIVE ROSTER</Text>
              <Text style={styles.teamListTitle}>Field team</Text>
              <Text style={styles.teamListSub}>Manage the roster here, open the map when you need it.</Text>
            </View>
            <View style={styles.teamFilterChips}>
              {(['all', 'online', 'pending'] as TabFilter[]).map((tab) => (
                <TouchableOpacity
                  key={tab}
                  style={[styles.teamChip, activeTab === tab && styles.teamChipActive]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setActiveTab(tab);
                  }}
                  activeOpacity={0.85}
                >
                  <Text style={[styles.teamChipText, activeTab === tab && styles.teamChipTextActive]}>
                    {tab === 'all' ? 'All' : tab === 'online' ? 'Online' : 'Pending'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <ScrollView
            style={styles.teamListScroll}
            contentContainerStyle={[styles.teamListScrollContent, { paddingBottom: Math.max(insets.bottom, 24) + TAB_BAR_TOTAL_HEIGHT + 20 }]}
            showsVerticalScrollIndicator={false}
            refreshControl={<RefreshControl refreshing={false} onRefresh={() => void loadValeters(true)} tintColor={SKY} />}
          >
            {filteredValeters.length === 0 ? (
              <View style={styles.emptyListWrap}>
                <EmptyState
                  icon="people-outline"
                  title={emptyStateTitle}
                  subtitle={emptyStateSubtitle}
                  actionLabel={emptyStateActionLabel}
                  onAction={emptyStateAction}
                  iconColor={primaryColor}
                />
              </View>
            ) : (
              <View style={styles.teamListCards}>
                {filteredValeters.map((v, i) => {
                  const glass = businessTheme.glassBorder ?? 'rgba(125,211,252,0.28)';
                  let rosterStatusLabel = 'Offline';
                  let rosterDotStatus: 'available' | 'busy' | 'offline' = 'offline';
                  if (v.is_online) {
                    rosterStatusLabel = 'Available';
                    rosterDotStatus = 'available';
                  } else if (v.clocked_in) {
                    rosterStatusLabel = 'On a job';
                    rosterDotStatus = 'busy';
                  }
                  return (
                    <View key={v.id} style={styles.teamListCardWrap}>
                      <View
                        style={[
                          styles.hCardOuter,
                          { borderColor: glass },
                        ]}
                      >
                        <LinearGradient
                          colors={[`${headerBackground[0]}E8`, `${headerBackground[1] || headerBackground[0]}D0`]}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 0, y: 1 }}
                          style={StyleSheet.absoluteFill}
                        />
                        <LinearGradient
                          colors={[`${headerAccent}30`, 'transparent']}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 0, y: 1 }}
                          style={StyleSheet.absoluteFill}
                          pointerEvents="none"
                        />
                        <View style={[styles.hCardGlassStroke, { borderColor: glass }]} />
                        <View style={[styles.hCardGlowLine, { backgroundColor: `${primaryColor}70`, shadowColor: primaryColor }]} />
                        <View style={styles.hCardInner}>
                          <Pressable
                            onPress={async () => {
                              await hapticFeedback('light');
                              setSelectedIndex(i);
                              setDetailMember(v);
                            }}
                            style={({ pressed }) => [styles.hCardPressableBody, pressed && { opacity: 0.94 }]}
                          >
                            <View style={styles.hCardMainBlock}>
                              <View style={styles.hCardHeroRow}>
                                <View style={styles.hCardAvatarCol}>
                                  <View
                                    style={[
                                      styles.hCardAvatarRing,
                                      { borderColor: primaryColor },
                                    ]}
                                  >
                                    {v.photoUrl ? (
                                      <Image source={{ uri: v.photoUrl }} style={styles.hCardAvatar} resizeMode="cover" />
                                    ) : (
                                      <LinearGradient
                                        colors={[primaryColor, businessTheme.primaryAlt || SKY]}
                                        style={styles.hCardAvatar}
                                      >
                                        <Text style={styles.hCardAvatarLetter}>{v.name.trim().slice(0, 1).toUpperCase()}</Text>
                                      </LinearGradient>
                                    )}
                                  </View>
                                  <View style={[styles.hCardRankBadge, { borderColor: glass }]}>
                                    <Text style={styles.hCardRankText}>#{String(i + 1).padStart(2, '0')}</Text>
                                  </View>
                                </View>
                                <View style={styles.hCardTitleBlock}>
                                  <View style={styles.hCardNameStatusRow}>
                                    <Text style={styles.hCardName} numberOfLines={1}>{v.name}</Text>
                                    {v.is_online ? (
                                      <View style={styles.hCardOnlinePill}>
                                        <View style={styles.onlineDot} />
                                        <Text style={styles.onlineTagText}>LIVE</Text>
                                      </View>
                                    ) : (
                                      <View style={styles.hCardOfflinePill}>
                                        <Text style={styles.offlineTag}>Away</Text>
                                      </View>
                                    )}
                                  </View>
                                  {orgDisplayName ? (
                                    <View style={styles.hCardBizRow}>
                                      <Ionicons name="business" size={12} color={primaryColor} />
                                      <Text style={styles.hCardBizName} numberOfLines={1}>{orgDisplayName}</Text>
                                    </View>
                                  ) : null}
                                  <Text style={styles.hCardEmail} numberOfLines={1}>{v.email}</Text>
                                </View>
                              </View>
                              <View style={[styles.hCardAssignChip, { borderColor: glass }]}>
                                <Ionicons
                                  name={v.valeter_work_mode === 'location' ? 'business' : 'car-outline'}
                                  size={13}
                                  color={primaryColor}
                                />
                                <Text style={styles.hCardAssignText} numberOfLines={1}>
                                  {v.valeter_work_mode === 'location' && v.assigned_location_id
                                    ? locationNameById.get(v.assigned_location_id) ?? 'Assigned site'
                                    : 'Mobile fleet'}
                                </Text>
                              </View>
                            </View>
                            <View style={styles.hCardBodyFlexFill} />
                          </Pressable>
                          <View style={styles.hCardFooter}>
                            <View style={styles.hCardFooterTop}>
                              <StatusDot status={rosterDotStatus} size={9} pulseOnChange />
                              <Text style={styles.hCardFooterStatusLabel} numberOfLines={1}>{rosterStatusLabel}</Text>
                            </View>
                            <View style={styles.hCardFooterActions}>
                              <TouchableOpacity
                                onPress={() => void openWasherChat(v)}
                                activeOpacity={0.85}
                                style={[styles.hCardActionBtn, styles.hCardActionBtnPrimary, { borderColor: primaryColor }]}
                              >
                                <LinearGradient
                                  colors={[`${primaryColor}38`, `${primaryColor}14`]}
                                  start={{ x: 0, y: 0 }}
                                  end={{ x: 1, y: 1 }}
                                  style={StyleSheet.absoluteFill}
                                />
                                <Ionicons name="chatbubble-ellipses-outline" size={15} color={primaryColor} />
                                <Text style={[styles.hCardActionBtnText, { color: primaryColor }]} numberOfLines={1}>
                                  Message
                                </Text>
                              </TouchableOpacity>
                              <TouchableOpacity
                                onPress={async () => {
                                  await hapticFeedback('light');
                                  setSelectedIndex(i);
                                  setDetailMember(v);
                                }}
                                activeOpacity={0.85}
                                style={[styles.hCardActionBtn, styles.hCardActionBtnGhost, { borderColor: glass }]}
                              >
                                <Text style={styles.hCardTap} numberOfLines={1}>Details</Text>
                                <Ionicons name="chevron-forward" size={15} color={primaryColor} />
                              </TouchableOpacity>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </ScrollView>
        </View>
      </SafeAreaView>

      <Modal
        visible={showMapModal}
        animationType="fade"
        transparent={false}
        onRequestClose={() => setShowMapModal(false)}
      >
        <View style={styles.teamMapModalRoot}>
          <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
          <BubbleBackground accountType="business" />
          <View style={[styles.teamMapHeader, { paddingTop: insets.top + 16 }]}>
            <View>
              <Text style={styles.teamMapTitle}>Team map</Text>
              <Text style={styles.teamMapSubtitle}>See every car care pro on the map</Text>
            </View>
            <Pressable onPress={() => setShowMapModal(false)} style={({ pressed }) => [styles.teamMapClose, pressed && { opacity: 0.85 }]} hitSlop={12}>
              <Ionicons name="close" size={22} color="#F9FAFB" />
            </Pressable>
          </View>
          <MapView
            ref={mapRef}
            style={StyleSheet.absoluteFill}
            region={region}
            provider={Platform.OS === 'ios' ? PROVIDER_DEFAULT : undefined}
            customMapStyle={DARK_MAP_STYLE}
            showsUserLocation={false}
            showsMyLocationButton={false}
            mapPadding={{ top: insets.top + 110, bottom: Math.max(20, insets.bottom + 20), left: 0, right: 0 }}
          >
            {valeterCoords.map((vc, i) => {
              const sel = i === selectedIndex;
              return (
                <Marker
                  key={vc.valeter.id}
                  coordinate={{ latitude: vc.latitude, longitude: vc.longitude }}
                  anchor={{ x: 0.5, y: 0.5 }}
                  onPress={() => {
                    setSelectedIndex(i);
                    hapticFeedback('light');
                  }}
                >
                  <View style={[styles.mapMarkerWrap, sel && styles.mapMarkerWrapSelected]}>
                    <View style={[styles.mapMarkerGlow, sel && { backgroundColor: `${primaryColor}44` }]} />
                    <LinearGradient
                      colors={sel ? [primaryColor, businessTheme.primaryAlt || SKY] : ['#1e293b', '#334155']}
                      style={styles.mapMarkerCore}
                    >
                      {vc.valeter.photoUrl ? (
                        <Image source={{ uri: vc.valeter.photoUrl }} style={styles.mapMarkerAvatar} resizeMode="cover" />
                      ) : (
                        <Ionicons name="person" size={20} color={sel ? '#0f172a' : SKY} />
                      )}
                    </LinearGradient>
                    {vc.valeter.is_online && <View style={styles.mapMarkerPulse} />}
                  </View>
                </Marker>
              );
            })}
          </MapView>

          <View style={[styles.bottomArea, { height: sheetHeight }]}>
            <View style={styles.sheetShell}>
              <View style={styles.sheetHandle} />
              <View style={styles.sheetHeadRow}>
                <View style={styles.sheetHeadTextCol}>
                  <Text style={styles.sheetKicker}>TEAM ROSTER</Text>
                  <Text style={styles.sheetTitle}>Swipe the cards</Text>
                  <Text style={styles.sheetSub}>Tap a card for details or message the team member.</Text>
                </View>
              </View>

              {filteredValeters.length === 0 ? (
                <View style={styles.emptySheetBody}>
                  <EmptyState
                    icon="people-outline"
                    title={emptyStateTitle}
                    subtitle={emptyStateSubtitle}
                    actionLabel={emptyStateActionLabel}
                    onAction={emptyStateAction}
                    iconColor={primaryColor}
                  />
                </View>
              ) : (
                <>
                  <ScrollView
                    ref={cardScrollRef}
                    horizontal
                    style={styles.hCardScroll}
                    showsHorizontalScrollIndicator={false}
                    decelerationRate="fast"
                    snapToInterval={CARD_WIDTH + CARD_GAP}
                    snapToAlignment="start"
                    contentContainerStyle={[
                      styles.hScrollContent,
                      { paddingLeft: SHEET_HORIZONTAL_PAD, paddingRight: SHEET_HORIZONTAL_PAD },
                    ]}
                    onMomentumScrollEnd={onCardScroll}
                  >
                    {filteredValeters.map((v, i) => {
                      const glass = businessTheme.glassBorder ?? 'rgba(125,211,252,0.28)';
                      let rosterStatusLabel = 'Offline';
                      let rosterDotStatus: 'available' | 'busy' | 'offline' = 'offline';
                      if (v.is_online) {
                        rosterStatusLabel = 'Available';
                        rosterDotStatus = 'available';
                      } else if (v.clocked_in) {
                        rosterStatusLabel = 'On a job';
                        rosterDotStatus = 'busy';
                      }
                      return (
                        <View key={v.id} style={[styles.hCardWrap, { width: CARD_WIDTH, height: '100%' }]}>
                          <View style={[styles.hCardOuter, { borderColor: glass }]}>
                            <LinearGradient
                              colors={[`${headerBackground[0]}E8`, `${headerBackground[1] || headerBackground[0]}D0`]}
                              start={{ x: 0, y: 0 }}
                              end={{ x: 0, y: 1 }}
                              style={StyleSheet.absoluteFill}
                            />
                            <LinearGradient
                              colors={[`${headerAccent}30`, 'transparent']}
                              start={{ x: 0, y: 0 }}
                              end={{ x: 0, y: 1 }}
                              style={StyleSheet.absoluteFill}
                              pointerEvents="none"
                            />
                            <View style={[styles.hCardGlassStroke, { borderColor: glass }]} />
                            <View style={[styles.hCardGlowLine, { backgroundColor: `${primaryColor}70`, shadowColor: primaryColor }]} />
                            <View style={styles.hCardInner}>
                              <Pressable
                                onPress={async () => {
                                  await hapticFeedback('light');
                                  setSelectedIndex(i);
                                  setDetailMember(v);
                                }}
                                style={({ pressed }) => [styles.hCardPressableBody, pressed && { opacity: 0.94 }]}
                              >
                                <View style={styles.hCardMainBlock}>
                                  <View style={styles.hCardHeroRow}>
                                    <View style={styles.hCardAvatarCol}>
                                      <View style={[styles.hCardAvatarRing, { borderColor: primaryColor }]}>
                                        {v.photoUrl ? (
                                          <Image source={{ uri: v.photoUrl }} style={styles.hCardAvatar} resizeMode="cover" />
                                        ) : (
                                          <LinearGradient
                                            colors={[primaryColor, businessTheme.primaryAlt || SKY]}
                                            style={styles.hCardAvatar}
                                          >
                                            <Text style={styles.hCardAvatarLetter}>
                                              {v.name.trim().slice(0, 1).toUpperCase()}
                                            </Text>
                                          </LinearGradient>
                                        )}
                                      </View>
                                      <View style={[styles.hCardRankBadge, { borderColor: glass }]}>
                                        <Text style={styles.hCardRankText}>#{String(i + 1).padStart(2, '0')}</Text>
                                      </View>
                                    </View>
                                    <View style={styles.hCardTitleBlock}>
                                      <View style={styles.hCardNameStatusRow}>
                                        <Text style={styles.hCardName} numberOfLines={1}>
                                          {v.name}
                                        </Text>
                                        {v.is_online ? (
                                          <View style={styles.hCardOnlinePill}>
                                            <View style={styles.onlineDot} />
                                            <Text style={styles.onlineTagText}>LIVE</Text>
                                          </View>
                                        ) : (
                                          <View style={styles.hCardOfflinePill}>
                                            <Text style={styles.offlineTag}>Away</Text>
                                          </View>
                                        )}
                                      </View>
                                      {orgDisplayName ? (
                                        <View style={styles.hCardBizRow}>
                                          <Ionicons name="business" size={12} color={primaryColor} />
                                          <Text style={styles.hCardBizName} numberOfLines={1}>
                                            {orgDisplayName}
                                          </Text>
                                        </View>
                                      ) : null}
                                      <Text style={styles.hCardEmail} numberOfLines={1}>
                                        {v.email}
                                      </Text>
                                    </View>
                                  </View>
                                  <View style={[styles.hCardAssignChip, { borderColor: glass }]}>
                                    <Ionicons
                                      name={v.valeter_work_mode === 'location' ? 'business' : 'car-outline'}
                                      size={13}
                                      color={primaryColor}
                                    />
                                    <Text style={styles.hCardAssignText} numberOfLines={1}>
                                      {v.valeter_work_mode === 'location' && v.assigned_location_id
                                        ? locationNameById.get(v.assigned_location_id) ?? 'Assigned site'
                                        : 'Mobile fleet'}
                                    </Text>
                                  </View>
                                </View>
                                <View style={styles.hCardBodyFlexFill} />
                              </Pressable>
                              <View style={styles.hCardFooter}>
                                <View style={styles.hCardFooterTop}>
                                  <StatusDot status={rosterDotStatus} size={9} pulseOnChange />
                                  <Text style={styles.hCardFooterStatusLabel} numberOfLines={1}>
                                    {rosterStatusLabel}
                                  </Text>
                                </View>
                                <View style={styles.hCardFooterActions}>
                                  <TouchableOpacity
                                    onPress={() => void openWasherChat(v)}
                                    activeOpacity={0.85}
                                    style={[styles.hCardActionBtn, styles.hCardActionBtnPrimary, { borderColor: primaryColor }]}
                                  >
                                    <LinearGradient
                                      colors={[`${primaryColor}38`, `${primaryColor}14`]}
                                      start={{ x: 0, y: 0 }}
                                      end={{ x: 1, y: 1 }}
                                      style={StyleSheet.absoluteFill}
                                    />
                                    <Ionicons name="chatbubble-ellipses-outline" size={15} color={primaryColor} />
                                    <Text style={[styles.hCardActionBtnText, { color: primaryColor }]} numberOfLines={1}>
                                      Message
                                    </Text>
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={async () => {
                                      await hapticFeedback('light');
                                      setSelectedIndex(i);
                                      setDetailMember(v);
                                    }}
                                    activeOpacity={0.85}
                                    style={[styles.hCardActionBtn, styles.hCardActionBtnGhost, { borderColor: glass }]}
                                  >
                                    <Text style={styles.hCardTap} numberOfLines={1}>
                                      Details
                                    </Text>
                                    <Ionicons name="chevron-forward" size={15} color={primaryColor} />
                                  </TouchableOpacity>
                                </View>
                              </View>
                            </View>
                          </View>
                        </View>
                      );
                    })}
                  </ScrollView>
                  <View style={styles.dotsRow}>
                    {filteredValeters.map((_, idx) => (
                      <View key={`team-dot-${idx}`} style={[styles.dot, idx === selectedIndex && { backgroundColor: primaryColor }]} />
                    ))}
                  </View>
                </>
              )}
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={!!detailMember}
        transparent
        animationType="slide"
        onRequestClose={() => {
          if (assignmentLocPicker) {
            setAssignmentLocPicker(false);
            return;
          }
          setDetailMember(null);
        }}
      >
        <View style={styles.detailModalRoot}>
        <Pressable
          style={styles.detailBackdrop}
          onPress={() => {
            if (assignmentLocPicker) {
              setAssignmentLocPicker(false);
              return;
            }
            setDetailMember(null);
          }}
        />
        {detailMember && (
          <View style={[styles.detailSheet, { paddingBottom: Math.max(20, insets.bottom + 12) }]}>
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <BusinessSheetBackground />
            </View>
            <View style={styles.detailHandle} />
            <View style={styles.detailHeader}>
              {detailMember.photoUrl ? (
                <Image
                  source={{ uri: detailMember.photoUrl }}
                  style={styles.detailAvatarImg}
                  resizeMode="cover"
                />
              ) : (
                <LinearGradient
                  colors={[primaryColor, businessTheme.primaryAlt || SKY]}
                  style={styles.detailAvatarImg}
                >
                  <Text style={styles.detailAvatarLetter}>{detailMember.name.trim().slice(0, 1).toUpperCase()}</Text>
                </LinearGradient>
              )}
              <View style={{ flex: 1 }}>
                <Text style={styles.detailName}>{detailMember.name}</Text>
                {orgDisplayName ? (
                  <View style={styles.detailBizRow}>
                    <Ionicons name="business" size={12} color={primaryColor} />
                    <Text style={styles.detailBizName} numberOfLines={1}>
                      {orgDisplayName}
                    </Text>
                  </View>
                ) : null}
                <Text style={styles.detailEmail}>{detailMember.email}</Text>
              </View>
              <TouchableOpacity onPress={() => setDetailMember(null)} hitSlop={12}>
                <Ionicons name="close" size={24} color={MUTED_TEXT} />
              </TouchableOpacity>
            </View>
            <View style={styles.detailStatRow}>
              <View style={[styles.detailStatCard, { borderColor: `${primaryColor}40` }]}>
                <Ionicons name="star" size={18} color="#FBBF24" />
                <Text style={styles.detailStatCardValue}>
                  {detailMember.rating != null && detailMember.rating > 0
                    ? detailMember.rating.toFixed(1)
                    : '—'}
                </Text>
                <Text style={styles.detailStatCardLabel}>Avg rating</Text>
              </View>
              <View style={[styles.detailStatCard, { borderColor: `${primaryColor}40` }]}>
                <Ionicons name="checkmark-done" size={18} color={primaryColor} />
                <Text style={styles.detailStatCardValue}>{detailMember.total_jobs ?? 0}</Text>
                <Text style={styles.detailStatCardLabel}>Jobs completed</Text>
              </View>
            </View>

            <View style={styles.detailAssignment}>
              <Text style={styles.detailAssignmentTitle}>Work assignment</Text>
              <Text style={styles.detailAssignmentHint}>
                Mobile covers your whole operation; fixed site ties this car care pro to one location for rostering.
              </Text>
              <View style={styles.detailModeRow}>
                <TouchableOpacity
                  style={[
                    styles.detailModeChip,
                    draftWorkMode === 'mobile' && { backgroundColor: `${primaryColor}35`, borderColor: primaryColor },
                  ]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setDraftWorkMode('mobile');
                  }}
                >
                  <Ionicons name="car-sport-outline" size={16} color={LIGHT_TEXT} />
                  <Text style={styles.detailModeChipText}>Mobile fleet</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.detailModeChip,
                    draftWorkMode === 'location' && { backgroundColor: `${primaryColor}35`, borderColor: primaryColor },
                  ]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setDraftWorkMode('location');
                  }}
                >
                  <Ionicons name="business" size={16} color={LIGHT_TEXT} />
                  <Text style={styles.detailModeChipText}>Fixed site</Text>
                </TouchableOpacity>
              </View>
              {draftWorkMode === 'location' ? (
                <TouchableOpacity
                  style={[styles.detailLocationPick, { borderColor: `${primaryColor}55` }]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    if (orgLocations.length === 0) {
                      Alert.alert('No locations', 'Add a location under Business → Locations first.');
                      return;
                    }
                    setAssignmentLocPicker(true);
                  }}
                >
                  <Text style={styles.detailLocationPickLabel} numberOfLines={1}>
                    {draftLocationId
                      ? locationNameById.get(draftLocationId) ?? 'Select location'
                      : 'Choose location…'}
                  </Text>
                  <Ionicons name="chevron-down" size={18} color={MUTED_TEXT} />
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity
                style={[styles.detailSaveAssignBtn, { backgroundColor: `${primaryColor}38` }]}
                onPress={() => void saveValeterAssignment()}
                disabled={savingAssignment}
              >
                {savingAssignment ? (
                  <ActivityIndicator size="small" color={LIGHT_TEXT} />
                ) : (
                  <Text style={styles.detailSaveAssignText}>Save assignment</Text>
                )}
              </TouchableOpacity>
            </View>

            <View style={styles.detailActions}>
              <TouchableOpacity
                style={[styles.detailBtnPrimary, { backgroundColor: `${primaryColor}40` }]}
                onPress={async () => {
                  const m = detailMember;
                  if (!m) return;
                  setDetailMember(null);
                  await openWasherChat(m);
                }}
              >
                <Ionicons name="chatbubble-outline" size={16} color={LIGHT_TEXT} />
                <Text style={styles.detailBtnPrimaryText}>Message</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  if (Platform.OS === 'ios' && ActionSheetIOS?.showActionSheetWithOptions) {
                    ActionSheetIOS.showActionSheetWithOptions(
                      {
                        options: ['Cancel', 'Remove from team'],
                        destructiveButtonIndex: 1,
                        cancelButtonIndex: 0,
                      },
                      (idx) => {
                        if (idx === 1) void removeValeterFromOrg(detailMember);
                      }
                    );
                  } else {
                    Alert.alert(
                      detailMember.name,
                      'Remove this person from your team?',
                      [
                        { text: 'Cancel', style: 'cancel' },
                        { text: 'Remove', style: 'destructive', onPress: () => void removeValeterFromOrg(detailMember) },
                      ]
                    );
                  }
                }}
                style={styles.detailBtnGhost}
              >
                {removingId === detailMember.id ? (
                  <ActivityIndicator size="small" color="#F87171" />
                ) : (
                  <>
                    <Ionicons name="person-remove-outline" size={16} color="#F87171" />
                    <Text style={styles.detailBtnGhostText}>Remove</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        {assignmentLocPicker && detailMember ? (
          <View style={styles.assignmentPickerLayer} pointerEvents="box-none">
            <Pressable style={styles.locPickBackdrop} onPress={() => setAssignmentLocPicker(false)} />
            <View style={[styles.locPickSheet, { paddingBottom: Math.max(20, insets.bottom) }]}>
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
                <BusinessSheetBackground />
              </View>
              <Text style={styles.locPickTitle}>Assign to location</Text>
              <ScrollView
                style={styles.locPickScroll}
                keyboardShouldPersistTaps="handled"
                nestedScrollEnabled
              >
                {orgLocations.length === 0 ? (
                  <Text style={styles.locPickEmpty}>
                    No locations loaded. Add one under Business → Locations, then pull to refresh the team map or reopen
                    this card.
                  </Text>
                ) : (
                  orgLocations.map((l) => (
                    <TouchableOpacity
                      key={l.id}
                      style={[
                        styles.locPickRow,
                        draftLocationId === l.id && { backgroundColor: `${primaryColor}22` },
                      ]}
                      onPress={async () => {
                        await hapticFeedback('light');
                        setDraftLocationId(l.id);
                        setAssignmentLocPicker(false);
                      }}
                      activeOpacity={0.85}
                    >
                      <Ionicons name="location-outline" size={18} color={primaryColor} />
                      <Text style={styles.locPickRowText} numberOfLines={2}>
                        {l.name}
                      </Text>
                      {draftLocationId === l.id ? (
                        <Ionicons name="checkmark-circle" size={20} color={primaryColor} />
                      ) : null}
                    </TouchableOpacity>
                  ))
                )}
              </ScrollView>
            </View>
          </View>
        ) : null}
        </View>
      </Modal>

      <InviteWasherSheet
        visible={inviteOpen}
        onClose={() => setInviteOpen(false)}
        primaryColor={primaryColor}
        primaryAlt={businessTheme.primaryAlt}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  safeContent: { flex: 1 },
  headerSafe: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
  },
  searchHeaderOuter: {
    alignItems: 'center',
    paddingHorizontal: HEADER_MARGIN_H,
    marginTop: 8,
  },
  searchHeaderCard: {
    minHeight: SEARCH_CARD_HEIGHT,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  searchHeaderGlassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  searchHeaderGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    zIndex: 5,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  searchHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 8,
    minHeight: SEARCH_CARD_HEIGHT,
    zIndex: 10,
  },
  headerIconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexShrink: 0,
  },
  teamSearchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 0,
    gap: 8,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 18,
    paddingHorizontal: 12,
    minHeight: 40,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  searchHeaderInput: {
    flex: 1,
    color: LIGHT_TEXT,
    fontSize: 15,
    paddingVertical: 0,
  },
  teamSearchClearBtn: {
    width: 22,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerInviteBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(125,211,252,0.18)',
    flexShrink: 0,
  },
  teamPageShell: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  teamHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  teamListHeader: {
    marginTop: 14,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    gap: 14,
  },
  teamListHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  teamKicker: {
    color: 'rgba(125,211,252,0.9)',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.2,
  },
  teamListTitle: {
    color: LIGHT_TEXT,
    fontSize: 20,
    fontWeight: '800',
    marginTop: 2,
    letterSpacing: -0.4,
  },
  teamListSub: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 17,
    marginTop: 4,
  },
  teamFilterChips: {
    flexDirection: 'row',
    flexShrink: 0,
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
    gap: 8,
    maxWidth: 164,
  },
  teamChip: {
    minHeight: 34,
    paddingHorizontal: 12,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  teamChipActive: {
    backgroundColor: 'rgba(125,211,252,0.18)',
    borderColor: 'rgba(125,211,252,0.36)',
  },
  teamChipText: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '700',
  },
  teamChipTextActive: {
    color: LIGHT_TEXT,
  },
  teamListScroll: {
    flex: 1,
    minHeight: 0,
  },
  teamListScrollContent: {
    paddingTop: 2,
    paddingBottom: 20,
  },
  emptyListWrap: {
    paddingTop: 36,
  },
  teamListCards: {
    gap: 12,
  },
  teamListCardWrap: {
    width: '100%',
  },
  teamMapModalRoot: {
    flex: 1,
  },
  teamMapHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 20,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  teamMapTitle: {
    color: LIGHT_TEXT,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  teamMapSubtitle: {
    color: MUTED_TEXT,
    fontSize: 12,
    marginTop: 4,
  },
  teamMapClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },

  mapSideRail: {
    position: 'absolute',
    right: 10,
    zIndex: 25,
    width: MAP_SIDE_RAIL_WIDTH + 8,
  },
  mapSideRailInner: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    gap: 12,
    paddingTop: 4,
  },
  mapSideStack: {
    gap: 8,
    alignItems: 'flex-end',
    paddingRight: 2,
  },
  mapSideBtn: {
    position: 'relative',
    width: MAP_SIDE_RAIL_WIDTH,
    minHeight: 54,
    borderRadius: 16,
    backgroundColor: 'rgba(15,23,42,0.82)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    paddingHorizontal: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 14,
  },
  mapSideBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: 'rgba(16,185,129,0.95)',
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  mapSideBadgeText: { color: LIGHT_TEXT, fontSize: 9, fontWeight: '800' },
  mapSideBtnLabel: {
    color: MUTED_TEXT,
    fontSize: 9,
    fontWeight: '700',
    marginTop: 2,
    textAlign: 'center',
  },
  mapSideBtnLabelMuted: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 8,
    fontWeight: '700',
    marginTop: 2,
  },
  mapSideDivider: {
    height: StyleSheet.hairlineWidth,
    width: 36,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignSelf: 'flex-end',
    marginVertical: 2,
  },
  emptyStateWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 28,
    gap: 14,
  },
  emptyStateTitle: { color: LIGHT_TEXT, fontSize: 18, fontWeight: '800', textAlign: 'center' },
  emptyStateSubtitle: { color: MUTED_TEXT, fontSize: 14, textAlign: 'center', lineHeight: 20 },

  mapMarkerWrap: { alignItems: 'center', justifyContent: 'center' },
  mapMarkerWrapSelected: { transform: [{ scale: 1.08 }] },
  mapMarkerGlow: {
    position: 'absolute',
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(125,211,252,0.2)',
  },
  mapMarkerCore: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    overflow: 'hidden',
  },
  mapMarkerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  mapMarkerPulse: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#34D399',
    borderWidth: 2,
    borderColor: '#0f172a',
  },

  bottomArea: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  sheetShell: {
    flex: 1,
    flexDirection: 'column',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingHorizontal: SHEET_HORIZONTAL_PAD,
    paddingTop: 0,
    paddingBottom: 0,
    minHeight: 0,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 36,
    height: 4,
    borderRadius: 2,
    marginTop: 8,
    marginBottom: 8,
  },
  sheetHeadRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
    gap: 10,
  },
  sheetHeadTextCol: { flex: 1, minWidth: 0 },
  sheetFilterFab: {
    width: 44,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    marginTop: 2,
    flexShrink: 0,
  },
  sheetFilterFabIcon: { zIndex: 2 },
  sheetKicker: {
    color: 'rgba(125,211,252,0.85)',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.1,
  },
  sheetTitle: { color: LIGHT_TEXT, fontSize: 18, fontWeight: '800', marginTop: 2, letterSpacing: -0.4 },
  sheetSub: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    marginTop: 2,
    marginBottom: 0,
    fontWeight: '600',
    letterSpacing: 0.2,
  },

  hCardScroll: { flex: 1, minHeight: 0 },
  /** flexGrow + stretch: cards fill roster strip height so nothing clips the sheet */
  hScrollContent: {
    flexGrow: 1,
    paddingTop: 2,
    paddingBottom: 10,
    paddingRight: 0,
    alignItems: 'stretch',
  },
  hCardWrap: {
    marginRight: CARD_GAP,
    borderRadius: 24,
    alignSelf: 'stretch',
  },
  hCardOuter: {
    flex: 1,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    minHeight: 0,
    position: 'relative',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  hCardOuterSelected: {
    shadowColor: colors.SKY,
    shadowOpacity: 0.5,
    shadowRadius: 24,
    elevation: 24,
  },
  hCardGlassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderRadius: 24,
    zIndex: 2,
  },
  hCardGlowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
    zIndex: 3,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.75,
    shadowRadius: 8,
  },
  hCardInner: {
    flex: 1,
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 12,
    zIndex: 4,
    justifyContent: 'space-between',
    minHeight: 0,
    overflow: 'hidden',
  },
  hCardHeroRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  hCardAvatarCol: { position: 'relative' },
  hCardAvatarRing: {
    padding: 2,
    borderRadius: 20,
    borderWidth: 2,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  hCardAvatar: {
    width: 52,
    height: 52,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  hCardAvatarLetter: {
    color: '#0f172a',
    fontSize: 20,
    fontWeight: '900',
  },
  hCardRankBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    backgroundColor: 'rgba(15,23,42,0.94)',
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 10,
    borderWidth: 1,
  },
  hCardRankText: {
    color: 'rgba(125,211,252,0.95)',
    fontSize: 11,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },
  hCardTitleBlock: { flex: 1, minWidth: 0, justifyContent: 'flex-start', paddingTop: 1 },
  hCardNameStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minWidth: 0,
  },
  hCardBizRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 6,
  },
  hCardBizName: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  hCardOnlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flexShrink: 0,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(52,211,153,0.35)',
  },
  hCardOfflinePill: {
    flexShrink: 0,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  onlineDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: '#34D399' },
  onlineTagText: { color: '#6EE7B7', fontSize: 9, fontWeight: '900', letterSpacing: 0.5 },
  offlineTag: { color: MUTED_TEXT, fontSize: 9, fontWeight: '800' },
  hCardName: {
    color: LIGHT_TEXT,
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: -0.3,
    flex: 1,
    minWidth: 0,
  },
  hCardAssignChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 2,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  hCardAssignText: { color: MUTED_TEXT, fontSize: 12, fontWeight: '700', flex: 1, minWidth: 0 },
  hCardEmail: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    marginTop: 5,
    lineHeight: 14,
  },
  hCardPressableBody: {
    flex: 1,
    minHeight: 0,
    flexShrink: 1,
    flexDirection: 'column',
    overflow: 'hidden',
  },
  hCardMainBlock: {
    gap: 8,
    flexShrink: 0,
  },
  hCardBodyFlexFill: {
    flex: 1,
    minHeight: 0,
  },
  hCardFooter: {
    flexDirection: 'column',
    alignItems: 'stretch',
    flexShrink: 0,
    gap: 8,
    marginTop: 0,
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  hCardFooterTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minWidth: 0,
  },
  hCardFooterStatusLabel: {
    flex: 1,
    minWidth: 0,
    color: 'rgba(249,250,251,0.55)',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.15,
  },
  hCardFooterActions: {
    flexDirection: 'row',
    alignItems: 'stretch',
    flexShrink: 0,
    gap: 8,
    minWidth: 0,
    width: '100%',
  },
  hCardActionBtn: {
    flex: 1,
    flexBasis: 0,
    minWidth: 0,
    minHeight: 40,
    maxHeight: 40,
    paddingHorizontal: 6,
    borderRadius: 12,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    borderWidth: 1,
  },
  hCardActionBtnPrimary: {
    position: 'relative',
  },
  hCardActionBtnGhost: {
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  hCardActionBtnText: { fontSize: 12, fontWeight: '800', flexShrink: 1 },
  hCardTap: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '800', flexShrink: 1 },

  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 7,
    marginTop: 4,
    marginBottom: 0,
    flexShrink: 0,
  },
  dot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: 'rgba(255,255,255,0.22)' },

  emptySheetBody: { flex: 1, minHeight: 120, justifyContent: 'center' },

  detailModalRoot: {
    flex: 1,
  },
  detailBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,13,20,0.65)',
  },
  detailSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    paddingHorizontal: 20,
    paddingTop: 8,
    borderWidth: 1,
    borderBottomWidth: 0,
    borderColor: 'rgba(125,211,252,0.28)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  detailHandle: {
    alignSelf: 'center',
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(125,211,252,0.6)',
    marginTop: 8,
    marginBottom: 8,
  },
  detailHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  detailAvatarImg: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
  },
  detailAvatarLetter: { color: '#0f172a', fontSize: 19, fontWeight: '900' },
  detailName: { color: LIGHT_TEXT, fontSize: 17, fontWeight: '800' },
  detailBizRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
    maxWidth: '100%',
  },
  detailBizName: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600', flex: 1 },
  detailEmail: { color: MUTED_TEXT, fontSize: 12, marginTop: 3 },
  detailStatRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 14,
  },
  detailStatCard: {
    flex: 1,
    flexBasis: 0,
    minWidth: 0,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    gap: 4,
  },
  detailStatCardValue: {
    color: LIGHT_TEXT,
    fontSize: 20,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    letterSpacing: -0.4,
  },
  detailStatCardLabel: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  detailAssignment: {
    marginBottom: 12,
    paddingTop: 4,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  detailAssignmentTitle: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '800', marginBottom: 4 },
  detailAssignmentHint: { color: MUTED_TEXT, fontSize: 11, lineHeight: 16 },
  detailModeRow: { flexDirection: 'row', gap: 8, marginTop: 10, marginBottom: 8 },
  detailModeChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  detailModeChipText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '800' },
  detailLocationPick: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    marginBottom: 10,
  },
  detailLocationPickLabel: { color: LIGHT_TEXT, fontSize: 13, fontWeight: '700', flex: 1, marginRight: 8 },
  detailSaveAssignBtn: {
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  detailSaveAssignText: { color: LIGHT_TEXT, fontSize: 13, fontWeight: '800' },
  detailActions: { flexDirection: 'row', gap: 10, alignItems: 'stretch' },
  assignmentPickerLayer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 200,
    elevation: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locPickBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(5,12,24,0.72)',
    zIndex: 0,
  },
  locPickSheet: {
    alignSelf: 'center',
    width: '90%',
    maxWidth: 400,
    maxHeight: '52%',
    backgroundColor: 'transparent',
    overflow: 'hidden',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.32)',
    padding: 12,
    zIndex: 2,
    elevation: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.22,
    shadowRadius: 16,
  },
  locPickTitle: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '800', marginBottom: 8, zIndex: 1, letterSpacing: -0.3 },
  locPickScroll: { maxHeight: 280, zIndex: 1 },
  locPickEmpty: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 17,
    paddingVertical: 6,
  },
  locPickRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 10,
    marginBottom: 4,
  },
  locPickRowText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '600', flex: 1 },
  detailBtnPrimary: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 12,
  },
  detailBtnPrimaryText: { color: LIGHT_TEXT, fontWeight: '800', fontSize: 13, flexShrink: 1 },
  detailBtnGhost: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  detailBtnGhostText: { color: '#FCA5A5', fontWeight: '800', fontSize: 13 },
});
