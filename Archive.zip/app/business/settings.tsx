import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons, type IconGlyphName } from '../../src/components/shared/ChromeGlyph';
import { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import LoadingScreen from '../../src/components/LoadingScreen';

const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function BusinessSettings() {
  const { user, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    setLoading(false);
  }, [user?.id]);

  const handleDeleteAccount = async () => {
    await hapticFeedback('light');
    router.push('/account-deletion' as any);
  };

  const handleLogout = async () => {
    if (loggingOut) return;

    Alert.alert(
      'Log out?',
      'You’ll need to sign in again to access your business account.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log out',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoggingOut(true);
              await hapticFeedback('medium');
              await logout();
            } catch (e: any) {
              console.error('[BusinessSettings] logout error:', e);
              Alert.alert('Error', e?.message || 'Failed to log out. Please try again.');
            } finally {
              setLoggingOut(false);
            }
          },
        },
      ]
    );
  };

  type SettingsItem = {
    id: string;
    label: string;
    hint?: string;
    icon: string;
    route: string;
    color: string;
  };

  type SettingsSection = {
    title: string;
    subtitle: string;
    items: SettingsItem[];
  };

  const settingsSections: SettingsSection[] = [
    {
      title: 'Company',
      subtitle: 'Profile, alerts, and booking activity',
      items: [
        {
          id: 'profile',
          label: 'Business profile',
          hint: 'Storefront, logo, and contact',
          icon: 'business',
          route: '/business/profile',
          color: SKY,
        },
        {
          id: 'notifications',
          label: 'Notifications',
          hint: 'Business alerts and updates',
          icon: 'notifications-outline',
          route: '/business/notifications',
          color: '#A78BFA',
        },
        {
          id: 'bookings',
          label: 'Bookings',
          hint: 'All jobs and history',
          icon: 'calendar-outline',
          route: '/business/bookings',
          color: '#F59E0B',
        },
        {
          id: 'key-metrics',
          label: 'Key metrics',
          hint: 'Digital ring charts for KPIs',
          icon: 'pie-chart',
          route: '/business/key-metrics',
          color: '#8B5CF6',
        },
      ],
    },
    {
      title: 'Locations',
      subtitle: 'Sites, opening hours, and per-location services',
      items: [
        {
          id: 'locations',
          label: 'Manage locations',
          hint: 'Addresses, hours, coverage',
          icon: 'location',
          route: '/business/locations',
          color: '#10B981',
        },
      ],
    },
    {
      title: 'Operations',
      subtitle: 'What you offer, your team, and money in',
      items: [
        {
          id: 'services',
          label: 'Services',
          hint: 'Wash tiers and pricing',
          icon: 'construct',
          route: '/business/services',
          color: '#F59E0B',
        },
        {
          id: 'team',
          label: 'Team',
          hint: 'Car Care Pros and roles',
          icon: 'people',
          route: '/business/team',
          color: SKY,
        },
        {
          id: 'earnings',
          label: 'Earnings',
          hint: 'Revenue and balance',
          icon: 'wallet-outline',
          route: '/business/earnings',
          color: '#06B6D4',
        },
      ],
    },
    {
      title: 'Payments',
      subtitle: 'Getting paid on the platform',
      items: [
        {
          id: 'stripe-connect',
          label: 'Stripe Connect',
          hint: 'Payouts and onboarding',
          icon: 'wallet-outline',
          route: '/business/stripe-connect',
          color: '#10B981',
        },
      ],
    },
    {
      title: 'Legal',
      subtitle: 'Policies that apply to your business',
      items: [
        {
          id: 'terms',
          label: 'Terms and conditions',
          hint: 'Platform and business terms',
          icon: 'document-text-outline',
          route: '/terms-of-service',
          color: '#94A3B8',
        },
        {
          id: 'privacy',
          label: 'Privacy policy',
          hint: 'How we handle data',
          icon: 'shield-checkmark-outline',
          route: '/privacy-policy',
          color: '#64748B',
        },
      ],
    },
  ];

  if (loading) {
    return <LoadingScreen message="Loading settings…" />;
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>
      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: 12,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <View style={styles.headerSpacer} />
          <Text style={styles.headerTitle}>Settings</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            activeOpacity={0.8}
            style={styles.headerCloseButton}
            accessibilityRole="button"
            accessibilityLabel="Close settings"
          >
            <Ionicons name="close" size={22} color={SKY} />
          </TouchableOpacity>
        </View>

        <Animated.View style={[styles.introBlock, { opacity: fadeAnim }]}>
          <Text style={styles.introTitle}>Business hub</Text>
          <Text style={styles.introBody}>
            Manage locations, operations, payouts, legal, and account actions. Appearance and storefront editing stay under{' '}
            <Text style={styles.introEmphasis}>Profile</Text> in the tab bar.
          </Text>
        </Animated.View>

        {settingsSections.map((section, sectionIndex) => (
          <Animated.View
            key={section.title}
            style={[
              styles.section,
              { opacity: fadeAnim },
              {
                transform: [
                  {
                    translateY: fadeAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [28 + sectionIndex * 8, 0],
                    }),
                  },
                ],
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{section.title}</Text>
              <Text style={styles.sectionSubtitle}>{section.subtitle}</Text>
            </View>
            <View style={styles.itemsContainer}>
              {section.items.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push(item.route as any);
                  }}
                  style={styles.itemWrapper}
                  activeOpacity={0.9}
                >
                  <GlassCard style={styles.itemCard} accountType="business" borderColor={`${item.color}40`}>
                    <View style={styles.itemContent}>
                      <View style={styles.itemIconWrapper}>
                        <LocationStyleIconBox
                          icon={item.icon as IconGlyphName}
                          colors={accentToGradient(item.color)}
                        />
                      </View>
                      <View style={styles.itemTextCol}>
                        <Text style={styles.itemLabel}>{item.label}</Text>
                        {item.hint ? <Text style={styles.itemHint}>{item.hint}</Text> : null}
                      </View>
                      <Ionicons name="chevron-forward" size={20} color="rgba(148,163,184,0.9)" />
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        ))}

        {/* Logout */}
        <Animated.View
          style={[
            styles.section,
            styles.accountSection,
            { opacity: fadeAnim },
            {
              transform: [
                {
                  translateY: fadeAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [36, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Account</Text>
            <Text style={styles.sectionSubtitle}>Session and sign-in</Text>
          </View>

          <TouchableOpacity
            onPress={handleLogout}
            disabled={loggingOut}
            activeOpacity={0.9}
          >
            <GlassCard style={[styles.logoutCard, loggingOut && { opacity: 0.7 }] as any} accountType="business" borderColor="rgba(239,68,68,0.35)">
              <View style={styles.logoutContent}>
                <View style={[styles.logoutIconWrapper, { backgroundColor: 'transparent', borderWidth: 0 }]}>
                  {loggingOut ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <LocationStyleIconBox icon="log-out-outline" preset="red" />
                  )}
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.logoutTitle}>
                    {loggingOut ? 'Logging out…' : 'Log out'}
                  </Text>
                  <Text style={styles.logoutSubtitle}>
                    Sign out of this business account
                  </Text>
                </View>

                <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
              </View>
            </GlassCard>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleDeleteAccount} activeOpacity={0.9} style={{ marginTop: 12 }}>
            <GlassCard style={styles.deleteAccountCard as any} accountType="business" borderColor="rgba(239,68,68,0.45)">
              <View style={styles.logoutContent}>
                <View style={[styles.logoutIconWrapper, { backgroundColor: 'transparent', borderWidth: 0 }]}>
                  <LocationStyleIconBox icon="trash-outline" preset="red" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.logoutTitle}>Delete account</Text>
                  <Text style={styles.logoutSubtitle}>Open a deletion request form</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
              </View>
            </GlassCard>
          </TouchableOpacity>
        </Animated.View>

        <View style={{ height: 22 }} />
      </Animated.ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 4,
    paddingBottom: 14,
  },
  headerSpacer: {
    width: 36,
    height: 36,
  },
  headerTitle: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  headerCloseButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  introBlock: {
    marginBottom: 22,
    paddingBottom: 4,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.22)',
  },
  introTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  introBody: {
    color: 'rgba(249,250,251,0.72)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 14,
  },
  introEmphasis: {
    color: SKY,
    fontWeight: '700',
  },
  section: {
    marginBottom: 22,
  },
  accountSection: {
    marginTop: 4,
  },
  sectionHeader: {
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: 0.15,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 13,
    lineHeight: 18,
    marginTop: 4,
    fontWeight: '500',
  },
  itemsContainer: {
    gap: 10,
  },
  itemWrapper: {
    marginBottom: 0,
  },
  itemCard: {
    padding: 16,
  },
  itemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  itemTextCol: {
    flex: 1,
    minWidth: 0,
  },
  itemIconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  itemHint: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 3,
  },

  // Logout
  logoutCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  logoutContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  logoutIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  logoutTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  logoutSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  deleteAccountCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
});
