import React, { useEffect, useState, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  TouchableOpacity,
  ScrollView,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useLocalSearchParams, router } from 'expo-router';
import MapView, { Marker } from 'react-native-maps';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import PremiumButton from '../../../src/components/premium/PremiumButton';
import { colors } from '../../../src/constants/colors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { SCREEN_PADDING_H } from '../../../src/constants/premiumTokens';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { canOpenLiveTracking } from '../../../src/utils/businessBookingAccess';
import { canBusinessUseBookingChat } from '../../../src/services/bookingCustomerChatAccess';
import { resolveCustomerAvatarFromProfileRow } from '../../../src/utils/customerProfiles';

const SKY = colors.SKY;

type BookingDetails = {
  id: string;
  status: string;
  service_type?: string | null;
  service_name: string | null;
  wash_type?: string | null;
  location_address: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  location_id?: string | null;
  valeter_id?: string | null;
  scheduled_at: string | null;
  created_at: string;
  price: number | null;
  user_id?: string | null;
  customer_name?: string | null;
  customer_review?: string | null;
};

function isMissingColumnErr(err: any) {
  const code = String(err?.code || '');
  const msg = String(err?.message || '').toLowerCase();
  return code === '42703' || msg.includes('does not exist') || msg.includes('column');
}

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

const isPendingStatus = (status: string) =>
  ['pending', 'pending_business_acceptance'].includes(status.toLowerCase());

const LIVE_STATUSES = ['valeter_assigned', 'en_route', 'arrived', 'in_progress'];
const isLiveStatus = (status: string) => LIVE_STATUSES.includes((status || '').toLowerCase());

const DETAIL_MAP_HEIGHT = 160;
const DEFAULT_REGION = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function BusinessBookingDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { theme: businessTheme } = useAccountTheme();
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const presenceChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const [booking, setBooking] = useState<BookingDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [customerPhoto, setCustomerPhoto] = useState<string | null>(null);
  const [vehicleLine, setVehicleLine] = useState<string | null>(null);
  const [valeterDisplayName, setValeterDisplayName] = useState<string | null>(null);
  const [chatAllowed, setChatAllowed] = useState(true);

  useEffect(() => {
    if (id) loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Realtime: booking updates
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`booking-detail-${id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `id=eq.${id}` },
        (payload) => {
          if (payload.new && typeof payload.new === 'object') {
            const row = payload.new as Record<string, unknown>;
            setBooking((prev) => {
              if (!prev || prev.id !== id) return prev;
              return {
                ...prev,
                status: (row.status as string) ?? prev.status,
                service_name: (row.service_name as string | null) ?? prev.service_name,
                service_type: (row.service_type as string | null) ?? prev.service_type,
                wash_type: (row.wash_type as string | null) ?? prev.wash_type,
                location_address: (row.location_address as string | null) ?? prev.location_address,
                location_lat: row.location_lat != null ? Number(row.location_lat) : prev.location_lat,
                location_lng: row.location_lng != null ? Number(row.location_lng) : prev.location_lng,
                location_id: (row.location_id as string | null) ?? prev.location_id,
                valeter_id: (row.valeter_id as string | null) ?? prev.valeter_id,
                scheduled_at: (row.scheduled_at as string | null) ?? prev.scheduled_at,
                price: row.price != null ? Number(row.price) : prev.price,
                customer_name: (row.customer_name as string | null) ?? prev.customer_name,
                customer_review: (row.customer_review as string | null) ?? prev.customer_review,
              };
            });
          }
        }
      )
      .subscribe();
    channelRef.current = channel;
    return () => {
      supabase.removeChannel(channel);
      channelRef.current = null;
    };
  }, [id]);

  // Valeter presence when assigned and status is live
  useEffect(() => {
    const valeterId = booking?.valeter_id;
    if (!valeterId || !isLiveStatus(booking?.status ?? '')) {
      setValeterLocation(null);
      if (presenceChannelRef.current) {
        supabase.removeChannel(presenceChannelRef.current);
        presenceChannelRef.current = null;
      }
      return;
    }
    const presenceChannel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'valeter_presence', filter: `user_id=eq.${valeterId}` },
        (payload) => {
          const row = (payload.new || payload.old) as Record<string, unknown> | undefined;
          if (row && row.last_lat != null && row.last_lng != null) {
            const lat = Number(row.last_lat);
            const lng = Number(row.last_lng);
            if (Number.isFinite(lat) && Number.isFinite(lng)) {
              setValeterLocation({ latitude: lat, longitude: lng });
            }
            return;
          }
          setValeterLocation(null);
        }
      )
      .subscribe();
    presenceChannelRef.current = presenceChannel;
    // Fetch current position once
    (async () => {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();
      if (data?.last_lat != null && data?.last_lng != null) {
        const lat = Number(data.last_lat);
        const lng = Number(data.last_lng);
        if (Number.isFinite(lat) && Number.isFinite(lng)) {
          setValeterLocation({ latitude: lat, longitude: lng });
        }
      }
    })();
    return () => {
      supabase.removeChannel(presenceChannel);
      presenceChannelRef.current = null;
      setValeterLocation(null);
    };
  }, [booking?.id, booking?.valeter_id, booking?.status]);

  useEffect(() => {
    const uid = booking?.user_id;
    if (!uid) {
      setCustomerPhoto(null);
      setVehicleLine(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const [{ data: profile }, { data: vehicle }] = await Promise.all([
          supabase.from('profiles').select('profile_picture, logo').eq('id', uid).maybeSingle(),
          supabase
            .from('customer_vehicles')
            .select('registration, make, model')
            .eq('user_id', uid)
            .eq('is_default', true)
            .maybeSingle(),
        ]);
        if (cancelled) return;
        setCustomerPhoto(resolveCustomerAvatarFromProfileRow(profile as any));
        const v = vehicle as { registration?: string; make?: string; model?: string } | null;
        const mm = [v?.make, v?.model].filter(Boolean).join(' ').trim();
        const reg = v?.registration?.trim();
        setVehicleLine(mm ? (reg ? `${reg} · ${mm}` : mm) : reg || null);
      } catch {
        if (!cancelled) {
          setCustomerPhoto(null);
          setVehicleLine(null);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [booking?.user_id]);

  useEffect(() => {
    const vid = booking?.valeter_id;
    if (!vid) {
      setValeterDisplayName(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data } = await supabase.from('profiles').select('full_name, name').eq('id', vid).maybeSingle();
      if (cancelled) return;
      const p = data as { full_name?: string; name?: string } | null;
      setValeterDisplayName((p?.full_name || p?.name || null) as string | null);
    })();
    return () => {
      cancelled = true;
    };
  }, [booking?.valeter_id]);

  useEffect(() => {
    if (!booking) return;
    let cancelled = false;
    (async () => {
      const ok = await canBusinessUseBookingChat(booking.status, booking.id, booking.user_id);
      if (!cancelled) setChatAllowed(ok);
    })();
    return () => {
      cancelled = true;
    };
  }, [booking?.id, booking?.status, booking?.user_id]);

  useEffect(() => {
    if (!id || !booking?.user_id) return;
    const channel = supabase
      .channel(`booking-detail-chat-unlock-${id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'booking_messages',
          filter: `booking_id=eq.${id}`,
        },
        (payload) => {
          const row = payload.new as { sender_id?: string } | null;
          if (row?.sender_id && row.sender_id === booking.user_id) {
            setChatAllowed(true);
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, booking?.user_id]);

  const canCancel = useMemo(() => {
    if (!booking) return false;
    const s = booking.status.toLowerCase();
    return s !== 'cancelled' && s !== 'completed';
  }, [booking]);

  const loadBooking = async () => {
    try {
      setLoading(true);

      const baseFields = [
        'id',
        'status',
        'service_type',
        'service_name',
        'wash_type',
        'location_address',
        'location_lat',
        'location_lng',
        'location_id',
        'valeter_id',
        'scheduled_at',
        'created_at',
        'price',
        'user_id',
        'customer_name',
        'customer_review',
      ];

      let fields = [...baseFields];

      for (let i = 0; i < 6; i++) {
        const { data, error } = await supabase
          .from('bookings')
          .select(fields.join(','))
          .eq('id', id)
          .maybeSingle();
        const row = data as Record<string, unknown> | null;

        if (!error && row) {
          const lat = row.location_lat != null ? Number(row.location_lat) : null;
          const lng = row.location_lng != null ? Number(row.location_lng) : null;
          setBooking({
            id: String(row.id ?? ''),
            status: String(row.status ?? 'unknown'),
            service_type: (row.service_type as string | null) ?? null,
            service_name: (row.service_name as string | null) ?? null,
            wash_type: (row.wash_type as string | null) ?? null,
            location_address: (row.location_address as string | null) ?? null,
            location_lat: Number.isFinite(lat) ? lat : null,
            location_lng: Number.isFinite(lng) ? lng : null,
            location_id: (row.location_id as string | null) ?? null,
            valeter_id: (row.valeter_id as string | null) ?? null,
            scheduled_at: (row.scheduled_at as string | null) ?? null,
            created_at: String(row.created_at ?? new Date().toISOString()),
            price: row.price != null ? Number(row.price) : null,
            user_id: (row.user_id as string | null) ?? null,
            customer_name: (row.customer_name as string | null) ?? null,
            customer_review: (row.customer_review as string | null) ?? null,
          });
          return;
        }

        if (isMissingColumnErr(error)) {
          const missing = getMissingColumn(error?.message);
          if (missing && fields.includes(missing)) {
            fields = fields.filter(f => f !== missing);
            continue;
          }
        }

        throw error;
      }

      throw new Error('Failed to load booking');
    } catch (err: any) {
      console.error('[BookingDetails] load error:', err);
      Alert.alert('Error', err?.message || 'Failed to load booking');
    } finally {
      setLoading(false);
    }
  };

  const acceptBooking = async () => {
    if (!booking) return;

    try {
      setActionLoading(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('bookings')
        .update({ status: 'confirmed' })
        .eq('id', booking.id);

      if (error) throw error;

      setBooking({ ...booking, status: 'confirmed' });
      Alert.alert('Accepted', 'Booking has been accepted');
    } catch (err: any) {
      console.error('[BookingDetails] accept error:', err);
      Alert.alert('Error', err?.message || 'Failed to accept booking');
    } finally {
      setActionLoading(false);
    }
  };

  const cancelBooking = async () => {
    if (!booking) return;

    Alert.alert(
      'Cancel booking',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              setActionLoading(true);
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled' })
                .eq('id', booking.id);

              if (error) throw error;

              Alert.alert('Cancelled', 'The booking has been cancelled.');
              router.replace('/business/dashboard');
            } catch (err: any) {
              console.error('[BookingDetails] cancel error:', err);
              Alert.alert('Error', err?.message || 'Failed to cancel booking');
            } finally {
              setActionLoading(false);
            }
          },
        },
      ]
    );
  };

  const speakToCustomer = async () => {
    if (!booking) return;
    await hapticFeedback('light');
    if (!chatAllowed) {
      Alert.alert(
        'Messaging locked',
        'For completed jobs, messaging unlocks when the customer sends a message.'
      );
      return;
    }
    router.push({ pathname: '/business/bookings/chat', params: { id: booking.id } } as any);
  };

  if (loading) {
    return <LoadingScreen message="Loading booking…" />;
  }

  if (!booking) return null;

  const serviceDisplay =
    getServiceDisplayName(booking.service_type ?? undefined, booking.service_name) ||
    booking.service_name ||
    booking.wash_type ||
    'Service';
  const customerDisplay = booking.customer_name || 'Customer';
  const trackingAllowed = canOpenLiveTracking(booking.scheduled_at, booking.status);

  const scheduledLabel = booking.scheduled_at
    ? new Date(booking.scheduled_at).toLocaleString('en-GB', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;

  const hasJobCoords =
    booking.location_lat != null &&
    booking.location_lng != null &&
    Number.isFinite(booking.location_lat) &&
    Number.isFinite(booking.location_lng);
  const mapRegion = hasJobCoords
    ? {
        latitude: booking.location_lat!,
        longitude: booking.location_lng!,
        latitudeDelta: 0.006,
        longitudeDelta: 0.006,
      }
    : valeterLocation
      ? {
          latitude: valeterLocation.latitude,
          longitude: valeterLocation.longitude,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }
      : DEFAULT_REGION;
  const showMap = hasJobCoords || valeterLocation;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader
        title="Booking Details"
        accountType="business"
        showBack={true}
        onBack={() => router.back()}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingHorizontal: SCREEN_PADDING_H, paddingBottom: 48 },
        ]}
      >
        {showMap ? (
          <View style={[styles.mapWrap, { height: DETAIL_MAP_HEIGHT }]}>
            <MapView
              style={StyleSheet.absoluteFill}
              region={mapRegion}
              customMapStyle={DARK_MAP_STYLE}
              mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
            >
              {hasJobCoords && (
                <Marker
                  coordinate={{
                    latitude: booking.location_lat!,
                    longitude: booking.location_lng!,
                  }}
                  title="Job location"
                />
              )}
              {valeterLocation && (
                <Marker
                  coordinate={valeterLocation}
                  title="Car Care Pro"
                  pinColor={SKY}
                />
              )}
            </MapView>
          </View>
        ) : (
          <View style={[styles.mapPlaceholder, { height: DETAIL_MAP_HEIGHT }]}>
            <Ionicons name="map-outline" size={32} color="rgba(135,206,235,0.5)" />
            <Text style={styles.mapPlaceholderText}>No map data</Text>
          </View>
        )}

        <GlassCard accountType="business" style={styles.detailCard}>
          <View style={styles.hero}>
            <View style={styles.heroIconWrap}>
              {customerPhoto ? (
                <Image source={{ uri: customerPhoto }} style={styles.heroAvatar} resizeMode="cover" />
              ) : (
                <Text style={styles.heroInitial}>{customerDisplay.charAt(0).toUpperCase()}</Text>
              )}
            </View>
            <Text style={styles.heroName}>{customerDisplay}</Text>
            <StatusBadge status={booking.status as any} size="medium" />
          </View>

          <View style={styles.infoRows}>
            <View style={styles.infoRow}>
              <Ionicons name="briefcase-outline" size={18} color={SKY} />
              <Text style={styles.infoText}>{serviceDisplay}</Text>
            </View>
            {vehicleLine ? (
              <View style={styles.infoRow}>
                <Ionicons name="car-sport-outline" size={18} color={SKY} />
                <Text style={styles.infoText} numberOfLines={2}>
                  {vehicleLine}
                </Text>
              </View>
            ) : null}
            {valeterDisplayName ? (
              <View style={styles.infoRow}>
                <Ionicons name="person-outline" size={18} color={SKY} />
                <Text style={styles.infoText} numberOfLines={1}>
                  Car Care Pro: {valeterDisplayName}
                </Text>
              </View>
            ) : null}
            {scheduledLabel && (
              <View style={styles.infoRow}>
                <Ionicons name="time-outline" size={18} color={SKY} />
                <Text style={styles.infoText}>{scheduledLabel}</Text>
              </View>
            )}
            {booking.location_address ? (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={18} color={SKY} />
                <Text style={styles.infoText} numberOfLines={2}>
                  {booking.location_address}
                </Text>
              </View>
            ) : null}
            {booking.price != null ? (
              <View style={styles.infoRow}>
                <Ionicons name="wallet-outline" size={18} color={SKY} />
                <Text style={[styles.infoText, styles.infoPrice]}>£{Number(booking.price).toFixed(2)}</Text>
              </View>
            ) : null}
          </View>
        </GlassCard>

        {/* Actions (tracking PremiumButton style) */}
        <View style={styles.actions}>
          {isPendingStatus(booking.status) && (
            <PremiumButton
              title="Accept booking"
              onPress={acceptBooking}
              loading={actionLoading}
              icon={<Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />}
            />
          )}

          <PremiumButton
            title={trackingAllowed ? 'Track booking' : 'Live tracking locked'}
            onPress={() => {
              hapticFeedback('light');
              if (!trackingAllowed) {
                Alert.alert(
                  'Tracking unavailable',
                  ['completed', 'cancelled'].includes(booking.status.toLowerCase())
                    ? 'This booking has ended.'
                    : 'Live tracking unlocks 30 minutes before the scheduled start.'
                );
                return;
              }
              router.push({ pathname: '/business/bookings/tracking', params: { bookingId: booking.id } } as any);
            }}
            variant="secondary"
            icon={<Ionicons name="navigate-outline" size={18} color={businessTheme.primary} />}
          />

          <PremiumButton
            title={chatAllowed ? 'Message customer' : 'Message locked'}
            onPress={speakToCustomer}
            variant="secondary"
            icon={<Ionicons name="chatbubble-ellipses-outline" size={18} color={businessTheme.primary} />}
          />

          {canCancel && (
            <TouchableOpacity
              style={styles.dangerBtn}
              onPress={cancelBooking}
              disabled={actionLoading}
            >
              <Ionicons name="close-circle-outline" size={20} color="#FCA5A5" />
              <Text style={styles.dangerBtnText}>Cancel booking</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 15 },
  content: { paddingBottom: 48 },

  mapWrap: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 16,
  },
  mapPlaceholder: {
    width: '100%',
    borderRadius: 16,
    backgroundColor: 'rgba(30,41,59,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  mapPlaceholderText: {
    color: 'rgba(135,206,235,0.6)',
    fontSize: 14,
    fontWeight: '500',
  },

  detailCard: {
    padding: 20,
    marginBottom: 24,
    borderRadius: 20,
  },
  hero: {
    alignItems: 'center',
    marginBottom: 20,
  },
  heroIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  heroAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  heroInitial: {
    color: '#F1F5F9',
    fontSize: 26,
    fontWeight: '700',
  },
  heroName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 10,
  },
  infoRows: { gap: 12 },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  infoText: {
    flex: 1,
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '500',
    lineHeight: 22,
  },
  infoPrice: {
    fontWeight: '700',
    color: SKY,
  },

  actions: { gap: 12 },
  dangerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.4)',
    backgroundColor: 'rgba(239,68,68,0.12)',
  },
  dangerBtnText: { color: '#FCA5A5', fontSize: 15, fontWeight: '700' },
});
