/**
 * Redirect: bookings list removed; go to history.
 */
import { useEffect } from 'react';
import { router } from 'expo-router';

export default function BookingsRedirect() {
  useEffect(() => {
    router.replace('/business/bookings/activity');
  }, []);
  return null;
}
