/**
 * Business live tracking for a single booking.
 * Full-screen map + inline bottom sheet (same position/style as business locations sheet),
 * with tracking progress, status action button, and chat.
 */
import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Dimensions,
  Animated,
  PanResponder,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import MapView, { Marker, Region } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import InfoBottomSheet, { infoBottomSheetContentStyles as sheetStyles } from '../../../src/components/shared/InfoBottomSheet';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { colors } from '../../../src/constants/colors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../../src/components/LoadingScreen';
import BusinessSheetBackground from '../../../src/components/shared/BusinessSheetBackground';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { MAP_LOCKED_DARK } from '../../../src/constants/mapConstants';
import { HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER, BOOKING_SHEET_DARK_OVERLAY } from '../../../src/constants/bookingCardTheme';
import {
  getStages,
  getStageProgressPercent,
  getStatusForStageIndex,
  type BookingStatus as HelperBookingStatus,
} from '../../../src/utils/trackingStatusHelpers';
import { canOpenLiveTracking } from '../../../src/utils/businessBookingAccess';
import { fetchProfileById, resolveCustomerAvatarFromProfileRow } from '../../../src/utils/customerProfiles';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';

const HANDLE_H = 24;
/** Match Archive 2 owner tracking: sheet height 35% of screen */
const TRACKING_SHEET_MAX_HEIGHT_RATIO = 0.35;
const SHEET_HEIGHT = height * TRACKING_SHEET_MAX_HEIGHT_RATIO;
const ACTIONS_BAR_HEIGHT = 52;
const TOTAL_SHEET_HEIGHT = SHEET_HEIGHT + ACTIONS_BAR_HEIGHT;
const DRAG_CLOSE_THRESHOLD = 80;
const DRAG_VELOCITY_THRESHOLD = 0.3;
const MAX_PEEK_DRAG = 48; // slight drag only; full swipe still closes

type BookingStatus =
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'scheduled'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

const DEFAULT_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function BusinessBookingTracking() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = typeof params.bookingId === 'string' && params.bookingId !== 'undefined' ? params.bookingId : null;
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme } = useAccountTheme();

  const [booking, setBooking] = useState<any | null>(null);
  const [status, setStatus] = useState<BookingStatus>('pending_payment');
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [hubLocation, setHubLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<{
    registration?: string;
    make?: string;
    model?: string;
    photo?: string;
    summaryLine?: string;
  } | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [infoSheetVisible, setInfoSheetVisible] = useState(false);
  const [customerProfilePhoto, setCustomerProfilePhoto] = useState<string | null>(null);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
  }, [bookingId]);

  useEffect(() => {
    if (!bookingId) return;
    const ch = supabase
      .channel(`business-tracking-${bookingId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${bookingId}` },
        (payload) => {
          const row = payload.new as Record<string, unknown> | null;
          if (!row) return;
          const next = row.status as string | undefined;
          const sched = row.scheduled_at as string | null | undefined;
          if (next && !canOpenLiveTracking(sched, next)) {
            Alert.alert(
              'Tracking unavailable',
              ['completed', 'cancelled'].includes(String(next).toLowerCase())
                ? 'This booking has ended.'
                : 'Live tracking unlocks 30 minutes before the scheduled start.'
            );
            router.replace({ pathname: '/business/bookings/[id]', params: { id: bookingId! } } as any);
            return;
          }
          if (next) setStatus(next as BookingStatus);
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [bookingId]);

  const loadBooking = async () => {
    if (!bookingId) return;
    setVehicleDetails(null);
    setCustomerProfilePhoto(null);
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', bookingId).single();
      if (error || !data) {
        Alert.alert('Error', 'Booking not found');
        router.back();
        return;
      }
      let bookingData = { ...data } as any;
      const userId = (data as any).user_id;
      if (userId) {
        const profile = await fetchProfileById(userId);
        const name = profile?.full_name || profile?.name;
        if (name) bookingData.customer_name = name;
        setCustomerProfilePhoto(resolveCustomerAvatarFromProfileRow(profile));
      }
      const st = String(bookingData.status || '');
      if (!canOpenLiveTracking(bookingData.scheduled_at, st)) {
        Alert.alert(
          'Tracking unavailable',
          ['completed', 'cancelled'].includes(st.toLowerCase())
            ? 'This booking has ended.'
            : 'Live tracking unlocks 30 minutes before the scheduled start.'
        );
        router.replace({ pathname: '/business/bookings/[id]', params: { id: bookingId! } } as any);
        return;
      }

      setBooking(bookingData);
      setStatus((data.status as BookingStatus) || 'confirmed');
      const lat = data.location_lat ?? data.customer_lat;
      const lng = data.location_lng ?? data.customer_lng;
      if (lat != null && lng != null) {
        setRegion({
          latitude: Number(lat),
          longitude: Number(lng),
          latitudeDelta: 0.012,
          longitudeDelta: 0.012,
        });
      }
      const orgId = (data as any).organization_id ?? user?.organizationId ?? null;
      if (orgId) {
        const { data: loc } = await supabase
          .from('car_wash_locations')
          .select('latitude, longitude')
          .eq('organization_id', orgId)
          .not('latitude', 'is', null)
          .limit(1)
          .maybeSingle();
        if (loc && (loc as any).latitude != null) {
          setHubLocation({ lat: Number((loc as any).latitude), lng: Number((loc as any).longitude) });
        }
      }
      if (userId) {
        const vehicleId = (booking as any)?.vehicle_id as string | undefined;
        let vehicles: any = null;
        if (vehicleId) {
          const { data } = await supabase
            .from('customer_vehicles')
            .select('registration, make, model, photo')
            .eq('id', vehicleId)
            .maybeSingle();
          vehicles = data;
        }
        if (!vehicles) {
          const { data } = await supabase
            .from('customer_vehicles')
            .select('registration, make, model, photo')
            .eq('user_id', userId)
            .eq('is_default', true)
            .limit(1)
            .maybeSingle();
          vehicles = data;
        }
        if (vehicles || (booking as any)?.vehicle_info) {
          setVehicleDetails({
            registration: vehicles?.registration ?? undefined,
            make: vehicles?.make ?? undefined,
            model: vehicles?.model ?? undefined,
            photo: vehicles?.photo ?? undefined,
            summaryLine:
              typeof (booking as any)?.vehicle_info === 'string' && (booking as any).vehicle_info.trim()
                ? (booking as any).vehicle_info.trim()
                : undefined,
          });
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to load booking');
      router.back();
    }
  };

  const getProgress = (): number => {
    switch (status) {
      case 'pending_business_acceptance':
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return 10;
      case 'confirmed':
      case 'scheduled':
        return 25;
      case 'en_route':
        return 50;
      case 'arrived':
        return 70;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      case 'cancelled':
        return 0;
      default:
        return 20;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Waiting for payment';
      case 'confirmed':
      case 'scheduled':
        return 'Confirmed';
      case 'en_route':
        return 'Car Care Pro on the way';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Tracking booking';
    }
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'confirmed':
      case 'scheduled':
        return { label: 'Mark customer arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: 'Start wash', action: () => updateStatus('in_progress') };
      case 'in_progress':
        return { label: 'Mark complete', action: () => updateStatus('completed') };
      default:
        return null;
    }
  };

  const updateStatus = async (newStatus: BookingStatus) => {
    if (!bookingId) return;
    hapticFeedback('medium');
    try {
      const { error } = await supabase.from('bookings').update({ status: newStatus }).eq('id', bookingId);
      if (error) throw error;
      setStatus(newStatus);
      if (newStatus === 'completed') {
        Alert.alert('Done', 'Booking marked complete.', [{ text: 'OK', onPress: () => router.back() }]);
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to update');
    }
  };

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';
  const handleCancel = () => {
    if (!canCancel) return;
    hapticFeedback('light');
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? The customer will be notified.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            setCancelling(true);
            const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
            if (error) Alert.alert('Error', error.message);
            else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Booking cancelled.', [{ text: 'OK', onPress: () => router.replace('/business/dashboard') }]);
            }
            setCancelling(false);
          },
        },
      ]
    );
  };

  const handleChat = () => {
    hapticFeedback('light');
    router.push({ pathname: '/business/bookings/chat', params: { id: bookingId } } as any);
  };

  const customerCoords = useMemo(() => {
    if (!booking) return null;
    const lat = booking.location_lat ?? booking.customer_lat;
    const lng = booking.location_lng ?? booking.customer_lng;
    if (lat == null || lng == null) return null;
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [booking]);

  const nextAction = getNextAction();
  const statusMessage = getStatusMessage();
  const isDetailing = booking?.service_type === 'detailing';
  const stages = getStages(status as HelperBookingStatus, isDetailing);
  const stageProgressPercent = getStageProgressPercent(status as HelperBookingStatus, isDetailing);
  const accent = theme.primary ?? SKY;
  const rawSheet = (theme.headerBackground ?? HEADER_STYLE_CARD_GRADIENT) as [string, string];
  const toOpaque = (s: string, alpha: number) => (s.includes('rgba') ? s.replace(/,\s*[\d.]+\)$/, `, ${alpha})`) : `${s}${alpha === 1 ? 'FF' : 'EE'}`);
  const sheetGradient = [toOpaque(rawSheet[0], 1), toOpaque(rawSheet[1] || rawSheet[0], 0.93)] as [string, string];
  const sheetBorder = theme.glassBorder ?? HEADER_STYLE_CARD_BORDER;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const dragOffset = useRef(new Animated.Value(0)).current;
  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 5,
        onPanResponderMove: (_, g) => {
          const dy = g.dy;
          if (dy > 0) dragOffset.setValue(Math.min(dy, MAX_PEEK_DRAG));
        },
        onPanResponderRelease: (_, g) => {
          const { dy, vy } = g;
          const shouldClose = dy > DRAG_CLOSE_THRESHOLD || (dy > 30 && vy > DRAG_VELOCITY_THRESHOLD);
          if (shouldClose) {
            Animated.timing(dragOffset, {
              toValue: TOTAL_SHEET_HEIGHT,
              duration: 220,
              useNativeDriver: true,
            }).start(() => router.back());
          } else {
            Animated.spring(dragOffset, {
              toValue: 0,
              useNativeDriver: true,
              damping: 25,
              stiffness: 300,
            }).start();
          }
        },
      }),
    [dragOffset]
  );

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (status === 'cancelled') {
      router.replace('/business/dashboard');
      return;
    }
    if (status === 'completed') {
      router.replace('/business/bookings/activity');
    }
  }, [status, router]);

  if (status === 'completed' || status === 'cancelled') return null;
  if (!bookingId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />
        <View style={styles.centered}>
          <Text style={styles.errorText}>No booking selected</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return <LoadingScreen message="Loading…" />;
  }

  const mapRegion: Region = customerCoords
    ? { ...region, latitude: customerCoords.latitude, longitude: customerCoords.longitude }
    : region;

  const vehiclePhoto = vehicleDetails?.photo ?? (booking as any)?.vehicle_photo;
  const vehicleSummary =
    vehicleDetails?.summaryLine ||
    (typeof (booking as any)?.vehicle_info === 'string' ? String((booking as any).vehicle_info).trim() : '') ||
    null;
  const vehicleReg = vehicleSummary
    ? null
    : vehicleDetails?.registration ?? (booking as any)?.vehicle_registration ?? (booking as any)?.registration;
  const vehicleMakeModel = vehicleSummary
    ? vehicleSummary
    : [vehicleDetails?.make ?? (booking as any)?.vehicle_make, vehicleDetails?.model ?? (booking as any)?.vehicle_model]
        .filter(Boolean)
        .join(' ');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background as [string, string]} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <View style={styles.mapWrap}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={mapRegion}
          onRegionChangeComplete={setRegion}
          customMapStyle={DARK_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          mapPadding={{ top: 0, bottom: Math.round(height * TRACKING_SHEET_MAX_HEIGHT_RATIO) + 80, left: 0, right: 0 }}
        >
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.lat, longitude: hubLocation.lng }}>
              <View style={styles.hubMarker}>
                <Ionicons name="business" size={22} color="#fff" />
              </View>
            </Marker>
          )}
          {customerCoords && (
            <Marker coordinate={customerCoords}>
              <View style={styles.jobMarker}>
                <Ionicons name="location" size={24} color="#fff" />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <View style={styles.headerOverlay}>
        <AppHeader title="Tracking" accountType="business" showBack onBack={() => router.back()} />
      </View>

      <Animated.View
        style={[
          styles.trackingSheetContainer,
          { height: TOTAL_SHEET_HEIGHT, transform: [{ translateY: dragOffset }] },
        ]}
      >
        <View style={styles.trackSheetChatRow}>
          <TouchableOpacity onPress={handleCancel} disabled={!canCancel || cancelling} style={[styles.trackSheetInfoBtn, styles.bookingInfoCancelBtn]} hitSlop={12} activeOpacity={0.8}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
            {cancelling ? (
              <ActivityIndicator size="small" color="#EF4444" />
            ) : (
              <Ionicons name="trash-outline" size={20} color={canCancel ? '#EF4444' : '#64748B'} style={styles.trackSheetInfoBtnIcon} />
            )}
          </TouchableOpacity>
        </View>

        <View style={[styles.trackSheetPanel, { borderColor: sheetBorder }]}>
          <BusinessSheetBackground />
          <View style={styles.trackSheetDragArea} {...panResponder.panHandlers} />
          <View style={[styles.trackSheetHandle, { backgroundColor: accent + '50' }]} />
          <View style={styles.trackSheetBody}>
            <Animated.View style={{ opacity: fadeAnim }}>
              <View style={styles.smallTrackingCardWrap}>
                <View style={[styles.smallTrackingCard, { borderColor: sheetBorder }]}>
                  <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
                  <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
                  <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                  <View style={[styles.smallTrackingCardGlowOverlay, { borderColor: accent + '40', shadowColor: accent }]} pointerEvents="none" />
                  <View style={styles.smallTrackingCardContent}>
                    <View style={styles.smallCardRow}>
                      <View style={styles.smallCardBody}>
                        <Text style={styles.smallCardService} numberOfLines={1}>{getServiceDisplayName(booking.service_type, booking.service_name)}</Text>
                        <Text style={[styles.smallCardStatus, { color: accent }]} numberOfLines={1}>{statusMessage}</Text>
                      </View>
                      <View style={[styles.smallRingWrap, { borderColor: accent + '60', backgroundColor: accent + '12' }]}>
                        <AnimatedProgress progress={getProgress()} size={58} strokeWidth={6} showPercentage color={accent} gamified />
                      </View>
                    </View>
                    <View style={styles.smallCardProgressWrap}>
                      <View style={[styles.smallCardProgressTrack, { borderColor: accent + '25' }]}>
                        <View style={[styles.smallCardProgressFill, { width: `${stageProgressPercent}%`, backgroundColor: accent }]} />
                      </View>
                      <View style={styles.smallStagesRow}>
                        {stages.map((stage) => {
                          const iconName = stage.icon === 'location' ? 'locate' : stage.icon;
                          let stageIconColor = '#94A3B8';
                          if (stage.current) stageIconColor = accent;

                          let stageIcon: React.ReactNode;
                          if (stage.done) {
                            stageIcon = <Ionicons name="checkmark" size={10} color="#FFFFFF" />;
                          } else {
                            stageIcon = <Ionicons name={iconName as any} size={10} color={stageIconColor} />;
                          }

                          return (
                            <View key={stage.label} style={styles.smallStageItem}>
                              <View
                                style={[
                                  styles.smallStageDot,
                                  stage.done && styles.smallStageDotDone,
                                  stage.current && [styles.smallStageDotCurrent, { borderColor: accent }],
                                ]}
                              >
                                {stageIcon}
                              </View>
                              <Text
                                style={[
                                  styles.smallStageLabel,
                                  stage.done && styles.smallStageLabelDone,
                                  stage.current && { color: accent, fontWeight: '700' },
                                ]}
                                numberOfLines={1}
                              >
                                {stage.label}
                              </Text>
                            </View>
                          );
                        })}
                      </View>
                    </View>
                  </View>
                </View>
              </View>
              <View style={styles.bookingInfoRow}>
                <View style={styles.bookingInfoSideSlot}>
                  <TouchableOpacity onPress={handleChat} style={[styles.trackSheetInfoBtn, { borderColor: accent + '55' }]} activeOpacity={0.85}>
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                    <Ionicons name="chatbubble-ellipses-outline" size={22} color={accent} style={styles.trackSheetInfoBtnIcon} />
                  </TouchableOpacity>
                </View>
                <View style={styles.bookingInfoCenterSlot}>
                  {nextAction ? (
                    <TouchableOpacity onPress={nextAction.action} style={[styles.bookingInfoCard, styles.bookingInfoActionCard, { borderColor: accent + '55' }]} activeOpacity={0.85}>
                      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                      <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                      <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                      <Ionicons name="arrow-forward" size={22} color={accent} />
                      <View style={styles.bookingInfoCardTextWrap}>
                        <Text style={[styles.bookingInfoCardText, { color: accent }]}>{nextAction.label}</Text>
                      </View>
                    </TouchableOpacity>
                  ) : null}
                </View>
                <View style={styles.bookingInfoSideSlot}>
                  <TouchableOpacity onPress={() => { hapticFeedback('light'); setInfoSheetVisible(true); }} style={[styles.trackSheetInfoBtn, { borderColor: accent + '55' }]} activeOpacity={0.85}>
                    <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <LinearGradient colors={sheetGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <View style={[StyleSheet.absoluteFill, styles.trackSheetDarkOverlay]} pointerEvents="none" />
                    <Ionicons name="information-circle-outline" size={22} color={accent} style={styles.trackSheetInfoBtnIcon} />
                  </TouchableOpacity>
                </View>
              </View>
            </Animated.View>
          </View>
        </View>
      </Animated.View>

      <InfoBottomSheet
        visible={infoSheetVisible}
        onClose={() => setInfoSheetVisible(false)}
        title="Job details"
        accentColor={accent}
        contentMaxHeight="78%"
      >
        {booking ? (
          <View style={styles.jobInfoProfile}>
            <View style={styles.jobInfoProfileHeader}>
              <View style={[styles.jobInfoAvatar, { borderColor: accent }]}>
                {customerProfilePhoto ? (
                  <Image source={{ uri: customerProfilePhoto }} style={styles.jobInfoAvatarImage} resizeMode="cover" />
                ) : (
                  <Ionicons name="person" size={36} color={accent} />
                )}
              </View>
              <Text style={styles.jobInfoProfileName}>{booking.customer_name ?? 'Customer'}</Text>
              <Text style={[styles.jobInfoProfileHeadline, { color: accent }]}>
                {getServiceDisplayName(booking.service_type, booking.service_name)}
              </Text>
              <View style={[styles.jobInfoProfileMeta, { backgroundColor: accent + '22', borderColor: accent + '44' }]}>
                <Ionicons name="person-circle-outline" size={14} color={accent} />
                <Text style={[styles.jobInfoOwnerLabel, { color: accent }]}>Owner</Text>
              </View>
            </View>

            <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
              <View style={styles.jobInfoSectionHeader}>
                <Ionicons name="time-outline" size={18} color={accent} />
                <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Status</Text>
              </View>
              <Text style={styles.jobInfoSectionText}>{statusMessage}</Text>
            </View>

            {vehicleDetails?.photo ? (
              <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
                <View style={styles.jobInfoSectionHeader}>
                  <Ionicons name="car-outline" size={18} color={accent} />
                  <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>{"Customer's car"}</Text>
                </View>
                <View style={styles.carImageWrap}>
                  <Image source={{ uri: vehicleDetails.photo }} style={styles.carImage} resizeMode="cover" />
                </View>
              </View>
            ) : null}
            {(vehicleSummary || vehicleReg || vehicleMakeModel || vehicleDetails?.registration || vehicleDetails?.make || booking.vehicle_registration || booking.vehicle_make || booking.vehicle_model) ? (
              <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
                <View style={styles.jobInfoSectionHeader}>
                  <Ionicons name="car-outline" size={18} color={accent} />
                  <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>
                    {vehicleSummary && vehicleSummary.includes('·') ? 'Vehicles' : 'Vehicle'}
                  </Text>
                </View>
                <Text style={styles.jobInfoSectionText}>
                  {vehicleSummary ||
                    [vehicleReg, vehicleMakeModel].filter(Boolean).join(' · ') ||
                    [
                      vehicleDetails?.registration ?? booking.vehicle_registration,
                      vehicleDetails?.make ?? booking.vehicle_make,
                      vehicleDetails?.model ?? booking.vehicle_model,
                    ]
                      .filter(Boolean)
                      .join(' · ') ||
                    '—'}
                </Text>
              </View>
            ) : null}

            <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
              <View style={styles.jobInfoSectionHeader}>
                <Ionicons name="location-outline" size={18} color={accent} />
                <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Location</Text>
              </View>
              <Text style={styles.jobInfoSectionText}>{booking.location_address || '—'}</Text>
            </View>

            <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
              <View style={styles.jobInfoSectionHeader}>
                <Ionicons name="wallet-outline" size={18} color={accent} />
                <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Price</Text>
              </View>
              <Text style={[styles.jobInfoSectionText, styles.jobInfoPrice]}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
            </View>

            {booking.scheduled_at ? (
              <View style={[styles.jobInfoSection, { borderColor: accent + '30' }]}>
                <View style={styles.jobInfoSectionHeader}>
                  <Ionicons name="calendar-outline" size={18} color={accent} />
                  <Text style={[styles.jobInfoSectionTitle, { color: accent }]}>Scheduled</Text>
                </View>
                <Text style={styles.jobInfoSectionText}>
                  {new Date(booking.scheduled_at).toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'short' })}
                </Text>
              </View>
            ) : null}
          </View>
        ) : null}
      </InfoBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16 },
  errorText: { color: '#F9FAFB', fontSize: 16 },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#fff', fontWeight: '700' },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
  loadingText: { color: SKY, fontSize: 14 },
  mapWrap: { ...StyleSheet.absoluteFillObject },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  iconBtnDisabled: { opacity: 0.6 },
  floatingActionsRow: {
    position: 'absolute',
    right: 20,
    zIndex: 10,
    flexDirection: 'row',
    gap: 10,
  },
  floatingIconBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  trackingSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  trackSheetChatRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 20,
    paddingBottom: 6,
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  trackSheetChatBtn: {
    overflow: 'hidden',
    borderRadius: 18,
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    minWidth: 100,
  },
  trackSheetArrivedBtn: {},
  trackSheetChatBtnContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    zIndex: 1,
  },
  trackSheetChatBtnText: {
    fontSize: 15,
    fontWeight: '700',
  },
  trackSheetInfoBtn: {
    overflow: 'hidden',
    width: 46,
    height: 46,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackSheetInfoBtnIcon: { zIndex: 1 },
  trackSheetPanel: {
    flex: 1,
    backgroundColor: 'transparent',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingTop: 6,
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  trackSheetDarkOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  trackSheetDragArea: {
    width: '100%',
    height: 20,
    marginBottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackSheetHandle: {
    width: 36,
    height: 3,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 8,
  },
  trackSheetBody: {
    flex: 1,
    minHeight: 0,
    marginTop: 4,
    overflow: 'hidden',
  },
  smallTrackingCardWrap: { paddingHorizontal: 0 },
  smallTrackingCard: {
    overflow: 'hidden',
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  smallTrackingCardGlowOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 22,
    borderWidth: 1,
    backgroundColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 2,
  },
  smallTrackingCardContent: {
    padding: 18,
    paddingVertical: 16,
  },
  smallCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  smallRingWrap: {
    marginLeft: 12,
    padding: 2,
    borderRadius: 31,
    borderWidth: 1,
  },
  smallCardBody: { flex: 1, minWidth: 0 },
  smallCardService: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1.4,
    marginBottom: 2,
  },
  smallCardStatus: { fontSize: 15, fontWeight: '800', letterSpacing: 0.4 },
  smallCardProgressWrap: { marginBottom: 10 },
  smallCardProgressTrack: {
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 8,
    borderWidth: 1,
  },
  smallCardProgressFill: { height: '100%', borderRadius: 2 },
  smallStagesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  smallStageItem: { flex: 1, alignItems: 'center', minWidth: 0 },
  smallStageDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(100,116,139,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  smallStageDotDone: {
    backgroundColor: 'rgba(16,185,129,0.9)',
    borderColor: '#10B981',
  },
  smallStageDotCurrent: {
    backgroundColor: SKY + '30',
    borderWidth: 1.5,
  },
  smallStageLabel: {
    fontSize: 9,
    fontWeight: '600',
    color: '#94A3B8',
    letterSpacing: 0.2,
  },
  smallStageLabelDone: { color: '#34D399', fontWeight: '700' },
  bookingInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 10,
  },
  bookingInfoSideSlot: {
    width: 46,
    flexShrink: 0,
  },
  bookingInfoCenterSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 0,
  },
  bookingInfoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    minWidth: 0,
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    gap: 12,
  },
  bookingInfoActionCard: {
    overflow: 'hidden',
    position: 'relative',
  },
  bookingInfoCardTextWrap: { flex: 1, minWidth: 0, zIndex: 1 },
  bookingInfoCardText: { fontSize: 15, fontWeight: '700' },
  bookingInfoCancelBtn: {
    overflow: 'hidden',
    position: 'relative',
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#8B5CF6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  jobMarker: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(30,58,138,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: SKY,
  },
  infoModalBody: { gap: 10, marginBottom: 18 },
  jobInfoProfile: { paddingBottom: 24 },
  jobInfoProfileHeader: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  jobInfoAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    overflow: 'hidden',
  },
  jobInfoAvatarImage: {
    width: '100%',
    height: '100%',
    borderRadius: 38,
  },
  jobInfoProfileName: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
    textAlign: 'center',
  },
  jobInfoProfileHeadline: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
    opacity: 0.95,
  },
  jobInfoProfileMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  jobInfoOwnerLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  jobInfoSection: {
    padding: 14,
    marginBottom: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  jobInfoSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  jobInfoSectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  jobInfoSectionText: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
    paddingLeft: 26,
  },
  jobInfoPrice: { fontWeight: '700', color: '#F9FAFB' },
  carImageWrap: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    marginTop: 8,
  },
  carImage: { width: '100%', height: '100%' },
});
