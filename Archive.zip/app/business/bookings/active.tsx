/**
 * Redirect: active bookings are now shown on the main map view.
 */
import { useEffect } from 'react';
import { router } from 'expo-router';

export default function ActiveBookingsRedirect() {
  useEffect(() => {
    router.replace('/business/bookings/activity');
  }, []);
  return null;
}
