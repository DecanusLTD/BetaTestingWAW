/**
 * Valeter Stripe Connect — calm 3-step payout setup process.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  Modal,
  Pressable,
  Animated,
  Easing,
  LayoutAnimation,
  Platform,
  UIManager,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { stripeConnectService } from '../../src/services/stripeConnectService';
import {
  valeterStripeConnectService,
  type StripeConnectStatus,
  type ValeterStripeConnectStatus,
} from '../../src/services/valeterStripeConnectService';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import LoadingScreen from '../../src/components/LoadingScreen';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const STEPS = [
  { id: 1, label: 'Connect', title: 'Link your payout account' },
  { id: 2, label: 'Verify', title: 'Stripe is checking your details' },
  { id: 3, label: 'Ready', title: "You're ready to get paid" },
] as const;

function stepIndexForStatus(status: StripeConnectStatus | undefined): number {
  switch (status) {
    case 'completed':
      return 3;
    case 'in_progress':
    case 'restricted':
    case 'rejected':
      return 2;
    case 'not_started':
    default:
      return 1;
  }
}

function shortenAccountId(id: string | null | undefined): string {
  if (!id || id.length < 12) return id || 'Not linked yet';
  return `${id.slice(0, 10)}…${id.slice(-4)}`;
}

function formatRelativeTimestamp(value: string | null | undefined): string {
  if (!value) return 'Not synced yet';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.max(1, Math.round(diffMs / 60000));
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${Math.round(diffHours / 24)}d ago`;
}

function ProgressRail({
  activeStep,
  accent,
  gold,
  attention,
}: Readonly<{ activeStep: number; accent: string; gold: string; attention: boolean }>) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse, activeStep]);

  return (
    <View style={styles.rail}>
      {STEPS.map((step, index) => {
        const n = step.id;
        const done = n < activeStep;
        const current = n === activeStep;
        const lineDone = n < activeStep;
        return (
          <React.Fragment key={step.id}>
            {index > 0 ? (
              <View
                style={[
                  styles.railLine,
                  { backgroundColor: lineDone || done ? accent : 'rgba(255,255,255,0.14)' },
                ]}
              />
            ) : null}
            <View style={styles.railNodeWrap}>
              <Animated.View
                style={[
                  styles.railNode,
                  {
                    borderColor: done || current ? (attention && current ? '#FCA5A5' : accent) : 'rgba(255,255,255,0.2)',
                    backgroundColor: done
                      ? accent
                      : current
                        ? attention
                          ? 'rgba(248,113,113,0.22)'
                          : `${accent}28`
                        : 'rgba(255,255,255,0.06)',
                    transform: current
                      ? [
                          {
                            scale: pulse.interpolate({
                              inputRange: [0, 1],
                              outputRange: [1, 1.08],
                            }),
                          },
                        ]
                      : undefined,
                  },
                ]}
              >
                {done ? (
                  <Ionicons name="checkmark" size={16} color="#0A1929" />
                ) : (
                  <Text
                    style={[
                      styles.railNodeText,
                      { color: current ? (attention ? '#FCA5A5' : accent) : 'rgba(248,250,252,0.45)' },
                    ]}
                  >
                    {n}
                  </Text>
                )}
              </Animated.View>
              <Text
                style={[
                  styles.railLabel,
                  {
                    color: current ? gold : done ? 'rgba(248,250,252,0.78)' : 'rgba(248,250,252,0.4)',
                    fontWeight: current ? '800' : '600',
                  },
                ]}
              >
                {step.label}
              </Text>
            </View>
          </React.Fragment>
        );
      })}
    </View>
  );
}

export default function ValeterStripeConnectScreen() {
  const { user, logout } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const primary = theme.primary || '#9EC9E0';
  const gold = theme.accentAlt || '#E8C547';
  const isOnboardingMode = params?.mode === 'onboarding';
  const autoSyncAttemptedRef = useRef(false);
  const autoStartAttemptedRef = useRef(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [status, setStatus] = useState<ValeterStripeConnectStatus | null>(null);
  const [syncFlashVisible, setSyncFlashVisible] = useState(false);
  const [syncFlashKind, setSyncFlashKind] = useState<'success' | 'error'>('success');
  const [detailsOpen, setDetailsOpen] = useState(false);
  const syncFlashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const syncInFlightRef = useRef(false);
  const [dialogVisible, setDialogVisible] = useState(false);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogMessage, setDialogMessage] = useState('');
  const [dialogType, setDialogType] = useState<'error' | 'warning' | 'info'>('info');
  const [dialogActions, setDialogActions] = useState<
    Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }>
  >([]);

  const surface = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const panel = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const border = isLight ? theme.glassBorder || 'rgba(158,201,224,0.42)' : 'rgba(255,255,255,0.12)';
  const textMain = theme.textPrimary || '#F8FAFC';
  const textMuted = theme.textOnBackground || 'rgba(248,250,252,0.66)';

  const openDialog = (
    title: string,
    message: string,
    type: 'error' | 'warning' | 'info' = 'info',
    actions: Array<{ label: string; kind?: 'primary' | 'secondary' | 'danger'; onPress?: () => void }> = [
      { label: 'Close', kind: 'primary' },
    ]
  ) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogType(type);
    setDialogActions(actions);
    setDialogVisible(true);
  };

  const load = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const next = await valeterStripeConnectService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [user?.id]);

  useEffect(() => {
    if (!params?.stripe_return && !params?.stripe_refresh) return;
    void handleCheckStatus(true);
  }, [params?.stripe_return, params?.stripe_refresh]);

  const startConnect = async () => {
    if (saving || !user?.id) return;
    try {
      await hapticFeedback('light');
      setSaving(true);
      const onboardingLink = await stripeConnectService.createOnboardingLink();
      await valeterStripeConnectService.startStripeConnect(user.id);
      await Linking.openURL(onboardingLink.url);
    } catch (error: any) {
      openDialog('Unable to start Stripe Connect', error?.message || 'Failed to start Stripe Connect.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const reloadStatusQuietly = async () => {
    if (!user?.id) return;
    try {
      const next = await valeterStripeConnectService.getStatus(user.id);
      setStatus(next);
    } catch (error: any) {
      openDialog('Unable to load Stripe setup', error?.message || 'Failed to load Stripe Connect status.', 'error');
    }
  };

  const showSyncFlash = (kind: 'success' | 'error') => {
    if (syncFlashTimerRef.current) clearTimeout(syncFlashTimerRef.current);
    // Keep kind set while hiding so the fade-out doesn't flip to the error (red) styles.
    setSyncFlashKind(kind);
    setSyncFlashVisible(true);
    syncFlashTimerRef.current = setTimeout(() => {
      setSyncFlashVisible(false);
      syncFlashTimerRef.current = null;
    }, 1800);
  };

  useEffect(() => {
    return () => {
      if (syncFlashTimerRef.current) clearTimeout(syncFlashTimerRef.current);
    };
  }, []);

  const handleCheckStatus = async (silent = false) => {
    if (saving || syncInFlightRef.current || !user?.id) return;
    syncInFlightRef.current = true;
    try {
      await hapticFeedback('light');
      setRefreshing(true);
      const result = await stripeConnectService.syncStatusFromStripe();
      await valeterStripeConnectService.setStripeStatus(user.id, {
        stripeConnectStatus: result.stripeConnectStatus,
        stripeAccountId: result.stripeAccountId,
        stripeDetails: {
          detailsSubmitted: result.detailsSubmitted,
          chargesEnabled: result.chargesEnabled,
          payoutsEnabled: result.payoutsEnabled,
          updated_from_stripe_at: new Date().toISOString(),
        },
        stripeOnboardingCompletedAt:
          result.stripeConnectStatus === 'completed' ? new Date().toISOString() : undefined,
        stripeOnboardingStartedAt:
          result.stripeConnectStatus !== 'not_started' ? new Date().toISOString() : undefined,
      });
      await reloadStatusQuietly();
      if (result.stripeConnectStatus === 'completed') {
        showSyncFlash('success');
        return;
      }
      if (!silent && (result.stripeConnectStatus === 'restricted' || result.stripeConnectStatus === 'rejected')) {
        showSyncFlash('error');
      }
    } catch (error: any) {
      if (!silent) showSyncFlash('error');
      else openDialog('Unable to check Stripe status', error?.message || 'Failed to check Stripe status.', 'error');
    } finally {
      syncInFlightRef.current = false;
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (loading || saving || refreshing || autoSyncAttemptedRef.current) return;
    if (!status?.stripeAccountId || status.stripeConnectStatus === 'completed') return;
    autoSyncAttemptedRef.current = true;
    void handleCheckStatus(true);
  }, [loading, saving, refreshing, status?.stripeAccountId, status?.stripeConnectStatus]);

  /** Onboarding: open Stripe Express as soon as the screen is ready (don’t wait for a tap). */
  useEffect(() => {
    if (!isOnboardingMode || loading || saving || !user?.id) return;
    if (autoStartAttemptedRef.current) return;
    if (status?.stripeConnectStatus === 'completed') return;
    if (params?.stripe_return || params?.stripe_refresh) return;
    autoStartAttemptedRef.current = true;
    const t = setTimeout(() => {
      void startConnect();
    }, 450);
    return () => clearTimeout(t);
  }, [isOnboardingMode, loading, saving, user?.id, status?.stripeConnectStatus, params?.stripe_return, params?.stripe_refresh]);

  const handleBackOrLogout = async () => {
    if (saving) return;
    if (isOnboardingMode) {
      try {
        await hapticFeedback('medium');
        setSaving(true);
        await logout();
        router.replace('/auth/login');
      } catch (error: any) {
        openDialog('Unable to log out', error?.message || 'Failed to log out.', 'error');
      } finally {
        setSaving(false);
      }
      return;
    }
    router.back();
  };

  const stripeState = status?.stripeConnectStatus ?? 'not_started';
  const activeStep = stepIndexForStatus(stripeState);
  const isComplete = stripeState === 'completed';
  const attention = stripeState === 'restricted' || stripeState === 'rejected';
  const hasStarted = stripeState !== 'not_started';

  const copy = useMemo(() => {
    if (stripeState === 'completed') {
      return {
        title: "You're ready to get paid",
        body: 'Your payout account is linked. Accept jobs and earnings flow through Stripe securely.',
      };
    }
    if (stripeState === 'restricted') {
      return {
        title: 'Stripe needs a little more',
        body: 'Open Stripe to finish the remaining verification steps, then refresh here.',
      };
    }
    if (stripeState === 'rejected') {
      return {
        title: 'Stripe needs updated details',
        body: 'Review the information in Stripe, update what’s needed, then refresh status here.',
      };
    }
    if (stripeState === 'in_progress') {
      return {
        title: 'Stripe is checking your details',
        body: 'Finish any open steps in Stripe’s secure form, then return here and refresh.',
      };
    }
    return {
      title: 'Link your payout account',
      body: 'Connect once with Stripe so Wish a Washer can pay you for completed jobs.',
    };
  }, [stripeState]);

  const primaryLabel = (() => {
    if (isComplete) return isOnboardingMode ? 'Continue to app' : 'Done';
    if (stripeState === 'restricted' || stripeState === 'rejected') return 'Fix in Stripe';
    if (stripeState === 'in_progress') return 'Finish in Stripe';
    return 'Connect with Stripe';
  })();

  const onPrimary = () => {
    if (isComplete) {
      if (isOnboardingMode) router.replace('/valeter/valeter-dashboard');
      else router.back();
      return;
    }
    void startConnect();
  };

  const stripeDetails = status?.stripeDetails ?? {};
  const stripeSyncedAt =
    (stripeDetails as Record<string, any>).updated_from_stripe_at ??
    (stripeDetails as Record<string, any>).updated_from_stripe_webhook_at ??
    status?.stripeOnboardingCompletedAt ??
    status?.stripeOnboardingStartedAt ??
    null;

  if (loading) {
    return <LoadingScreen message="Loading payout setup…" />;
  }

  return (
    <View style={styles.flex}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <SafeAreaView style={styles.flex} edges={[]}>
        <ValeterScreenHeader
          title="Payout setup"
          rightAction={
            <View style={styles.headerActions}>
              <TouchableOpacity
                style={[styles.headerIconBtn, { borderColor: `${primary}40` }]}
                onPress={() => handleCheckStatus(false)}
                disabled={saving || refreshing}
                activeOpacity={0.85}
                accessibilityLabel="Refresh Stripe status"
              >
                {refreshing ? (
                  <ActivityIndicator size="small" color={textMain} />
                ) : (
                  <Ionicons name="refresh-outline" size={18} color={textMain} />
                )}
              </TouchableOpacity>
              {isOnboardingMode ? (
                <TouchableOpacity
                  style={[styles.logoutBtn, { borderColor: `${primary}40` }]}
                  onPress={handleBackOrLogout}
                  activeOpacity={0.85}
                >
                  <Ionicons name="log-out-outline" size={18} color={textMain} />
                  <Text style={[styles.logoutText, { color: textMain }]}>Log out</Text>
                </TouchableOpacity>
              ) : null}
            </View>
          }
        />

        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollInner,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 8,
              paddingBottom: 24 + insets.bottom,
            },
          ]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                void handleCheckStatus(true);
              }}
              tintColor={primary}
              colors={[primary]}
              progressBackgroundColor="rgba(15,30,48,0.9)"
            />
          }
        >
          <View style={styles.logoRow}>
            <Image
              source={require('../../assets/stripe/img.png')}
              style={styles.stripeLogo}
              resizeMode="contain"
            />
          </View>

          <ProgressRail activeStep={activeStep} accent={primary} gold={gold} attention={attention} />

          {isComplete || attention ? (
            <View
              style={[
                styles.resultCard,
                isComplete ? styles.resultCardSuccess : styles.resultCardError,
              ]}
            >
              <View style={[styles.resultIconWrap, isComplete ? styles.resultIconSuccess : styles.resultIconError]}>
                <Ionicons
                  name={isComplete ? 'checkmark' : 'close'}
                  size={42}
                  color={isComplete ? '#059669' : '#DC2626'}
                />
              </View>
              <Text style={[styles.statusTitle, { color: textMain, textAlign: 'center' }]}>{copy.title}</Text>
              <Text style={[styles.statusBody, { color: textMuted, textAlign: 'center' }]}>{copy.body}</Text>
            </View>
          ) : (
            <View style={[styles.statusCard, { backgroundColor: surface, borderColor: border }]}>
              <Text style={[styles.stepEyebrow, { color: gold }]}>STEP {activeStep} OF 3</Text>
              <Text style={[styles.statusTitle, { color: textMain }]}>{copy.title}</Text>
              <Text style={[styles.statusBody, { color: textMuted }]}>{copy.body}</Text>
            </View>
          )}

          {(isComplete || hasStarted) && (
            <TouchableOpacity
              style={[styles.detailsToggle, { borderColor: border, backgroundColor: panel }]}
              onPress={() => {
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                setDetailsOpen((v) => !v);
              }}
              activeOpacity={0.85}
            >
              <Text style={[styles.detailsToggleText, { color: textMain }]}>Account details</Text>
              <Ionicons name={detailsOpen ? 'chevron-up' : 'chevron-down'} size={18} color={primary} />
            </TouchableOpacity>
          )}

          {detailsOpen ? (
            <View style={[styles.detailsCard, { backgroundColor: panel, borderColor: border }]}>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Account</Text>
                <Text style={[styles.detailValue, { color: textMain }]} numberOfLines={1}>
                  {shortenAccountId(status?.stripeAccountId)}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Payouts</Text>
                <Text style={[styles.detailValue, { color: textMain }]}>
                  {stripeDetails.payoutsEnabled ? 'Enabled' : 'Pending'}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={[styles.detailLabel, { color: textMuted }]}>Last synced</Text>
                <Text style={[styles.detailValue, { color: textMain }]}>
                  {formatRelativeTimestamp(stripeSyncedAt)}
                </Text>
              </View>
            </View>
          ) : null}
        </ScrollView>

        <View style={[styles.footer, { paddingBottom: Math.max(14, insets.bottom + 10) }]}>
          <ContinueCTAButton
            title={primaryLabel}
            onPress={onPrimary}
            accentColor={primary}
            disabled={saving || refreshing}
            loading={saving}
            showTrailingChevron={!saving}
            style={styles.primaryCta}
          />

          {!isComplete ? (
            <TouchableOpacity
              style={[styles.refreshBtn, { borderColor: `${primary}44` }]}
              onPress={() => handleCheckStatus(false)}
              disabled={saving || refreshing}
              activeOpacity={0.88}
            >
              {refreshing ? (
                <ActivityIndicator color={textMain} />
              ) : (
                <>
                  <Ionicons name="refresh-outline" size={18} color={textMain} />
                  <Text style={[styles.refreshText, { color: textMain }]}>Refresh status</Text>
                </>
              )}
            </TouchableOpacity>
          ) : null}

          {isComplete ? (
            <TouchableOpacity style={styles.tertiaryBtn} onPress={startConnect} disabled={saving || refreshing} activeOpacity={0.85}>
              <Text style={[styles.tertiaryText, { color: textMuted }]}>Update Stripe details</Text>
            </TouchableOpacity>
          ) : null}

          <Text style={[styles.footerHint, { color: textMuted }]}>
            {isComplete
              ? 'Stripe controls payout timing and verification.'
              : 'You can leave and finish later — progress is saved.'}
          </Text>
        </View>
      </SafeAreaView>

      <Modal visible={dialogVisible} transparent animationType="fade" onRequestClose={() => setDialogVisible(false)}>
        <Pressable style={styles.dialogOverlay} onPress={() => setDialogVisible(false)}>
          <View
            style={[
              styles.dialogCard,
              dialogType === 'error'
                ? styles.dialogError
                : dialogType === 'warning'
                  ? styles.dialogWarning
                  : styles.dialogInfo,
            ]}
          >
            <Text style={styles.dialogTitle}>{dialogTitle}</Text>
            <Text style={styles.dialogMessage}>{dialogMessage}</Text>
            <View style={styles.dialogActions}>
              {dialogActions.map((action, index) => (
                <TouchableOpacity
                  key={`${action.label}-${index}`}
                  style={[
                    styles.dialogButton,
                    action.kind === 'secondary' && styles.dialogButtonSecondary,
                    action.kind === 'danger' && styles.dialogButtonDanger,
                  ]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setDialogVisible(false);
                    action.onPress?.();
                  }}
                >
                  <Text style={styles.dialogButtonText}>{action.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Pressable>
      </Modal>

      <Modal
        visible={syncFlashVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setSyncFlashVisible(false)}
      >
        <Pressable
          style={[
            styles.flashOverlay,
            syncFlashKind === 'success' ? styles.flashOverlaySuccess : styles.flashOverlayError,
          ]}
          onPress={() => setSyncFlashVisible(false)}
        >
          <View
            style={[
              styles.flashIconWrap,
              syncFlashKind === 'success' ? styles.flashIconSuccess : styles.flashIconError,
            ]}
          >
            <Ionicons
              name={syncFlashKind === 'success' ? 'checkmark' : 'close'}
              size={56}
              color={syncFlashKind === 'success' ? '#059669' : '#DC2626'}
            />
          </View>
          <Text style={styles.flashTitle}>
            {syncFlashKind === 'success' ? 'Connected' : 'Not ready yet'}
          </Text>
          <Text style={styles.flashBody}>
            {syncFlashKind === 'success'
              ? 'Your Stripe payout account is ready.'
              : 'Finish the remaining steps in Stripe, then refresh again.'}
          </Text>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scroll: { flex: 1 },
  scrollInner: {
    paddingHorizontal: 20,
    gap: 16,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerIconBtn: {
    width: 36,
    height: 36,
    borderRadius: 999,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  logoutText: {
    fontSize: 13,
    fontWeight: '800',
  },
  logoRow: {
    alignItems: 'center',
    paddingTop: 4,
  },
  stripeLogo: {
    width: 120,
    height: 48,
  },
  rail: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  railNodeWrap: {
    alignItems: 'center',
    width: 72,
    gap: 8,
  },
  railNode: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  railNodeText: {
    fontSize: 13,
    fontWeight: '800',
  },
  railLabel: {
    fontSize: 11,
    textAlign: 'center',
  },
  railLine: {
    flex: 1,
    height: 2,
    marginTop: 17,
    borderRadius: 1,
    maxWidth: 48,
  },
  statusCard: {
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 18,
    paddingVertical: 18,
    gap: 8,
  },
  resultCard: {
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 20,
    paddingVertical: 28,
    gap: 10,
    alignItems: 'center',
  },
  resultCardSuccess: {
    backgroundColor: 'rgba(16, 185, 129, 0.16)',
    borderColor: 'rgba(16, 185, 129, 0.45)',
  },
  resultCardError: {
    backgroundColor: 'rgba(239, 68, 68, 0.14)',
    borderColor: 'rgba(239, 68, 68, 0.45)',
  },
  resultIconWrap: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
    borderWidth: 2,
  },
  resultIconSuccess: {
    backgroundColor: 'rgba(16, 185, 129, 0.22)',
    borderColor: 'rgba(16, 185, 129, 0.55)',
  },
  resultIconError: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
    borderColor: 'rgba(239, 68, 68, 0.55)',
  },
  flashOverlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 12,
  },
  flashOverlaySuccess: {
    backgroundColor: 'rgba(6, 78, 59, 0.82)',
  },
  flashOverlayError: {
    backgroundColor: 'rgba(127, 29, 29, 0.82)',
  },
  flashIconWrap: {
    width: 104,
    height: 104,
    borderRadius: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    marginBottom: 8,
  },
  flashIconSuccess: {
    backgroundColor: 'rgba(167, 243, 208, 0.95)',
    borderColor: '#6EE7B7',
  },
  flashIconError: {
    backgroundColor: 'rgba(254, 202, 202, 0.95)',
    borderColor: '#FCA5A5',
  },
  flashTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '900',
    textAlign: 'center',
  },
  flashBody: {
    color: 'rgba(249,250,251,0.82)',
    fontSize: 15,
    lineHeight: 22,
    textAlign: 'center',
  },
  stepEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  statusTitle: {
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 30,
  },
  statusBody: {
    fontSize: 14,
    lineHeight: 21,
  },
  detailsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  detailsToggleText: {
    fontSize: 14,
    fontWeight: '700',
  },
  detailsCard: {
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 2,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    paddingVertical: 10,
  },
  detailLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  detailValue: {
    flex: 1,
    textAlign: 'right',
    fontSize: 13,
    fontWeight: '800',
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 10,
    gap: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  primaryCta: {
    borderRadius: 20,
    minHeight: 52,
  },
  refreshBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 13,
  },
  refreshText: {
    fontSize: 15,
    fontWeight: '800',
  },
  tertiaryBtn: {
    alignItems: 'center',
    paddingVertical: 4,
  },
  tertiaryText: {
    fontSize: 13,
    fontWeight: '700',
  },
  footerHint: {
    fontSize: 12,
    lineHeight: 17,
    textAlign: 'center',
  },
  dialogOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.58)',
    justifyContent: 'center',
    padding: 20,
  },
  dialogCard: {
    borderRadius: 20,
    padding: 18,
    gap: 12,
    borderWidth: 1,
  },
  dialogError: { backgroundColor: '#1F0F10', borderColor: 'rgba(239,68,68,0.4)' },
  dialogWarning: { backgroundColor: '#1F1609', borderColor: 'rgba(245,158,11,0.4)' },
  dialogInfo: { backgroundColor: '#0C1B2A', borderColor: 'rgba(96,165,250,0.4)' },
  dialogTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  dialogMessage: { color: 'rgba(249,250,251,0.72)', fontSize: 14, lineHeight: 20 },
  dialogActions: { flexDirection: 'row', gap: 10, justifyContent: 'flex-end', flexWrap: 'wrap' },
  dialogButton: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  dialogButtonSecondary: { backgroundColor: 'rgba(255,255,255,0.08)' },
  dialogButtonDanger: { backgroundColor: 'rgba(239,68,68,0.18)' },
  dialogButtonText: { color: '#F9FAFB', fontSize: 13, fontWeight: '800' },
});
