/**
 * Valeter Notification Preferences – Control how and when you receive alerts.
 * Matches business notification-settings page layout and styling.
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { supabase } from '../../../src/lib/supabase';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';

const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const SETTINGS: { key: keyof NotificationPreferences; label: string; description: string; icon: string }[] = [
  { key: 'jobAlerts', label: 'Job request alerts', description: 'Get notified about new job opportunities', icon: 'briefcase' },
  { key: 'sound', label: 'Sound', description: 'Play sound for notifications', icon: 'volume-high' },
  { key: 'vibration', label: 'Vibration', description: 'Vibrate for alerts', icon: 'phone-portrait' },
  { key: 'email', label: 'Email', description: 'Receive email summaries', icon: 'mail' },
];

export default function ValeterNotificationPreferences() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadNotificationPreferences();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadNotificationPreferences = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('notification_preferences')
        .eq('user_id', user.id)
        .maybeSingle();
      if (error) throw error;
      if (!data?.notification_preferences) {
        setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
        return;
      }

      const merged: NotificationPreferences = {
        ...DEFAULT_NOTIFICATION_PREFS,
        ...(data.notification_preferences as Partial<NotificationPreferences> | null),
      };
      setNotificationPrefs(merged);
    } catch (error) {
      console.error('Error loading notification preferences:', error);
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
    } finally {
      setLoading(false);
    }
  };

  const saveNotificationPreferences = async (prefs: NotificationPreferences) => {
    if (!user?.id) return;
    try {
      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (existingProfile) {
        const { error } = await supabase
          .from('valeter_profiles')
          .update({ notification_preferences: prefs })
          .eq('user_id', user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, notification_preferences: prefs, full_name: user.name || 'Car Care Pro' });
        if (error) throw error;
      }
    } catch (error) {
      console.error('Error saving notification preferences:', error);
    }
  };

  const handleToggle = async (key: keyof NotificationPreferences) => {
    try {
      await hapticFeedback('light');
      const newPrefs: NotificationPreferences = { ...notificationPrefs, [key]: !notificationPrefs[key] };
      setNotificationPrefs(newPrefs);
      await saveNotificationPreferences(newPrefs);
    } catch (error) {
      console.error('Error updating notification preferences:', error);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Notifications" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader title="Notifications" />

      <View style={styles.screen}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: insets.bottom + 24,
            },
          ]}
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.headerSection}>
            <View style={styles.headerIconBox}>
              <Ionicons name="notifications-outline" size={28} color={SKY} />
            </View>
            <View>
              <Text style={styles.sectionTitle}>Notification preferences</Text>
              <Text style={styles.sectionSubtitle}>
                Control how and when you receive alerts
              </Text>
            </View>
          </View>

          <GlassCard style={styles.categoryCard} accountType="valeter">
            <View style={styles.settingsList}>
              {SETTINGS.map((item, index) => {
                const enabled = notificationPrefs[item.key];
                return (
                  <View key={item.key}>
                    <TouchableOpacity
                      style={styles.settingRow}
                      onPress={() => handleToggle(item.key)}
                      activeOpacity={0.8}
                    >
                      <View style={styles.settingLeft}>
                        <View style={[styles.settingIconBox, enabled && styles.settingIconBoxActive]}>
                          <Ionicons
                            name={enabled ? 'notifications' : 'notifications-off'}
                            size={18}
                            color={enabled ? SKY : 'rgba(255,255,255,0.5)'}
                          />
                        </View>
                        <View style={styles.settingInfo}>
                          <Text style={[styles.settingLabel, !enabled && styles.settingLabelDisabled]}>
                            {item.label}
                          </Text>
                          <Text style={styles.settingDescription}>{item.description}</Text>
                        </View>
                      </View>
                      <Switch
                        value={enabled}
                        onValueChange={() => handleToggle(item.key)}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: SKY }}
                        thumbColor={enabled ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                    </TouchableOpacity>
                    {index < SETTINGS.length - 1 && <View style={styles.settingDivider} />}
                  </View>
                );
              })}
            </View>
          </GlassCard>
          </Animated.View>
        </Animated.ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  screen: { flex: 1, paddingHorizontal: 20 },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 12,
    paddingBottom: 14,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerSpacer: { width: 44, height: 44 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 0 },
  content: { gap: 20 },
  headerSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    marginBottom: 20,
  },
  headerIconBox: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(158,201,224,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(158,201,224,0.25)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  categoryCard: {
    borderRadius: 16,
    padding: 0,
    overflow: 'hidden',
  },
  settingsList: { padding: 12 },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingIconBox: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  settingIconBoxActive: {
    backgroundColor: 'rgba(158,201,224,0.15)',
    borderColor: 'rgba(158,201,224,0.3)',
  },
  settingInfo: { flex: 1, gap: 3 },
  settingLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.1,
  },
  settingLabelDisabled: {
    color: 'rgba(249,250,251,0.6)',
  },
  settingDescription: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  settingDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginLeft: 48,
    marginVertical: 4,
  },
});
