import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { supabase } from '../../../src/lib/supabase';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import LoadingScreen from '../../../src/components/LoadingScreen';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { getServicesOfferedFromSettings, type ValeterServiceSettingsRow } from '../../../src/utils/valeterServicesOffered';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { lightMistElevated, lightMistInput } from '../../../src/constants/accountThemes';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import ValeterPickerSheet from '../../../src/components/valeter/ValeterPickerSheet';
import {
  ValeterExperienceWheelPicker,
  formatExperienceLabel,
  parseExperienceLabel,
} from '../../../src/components/valeter/ValeterWheelPicker';

const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.65)';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#152238'];
const DEFAULT_BIO = 'Professional mobile car care pro';
const BIO_MAX = 160;

function isDefaultBio(bio?: string | null): boolean {
  const t = (bio || '').trim().toLowerCase();
  return !t || t === DEFAULT_BIO.toLowerCase();
}

function isEmptyExperience(experience?: string | null): boolean {
  return !experience || /^0\s*years?$/i.test(experience.trim());
}

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  business_name?: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  is_self_sufficient?: boolean;
}

type InfoRowProps = Readonly<{
  label: string;
  hint?: string;
  editing: boolean;
  children: React.ReactNode;
  last?: boolean;
  labelColor?: string;
  hintColor?: string;
}>;

function InfoRow({ label, hint, editing, children, last, labelColor, hintColor }: InfoRowProps) {
  return (
    <View style={[styles.infoRow, !last && styles.infoRowBorder]}>
      <View style={styles.infoRowLabelBlock}>
        <Text style={[styles.infoRowLabel, labelColor ? { color: labelColor } : null]}>{label}</Text>
        {hint ? <Text style={[styles.infoRowHint, hintColor ? { color: hintColor } : null]}>{hint}</Text> : null}
      </View>
      <View style={[styles.infoRowValueBlock, editing && styles.infoRowValueEditing]}>{children}</View>
    </View>
  );
}

export default function ValeterPersonalInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const primary = theme.primary || SKY;
  const glassBorder = theme.glassBorder ?? `${primary}35`;
  const textMain = theme.textPrimary ?? LIGHT_TEXT;
  const textMuted = theme.textSecondary ?? MUTED_TEXT;
  const isLight = theme.mode === 'light';
  const insets = useSafeAreaInsets();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [serviceSettings, setServiceSettings] = useState<ValeterServiceSettingsRow | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [experiencePickerOpen, setExperiencePickerOpen] = useState(false);
  const [experienceDraft, setExperienceDraft] = useState({ years: 1, months: 0 });

  const offeredServices = useMemo(
    () => getServicesOfferedFromSettings(serviceSettings),
    [serviceSettings]
  );

  useEffect(() => {
    if (user?.id) {
      loadProfile();
      loadServiceSettings();
    }
  }, [user?.id]);

  useFocusEffect(
    React.useCallback(() => {
      if (user?.id) loadServiceSettings();
    }, [user?.id])
  );

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Car Care Pro',
          bio: DEFAULT_BIO,
          experience: '0 years',
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile information');
    } finally {
      setIsLoading(false);
    }
  };

  const loadServiceSettings = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('tier_pricing, detailing_offered, detailing_menu')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (!error && data) setServiceSettings(data);
    } catch {
      // table may not exist
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;
    const name = (profile.full_name || '').trim();
    if (!name) {
      Alert.alert('Name required', 'Add your name before saving.');
      return;
    }

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          full_name: name,
          business_name: profile.business_name ?? null,
          bio: (profile.bio || '').trim() || DEFAULT_BIO,
          experience: profile.experience,
          is_self_sufficient: profile.is_self_sufficient,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      setProfile({ ...profile, full_name: name });
      await hapticFeedback('success');
      Alert.alert('Saved', 'Your personal details were updated.');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelEdit = () => {
    loadProfile();
    setIsEditing(false);
    setExperiencePickerOpen(false);
  };

  const openExperiencePicker = async () => {
    await hapticFeedback('light');
    const parsed = parseExperienceLabel(profile!.experience);
    setExperienceDraft(
      parsed.years === 0 && parsed.months === 0 ? { years: 1, months: 0 } : parsed
    );
    setExperiencePickerOpen(true);
  };

  const commitExperiencePicker = async () => {
    await hapticFeedback('light');
    setProfile({
      ...profile!,
      experience: formatExperienceLabel(experienceDraft.years, experienceDraft.months),
    });
    setExperiencePickerOpen(false);
  };

  const toggleSelfSufficient = async (value: boolean) => {
    if (!profile) return;
    await hapticFeedback('light');
    setProfile({ ...profile, is_self_sufficient: value });
    if (!isEditing || !user?.id) return;
    try {
      await supabase.from('valeter_profiles').update({ is_self_sufficient: value }).eq('user_id', user.id);
    } catch (e) {
      console.error('Error saving self-sufficiency:', e);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <ValeterScreenHeader title="Personal information" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Personal information" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  const displayBio = isDefaultBio(profile.bio) ? DEFAULT_BIO : (profile.bio || DEFAULT_BIO);
  const bioDraft = isDefaultBio(profile.bio) ? '' : profile.bio || '';
  const experienceDisplay = isEmptyExperience(profile.experience) ? 'Not specified' : profile.experience!;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Personal information"
        rightAction={
          isEditing ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                handleCancelEdit();
              }}
              style={[styles.headerChip, { borderColor: `${primary}40`, backgroundColor: `${primary}14` }]}
              hitSlop={8}
            >
              <Text style={[styles.headerChipText, { color: primary }]}>Cancel</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setIsEditing(true);
              }}
              style={[styles.headerChip, { borderColor: `${primary}40`, backgroundColor: `${primary}14` }]}
              hitSlop={8}
            >
              <Ionicons name="pencil" size={14} color={primary} />
              <Text style={[styles.headerChipText, { color: primary }]}>Edit</Text>
            </TouchableOpacity>
          )
        }
      />

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: insets.bottom + VALETER_CONTENT_BOTTOM_PAD + (isEditing ? 100 : 8) },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.hero}>
            <Text style={[styles.heroEyebrow, { color: primary }]}>Customer-facing</Text>
            <Text style={[styles.heroTitle, { color: textMain }]} numberOfLines={1}>
              {profile.full_name || 'Your name'}
            </Text>
            <Text style={[styles.heroSub, { color: textMuted }]} numberOfLines={2}>
              {profile.business_name?.trim()
                ? profile.business_name
                : 'Add a business name so customers recognise you'}
            </Text>
          </View>

          <Text style={[styles.sectionLabel, { color: textMuted }]}>Identity</Text>
          <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: isLight ? lightMistElevated : 'rgba(15,23,42,0.42)' }]}>
            <InfoRow label="Name" hint="Shown on jobs and your profile" editing={isEditing} labelColor={textMuted} hintColor={isLight ? 'rgba(248,250,252,0.55)' : undefined}>
              {isEditing ? (
                <TextInput
                  style={[styles.input, { color: textMain, borderColor: isLight ? 'rgba(158,201,224,0.32)' : 'rgba(148,163,184,0.22)', backgroundColor: isLight ? lightMistInput : 'rgba(255,255,255,0.06)' }]}
                  value={profile.full_name}
                  onChangeText={(text) => setProfile({ ...profile, full_name: text })}
                  placeholder="Your name"
                  placeholderTextColor={textMuted}
                  autoCapitalize="words"
                />
              ) : (
                <Text style={[styles.value, { color: textMain }]}>{profile.full_name}</Text>
              )}
            </InfoRow>

            <InfoRow label="Business name" hint="Optional trading name" editing={isEditing} labelColor={textMuted} hintColor={isLight ? 'rgba(248,250,252,0.55)' : undefined}>
              {isEditing ? (
                <TextInput
                  style={[styles.input, { color: textMain, borderColor: isLight ? 'rgba(158,201,224,0.32)' : 'rgba(148,163,184,0.22)', backgroundColor: isLight ? lightMistInput : 'rgba(255,255,255,0.06)' }]}
                  value={profile.business_name ?? ''}
                  onChangeText={(text) => setProfile({ ...profile, business_name: text || undefined })}
                  placeholder="e.g. Joe's Mobile Valeting"
                  placeholderTextColor={textMuted}
                />
              ) : (
                <Text style={[styles.value, { color: profile.business_name?.trim() ? textMain : textMuted }]}>
                  {profile.business_name?.trim() ? profile.business_name : 'Not set'}
                </Text>
              )}
            </InfoRow>

            <InfoRow label="Email" hint="Account login — not editable here" editing={false} last labelColor={textMuted} hintColor={isLight ? 'rgba(248,250,252,0.55)' : undefined}>
              <Text style={[styles.value, { color: textMain }]}>{user?.email || '—'}</Text>
            </InfoRow>
          </View>

          <Text style={[styles.sectionLabel, { color: textMuted }]}>About you</Text>
          <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: isLight ? lightMistElevated : 'rgba(15,23,42,0.42)' }]}>
            <InfoRow label="Bio" hint="Short intro customers see" editing={isEditing} labelColor={textMuted} hintColor={isLight ? 'rgba(248,250,252,0.55)' : undefined}>
              {isEditing ? (
                <View>
                  <TextInput
                    style={[styles.input, styles.bioInput, { color: textMain, borderColor: isLight ? 'rgba(158,201,224,0.32)' : 'rgba(148,163,184,0.22)', backgroundColor: isLight ? lightMistInput : 'rgba(255,255,255,0.06)' }]}
                    value={bioDraft}
                    onChangeText={(text) =>
                      setProfile({ ...profile, bio: text.slice(0, BIO_MAX) })
                    }
                    placeholder={DEFAULT_BIO}
                    placeholderTextColor={textMuted}
                    multiline
                    maxLength={BIO_MAX}
                  />
                  <Text style={[styles.charCount, { color: textMuted }]}>
                    {bioDraft.length}/{BIO_MAX}
                  </Text>
                </View>
              ) : (
                <Text style={[styles.value, { color: textMain }]}>{displayBio}</Text>
              )}
            </InfoRow>

            <InfoRow label="Experience" hint="Years on the tools" editing={isEditing} last labelColor={textMuted} hintColor={isLight ? 'rgba(248,250,252,0.55)' : undefined}>
              {isEditing ? (
                <Pressable
                  onPress={openExperiencePicker}
                  style={({ pressed }) => [styles.pickerBtn, { borderColor: `${primary}40`, backgroundColor: isLight ? lightMistInput : 'rgba(255,255,255,0.06)', opacity: pressed ? 0.85 : 1 }]}
                >
                  <Text
                    style={[
                      styles.pickerBtnText,
                      { color: isEmptyExperience(profile.experience) ? textMuted : textMain },
                    ]}
                  >
                    {isEmptyExperience(profile.experience) ? 'Select experience' : profile.experience}
                  </Text>
                  <Ionicons name="chevron-expand" size={16} color={textMuted} />
                </Pressable>
              ) : (
                <Text style={[styles.value, { color: isEmptyExperience(profile.experience) ? textMuted : textMain }]}>
                  {experienceDisplay}
                </Text>
              )}
            </InfoRow>
          </View>

          <Text style={[styles.sectionLabel, { color: textMuted }]}>On the road</Text>
          <View style={[styles.capabilityCard, { borderColor: glassBorder, backgroundColor: isLight ? lightMistElevated : 'rgba(15,23,42,0.42)' }]}>
            <View style={styles.capabilityLeft}>
              <LocationStyleIconBox
                icon={profile.is_self_sufficient ? 'water' : 'water-outline'}
                preset={profile.is_self_sufficient ? 'cyan' : 'gray'}
              />
              <View style={styles.capabilityCopy}>
                <Text style={[styles.capabilityTitle, { color: textMain }]}>Self-sufficient</Text>
                <Text style={[styles.capabilitySub, { color: textMuted }]}>I bring my own water and power</Text>
              </View>
            </View>
            {isEditing ? (
              <Switch
                value={profile.is_self_sufficient ?? false}
                onValueChange={toggleSelfSufficient}
                trackColor={{ false: 'rgba(148,163,184,0.35)', true: `${primary}99` }}
                thumbColor={profile.is_self_sufficient ? primary : '#E2E8F0'}
              />
            ) : (
              <View
                style={[
                  styles.statusPill,
                  {
                    backgroundColor: profile.is_self_sufficient ? 'rgba(34,197,94,0.16)' : isLight ? 'rgba(71,85,105,0.12)' : 'rgba(148,163,184,0.14)',
                  },
                ]}
              >
                <Text
                  style={[
                    styles.statusPillText,
                    { color: profile.is_self_sufficient ? '#059669' : textMuted },
                  ]}
                >
                  {profile.is_self_sufficient ? 'Yes' : 'No'}
                </Text>
              </View>
            )}
          </View>

          <Text style={[styles.sectionLabel, { color: textMuted }]}>Services</Text>
          <View style={[styles.panel, { borderColor: glassBorder, backgroundColor: isLight ? lightMistElevated : 'rgba(15,23,42,0.42)' }]}>
            <Text style={[styles.servicesLead, { color: textMuted }]}>
              Wash packages and add-ons from your Services dashboard appear on your public profile.
            </Text>
            {offeredServices.length > 0 ? (
              <View style={styles.tagWrap}>
                {offeredServices.map((name) => (
                  <View key={name} style={[styles.tag, { borderColor: `${primary}35`, backgroundColor: isLight ? 'rgba(158,201,224,0.12)' : 'rgba(255,255,255,0.05)' }]}>
                    <Text style={[styles.tagText, { color: textMain }]}>{name}</Text>
                  </View>
                ))}
              </View>
            ) : (
              <Text style={[styles.servicesEmpty, { color: textMuted }]}>No services set yet.</Text>
            )}
            <TouchableOpacity
              style={[styles.manageBtn, { borderColor: `${primary}40`, backgroundColor: `${primary}12` }]}
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/valeter/profile/valeter-services');
              }}
              activeOpacity={0.85}
            >
              <LocationStyleIconBox icon="pricetag" preset="sky" />
              <View style={styles.manageBtnCopy}>
                <Text style={[styles.manageBtnTitle, { color: textMain }]}>Services & pricing</Text>
                <Text style={[styles.manageBtnSub, { color: textMuted }]}>Set wash tiers and add-ons</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={primary} />
            </TouchableOpacity>
          </View>
        </ScrollView>

        {isEditing ? (
          <View style={[styles.saveBar, { paddingBottom: Math.max(insets.bottom, 16), backgroundColor: isLight ? 'rgba(42,70,96,0.94)' : 'rgba(10,25,41,0.92)', borderTopColor: isLight ? 'rgba(232,197,71,0.22)' : 'rgba(255,255,255,0.08)' }]}>
            <ContinueCTAButton
              title="Save changes"
              onPress={handleSaveProfile}
              accentColor={primary}
              disabled={isSaving}
              loading={isSaving}
            />
          </View>
        ) : null}
      </KeyboardAvoidingView>

      <ValeterPickerSheet
        visible={experiencePickerOpen}
        title="Experience"
        onClose={() => setExperiencePickerOpen(false)}
        onDone={commitExperiencePicker}
        accent={primary}
      >
        <ValeterExperienceWheelPicker
          years={experienceDraft.years}
          months={experienceDraft.months}
          onChange={setExperienceDraft}
          accent={primary}
        />
      </ValeterPickerSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: LIGHT_TEXT, marginTop: 16, fontSize: 15 },

  headerChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  headerChipText: { fontSize: 13, fontWeight: '800' },

  hero: { marginBottom: 22 },
  heroEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  heroTitle: {
    color: LIGHT_TEXT,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  heroSub: {
    color: MUTED_TEXT,
    fontSize: 14,
    fontWeight: '600',
    marginTop: 6,
    lineHeight: 20,
  },

  sectionLabel: {
    color: 'rgba(249,250,251,0.42)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 4,
  },

  panel: {
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.42)',
    paddingHorizontal: 14,
    paddingVertical: 4,
    marginBottom: 20,
    overflow: 'hidden',
  },

  infoRow: {
    paddingVertical: 14,
  },
  infoRowBorder: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  infoRowLabelBlock: { marginBottom: 8 },
  infoRowLabel: {
    color: MUTED_TEXT,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  infoRowHint: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  infoRowValueBlock: {},
  infoRowValueEditing: {},

  value: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700', lineHeight: 22 },
  valueMuted: { color: MUTED_TEXT, fontWeight: '600' },

  input: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  bioInput: {
    minHeight: 88,
    textAlignVertical: 'top',
  },
  charCount: {
    color: 'rgba(249,250,251,0.35)',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'right',
    marginTop: 6,
  },

  pickerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  pickerBtnText: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '700', flex: 1 },

  capabilityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
    borderRadius: 18,
    borderWidth: 1,
    backgroundColor: 'rgba(15,23,42,0.42)',
    padding: 14,
    marginBottom: 20,
  },
  capabilityLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 },
  capabilityCopy: { flex: 1, minWidth: 0 },
  capabilityTitle: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '800' },
  capabilitySub: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600', marginTop: 2 },
  statusPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  statusPillText: { fontSize: 12, fontWeight: '800' },

  servicesLead: {
    color: MUTED_TEXT,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    paddingTop: 10,
    paddingBottom: 12,
  },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  tag: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tagText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '700' },
  servicesEmpty: {
    color: MUTED_TEXT,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 14,
  },
  manageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
  },
  manageBtnCopy: { flex: 1, minWidth: 0 },
  manageBtnTitle: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '800' },
  manageBtnSub: { color: MUTED_TEXT, fontSize: 12, fontWeight: '600', marginTop: 2 },

  saveBar: {
    paddingHorizontal: 20,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
    backgroundColor: 'rgba(10,25,41,0.92)',
  },
});
