import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Dimensions,
  Animated,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

interface ValeterDetailProfile {
  id: string;
  name: string;
  rating: number;
  totalRatings: number;
  jobsCompleted: number;
  totalEarnings: number;
  experience: string;
  specializations: string[];
  certifications: string[];
  isOnline: boolean;
  lastSeen: string;
  isConnected: boolean;
  bio: string;
  location: string;
  joinDate: string;
  averageJobTime: string;
  customerSatisfaction: number;
  responseTime: string;
  cancellationRate: number;
  recentJobs: {
    id: string;
    customerName: string;
    serviceType: string;
    date: string;
    rating: number;
    amount: number;
  }[];
  reviews: {
    id: string;
    customerName: string;
    rating: number;
    comment: string;
    date: string;
  }[];
}

export default function ValeterDetailProfile() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const { valeterId } = useLocalSearchParams();
  const { user } = useAuth();
  const [valeter, setValeter] = useState<ValeterDetailProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [64, 64],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.98, 0.96],
    extrapolate: 'clamp',
  });

  // Floating bubbles animation
  const bubbleData = useRef(
    Array.from({ length: 5 }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.15 + Math.random() * 0.1),
      scale: new Animated.Value(0.8 + Math.random() * 0.4),
      size: 20 + Math.random() * 30,
      leftPosition: Math.random() * Dimensions.get('window').width,
      duration: 8000 + Math.random() * 4000,
      delay: i * 1000,
    }))
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      const animateBubble = () => {
        Animated.parallel([
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateY, {
                toValue: -64 - 50,
                duration: bubble.duration,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateY, {
                toValue: 0,
                duration: 0,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateX, {
                toValue: 20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateX, {
                toValue: -20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.scale, {
                toValue: 1.2,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.scale, {
                toValue: 0.8,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
            ])
          ),
        ]).start();
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);

      return () => clearTimeout(timeout);
    });
  }, []);

  useEffect(() => {
    loadValeterProfile();
  }, [valeterId]);

  const loadValeterProfile = async () => {
    if (!valeterId) {
      setLoading(false);
      return;
    }
    try {
      // TODO: Load actual valeter profile from Supabase
      // Load from valeter_profiles, bookings, reviews tables
      setValeter(null);
    } catch (error) {
      console.error('Error loading valeter profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMessage = () => {
    if (valeter) {
      router.push({
        pathname: '/chat-screen',
        params: { 
          recipientId: valeter.id,
          recipientName: valeter.name,
          recipientType: 'valeter'
        }
      });
    }
  };

  const handleConnect = () => {
    if (valeter) {
      setValeter(prev => prev ? { ...prev, isConnected: true } : null);
      Alert.alert('Connected!', `You are now connected with ${valeter.name}.`);
    }
  };

  const handleDisconnect = () => {
    if (valeter) {
      Alert.alert(
        'Disconnect',
        `Are you sure you want to disconnect from ${valeter.name}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Disconnect',
            style: 'destructive',
            onPress: () => {
              setValeter(prev => prev ? { ...prev, isConnected: false } : null);
            }
          }
        ]
      );
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!valeter) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Valeter not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
            paddingTop: insets.top,
          },
        ]}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 30 : 25}
          tint="dark"
          style={StyleSheet.absoluteFill}
        >
          <LinearGradient
            colors={['rgba(10,25,41,0.85)', 'rgba(30,58,138,0.75)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </BlurView>
        {/* Floating Bubbles */}
        <View style={styles.bubblesContainer}>
          {bubbleData.map((bubble, index) => (
            <Animated.View
              key={index}
              style={[
                styles.bubble,
                {
                  width: bubble.size,
                  height: bubble.size,
                  left: bubble.leftPosition,
                  transform: [
                    { translateY: bubble.translateY },
                    { translateX: bubble.translateX },
                    { scale: bubble.scale },
                  ],
                  opacity: bubble.opacity,
                },
              ]}
            />
          ))}
        </View>
        <View style={styles.glowLine} />
        
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <TouchableOpacity 
              onPress={async () => {
                await hapticFeedback('light');
                router.back();
              }} 
              style={styles.backButton}
              activeOpacity={0.7}
            >
              <LinearGradient
                colors={['rgba(135,206,235,0.25)', 'rgba(135,206,235,0.15)']}
                style={styles.backButtonGradient}
              >
                <Ionicons name="chevron-back" size={20} color={SKY} />
              </LinearGradient>
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Valeter Profile</Text>
            <View style={styles.placeholder} />
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: 80, paddingBottom: 20 }}
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.profileInfo}>
            <View style={styles.profilePicture}>
              <Ionicons name="person" size={40} color={SKY} />
            </View>
            <View style={styles.profileDetails}>
              <Text style={styles.valeterName}>{valeter.name}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={16} color="#F59E0B" />
                <Text style={styles.ratingText}>{valeter.rating}</Text>
                <Text style={styles.ratingCount}>({valeter.totalRatings} reviews)</Text>
              </View>
              <View style={styles.statusRow}>
                <View style={[
                  styles.onlineIndicator,
                  { backgroundColor: valeter.isOnline ? '#10B981' : '#6B7280' }
                ]} />
                <Text style={styles.statusText}>
                  {valeter.isOnline ? 'Online' : valeter.lastSeen}
                </Text>
              </View>
            </View>
          </View>
          
          <View style={styles.actionButtons}>
            {valeter.isConnected ? (
              <>
                <TouchableOpacity style={[styles.actionButton, styles.messageButton]} onPress={handleMessage}>
                  <Ionicons name="chatbubble" size={16} color="#FFFFFF" />
                  <Text style={styles.actionButtonText}>Message</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionButton, styles.disconnectButton]} onPress={handleDisconnect}>
                  <Ionicons name="close-circle" size={16} color="#FFFFFF" />
                  <Text style={styles.actionButtonText}>Disconnect</Text>
                </TouchableOpacity>
              </>
            ) : (
              <TouchableOpacity style={[styles.actionButton, styles.connectButton]} onPress={handleConnect}>
                <Ionicons name="add-circle" size={16} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>Connect</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="briefcase" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.jobsCompleted}</Text>
                <Text style={styles.statLabel}>Jobs Completed</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="cash" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>£{valeter.totalEarnings.toLocaleString()}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="time" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.experience}</Text>
                <Text style={styles.statLabel}>Experience</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="happy" size={22} color="#10B981" />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.customerSatisfaction}%</Text>
                <Text style={styles.statLabel}>Satisfaction</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Performance Metrics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Performance Metrics</Text>
          <View style={styles.metricsContainer}>
            <View style={styles.metricItem}>
              <View style={styles.metricLeft}>
                <Ionicons name="time-outline" size={20} color={SKY} />
                <Text style={styles.metricLabel}>Average Response Time</Text>
              </View>
              <Text style={styles.metricValue}>{valeter.responseTime}</Text>
            </View>
            <View style={styles.metricItem}>
              <View style={styles.metricLeft}>
                <Ionicons name="hourglass-outline" size={20} color={SKY} />
                <Text style={styles.metricLabel}>Average Job Time</Text>
              </View>
              <Text style={styles.metricValue}>{valeter.averageJobTime}</Text>
            </View>
            <View style={styles.metricItem}>
              <View style={styles.metricLeft}>
                <Ionicons name="close-circle-outline" size={20} color={SKY} />
                <Text style={styles.metricLabel}>Cancellation Rate</Text>
              </View>
              <Text style={styles.metricValue}>{valeter.cancellationRate}%</Text>
            </View>
            <View style={styles.metricItem}>
              <View style={styles.metricLeft}>
                <Ionicons name="calendar-outline" size={20} color={SKY} />
                <Text style={styles.metricLabel}>Member Since</Text>
              </View>
              <Text style={styles.metricValue}>{valeter.joinDate}</Text>
            </View>
          </View>
        </View>

        {/* Bio */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.bioText}>{valeter.bio}</Text>
        </View>

        {/* Specializations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Specialisations</Text>
          <View style={styles.specializationsContainer}>
            {valeter.specializations.map((spec, index) => (
              <View key={index} style={styles.specializationTag}>
                <Text style={styles.specializationText}>{spec}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Certifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Certifications</Text>
          <View style={styles.certificationsContainer}>
            {valeter.certifications.map((cert, index) => (
              <View key={index} style={styles.certificationItem}>
                <View style={styles.certificationIconWrapper}>
                  <Ionicons name="trophy" size={20} color="#F59E0B" />
                </View>
                <Text style={styles.certificationText}>{cert}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent Jobs */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Jobs</Text>
          {valeter.recentJobs.map((job) => (
            <View key={job.id} style={styles.jobItem}>
              <LinearGradient
                colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
                style={styles.jobGradient}
              >
                <View style={styles.jobHeader}>
                  <View style={styles.jobLeft}>
                    <Ionicons name="person" size={16} color={SKY} />
                    <Text style={styles.jobCustomer}>{job.customerName}</Text>
                  </View>
                  <Text style={styles.jobAmount}>£{job.amount}</Text>
                </View>
                <View style={styles.jobDetails}>
                  <View style={styles.jobDetailRow}>
                    <Ionicons name="car" size={14} color={SKY} />
                    <Text style={styles.jobService}>{job.serviceType}</Text>
                  </View>
                  <View style={styles.jobDetailRow}>
                    <Ionicons name="calendar" size={14} color={SKY} />
                    <Text style={styles.jobDate}>{job.date}</Text>
                  </View>
                  <View style={styles.jobDetailRow}>
                    <Ionicons name="star" size={14} color="#F59E0B" />
                    <Text style={styles.jobRating}>{job.rating}</Text>
                  </View>
                </View>
              </LinearGradient>
            </View>
          ))}
        </View>

        {/* Reviews */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Customer Reviews</Text>
          {valeter.reviews.map((review) => (
            <View key={review.id} style={styles.reviewItem}>
              <LinearGradient
                colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
                style={styles.reviewGradient}
              >
                <View style={styles.reviewHeader}>
                  <View style={styles.reviewLeft}>
                    <Ionicons name="person-circle" size={20} color={SKY} />
                    <Text style={styles.reviewCustomer}>{review.customerName}</Text>
                  </View>
                  <View style={styles.reviewRatingRow}>
                    <Ionicons name="star" size={16} color="#F59E0B" />
                    <Text style={styles.reviewRating}>{review.rating}</Text>
                  </View>
                </View>
                <Text style={styles.reviewComment}>{review.comment}</Text>
                <Text style={styles.reviewDate}>{review.date}</Text>
              </LinearGradient>
            </View>
          ))}
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: '#EF4444',
    fontSize: 18,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    overflow: 'hidden',
  },
  bubblesContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
  bubble: {
    position: 'absolute',
    borderRadius: 50,
    backgroundColor: SKY,
    opacity: 0.15,
  },
  glowLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.4)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 4,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 16,
    justifyContent: 'center',
    height: 64,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  backButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  placeholder: {
    width: 36,
  },
  profileHeader: {
    padding: isSmallScreen ? 20 : 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  profileInfo: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  profileDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 4,
  },
  ratingText: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: '700',
  },
  ratingCount: {
    color: SKY,
    fontSize: 14,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  connectButton: {
    backgroundColor: '#10B981',
  },
  disconnectButton: {
    backgroundColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#3B82F6',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: isSmallScreen ? 16 : 20,
    gap: 12,
  },
  statCard: {
    width: (width - (isSmallScreen ? 44 : 52)) / 2,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  statCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statTextContainer: {
    flex: 1,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    marginBottom: 2,
    letterSpacing: -0.3,
  },
  statLabel: {
    color: SKY,
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  section: {
    padding: isSmallScreen ? 16 : 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    marginBottom: 16,
  },
  metricsContainer: {
    gap: 12,
  },
  metricItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  metricLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  metricLabel: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
  },
  bioText: {
    color: '#E5E7EB',
    fontSize: 16,
    lineHeight: 24,
  },
  specializationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  specializationTag: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  specializationText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  certificationsContainer: {
    gap: 12,
  },
  certificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    gap: 12,
  },
  certificationIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(245,158,11,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  certificationText: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
    fontWeight: '600',
  },
  jobItem: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  jobGradient: {
    padding: 16,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  jobLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  jobCustomer: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  jobAmount: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: '900',
  },
  jobDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 12,
  },
  jobDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  jobService: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  jobDate: {
    color: SKY,
    fontSize: 13,
  },
  jobRating: {
    color: '#F59E0B',
    fontSize: 13,
    fontWeight: '700',
  },
  reviewItem: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  reviewGradient: {
    padding: 16,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  reviewLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  reviewCustomer: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  reviewRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  reviewRating: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: '700',
  },
  reviewComment: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  reviewDate: {
    color: SKY,
    fontSize: 12,
    opacity: 0.8,
  },
});
