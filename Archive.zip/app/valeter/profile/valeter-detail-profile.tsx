import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

function twoStopGradient(bg: readonly string[] | undefined, fallback: [string, string]): [string, string] {
  if (Array.isArray(bg) && bg.length >= 2) {
    return [String(bg[0]), String(bg[1])];
  }
  return fallback;
}

interface ValeterDetailProfile {
  id: string;
  name: string;
  rating: number;
  totalRatings: number;
  jobsCompleted: number;
  totalEarnings: number;
  experience: string;
  specializations: string[];
  certifications: string[];
  isOnline: boolean;
  lastSeen: string;
  bio: string;
  location: string;
  joinDate: string;
}

export default function ValeterDetailProfile() {
  const router = useRouter();
  const { theme } = useAccountTheme();
  const gradientBg = twoStopGradient(theme?.background, VALETER_BG_FALLBACK);
  const scrollY = useRef(new Animated.Value(0)).current;
  const { valeterId } = useLocalSearchParams();
  const [valeter, setValeter] = useState<ValeterDetailProfile | null>(null);
  const [loading, setLoading] = useState(true);


  // Floating bubbles animation
  const bubbleData = useRef(
    Array.from({ length: 5 }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.15 + Math.random() * 0.1),
      scale: new Animated.Value(0.8 + Math.random() * 0.4),
      size: 20 + Math.random() * 30,
      leftPosition: Math.random() * Dimensions.get('window').width,
      duration: 8000 + Math.random() * 4000,
      delay: i * 1000,
    }))
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      const animateBubble = () => {
        Animated.parallel([
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateY, {
                toValue: -64 - 50,
                duration: bubble.duration,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateY, {
                toValue: 0,
                duration: 0,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateX, {
                toValue: 20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateX, {
                toValue: -20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.scale, {
                toValue: 1.2,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.scale, {
                toValue: 0.8,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
            ])
          ),
        ]).start();
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);

      return () => clearTimeout(timeout);
    });
  }, []);

  useEffect(() => {
    loadValeterProfile();
  }, [valeterId]);

  const loadValeterProfile = async () => {
    const raw = valeterId;
    const id = Array.isArray(raw) ? raw[0] : raw;
    if (!id || typeof id !== 'string') {
      setLoading(false);
      return;
    }
    try {
      const [vpRes, profRes, countRes, earnRes] = await Promise.all([
        supabase.from('valeter_profiles').select('*').eq('user_id', id).maybeSingle(),
        supabase.from('profiles').select('full_name, created_at').eq('id', id).maybeSingle(),
        supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .eq('valeter_id', id)
          .eq('status', 'completed'),
        supabase.from('bookings').select('price').eq('valeter_id', id).eq('status', 'completed'),
      ]);

      const vp = vpRes.data as Record<string, unknown> | null;
      const prof = profRes.data as { full_name?: string; created_at?: string } | null;

      if (!vp && !prof) {
        setValeter(null);
        return;
      }

      const name = (prof?.full_name as string) || (vp?.full_name as string) || 'Car Care Pro';
      const jobsCompleted = countRes.count ?? 0;
      const earningsRows = earnRes.data || [];
      const totalEarnings = earningsRows.reduce((s: number, r: { price?: number }) => s + Number(r.price || 0), 0);

      const joinDate = prof?.created_at
        ? new Date(prof.created_at).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })
        : '—';

      const specs = vp?.specializations;
      let specializations: string[] = [];
      if (Array.isArray(specs)) {
        specializations = specs as string[];
      } else if (typeof specs === 'string') {
        specializations = [specs];
      }

      const certs = vp?.certifications;
      const certifications = Array.isArray(certs) ? (certs as string[]) : [];

      const rating = Number(vp?.average_rating ?? 0);
      const totalRatings = Number(vp?.review_count ?? 0);

      setValeter({
        id,
        name,
        rating,
        totalRatings,
        jobsCompleted,
        totalEarnings,
        experience: (vp?.experience as string) || '—',
        specializations,
        certifications,
        isOnline: !!(vp as { is_online?: boolean })?.is_online,
        lastSeen: (vp?.last_seen_at as string) || 'Recently',
        bio: (vp?.bio as string) || '',
        location: (vp?.service_area as string) || (vp?.city as string) || '—',
        joinDate,
      });
    } catch (error) {
      console.error('Error loading valeter profile:', error);
      setValeter(null);
    } finally {
      setLoading(false);
    }
  };

  const handleMessage = () => {
    if (valeter) {
      router.push({
        pathname: '/chat-screen',
        params: {
          recipientId: valeter.id,
          recipientName: valeter.name,
          recipientType: 'valeter',
        },
      } as unknown as Parameters<typeof router.push>[0]);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LoadingScreen message="Loading profile…" />
      </SafeAreaView>
    );
  }

  if (!valeter) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Car Care Pro not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={gradientBg[0]} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />

      <ValeterScreenHeader title="Car Care Pro Profile" />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40, paddingHorizontal: 20 }}
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.profileInfo}>
            <View style={styles.profilePicture}>
              <Ionicons name="person" size={40} color={SKY} />
            </View>
            <View style={styles.profileDetails}>
              <Text style={styles.valeterName}>{valeter.name}</Text>
              {valeter.totalRatings > 0 ? (
                <View style={styles.ratingRow}>
                  <Ionicons name="star" size={16} color="#F59E0B" />
                  <Text style={styles.ratingText}>{valeter.rating}</Text>
                  <Text style={styles.ratingCount}>({valeter.totalRatings} reviews)</Text>
                </View>
              ) : (
                <Text style={styles.ratingCount}>No reviews yet</Text>
              )}
              <View style={styles.statusRow}>
                <View style={[
                  styles.onlineIndicator,
                  { backgroundColor: valeter.isOnline ? '#10B981' : '#6B7280' }
                ]} />
                <Text style={styles.statusText}>
                  {valeter.isOnline ? 'Online' : valeter.lastSeen}
                </Text>
              </View>
            </View>
          </View>
          
          <View style={styles.actionButtons}>
            <TouchableOpacity style={[styles.actionButton, styles.messageButton]} onPress={handleMessage}>
              <Ionicons name="chatbubble" size={16} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Message</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.contactNoticeRow}>
            <Ionicons name="shield-checkmark-outline" size={14} color={SKY} />
            <Text style={styles.contactNoticeText}>Contact details are private. Use in-app chat only.</Text>
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="briefcase" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.jobsCompleted}</Text>
                <Text style={styles.statLabel}>Jobs Completed</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="wallet" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>£{valeter.totalEarnings.toLocaleString()}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="time" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.experience}</Text>
                <Text style={styles.statLabel}>Experience</Text>
              </View>
            </View>
          </View>
          <View style={styles.statCard}>
            <View style={styles.statCardContent}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="calendar" size={22} color={SKY} />
              </View>
              <View style={styles.statTextContainer}>
                <Text style={styles.statNumber}>{valeter.joinDate}</Text>
                <Text style={styles.statLabel}>Member Since</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Bio */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.bioText}>{valeter.bio}</Text>
        </View>

        {/* Specializations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Specialisations</Text>
          <View style={styles.specializationsContainer}>
            {valeter.specializations.map((spec) => (
              <View key={`spec-${spec}`} style={styles.specializationTag}>
                <Text style={styles.specializationText}>{spec}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Certifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Certifications</Text>
          <View style={styles.certificationsContainer}>
            {valeter.certifications.map((cert) => (
              <View key={`cert-${cert}`} style={styles.certificationItem}>
                <View style={styles.certificationIconWrapper}>
                  <Ionicons name="trophy" size={20} color="#F59E0B" />
                </View>
                <Text style={styles.certificationText}>{cert}</Text>
              </View>
            ))}
          </View>
        </View>

      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: '#EF4444',
    fontSize: 18,
  },
  headerWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  header: {
    borderRadius: 24,
    marginHorizontal: 20,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 16,
    justifyContent: 'center',
    height: 64,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  backButtonInner: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  placeholder: {
    width: 36,
  },
  profileHeader: {
    padding: isSmallScreen ? 20 : 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  profileInfo: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  profileDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 4,
  },
  ratingText: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: '700',
  },
  ratingCount: {
    color: SKY,
    fontSize: 14,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  messageButton: {
    backgroundColor: '#3B82F6',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  contactNoticeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    gap: 6,
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  contactNoticeText: {
    color: 'rgba(249,250,251,0.78)',
    fontSize: 12,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: isSmallScreen ? 16 : 20,
    gap: 12,
  },
  statCard: {
    width: (width - (isSmallScreen ? 44 : 52)) / 2,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  statCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statTextContainer: {
    flex: 1,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    marginBottom: 2,
    letterSpacing: -0.3,
  },
  statLabel: {
    color: SKY,
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  section: {
    padding: isSmallScreen ? 16 : 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '600',
    marginBottom: 16,
  },
  bioText: {
    color: '#E5E7EB',
    fontSize: 16,
    lineHeight: 24,
  },
  specializationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  specializationTag: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  specializationText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  certificationsContainer: {
    gap: 12,
  },
  certificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    gap: 12,
  },
  certificationIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(245,158,11,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  certificationText: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
    fontWeight: '600',
  },
});
