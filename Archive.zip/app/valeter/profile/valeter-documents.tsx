/**
 * Valeter Documents — calm 3-step verification process (Upload → Review → Verified).
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  Modal,
  Animated,
  Easing,
  LayoutAnimation,
  Platform,
  UIManager,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import type { IconGlyphName } from '../../../src/components/shared/iconGlyphTypes';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../../src/constants/accountThemes';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import {
  valeterDocumentsSupabaseService,
  UploadedDocument,
} from '../../../src/services/ValeterDocumentsSupabaseService';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

type UiStatus = 'missing' | 'pending' | 'approved' | 'rejected';

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  required: boolean;
  icon: IconGlyphName;
}

const PROCESS_STEPS = [
  { id: 1, label: 'Upload' },
  { id: 2, label: 'Review' },
  { id: 3, label: 'Verified' },
] as const;

const REQUIRED_DOCUMENTS: RequiredDocument[] = [
  {
    id: 'profile_photo',
    name: 'Profile Photo',
    description: 'Clear face shot on plain background',
    required: true,
    icon: 'camera',
  },
  {
    id: 'driving_license',
    name: 'Driving Licence',
    description: 'Valid UK driving licence',
    required: true,
    icon: 'car',
  },
  {
    id: 'id_proof',
    name: 'Passport/Birth certificate',
    description: 'Valid passport photo page or birth certificate',
    required: true,
    icon: 'id-card',
  },
  {
    id: 'public_liability',
    name: 'Public Liability Insurance',
    description: 'Minimum £2M coverage',
    required: true,
    icon: 'document-text',
  },
];

const SUPPORTING_DOCUMENTS: RequiredDocument[] = [
  {
    id: 'dbs_check',
    name: 'DBS Check',
    description: 'Enhanced DBS certificate',
    required: false,
    icon: 'shield-checkmark',
  },
];

function ProgressRail({
  activeStep,
  accent,
  gold,
  attention,
}: Readonly<{ activeStep: number; accent: string; gold: string; attention: boolean }>) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1100,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse, activeStep]);

  return (
    <View style={styles.rail}>
      {PROCESS_STEPS.map((step, index) => {
        const n = step.id;
        const done = n < activeStep;
        const current = n === activeStep;
        return (
          <React.Fragment key={step.id}>
            {index > 0 ? (
              <View
                style={[
                  styles.railLine,
                  { backgroundColor: n <= activeStep ? accent : 'rgba(255,255,255,0.14)' },
                ]}
              />
            ) : null}
            <View style={styles.railNodeWrap}>
              <Animated.View
                style={[
                  styles.railNode,
                  {
                    borderColor:
                      done || current ? (attention && current ? '#FCA5A5' : accent) : 'rgba(255,255,255,0.2)',
                    backgroundColor: done
                      ? accent
                      : current
                        ? attention
                          ? 'rgba(248,113,113,0.22)'
                          : `${accent}28`
                        : 'rgba(255,255,255,0.06)',
                    transform: current
                      ? [
                          {
                            scale: pulse.interpolate({
                              inputRange: [0, 1],
                              outputRange: [1, 1.08],
                            }),
                          },
                        ]
                      : undefined,
                  },
                ]}
              >
                {done ? (
                  <Ionicons name="checkmark" size={16} color="#0A1929" />
                ) : (
                  <Text
                    style={[
                      styles.railNodeText,
                      { color: current ? (attention ? '#FCA5A5' : accent) : 'rgba(248,250,252,0.45)' },
                    ]}
                  >
                    {n}
                  </Text>
                )}
              </Animated.View>
              <Text
                style={[
                  styles.railLabel,
                  {
                    color: current ? gold : done ? 'rgba(248,250,252,0.78)' : 'rgba(248,250,252,0.4)',
                    fontWeight: current ? '800' : '600',
                  },
                ]}
              >
                {step.label}
              </Text>
            </View>
          </React.Fragment>
        );
      })}
    </View>
  );
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const primary = theme.primary || '#9EC9E0';
  const gold = theme.accentAlt || '#E8C547';
  const gradientBg = (theme.background || ['#6A9BB0', '#2A4660']) as [string, string];
  const surface = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const panel = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const border = isLight ? theme.glassBorder || 'rgba(158,201,224,0.42)' : 'rgba(255,255,255,0.12)';
  const textMain = theme.textPrimary || '#F8FAFC';
  const textMuted = theme.textOnBackground || 'rgba(248,250,252,0.66)';

  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedDocumentType, setSelectedDocumentType] = useState<RequiredDocument | null>(null);
  const [supportingOpen, setSupportingOpen] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    void loadDocuments();
    return valeterDocumentsSupabaseService.subscribeToUserDocuments(user.id, () => {
      void loadDocuments(true);
    });
  }, [user?.id]);

  const loadDocuments = async (soft = false) => {
    if (!user?.id) return;
    try {
      if (soft) setRefreshing(true);
      else setLoading(true);
      const userDocs = await valeterDocumentsSupabaseService.listUserDocuments(user.id);
      setDocuments(userDocs);
    } catch {
      Alert.alert('Error', 'Failed to load documents');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const findDocumentForType = (docType: RequiredDocument) =>
    documents.find((d) => d.docTypeId === docType.id);

  const getUiStatus = (docType: RequiredDocument): UiStatus => {
    const doc = findDocumentForType(docType);
    if (!doc) return 'missing';
    if (doc.verificationStatus === 'approved') return 'approved';
    if (doc.verificationStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const requiredStats = useMemo(() => {
    const statuses = REQUIRED_DOCUMENTS.map((d) => getUiStatus(d));
    const approved = statuses.filter((s) => s === 'approved').length;
    const rejected = statuses.filter((s) => s === 'rejected').length;
    const pending = statuses.filter((s) => s === 'pending').length;
    const missing = statuses.filter((s) => s === 'missing').length;
    const uploaded = approved + pending + rejected;
    return { approved, rejected, pending, missing, uploaded, total: REQUIRED_DOCUMENTS.length };
  }, [documents]);

  const activeStep = useMemo(() => {
    if (requiredStats.approved >= requiredStats.total) return 3;
    if (requiredStats.missing === 0) return 2;
    return 1;
  }, [requiredStats]);

  const attention = requiredStats.rejected > 0;

  const nextActionDoc = useMemo(() => {
    const rejected = REQUIRED_DOCUMENTS.find((d) => getUiStatus(d) === 'rejected');
    if (rejected) return rejected;
    const missing = REQUIRED_DOCUMENTS.find((d) => getUiStatus(d) === 'missing');
    if (missing) return missing;
    return null;
  }, [documents]);

  const copy = useMemo(() => {
    if (activeStep === 3) {
      return {
        title: "You're verified",
        body: 'All required documents are approved. You can still add optional docs to boost trust.',
      };
    }
    if (attention) {
      return {
        title: 'One document needs a re-upload',
        body: 'Fix the rejected file, then we’ll keep reviewing the rest.',
      };
    }
    if (activeStep === 2) {
      return {
        title: 'Under review',
        body: 'We’ve got your required uploads. Review usually takes up to 24 hours.',
      };
    }
    return {
      title: 'Upload your documents',
      body: 'Clear photos of your profile, licence, passport or birth certificate, and public liability — one step at a time.',
    };
  }, [activeStep, attention]);

  const openUpload = async (docType: RequiredDocument) => {
    await hapticFeedback('light');
    setSelectedDocumentType(docType);
    setShowSourceModal(true);
  };

  const closeSourceModal = () => {
    setShowSourceModal(false);
    setSelectedDocumentType(null);
  };

  const uploadSelectedDocument = async (localUri: string) => {
    if (!user?.id || !selectedDocumentType) return;
    const docType = selectedDocumentType;
    try {
      setUploading(docType.id);
      setShowSourceModal(false);
      await valeterDocumentsSupabaseService.uploadPhotoDocument({
        userId: user.id,
        docTypeId: docType.id,
        docName: docType.name,
        description: docType.description,
        localUri,
      });
      await loadDocuments(true);
      await hapticFeedback('medium');
    } catch (error: any) {
      Alert.alert('Upload failed', error?.message || 'Unable to upload this document right now.');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const pickFromCamera = async () => {
    if (!selectedDocumentType) return;
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow camera access to take a document photo.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: IMAGE_MEDIA_TYPES,
      quality: 0.8,
      allowsEditing: false,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    await uploadSelectedDocument(result.assets[0].uri);
  };

  const pickFromGallery = async () => {
    if (!selectedDocumentType) return;
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permission.status !== 'granted') {
      Alert.alert('Permission needed', 'Please allow photo library access to choose a document.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: IMAGE_MEDIA_TYPES,
      quality: 0.8,
      allowsEditing: false,
      selectionLimit: 1,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    await uploadSelectedDocument(result.assets[0].uri);
  };

  const primaryLabel = (() => {
    if (activeStep === 3) return 'Done';
    if (nextActionDoc) {
      return getUiStatus(nextActionDoc) === 'rejected'
        ? `Re-upload ${nextActionDoc.name}`
        : `Upload ${nextActionDoc.name}`;
    }
    return 'Refresh status';
  })();

  const onPrimary = () => {
    if (activeStep === 3) {
      router.back();
      return;
    }
    if (nextActionDoc) {
      void openUpload(nextActionDoc);
      return;
    }
    void loadDocuments(true);
  };

  const statusColor = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return '#10B981';
      case 'rejected':
        return '#EF4444';
      case 'pending':
        return '#F59E0B';
      default:
        return 'rgba(248,250,252,0.35)';
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading documents…" />;
  }

  return (
    <View style={styles.flex}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <SafeAreaView style={styles.flex} edges={[]}>
        <ValeterScreenHeader title="Documents" />

        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollInner,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 8,
              paddingBottom: 24,
            },
          ]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => loadDocuments(true)}
              tintColor={primary}
              colors={[primary]}
              progressBackgroundColor="rgba(15,30,48,0.9)"
            />
          }
        >
          <ProgressRail activeStep={activeStep} accent={primary} gold={gold} attention={attention} />

          <View
            style={[
              styles.statusCard,
              { backgroundColor: surface, borderColor: attention ? 'rgba(248,113,113,0.45)' : border },
            ]}
          >
            <Text style={[styles.stepEyebrow, { color: attention ? '#FCA5A5' : gold }]}>
              STEP {activeStep} OF 3
            </Text>
            <Text style={[styles.statusTitle, { color: textMain }]}>{copy.title}</Text>
            <Text style={[styles.statusBody, { color: textMuted }]}>{copy.body}</Text>
            <Text style={[styles.progressMeta, { color: textMuted }]}>
              {requiredStats.approved}/{requiredStats.total} required approved
            </Text>
          </View>

          {nextActionDoc ? (
            <View style={[styles.focusCard, { backgroundColor: surface, borderColor: `${primary}55` }]}>
              <View style={[styles.focusIcon, { backgroundColor: `${primary}22` }]}>
                <Ionicons name={nextActionDoc.icon} size={22} color={primary} />
              </View>
              <View style={styles.focusCopy}>
                <Text style={[styles.focusLabel, { color: gold }]}>UP NEXT</Text>
                <Text style={[styles.focusTitle, { color: textMain }]}>{nextActionDoc.name}</Text>
                <Text style={[styles.focusDesc, { color: textMuted }]}>{nextActionDoc.description}</Text>
              </View>
            </View>
          ) : null}

          <Text style={[styles.checklistTitle, { color: textMuted }]}>Required checklist</Text>
          <View style={[styles.checklist, { backgroundColor: panel, borderColor: border }]}>
            {REQUIRED_DOCUMENTS.map((doc, index) => {
              const status = getUiStatus(doc);
              const docRow = findDocumentForType(doc);
              const color = statusColor(status);
              const busy = uploading === doc.id;
              return (
                <TouchableOpacity
                  key={doc.id}
                  style={[
                    styles.checkRow,
                    index < REQUIRED_DOCUMENTS.length - 1 && styles.checkRowBorder,
                    { borderBottomColor: 'rgba(255,255,255,0.08)' },
                  ]}
                  activeOpacity={status === 'approved' || status === 'pending' ? 1 : 0.85}
                  onPress={() => {
                    if (status === 'missing' || status === 'rejected') void openUpload(doc);
                  }}
                  disabled={busy || status === 'pending'}
                >
                  <View style={[styles.checkDot, { backgroundColor: `${color}22`, borderColor: color }]}>
                    {busy ? (
                      <ActivityIndicator size="small" color={primary} />
                    ) : (
                      <Ionicons
                        name={
                          status === 'approved'
                            ? 'checkmark'
                            : status === 'rejected'
                              ? 'refresh'
                              : status === 'pending'
                                ? 'time'
                                : doc.icon
                        }
                        size={14}
                        color={color}
                      />
                    )}
                  </View>
                  <View style={styles.checkCopy}>
                    <Text style={[styles.checkName, { color: textMain }]}>{doc.name}</Text>
                    <Text style={[styles.checkStatus, { color }]}>
                      {status === 'approved'
                        ? 'Approved'
                        : status === 'rejected'
                          ? 'Rejected — tap to re-upload'
                          : status === 'pending'
                            ? 'Pending review'
                            : 'Not uploaded'}
                    </Text>
                  </View>
                  {docRow?.uri ? (
                    <Image source={{ uri: docRow.uri }} style={styles.checkThumb} />
                  ) : (
                    <Ionicons name="chevron-forward" size={16} color={textMuted} />
                  )}
                </TouchableOpacity>
              );
            })}
          </View>

          <TouchableOpacity
            style={[styles.detailsToggle, { borderColor: border, backgroundColor: panel }]}
            onPress={() => {
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              setSupportingOpen((v) => !v);
            }}
            activeOpacity={0.85}
          >
            <Text style={[styles.detailsToggleText, { color: textMain }]}>Optional documents</Text>
            <Ionicons name={supportingOpen ? 'chevron-up' : 'chevron-down'} size={18} color={primary} />
          </TouchableOpacity>

          {supportingOpen
            ? SUPPORTING_DOCUMENTS.map((doc) => {
                const status = getUiStatus(doc);
                const color = statusColor(status);
                const busy = uploading === doc.id;
                return (
                  <TouchableOpacity
                    key={doc.id}
                    style={[styles.supportRow, { backgroundColor: panel, borderColor: border }]}
                    activeOpacity={0.85}
                    onPress={() => {
                      if (status === 'missing' || status === 'rejected') void openUpload(doc);
                    }}
                    disabled={busy || status === 'pending' || status === 'approved'}
                  >
                    <View style={[styles.checkDot, { backgroundColor: `${color}22`, borderColor: color }]}>
                      {busy ? (
                        <ActivityIndicator size="small" color={primary} />
                      ) : (
                        <Ionicons name={doc.icon} size={14} color={color} />
                      )}
                    </View>
                    <View style={styles.checkCopy}>
                      <Text style={[styles.checkName, { color: textMain }]}>{doc.name}</Text>
                      <Text style={[styles.checkStatus, { color: textMuted }]}>{doc.description}</Text>
                    </View>
                    <Text style={[styles.optionalPill, { color: gold }]}>Optional</Text>
                  </TouchableOpacity>
                );
              })
            : null}
        </ScrollView>

        <View
          style={[
            styles.footer,
            { paddingBottom: Math.max(12, insets.bottom) + VALETER_CONTENT_BOTTOM_PAD },
          ]}
        >
          <ContinueCTAButton
            title={primaryLabel}
            onPress={onPrimary}
            accentColor={primary}
            disabled={!!uploading || refreshing}
            loading={!!uploading}
            showTrailingChevron={!uploading}
            style={styles.primaryCta}
          />
          <Text style={[styles.footerHint, { color: textMuted }]}>
            {activeStep === 3
              ? 'Optional docs can still help you win more bookings.'
              : 'Swipe down anytime to refresh review status.'}
          </Text>
        </View>
      </SafeAreaView>

      <Modal visible={showSourceModal} transparent animationType="slide" onRequestClose={closeSourceModal}>
        <TouchableOpacity activeOpacity={1} style={styles.modalOverlay} onPress={closeSourceModal}>
          <View style={[styles.modalSheet, { backgroundColor: gradientBg[1] }]}>
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: textMain }]}>
              Upload {selectedDocumentType?.name}
            </Text>
            <TouchableOpacity
              style={[styles.sourceOption, { borderColor: border, backgroundColor: surface }]}
              onPress={pickFromCamera}
            >
              <View style={[styles.sourceIcon, { backgroundColor: `${primary}22` }]}>
                <Ionicons name="camera-outline" size={24} color={primary} />
              </View>
              <View style={styles.sourceCopy}>
                <Text style={[styles.sourceTitle, { color: textMain }]}>Take photo</Text>
                <Text style={[styles.sourceSub, { color: textMuted }]}>Use your camera now</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.sourceOption, { borderColor: border, backgroundColor: surface }]}
              onPress={pickFromGallery}
            >
              <View style={[styles.sourceIcon, { backgroundColor: `${primary}22` }]}>
                <Ionicons name="images-outline" size={24} color={primary} />
              </View>
              <View style={styles.sourceCopy}>
                <Text style={[styles.sourceTitle, { color: textMain }]}>Choose photo</Text>
                <Text style={[styles.sourceSub, { color: textMuted }]}>Pick from your gallery</Text>
              </View>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  scroll: { flex: 1 },
  scrollInner: {
    paddingHorizontal: 20,
    gap: 14,
  },
  rail: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
  },
  railNodeWrap: {
    alignItems: 'center',
    width: 72,
    gap: 8,
  },
  railNode: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  railNodeText: {
    fontSize: 13,
    fontWeight: '800',
  },
  railLabel: {
    fontSize: 11,
    textAlign: 'center',
  },
  railLine: {
    flex: 1,
    height: 2,
    marginTop: 17,
    borderRadius: 1,
    maxWidth: 48,
  },
  statusCard: {
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 18,
    paddingVertical: 18,
    gap: 8,
  },
  stepEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  statusTitle: {
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 30,
  },
  statusBody: {
    fontSize: 14,
    lineHeight: 21,
  },
  progressMeta: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '700',
  },
  focusCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
  },
  focusIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  focusCopy: { flex: 1, minWidth: 0 },
  focusLabel: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  focusTitle: {
    marginTop: 2,
    fontSize: 16,
    fontWeight: '800',
  },
  focusDesc: {
    marginTop: 2,
    fontSize: 12,
    lineHeight: 17,
  },
  checklistTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginTop: 4,
  },
  checklist: {
    borderRadius: 18,
    borderWidth: 1,
    overflow: 'hidden',
  },
  checkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  checkRowBorder: {
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  checkDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkCopy: { flex: 1, minWidth: 0 },
  checkName: {
    fontSize: 14,
    fontWeight: '800',
  },
  checkStatus: {
    marginTop: 2,
    fontSize: 11,
    fontWeight: '600',
  },
  checkThumb: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  detailsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  detailsToggleText: {
    fontSize: 14,
    fontWeight: '700',
  },
  supportRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  optionalPill: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 10,
    gap: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  primaryCta: {
    borderRadius: 20,
    minHeight: 52,
  },
  footerHint: {
    fontSize: 12,
    lineHeight: 17,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingBottom: 28,
    paddingTop: 10,
    gap: 12,
  },
  modalHandle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.28)',
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  sourceOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
  },
  sourceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sourceCopy: { flex: 1 },
  sourceTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  sourceSub: {
    marginTop: 2,
    fontSize: 12,
  },
});
