// app/valeter/profile/valeter-profile.tsx

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
  Dimensions,
  Animated,
  Switch,
  Platform,
  ActionSheetIOS,
  ScrollView,
  ActivityIndicator,
  type ViewStyle,
  type TextStyle,
  type ImageStyle,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../../src/services/Valeterstatsservice';
import { ValeterTierService, ValeterTier } from '../../../src/services/ValeterTierService';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../../src/lib/supabase';
import { SCREEN_PADDING_H } from '../../../src/constants/screenLayout';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { lightMistElevated, lightMistPanel, lightMistInput } from '../../../src/constants/accountThemes';
import * as FileSystem from 'expo-file-system/legacy';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { getServicesOfferedFromSettings, type ValeterServiceSettingsRow } from '../../../src/utils/valeterServicesOffered';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';
const COVER_HEIGHT = 140;
/** Full-bleed profile photo fills the card width (square). */
const PROFILE_PHOTO_SIZE = Math.max(240, Math.round(width - SCREEN_PADDING_H * 2));

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

/** Format availability summary from schedule (profile meta). */
function formatAvailabilityForShare(schedule: AvailabilitySchedule | undefined | null): string {
  if (!schedule) return '—';
  const days: (keyof AvailabilitySchedule)[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const enabled = days.filter(d => (schedule as any)[d]?.enabled);
  if (enabled.length === 0) return '—';
  if (enabled.length === 7) return 'Every day';
  const abbr: Record<string, string> = { monday: 'Mon', tuesday: 'Tue', wednesday: 'Wed', thursday: 'Thu', friday: 'Fri', saturday: 'Sat', sunday: 'Sun' };
  return enabled.map(d => abbr[d] || d).join(', ');
}

const DAY_KEYS: (keyof AvailabilitySchedule)[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
function isAvailableToday(schedule: AvailabilitySchedule | undefined | null): boolean {
  if (!schedule) return false;
  const dayIndex = new Date().getDay();
  const key = DAY_KEYS[dayIndex];
  return !!(schedule as any)[key]?.enabled;
}

function LightModeRow() {
  const { mode, toggleMode, theme } = useAccountTheme();
  const titleColor = theme?.textPrimary ?? LIGHT_TEXT;
  const subColor = theme?.textSecondary ?? MUTED_TEXT;
  const primary = theme?.primary ?? SKY;
  const gold = theme?.accentAlt ?? '#E8C547';
  const isLight = mode === 'light';
  return (
    <View
      style={[
        styles.uberMenuItem,
        isLight && {
          backgroundColor: lightMistElevated,
          borderColor: 'rgba(232,197,71,0.28)',
          borderWidth: StyleSheet.hairlineWidth,
        },
      ]}
    >
      <View style={styles.quickActionIconBox}>
        <LocationStyleIconBox icon={mode === 'light' ? 'sunny' : 'moon'} preset={isLight ? 'amber' : 'sky'} />
      </View>
      <View style={styles.uberMenuBody}>
        <Text style={[styles.uberMenuTitle, { color: titleColor }]}>Appearance</Text>
        <Text style={[styles.uberMenuSub, { color: subColor }]}>{mode === 'light' ? 'Light' : 'Dark'} mode</Text>
      </View>
      <Switch
        value={mode === 'light'}
        onValueChange={() => toggleMode()}
        trackColor={{ false: '#334155', true: primary + '99' }}
        thumbColor={mode === 'light' ? gold : '#94A3B8'}
      />
    </View>
  );
}

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  vehicle_photo_url?: string | null;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
  is_self_sufficient?: boolean;
  services_offered?: string[] | null;
}

type BookingRow = {
  id: string;
  valeter_id: string | null;
  status: string; // booking_status enum
  price: number | string | null;
  scheduled_at: string;
  completed_at: string | null;
  updated_at: string;
};

// ✅ New image-picker API (no MediaTypeOptions)
const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;

  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  else if (ext === 'heic') mime = 'image/heic';
  else if (ext === 'heif') mime = 'image/heif';

  return { extRaw, ext, mime };
};

const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#152238'];

export default function ValeterProfile() { // NOSONAR - large screen component; behavior-preserving updates preferred
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = theme?.background ?? VALETER_BG_FALLBACK;
  const primaryColor = theme?.primary ?? SKY;
  const goldColor = theme?.accentAlt ?? '#E8C547';
  const textMain = theme?.textPrimary ?? LIGHT_TEXT;
  const textMuted = theme?.textSecondary ?? MUTED_TEXT;
  const isLight = theme?.mode === 'light';
  const panelBorder = isLight ? 'rgba(158,201,224,0.34)' : undefined;
  const goldBorder = isLight ? 'rgba(232,197,71,0.28)' : undefined;
  const menuItemLight = isLight
    ? { backgroundColor: lightMistElevated, borderColor: 'rgba(158,201,224,0.28)', borderWidth: StyleSheet.hairlineWidth }
    : undefined;
  const pillLight = isLight
    ? { backgroundColor: lightMistInput, borderColor: 'rgba(158,201,224,0.32)', borderWidth: 1 }
    : undefined;
  const { user, logout } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingPicture, setUploadingPicture] = useState(false);

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0,
  });

  const currentTierRef = useRef<ValeterTier | null>(null);

  const [todayStats, setTodayStats] = useState({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const [serviceRadiusMiles, setServiceRadiusMiles] = useState<number | null>(null);
  const [earningsThisMonth, setEarningsThisMonth] = useState<number>(0);
  const [serviceSettings, setServiceSettings] = useState<ValeterServiceSettingsRow | null>(null);

  const servicesOfferedDisplay = useMemo(
    () => getServicesOfferedFromSettings(serviceSettings),
    [serviceSettings]
  );

  const [activeTab, setActiveTab] = useState<'earnings' | 'settings'>('earnings');
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const params = useLocalSearchParams<{ tab?: string | string[] }>();

  useEffect(() => {
    const raw = params.tab;
    const tab = Array.isArray(raw) ? raw[0] : raw;
    if (tab === 'settings') setActiveTab('settings');
    else if (tab === 'earnings') setActiveTab('earnings');
  }, [params.tab]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();
  }, []);

  const getDayRangeISO = () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    return { startISO: start.toISOString(), endISO: end.toISOString() };
  };

  const computeTodayOverviewFromSchema = async (userId: string) => {
    const { startISO, endISO } = getDayRangeISO();

    const { data, error } = await supabase
      .from('bookings')
      .select('id,valeter_id,status,price,scheduled_at,completed_at,updated_at')
      .eq('valeter_id', userId)
      .eq('status', 'completed')
      .gte('completed_at', startISO)
      .lt('completed_at', endISO);

    if (error) throw error;

    const rows = (data || []) as BookingRow[];
    const jobsCompleted = rows.length;
    const earnings = rows.reduce((sum, b) => {
      const n = Number(b.price ?? 0);
      return sum + (Number.isFinite(n) ? n : 0);
    }, 0);

    return {
      hoursOnline: '0h 0m',
      jobsCompleted,
      earnings: Math.round(earnings * 100) / 100,
    };
  };

  useEffect(() => {
    const fetchStats = async () => {
      if (!user?.id) return;

      try {
        const [stats, today] = await Promise.all([
          ValeterStatsService.getValeterStats(user.id),
          computeTodayOverviewFromSchema(user.id),
        ]);
        setValeterStats(stats);
        currentTierRef.current = ValeterTierService.calculateTier(stats);
        setTodayStats(today);
      } catch (error) {
        console.error('Error fetching valeter stats:', error);
      }
    };

    fetchStats();
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      // Phase 1: Load critical profile data first
      loadProfile();
      
      // Phase 2: Load secondary data in background (non-blocking)
      Promise.all([
        loadServiceRadiusAndEarnings(),
        loadServiceSettings(),
      ]).catch((error) => {
        console.error('Error loading secondary profile data:', error);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadServiceRadiusAndEarnings = async () => {
    if (!user?.id) return;
    try {
      const { value: radiusMi } = await fetchRadiusPreference(user.id);
      setServiceRadiusMiles(radiusMi ?? null);
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const { data } = await supabase
        .from('bookings')
        .select('price')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .gte('completed_at', firstDayOfMonth.toISOString());
      const total = (data || []).reduce((sum, b) => sum + (Number((b as any).price) || 0), 0);
      setEarningsThisMonth(total);
    } catch (e) {
      console.warn('Error loading radius/earnings:', e);
    }
  };

  const loadServiceSettings = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('valeter_service_settings')
        .select('tier_pricing, detailing_offered, detailing_menu')
        .eq('valeter_id', user.id)
        .maybeSingle();
      if (!error && data) setServiceSettings(data);
    } catch {
      // table may not exist yet
    }
  };

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.from('valeter_profiles').select('*').eq('user_id', user!.id).maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: (user as any)?.name || 'Car Care Pro',
          bio: 'Professional mobile car care pro',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };

        const { data: created, error: createError } = await supabase.from('valeter_profiles').insert(newProfile).select().single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const BUCKET = 'valeter_documents';

  const base64ToUint8Array = (base64: string) => {
    const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.codePointAt(i) ?? 0;
    return bytes;
  };

  // ✅ Expo Go safe Supabase Storage upload (no blob.arrayBuffer)
  async function uploadUriToSupabase(uri: string, path: string, contentType = 'image/jpeg') {
    const fileUri = uri;

    const base64 = await FileSystem.readAsStringAsync(fileUri, {
      encoding: 'base64' as any,
    });

    const bytes = base64ToUint8Array(base64);

    const { data, error } = await supabase.storage.from(BUCKET).upload(path, bytes, {
      contentType,
      upsert: true,
    });

    if (error) {
      const msg = String(error?.message || '').toLowerCase();
      if (msg.includes('bucket') || msg.includes('not found')) {
        throw new Error("Storage bucket 'valeter_documents' was not found or is not accessible.");
      }
      if (msg.includes('row-level security') || msg.includes('policy') || msg.includes('permission')) {
        throw new Error('Upload blocked by storage policy. Please update Supabase Storage RLS for valeter uploads.');
      }
      throw error;
    }

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  const persistProfilePhotoUrl = async (publicUrl: string) => {
    if (!user?.id) throw new Error('No user');

    // Guarantee persistence even if row doesn't exist yet.
    const profileUpsert = await supabase
      .from('valeter_profiles')
      .upsert(
        {
          user_id: user.id,
          profile_photo_url: publicUrl,
          full_name: (profile?.full_name || user?.name || ' ').trim() || ' ',
        },
        { onConflict: 'user_id' }
      );

    if (profileUpsert.error) throw profileUpsert.error;

    // Keep generic profile in sync for screens that read from profiles.profile_picture.
    await supabase.from('profiles').update({ profile_picture: publicUrl }).eq('id', user.id);
  };

  const uploadProfilePhoto = async (uri: string) => {
    try {
      if (!user?.id) throw new Error('No user');

      const { extRaw, mime } = getExtAndMimeFromUri(uri);
      const fileName = `profile_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
      const storagePath = `profiles/${user.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, mime);
      if (!publicUrl) throw new Error('Upload succeeded but no public URL was returned.');

      await persistProfilePhotoUrl(publicUrl);

      setProfilePicture(publicUrl);
      setProfile((prev) => (prev ? { ...prev, profile_photo_url: publicUrl } : null));

      await hapticFeedback('medium');
      Alert.alert('Success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('[ValeterProfile] uploadProfilePhoto failed:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };

  const takePhoto = async () => {
    if (uploadingPicture) return;
    try {
      setUploadingPicture(true);

      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error: any) {
      console.error('[ValeterProfile] takePhoto error:', error);
      Alert.alert('Error', error?.message || 'Failed to take photo. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const pickImage = async () => {
    if (uploadingPicture) return;
    try {
      setUploadingPicture(true);

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error: any) {
      console.error('[ValeterProfile] pickImage error:', error);
      Alert.alert('Error', error?.message || 'Failed to select image. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');

      if (uploadingPicture) return;

      if (Platform.OS === 'ios') {
        ActionSheetIOS.showActionSheetWithOptions(
          {
            title: 'Upload Profile Picture',
            message: 'Choose how you want to add your profile picture',
            options: ['Cancel', 'Take Photo', 'Choose from Gallery'],
            cancelButtonIndex: 0,
            userInterfaceStyle: 'dark',
          },
          async (buttonIndex) => {
            if (buttonIndex === 1) await takePhoto();
            if (buttonIndex === 2) await pickImage();
          }
        );
      } else {
        Alert.alert('Upload Profile Picture', 'Choose how you want to add your profile picture', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Take Photo', onPress: () => { void takePhoto(); } },
          { text: 'Choose from Gallery', onPress: () => { void pickImage(); } },
        ]);
      }
    } catch (e) {
      console.warn('[ValeterProfile] handleUploadProfilePicture error:', e);
    }
  };

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert('Logout', 'Are you sure you want to logout?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                await logout();
              } catch (error) {
                console.error('Logout error:', error);
                Alert.alert('Logout Error', 'Failed to logout. Please try again.');
              }
            })();
          },
        },
      ]);
    } catch {}
  };


  if (isLoading) {
    return <LoadingScreen message="Loading profile…" />;
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={VALETER_BG_FALLBACK} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  const hasProfileBio = Boolean(profile.bio?.trim());
  let experienceLabel: string | null = null;
  if (profile.experience) {
    experienceLabel = `${profile.experience} experience`;
  } else if (valeterStats.experienceMonths >= 12) {
    experienceLabel = `${Math.floor(valeterStats.experienceMonths / 12)}+ years experience`;
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      {isLight ? (
        <LinearGradient
          colors={['rgba(158,201,224,0.18)', 'rgba(232,197,71,0.07)', 'transparent']}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
      ) : null}
      <BubbleBackground accountType="valeter" />

      <ValeterScreenHeader
        title="Profile"
        rightAction={
          <TouchableOpacity
            onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-personal-info'); }}
            style={styles.shareHeaderButton}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="pencil" size={22} color={isLight ? goldColor : SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.ScrollView
          style={styles.scrollView}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={16}
          contentContainerStyle={{
            paddingTop: HEADER_CONTENT_OFFSET + 8,
            paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24,
            paddingHorizontal: SCREEN_PADDING_H,
          }}
          showsVerticalScrollIndicator={false}
        >
          <Animated.View style={[styles.contentWrap, { opacity: fadeAnim }]}>
            <View style={styles.profileCard}>
              <View style={styles.profileAvatarRow}>
                <TouchableOpacity
                  onPress={handleUploadProfilePicture}
                  disabled={uploadingPicture}
                  style={styles.profileAvatarTouch}
                  activeOpacity={0.9}
                >
                  <View
                    style={[
                      styles.profileAvatarOuter,
                      isLight && {
                        backgroundColor: lightMistElevated,
                        borderColor: 'rgba(158,201,224,0.35)',
                      },
                    ]}
                  >
                    {profilePicture ? (
                      <Image
                        source={{ uri: profilePicture }}
                        style={styles.profileAvatarImg}
                        resizeMode="cover"
                      />
                    ) : (
                      <View style={styles.profileAvatarPlaceholder}>
                        <Ionicons name="person" size={52} color={primaryColor} />
                        <Text style={[styles.profileAvatarHint, { color: textMuted }]}>
                          Tap to add your photo
                        </Text>
                      </View>
                    )}
                    <View style={[styles.profileCameraBadge, { backgroundColor: primaryColor }]}>
                      {uploadingPicture ? (
                        <ActivityIndicator size="small" color="#0A1929" />
                      ) : (
                        <Ionicons name="camera" size={16} color="#0A1929" />
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
              <Text style={[styles.profileName, { color: textMain }]} numberOfLines={1}>{profile.full_name || 'Car Care Pro'}</Text>
              {hasProfileBio ? (
                <Text style={[styles.profileMeta, { color: textMuted, textAlign: 'center', marginBottom: 6, paddingHorizontal: 8 }]} numberOfLines={2}>{profile.bio}</Text>
              ) : (
                <Text style={[styles.profileMeta, { color: textMuted, fontStyle: 'italic', opacity: 0.8, textAlign: 'center', marginBottom: 6 }]}>Add a short bio in Personal info</Text>
              )}
              <View style={styles.profileMetaRow}>
                {experienceLabel ? <Text style={[styles.profileMeta, { color: textMuted }]}>{experienceLabel}</Text> : null}
                {serviceRadiusMiles != null && (
                  <Text style={[styles.profileMeta, { color: textMuted }]}> · {serviceRadiusMiles} mile radius</Text>
                )}
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.profilePillsWheel}
              >
                {(servicesOfferedDisplay.length > 0 ? servicesOfferedDisplay.slice(0, 5) : ['Tap to set wash, detail & repair prices']).map((label, idx) => (
                  <View key={`${label}-${idx}`} style={[styles.profilePill, isLight && pillLight]}>
                    <Text style={[styles.profilePillText, { color: textMain }]}>{label}</Text>
                  </View>
                ))}
                {profile?.verification_badge && (
                  <View style={[styles.profilePill, isLight && pillLight]}>
                    <Ionicons name="shield-checkmark" size={12} color={primaryColor} />
                    <Text style={[styles.profilePillText, { color: textMain }]}>Verified</Text>
                  </View>
                )}
              </ScrollView>
            </View>

            <TouchableOpacity
              style={[styles.activityRow, isLight && { backgroundColor: lightMistElevated, borderColor: goldBorder }]}
              onPress={async () => { await hapticFeedback('light'); router.push('/valeter/features/job-history'); }}
              activeOpacity={0.85}
            >
              <View style={styles.activityRowInner}>
                <Ionicons name="today-outline" size={22} color={primaryColor} />
                <View style={styles.activityRowTextWrap}>
                  <Text style={[styles.activityRowLabel, { color: textMain }]}>Today</Text>
                  <Text style={[styles.activityRowSub, { color: textMuted }]}>
                    {todayStats.jobsCompleted} jobs ·{' '}
                    <Text style={{ color: isLight ? goldColor : textMuted, fontWeight: '700' }}>
                      £{Number(todayStats.earnings || 0).toFixed(2)}
                    </Text>
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={textMuted} />
              </View>
            </TouchableOpacity>

            <View style={[styles.tabToggleRow, isLight && { backgroundColor: lightMistPanel, borderColor: panelBorder }]}>
              {(['earnings', 'settings'] as const).map((tab) => {
                const selected = activeTab === tab;
                return (
                  <TouchableOpacity
                    key={tab}
                    style={[
                      styles.tabToggleBtn,
                      selected && [styles.tabToggleBtnActive, { borderColor: `${primaryColor}40`, backgroundColor: isLight ? lightMistElevated : undefined }],
                    ]}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setActiveTab(tab);
                    }}
                    activeOpacity={0.8}
                  >
                    <Text style={[
                      styles.tabToggleText,
                      { color: textMuted },
                      selected && [styles.tabToggleTextActive, { color: textMain }],
                    ]}>
                      {tab === 'earnings' ? 'Earnings' : 'Settings'}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {activeTab === 'earnings' && (
              <GlassCard style={styles.sectionCard} accountType="valeter">
                <View style={styles.sectionHeaderRow}>
                  <LocationStyleIconBox icon="wallet-outline" preset="green" style={{ marginRight: 10 }} />
                  <Text style={[styles.sectionCardSubtitle, { color: textMain }]}>Earnings</Text>
                </View>
                <Text style={[styles.sectionCardDescription, { color: textMuted }]}>Private — only you see this</Text>
                <View style={styles.earningsSummaryRow}>
                  <View style={styles.earningsSummaryBlock}>
                    <Text style={[styles.earningsSummaryLabel, { color: textMuted }]}>This month</Text>
                    <Text style={[styles.earningsSummaryValue, { color: isLight ? goldColor : textMain }]}>£{earningsThisMonth.toFixed(2)}</Text>
                    <Text style={[styles.earningsSummarySub, { color: textMuted }]}>{valeterStats.jobsThisMonth} jobs</Text>
                  </View>
                  <View style={styles.earningsSummaryBlock}>
                    <Text style={[styles.earningsSummaryLabel, { color: textMuted }]}>Total earned</Text>
                    <Text style={[styles.earningsSummaryValue, { color: isLight ? goldColor : textMain }]}>£{Number(valeterStats.totalEarnings || 0).toFixed(2)}</Text>
                    <Text style={[styles.earningsSummarySub, { color: textMuted }]}>{valeterStats.totalJobs} jobs</Text>
                  </View>
                </View>
                <TouchableOpacity style={styles.earningsHistoryLink} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/valeter-wash-history'); }} activeOpacity={0.8}>
                  <Text style={[styles.earningsHistoryLinkText, { color: primaryColor }]}>View earnings history</Text>
                  <Ionicons name="chevron-forward" size={18} color={primaryColor} />
                </TouchableOpacity>
              </GlassCard>
            )}

            {activeTab === 'settings' && (
              <View style={styles.menuBlock}>
                <LightModeRow />
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-notification-preferences'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="notifications-outline" preset="pink" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Notifications</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Alerts & preferences</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-services'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="wallet-outline" preset="sky" />
                  </View>
                  <View style={styles.uberMenuBody}>
                    <Text style={[styles.uberMenuTitle, { color: textMain }]}>Services & pricing</Text>
                    <Text style={[styles.uberMenuSub, { color: textMuted }]}>Wash tiers, detailing & repairs</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-vehicle-info'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="car-sport-outline" preset="amber" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Vehicle</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Update your car details</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/settings/working-hours'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="time-outline" preset="green" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Working hours</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Open original schedule settings</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/stripe-connect'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="wallet-outline" preset="green" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Stripe Connect</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Payouts and onboarding</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/settings/distance-covering'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="navigate-outline" preset="cyan" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Distance covering</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Open original radius settings</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/profile/valeter-documents'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="document-text-outline" preset="amber" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Documents</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Verification & uploads</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/features/referral-system'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="people-outline" preset="purple" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Referrals</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Invite valeters, earn points</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/valeter-rewards-system'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="gift-outline" preset="amber" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Rewards</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Points, tiers & perks</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/valeter/support/help-support'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="help-circle-outline" preset="sky" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Help & support</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>FAQs and contact</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, menuItemLight]} onPress={async () => { await hapticFeedback('light'); router.push('/terms-of-service'); }} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="document-text-outline" preset="sky" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Terms and conditions</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Platform and account terms</Text></View>
                  <Ionicons name="chevron-forward" size={18} color={textMuted} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.uberMenuItem, styles.uberMenuItemDanger, isLight && { backgroundColor: 'rgba(239,68,68,0.1)' }]} onPress={handleLogout} activeOpacity={0.7}>
                  <View style={styles.quickActionIconBox}>
                    <LocationStyleIconBox icon="log-out-outline" preset="red" />
                  </View>
                  <View style={styles.uberMenuBody}><Text style={[styles.uberMenuTitle, { color: textMain }]}>Log out</Text><Text style={[styles.uberMenuSub, { color: textMuted }]}>Sign out of your account</Text></View>
                  <Ionicons name="chevron-forward" size={18} color="rgba(239,68,68,0.8)" />
                </TouchableOpacity>
              </View>
            )}

            <View style={styles.appInfoSection}>
              <Text style={[styles.appInfoText, { color: textMuted }]}>Wish a Wash v1.0.0</Text>
              <Text style={[styles.appInfoText, { color: textMuted }]}>© 2026 Wish a Wash. All rights reserved.</Text>
            </View>
          </Animated.View>
      </Animated.ScrollView>

    </SafeAreaView>
  );
}



const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#F9FAFB', fontSize: 18, marginTop: 12 },
  contentWrap: { width: '100%' },
  heroBlock: {
    alignItems: 'center',
    paddingTop: 8,
    paddingBottom: 18,
  },
  heroAvatarTouch: {
    position: 'relative',
    marginBottom: 14,
  },
  heroAvatarRing: {
    width: 104,
    height: 104,
    borderRadius: 52,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 3,
  },
  heroAvatarImg: {
    width: 96,
    height: 96,
    borderRadius: 48,
  },
  heroAvatarPlaceholder: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: 'rgba(15,23,42,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroCameraBadge: {
    position: 'absolute',
    right: 4,
    bottom: 4,
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  heroName: {
    color: LIGHT_TEXT,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.6,
    textAlign: 'center',
  },
  heroBio: {
    color: MUTED_TEXT,
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 6,
    paddingHorizontal: 20,
    lineHeight: 20,
  },
  heroBioEmpty: {
    fontStyle: 'italic',
    opacity: 0.75,
  },
  heroMetaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    gap: 6,
  },
  heroMeta: {
    color: 'rgba(249,250,251,0.55)',
    fontSize: 12,
    fontWeight: '600',
  },
  verifiedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: 'rgba(56,189,248,0.12)',
  },
  verifiedChipText: {
    fontSize: 11,
    fontWeight: '800',
  },
  pulseStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.42)',
    marginBottom: 16,
    overflow: 'hidden',
  },
  pulseCell: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
  },
  pulseValue: {
    color: LIGHT_TEXT,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  pulseLabel: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '700',
    marginTop: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  pulseDivider: {
    width: 1,
    alignSelf: 'stretch',
    marginVertical: 12,
  },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 16,
  },
  quickTile: {
    width: '47.5%',
    flexGrow: 1,
    minWidth: '45%',
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(15,23,42,0.4)',
    alignItems: 'flex-start',
    gap: 10,
  },
  quickTileLabel: {
    color: LIGHT_TEXT,
    fontSize: 14,
    fontWeight: '800',
  },
  monthSnapshot: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    backgroundColor: 'rgba(15,23,42,0.4)',
    marginBottom: 14,
  },
  monthSnapshotLabel: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  monthSnapshotValue: {
    color: LIGHT_TEXT,
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.4,
    marginTop: 2,
  },
  monthSnapshotSub: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  monthSnapshotCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
  },
  monthSnapshotCtaText: {
    fontSize: 13,
    fontWeight: '800',
  },
  servicePills: {
    gap: 8,
    paddingBottom: 8,
    marginBottom: 8,
  },
  servicePill: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  servicePillText: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 12,
    fontWeight: '700',
  },
  sectionBlock: {
    marginBottom: 20,
  },
  sectionLabel: {
    color: 'rgba(249,250,251,0.45)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
    marginBottom: 8,
    paddingHorizontal: 2,
  },
  sectionStack: {
    gap: 8,
  },
  linkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  linkRowDanger: {
    backgroundColor: 'rgba(239,68,68,0.08)',
    borderColor: 'rgba(239,68,68,0.18)',
  },
  linkBody: { flex: 1, minWidth: 0 },
  linkTitle: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '800', marginBottom: 2 },
  linkTitleDanger: { color: '#FCA5A5' },
  linkSub: { color: 'rgba(249,250,251,0.55)', fontSize: 12, fontWeight: '600' },
  headerRightActions: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  floatingMenuCorner: {
    position: 'absolute',
    left: SCREEN_PADDING_H,
    zIndex: 50,
  },
  floatingActionCorner: {
    position: 'absolute',
    right: SCREEN_PADDING_H,
    zIndex: 50,
  },
  scrollView: { flex: 1 },

  coverWrapper: { marginHorizontal: -SCREEN_PADDING_H },
  coverBanner: {
    height: COVER_HEIGHT,
    width: width + SCREEN_PADDING_H * 2,
    maxWidth: '100%',
    alignSelf: 'center',
  },
  coverSpacer: { height: 0 },
  profileCard: {
    marginTop: 12,
    alignItems: 'center',
    marginBottom: 20,
    width: '100%',
  },
  profileAvatarRow: { width: '100%', marginBottom: 14 },
  profileAvatarWrap: {
    position: 'relative' as const,
    width: '100%',
    alignSelf: 'center',
  },
  profileAvatarTouch: { width: '100%' },
  profileAvatarOuter: {
    width: '100%',
    height: PROFILE_PHOTO_SIZE,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  profileAvatarInner: {
    width: '100%',
    height: '100%',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileAvatarImg: { width: '100%', height: '100%' },
  profileAvatarPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: `${SKY}18`,
  },
  profileAvatarHint: {
    fontSize: 13,
    fontWeight: '700',
  },
  profileCameraBadge: {
    position: 'absolute',
    right: 14,
    bottom: 14,
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'rgba(10,25,41,0.35)',
  },
  profileName: {
    color: LIGHT_TEXT,
    fontSize: isSmallScreen ? 22 : 24,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  profileMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  profileMeta: { color: MUTED_TEXT, fontSize: 14, fontWeight: '600' },
  profileTierLine: { color: MUTED_TEXT, fontSize: 13, marginBottom: 8 },
  profilePills: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center', marginTop: 8 },
  profilePillsWheel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 10,
    paddingTop: 2,
    paddingBottom: 4,
  },
  profilePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  profilePillText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '700' },
  profileHeroBio: { color: MUTED_TEXT, fontSize: 14, lineHeight: 20, textAlign: 'center', marginBottom: 6, paddingHorizontal: 8 },
  profileHeroBioPlaceholder: { color: 'rgba(249,250,251,0.5)', fontSize: 13, fontStyle: 'italic', textAlign: 'center', marginBottom: 6 },
  profileHeroMeta: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', gap: 4, marginBottom: 8 },
  profileServiceTags: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, marginBottom: 10 },
  profileServiceTag: { paddingVertical: 4, paddingHorizontal: 10, borderRadius: 12, backgroundColor: 'rgba(56,189,248,0.15)' },
  profileServiceTagText: { color: LIGHT_TEXT, fontSize: 12, fontWeight: '600' },
  profileAvailabilityText: { color: MUTED_TEXT, fontSize: 13, textAlign: 'center' },
  sectionCardSubtitle: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '800', marginBottom: 4 },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  sectionCardDescription: { color: MUTED_TEXT, fontSize: 13, marginBottom: 16 },
  publicPreviewRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 14, marginBottom: 14 },
  publicPreviewAvatar: { width: 56, height: 56, borderRadius: 28, overflow: 'hidden', backgroundColor: 'rgba(255,255,255,0.06)' },
  publicPreviewAvatarImg: { width: '100%', height: '100%' },
  publicPreviewAvatarPlaceholder: { width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', backgroundColor: `${SKY}20` },
  publicPreviewText: { flex: 1, minWidth: 0 },
  publicPreviewName: { color: LIGHT_TEXT, fontSize: 16, fontWeight: '800', marginBottom: 4 },
  publicPreviewBio: { color: MUTED_TEXT, fontSize: 13, marginBottom: 4 },
  publicPreviewBioPlaceholder: { color: 'rgba(249,250,251,0.5)', fontSize: 13, fontStyle: 'italic', marginBottom: 4 },
  publicPreviewMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 6 },
  publicPreviewMetaText: { color: MUTED_TEXT, fontSize: 12 },
  publicPreviewTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 6 },
  publicPreviewTag: { paddingVertical: 2, paddingHorizontal: 8, borderRadius: 8, backgroundColor: 'rgba(56,189,248,0.12)' },
  publicPreviewTagText: { color: LIGHT_TEXT, fontSize: 11, fontWeight: '600' },
  publicPreviewAvailable: { marginTop: 4 },
  publicPreviewAvailableText: { color: '#10B981', fontSize: 12, fontWeight: '700' },
  editPublicButton: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8, paddingVertical: 10 },
  editPublicButtonText: { color: SKY, fontSize: 14, fontWeight: '700' },
  trustRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  trustStat: { alignItems: 'center', flex: 1 },
  trustStars: { flexDirection: 'row', gap: 2, marginBottom: 4 },
  trustStatValue: { color: LIGHT_TEXT, fontSize: 18, fontWeight: '800' },
  trustStatLabel: { color: MUTED_TEXT, fontSize: 12, marginTop: 2 },
  verifiedBadgeRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 12, backgroundColor: 'rgba(16,185,129,0.12)', marginBottom: 14 },
  verifiedBadgeText: { color: '#10B981', fontSize: 14, fontWeight: '700' },
  beforeAfterSection: { paddingVertical: 12, paddingHorizontal: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)', borderStyle: 'dashed' },
  beforeAfterLabel: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '700', marginBottom: 4 },
  beforeAfterHint: { color: MUTED_TEXT, fontSize: 12 },
  earningsSummaryRow: { flexDirection: 'row', gap: 12, marginBottom: 18 },
  earningsSummaryBlock: { flex: 1, paddingVertical: 14, paddingHorizontal: 14, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.06)' },
  earningsSummaryLabel: { color: MUTED_TEXT, fontSize: 12, marginBottom: 4 },
  earningsSummaryValue: { color: LIGHT_TEXT, fontSize: 20, fontWeight: '800' },
  earningsSummarySub: { color: MUTED_TEXT, fontSize: 12, marginTop: 2 },
  earningsHistoryLink: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10 },
  earningsHistoryLinkText: { color: SKY, fontSize: 14, fontWeight: '700' },

  shareHeaderButton: {
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },

  activityRow: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  activityRowInner: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, paddingHorizontal: 16, gap: 12 },
  activityRowTextWrap: { flex: 1 },
  activityRowLabel: { fontSize: 16, fontWeight: '700', color: LIGHT_TEXT },
  activityRowSub: { fontSize: 12, color: MUTED_TEXT, marginTop: 2 },
  tabToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 4,
    marginBottom: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  tabToggleBtn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  tabToggleBtnActive: {
    backgroundColor: 'rgba(135,206,235,0.14)',
  },
  tabToggleText: {
    color: 'rgba(249,250,251,0.68)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  tabToggleTextActive: {
    color: '#F9FAFB',
    fontWeight: '800',
  },
  sectionCard: { padding: 20, marginBottom: 16, borderRadius: 20 },
  viewAsCustomerIconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(56,189,248,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionCardTitle: { color: LIGHT_TEXT, fontSize: 18, fontWeight: '800', marginBottom: 16 },
  aboutBio: { color: MUTED_TEXT, fontSize: 14, lineHeight: 20, marginBottom: 12 },
  aboutPlaceholder: { color: MUTED_TEXT, fontSize: 13, fontStyle: 'italic', marginBottom: 12 },
  menuBlock: { marginBottom: 16 },

  uberHero: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 20,
    marginBottom: 8,
  },
  uberAvatarWrap: { position: 'relative', marginBottom: 12 },
  uberAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  uberAvatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  uberVerifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  uberName: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', marginBottom: 4 },
  uberEmail: { color: 'rgba(249,250,251,0.7)', fontSize: 14, marginBottom: 4 },
  uberTier: { color: SKY, fontSize: 13, fontWeight: '600' },
  uberTodayStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginHorizontal: 16,
    marginBottom: 20,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
  },
  uberTodayLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '600' },
  uberTodayValue: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  uberMenuBlock: { marginBottom: 24, paddingHorizontal: 16 },
  uberMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    gap: 12,
  },
  uberMenuItemDanger: { backgroundColor: 'rgba(239,68,68,0.08)' },
  quickActionIconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberMenuIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  uberMenuBody: { flex: 1, minWidth: 0 },
  uberMenuTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 2 },
  uberMenuSub: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },

  heroSection: { padding: 20, alignItems: 'center', marginBottom: 24 },
  profilePictureContainer: { alignItems: 'center', marginBottom: 20, position: 'relative' },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    overflow: 'hidden',
  },
  profilePicturePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileImage: { width: '100%', height: '100%', borderRadius: 60 },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  uploadButtonDisabled: { opacity: 0.7, backgroundColor: '#6B7280' },

  profileInfo: { alignItems: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  userName: { color: '#F9FAFB', fontSize: isSmallScreen ? 24 : 28, fontWeight: '800' },
  emailRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  userEmail: { color: SKY, fontSize: isSmallScreen ? 14 : 16 },
  userExperience: { color: SKY, fontSize: isSmallScreen ? 14 : 16, fontStyle: 'italic' },
  selfSufficiencyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignSelf: 'flex-start',
  },
  selfSufficiencyText: { fontSize: 12, fontWeight: '600' },

  tierBadgeIcon: { fontSize: 40 },
  tierInfoCard: { borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  tierInfoCardGradient: { padding: 12 },
  tierInfoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  tierInfoIcon: { fontSize: 32 },
  tierInfoTextContainer: { flex: 1 },
  tierInfoTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', marginBottom: 4 },
  tierInfoSubtitle: { color: '#E0E7FF', fontSize: 13, fontWeight: '500' },
  tierInfoProgress: { alignItems: 'flex-end' },
  tierInfoProgressText: { fontSize: 18, fontWeight: '900', marginBottom: 2 },
  tierInfoProgressLabel: { color: '#E0E7FF', fontSize: 11, fontWeight: '600' },

  section: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  sectionHeaderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeaderText: {
    flex: 1,
    gap: 4,
  },
  sectionTitle: { 
    color: '#F9FAFB', 
    fontSize: 20, 
    fontWeight: '600', 
    letterSpacing: -0.3, 
    marginBottom: 0,
  },
  sectionSubtitle: { 
    color: 'rgba(249,250,251,0.65)', 
    fontSize: 13, 
    fontWeight: '500',
    lineHeight: 18,
    marginBottom: 0,
  },
  settingsCard: {
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginTop: 0,
    marginBottom: 12,
    overflow: 'hidden',
  },
  featuredToggleRow: {
    marginBottom: 14,
  },
  featuredToggleBackground: {
    borderRadius: 16,
    padding: 16,
  },
  featuredToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  featuredToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flex: 1,
  },
  featuredIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featuredIconWrapperActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  featuredToggleText: {
    flex: 1,
    gap: 2,
  },
  featuredToggleLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  featuredToggleDescription: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  preferencesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  preferenceCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 10,
  },
  preferenceIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  preferenceIconBoxActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  preferenceLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  scheduleCard: {
    borderRadius: 18,
    padding: 14,
    marginTop: 0,
    overflow: 'hidden',
  },
  scheduleDayCard: {
    paddingVertical: 10,
    paddingHorizontal: 4,
  },
  scheduleDayCardActive: {
    backgroundColor: 'rgba(16,185,129,0.08)',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  scheduleDayContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  scheduleDayLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  scheduleDayBadge: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleDayBadgeActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  scheduleDayBadgeWeekend: {
    backgroundColor: 'rgba(251,191,36,0.1)',
    borderColor: 'rgba(251,191,36,0.2)',
  },
  scheduleDayAbbr: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  scheduleDayAbbrActive: {
    color: '#10B981',
  },
  scheduleDayLabel: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: -0.2,
    minWidth: 100,
  },
  scheduleDayLabelActive: {
    color: '#F9FAFB',
  },
  scheduleTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    marginRight: 8,
    justifyContent: 'flex-end',
  },
  scheduleTimeInput: {
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 5,
    minWidth: 65,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleTimeInputText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.5,
    textAlign: 'center',
    padding: 0,
    width: '100%',
    height: '100%',
    textAlignVertical: 'center',
  },
  scheduleTimeSeparator: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '700',
    marginHorizontal: 4,
  },
  scheduleOffBadge: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  scheduleOffText: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  scheduleDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginLeft: 52,
    marginVertical: 6,
  },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  statCard: {
    width: (width - 48) / 2 - 6,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  statCardContent: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statTextContainer: { flex: 1 },
  statNumber: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#F9FAFB', marginBottom: 2 },
  statLabel: { fontSize: 12, color: SKY, fontWeight: '600' },

  businessCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
  },
  businessHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  businessInfo: { flex: 1 },
  businessTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  businessSubtitle: { color: SKY, fontSize: 13, marginTop: 2 },

  documentsCard: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    marginTop: 12,
  },
  documentsCardGradient: { padding: 18 },
  documentsCardContent: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  documentsIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentsTextContainer: { flex: 1, gap: 4 },
  documentsCardTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', letterSpacing: 0.2 },
  documentsCardSubtitle: { color: '#87CEEB', fontSize: 13, opacity: 0.9, fontWeight: '600' },

  menuSection: { gap: 8 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    marginBottom: 8,
  },
  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  menuContent: { flex: 1 },
  menuTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: '#87CEEB', fontSize: 11, fontWeight: '600' },

  settingsContainer: { gap: 12 },
  // Logout
  logoutCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  logoutContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  logoutIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  logoutTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  logoutSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  // Delete Account
  deleteCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  deleteContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  deleteIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  deleteTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  deleteSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },

  appInfoSection: { padding: 20 },
  appInfoText: { color: SKY, fontSize: 12, textAlign: 'center', marginBottom: 4, opacity: 0.7 },

  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },

  // ✅ Modal styles - Redesigned
  modalOverlay: {
    flex: 1,
    padding: 0,
    justifyContent: 'flex-end',
  },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.75)',
  },
  modalCard: {
    height: '90%',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    backgroundColor: 'rgba(10,25,41,0.98)',
    overflow: 'hidden',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  modalHeader: {
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  modalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    flex: 1,
  },
  modalHeaderIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 18,
    overflow: 'hidden',
  },
  modalHeaderIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalHeaderText: {
    flex: 1,
    gap: 4,
  },
  modalTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: '800', letterSpacing: 0.3 },
  modalSub: { color: 'rgba(249,250,251,0.6)', fontSize: 14, marginTop: 2, lineHeight: 20 },
  modalScrollContent: {
    paddingBottom: 40,
  },
  modalIconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionHeaderContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 20,
  },
  modalLoading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  modalLoadingText: { color: 'rgba(249,250,251,0.8)', fontWeight: '800' },

  modalSection: { padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(135,206,235,0.1)' },
  modalSectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', letterSpacing: 0.2 },
  modalHint: { color: 'rgba(249,250,251,0.6)', fontSize: 13, marginTop: 4, lineHeight: 20 },

  // Tabs + tier cards (same as business)
  tabsRow: {
    flexDirection: 'row',
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 10,
    padding: 4,
  },
  serviceTab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
  },
  serviceTabActive: { backgroundColor: 'rgba(135,206,235,0.25)' },
  serviceTabText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '600' },
  serviceTabTextActive: { color: '#F9FAFB' },
  tierCardsList: { gap: 12, marginTop: 8 },
  tierCard: {
    borderRadius: 20,
    padding: 0,
    overflow: 'hidden',
  },
  tierContent: { padding: 18, gap: 16 },
  tierInfo: { flex: 1 },
  tierHeader: { gap: 8 },
  tierTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
  },
  tierName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.2,
    flex: 1,
  },
  badgeRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.25)',
  },
  ecoBadgeText: { color: '#10B981', fontSize: 10, fontWeight: '700', letterSpacing: 0.2 },
  tierBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  priceSummaryRow: { marginTop: 6 },
  priceSummaryText: { color: 'rgba(249,250,251,0.85)', fontSize: 16, fontWeight: '800', letterSpacing: -0.3 },
  infoIconButton: { padding: 4, marginLeft: 2 },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  switchLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  switchLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '700' },
  switchLabelDisabled: { color: 'rgba(249,250,251,0.50)' },

  // Pricing bottom sheet (same as business)
  pricingSheetContainer: { flex: 1, justifyContent: 'flex-end' },
  pricingSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    paddingHorizontal: 24,
    paddingTop: 12,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 24,
    maxHeight: '85%',
  },
  /** Use when rendering a pricing modal/sheet (distinct from tab/view-as-customer `sheetHandle`) */
  pricingSheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 24,
  },
  sheetHeader: { marginBottom: 24, alignItems: 'center' },
  sheetTitle: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', letterSpacing: -0.5, marginBottom: 4 },
  sheetSubtitle: { color: SKY, fontSize: 15, fontWeight: '600' },
  sheetContent: { marginBottom: 24 },
  sheetSectionTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 8, marginLeft: 4 },
  priceInputsContainer: { marginTop: 8, gap: 0 },
  sheetInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  sheetInputLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  sheetIconBox: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  sheetInputLabel: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  sheetInputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    width: 120,
    minHeight: 44,
  },
  sheetInputCurrency: { color: 'rgba(249,250,251,0.6)', fontSize: 16, fontWeight: '600', marginRight: 6 },
  sheetInput: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', flex: 1, padding: 0 },
  sheetDoneButton: { borderRadius: 20, overflow: 'hidden', marginTop: 8 },
  sheetDoneGradient: { paddingVertical: 16, alignItems: 'center', justifyContent: 'center' },
  sheetDoneText: { color: '#FFFFFF', fontSize: 17, fontWeight: '700', letterSpacing: -0.3 },

  // Eco Wash Card
  ecoWashCard: {
    padding: 20,
    borderRadius: 20,
  },
  ecoWashContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  ecoWashLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  ecoWashIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ecoWashText: {
    flex: 1,
    gap: 4,
  },

  rowBetweenCenter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },

  serviceRow: {
    padding: 12,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceRowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  serviceRowTitle: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 14, fontWeight: '900', flexShrink: 1 },

  pill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  pillText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '900' },

  inputsRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inputLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inputWrap: {
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    overflow: 'hidden',
  },
  input: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  // Tier pricing styles - Enhanced
  tierCardsContainer: {
    gap: 16,
    marginTop: 8,
  },
  tierCardEnhanced: {
    padding: 20,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 0,
  },
  tierCardHeaderEnhanced: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 20,
  },
  tierIconWrapperEnhanced: {
    width: 60,
    height: 60,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  tierHeaderTextEnhanced: {
    flex: 1,
  },
  tierNameEnhanced: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 10,
    letterSpacing: 0.3,
  },
  tierPillsRowEnhanced: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  tierPillEnhanced: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  tierPillTextEnhanced: {
    fontSize: 14,
    fontWeight: '700',
  },
  tierInputsRowEnhanced: {
    flexDirection: 'column',
    gap: 12,
  },
  tierInputGroup: {
    flex: 1,
  },
  tierInputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  tierInputLabelEnhanced: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '700',
  },
  tierSizePricingGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  tierSizeInputItem: {
    width: '48%',
  },
  tierSizeInputLabel: {
    color: 'rgba(249,250,251,0.68)',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
  },
  tierInputBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tierInputEnhanced: {
    color: '#F9FAFB',
    fontSize: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontWeight: '700',
  },

  // Detailing styles - Enhanced
  detailingToggleCard: {
    padding: 20,
    borderRadius: 20,
  },
  detailingToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  detailingToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  detailingToggleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(245,158,11,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailingToggleText: {
    flex: 1,
    gap: 4,
  },
  detailingItemsContainer: {
    gap: 12,
    marginTop: 16,
  },
  detailingItemCard: {
    padding: 18,
    borderRadius: 20,
  },
  detailingItemCardDisabled: {
    opacity: 0.6,
  },
  detailingItemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  detailingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  detailingItemIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailingItemIconDisabled: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderColor: 'rgba(255,255,255,0.1)',
  },
  detailingItemName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  detailingItemNameBlock: {
    flex: 1,
    gap: 2,
  },
  detailingItemStatusText: {
    color: 'rgba(135,206,235,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  detailingItemStatusTextDisabled: {
    color: 'rgba(249,250,251,0.45)',
  },
  detailingItemNameDisabled: {
    color: 'rgba(249,250,251,0.5)',
  },
  detailingItemInputContainer: {
    flexDirection: 'column',
    alignItems: 'stretch',
    gap: 10,
  },
  detailingItemInputGroup: {
    flex: 1,
  },
  detailingItemInputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  detailingItemInputLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  detailingItemInputBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  detailingItemInput: {
    color: '#F9FAFB',
    fontSize: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontWeight: '700',
  },
  detailingItemPriceBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  detailingItemPriceBadgeText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
  },
  
  // Enhanced Footer
  modalFooterEnhanced: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
    flexDirection: 'row',
    gap: 14,
    backgroundColor: 'rgba(10,25,41,0.5)',
  },
  modalSecondaryBtnEnhanced: {
    flex: 1,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  modalSecondaryTextEnhanced: { color: '#E5E7EB', fontWeight: '700', fontSize: 16 },
  modalPrimaryBtnEnhanced: {
    flex: 1.5,
    borderRadius: 18,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    flexDirection: 'row',
    gap: 10,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  modalPrimaryTextEnhanced: { color: '#FFFFFF', fontWeight: '700', fontSize: 16 },
}) as Record<string, ViewStyle & TextStyle & ImageStyle>;
