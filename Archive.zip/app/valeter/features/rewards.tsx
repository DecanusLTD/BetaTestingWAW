/**
 * Valeter Rewards – Same UI as customer rewards; redirects to valeter rewards system.
 * Re-export / wrapper so profile can link to /valeter/features/rewards like customer.
 */
import React, { useEffect } from 'react';
import { router } from 'expo-router';
import LoadingScreen from '../../../src/components/LoadingScreen';

export default function ValeterRewardsPage() {
  useEffect(() => {
    router.replace('/valeter/valeter-rewards-system' as any);
  }, []);
  return <LoadingScreen message="Redirecting…" />;
}
