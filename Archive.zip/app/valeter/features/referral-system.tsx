import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Share,
  Alert,
  RefreshControl,
  Platform,
  Clipboard,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import {
  getValeterReferralSummary,
  applyValeterReferralCode,
  generateValeterReferralCode,
  VALETER_REFERRAL_BONUS_POINTS,
  formatRelativeDate,
  type ValeterReferralRow,
} from '../../../src/services/ValeterLoyaltyService';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const WEB_JOIN_BASE = 'https://wishawash.com/join';

function buildShareMessage(code: string): string {
  const link = `${WEB_JOIN_BASE}?code=${encodeURIComponent(code)}`;
  return `Join me on Wish a Wash as a valeter! Use my referral code ${code} and earn £10 bonus when you complete your first job.\n\nSign up here: ${link}`;
}

export default function ValeterReferralSystem() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [referralCode, setReferralCode] = useState(user?.id ? generateValeterReferralCode(user.id) : 'WAW-V-00000000');
  const [hasAppliedReferral, setHasAppliedReferral] = useState(false);
  const [referrals, setReferrals] = useState<ValeterReferralRow[]>([]);
  const [entryCode, setEntryCode] = useState('');
  const [applyingCode, setApplyingCode] = useState(false);
  const [showEnterCode, setShowEnterCode] = useState(false);

  const rewardedCount = useMemo(() => referrals.filter((r) => r.status === 'rewarded').length, [referrals]);
  const totalEarned = rewardedCount * VALETER_REFERRAL_BONUS_POINTS;

  const load = useCallback(async () => {
    if (!user?.id) { setLoading(false); setRefreshing(false); return; }
    try {
      if (!refreshing) setLoading(true);
      const summary = await getValeterReferralSummary(user.id);
      setReferralCode(summary.referralCode);
      setHasAppliedReferral(summary.referredBy);
      setReferrals(summary.referrals);
    } catch (e) {
      console.warn('[ValeterReferral] load failed:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, refreshing]);

  useEffect(() => { void load(); }, [load]);

  const onRefresh = () => { setRefreshing(true); void load(); };

  const handleShare = async () => {
    try {
      const message = buildShareMessage(referralCode);
      const link = `${WEB_JOIN_BASE}?code=${encodeURIComponent(referralCode)}`;
      await Share.share(
        Platform.OS === 'ios' ? { message, url: link } : { message, title: 'Join Wish a Wash' },
      );
    } catch {
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    const link = `${WEB_JOIN_BASE}?code=${encodeURIComponent(referralCode)}`;
    Clipboard.setString(`${referralCode}\n${link}`);
    Alert.alert('Copied', 'Your referral code and invite link are on the clipboard.');
  };

  const handleApplyCode = async () => {
    if (!user?.id) return;
    const normalized = entryCode.trim().toUpperCase();
    if (!normalized) { Alert.alert('Enter a code', "Paste or type a referral code."); return; }
    if (normalized === referralCode) { Alert.alert("That's your code", "Enter someone else's referral code."); return; }
    if (hasAppliedReferral) { Alert.alert('Already applied', "You've already used a referral code."); return; }

    try {
      setApplyingCode(true);
      const applied = await applyValeterReferralCode(user.id, normalized);
      if (applied) {
        setHasAppliedReferral(true);
        setEntryCode('');
        setShowEnterCode(false);
        Alert.alert('Code applied', 'Complete your first job to unlock the referral bonus.');
        void load();
      } else {
        Alert.alert('Invalid code', "We couldn't find that referral code. Check it and try again.");
      }
    } catch {
      Alert.alert('Error', 'Unable to apply referral code right now.');
    } finally {
      setApplyingCode(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader title="Referrals" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 20 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.heroIcon}>
            <Ionicons name="people" size={40} color="#F9FAFB" />
          </View>
          <Text style={styles.heroTitle}>Invite valeters, earn {VALETER_REFERRAL_BONUS_POINTS} pts</Text>
          <Text style={styles.heroSub}>
            Earn {VALETER_REFERRAL_BONUS_POINTS} points for every valeter that signs up with your code and completes their first job.
          </Text>
        </View>

        {/* Code card */}
        <View style={styles.codeCard}>
          <Text style={styles.codeLabel}>YOUR REFERRAL CODE</Text>
          <TouchableOpacity style={styles.codeBox} onPress={handleCopy} activeOpacity={0.7}>
            <Text style={styles.codeText}>{referralCode}</Text>
            <Ionicons name="copy-outline" size={20} color={SKY} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.shareBtn} onPress={() => void handleShare()}>
            <Text style={styles.shareBtnText}>Share Invite Link</Text>
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{loading ? '—' : rewardedCount}</Text>
            <Text style={styles.statLabel}>Rewarded</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{loading ? '—' : referrals.length}</Text>
            <Text style={styles.statLabel}>Total Invites</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{loading ? '—' : `${totalEarned} pts`}</Text>
            <Text style={styles.statLabel}>Points Earned</Text>
          </View>
        </View>

        {/* Enter a code */}
        {!hasAppliedReferral && (
          <TouchableOpacity style={styles.enterCodeToggle} onPress={() => setShowEnterCode((v) => !v)} activeOpacity={0.8}>
            <Ionicons name="ticket-outline" size={18} color={SKY} />
            <Text style={styles.enterCodeToggleText}>Have a referral code? Enter it here</Text>
            <Ionicons name={showEnterCode ? 'chevron-up' : 'chevron-down'} size={16} color={SKY} />
          </TouchableOpacity>
        )}

        {showEnterCode && !hasAppliedReferral && (
          <View style={styles.enterCodeCard}>
            <Text style={styles.enterCodeLabel}>Enter referral code</Text>
            <View style={styles.enterCodeRow}>
              <TouchableOpacity
                style={styles.enterCodeInput}
                onPress={() => {
                  Alert.prompt?.(
                    'Enter referral code',
                    "Paste your friend's code",
                    (text) => { if (text) setEntryCode(text.trim().toUpperCase()); },
                    'plain-text',
                    entryCode,
                  );
                }}
                activeOpacity={0.8}
              >
                <Text style={[styles.enterCodeInputText, !entryCode && styles.enterCodePlaceholder]}>
                  {entryCode || 'WAW-V-XXXXXXXX'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.applyBtn, applyingCode && styles.applyBtnDisabled]}
                onPress={() => void handleApplyCode()}
                disabled={applyingCode}
              >
                <Text style={styles.applyBtnText}>{applyingCode ? '…' : 'Apply'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {hasAppliedReferral && (
          <View style={styles.appliedBadge}>
            <Ionicons name="checkmark-circle" size={18} color="#10B981" />
            <Text style={styles.appliedBadgeText}>Referral code applied to your account</Text>
          </View>
        )}

        {/* Roster */}
        <Text style={[styles.sectionTitle, { marginTop: 24 }]}>Your Invites</Text>
        {loading ? (
          <Text style={styles.emptyText}>Loading…</Text>
        ) : referrals.length === 0 ? (
          <View style={styles.emptyState}>
            <GradientIconBox icon="mail-open-outline" preset="gray" boxSize={64} size={32} />
            <Text style={styles.emptyText}>No invites yet</Text>
            <Text style={styles.emptySub}>Share your code to start earning!</Text>
          </View>
        ) : (
          referrals.map((r) => {
            const isRewarded = r.status === 'rewarded';
            return (
              <View key={r.id} style={styles.rosterItem}>
                <View style={styles.rosterAvatar}>
                  <Text style={styles.rosterAvatarText}>{r.refereeName.charAt(0).toUpperCase()}</Text>
                </View>
                <View style={styles.rosterInfo}>
                  <Text style={styles.rosterName}>{r.refereeName}</Text>
                  <View style={styles.rosterStatusRow}>
                    <View style={[styles.statusDot, isRewarded ? styles.dotRewarded : styles.dotPending]} />
                    <Text style={styles.rosterMeta}>
                      {r.status.charAt(0).toUpperCase() + r.status.slice(1)} · {formatRelativeDate(r.createdAt)}
                    </Text>
                  </View>
                </View>
                <Text style={[styles.rosterReward, isRewarded ? styles.rewardRewarded : styles.rewardPending]}>
                  {isRewarded ? `+${r.rewardAmount} pts` : 'Pending'}
                </Text>
              </View>
            );
          })
        )}

        <View style={styles.disclaimer}>
          <Ionicons name="information-circle-outline" size={16} color="#6B7280" />
          <Text style={styles.disclaimerText}>
            You earn {VALETER_REFERRAL_BONUS_POINTS} points when a referred valeter completes their first job.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },

  hero: { alignItems: 'center', marginBottom: 28, marginTop: 8 },
  heroIcon: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(135,206,235,0.15)', justifyContent: 'center', alignItems: 'center', marginBottom: 16, borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)' },
  heroTitle: { color: '#F9FAFB', fontSize: 26, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  heroSub: { color: '#D1D5DB', fontSize: 14, textAlign: 'center', lineHeight: 22, paddingHorizontal: 16 },

  codeCard: { backgroundColor: 'rgba(10,25,41,0.6)', borderRadius: 24, padding: 24, marginBottom: 20, borderWidth: 1, borderColor: 'rgba(135,206,235,0.2)' },
  codeLabel: { color: '#9CA3AF', fontSize: 11, fontWeight: '700', letterSpacing: 1.5, marginBottom: 12 },
  codeBox: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 16, paddingHorizontal: 20, paddingVertical: 16, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  codeText: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', letterSpacing: 2 },
  shareBtn: { backgroundColor: SKY, borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  shareBtnText: { color: '#0A1929', fontSize: 16, fontWeight: '700' },

  statsRow: { flexDirection: 'row', backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 20, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  statBox: { flex: 1, alignItems: 'center' },
  statValue: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  statLabel: { color: '#9CA3AF', fontSize: 12, fontWeight: '500', textAlign: 'center' },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginHorizontal: 12 },

  enterCodeToggle: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 14, paddingHorizontal: 16, backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 16, marginBottom: 10, borderWidth: 1, borderColor: 'rgba(135,206,235,0.15)' },
  enterCodeToggleText: { flex: 1, color: SKY, fontSize: 14, fontWeight: '600' },

  enterCodeCard: { backgroundColor: 'rgba(10,25,41,0.5)', borderRadius: 20, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(135,206,235,0.2)' },
  enterCodeLabel: { color: '#9CA3AF', fontSize: 12, fontWeight: '600', marginBottom: 12 },
  enterCodeRow: { flexDirection: 'row', gap: 10 },
  enterCodeInput: { flex: 1, backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  enterCodeInputText: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', letterSpacing: 1 },
  enterCodePlaceholder: { color: '#4B5563' },
  applyBtn: { backgroundColor: SKY, borderRadius: 14, paddingHorizontal: 20, justifyContent: 'center', alignItems: 'center' },
  applyBtnDisabled: { opacity: 0.5 },
  applyBtnText: { color: '#0A1929', fontWeight: '700', fontSize: 15 },

  appliedBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(16,185,129,0.1)', borderRadius: 14, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(16,185,129,0.25)' },
  appliedBadgeText: { color: '#10B981', fontSize: 14, fontWeight: '600' },

  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', marginBottom: 14 },

  emptyState: { alignItems: 'center', paddingVertical: 32, backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)', marginBottom: 16 },
  emptyText: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginTop: 12, marginBottom: 4 },
  emptySub: { color: '#9CA3AF', fontSize: 13 },

  rosterItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(10,25,41,0.4)', padding: 16, borderRadius: 20, marginBottom: 10, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  rosterAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(135,206,235,0.15)', justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  rosterAvatarText: { color: SKY, fontSize: 17, fontWeight: '700' },
  rosterInfo: { flex: 1 },
  rosterName: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginBottom: 4 },
  rosterStatusRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  dotRewarded: { backgroundColor: '#10B981' },
  dotPending: { backgroundColor: '#F59E0B' },
  rosterMeta: { color: '#9CA3AF', fontSize: 12 },
  rosterReward: { fontSize: 14, fontWeight: '700', marginLeft: 10 },
  rewardRewarded: { color: '#10B981' },
  rewardPending: { color: '#F59E0B' },

  disclaimer: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginTop: 16, marginBottom: 8 },
  disclaimerText: { color: '#6B7280', fontSize: 12, flex: 1, lineHeight: 18 },
});
