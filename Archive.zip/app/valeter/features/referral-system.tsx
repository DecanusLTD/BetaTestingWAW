import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterReferralSystem() {
  const { user } = useAuth();
  
  // Generate short referral code from user ID (first 6 characters, uppercase)
  const generateShortCode = (userId: string | undefined): string => {
    if (!userId) return 'WAW000';
    // Take first 6 chars of user ID, convert to uppercase, remove hyphens
    const shortId = userId.replace(/-/g, '').substring(0, 6).toUpperCase();
    return shortId || 'WAW000';
  };
  
  const [referralCode] = useState(generateShortCode(user?.id));
  const [referrals] = useState<Array<{ id: string; name: string; date: string; reward: string }>>([]);

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Join me on Wish a Wash as a valeter! Use my referral code: ${referralCode} and get £10 bonus when you complete your first job!`,
      });
    } catch (error) {
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Referrals" accountType="valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Referral Code Card */}
        <View style={styles.codeCard}>
          <BlurView intensity={35} tint="dark" style={styles.codeBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.codeBorder} />
            <View style={styles.codeGradient}>
              <View style={styles.codeIconWrapper}>
                <Ionicons name="gift" size={32} color={SKY} />
              </View>
              <Text style={styles.codeLabel}>Your Referral Code</Text>
              <View style={styles.codeContainer}>
                <Text style={styles.codeText}>{referralCode}</Text>
              </View>
              <View style={styles.codeActions}>
                <TouchableOpacity style={styles.codeButton} onPress={handleCopy}>
                  <Ionicons name="copy" size={18} color={SKY} />
                  <Text style={styles.codeButtonText}>Copy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.codeButton} onPress={handleShare}>
                  <Ionicons name="share" size={18} color={SKY} />
                  <Text style={styles.codeButtonText}>Share</Text>
                </TouchableOpacity>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Rewards Info */}
        <View style={styles.infoCard}>
          <BlurView intensity={30} tint="dark" style={styles.infoBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.infoBorder} />
            <View style={styles.infoContentWrapper}>
              <View style={styles.infoIconWrapper}>
                <Ionicons name="information-circle" size={24} color={SKY} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoTitle}>How it Works</Text>
                <Text style={styles.infoText}>
                  Share your code with other valeters. When they sign up and complete their first job, you both get £10 bonus!
                </Text>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Referrals List */}
        <View style={styles.referralsSection}>
          <Text style={styles.sectionTitle}>Your Referrals ({referrals.length})</Text>
          {referrals.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="people-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyText}>No referrals yet</Text>
              <Text style={styles.emptySubtext}>Start sharing your code!</Text>
            </View>
          ) : (
            referrals.map((referral) => (
              <View key={referral.id} style={styles.referralCard}>
                <BlurView intensity={30} tint="dark" style={styles.referralBlur}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.referralBorder} />
                  <View style={styles.referralContentWrapper}>
                    <View style={styles.referralIconWrapper}>
                      <Ionicons name="person" size={20} color={SKY} />
                    </View>
                    <View style={styles.referralContent}>
                      <Text style={styles.referralName}>{referral.name}</Text>
                      <Text style={styles.referralDate}>{referral.date}</Text>
                    </View>
                    <View style={styles.rewardBadge}>
                      <Text style={styles.rewardText}>{referral.reward}</Text>
                    </View>
                  </View>
                </BlurView>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  codeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  codeBlur: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  codeBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeGradient: {
    padding: 24,
    alignItems: 'center',
  },
  codeIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  codeContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    letterSpacing: 2,
  },
  codeActions: {
    flexDirection: 'row',
    gap: 12,
  },
  codeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  codeButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  infoBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  infoBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoContentWrapper: {
    flexDirection: 'row',
    padding: 16,
  },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: SKY,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  referralsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 12,
    marginBottom: 4,
  },
  emptySubtext: {
    color: SKY,
    fontSize: 13,
  },
  referralCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  referralBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  referralBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  referralContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  referralIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  referralContent: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  referralDate: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  rewardBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  rewardText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
});


