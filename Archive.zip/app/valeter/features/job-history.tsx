/**
 * Valeter Job History – Past jobs & receipts. Premium redesign.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  RefreshControl,
  Alert,
  ActivityIndicator,
  ScrollView,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import InfoBottomSheet, { infoBottomSheetHeaderStyles as hn } from '../../../src/components/shared/InfoBottomSheet';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import EmptyState from '../../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER } from '../../../src/constants/bookingCardTheme';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';
import { LocationStyleIconBox } from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';

const SKY = colors.SKY ?? '#38BDF8';

function getRelativeDate(dateLike: string | null): string {
  if (!dateLike) return '—';
  const d = new Date(dateLike);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - d.getTime()) / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function getSectionKey(completedAt: string | null, createdAt: string): string {
  const d = new Date(completedAt || createdAt);
  const now = new Date();
  const thisMonth = now.getFullYear() * 12 + now.getMonth();
  const thatMonth = d.getFullYear() * 12 + d.getMonth();
  const diff = thisMonth - thatMonth;
  if (diff === 0) return 'this_month';
  if (diff === 1) return 'last_month';
  return 'older';
}

function getSectionLabel(key: string): string {
  switch (key) {
    case 'this_month': return 'This month';
    case 'last_month': return 'Last month';
    case 'older': return 'Older';
    default: return key;
  }
}

type JobRow = {
  id: string;
  service_name: string | null;
  service_type: string | null;
  price: number;
  completed_at: string | null;
  created_at: string;
  location_address: string | null;
  rating: number | null;
  review: string | null;
};

export default function ValeterJobHistoryScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme?.primary ?? SKY;
  const gradientBg = (theme?.background ?? ['#0A1929', '#1e3a5f']) as [string, string];
  const cardGradient = (theme?.headerBackground ?? HEADER_STYLE_CARD_GRADIENT) as [string, string];
  const cardBorder = theme?.glassBorder ?? HEADER_STYLE_CARD_BORDER;

  const [orders, setOrders] = useState<JobRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<JobRow | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_name, service_type, price, completed_at, created_at, location_address, rating, review')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false })
        .limit(1000);

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({
        id: r.id,
        service_name: r.service_name,
        service_type: r.service_type,
        price: Number(r.price) || 0,
        completed_at: r.completed_at,
        created_at: r.created_at,
        location_address: r.location_address ?? null,
        rating: r.rating != null ? Number(r.rating) : null,
        review: typeof r.review === 'string' && r.review.trim() ? r.review.trim() : null,
      }));
      setOrders(rows);
    } catch (e) {
      console.error('[ValeterJobHistory] load error', e);
      Alert.alert('Error', 'Failed to load job history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase
      .channel('job-history-completed')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const row = (payload.new ?? payload.old) as any;
          if (row?.status === 'completed' && payload.eventType === 'INSERT') {
            setOrders((prev) => {
              const exists = prev.some((o) => o.id === row.id);
              if (exists) return prev;
              const newOrder: JobRow = {
                id: row.id,
                service_name: row.service_name ?? null,
                service_type: row.service_type ?? null,
                price: Number(row.price) || 0,
                completed_at: row.completed_at ?? null,
                created_at: row.created_at ?? '',
                location_address: row.location_address ?? null,
                rating: row.rating != null ? Number(row.rating) : null,
                review: typeof row.review === 'string' ? row.review : null,
              };
              return [newOrder, ...prev].sort(
                (a, b) => new Date(b.completed_at || b.created_at).getTime() - new Date(a.completed_at || a.created_at).getTime()
              );
            });
          }
          if (row?.status !== 'completed' && payload.eventType === 'UPDATE') {
            setOrders((prev) => prev.filter((o) => o.id !== row.id));
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadOrders();
  }, [loadOrders]);

  const grouped = useMemo(() => {
    const map = new Map<string, JobRow[]>();
    orders.forEach((o) => {
      const key = getSectionKey(o.completed_at, o.created_at);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    });
    return ['this_month', 'last_month', 'older']
      .map((key) => ({ key, items: map.get(key) || [] }))
      .filter((g) => g.items.length > 0);
  }, [orders]);

  const totalEarnings = useMemo(() => orders.reduce((sum, o) => sum + o.price, 0), [orders]);
  const { thisMonthEarnings, lastMonthEarnings } = useMemo(() => {
    const now = new Date();
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    let thisMonth = 0;
    let lastMonth = 0;
    orders.forEach((o) => {
      const d = new Date(o.completed_at || o.created_at);
      if (d >= thisMonthStart) thisMonth += o.price;
      else if (d >= lastMonthStart && d < thisMonthStart) lastMonth += o.price;
    });
    return { thisMonthEarnings: thisMonth, lastMonthEarnings: lastMonth };
  }, [orders]);
  const formatCurrency = (n: number) => `£${n.toFixed(2).replace(/\.00$/, '')}`;

  const handleDeleteOrder = useCallback((id: string) => {
    if (!user?.id) return;
    hapticFeedback('light');
    Alert.alert(
      'Remove job',
      'Permanently remove this job from your history?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase.from('bookings').delete().eq('id', id).eq('valeter_id', user.id);
              if (error) throw error;
              setOrders((prev) => prev.filter((o) => o.id !== id));
            } catch (e: any) {
              console.error('[JobHistory] delete error', e);
              Alert.alert('Error', e?.message ?? 'Could not remove job. It may be protected.');
            }
          },
        },
      ]
    );
  }, [user?.id]);

  const handleDeleteAll = useCallback(() => {
    if (!user?.id || orders.length === 0) return;
    hapticFeedback('light');
    const ids = orders.map((o) => o.id);
    Alert.alert(
      'Delete all history',
      'Permanently remove all these jobs from history? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete all',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .delete()
                .eq('valeter_id', user!.id)
                .in('id', ids);
              if (error) throw error;
              setOrders([]);
              Alert.alert('Done', 'All jobs have been removed from history.');
            } catch (e: any) {
              console.error('[JobHistory] delete all error', e);
              Alert.alert('Error', e?.message ?? 'Some jobs could not be removed. Try removing them one by one.');
            }
          },
        },
      ]
    );
  }, [orders, user?.id]);

  return (
    <View style={styles.container}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader
        title="Job history"
        subtitle="Completed jobs & earnings"
       
        rightAction={
          orders.length > 0 ? (
            <TouchableOpacity onPress={handleDeleteAll} style={styles.headerDeleteBtn} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
              <LocationStyleIconBox variant="card" icon="trash-outline" colors={accentToGradient(accent)} />
            </TouchableOpacity>
          ) : null
        }
      />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24,
          },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={accent} />}
      >
        {loading ? (
          <View style={styles.centered}>
            <DefaultLoadingSkeleton message="Loading history…" variant="rich" />
          </View>
        ) : orders.length === 0 ? (
          <EmptyState
            icon="wallet-outline"
            title="No completed jobs yet"
            subtitle="Your completed jobs and earnings will appear here."
            actionLabel="View jobs"
            onAction={() => router.push('/valeter/jobs')}
            iconColor={accent}
          />
        ) : (
          <>
            {/* Summary strip */}
            <View style={[styles.summaryStrip, { borderColor: `${accent}40`, shadowColor: accent }]}>
              <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={cardGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <View style={styles.summaryOverlay} />
              <View style={styles.summaryRow}>
                <View style={styles.summaryItem}>
                  <LocationStyleIconBox icon="briefcase-outline" colors={accentToGradient(accent)} />
                  <Text style={[styles.summaryValue, { color: '#F9FAFB' }]}>{orders.length}</Text>
                  <Text style={[styles.summaryLabel, { color: accent }]}>jobs</Text>
                </View>
                <View style={[styles.summaryDivider, { backgroundColor: `${accent}30` }]} />
                <View style={styles.summaryItem}>
                  <LocationStyleIconBox icon="wallet-outline" preset="green" />
                  <Text style={[styles.summaryValue, { color: accent }]}>{formatCurrency(totalEarnings)}</Text>
                  <Text style={[styles.summaryLabel, { color: '#94A3B8' }]}>total</Text>
                </View>
              </View>
              <View style={[styles.summaryRow, styles.summaryRowSecondary]}>
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryLabel, { color: '#94A3B8' }]}>This month</Text>
                  <Text style={[styles.summaryValueSmall, { color: '#F9FAFB' }]}>{formatCurrency(thisMonthEarnings)}</Text>
                </View>
                <View style={[styles.summaryDivider, { backgroundColor: `${accent}30` }]} />
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryLabel, { color: '#94A3B8' }]}>Last month</Text>
                  <Text style={[styles.summaryValueSmall, { color: '#F9FAFB' }]}>{formatCurrency(lastMonthEarnings)}</Text>
                </View>
              </View>
            </View>

            {grouped.map(({ key, items }) => (
              <View key={key} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={[styles.sectionDot, { backgroundColor: accent }]} />
                  <Text style={[styles.sectionTitle, { color: accent }]}>{getSectionLabel(key)}</Text>
                </View>
                {items.map((order) => (
                  <View key={order.id} style={[styles.card, { borderColor: `${accent}35`, shadowColor: accent }]}>
                    <BlurView intensity={16} tint="dark" style={StyleSheet.absoluteFill} />
                    <LinearGradient colors={cardGradient} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
                    <View style={styles.cardOverlay} />
                    <View style={styles.cardInner}>
                      <TouchableOpacity
                        style={styles.cardMainTouchable}
                        activeOpacity={0.85}
                        onPress={() => {
                          hapticFeedback('light');
                          setSelectedOrder(order);
                        }}
                      >
                        <View style={styles.serviceIconChrome}>
                          <LocationStyleIconBox icon="car-sport-outline" colors={accentToGradient(accent)} />
                        </View>
                        <View style={styles.cardBody}>
                          <Text style={styles.serviceName}>
                            {getServiceDisplayName(order.service_type, order.service_name)}
                          </Text>
                          <Text style={styles.date}>{getRelativeDate(order.completed_at || order.created_at)}</Text>
                          {order.location_address ? (
                            <Text style={styles.address} numberOfLines={1}>{order.location_address}</Text>
                          ) : null}
                          {order.rating != null && order.rating > 0 && (
                            <View style={styles.ratingRow}>
                              <Ionicons name="star" size={14} color="#FBBF24" />
                              <Text style={[styles.ratingText, { color: accent }]}>Customer rated you {order.rating}★</Text>
                            </View>
                          )}
                          {order.review ? (
                            <TouchableOpacity
                              activeOpacity={0.85}
                              onPress={() => {
                                hapticFeedback('light');
                                Alert.alert('Customer review', order.review ?? '');
                              }}
                              hitSlop={{ top: 4, bottom: 4 }}
                            >
                              <Text style={styles.reviewSnippet} numberOfLines={2}>
                                "{order.review}"
                              </Text>
                              <Text style={styles.reviewTapHint}>Tap to read full review</Text>
                            </TouchableOpacity>
                          ) : null}
                        </View>
                        <View style={[styles.priceWrap, { backgroundColor: `${accent}18` }]}>
                          <Text style={[styles.price, { color: accent }]}>{formatCurrency(order.price)}</Text>
                        </View>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleDeleteOrder(order.id)}
                        style={[styles.cardDeleteBtn, { borderColor: `${accent}30` }]}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <LocationStyleIconBox variant="inline" icon="trash-outline" preset="red" />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>
            ))}
          </>
        )}
      </ScrollView>

      {/* Job detail bottom sheet */}
      {selectedOrder ? (
        <InfoBottomSheet
          visible={!!selectedOrder}
          onClose={() => setSelectedOrder(null)}
          title={getServiceDisplayName(selectedOrder.service_type, selectedOrder.service_name)}
          variant="header"
          accentColor={accent}
          footer={
            <TouchableOpacity
              style={hn.saveBtn}
              onPress={() => {
                hapticFeedback('light');
                setSelectedOrder(null);
              }}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={[getAccountTheme('valeter').primary, getAccountTheme('valeter').primaryAlt]}
                style={StyleSheet.absoluteFill}
              />
              <Text style={hn.saveBtnText}>Close</Text>
            </TouchableOpacity>
          }
        >
          <View style={hn.list}>
            <View style={hn.listItem}>
              <View style={[hn.listItemIcon, styles.sheetRowIconSlot]}>
                <LocationStyleIconBox variant="inline" icon="calendar-outline" colors={accentToGradient(accent)} />
              </View>
              <Text style={hn.listItemLabel}>Completed</Text>
              <Text style={hn.listItemValue}>
                {selectedOrder.completed_at
                  ? new Date(selectedOrder.completed_at).toLocaleString('en-GB', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : getRelativeDate(selectedOrder.completed_at || selectedOrder.created_at)}
              </Text>
            </View>
            {selectedOrder.location_address ? (
              <View style={hn.listItem}>
                <View style={[hn.listItemIcon, styles.sheetRowIconSlot]}>
                  <LocationStyleIconBox variant="inline" icon="location-outline" colors={accentToGradient(accent)} />
                </View>
                <Text style={hn.listItemLabel}>Address</Text>
                <Text style={hn.listItemValue}>{selectedOrder.location_address}</Text>
              </View>
            ) : null}
            <View style={[hn.listItem, !(selectedOrder.rating != null && selectedOrder.rating > 0) && hn.listItemLast]}>
              <View style={[hn.listItemIcon, styles.sheetRowIconSlot]}>
                <LocationStyleIconBox variant="inline" icon="wallet-outline" preset="green" />
              </View>
              <Text style={hn.listItemLabel}>Earnings</Text>
              <Text style={[hn.listItemValue, hn.listItemValueAccent, { color: accent }]}>
                {formatCurrency(selectedOrder.price)}
              </Text>
            </View>
            {selectedOrder.rating != null && selectedOrder.rating > 0 && (
              <View style={[hn.listItem, hn.listItemLast]}>
                <View style={[hn.listItemIcon, styles.sheetRowIconSlot]}>
                  <LocationStyleIconBox variant="inline" icon="star" preset="amber" />
                </View>
                <Text style={hn.listItemLabel}>Customer rating</Text>
                <Text style={hn.listItemValue}>{selectedOrder.rating}★</Text>
              </View>
            )}
          </View>
          {selectedOrder.review ? (
            <Pressable
              style={({ pressed }) => [hn.reviewBlock, pressed && { opacity: 0.92 }]}
              onPress={() => {
                hapticFeedback('light');
                Alert.alert('Customer review', selectedOrder.review ?? '');
              }}
            >
              <Text style={hn.reviewLabel}>Customer review · tap to expand</Text>
              <Text style={hn.reviewText}>"{selectedOrder.review}"</Text>
            </Pressable>
          ) : null}
        </InfoBottomSheet>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingTop: 16 },
  centered: {
    paddingVertical: 48,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    fontWeight: '600',
  },
  summaryStrip: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 3,
  },
  summaryOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 24,
  },
  summaryRowSecondary: {
    paddingTop: 0,
    paddingBottom: 18,
  },
  summaryValueSmall: {
    fontSize: 15,
    fontWeight: '700',
  },
  summaryItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  summaryDivider: {
    width: 1,
    height: 28,
    borderRadius: 1,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '800',
  },
  summaryLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  section: { marginBottom: 24 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  card: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1.5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 2,
  },
  cardOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  cardInner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  cardMainTouchable: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 0,
  },
  cardDeleteBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  headerDeleteBtn: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceIconChrome: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  sheetRowIconSlot: {
    backgroundColor: 'transparent',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardBody: { flex: 1, minWidth: 0 },
  serviceName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#F9FAFB',
    marginBottom: 2,
  },
  date: {
    fontSize: 13,
    color: '#94A3B8',
    fontWeight: '500',
  },
  address: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
  },
  ratingText: {
    fontSize: 12,
    fontWeight: '600',
  },
  reviewSnippet: {
    fontSize: 12,
    color: 'rgba(249,250,251,0.8)',
    fontStyle: 'italic',
    marginTop: 4,
  },
  reviewTapHint: {
    fontSize: 10,
    fontWeight: '700',
    color: 'rgba(125,211,252,0.75)',
    marginTop: 4,
    letterSpacing: 0.2,
  },
  priceWrap: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    marginLeft: 12,
  },
  price: {
    fontSize: 16,
    fontWeight: '800',
  },
  sheetContainer: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  sheetBackdrop: {
    ...StyleSheet.absoluteFillObject,
  },
  detailSheet: {
    backgroundColor: '#0F2847',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    maxHeight: '85%',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  sheetHandle: {
    width: 40,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 20,
  },
  sheetHeader: { marginBottom: 20 },
  sheetTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  sheetSubtitle: { fontSize: 14, fontWeight: '600' },
  sheetScroll: { maxHeight: 320, marginBottom: 16 },
  sheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  sheetLabel: { color: '#94A3B8', fontSize: 14, fontWeight: '600', minWidth: 100 },
  sheetValue: { flex: 1, color: '#F9FAFB', fontSize: 15, fontWeight: '600' },
  sheetPrice: { fontSize: 18, fontWeight: '800' },
  sheetReviewBlock: {
    marginTop: 8,
    padding: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  sheetReviewLabel: { color: '#94A3B8', fontSize: 12, fontWeight: '700', marginBottom: 6 },
  sheetReviewText: { color: 'rgba(249,250,251,0.9)', fontSize: 14, fontStyle: 'italic', lineHeight: 20 },
  sheetCloseBtn: {
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sheetCloseBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
