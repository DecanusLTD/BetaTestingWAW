import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Platform } from 'react-native';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import LoadingScreen from '../../src/components/LoadingScreen';

const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

export default function ValeterAnalytics() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: valeterTheme } = useAccountTheme();
  const gradientBg = (valeterTheme?.background || VALETER_BG_FALLBACK) as [string, string];
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalEarnings: 0,
    totalJobs: 0,
    averageRating: 0,
    completedJobs: 0,
    cancelledJobs: 0,
    onlineHours: 0,
    thisMonthEarnings: 0,
    thisWeekEarnings: 0,
  });

  useEffect(() => {
    loadAnalytics();
  }, [user?.id]);

  const loadAnalytics = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      
      // Load bookings from Supabase
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = bookings || [];
      const completed = bookingsList.filter((b: any) => ['completed', 'rated', 'closed'].includes(b.status));
      const cancelled = bookingsList.filter((b: any) => b.status === 'cancelled');
      
      // Calculate earnings
      const totalEarnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Calculate monthly/weekly earnings
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      
      const thisMonthEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfMonth;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      const thisWeekEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfWeek;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Load valeter stats
      let valeterStats = null;
      try {
        valeterStats = await ValeterStatsService.getValeterStats(user.id);
      } catch (e) {
        console.warn('[Analytics] Failed to load valeter stats:', e);
      }
      
      // Online hours: valeter_presence has no timestamp history, so we estimate from job activity (time span of completed jobs this week)
      let onlineHours = 0;
      const weekCompleted = completed.filter((b: any) => {
        const date = b.completed_at || b.updated_at || b.created_at;
        return date && new Date(date) >= firstDayOfWeek;
      });
      if (weekCompleted.length >= 2) {
        const times = weekCompleted.map((b: any) => new Date(b.completed_at || b.updated_at || b.created_at).getTime());
        const spanHours = (Math.max(...times) - Math.min(...times)) / (1000 * 60 * 60);
        onlineHours = Math.round(Math.min(spanHours, 24 * 7) * 10) / 10;
      }

      setStats({
        totalEarnings,
        totalJobs: bookingsList.length,
        averageRating: valeterStats?.averageRating || 0,
        completedJobs: completed.length,
        cancelledJobs: cancelled.length,
        onlineHours,
        thisMonthEarnings,
        thisWeekEarnings,
      });
    } catch (error: any) {
      console.error('[Analytics] Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading analytics…" />;
  }

  const successRate = stats.totalJobs > 0
    ? Math.round((stats.completedJobs / stats.totalJobs) * 100)
    : 0;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader 
        title="Analytics" 
        accountType="valeter" 
        rightAction={
          <TouchableOpacity onPress={loadAnalytics} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color="#3B82F6" />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            paddingHorizontal: 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <LinearGradient
                colors={valeterTheme.headerBackground || valeterTheme.background}
                style={styles.statCardGradient}
              >
                <Ionicons name="wallet" size={28} color={SKY} />
                <Text style={styles.statNumber}>£{stats.totalEarnings.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </LinearGradient>
            </View>
            
            <View style={styles.statCard}>
              <LinearGradient
                colors={valeterTheme.headerBackground || valeterTheme.background}
                style={styles.statCardGradient}
              >
                <Ionicons name="briefcase" size={28} color={SKY} />
                <Text style={styles.statNumber}>{stats.totalJobs}</Text>
                <Text style={styles.statLabel}>Total Jobs</Text>
              </LinearGradient>
            </View>
            
            {stats.averageRating > 0 && (
              <View style={styles.statCard}>
                <LinearGradient
                  colors={valeterTheme.headerBackground || valeterTheme.background}
                  style={styles.statCardGradient}
                >
                  <Ionicons name="star" size={28} color="#F59E0B" />
                  <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
                  <Text style={styles.statLabel}>Avg Rating</Text>
                </LinearGradient>
              </View>
            )}
            
            <View style={styles.statCard}>
              <LinearGradient
                colors={valeterTheme.headerBackground || valeterTheme.background}
                style={styles.statCardGradient}
              >
                <Ionicons name="checkmark-circle" size={28} color="#10B981" />
                <Text style={styles.statNumber}>{stats.completedJobs}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </LinearGradient>
            </View>
          </View>
        </View>

        {/* Earnings Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Earnings Breakdown</Text>
          
          <View style={styles.earningsCard}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="calendar" size={20} color={SKY} />
                <Text style={styles.earningsLabel}>This Month</Text>
              </View>
              <Text style={styles.earningsValue}>£{stats.thisMonthEarnings.toFixed(2)}</Text>
            </View>
          </View>
          
          <View style={styles.earningsCard}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="time" size={20} color={SKY} />
                <Text style={styles.earningsLabel}>This Week</Text>
              </View>
              <Text style={styles.earningsValue}>£{stats.thisWeekEarnings.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        {/* Job Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Job Performance</Text>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.jobLabel}>Completed Jobs</Text>
              </View>
              <Text style={styles.jobValue}>{stats.completedJobs}</Text>
            </View>
          </View>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
                <Text style={styles.jobLabel}>Cancelled Jobs</Text>
              </View>
              <Text style={styles.jobValue}>{stats.cancelledJobs}</Text>
            </View>
          </View>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="trending-up" size={20} color={SKY} />
                <Text style={styles.jobLabel}>Success Rate</Text>
              </View>
              <Text style={styles.jobValue}>{successRate}%</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/valeter-dashboard')}
          >
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.actionButtonGradient}>
              <Ionicons name="home" size={20} color="#FFFFFF" />
              <Text style={[styles.actionButtonText, { color: '#FFFFFF' }]}>Go to Dashboard</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/valeter-history')}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="time" size={20} color={SKY} />
              <Text style={styles.actionButtonText}>View History</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/profile/valeter-profile')}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="person" size={20} color={SKY} />
              <Text style={styles.actionButtonText}>View Profile</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  headerWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  header: {
    width: width - 40,
    borderRadius: 24,
    marginHorizontal: 20,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingTop: 12,
    paddingBottom: 16,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '700',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40) - 12) / 2,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  statCardGradient: {
    padding: 18,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  earningsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  earningsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  earningsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  earningsLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  jobCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  jobRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  jobLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
  },
  jobValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  actionButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  actionButtonText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
  },
});
