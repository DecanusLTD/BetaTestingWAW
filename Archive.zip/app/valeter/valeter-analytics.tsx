import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  Dimensions,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { supabase } from '../../src/lib/supabase';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
import { colors } from '../../src/constants/colors';

const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterAnalytics() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalEarnings: 0,
    totalJobs: 0,
    averageRating: 0,
    completedJobs: 0,
    cancelledJobs: 0,
    onlineHours: 0,
    thisMonthEarnings: 0,
    thisWeekEarnings: 0,
  });

  useEffect(() => {
    loadAnalytics();
  }, [user?.id]);

  const loadAnalytics = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      
      // Load bookings from Supabase
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = bookings || [];
      const completed = bookingsList.filter((b: any) => ['completed', 'rated', 'closed'].includes(b.status));
      const cancelled = bookingsList.filter((b: any) => b.status === 'cancelled');
      
      // Calculate earnings
      const totalEarnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Calculate monthly/weekly earnings
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      
      const thisMonthEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfMonth;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      const thisWeekEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfWeek;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Load valeter stats
      let valeterStats = null;
      try {
        valeterStats = await ValeterStatsService.getValeterStats(user.id);
      } catch (e) {
        console.warn('[Analytics] Failed to load valeter stats:', e);
      }
      
      setStats({
        totalEarnings,
        totalJobs: bookingsList.length,
        averageRating: valeterStats?.averageRating || 0,
        completedJobs: completed.length,
        cancelledJobs: cancelled.length,
        onlineHours: 0, // TODO: Calculate from presence data
        thisMonthEarnings,
        thisWeekEarnings,
      });
    } catch (error: any) {
      console.error('[Analytics] Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading analytics...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const successRate = stats.totalJobs > 0
    ? Math.round((stats.completedJobs / stats.totalJobs) * 100)
    : 0;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top }]}>
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Analytics</Text>
            <TouchableOpacity onPress={loadAnalytics} style={styles.refreshButton}>
              <Ionicons name="refresh" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + 90 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <LinearGradient
                colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
                style={styles.statCardGradient}
              >
                <Ionicons name="cash" size={28} color={SKY} />
                <Text style={styles.statNumber}>£{stats.totalEarnings.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </LinearGradient>
            </View>
            
            <View style={styles.statCard}>
              <LinearGradient
                colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
                style={styles.statCardGradient}
              >
                <Ionicons name="briefcase" size={28} color={SKY} />
                <Text style={styles.statNumber}>{stats.totalJobs}</Text>
                <Text style={styles.statLabel}>Total Jobs</Text>
              </LinearGradient>
            </View>
            
            {stats.averageRating > 0 && (
              <View style={styles.statCard}>
                <LinearGradient
                  colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
                  style={styles.statCardGradient}
                >
                  <Ionicons name="star" size={28} color="#F59E0B" />
                  <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
                  <Text style={styles.statLabel}>Avg Rating</Text>
                </LinearGradient>
              </View>
            )}
            
            <View style={styles.statCard}>
              <LinearGradient
                colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
                style={styles.statCardGradient}
              >
                <Ionicons name="checkmark-circle" size={28} color="#10B981" />
                <Text style={styles.statNumber}>{stats.completedJobs}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </LinearGradient>
            </View>
          </View>
        </View>

        {/* Earnings Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Earnings Breakdown</Text>
          
          <View style={styles.earningsCard}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="calendar" size={20} color={SKY} />
                <Text style={styles.earningsLabel}>This Month</Text>
              </View>
              <Text style={styles.earningsValue}>£{stats.thisMonthEarnings.toFixed(2)}</Text>
            </View>
          </View>
          
          <View style={styles.earningsCard}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="time" size={20} color={SKY} />
                <Text style={styles.earningsLabel}>This Week</Text>
              </View>
              <Text style={styles.earningsValue}>£{stats.thisWeekEarnings.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        {/* Job Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Job Performance</Text>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={styles.jobLabel}>Completed Jobs</Text>
              </View>
              <Text style={styles.jobValue}>{stats.completedJobs}</Text>
            </View>
          </View>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
                <Text style={styles.jobLabel}>Cancelled Jobs</Text>
              </View>
              <Text style={styles.jobValue}>{stats.cancelledJobs}</Text>
            </View>
          </View>
          
          <View style={styles.jobCard}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="trending-up" size={20} color={SKY} />
                <Text style={styles.jobLabel}>Success Rate</Text>
              </View>
              <Text style={styles.jobValue}>{successRate}%</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/valeter-dashboard')}
          >
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.actionButtonGradient}>
              <Ionicons name="home" size={20} color="#0A1929" />
              <Text style={[styles.actionButtonText, { color: '#0A1929' }]}>Go to Dashboard</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/profile/valeter-profile')}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="person" size={20} color={SKY} />
              <Text style={styles.actionButtonText}>View Profile</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 16,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
    letterSpacing: 0.3,
  },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40) - 12) / 2,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  statCardGradient: {
    padding: 18,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  earningsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  earningsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  earningsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  earningsLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  jobCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  jobRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  jobLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
  },
  jobValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  actionButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  actionButtonText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
  },
});
