import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { colors } from '../../../src/constants/colors';
import { SCREEN_PADDING_H } from '../../../src/constants/premiumTokens';
import DefaultLoadingSkeleton from '../../../src/components/shared/DefaultLoadingSkeleton';

const { height } = Dimensions.get('window');
const SKY = colors.SKY ?? '#38BDF8';

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'scheduled'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['pending_payment', 'confirmed', 'scheduled', 'en_route', 'arrived', 'in_progress'];

const DEFAULT_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function TripsPage() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ jobId?: string }>();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' && params.jobId !== 'undefined' ? params.jobId : null;

  const [activeJob, setActiveJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [status, setStatus] = useState<JobStatus>('pending_payment');
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [loading, setLoading] = useState(true);
  const [valeterLocation, setValeterLocation] = useState<{ lat: number; lng: number } | null>(null);

  const mapRef = useRef<MapView>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadValeterLocation = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data?.last_lat != null && data?.last_lng != null) {
        setValeterLocation({ lat: data.last_lat, lng: data.last_lng });
        setRegion({
          latitude: data.last_lat,
          longitude: data.last_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
    } catch (e) {
      console.warn('[Trips] valeter location error:', e);
    }
  };

  const loadJobById = async (id: string) => {
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
      if (error) throw error;
      if (!data) {
        setActiveJob(null);
        return;
      }
      applyJobData(data);
    } catch (e) {
      console.error('[Trips] loadJob error:', e);
      setActiveJob(null);
    } finally {
      setLoading(false);
    }
  };

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ACTIVE_STATUSES)
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      if (data) {
        applyJobData(data);
      } else {
        setActiveJob(null);
      }
    } catch (e) {
      console.error('[Trips] loadActiveJob error:', e);
      setActiveJob(null);
    } finally {
      setLoading(false);
    }
  };

  const applyJobData = async (data: any) => {
    setActiveJob(data);
    setStatus(data.status || 'pending_payment');
    if (data.user_id) {
      const profile = await fetchProfileById(data.user_id);
      setCustomerName(profile?.full_name || 'Customer');
      try {
        const { data: vehicle } = await supabase
          .from('customer_vehicles')
          .select('registration, make, model, type')
          .eq('user_id', data.user_id)
          .eq('is_default', true)
          .maybeSingle();
        if (vehicle) {
          setActiveJob((prev: any) => ({
            ...prev,
            vehicle_registration: vehicle.registration,
            vehicle_make: vehicle.make,
            vehicle_model: vehicle.model,
            vehicle_type: vehicle.type,
          }));
        }
      } catch (_) {}
    }
    if (data.location_lat != null && data.location_lng != null) {
      setRegion({
        latitude: data.location_lat,
        longitude: data.location_lng,
        latitudeDelta: 0.012,
        longitudeDelta: 0.012,
      });
    }
  };

  useEffect(() => {
    loadValeterLocation();
    if (jobIdParam) {
      loadJobById(jobIdParam);
    } else {
      loadActiveJob();
    }
  }, [jobIdParam, user?.id]);

  useEffect(() => {
    const id = jobIdParam ?? activeJob?.id;
    if (!id) return;
    const ch = supabase
      .channel(`trips-job-${id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${id}` },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated?.status ?? status);
          if (updated?.status === 'completed') {
            router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: id } });
          }
        }
      )
      .subscribe();
    channelRef.current = ch;
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [jobIdParam, activeJob?.id]);

  const handleRecenter = () => {
    hapticFeedback('light');
    if (activeJob?.location_lat != null && activeJob?.location_lng != null) {
      const r: Region = {
        latitude: activeJob.location_lat,
        longitude: activeJob.location_lng,
        latitudeDelta: 0.012,
        longitudeDelta: 0.012,
      };
      setRegion(r);
      mapRef.current?.animateToRegion(r, 400);
    } else if (valeterLocation) {
      const r: Region = {
        latitude: valeterLocation.lat,
        longitude: valeterLocation.lng,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      };
      setRegion(r);
      mapRef.current?.animateToRegion(r, 400);
    }
  };

  const getProgress = (): number => {
    switch (status) {
      case 'pending_payment':
        return 20;
      case 'confirmed':
      case 'scheduled':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Awaiting customer payment';
      case 'confirmed':
      case 'scheduled':
        return 'Paid - ready to start journey';
      case 'en_route':
        return 'On the way';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Completed';
      default:
        return 'Tracking job';
    }
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'pending_payment':
        return null;
      case 'confirmed':
      case 'scheduled':
        return { label: 'Start journey', action: () => updateStatus('en_route') };
      case 'en_route':
        return { label: 'Mark arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: 'Start service', action: () => { void startServiceWithPhoto(); } };
      case 'in_progress':
        return { label: 'Complete service', action: () => { void completeServiceWithPhoto(); } };
      default:
        return null;
    }
  };

  const startServiceWithPhoto = async () => {
    if (!activeJob?.id || !user?.id) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: activeJob.id,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'BEFORE IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before starting.',
      });
      if (!sent) return;
      await updateStatus('in_progress');
    } catch (e: any) {
      console.warn('[Trips] startServiceWithPhoto error:', e);
    }
  };

  const completeServiceWithPhoto = async () => {
    if (!activeJob?.id || !user?.id) return;
    try {
      const sent = await promptAndSendBookingPhotoMessage({
        bookingId: activeJob.id,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'Finished IMAGE',
        promptTitle: 'Photo required',
        promptMessage: 'You need to take a picture before finishing.',
      });
      if (!sent) return;
      await updateStatus('completed');
    } catch (e: any) {
      console.warn('[Trips] completeServiceWithPhoto error:', e);
    }
  };

  const updateStatus = async (newStatus: JobStatus) => {
    const id = jobIdParam ?? activeJob?.id;
    if (!id || !user?.id) return;
    hapticFeedback('medium');
    try {
      const { error } = await supabase.from('bookings').update({ status: newStatus }).eq('id', id);
      if (error) throw error;
      setStatus(newStatus);
      if (newStatus === 'completed') {
        router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: id } });
      }
    } catch (e: any) {
      console.warn('[Trips] updateStatus error:', e);
    }
  };

  const nextAction = getNextAction();
  const cardBottom = TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + 16;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <View style={styles.mapWrap}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region}
          onRegionChangeComplete={setRegion}
          showsUserLocation
          showsMyLocationButton={false}
          mapPadding={{ top: 0, bottom: height * 0.42, left: 0, right: 0 }}
          loadingIndicatorColor={SKY}
        >
          {valeterLocation && (
            <Marker coordinate={{ latitude: valeterLocation.lat, longitude: valeterLocation.lng }}>
              <View style={styles.valeterMarker}>
                <Ionicons name="car" size={20} color="#fff" />
              </View>
            </Marker>
          )}
          {activeJob?.location_lat != null && activeJob?.location_lng != null && (
            <Marker
              coordinate={{
                latitude: activeJob.location_lat,
                longitude: activeJob.location_lng,
              }}
            >
              <View style={styles.jobMarker}>
                <Ionicons name="location" size={24} color="#fff" />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <View style={[styles.floatingActionCorner, { top: insets.top + 8 }]}>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={handleRecenter} style={styles.iconBtn}>
            <Ionicons name="locate" size={20} color={SKY} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => (jobIdParam ? loadJobById(jobIdParam) : loadActiveJob())}
            style={styles.iconBtn}
          >
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        </View>
      </View>

      {loading && !activeJob ? (
        <View style={styles.emptyWrap}>
          <View style={[styles.emptyCard, { overflow: 'hidden', padding: 0, minHeight: 260 }]}>
            <DefaultLoadingSkeleton message="Loading…" />
          </View>
        </View>
      ) : !activeJob ? (
        <View style={styles.emptyWrap}>
          <View style={styles.emptyCard}>
            <BlurView intensity={Platform.OS === 'ios' ? 48 : 72} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={styles.emptyCardContent}>
              <View style={styles.emptyCardIconWrap}>
                <GradientIconBox icon="map-outline" preset="sky" boxSize={72} size={40} />
              </View>
              <Text style={styles.emptyCardTitle}>No active wash</Text>
              <Text style={styles.emptyCardSub}>
                Accept a job to start tracking your wash here.
              </Text>
              <View style={styles.emptyCardBullets}>
                <View style={styles.emptyCardBulletRow}>
                  <Ionicons name="checkmark-circle" size={18} color={SKY} />
                  <Text style={styles.emptyCardBulletText}>Track your route on the map</Text>
                </View>
                <View style={styles.emptyCardBulletRow}>
                  <Ionicons name="checkmark-circle" size={18} color={SKY} />
                  <Text style={styles.emptyCardBulletText}>Update status in one tap</Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => { hapticFeedback('light'); router.push('/valeter/jobs'); }}
                style={styles.emptyCardBtn}
                activeOpacity={0.88}
              >
                <View style={styles.emptyCardBtnContent}>
                  <Ionicons name="briefcase-outline" size={20} color="#fff" />
                  <Text style={styles.emptyCardBtnText}>View available washes</Text>
                  <Ionicons name="arrow-forward" size={18} color="#fff" />
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      ) : (
        <View style={[styles.cardWrap, { bottom: cardBottom }]}>
          <BlurView intensity={Platform.OS === 'ios' ? 48 : 72} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={styles.card}>
            <Text style={styles.cardHint}>Update status as you go</Text>
            <View style={styles.cardTop}>
              <StatusBadge status={status} size="medium" />
              <Text style={styles.cardStatus}>{getStatusMessage()}</Text>
            </View>
            <View style={styles.cardProgress}>
              <AnimatedProgress progress={getProgress()} size={88} showPercentage color={SKY} />
            </View>
            <View style={styles.cardInfo}>
              <Text style={styles.cardService}>
                {getServiceDisplayName(activeJob.service_type, activeJob.service_name)}
              </Text>
              <Text style={styles.cardAddress} numberOfLines={1}>
                {activeJob.location_address || '—'}
              </Text>
              <Text style={styles.cardMeta}>
                {customerName} · £{Number(activeJob.price ?? 0).toFixed(2)}
              </Text>
            </View>
            {nextAction ? (
              <TouchableOpacity onPress={nextAction.action} style={styles.cardBtn} activeOpacity={0.85}>
                <Text style={styles.cardBtnText}>{nextAction.label}</Text>
                <Ionicons name="arrow-forward" size={18} color="#fff" />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => router.push({ pathname: '/valeter/jobs/tracking', params: { jobId: activeJob.id } } as any)}
                style={styles.cardBtnSecondary}
                activeOpacity={0.85}
              >
                <Ionicons name="locate" size={18} color={SKY} />
                <Text style={styles.cardBtnSecondaryText}>Track job</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  mapWrap: { ...StyleSheet.absoluteFillObject },
  floatingActionCorner: {
    position: 'absolute',
    right: SCREEN_PADDING_H,
    zIndex: 20,
  },
  headerActions: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  valeterMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#fff',
  },
  jobMarker: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(30,58,138,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: SKY,
  },
  emptyWrap: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyCard: {
    width: '100%',
    maxWidth: 320,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    overflow: 'hidden',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 12 },
      android: { elevation: 8 },
    }),
  },
  emptyCardContent: {
    alignItems: 'center',
    paddingVertical: 32,
    paddingHorizontal: 28,
    zIndex: 1,
  },
  emptyCardIconWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  emptyCardTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  emptyCardSub: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    marginBottom: 20,
    paddingHorizontal: 4,
  },
  emptyCardBullets: {
    alignSelf: 'stretch',
    marginBottom: 24,
    gap: 10,
  },
  emptyCardBulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  emptyCardBulletText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyCardBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 20,
    backgroundColor: SKY,
    borderWidth: 1,
    borderColor: SKY + '99',
    alignSelf: 'stretch',
    minWidth: 200,
    ...Platform.select({
      ios: { shadowColor: SKY, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8 },
      android: { elevation: 4 },
    }),
  },
  emptyCardBtnContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  emptyCardBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  cardWrap: {
    position: 'absolute',
    left: SCREEN_PADDING_H,
    right: SCREEN_PADDING_H,
    zIndex: 1000,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    ...Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 12 },
      android: { elevation: 8 },
    }),
  },
  card: {
    padding: 20,
    minHeight: 260,
  },
  cardHint: { fontSize: 12, color: 'rgba(255,255,255,0.6)', textAlign: 'center', marginBottom: 8 },
  cardTop: { alignItems: 'center', marginBottom: 12 },
  cardStatus: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', marginTop: 8, textAlign: 'center' },
  cardProgress: { alignItems: 'center', marginBottom: 16 },
  cardInfo: { marginBottom: 16, paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.08)' },
  cardService: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 4 },
  cardAddress: { color: 'rgba(249,250,251,0.7)', fontSize: 13, marginBottom: 4 },
  cardMeta: { color: SKY, fontSize: 13, fontWeight: '600' },
  cardBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: SKY,
  },
  cardBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  cardBtnSecondary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  cardBtnSecondaryText: { color: SKY, fontSize: 16, fontWeight: '700' },
});
