/**
 * Legacy route — trips/tracking now use the dashboard background map + tracking sheet.
 */
import { useEffect } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import LoadingScreen from '../../../src/components/LoadingScreen';

export default function TripsRedirect() {
  const params = useLocalSearchParams<{ jobId?: string }>();
  const jobId = typeof params.jobId === 'string' && params.jobId !== 'undefined' ? params.jobId : null;

  useEffect(() => {
    if (jobId) {
      router.replace({ pathname: '/valeter/valeter-dashboard', params: { trackingJobId: jobId } } as any);
    } else {
      router.replace('/valeter/valeter-dashboard');
    }
  }, [jobId]);

  return <LoadingScreen message="Opening trip…" />;
}
