import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

export default function ValeterRewardsSystem() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  
  const [points] = useState(850);
  const nextTierPoints = 1000;
  const progress = Math.min((points / nextTierPoints) * 100, 100);

  const rewards = [
    { id: '1', title: 'Bonus Payment', points: 500, icon: 'wallet', description: '£50 direct bonus to your account' },
    { id: '2', title: 'Free Training', points: 750, icon: 'school', description: 'Advanced detailing workshop' },
    { id: '3', title: 'Premium Tools', points: 1000, icon: 'construct', description: 'Professional grade polisher kit' },
    { id: '4', title: 'Equipment Upgrade', points: 1500, icon: 'hardware-chip', description: 'Complete van setup refresh' },
    { id: '5', title: 'Extra Commission', points: 2000, icon: 'wallet', description: '+5% on all washes for 30 days' },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <AppHeader title="Rewards" accountType="valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            paddingHorizontal: 20,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Tier Header Section - Uber Pro Style */}
        <View style={styles.tierSection}>
          <View style={styles.tierHeader}>
            <View>
              <Text style={styles.tierSubTitle}>Current Tier</Text>
              <Text style={styles.tierTitle}>Gold Partner</Text>
            </View>
            <View style={styles.pointsBadge}>
              <Text style={styles.pointsBadgeText}>{points} pts</Text>
            </View>
          </View>

          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                <Text style={styles.progressTextBold}>{nextTierPoints - points}</Text> points to Platinum
              </Text>
              <Ionicons name="information-circle-outline" size={20} color={SKY} />
            </View>
            <View style={styles.progressBarBg}>
              <LinearGradient 
                colors={['#87CEEB', '#3B82F6']} 
                style={[styles.progressBarFill, { width: `${progress}%` }]} 
                start={{x: 0, y: 0}} end={{x: 1, y: 0}}
              />
            </View>
            <View style={styles.progressFooter}>
              <Text style={styles.progressMinMax}>0</Text>
              <Text style={styles.progressMinMax}>{nextTierPoints}</Text>
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="list" size={20} color="#F9FAFB" />
            <Text style={styles.actionButtonText}>How to earn</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.actionButtonOutline]}>
            <Ionicons name="time" size={20} color={SKY} />
            <Text style={styles.actionButtonTextOutline}>History</Text>
          </TouchableOpacity>
        </View>

        {/* Rewards List */}
        <View style={styles.rewardsSection}>
          <Text style={styles.sectionTitle}>Unlockable Rewards</Text>
          
          {rewards.map((reward, index) => {
            const isUnlocked = points >= reward.points;
            return (
              <View key={reward.id} style={[styles.rewardItem, !isUnlocked && styles.rewardItemLocked]}>
                <View style={styles.rewardIconContainer}>
                  <View style={[styles.rewardIconBg, isUnlocked ? styles.iconBgUnlocked : styles.iconBgLocked]}>
                    <Ionicons 
                      name={reward.icon as any} 
                      size={24} 
                      color={isUnlocked ? '#10B981' : '#6B7280'} 
                    />
                  </View>
                </View>
                
                <View style={styles.rewardInfo}>
                  <Text style={[styles.rewardTitleText, !isUnlocked && styles.textLocked]}>
                    {reward.title}
                  </Text>
                  <Text style={styles.rewardDescText}>{reward.description}</Text>
                  
                  <View style={styles.pointsReqContainer}>
                    <Ionicons name={isUnlocked ? "checkmark-circle" : "lock-closed"} size={14} color={isUnlocked ? "#10B981" : "#6B7280"} />
                    <Text style={[styles.pointsReqText, isUnlocked && styles.pointsReqTextUnlocked]}>
                      {isUnlocked ? 'Unlocked' : `${reward.points} pts required`}
                    </Text>
                  </View>
                </View>

                {isUnlocked && (
                  <TouchableOpacity style={styles.redeemButton}>
                    <Text style={styles.redeemButtonText}>Redeem</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          })}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  
  tierSection: {
    backgroundColor: 'rgba(10,25,41,0.6)',
    borderRadius: 24,
    padding: 24,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  tierHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  tierSubTitle: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  tierTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
  },
  pointsBadge: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  pointsBadgeText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
  },
  progressContainer: {
    marginTop: 8,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#D1D5DB',
    fontSize: 15,
  },
  progressTextBold: {
    color: '#F9FAFB',
    fontWeight: '700',
  },
  progressBarBg: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressMinMax: {
    color: '#6B7280',
    fontSize: 12,
    fontWeight: '600',
  },

  quickActions: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 32,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingVertical: 14,
    borderRadius: 16,
    gap: 8,
  },
  actionButtonText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  actionButtonOutline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  actionButtonTextOutline: {
    color: SKY,
    fontSize: 15,
    fontWeight: '600',
  },

  rewardsSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 16,
    letterSpacing: 0.5,
  },
  rewardItem: {
    flexDirection: 'row',
    backgroundColor: 'rgba(10,25,41,0.4)',
    borderRadius: 20,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  rewardItemLocked: {
    opacity: 0.7,
  },
  rewardIconContainer: {
    marginRight: 16,
  },
  rewardIconBg: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconBgUnlocked: {
    backgroundColor: 'rgba(16,185,129,0.15)',
  },
  iconBgLocked: {
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  rewardInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  rewardTitleText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  textLocked: {
    color: '#9CA3AF',
  },
  rewardDescText: {
    color: '#9CA3AF',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 8,
  },
  pointsReqContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  pointsReqText: {
    color: '#6B7280',
    fontSize: 13,
    fontWeight: '600',
  },
  pointsReqTextUnlocked: {
    color: '#10B981',
  },
  redeemButton: {
    alignSelf: 'center',
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    marginLeft: 12,
  },
  redeemButtonText: {
    color: '#10B981',
    fontWeight: '700',
    fontSize: 14,
  },
});
