import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';
import { colors } from '../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../src/components/valeter/ValeterNavSidebar';
import {
  getValeterLoyaltyBalance,
  getValeterLoyaltyActivity,
  redeemValeterReward,
  getValeterTierProgress,
  VALETER_REWARDS,
  formatRelativeDate,
  type ValeterReward,
} from '../../src/services/ValeterLoyaltyService';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

export default function ValeterRewardsSystem() {
  const { user, updateUser } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [points, setPoints] = useState(0);
  const [completedJobs, setCompletedJobs] = useState(0);
  const [activity, setActivity] = useState<Array<{ id: string; label: string; pointsLabel: string; date: string; kind: 'earn' | 'redeem' }>>([]);

  const load = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      if (!refreshing) setLoading(true);
      const [balance, activityRows] = await Promise.all([
        getValeterLoyaltyBalance(user.id),
        getValeterLoyaltyActivity(user.id),
      ]);
      setPoints(balance.points);
      setCompletedJobs(balance.completedJobs);
      setActivity(activityRows);
    } catch (e) {
      console.warn('[ValeterRewards] load failed:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, refreshing]);

  useEffect(() => { void load(); }, [load]);

  const onRefresh = () => { setRefreshing(true); void load(); };

  const handleRedeem = (reward: ValeterReward) => {
    if (!user?.id || redeemingId || points < reward.points) return;
    Alert.alert(
      'Redeem reward',
      `Spend ${reward.points.toLocaleString()} points to unlock "${reward.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            void (async () => {
              try {
                setRedeemingId(reward.id);
                const next = await redeemValeterReward(user.id, reward);
                if (updateUser) await updateUser({ tierPoints: next });
                setPoints(next);
                const activityRows = await getValeterLoyaltyActivity(user.id);
                setActivity(activityRows);
                Alert.alert('Redeemed!', `"${reward.title}" has been added to your account.`);
              } catch (err: any) {
                Alert.alert('Failed', err?.message || 'Unable to redeem right now.');
              } finally {
                setRedeemingId(null);
              }
            })();
          },
        },
      ],
    );
  };

  const tierInfo = getValeterTierProgress(points);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader title="Rewards" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 20 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Tier card */}
        <View style={styles.tierCard}>
          <View style={styles.tierHeader}>
            <View>
              <Text style={styles.tierSubTitle}>Current Tier</Text>
              <Text style={[styles.tierTitle, { color: tierInfo.color }]}>{tierInfo.tier} Partner</Text>
            </View>
            <View style={styles.pointsBadge}>
              <Text style={styles.pointsBadgeText}>{loading ? '—' : points.toLocaleString()} pts</Text>
            </View>
          </View>

          <View style={styles.progressBarBg}>
            <LinearGradient
              colors={[tierInfo.color, SKY]}
              style={[styles.progressBarFill, { width: `${tierInfo.progress}%` }]}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            />
          </View>

          <View style={styles.progressFooter}>
            {tierInfo.nextTier ? (
              <Text style={styles.progressHint}>
                <Text style={{ color: '#F9FAFB', fontWeight: '700' }}>{tierInfo.pointsToNext.toLocaleString()}</Text>
                {' pts to '}{tierInfo.nextTier}
              </Text>
            ) : (
              <Text style={styles.progressHint}>Maximum tier reached</Text>
            )}
            <Text style={styles.progressHint}>{completedJobs} jobs completed</Text>
          </View>
        </View>

        {/* How to earn */}
        <View style={styles.earnCard}>
          <Text style={styles.sectionTitle}>How to earn</Text>
          {[
            { label: 'Job completed', pts: '+25 pts', icon: 'checkmark-circle-outline' },
            { label: '5-star rating received', pts: '+50 pts', icon: 'star-outline' },
            { label: 'Refer a valeter', pts: '+100 pts', icon: 'people-outline' },
          ].map((item) => (
            <View key={item.label} style={styles.earnRow}>
              <Ionicons name={item.icon as any} size={20} color={SKY} />
              <Text style={styles.earnLabel}>{item.label}</Text>
              <Text style={styles.earnPts}>{item.pts}</Text>
            </View>
          ))}
        </View>

        {/* Rewards list */}
        <Text style={styles.sectionTitle}>Unlockable Rewards</Text>
        {VALETER_REWARDS.map((reward) => {
          const unlocked = points >= reward.points;
          const redeeming = redeemingId === reward.id;
          return (
            <View key={reward.id} style={[styles.rewardItem, !unlocked && styles.rewardItemLocked]}>
              <View style={[styles.rewardIconBg, unlocked ? styles.iconUnlocked : styles.iconLocked]}>
                <Ionicons name={reward.icon as any} size={24} color={unlocked ? '#10B981' : '#6B7280'} />
              </View>
              <View style={styles.rewardInfo}>
                <Text style={[styles.rewardTitle, !unlocked && styles.textMuted]}>{reward.title}</Text>
                <Text style={styles.rewardDesc}>{reward.description}</Text>
                <View style={styles.rewardReqRow}>
                  <Ionicons name={unlocked ? 'checkmark-circle' : 'lock-closed'} size={13} color={unlocked ? '#10B981' : '#6B7280'} />
                  <Text style={[styles.rewardReqText, unlocked && styles.rewardReqUnlocked]}>
                    {unlocked ? 'Unlocked' : `${reward.points.toLocaleString()} pts required`}
                  </Text>
                </View>
              </View>
              {unlocked && (
                <TouchableOpacity
                  style={[styles.redeemBtn, redeeming && styles.redeemBtnDisabled]}
                  onPress={() => handleRedeem(reward)}
                  disabled={!!redeemingId}
                >
                  <Text style={styles.redeemBtnText}>{redeeming ? '…' : 'Redeem'}</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}

        {/* Activity feed */}
        {activity.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { marginTop: 24 }]}>Recent activity</Text>
            {activity.map((item) => (
              <View key={item.id} style={styles.activityRow}>
                <Ionicons
                  name={item.kind === 'redeem' ? 'gift-outline' : 'briefcase-outline'}
                  size={18}
                  color={item.kind === 'redeem' ? '#A78BFA' : SKY}
                />
                <View style={styles.activityInfo}>
                  <Text style={styles.activityLabel}>{item.label}</Text>
                  <Text style={styles.activityDate}>{formatRelativeDate(item.date)}</Text>
                </View>
                <Text style={[styles.activityPts, { color: item.kind === 'redeem' ? '#A78BFA' : '#10B981' }]}>
                  {item.pointsLabel}
                </Text>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },

  tierCard: {
    backgroundColor: 'rgba(10,25,41,0.6)',
    borderRadius: 24,
    padding: 24,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  tierHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  tierSubTitle: { color: SKY, fontSize: 13, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 },
  tierTitle: { fontSize: 26, fontWeight: '800' },
  pointsBadge: { backgroundColor: 'rgba(135,206,235,0.15)', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)' },
  pointsBadgeText: { color: SKY, fontSize: 16, fontWeight: '700' },
  progressBarBg: { height: 8, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 4, overflow: 'hidden', marginBottom: 10 },
  progressBarFill: { height: '100%', borderRadius: 4 },
  progressFooter: { flexDirection: 'row', justifyContent: 'space-between' },
  progressHint: { color: '#9CA3AF', fontSize: 13 },

  earnCard: { backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 20, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  earnRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8 },
  earnLabel: { flex: 1, color: '#D1D5DB', fontSize: 14 },
  earnPts: { color: '#10B981', fontSize: 14, fontWeight: '700' },

  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', marginBottom: 14 },

  rewardItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 20, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  rewardItemLocked: { opacity: 0.65 },
  rewardIconBg: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  iconUnlocked: { backgroundColor: 'rgba(16,185,129,0.15)' },
  iconLocked: { backgroundColor: 'rgba(255,255,255,0.05)' },
  rewardInfo: { flex: 1 },
  rewardTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginBottom: 3 },
  textMuted: { color: '#9CA3AF' },
  rewardDesc: { color: '#9CA3AF', fontSize: 13, lineHeight: 18, marginBottom: 6 },
  rewardReqRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  rewardReqText: { color: '#6B7280', fontSize: 12, fontWeight: '600' },
  rewardReqUnlocked: { color: '#10B981' },
  redeemBtn: { backgroundColor: 'rgba(16,185,129,0.2)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 14, marginLeft: 10 },
  redeemBtnDisabled: { opacity: 0.5 },
  redeemBtnText: { color: '#10B981', fontWeight: '700', fontSize: 13 },

  activityRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(10,25,41,0.4)', borderRadius: 16, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: 'rgba(255,255,255,0.05)' },
  activityInfo: { flex: 1 },
  activityLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },
  activityDate: { color: '#6B7280', fontSize: 12, marginTop: 2 },
  activityPts: { fontSize: 14, fontWeight: '700' },
});
