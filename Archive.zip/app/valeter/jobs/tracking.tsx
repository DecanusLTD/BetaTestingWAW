/**
 * Legacy route — tracking now lives on the dashboard map + bottom sheet.
 */
import { useEffect } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import LoadingScreen from '../../../src/components/LoadingScreen';

export default function JobTrackingRedirect() {
  const params = useLocalSearchParams<{ jobId?: string }>();
  const jobId = typeof params.jobId === 'string' && params.jobId !== 'undefined' ? params.jobId : null;

  useEffect(() => {
    if (jobId) {
      router.replace({ pathname: '/valeter/valeter-dashboard', params: { trackingJobId: jobId } } as any);
          } else {
      router.replace('/valeter/valeter-dashboard');
    }
  }, [jobId]);

  return <LoadingScreen message="Opening tracker…" />;
}
