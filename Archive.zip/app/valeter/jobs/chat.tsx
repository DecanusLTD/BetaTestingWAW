/**
 * Valeter chat with customer – WhatsApp-like UI (shared ChatThreadView).
 */
import React, { useMemo, useState, useEffect } from 'react';
import { View, Alert, TextInput, Text, StyleSheet } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';
import { sendBookingPaymentRequest } from '../../../src/services/bookingPaymentRequestService';
import { colors } from '../../../src/constants/colors';
import { lightMistInput, lightMistPanel } from '../../../src/constants/accountThemes';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { getCustomerDisplayName } from '../../../src/utils/customerProfiles';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import ChatThreadView from '../../../src/components/chat/ChatThreadView';
import LoadingScreen from '../../../src/components/LoadingScreen';
import InfoBottomSheet from '../../../src/components/shared/InfoBottomSheet';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const SKY = colors.SKY;

export default function ValeterJobChatScreen() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const { user } = useAuth();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const accent = theme?.primary ?? SKY;
  const chatWall = isLight ? '#C5DCE8' : (theme?.background?.[0] ?? '#0B1F36');
  const sheetText = isLight ? '#0F2740' : '#FFFFFF';
  const sheetMuted = isLight ? 'rgba(15,39,64,0.62)' : 'rgba(255,255,255,0.65)';
  const sheetSoft = isLight ? 'rgba(15,39,64,0.45)' : 'rgba(255,255,255,0.38)';
  const sheetFieldBg = isLight ? lightMistInput : 'rgba(255,255,255,0.06)';
  const sheetFieldBorder = isLight ? 'rgba(126,184,212,0.45)' : 'rgba(255,255,255,0.12)';
  const amountCardBg = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const amountCardBorder = isLight ? 'rgba(126,184,212,0.4)' : 'rgba(255,255,255,0.1)';

  const [customerName, setCustomerName] = useState<string>('Customer');
  const [serviceName, setServiceName] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [requestModalVisible, setRequestModalVisible] = useState(false);
  const [requestAmount, setRequestAmount] = useState('');
  const [requestReason, setRequestReason] = useState('');
  const [requestNote, setRequestNote] = useState('');
  const [submittingRequest, setSubmittingRequest] = useState(false);

  const parsedAmount = Number(requestAmount);
  const amountPreview = useMemo(() => {
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) return null;
    const platformFee = Math.max(0, parsedAmount * 0.05);
    return {
      total: parsedAmount,
      platformFee,
      youReceive: Math.max(0, parsedAmount - platformFee),
    };
  }, [parsedAmount]);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('user_id, service_type, service_name, location_address')
          .eq('id', bookingId)
          .eq('valeter_id', user?.id)
          .maybeSingle();
        if (error || !data) {
          setLoading(false);
          return;
        }
        const r = data as any;
        setServiceName(getServiceDisplayName(r.service_type, r.service_name));
        setCustomerName(await getCustomerDisplayName(r.user_id));
      } catch {
        setCustomerName('Customer');
      } finally {
        setLoading(false);
      }
    })();
  }, [bookingId, user?.id]);

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    hapticFeedback('light');
    Alert.alert('Call', 'Call customer – will open phone dialler when connected.');
  };

  const handleAttachImage = async () => {
    hapticFeedback('light');
    if (!bookingId || !user?.id) return;
    try {
      await promptAndSendBookingPhotoMessage({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'IMAGE',
        promptTitle: 'Photo',
        promptMessage: 'Take a photo to send in chat.',
      });
    } catch (error: any) {
      Alert.alert('Photo', error?.message || 'Could not take or send the photo.');
    }
  };

  const handleVoiceNote = () => {
    hapticFeedback('light');
    Alert.alert('Voice note', 'Hold to record – voice messages will be sent when backend is ready.');
  };

  const openPaymentRequest = () => {
    hapticFeedback('light');
    setRequestModalVisible(true);
  };

  const submitPaymentRequest = async () => {
    if (!bookingId || !user?.id) return;
    const amount = Number(requestAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      Alert.alert('Extra charge', 'Enter a valid amount.');
      return;
    }
    if (!requestReason.trim()) {
      Alert.alert('Extra charge', 'Tell the customer why you need the extra amount.');
      return;
    }

    try {
      await hapticFeedback('medium');
      setSubmittingRequest(true);
      await sendBookingPaymentRequest({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        amount,
        reason: requestReason.trim(),
        note: requestNote.trim() || undefined,
        currency: 'gbp',
      });
      setRequestModalVisible(false);
      setRequestAmount('');
      setRequestReason('');
      setRequestNote('');
      Alert.alert('Request sent', 'The customer will see the extra charge request in chat.');
    } catch (error: any) {
      Alert.alert('Extra charge', error?.message || 'Could not send the request.');
    } finally {
      setSubmittingRequest(false);
    }
  };

  const handleDeleteChat = () => {
    hapticFeedback('light');
    Alert.alert(
      'Delete chat',
      'Remove this conversation from your list?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (bookingId) {
              const { addDeletedChatBookingId } = await import('../../../src/services/DeletedChatsService');
              await addDeletedChatBookingId(bookingId);
            }
            router.back();
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: chatWall }} edges={[]}>
      <ChatThreadView
        bookingId={bookingId}
        currentUserId={user?.id ?? null}
        currentUserRole="valeter"
        title={customerName}
        subtitle={serviceName}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onVoiceNote={handleVoiceNote}
        onRequestPayment={openPaymentRequest}
        onDelete={handleDeleteChat}
        accentColor={accent}
        backgroundColor={chatWall}
      />

      <InfoBottomSheet
        visible={requestModalVisible}
        onClose={() => setRequestModalVisible(false)}
        title="Request extra payment"
        accentColor={accent}
        variant="header"
        contentMaxHeight="68%"
        footer={
          <View style={styles.sheetFooter}>
            <ContinueCTAButton
              title={submittingRequest ? 'Sending…' : 'Send request'}
              onPress={submitPaymentRequest}
              accentColor={accent}
              loading={submittingRequest}
              disabled={submittingRequest}
              showTrailingChevron={false}
            />
          </View>
        }
      >
        <Text style={[styles.sheetSubtitle, { color: sheetMuted }]}>
          The customer will get a pay button in this chat.
        </Text>

        <View style={[styles.amountCard, { backgroundColor: amountCardBg, borderColor: amountCardBorder }]}>
          <Text style={[styles.amountLabel, { color: sheetSoft }]}>Amount</Text>
          <View style={styles.amountRow}>
            <Text style={[styles.amountCurrency, { color: accent }]}>£</Text>
            <TextInput
              value={requestAmount}
              onChangeText={setRequestAmount}
              placeholder="0.00"
              placeholderTextColor={sheetSoft}
              keyboardType="decimal-pad"
              style={[styles.amountInput, { color: sheetText }]}
            />
          </View>
          {amountPreview ? (
            <Text style={[styles.amountMeta, { color: sheetMuted }]}>
              Fee £{amountPreview.platformFee.toFixed(2)} · You receive £{amountPreview.youReceive.toFixed(2)}
            </Text>
          ) : null}
        </View>

        <View style={styles.field}>
          <Text style={[styles.label, { color: sheetText }]}>Reason</Text>
          <TextInput
            value={requestReason}
            onChangeText={setRequestReason}
            placeholder="e.g. Very dirty car, extra time needed"
            placeholderTextColor={sheetSoft}
            style={[styles.input, styles.inputMultiline, { color: sheetText, backgroundColor: sheetFieldBg, borderColor: sheetFieldBorder }]}
            multiline
          />
        </View>

        <View style={styles.field}>
          <Text style={[styles.label, { color: sheetText }]}>
            Note <Text style={[styles.labelOptional, { color: sheetSoft }]}>(optional)</Text>
          </Text>
          <TextInput
            value={requestNote}
            onChangeText={setRequestNote}
            placeholder="Any extra detail"
            placeholderTextColor={sheetSoft}
            style={[styles.input, { color: sheetText, backgroundColor: sheetFieldBg, borderColor: sheetFieldBorder }]}
          />
        </View>
      </InfoBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  sheetFooter: {
    gap: 10,
  },
  sheetSubtitle: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  amountCard: {
    marginBottom: 16,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
  },
  amountLabel: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
  },
  amountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  amountCurrency: {
    fontSize: 28,
    fontWeight: '800',
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: '800',
    paddingVertical: 0,
    minHeight: 40,
  },
  amountMeta: {
    marginTop: 10,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  field: {
    gap: 8,
    marginBottom: 14,
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
  },
  labelOptional: {
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderRadius: 14,
    fontSize: 15,
    lineHeight: 21,
    minHeight: 48,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  inputMultiline: {
    minHeight: 72,
    textAlignVertical: 'top',
  },
});
