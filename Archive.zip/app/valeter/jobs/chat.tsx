/**
 * Valeter chat with customer – WhatsApp-like UI (shared ChatThreadView).
 */
import React, { useState, useEffect } from 'react';
import { View, ActivityIndicator, Alert, Modal, TextInput, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { promptAndSendBookingPhotoMessage } from '../../../src/services/bookingChatMediaService';
import { sendBookingPaymentRequest } from '../../../src/services/bookingPaymentRequestService';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import ChatThreadView from '../../../src/components/chat/ChatThreadView';
import LoadingScreen from '../../../src/components/LoadingScreen';

const SKY = colors.SKY;

async function getCustomerName(userId: string): Promise<string> {
  try {
    const { data } = await supabase.from('profiles').select('full_name, name').eq('id', userId).maybeSingle();
    const p = data as any;
    return (p?.full_name || p?.name || 'Customer') as string;
  } catch {
    return 'Customer';
  }
}

export default function ValeterJobChatScreen() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const { user } = useAuth();
  const [customerName, setCustomerName] = useState<string>('Customer');
  const [serviceName, setServiceName] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [requestModalVisible, setRequestModalVisible] = useState(false);
  const [requestAmount, setRequestAmount] = useState('');
  const [requestReason, setRequestReason] = useState('');
  const [requestNote, setRequestNote] = useState('');

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('user_id, service_type, service_name, location_address')
          .eq('id', bookingId)
          .eq('valeter_id', user?.id)
          .maybeSingle();
        if (error || !data) {
          setLoading(false);
          return;
        }
        const r = data as any;
        setServiceName(getServiceDisplayName(r.service_type, r.service_name));
        setCustomerName(await getCustomerName(r.user_id));
      } catch {
        setCustomerName('Customer');
      } finally {
        setLoading(false);
      }
    })();
  }, [bookingId, user?.id]);

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    hapticFeedback('light');
    Alert.alert('Call', 'Call customer – will open phone dialler when connected.');
  };

  const handleAttachImage = async () => {
    hapticFeedback('light');
    if (!bookingId || !user?.id) return;
    try {
      await promptAndSendBookingPhotoMessage({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        content: 'IMAGE',
        promptTitle: 'Photo',
        promptMessage: 'Take a photo to send in chat.',
      });
    } catch (error: any) {
      Alert.alert('Photo', error?.message || 'Could not take or send the photo.');
    }
  };

  const handleVoiceNote = () => {
    hapticFeedback('light');
    Alert.alert('Voice note', 'Hold to record – voice messages will be sent when backend is ready.');
  };

  const openPaymentRequest = () => {
    hapticFeedback('light');
    setRequestModalVisible(true);
  };

  const submitPaymentRequest = async () => {
    if (!bookingId || !user?.id) return;
    const amount = Number(requestAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      Alert.alert('Extra charge', 'Enter a valid amount.');
      return;
    }
    if (!requestReason.trim()) {
      Alert.alert('Extra charge', 'Tell the customer why you need the extra amount.');
      return;
    }

    try {
      await hapticFeedback('medium');
      await sendBookingPaymentRequest({
        bookingId,
        senderId: user.id,
        senderRole: 'valeter',
        amount,
        reason: requestReason.trim(),
        note: requestNote.trim() || undefined,
        currency: 'gbp',
      });
      setRequestModalVisible(false);
      setRequestAmount('');
      setRequestReason('');
      setRequestNote('');
      Alert.alert('Request sent', 'The customer will see the extra charge request in chat.');
    } catch (error: any) {
      Alert.alert('Extra charge', error?.message || 'Could not send the request.');
    }
  };

  const handleDeleteChat = () => {
    hapticFeedback('light');
    Alert.alert(
      'Delete chat',
      'Remove this conversation from your list?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (bookingId) {
              const { addDeletedChatBookingId } = await import('../../../src/services/DeletedChatsService');
              await addDeletedChatBookingId(bookingId);
            }
            router.back();
          },
        },
      ]
    );
  };

  if (loading) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0F172A' }} edges={[]}>
      <ChatThreadView
        bookingId={bookingId}
        currentUserId={user?.id ?? null}
        currentUserRole="valeter"
        title={customerName}
        subtitle={serviceName}
        onBack={handleBack}
        onCall={handleCall}
        onAttachImage={handleAttachImage}
        onVoiceNote={handleVoiceNote}
        onRequestPayment={openPaymentRequest}
        onDelete={handleDeleteChat}
        accentColor={SKY}
      />

      <Modal transparent visible={requestModalVisible} animationType="fade" onRequestClose={() => setRequestModalVisible(false)}>
        <View style={styles.modalBackdrop}>
          <TouchableOpacity style={StyleSheet.absoluteFill} activeOpacity={1} onPress={() => setRequestModalVisible(false)} />
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Request extra payment</Text>
            <Text style={styles.modalSubtitle}>Ask the customer for a top-up amount before continuing the wash.</Text>

            <View style={styles.field}>
              <Text style={styles.label}>Amount (£)</Text>
              <TextInput
                value={requestAmount}
                onChangeText={setRequestAmount}
                placeholder="10.00"
                placeholderTextColor="rgba(255,255,255,0.38)"
                keyboardType="decimal-pad"
                style={styles.input}
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Reason</Text>
              <TextInput
                value={requestReason}
                onChangeText={setRequestReason}
                placeholder="Very dirty car, extra time needed"
                placeholderTextColor="rgba(255,255,255,0.38)"
                style={styles.input}
                multiline
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Note</Text>
              <TextInput
                value={requestNote}
                onChangeText={setRequestNote}
                placeholder="Optional extra detail"
                placeholderTextColor="rgba(255,255,255,0.38)"
                style={styles.input}
                multiline
              />
            </View>

            <View style={styles.row}>
              <TouchableOpacity style={[styles.btn, styles.btnGhost]} onPress={() => setRequestModalVisible(false)}>
                <Text style={styles.btnGhostText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, styles.btnPrimary]} onPress={submitPaymentRequest}>
                <Text style={styles.btnPrimaryText}>Send request</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  modalBackdrop: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  modalCard: {
    margin: 16,
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.98)',
    padding: 18,
    gap: 12,
  },
  modalTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '800',
  },
  modalSubtitle: {
    color: 'rgba(255,255,255,0.72)',
    fontSize: 13,
    lineHeight: 18,
  },
  field: {
    gap: 8,
  },
  label: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
  },
  input: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    color: '#fff',
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    minHeight: 48,
  },
  row: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 4,
  },
  btn: {
    flex: 1,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  btnGhost: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: 'transparent',
  },
  btnGhostText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '800',
  },
  btnPrimary: {
    backgroundColor: SKY,
  },
  btnPrimaryText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '900',
  },
});
