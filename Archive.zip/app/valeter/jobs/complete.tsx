import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  StatusBar,
  TextInput,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById, resolveCustomerAvatarFromProfileRow } from '../../../src/utils/customerProfiles';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';
import { themeBackgroundGradient } from '../../../src/utils/themeGradient';
import { lightMistElevated, lightMistPanel } from '../../../src/constants/accountThemes';

const SKY = colors.SKY;
const BG = colors.BG;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const RATING_LABELS: Record<number, string> = {
  1: 'Poor',
  2: 'Fair',
  3: 'Good',
  4: 'Very good',
  5: 'Excellent',
};

const LOW_RATING_CHIPS = ['Hard to find', 'No-show issues', 'Unclear location', 'Rude', 'Other'];

type CompletedJob = {
  location_address?: string | null;
  service_type?: string | null;
  service_name?: string | null;
  price?: number | string | null;
  valeter_rating?: number | null;
  user_id?: string | null;
};

function resolveJobIdParam(jobId: string | string[] | undefined): string {
  if (typeof jobId === 'string') return jobId;
  if (Array.isArray(jobId)) return jobId[0] ?? '';
  return '';
}

export default function JobComplete() {
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const gradientBg = themeBackgroundGradient(theme?.background, VALETER_BG_FALLBACK);
  const params = useLocalSearchParams();
  const jobId = resolveJobIdParam(params.jobId);

  const [job, setJob] = useState<CompletedJob | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [customerAvatar, setCustomerAvatar] = useState<string | null>(null);
  const [customerRating, setCustomerRating] = useState(0);
  const [ratingSaved, setRatingSaved] = useState(false);
  const [savingRating, setSavingRating] = useState(false);
  const [note, setNote] = useState('');
  const [selectedChip, setSelectedChip] = useState<string | null>(null);
  const [earningsDisplay, setEarningsDisplay] = useState(0);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const successScale = useRef(new Animated.Value(0)).current;
  const starPop = useRef(new Animated.Value(1)).current;

  const accent = theme?.primary ?? SKY;
  const textMain = theme?.textPrimary ?? '#F8FAFC';
  const textMuted = theme?.textSecondary ?? 'rgba(248,250,252,0.7)';
  const cardBg = isLight ? lightMistElevated : 'rgba(15,23,42,0.72)';
  const cardBorder = isLight ? 'rgba(158,201,224,0.36)' : 'rgba(148,163,184,0.22)';
  const inputBg = isLight ? lightMistPanel : 'rgba(15,23,42,0.55)';

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 480, useNativeDriver: true }),
      Animated.spring(successScale, { toValue: 1, tension: 56, friction: 7, useNativeDriver: true }),
    ]).start();
    loadJob();
  }, [jobId]);

  useEffect(() => {
    const target = Number(job?.price || 0);
    if (!target) {
      setEarningsDisplay(0);
      return;
    }
    let frame = 0;
    const frames = 22;
    const id = setInterval(() => {
      frame += 1;
      setEarningsDisplay(Math.round((target * frame) / frames * 100) / 100);
      if (frame >= frames) clearInterval(id);
    }, 28);
    return () => clearInterval(id);
  }, [job?.price]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', jobId).single();
      if (error) throw error;
      setJob(data);
      if (data?.valeter_rating != null) {
        setCustomerRating(Number(data.valeter_rating));
        setRatingSaved(true);
      }
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name?.trim() || 'Customer');
        setCustomerAvatar(resolveCustomerAvatarFromProfileRow(profile) || null);
      } else {
        setCustomerName('Customer');
        setCustomerAvatar(null);
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const persistRating = async (stars: number) => {
    if (!jobId) return;
    setSavingRating(true);
    try {
      const { error } = await supabase.from('bookings').update({ valeter_rating: stars }).eq('id', jobId);
      if (error) throw error;
      setRatingSaved(true);
    } catch (e) {
      console.error('Error saving rating:', e);
    } finally {
      setSavingRating(false);
    }
  };

  const handleRateCustomer = async (stars: number) => {
    if (savingRating || !jobId) return;
    await hapticFeedback('medium');
    setCustomerRating(stars);
    Animated.sequence([
      Animated.timing(starPop, { toValue: 1.12, duration: 90, useNativeDriver: true }),
      Animated.spring(starPop, { toValue: 1, friction: 5, useNativeDriver: true }),
    ]).start();
    await persistRating(stars);
  };

  const handleBackToMap = async () => {
    await hapticFeedback('light');
    router.replace('/valeter/valeter-dashboard');
  };

  const serviceLabel = getServiceDisplayName(job?.service_type, job?.service_name);
  const showLowChips = customerRating > 0 && customerRating <= 2;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />

      <ValeterScreenHeader title="Job complete" showBack={false} />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 8,
              paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 24,
            },
          ]}
        >
          <Animated.View style={[styles.hero, { transform: [{ scale: successScale }] }]}>
            <View style={[styles.successCircle, { borderColor: `${accent}55` }]}>
              <Ionicons name="checkmark-done-circle" size={56} color="#10B981" />
            </View>
            <Text style={[styles.heroTitle, { color: textMain }]}>Well done</Text>
            <Text style={[styles.earnings, { color: accent }]}>£{earningsDisplay.toFixed(2)}</Text>
            <Text style={[styles.earningsHint, { color: textMuted }]}>earned · {serviceLabel}</Text>
          </Animated.View>

          <View style={[styles.ratingCard, { backgroundColor: cardBg, borderColor: cardBorder }]}>
            <View style={styles.customerRow}>
              <View style={[styles.avatar, { borderColor: `${accent}55`, backgroundColor: `${accent}18` }]}>
                {customerAvatar ? (
                  <Image source={{ uri: customerAvatar }} style={styles.avatarImg} />
                ) : (
                  <Ionicons name="person" size={28} color={accent} />
                )}
              </View>
              <View style={styles.customerCopy}>
                <Text style={[styles.rateEyebrow, { color: textMuted }]}>Rate this customer</Text>
                <Text style={[styles.customerName, { color: textMain }]} numberOfLines={1}>
                  {customerName}
                </Text>
              </View>
            </View>

            <Animated.View style={[styles.starsRow, { transform: [{ scale: starPop }] }]}>
              {[1, 2, 3, 4, 5].map((star) => (
                <TouchableOpacity
                  key={star}
                  onPress={() => handleRateCustomer(star)}
                  disabled={savingRating}
                  style={styles.starBtn}
                  activeOpacity={0.85}
                  accessibilityRole="button"
                  accessibilityLabel={`${star} star${star === 1 ? '' : 's'}`}
                >
                  <Ionicons
                    name={customerRating >= star ? 'star' : 'star-outline'}
                    size={40}
                    color={customerRating >= star ? '#E8C547' : 'rgba(148,163,184,0.45)'}
                  />
                </TouchableOpacity>
              ))}
            </Animated.View>

            <Text style={[styles.ratingLabel, { color: textMuted }]}>
              {customerRating === 0 && 'Tap a star to rate'}
              {customerRating > 0 && (RATING_LABELS[customerRating] ?? `${customerRating} stars`)}
              {ratingSaved && customerRating > 0 ? ' · Saved' : ''}
            </Text>

            {showLowChips ? (
              <View style={styles.chipRow}>
                {LOW_RATING_CHIPS.map((chip) => {
                  const on = selectedChip === chip;
                  return (
                    <TouchableOpacity
                      key={chip}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedChip(on ? null : chip);
                      }}
                      style={[
                        styles.chip,
                        {
                          borderColor: on ? accent : cardBorder,
                          backgroundColor: on ? `${accent}22` : inputBg,
                        },
                      ]}
                      activeOpacity={0.85}
                    >
                      <Text style={[styles.chipText, { color: on ? accent : textMuted }]}>{chip}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            ) : null}

            {customerRating > 0 ? (
              <TextInput
                value={note}
                onChangeText={setNote}
                placeholder="Optional note (only you see this for now)"
                placeholderTextColor="rgba(148,163,184,0.55)"
                style={[
                  styles.noteInput,
                  { color: textMain, backgroundColor: inputBg, borderColor: cardBorder },
                ]}
                multiline
                maxLength={160}
              />
            ) : null}
          </View>

          <TouchableOpacity onPress={handleBackToMap} style={styles.primaryBtn} activeOpacity={0.88}>
            <LinearGradient colors={[accent, '#3B82F6']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.primaryGradient}>
              <Text style={styles.primaryText}>Back to map</Text>
              <Ionicons name="map-outline" size={18} color="#0A1929" />
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/valeter/valeter-wash-history' as any);
            }}
            style={styles.secondaryBtn}
            activeOpacity={0.85}
          >
            <Text style={[styles.secondaryText, { color: textMuted }]}>View job history</Text>
          </TouchableOpacity>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  hero: {
    alignItems: 'center',
    marginBottom: 22,
  },
  successCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(16,185,129,0.18)',
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 6,
  },
  earnings: {
    fontSize: 36,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  earningsHint: {
    marginTop: 4,
    fontSize: 14,
    fontWeight: '600',
  },
  ratingCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 18,
    marginBottom: 18,
  },
  customerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 18,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1.5,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
  },
  customerCopy: {
    flex: 1,
    minWidth: 0,
  },
  rateEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  customerName: {
    fontSize: 18,
    fontWeight: '800',
  },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    marginBottom: 10,
  },
  starBtn: {
    padding: 4,
  },
  ratingLabel: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'center',
    marginTop: 12,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  chipText: {
    fontSize: 12,
    fontWeight: '700',
  },
  noteInput: {
    marginTop: 14,
    minHeight: 72,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    fontWeight: '500',
    textAlignVertical: 'top',
  },
  primaryBtn: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 10,
  },
  primaryGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  primaryText: {
    color: '#0A1929',
    fontSize: 17,
    fontWeight: '800',
  },
  secondaryBtn: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  secondaryText: {
    fontSize: 14,
    fontWeight: '700',
  },
});
