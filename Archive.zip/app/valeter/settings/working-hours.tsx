/**
 * Working hours — interactive week schedule (strip + live status + presets).
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  ScrollView,
  Pressable,
  TouchableOpacity,
  Modal,
  Platform,
  LayoutAnimation,
  UIManager,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import DateTimePicker from '@react-native-community/datetimepicker';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/valeter/ValeterScreenHeader';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../../src/constants/accountThemes';
import { colors } from '../../../src/constants/colors';
import LoadingScreen from '../../../src/components/LoadingScreen';
import { loadCalendarSyncSettings, saveCalendarSyncSettings } from '../../../src/services/calendarSyncSettings';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const SKY = colors.SKY;
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#2563EB'];

const DAYS_ORDER = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const;
type DayKey = (typeof DAYS_ORDER)[number];

const DAY_LABELS: Record<DayKey, string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
  sunday: 'Sunday',
};

const DAY_SHORT: Record<DayKey, string> = {
  monday: 'Mon',
  tuesday: 'Tue',
  wednesday: 'Wed',
  thursday: 'Thu',
  friday: 'Fri',
  saturday: 'Sat',
  sunday: 'Sun',
};

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

type TimePickerTarget = {
  day: DayKey;
  field: 'startTime' | 'endTime';
} | null;

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

const REMINDER_OPTIONS = [5, 10, 15, 30, 60];
const JS_DAY_KEYS: DayKey[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

const PRESETS = [
  { id: 'weekdays', label: 'Weekdays', hint: '8–6', icon: 'briefcase-outline' as const },
  { id: 'weekends', label: 'Weekends', hint: '9–5', icon: 'sunny-outline' as const },
  { id: 'late', label: 'Late nights', hint: '10–20', icon: 'moon-outline' as const },
  { id: 'full', label: 'Full week', hint: '8–6', icon: 'calendar-outline' as const },
] as const;

function twoStopGradient(bg: readonly string[] | undefined, fallback: [string, string]): [string, string] {
  if (Array.isArray(bg) && bg.length >= 2) return [String(bg[0]), String(bg[1])];
  return fallback;
}

function minutesFromTime(value: string): number {
  const [h, m] = value.split(':').map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
  return h * 60 + m;
}

function formatHoursLabel(minutes: number): string {
  const hrs = Math.round((minutes / 60) * 10) / 10;
  return Number.isInteger(hrs) ? `${hrs}` : `${hrs}`;
}

function isScheduleOpenNow(schedule: AvailabilitySchedule, now = new Date()): boolean {
  const dayKey = JS_DAY_KEYS[now.getDay()];
  const day = schedule[dayKey];
  if (!day?.enabled) return false;
  const open = minutesFromTime(day.startTime);
  const close = minutesFromTime(day.endTime);
  if (close <= open) return false;
  const minutesNow = now.getHours() * 60 + now.getMinutes();
  return minutesNow >= open && minutesNow < close;
}

function todayKey(now = new Date()): DayKey {
  return JS_DAY_KEYS[now.getDay()];
}

export default function WorkingHours() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const gradientBg = twoStopGradient(theme?.background, VALETER_BG_FALLBACK);
  const accent = theme?.primary ?? theme?.accent ?? SKY;
  const gold = theme?.accentAlt ?? '#E8C547';
  const textPrimary = theme?.textPrimary ?? '#F9FAFB';
  const textSecondary = theme?.textSecondary ?? 'rgba(249,250,251,0.85)';
  const textMuted = theme?.textOnBackground ?? 'rgba(249,250,251,0.55)';
  const surface = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const panel = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const border = isLight ? theme?.glassBorder ?? 'rgba(158,201,224,0.42)' : 'rgba(255,255,255,0.12)';

  const [loading, setLoading] = useState(true);
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);
  const [saving, setSaving] = useState(false);
  const [timePickerTarget, setTimePickerTarget] = useState<TimePickerTarget>(null);
  const [calendarSyncEnabled, setCalendarSyncEnabled] = useState(true);
  const [calendarReminderMinutes, setCalendarReminderMinutes] = useState<number[]>([30, 10]);
  const [selectedDay, setSelectedDay] = useState<DayKey>(todayKey());
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [nowTick, setNowTick] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNowTick(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (user?.id) {
      void loadAvailabilitySchedule();
      void (async () => {
        const settings = await loadCalendarSyncSettings(user.id);
        setCalendarSyncEnabled(settings.enabled);
        setCalendarReminderMinutes(settings.reminderMinutes);
      })();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data: profile, error } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();
      if (error) throw error;
      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    } finally {
      setLoading(false);
    }
  };

  const persistSchedule = useCallback(
    async (newSchedule: AvailabilitySchedule) => {
      if (!user?.id) return;
      setSaving(true);
      try {
        const { error } = await supabase
          .from('valeter_profiles')
          .update({ availability_schedule: newSchedule })
          .eq('user_id', user.id);
        if (error) throw error;
        try {
          await supabase.rpc('update_my_presence', {
            p_is_online: isScheduleOpenNow(newSchedule),
          });
        } catch (presenceError) {
          console.warn('[WorkingHours] presence sync error:', presenceError);
        }
      } catch (e) {
        console.error('Error saving schedule:', e);
      } finally {
        setSaving(false);
      }
    },
    [user?.id]
  );

  const weekStats = useMemo(() => {
    let daysOn = 0;
    let minutes = 0;
    DAYS_ORDER.forEach((d) => {
      const day = availabilitySchedule[d];
      if (!day.enabled) return;
      daysOn += 1;
      const span = minutesFromTime(day.endTime) - minutesFromTime(day.startTime);
      if (span > 0) minutes += span;
    });
    return { daysOn, hours: formatHoursLabel(minutes) };
  }, [availabilitySchedule]);

  const today = todayKey(nowTick);
  const todaySchedule = availabilitySchedule[today];
  const openNow = isScheduleOpenNow(availabilitySchedule, nowTick);
  const selected = availabilitySchedule[selectedDay];

  const liveStatus = useMemo(() => {
    if (!todaySchedule.enabled) return { title: 'Off today', body: 'You’re marked unavailable for new jobs today.' };
    if (openNow) return { title: 'Open now', body: `Accepting jobs until ${todaySchedule.endTime}` };
    const nowMins = nowTick.getHours() * 60 + nowTick.getMinutes();
    const open = minutesFromTime(todaySchedule.startTime);
    if (nowMins < open) return { title: 'Opens later', body: `Today’s window is ${todaySchedule.startTime}–${todaySchedule.endTime}` };
    return { title: 'Closed for today', body: `You were available ${todaySchedule.startTime}–${todaySchedule.endTime}` };
  }, [todaySchedule, openNow, nowTick]);

  const handleDayToggle = async (day: DayKey) => {
    await hapticFeedback('light');
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    const newSchedule = {
      ...availabilitySchedule,
      [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
    };
    setAvailabilitySchedule(newSchedule);
    setSelectedDay(day);
    void persistSchedule(newSchedule);
  };

  const selectDay = async (day: DayKey) => {
    await hapticFeedback('light');
    setSelectedDay(day);
  };

  const parseTimeToDate = (value: string) => {
    const [h, m] = value.split(':').map(Number);
    const date = new Date();
    date.setHours(Number.isFinite(h) ? h : 0, Number.isFinite(m) ? m : 0, 0, 0);
    return date;
  };

  const formatTime = (date: Date) => {
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
  };

  const openTimePicker = (day: DayKey, field: 'startTime' | 'endTime') => {
    void hapticFeedback('light');
    setTimePickerTarget({ day, field });
  };

  const closeTimePicker = () => setTimePickerTarget(null);

  const handleTimeSelected = (date: Date) => {
    if (!timePickerTarget) return;
    const { day, field } = timePickerTarget;
    const nextValue = formatTime(date);
    const newSchedule = {
      ...availabilitySchedule,
      [day]: { ...availabilitySchedule[day], [field]: nextValue },
    };
    setAvailabilitySchedule(newSchedule);
    void persistSchedule(newSchedule);
  };

  const pickerCardBg = theme?.navBarBottomDark ?? theme?.cardBackground ?? theme?.background?.[1] ?? '#0C2744';

  const saveCalendarSettings = useCallback(
    async (enabled: boolean, reminderMinutes: number[]) => {
      if (!user?.id) return;
      await saveCalendarSyncSettings(user.id, { enabled, reminderMinutes });
    },
    [user?.id]
  );

  const toggleCalendarSync = async (next: boolean) => {
    await hapticFeedback('light');
    setCalendarSyncEnabled(next);
    await saveCalendarSettings(next, calendarReminderMinutes);
  };

  const toggleReminderOption = async (minutes: number) => {
    await hapticFeedback('light');
    const has = calendarReminderMinutes.includes(minutes);
    const next = has
      ? calendarReminderMinutes.filter((m) => m !== minutes)
      : [...calendarReminderMinutes, minutes].sort((a, b) => b - a);
    if (next.length === 0) return;
    setCalendarReminderMinutes(next);
    await saveCalendarSettings(calendarSyncEnabled, next);
  };

  const applyPreset = async (id: (typeof PRESETS)[number]['id']) => {
    await hapticFeedback('medium');
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    const next = { ...availabilitySchedule };

    if (id === 'weekdays') {
      (['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] as const).forEach((d) => {
        next[d] = { enabled: true, startTime: '08:00', endTime: '18:00' };
      });
      next.saturday = { ...next.saturday, enabled: false };
      next.sunday = { ...next.sunday, enabled: false };
    } else if (id === 'weekends') {
      next.saturday = { enabled: true, startTime: '09:00', endTime: '17:00' };
      next.sunday = { enabled: true, startTime: '09:00', endTime: '17:00' };
    } else if (id === 'late') {
      DAYS_ORDER.forEach((d) => {
        if (d === 'sunday') next[d] = { enabled: false, startTime: '10:00', endTime: '20:00' };
        else next[d] = { enabled: true, startTime: '10:00', endTime: '20:00' };
      });
    } else if (id === 'full') {
      DAYS_ORDER.forEach((d) => {
        next[d] = { enabled: true, startTime: '08:00', endTime: '18:00' };
      });
    }

    setAvailabilitySchedule(next);
    void persistSchedule(next);
  };

  const copySelectedToWeekdays = async () => {
    await hapticFeedback('medium');
    const source = availabilitySchedule[selectedDay];
    const next = { ...availabilitySchedule };
    (['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] as const).forEach((d) => {
      next[d] = { ...source };
    });
    setAvailabilitySchedule(next);
    void persistSchedule(next);
  };

  const rangePct = useMemo(() => {
    if (!selected.enabled) return { start: 0, width: 0 };
    const start = minutesFromTime(selected.startTime);
    const end = minutesFromTime(selected.endTime);
    const dayStart = 6 * 60;
    const dayEnd = 22 * 60;
    const span = dayEnd - dayStart;
    const left = Math.max(0, Math.min(1, (start - dayStart) / span));
    const right = Math.max(0, Math.min(1, (end - dayStart) / span));
    return { start: left * 100, width: Math.max(4, (right - left) * 100) };
  }, [selected]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ValeterScreenHeader title="Working hours" />
        <LoadingScreen message="Loading schedule…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ValeterScreenHeader title="Working hours" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET + 8,
          paddingBottom: insets.bottom + VALETER_CONTENT_BOTTOM_PAD + 24,
          paddingHorizontal: 20,
          gap: 14,
        }}
      >
        <View
          style={[
            styles.statusCard,
            {
              backgroundColor: surface,
              borderColor: openNow ? `${accent}66` : border,
            },
          ]}
        >
          <View style={styles.statusTop}>
            <View style={[styles.liveDot, { backgroundColor: openNow ? '#34D399' : textMuted }]} />
            <Text style={[styles.statusTitle, { color: textPrimary }]}>{liveStatus.title}</Text>
            {saving ? <Text style={[styles.savingPill, { color: gold }]}>Saving…</Text> : null}
          </View>
          <Text style={[styles.statusBody, { color: textMuted }]}>{liveStatus.body}</Text>
          <Text style={[styles.weekMeta, { color: textSecondary }]}>
            {weekStats.daysOn} day{weekStats.daysOn === 1 ? '' : 's'} · ~{weekStats.hours} hrs this week
          </Text>
        </View>

        <Text style={[styles.sectionEyebrow, { color: gold }]}>YOUR WEEK</Text>
        <View style={styles.weekStrip}>
          {DAYS_ORDER.map((day) => {
            const on = availabilitySchedule[day].enabled;
            const isSelected = selectedDay === day;
            const isToday = day === today;
            return (
              <Pressable
                key={day}
                onPress={() => selectDay(day)}
                onLongPress={() => handleDayToggle(day)}
                style={[
                  styles.dayPill,
                  {
                    backgroundColor: isSelected ? `${accent}30` : panel,
                    borderColor: isSelected ? accent : on ? `${gold}55` : border,
                  },
                ]}
              >
                {isToday ? <View style={[styles.todayDot, { backgroundColor: gold }]} /> : null}
                <Text style={[styles.dayPillShort, { color: isSelected || on ? textPrimary : textMuted }]}>
                  {DAY_SHORT[day]}
                </Text>
                <Text style={[styles.dayPillState, { color: on ? accent : textMuted }]}>{on ? 'On' : 'Off'}</Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={[styles.hint, { color: textMuted }]}>Tap a day to edit · hold to toggle on/off</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.presetRow}>
          {PRESETS.map((preset) => (
            <TouchableOpacity
              key={preset.id}
              style={[styles.presetChip, { backgroundColor: panel, borderColor: border }]}
              onPress={() => applyPreset(preset.id)}
              activeOpacity={0.85}
            >
              <Ionicons name={preset.icon} size={14} color={accent} />
              <View>
                <Text style={[styles.presetLabel, { color: textPrimary }]}>{preset.label}</Text>
                <Text style={[styles.presetHint, { color: textMuted }]}>{preset.hint}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={[styles.editorCard, { backgroundColor: surface, borderColor: border }]}>
          <View style={styles.editorHeader}>
            <View>
              <Text style={[styles.editorDay, { color: textPrimary }]}>{DAY_LABELS[selectedDay]}</Text>
              <Text style={[styles.editorSub, { color: textMuted }]}>
                {selected.enabled ? `${selected.startTime} – ${selected.endTime}` : 'Day off'}
              </Text>
            </View>
            <Switch
              value={selected.enabled}
              onValueChange={() => handleDayToggle(selectedDay)}
              trackColor={{ false: 'rgba(255,255,255,0.2)', true: accent }}
              thumbColor="#FFFFFF"
              ios_backgroundColor="rgba(255,255,255,0.2)"
            />
          </View>

          {selected.enabled ? (
            <>
              <View style={[styles.rangeTrack, { backgroundColor: 'rgba(255,255,255,0.08)' }]}>
                <View
                  style={[
                    styles.rangeFill,
                    {
                      left: `${rangePct.start}%`,
                      width: `${rangePct.width}%`,
                      backgroundColor: accent,
                    },
                  ]}
                />
              </View>
              <View style={styles.rangeLabels}>
                <Text style={[styles.rangeLabel, { color: textMuted }]}>06:00</Text>
                <Text style={[styles.rangeLabel, { color: textMuted }]}>22:00</Text>
              </View>

              <View style={styles.timeRow}>
                <Pressable
                  onPress={() => openTimePicker(selectedDay, 'startTime')}
                  style={({ pressed }) => [
                    styles.timeChip,
                    { borderColor: `${accent}55`, backgroundColor: panel, opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={[styles.timeChipLabel, { color: textMuted }]}>Start</Text>
                  <Text style={[styles.timeChipValue, { color: textPrimary }]}>{selected.startTime}</Text>
                </Pressable>
                <Text style={[styles.timeDash, { color: textMuted }]}>→</Text>
                <Pressable
                  onPress={() => openTimePicker(selectedDay, 'endTime')}
                  style={({ pressed }) => [
                    styles.timeChip,
                    { borderColor: `${accent}55`, backgroundColor: panel, opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={[styles.timeChipLabel, { color: textMuted }]}>End</Text>
                  <Text style={[styles.timeChipValue, { color: textPrimary }]}>{selected.endTime}</Text>
                </Pressable>
              </View>

              <TouchableOpacity style={styles.copyBtn} onPress={copySelectedToWeekdays} activeOpacity={0.85}>
                <Ionicons name="copy-outline" size={16} color={gold} />
                <Text style={[styles.copyBtnText, { color: gold }]}>Copy these hours to weekdays</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Text style={[styles.offCopy, { color: textMuted }]}>
              Turn this day on to set when you’re available for jobs.
            </Text>
          )}
        </View>

        <TouchableOpacity
          style={[styles.detailsToggle, { borderColor: border, backgroundColor: panel }]}
          onPress={() => {
            LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            setCalendarOpen((v) => !v);
          }}
          activeOpacity={0.85}
        >
          <Text style={[styles.detailsToggleText, { color: textPrimary }]}>Phone calendar</Text>
          <Ionicons name={calendarOpen ? 'chevron-up' : 'chevron-down'} size={18} color={accent} />
        </TouchableOpacity>

        {calendarOpen ? (
          <View style={[styles.syncCard, { backgroundColor: surface, borderColor: border }]}>
            <View style={styles.syncHeaderRow}>
              <View style={styles.syncTitleWrap}>
                <Text style={[styles.syncTitle, { color: textPrimary }]}>Sync booked jobs</Text>
                <Text style={[styles.syncSub, { color: textMuted }]}>
                  Keep Wish a Washer jobs on your phone calendar automatically.
                </Text>
              </View>
              <Switch
                value={calendarSyncEnabled}
                onValueChange={toggleCalendarSync}
                trackColor={{ false: 'rgba(255,255,255,0.2)', true: accent }}
                thumbColor="#FFFFFF"
                ios_backgroundColor="rgba(255,255,255,0.2)"
              />
            </View>
            <Text style={[styles.reminderLabel, { color: textMuted }]}>Reminders before booking</Text>
            <View style={styles.reminderChips}>
              {REMINDER_OPTIONS.map((minutes) => {
                const selectedRem = calendarReminderMinutes.includes(minutes);
                return (
                  <Pressable
                    key={minutes}
                    onPress={() => toggleReminderOption(minutes)}
                    style={[
                      styles.reminderChip,
                      {
                        borderColor: selectedRem ? `${accent}95` : border,
                        backgroundColor: selectedRem ? `${accent}26` : panel,
                        opacity: calendarSyncEnabled ? 1 : 0.45,
                      },
                    ]}
                    disabled={!calendarSyncEnabled}
                  >
                    <Text style={[styles.reminderChipText, { color: selectedRem ? textPrimary : textMuted }]}>
                      {minutes}m
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}
      </ScrollView>

      {timePickerTarget && (
        <>
          {Platform.OS === 'ios' ? (
            <Modal transparent animationType="fade" visible onRequestClose={closeTimePicker}>
              <View style={styles.pickerOverlay}>
                <View style={[styles.pickerCard, { backgroundColor: pickerCardBg }]}>
                  <View style={styles.pickerHeader}>
                    <Pressable onPress={closeTimePicker} style={styles.pickerHeaderBtn}>
                      <Text style={[styles.pickerHeaderBtnText, { color: textSecondary }]}>Cancel</Text>
                    </Pressable>
                    <Text style={[styles.pickerTitle, { color: textPrimary }]}>Select time</Text>
                    <Pressable onPress={closeTimePicker} style={styles.pickerHeaderBtn}>
                      <Text style={[styles.pickerHeaderBtnText, { color: accent }]}>Done</Text>
                    </Pressable>
                  </View>
                  <DateTimePicker
                    value={parseTimeToDate(availabilitySchedule[timePickerTarget.day][timePickerTarget.field])}
                    mode="time"
                    display="spinner"
                    is24Hour
                    themeVariant="dark"
                    onChange={(_, selectedDate) => {
                      if (selectedDate) handleTimeSelected(selectedDate);
                    }}
                  />
                </View>
              </View>
            </Modal>
          ) : (
            <DateTimePicker
              value={parseTimeToDate(availabilitySchedule[timePickerTarget.day][timePickerTarget.field])}
              mode="time"
              display="default"
              is24Hour
              onChange={(event, selectedDate) => {
                if (event.type === 'dismissed') {
                  closeTimePicker();
                  return;
                }
                if (selectedDate) handleTimeSelected(selectedDate);
                closeTimePicker();
              }}
            />
          )}
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  statusCard: {
    borderRadius: 22,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 6,
  },
  statusTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  savingPill: {
    fontSize: 11,
    fontWeight: '800',
  },
  statusBody: {
    fontSize: 13,
    lineHeight: 19,
  },
  weekMeta: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '700',
  },
  sectionEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
    marginTop: 4,
  },
  weekStrip: {
    flexDirection: 'row',
    gap: 6,
  },
  dayPill: {
    flex: 1,
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 10,
    gap: 4,
  },
  todayDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    marginBottom: -2,
  },
  dayPillShort: {
    fontSize: 11,
    fontWeight: '800',
  },
  dayPillState: {
    fontSize: 10,
    fontWeight: '700',
  },
  hint: {
    fontSize: 11,
    marginTop: -4,
  },
  presetRow: {
    gap: 8,
    paddingVertical: 2,
  },
  presetChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    minWidth: 110,
  },
  presetLabel: {
    fontSize: 12,
    fontWeight: '800',
  },
  presetHint: {
    fontSize: 10,
    fontWeight: '600',
  },
  editorCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 16,
    gap: 14,
  },
  editorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  editorDay: {
    fontSize: 18,
    fontWeight: '900',
  },
  editorSub: {
    marginTop: 2,
    fontSize: 13,
    fontWeight: '600',
  },
  rangeTrack: {
    height: 10,
    borderRadius: 5,
    overflow: 'hidden',
    position: 'relative',
  },
  rangeFill: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    borderRadius: 5,
    opacity: 0.85,
  },
  rangeLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -6,
  },
  rangeLabel: {
    fontSize: 10,
    fontWeight: '700',
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  timeChip: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  timeChipLabel: {
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 2,
  },
  timeChipValue: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  timeDash: {
    fontSize: 16,
    fontWeight: '700',
  },
  copyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 4,
  },
  copyBtnText: {
    fontSize: 13,
    fontWeight: '700',
  },
  offCopy: {
    fontSize: 13,
    lineHeight: 19,
  },
  detailsToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  detailsToggleText: {
    fontSize: 14,
    fontWeight: '700',
  },
  syncCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
  },
  syncHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  syncTitleWrap: { flex: 1 },
  syncTitle: {
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 3,
  },
  syncSub: {
    fontSize: 12,
    lineHeight: 17,
  },
  reminderLabel: {
    marginTop: 12,
    marginBottom: 8,
    fontSize: 12,
    fontWeight: '600',
  },
  reminderChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  reminderChip: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  reminderChipText: {
    fontSize: 12,
    fontWeight: '700',
  },
  pickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  pickerCard: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingBottom: 20,
  },
  pickerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingTop: 12,
  },
  pickerHeaderBtn: {
    paddingVertical: 8,
    minWidth: 54,
  },
  pickerHeaderBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
  pickerTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
});
