import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Animated,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import MapView, { Circle, Region } from 'react-native-maps';
import Slider from '@react-native-community/slider';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { supabase } from '../../../src/lib/supabase';
import { fetchRadiusPreference, RadiusColumn } from '../../../src/utils/radiusPreference';
import ValeterScreenHeader, {
  HEADER_HEIGHT,
} from '../../../src/components/valeter/ValeterScreenHeader';
import ValeterDashboardChrome from '../../../src/components/valeter/ValeterDashboardChrome';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { lightMistElevated, lightMistPanel } from '../../../src/constants/accountThemes';
import { colors } from '../../../src/constants/colors';
import LoadingScreen from '../../../src/components/LoadingScreen';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';
import {
  DARK_MAP_STYLE,
  DEFAULT_MAP_REGION,
  MAP_CAMERA_ANIMATION_DURATION,
  MAP_LOCKED_DARK,
} from '../../../src/constants/mapConstants';

const SKY = colors.SKY ?? '#87CEEB';
const MI_TO_M = 1609.34;
const MIN_RADIUS_MI = 5;
const MAX_RADIUS_MI = 100;
/** Fallback until sheet onLayout measures — keeps map above sheet on first paint. */
const SHEET_HEIGHT_FALLBACK = 420;
const RADIUS_OPTIONS = [5, 10, 15, 20, 25, 30, 40, 50, 75, 100] as const;
const PRESETS = [
  { label: 'Local', miles: 10 },
  { label: 'Metro', miles: 25 },
  { label: 'Regional', miles: 50 },
  { label: 'Max', miles: 100 },
] as const;

function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 3958.8;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function nearestOption(value: number): number {
  const clamped = Math.min(MAX_RADIUS_MI, Math.max(MIN_RADIUS_MI, value));
  return RADIUS_OPTIONS.reduce((best, option) =>
    Math.abs(option - clamped) < Math.abs(best - clamped) ? option : best
  );
}

function regionForRadius(lat: number, lng: number, radiusMi: number): Region {
  const pad = 2.35;
  const latDelta = Math.max((radiusMi * 2 * pad) / 69, 0.06);
  const lngDelta = latDelta / Math.max(Math.cos((lat * Math.PI) / 180), 0.2);
  return {
    latitude: lat,
    longitude: lng,
    latitudeDelta: latDelta,
    longitudeDelta: lngDelta,
  };
}

function getRadiusDescription(radius: number) {
  if (radius <= 5) return 'Neighbourhood — short hops only';
  if (radius <= 10) return 'Local district — city core';
  if (radius <= 15) return 'Extended city coverage';
  if (radius <= 20) return 'Metro fringe — more job volume';
  if (radius <= 30) return 'Wide metro — high demand reach';
  if (radius <= 50) return 'Regional — town-to-town runs';
  if (radius <= 75) return 'Long-range — serious travel time';
  return 'Maximum reach — up to 100 miles';
}

function estimateDriveMinutes(radiusMi: number) {
  // Rough edge-of-circle drive at ~28 mph average urban/highway mix
  return Math.max(8, Math.round((radiusMi / 28) * 60));
}

function demandLabel(count: number | null, loading: boolean) {
  if (loading) return 'Scanning demand…';
  if (count == null) return 'Demand unavailable';
  if (count === 0) return 'Quiet in this ring right now';
  if (count === 1) return '~1 open job in range';
  return `~${count} open jobs in range`;
}

export default function DistanceCovering() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme, mode } = useAccountTheme();
  const isLight = mode === 'light';
  const primaryAccent = theme.primary || SKY;
  const gold = theme.accentAlt || '#E8C547';
  const sheetGradient = (theme.headerBackground || theme.background || ['#0B1F36', '#071525']) as [
    string,
    string,
  ];
  const sheetSurface = isLight ? lightMistElevated : 'rgba(255,255,255,0.06)';
  const sheetChip = isLight ? lightMistPanel : 'rgba(255,255,255,0.05)';
  const sheetBorder = isLight
    ? theme.glassBorder || 'rgba(158,201,224,0.42)'
    : `${primaryAccent}55`;
  const mutedText = theme.textOnBackground || 'rgba(248,250,252,0.66)';
  const secondaryText = theme.textSecondary || 'rgba(248,250,252,0.78)';
  const primaryText = theme.textPrimary || '#F8FAFC';

  const mapRef = useRef<MapView | null>(null);
  const lastHapticPreset = useRef<number | null>(null);
  const pulse = useRef(new Animated.Value(0)).current;
  const sheetIn = useRef(new Animated.Value(0)).current;

  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRadius, setIsLoadingRadius] = useState(true);
  const [radiusColumn, setRadiusColumn] = useState<RadiusColumn>('working_radius');
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [jobsInRange, setJobsInRange] = useState<number | null>(null);
  const [jobsLoading, setJobsLoading] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [sheetHeight, setSheetHeight] = useState(SHEET_HEIGHT_FALLBACK);

  const headerPad = insets.top + HEADER_HEIGHT;
  const mapPadding = useMemo(
    () => ({ top: headerPad + 8, right: 16, bottom: 16, left: 16 }),
    [headerPad]
  );

  const circleCenter = coords ?? {
    latitude: DEFAULT_MAP_REGION.latitude,
    longitude: DEFAULT_MAP_REGION.longitude,
  };

  const fitMapToRadius = useCallback(
    (radiusMi: number, animated = true) => {
      if (!mapRef.current || !coords) return;
      const region = regionForRadius(coords.latitude, coords.longitude, radiusMi);
      if (animated) {
        mapRef.current.animateToRegion(region, MAP_CAMERA_ANIMATION_DURATION);
      } else {
        mapRef.current.animateToRegion(region, 0);
      }
    },
    [coords]
  );

  const loadLocation = useCallback(async () => {
    try {
      if (user?.id) {
        const { data: presence } = await supabase
          .from('valeter_presence')
          .select('last_lat, last_lng')
          .eq('user_id', user.id)
          .maybeSingle();
        if (presence?.last_lat != null && presence?.last_lng != null) {
          setCoords({
            latitude: Number(presence.last_lat),
            longitude: Number(presence.last_lng),
          });
          return;
        }
      }

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;

      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setCoords({
        latitude: Number(loc.coords.latitude.toFixed(6)),
        longitude: Number(loc.coords.longitude.toFixed(6)),
      });
    } catch (error) {
      console.warn('[distance-covering] location error', error);
    }
  }, [user?.id]);

  const loadJobsInRange = useCallback(
    async (radiusMi: number, center: { latitude: number; longitude: number } | null) => {
      if (!center) {
        setJobsInRange(null);
        return;
      }
      try {
        setJobsLoading(true);
        const { data: bookings } = await supabase
          .from('bookings')
          .select('id, location_lat, location_lng')
          .in('status', ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'scheduled'])
          .not('location_lat', 'is', null)
          .not('location_lng', 'is', null)
          .limit(200);

        const count = (bookings || []).filter((b: any) => {
          if (b.location_lat == null || b.location_lng == null) return false;
          return (
            haversineMi(center.latitude, center.longitude, Number(b.location_lat), Number(b.location_lng)) <=
            radiusMi
          );
        }).length;
        setJobsInRange(count);
      } catch {
        setJobsInRange(null);
      } finally {
        setJobsLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!user?.id) {
        setIsLoadingRadius(false);
        return;
      }
      try {
        setIsLoadingRadius(true);
        const { value, column } = await fetchRadiusPreference(user.id);
        if (!mounted) return;
        setRadiusColumn(column);
        setSelectedRadius(nearestOption(typeof value === 'number' ? value : 10));
      } catch (error) {
        console.error('Error loading radius:', error);
      } finally {
        if (mounted) setIsLoadingRadius(false);
      }
    })();
    loadLocation();
    Animated.timing(sheetIn, {
      toValue: 1,
      duration: 420,
      useNativeDriver: true,
    }).start();
    return () => {
      mounted = false;
    };
  }, [user?.id, loadLocation, sheetIn]);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1600, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 1600, useNativeDriver: true }),
      ])
    ).start();
  }, [pulse]);

  useEffect(() => {
    if (!mapReady || !coords) return;
    fitMapToRadius(selectedRadius, true);
  }, [selectedRadius, coords, mapReady, sheetHeight, fitMapToRadius]);

  useEffect(() => {
    const handle = setTimeout(() => {
      loadJobsInRange(selectedRadius, coords);
    }, 280);
    return () => clearTimeout(handle);
  }, [selectedRadius, coords, loadJobsInRange]);

  const handleRadiusChange = (value: number, withHaptic = false) => {
    const next = Math.min(MAX_RADIUS_MI, Math.max(MIN_RADIUS_MI, Math.round(value)));
    if (withHaptic || RADIUS_OPTIONS.includes(next as (typeof RADIUS_OPTIONS)[number])) {
      if (lastHapticPreset.current !== next) {
        lastHapticPreset.current = next;
        hapticFeedback('light');
      }
    }
    setSelectedRadius(next);
  };

  const handlePreset = (miles: number) => {
    lastHapticPreset.current = miles;
    hapticFeedback('medium');
    setSelectedRadius(miles);
  };

  const handleSaveRadius = async () => {
    if (!user?.id) {
      Alert.alert('Error', 'Please sign in to update your settings.');
      return;
    }

    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      const buildPayload = (column: RadiusColumn) => ({
        [column]: Math.round(selectedRadius),
      });

      let error: any;

      if (existingProfile) {
        const { error: updateError } = await supabase
          .from('valeter_profiles')
          .update(buildPayload(radiusColumn))
          .eq('user_id', user.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, ...buildPayload(radiusColumn), is_online: false });
        error = insertError;
      }

      if (error && error.code === '42703' && radiusColumn === 'working_radius') {
        setRadiusColumn('radius_coverage');
        const fallbackPayload = buildPayload('radius_coverage');

        if (existingProfile) {
          const { error: legacyUpdateError } = await supabase
            .from('valeter_profiles')
            .update(fallbackPayload)
            .eq('user_id', user.id);
          error = legacyUpdateError;
        } else {
          const { error: legacyInsertError } = await supabase
            .from('valeter_profiles')
            .insert({ user_id: user.id, ...fallbackPayload, is_online: false });
          error = legacyInsertError;
        }
      }

      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        Alert.alert(
          'Database Migration Required',
          `Some columns need to be added. Please run this SQL in Supabase:

ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS working_radius INTEGER DEFAULT 10;
ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS availability_schedule JSONB;

Your notification preferences are saved locally on this device.`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      if (error) throw error;

      Alert.alert('Territory updated', `You're covering ${Math.round(selectedRadius)} miles.`, [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', error.message || 'Failed to save settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const driveMinutes = useMemo(() => estimateDriveMinutes(selectedRadius), [selectedRadius]);
  const sheetTranslate = sheetIn.interpolate({
    inputRange: [0, 1],
    outputRange: [40, 0],
  });

  if (isLoadingRadius) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={[StyleSheet.absoluteFill, { backgroundColor: '#0B1724' }]} />
        <ValeterScreenHeader title="Working radius" />
        <LoadingScreen message="Loading…" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <MapView
        ref={mapRef}
        style={[styles.map, { bottom: sheetHeight }]}
        initialRegion={
          coords
            ? regionForRadius(coords.latitude, coords.longitude, selectedRadius)
            : DEFAULT_MAP_REGION
        }
        mapPadding={mapPadding}
        customMapStyle={DARK_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        showsUserLocation={!!coords}
        showsMyLocationButton={false}
        showsCompass={false}
        rotateEnabled={false}
        pitchEnabled={false}
        onMapReady={() => setMapReady(true)}
      >
        <Circle
          center={circleCenter}
          radius={selectedRadius * MI_TO_M}
          strokeColor={primaryAccent}
          strokeWidth={2.5}
          fillColor={`${primaryAccent}33`}
        />
      </MapView>

      <View pointerEvents="none" style={[styles.mapScrim, { bottom: sheetHeight }]} />

      <ValeterScreenHeader title="Working radius" />

      <Animated.View
        style={[
          styles.sheet,
          {
            paddingBottom: Math.max(16, insets.bottom + 12),
            opacity: sheetIn,
            transform: [{ translateY: sheetTranslate }],
          },
        ]}
        onLayout={(e) => {
          const h = Math.ceil(e.nativeEvent.layout.height);
          if (h > 0 && Math.abs(h - sheetHeight) > 2) {
            setSheetHeight(h);
          }
        }}
      >
        <ValeterDashboardChrome accent={primaryAccent} headerGradient={sheetGradient} />
        <View style={[styles.sheetBorder, { borderColor: sheetBorder }]} />

        <View style={[styles.sheetHandle, isLight && { backgroundColor: 'rgba(248,250,252,0.42)' }]} />

        <View
          style={[
            styles.radiusBox,
            {
              borderColor: isLight ? theme.glassBorderAlt || `${gold}66` : `${gold}66`,
              backgroundColor: sheetSurface,
            },
          ]}
        >
          <Animated.View
            style={[
              styles.radiusBoxPulse,
              {
                borderColor: gold,
                opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.12, 0.4] }),
                transform: [
                  {
                    scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.015] }),
                  },
                ],
              },
            ]}
          />
          <Text style={[styles.radiusBoxEyebrow, { color: mutedText }]}>YOUR TERRITORY</Text>
          <Text style={[styles.radiusBoxValue, { color: gold }]}>
            {selectedRadius}
            <Text style={[styles.radiusBoxUnit, { color: secondaryText }]}> miles</Text>
          </Text>
          <Text style={[styles.radiusDesc, { color: secondaryText }]}>
            {getRadiusDescription(selectedRadius)}
          </Text>
        </View>

        <View style={styles.statsRow}>
          <View
            style={[
              styles.statPill,
              {
                borderColor: isLight ? `${primaryAccent}55` : `${primaryAccent}44`,
                backgroundColor: sheetSurface,
              },
            ]}
          >
            <Text style={[styles.statValue, { color: primaryAccent }]}>
              {jobsLoading ? '…' : jobsInRange == null ? '—' : jobsInRange}
            </Text>
            <Text style={[styles.statLabel, { color: mutedText }]}>
              {demandLabel(jobsInRange, jobsLoading)}
            </Text>
          </View>
          <View
            style={[
              styles.statPill,
              {
                borderColor: isLight ? `${gold}55` : `${gold}44`,
                backgroundColor: sheetSurface,
              },
            ]}
          >
            <Text style={[styles.statValue, { color: gold }]}>~{driveMinutes}m</Text>
            <Text style={[styles.statLabel, { color: mutedText }]}>Est. drive to the edge</Text>
          </View>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.presetRow}
        >
          {PRESETS.map((preset) => {
            const active = selectedRadius === preset.miles;
            return (
              <TouchableOpacity
                key={preset.label}
                onPress={() => handlePreset(preset.miles)}
                activeOpacity={0.85}
                style={[
                  styles.presetChip,
                  {
                    backgroundColor: sheetChip,
                    borderColor: isLight ? 'rgba(158,201,224,0.34)' : 'rgba(255,255,255,0.14)',
                  },
                  active && {
                    backgroundColor: isLight ? `${primaryAccent}32` : `${primaryAccent}28`,
                    borderColor: primaryAccent,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.presetLabel,
                    { color: secondaryText },
                    active && { color: primaryText },
                  ]}
                >
                  {preset.label}
                </Text>
                <Text
                  style={[
                    styles.presetMiles,
                    { color: mutedText },
                    active && { color: primaryAccent },
                  ]}
                >
                  {preset.miles} mi
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        <View style={styles.sliderBlock}>
          <Slider
            style={styles.slider}
            minimumValue={MIN_RADIUS_MI}
            maximumValue={MAX_RADIUS_MI}
            step={1}
            value={selectedRadius}
            onValueChange={(v) => handleRadiusChange(v)}
            onSlidingComplete={(v) => {
              const snapped = nearestOption(v);
              handleRadiusChange(snapped, true);
              hapticFeedback('medium');
            }}
            minimumTrackTintColor={primaryAccent}
            maximumTrackTintColor={isLight ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.16)'}
            thumbTintColor={primaryAccent}
          />
          <View style={styles.sliderEnds}>
            <Text style={[styles.sliderEnd, { color: mutedText }]}>{MIN_RADIUS_MI} mi</Text>
            <Text style={[styles.sliderHint, { color: mutedText }]}>Drag to reshape your coverage</Text>
            <Text style={[styles.sliderEnd, { color: mutedText }]}>{MAX_RADIUS_MI} mi</Text>
          </View>
        </View>

        <ContinueCTAButton
          title="Save territory"
          onPress={handleSaveRadius}
          accentColor={primaryAccent}
          disabled={isLoading}
          loading={isLoading}
          style={styles.saveButton}
        />
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1724' },
  map: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  mapScrim: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(8,16,28,0.12)',
  },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  sheetBorder: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.28)',
    marginBottom: 12,
  },
  radiusBox: {
    position: 'relative',
    alignItems: 'center',
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 12,
  },
  radiusBoxPulse: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  radiusBoxEyebrow: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.4,
  },
  radiusBoxValue: {
    marginTop: 2,
    fontSize: 40,
    fontWeight: '900',
    letterSpacing: -1.2,
  },
  radiusBoxUnit: {
    fontSize: 16,
    fontWeight: '700',
  },
  radiusDesc: {
    marginTop: 6,
    fontSize: 13,
    lineHeight: 18,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 14,
  },
  statPill: {
    flex: 1,
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  statLabel: {
    marginTop: 2,
    fontSize: 11,
    lineHeight: 15,
  },
  presetRow: {
    gap: 8,
    paddingBottom: 4,
  },
  presetChip: {
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minWidth: 78,
  },
  presetLabel: {
    fontSize: 12,
    fontWeight: '800',
  },
  presetMiles: {
    marginTop: 2,
    fontSize: 11,
    fontWeight: '600',
  },
  sliderBlock: {
    marginTop: 10,
    marginBottom: 12,
  },
  slider: {
    width: '100%',
    height: 36,
  },
  sliderEnds: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  sliderEnd: {
    fontSize: 11,
    fontWeight: '700',
  },
  sliderHint: {
    fontSize: 11,
  },
  saveButton: {
    borderRadius: 20,
    minHeight: 52,
  },
});
