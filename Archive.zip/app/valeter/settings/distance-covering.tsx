import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Animated,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { supabase } from '../../../src/lib/supabase';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { fetchRadiusPreference, RadiusColumn } from '../../../src/utils/radiusPreference';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { colors } from '../../../src/constants/colors';
import LoadingScreen from '../../../src/components/LoadingScreen';
import ContinueCTAButton from '../../../src/components/ui/ContinueCTAButton';

const SKY = colors.SKY ?? '#87CEEB';
const VALETER_BG_FALLBACK: [string, string] = ['#0A1929', '#1E3A8A'];
const RADIUS_OPTIONS = [5, 10, 15, 20, 25, 30] as const;
const CARD_WIDTH = 248;
const CARD_GAP = 16;
const ITEM_SIZE = CARD_WIDTH + CARD_GAP;

export default function DistanceCovering() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { width: screenWidth } = useWindowDimensions();
  const { theme } = useAccountTheme();
  const gradientBg = (theme?.background || VALETER_BG_FALLBACK) as [string, string];
  const primaryAccent = theme.primary || SKY;

  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRadius, setIsLoadingRadius] = useState(true);
  const [radiusColumn, setRadiusColumn] = useState<RadiusColumn>('working_radius');
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scrollX = useRef(new Animated.Value(0)).current;
  const carouselRef = useRef<ScrollView>(null);

  useEffect(() => {
    loadCurrentRadius();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadCurrentRadius = async () => {
    if (!user?.id) return;

    try {
      setIsLoadingRadius(true);
      const { value, column } = await fetchRadiusPreference(user.id);
      setRadiusColumn(column);
      const nextRadius = typeof value === 'number' ? value : 10;
      setSelectedRadius(nextRadius);
      requestAnimationFrame(() => {
        const index = RADIUS_OPTIONS.indexOf(nextRadius as (typeof RADIUS_OPTIONS)[number]);
        if (index >= 0) {
          carouselRef.current?.scrollTo({ x: index * ITEM_SIZE, animated: false });
        }
      });
    } catch (error) {
      console.error('Error loading radius:', error);
    } finally {
      setIsLoadingRadius(false);
    }
  };

  const handleRadiusChange = (value: number, withHaptic = false) => {
    const next = Math.min(30, Math.max(5, value));
    if (withHaptic) hapticFeedback('light');
    setSelectedRadius(next);
  };

  const handleSaveRadius = async () => {
    if (!user?.id) {
      Alert.alert('Error', 'Please sign in to update your settings.');
      return;
    }

    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      const buildPayload = (column: RadiusColumn) => ({
        [column]: Math.round(selectedRadius),
      });

      let error: any;

      if (existingProfile) {
        const { error: updateError } = await supabase
          .from('valeter_profiles')
          .update(buildPayload(radiusColumn))
          .eq('user_id', user.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, ...buildPayload(radiusColumn), is_online: false });
        error = insertError;
      }

      if (error && error.code === '42703' && radiusColumn === 'working_radius') {
        setRadiusColumn('radius_coverage');
        const fallbackPayload = buildPayload('radius_coverage');

        if (existingProfile) {
          const { error: legacyUpdateError } = await supabase
            .from('valeter_profiles')
            .update(fallbackPayload)
            .eq('user_id', user.id);
          error = legacyUpdateError;
        } else {
          const { error: legacyInsertError } = await supabase
            .from('valeter_profiles')
            .insert({ user_id: user.id, ...fallbackPayload, is_online: false });
          error = legacyInsertError;
        }
      }

      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        Alert.alert(
          'Database Migration Required',
          `Some columns need to be added. Please run this SQL in Supabase:

ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS working_radius INTEGER DEFAULT 10;
ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS availability_schedule JSONB;

Your notification preferences are saved locally on this device.`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      if (error) throw error;

      Alert.alert('Settings Updated', 'Your settings have been saved successfully.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', error.message || 'Failed to save settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRadiusDescription = (radius: number) => {
    switch (Math.round(radius / 5) * 5) {
      case 5:
        return 'Perfect for local neighbourhood work';
      case 10:
        return 'Ideal for city district coverage';
      case 15:
        return 'Great for extended city areas';
      case 20:
        return 'Covers metropolitan areas';
      case 25:
        return 'Wide coverage for busy areas';
      case 30:
        return 'Maximum coverage for high-demand areas';
      default:
        return 'Select your preferred coverage area';
    }
  };

  if (isLoadingRadius) {
    return <LoadingScreen message="Loading…" />;
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <View style={styles.screen}>
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton} activeOpacity={0.75}>
            <Ionicons name="chevron-back" size={28} color="#F9FAFB" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Working radius</Text>
          <View style={styles.headerSpacer} />
        </View>

        <Animated.View style={[styles.body, { opacity: fadeAnim }]}>
          <View style={styles.content}>
            <View style={styles.carouselWrap}>
              <Animated.ScrollView
                ref={carouselRef}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={[
                  styles.carouselContent,
                  { paddingHorizontal: Math.max(14, (screenWidth - CARD_WIDTH) / 2) },
                ]}
                decelerationRate="fast"
                snapToInterval={ITEM_SIZE}
                snapToAlignment="start"
                disableIntervalMomentum
                onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], {
                  useNativeDriver: true,
                })}
                scrollEventThrottle={16}
                onMomentumScrollEnd={(event) => {
                  const index = Math.round(event.nativeEvent.contentOffset.x / ITEM_SIZE);
                  const radius = RADIUS_OPTIONS[Math.max(0, Math.min(RADIUS_OPTIONS.length - 1, index))];
                  if (radius !== selectedRadius) {
                    handleRadiusChange(radius);
                  }
                }}
              >
                {RADIUS_OPTIONS.map((radius, index) => {
                  const active = selectedRadius === radius;
                  const inputRange = [(index - 1) * ITEM_SIZE, index * ITEM_SIZE, (index + 1) * ITEM_SIZE];
                  const scale = scrollX.interpolate({
                    inputRange,
                    outputRange: [0.84, 1, 0.84],
                    extrapolate: 'clamp',
                  });
                  const opacity = scrollX.interpolate({
                    inputRange,
                    outputRange: [0.45, 1, 0.45],
                    extrapolate: 'clamp',
                  });
                  const translateY = scrollX.interpolate({
                    inputRange,
                    outputRange: [18, 0, 18],
                    extrapolate: 'clamp',
                  });
                  const rotateZ = scrollX.interpolate({
                    inputRange,
                    outputRange: ['-8deg', '0deg', '8deg'],
                    extrapolate: 'clamp',
                  });
                  return (
                    <Animated.View
                      key={radius}
                      style={[
                        styles.radiusCardShell,
                        {
                          opacity,
                          transform: [{ perspective: 1200 }, { scale }, { translateY }, { rotateZ }],
                        },
                      ]}
                    >
                      <TouchableOpacity
                        onPress={() => {
                          handleRadiusChange(radius, true);
                          carouselRef.current?.scrollTo({ x: index * ITEM_SIZE, animated: true });
                        }}
                        activeOpacity={0.88}
                        style={[
                          styles.radiusCard,
                          index === 0 && styles.radiusCardFirst,
                          index === RADIUS_OPTIONS.length - 1 && styles.radiusCardLast,
                          active && styles.radiusCardActive,
                        ]}
                      >
                        <Text style={[styles.radiusNumber, active && styles.radiusNumberActive]}>{radius}</Text>
                        <Text style={[styles.radiusLabel, active && styles.radiusLabelActive]}>Miles</Text>
                        <Text style={[styles.radiusCaption, active && styles.radiusCaptionActive]}>
                          {getRadiusDescription(radius)}
                        </Text>
                      </TouchableOpacity>
                    </Animated.View>
                  );
                })}
              </Animated.ScrollView>
            </View>

            <View style={styles.helperBlock}>
              <Text style={styles.helperTitle}>Choose how far you'll travel for jobs</Text>
              <Text style={styles.helperSubtitle}>Swipe to see more options</Text>
            </View>
          </View>

          <View style={[styles.saveWrap, { paddingBottom: Math.max(18, insets.bottom + 16) }]}>
            <ContinueCTAButton
              title="Save"
              onPress={handleSaveRadius}
              accentColor={primaryAccent}
              disabled={isLoading}
              loading={isLoading}
              style={styles.saveButton}
            />
          </View>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  screen: { flex: 1, paddingHorizontal: 20 },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    paddingBottom: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerSpacer: { width: 44, height: 44 },
  body: { flex: 1, paddingBottom: 8 },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  carouselWrap: {
    justifyContent: 'center',
  },
  carouselContent: {
    alignItems: 'center',
  },
  radiusCardShell: {
    width: CARD_WIDTH,
    marginRight: CARD_GAP,
  },
  radiusCard: {
    width: '100%',
    minHeight: 268,
    borderRadius: 30,
    paddingHorizontal: 22,
    paddingVertical: 26,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
  },
  radiusCardFirst: {
    marginLeft: 0,
  },
  radiusCardLast: {
    marginRight: 0,
  },
  radiusCardActive: {
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderColor: 'rgba(135,206,235,0.5)',
  },
  radiusNumber: {
    color: '#F9FAFB',
    fontSize: 70,
    lineHeight: 70,
    fontWeight: '900',
    letterSpacing: -2,
    textAlign: 'center',
  },
  radiusNumberActive: {
    color: '#FFFFFF',
  },
  radiusLabel: {
    marginTop: 8,
    color: 'rgba(249,250,251,0.6)',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  radiusLabelActive: {
    color: 'rgba(135,206,235,0.95)',
  },
  radiusCaption: {
    marginTop: 14,
    color: 'rgba(249,250,251,0.68)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  radiusCaptionActive: {
    color: 'rgba(249,250,251,0.86)',
  },
  helperBlock: {
    alignItems: 'center',
    paddingTop: 14,
    paddingBottom: 8,
    gap: 4,
  },
  helperTitle: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 15,
    fontWeight: '700',
    textAlign: 'center',
  },
  helperSubtitle: {
    color: 'rgba(249,250,251,0.56)',
    fontSize: 12,
    textAlign: 'center',
  },
  saveWrap: {
    width: '100%',
    alignSelf: 'center',
    marginTop: 'auto',
  },
  saveButton: {
    borderRadius: 20,
    minHeight: 54,
    backgroundColor: 'rgba(135,206,235,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.36)',
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowOffset: { width: 0, height: 8 },
    shadowRadius: 12,
    elevation: 8,
  },
});
