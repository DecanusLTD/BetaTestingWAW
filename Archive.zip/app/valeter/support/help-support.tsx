/**
 * Valeter Help & Support – Same layout as customer; FAQs for valeters.
 * Uses ScreenLayout for consistent positioning.
 */
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from '../../../src/components/shared/AppHeader';
import ScreenLayout from '../../../src/components/layout/ScreenLayout';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY;

const VALETER_FAQS = [
  { id: '1', question: 'How do I get jobs?', answer: 'Go online from your dashboard. Available jobs in your area will appear in the job queue. Accept jobs you want. Set working radius and hours in Profile.' },
  { id: '2', question: 'How do I update job status?', answer: 'You update status as you go: Accepted, En route, Arrived, Washing, Done. Use the tracking screen for the active job.' },
  { id: '3', question: 'When do I get paid?', answer: 'Earnings are typically paid weekly. Check Earnings and Wash history in your profile for totals.' },
  { id: '4', question: 'How do I contact a customer?', answer: 'Use Inbox to see threads for your jobs. Tap a conversation to open chat.' },
  { id: '5', question: 'How do I report an issue?', answer: 'Tap Report an issue in Help & Support, or email support@wishawash.com with job ID. We respond within 24-48 hours.' },
];

export default function ValeterHelpSupport() {
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);

  const toggleFAQ = async (id: string) => {
    await hapticFeedback('light');
    setExpandedFAQ(expandedFAQ === id ? null : id);
  };

  return (
    <ScreenLayout
      header={
        <AppHeader
          title="Help & Support"
          accountType="valeter"
          showBack
          onBack={() => { hapticFeedback('light'); router.back(); }}
        />
      }
      background={<LinearGradient colors={['#0A1929', '#1e3a5f']} style={StyleSheet.absoluteFill} />}
    >
      <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Support</Text>
          <TouchableOpacity
            style={styles.emailSupportCard}
            onPress={() => Linking.openURL('mailto:support@wishawash.com?subject=Car Care Pro Support')}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['rgba(135, 206, 235, 0.2)', 'rgba(30, 58, 138, 0.25)']}
              style={styles.emailSupportGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.emailSupportIconWrapper}>
                <Ionicons name="mail" size={32} color={SKY} />
              </View>
              <Text style={styles.emailSupportTitle}>Email Support</Text>
              <Text style={styles.emailSupportSubtitle}>support@wishawash.com</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>FAQs</Text>
          {VALETER_FAQS.map((faq) => (
            <TouchableOpacity
              key={faq.id}
              style={styles.faqItem}
              onPress={() => toggleFAQ(faq.id)}
            >
              <View style={styles.faqHeader}>
                <Text style={styles.faqQuestion}>{faq.question}</Text>
                <Text style={styles.faqToggle}>{expandedFAQ === faq.id ? '-' : '+'}</Text>
              </View>
              {expandedFAQ === faq.id && <Text style={styles.faqAnswer}>{faq.answer}</Text>}
            </TouchableOpacity>
          ))}
        </View>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Need Help?</Text>
        <TouchableOpacity style={styles.legalLink} onPress={() => Linking.openURL('mailto:support@wishawash.com?subject=Report an Issue')}>
          <Text style={styles.legalLinkText}>Report an issue</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.legalLink} onPress={() => Linking.openURL('mailto:support@wishawash.com?subject=Refund / Dispute')}>
          <Text style={styles.legalLinkText}>Refund / Dispute</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal</Text>
          <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/terms-of-service')}>
            <Text style={styles.legalLinkText}>Terms of Service</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/privacy-policy')}>
            <Text style={styles.legalLinkText}>Privacy Policy</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/cookie-policy' as any)}>
            <Text style={styles.legalLinkText}>Cookie Policy</Text>
          </TouchableOpacity>
        </View>
      <View style={styles.appInfoCard}>
        <Text style={styles.appInfoTitle}>Wish a Wash Car Care Pro</Text>
        <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
      </View>
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  section: { marginBottom: 24 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 12 },
  emailSupportCard: { borderRadius: 16, overflow: 'hidden', backgroundColor: 'rgba(30,41,59,0.6)', borderWidth: 1, borderColor: 'rgba(148,163,184,0.2)' },
  emailSupportGradient: { padding: 20 },
  emailSupportIconWrapper: { width: 56, height: 56, borderRadius: 28, backgroundColor: SKY + '30', justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  emailSupportTitle: { color: '#F9FAFB', fontSize: 17, fontWeight: '700', marginBottom: 4 },
  emailSupportSubtitle: { color: SKY, fontSize: 15 },
  faqContainer: { gap: 12 },
  faqItem: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16, marginBottom: 10 },
  faqHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  faqQuestion: { color: '#F9FAFB', fontSize: 16, fontWeight: '600', flex: 1, marginRight: 16 },
  faqToggle: { color: SKY, fontSize: 18, fontWeight: '700' },
  faqAnswer: { color: '#94A3B8', fontSize: 14, lineHeight: 22, marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(148,163,184,0.2)' },
  legalLink: { paddingVertical: 12 },
  legalLinkText: { color: SKY, fontSize: 15, fontWeight: '600' },
  appInfoCard: { alignItems: 'center', paddingVertical: 24 },
  appInfoTitle: { color: '#94A3B8', fontSize: 14, fontWeight: '600' },
  appInfoVersion: { color: '#64748B', fontSize: 12, marginTop: 4 },
});
