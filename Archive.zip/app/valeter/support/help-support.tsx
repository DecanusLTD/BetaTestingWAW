/**
 * Valeter Help & Support — magical interactive FAQs with the Wish a Wash magician.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Linking,
  Image,
  Animated,
  Easing,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChromeGlyph as Ionicons } from '../../../src/components/shared/ChromeGlyph';
import ValeterScreenHeader from '../../../src/components/valeter/ValeterScreenHeader';
import ScreenLayout from '../../../src/components/layout/ScreenLayout';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ICON } from '../../../src/constants/appAssetExports';
import { VALETER_CONTENT_BOTTOM_PAD } from '../../../src/components/valeter/ValeterNavSidebar';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const VALETER_FAQS = [
  {
    id: '1',
    question: 'How do I get jobs?',
    answer:
      'Go online from your dashboard. Available jobs in your area will appear in the job queue. Accept jobs you want. Set working radius and hours in Profile.',
  },
  {
    id: '2',
    question: 'How do I update job status?',
    answer:
      'You update status as you go: Accepted, En route, Arrived, Washing, Done. Use the tracking screen for the active job.',
  },
  {
    id: '3',
    question: 'When do I get paid?',
    answer:
      'Earnings are typically paid weekly. Check Earnings and Wash history in your profile for totals.',
  },
  {
    id: '4',
    question: 'How do I contact a customer?',
    answer: 'Use Inbox to see threads for your jobs. Tap a conversation to open chat.',
  },
  {
    id: '5',
    question: 'How do I report an issue?',
    answer:
      'Tap Report an issue in Help & Support, or email Admin@wishawashapp.com with job ID. We respond within 24-48 hours.',
  },
] as const;

type SparkleSpec = {
  id: string;
  x: Animated.Value;
  y: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  rotate: Animated.Value;
  color: string;
  size: number;
};

const SPARKLE_COLORS = ['#E8C547', '#FFE08A', '#9EC9E0', '#FFFFFF', '#F59E0B'];

function MagicSparkles({ burstKey }: Readonly<{ burstKey: number }>) {
  const sparkles = useRef<SparkleSpec[]>([]);
  const [, force] = useState(0);

  useEffect(() => {
    if (burstKey <= 0) return;

    const next: SparkleSpec[] = Array.from({ length: 14 }, (_, i) => {
      const angle = (Math.PI * 2 * i) / 14 + Math.random() * 0.4;
      const dist = 48 + Math.random() * 72;
      return {
        id: `${burstKey}-${i}`,
        x: new Animated.Value(0),
        y: new Animated.Value(0),
        opacity: new Animated.Value(1),
        scale: new Animated.Value(0.2),
        rotate: new Animated.Value(0),
        color: SPARKLE_COLORS[i % SPARKLE_COLORS.length],
        size: 5 + (i % 4) * 2,
      };
    });

    sparkles.current = next;
    force((n) => n + 1);

    next.forEach((s, i) => {
      const angle = (Math.PI * 2 * i) / 14 + Math.random() * 0.35;
      const dist = 52 + Math.random() * 80;
      Animated.parallel([
        Animated.timing(s.x, {
          toValue: Math.cos(angle) * dist,
          duration: 720 + Math.random() * 280,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(s.y, {
          toValue: Math.sin(angle) * dist - 24,
          duration: 720 + Math.random() * 280,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.sequence([
          Animated.timing(s.scale, {
            toValue: 1.15,
            duration: 220,
            useNativeDriver: true,
          }),
          Animated.timing(s.scale, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
          }),
        ]),
        Animated.timing(s.opacity, {
          toValue: 0,
          duration: 900,
          useNativeDriver: true,
        }),
        Animated.timing(s.rotate, {
          toValue: 1,
          duration: 900,
          useNativeDriver: true,
        }),
      ]).start();
    });
  }, [burstKey]);

  return (
    <View pointerEvents="none" style={styles.sparkleLayer}>
      {sparkles.current.map((s) => {
        const spin = s.rotate.interpolate({
          inputRange: [0, 1],
          outputRange: ['0deg', '180deg'],
        });
        return (
          <Animated.View
            key={s.id}
            style={[
              styles.sparkle,
              {
                width: s.size,
                height: s.size,
                backgroundColor: s.color,
                opacity: s.opacity,
                transform: [
                  { translateX: s.x },
                  { translateY: s.y },
                  { scale: s.scale },
                  { rotate: spin },
                ],
              },
            ]}
          />
        );
      })}
    </View>
  );
}

function MagicianHero({
  accent,
  gold,
  spinSignal,
}: Readonly<{ accent: string; gold: string; spinSignal: number }>) {
  const float = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const glow = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const bob = Animated.loop(
      Animated.sequence([
        Animated.timing(float, {
          toValue: 1,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(float, {
          toValue: 0,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    const shimmer = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, {
          toValue: 1,
          duration: 1400,
          useNativeDriver: true,
        }),
        Animated.timing(glow, {
          toValue: 0,
          duration: 1400,
          useNativeDriver: true,
        }),
      ])
    );
    bob.start();
    shimmer.start();
    return () => {
      bob.stop();
      shimmer.stop();
    };
  }, [float, glow]);

  useEffect(() => {
    if (spinSignal <= 0) return;
    spin.setValue(0);
    Animated.timing(spin, {
      toValue: 1,
      duration: 780,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [spinSignal, spin]);

  const translateY = float.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -10],
  });
  const rotate = spin.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });
  const haloOpacity = glow.interpolate({
    inputRange: [0, 1],
    outputRange: [0.28, 0.62],
  });

  return (
    <View style={styles.hero}>
      <Animated.View
        style={[
          styles.heroIconWrap,
          {
            transform: [{ translateY }, { rotate }],
          },
        ]}
      >
        <Image source={ICON} style={styles.heroIcon} resizeMode="contain" />
      </Animated.View>
      <Text style={styles.heroTitle}>Ask the magician</Text>
      <Text style={styles.heroSubtitle}>Tap a question — sparkles reveal the answer</Text>
    </View>
  );
}

function MagicFaqCard({
  faq,
  open,
  accent,
  gold,
  onPress,
}: Readonly<{
  faq: (typeof VALETER_FAQS)[number];
  open: boolean;
  accent: string;
  gold: string;
  onPress: () => void;
}>) {
  const flip = useRef(new Animated.Value(open ? 1 : 0)).current;
  const wobble = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(flip, {
      toValue: open ? 1 : 0,
      friction: 7,
      tension: 80,
      useNativeDriver: true,
    }).start();

    if (open) {
      Animated.sequence([
        Animated.timing(wobble, {
          toValue: 1,
          duration: 120,
          useNativeDriver: true,
        }),
        Animated.timing(wobble, {
          toValue: -1,
          duration: 120,
          useNativeDriver: true,
        }),
        Animated.timing(wobble, {
          toValue: 0,
          duration: 120,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [open, flip, wobble]);

  const rotateZ = wobble.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: ['-2.5deg', '0deg', '2.5deg'],
  });
  const scale = flip.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.015],
  });
  const chevron = flip.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'],
  });

  return (
    <Animated.View
      style={[
        styles.faqCard,
        open && {
          borderColor: `${gold}88`,
          backgroundColor: 'rgba(232,197,71,0.1)',
        },
        { transform: [{ rotateZ }, { scale }] },
      ]}
    >
      <TouchableOpacity onPress={onPress} activeOpacity={0.88} style={styles.faqTouchable}>
        <View style={styles.faqHeader}>
          <View style={[styles.faqBadge, { backgroundColor: open ? `${gold}33` : `${accent}22` }]}>
            <Ionicons name={open ? 'sparkles' : 'help-circle-outline'} size={18} color={open ? gold : accent} />
          </View>
          <Text style={[styles.faqQuestion, open && { color: '#FFF8E7' }]}>{faq.question}</Text>
          <Animated.View style={{ transform: [{ rotate: chevron }] }}>
            <Ionicons name="chevron-down" size={18} color={open ? gold : accent} />
          </Animated.View>
        </View>
        {open ? (
          <View style={styles.faqAnswerWrap}>
            <View style={[styles.faqAnswerRule, { backgroundColor: `${gold}44` }]} />
            <Text style={styles.faqAnswer}>{faq.answer}</Text>
          </View>
        ) : null}
      </TouchableOpacity>
    </Animated.View>
  );
}

export default function ValeterHelpSupport() {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = theme.primary || '#9EC9E0';
  const gold = theme.accentAlt || '#E8C547';
  const gradientBg = (theme.background || ['#6A9BB0', '#2A4660']) as [string, string];

  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [spinSignal, setSpinSignal] = useState(0);
  const [burstKey, setBurstKey] = useState(0);
  const [burstOrigin, setBurstOrigin] = useState({ top: 180 });

  const castSpell = useCallback(async (id: string, cardY?: number) => {
    await hapticFeedback('medium');
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    const opening = expandedFAQ !== id;
    setExpandedFAQ(opening ? id : null);
    if (opening) {
      setSpinSignal((n) => n + 1);
      if (cardY != null) setBurstOrigin({ top: cardY });
      setBurstKey((n) => n + 1);
    }
  }, [expandedFAQ]);

  const background = useMemo(
    () => (
      <>
        <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" bubbleCount={5} />
      </>
    ),
    [gradientBg]
  );

  return (
    <ScreenLayout
      header={<ValeterScreenHeader title="Help & Support" />}
      background={background}
      innerStyle={{
        paddingBottom: VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 12,
      }}
    >
      <View style={styles.stage}>
        <MagicianHero accent={accent} gold={gold} spinSignal={spinSignal} />
        <View style={[styles.burstAnchor, { top: burstOrigin.top }]} pointerEvents="none">
          <MagicSparkles burstKey={burstKey} />
        </View>
      </View>

      <Text style={[styles.sectionEyebrow, { color: gold }]}>SPELLBOOK</Text>
      <Text style={styles.sectionTitle}>Questions & answers</Text>

      <View style={styles.faqList}>
        {VALETER_FAQS.map((faq, index) => (
          <MagicFaqCard
            key={faq.id}
            faq={faq}
            open={expandedFAQ === faq.id}
            accent={accent}
            gold={gold}
            onPress={() => castSpell(faq.id, 168 + index * 22)}
          />
        ))}
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionEyebrow, { color: gold }]}>NEED A HUMAN?</Text>
        <Text style={styles.sectionTitle}>Contact support</Text>
        <TouchableOpacity
          style={[styles.emailSupportCard, { borderColor: `${accent}44` }]}
          onPress={() => Linking.openURL('mailto:Admin@wishawashapp.com?subject=Wish a Wash Support')}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[`${accent}28`, 'rgba(42,70,96,0.35)', `${gold}18`]}
            style={styles.emailSupportGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.emailRow}>
              <Image source={ICON} style={styles.emailIcon} resizeMode="contain" />
              <View style={styles.emailCopy}>
                <Text style={styles.emailSupportTitle}>Email the team</Text>
                <Text style={[styles.emailSupportSubtitle, { color: accent }]}>Admin@wishawashapp.com</Text>
              </View>
              <Ionicons name="send" size={18} color={accent} />
            </View>
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.legalLink}
          onPress={() => Linking.openURL('mailto:Admin@wishawashapp.com?subject=Report an Issue')}
        >
          <Ionicons name="warning-outline" size={16} color={accent} />
          <Text style={[styles.legalLinkText, { color: accent }]}>Report an issue</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.legalLink}
          onPress={() => Linking.openURL('mailto:Admin@wishawashapp.com?subject=Refund / Dispute')}
        >
          <Ionicons name="card-outline" size={16} color={accent} />
          <Text style={[styles.legalLinkText, { color: accent }]}>Refund / Dispute</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionEyebrow, { color: gold }]}>LEGAL</Text>
        <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/terms-of-service')}>
          <Text style={[styles.legalLinkText, { color: accent }]}>Terms & Conditions</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/privacy-policy')}>
          <Text style={[styles.legalLinkText, { color: accent }]}>Privacy Policy</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/cookie-policy' as any)}>
          <Text style={[styles.legalLinkText, { color: accent }]}>Cookie Policy</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionEyebrow, { color: '#FCA5A5' }]}>ACCOUNT</Text>
        <TouchableOpacity
          style={styles.deleteCard}
          onPress={async () => {
            await hapticFeedback('light');
            router.push('/account-deletion' as any);
          }}
          activeOpacity={0.85}
        >
          <View style={styles.deleteIconWrap}>
            <Ionicons name="trash-outline" size={18} color="#FCA5A5" />
          </View>
          <View style={styles.deleteCopy}>
            <Text style={styles.deleteTitle}>Delete account</Text>
            <Text style={styles.deleteSub}>Open a deletion request form</Text>
          </View>
          <Ionicons name="chevron-forward" size={16} color="rgba(252,165,165,0.7)" />
        </TouchableOpacity>
      </View>

      <View style={styles.appInfoCard}>
        <Image source={ICON} style={styles.appInfoIcon} resizeMode="contain" />
        <Text style={styles.appInfoTitle}>Wish a Washer App</Text>
        <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
      </View>
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  stage: {
    alignItems: 'center',
    marginBottom: 22,
    minHeight: 200,
  },
  burstAnchor: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    height: 1,
  },
  sparkleLayer: {
    width: 1,
    height: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sparkle: {
    position: 'absolute',
    borderRadius: 1,
    transform: [{ rotate: '45deg' }],
    shadowColor: '#E8C547',
    shadowOpacity: 0.8,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 0 },
  },
  hero: {
    alignItems: 'center',
    paddingTop: 8,
  },
  heroIconWrap: {
    width: 112,
    height: 112,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  heroIcon: {
    width: 112,
    height: 112,
    borderRadius: 24,
  },
  heroTitle: {
    marginTop: 16,
    color: '#F8FAFC',
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.6,
  },
  heroSubtitle: {
    marginTop: 6,
    color: 'rgba(248,250,252,0.68)',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 24,
  },
  section: {
    marginBottom: 22,
  },
  sectionEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.6,
    marginBottom: 4,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 14,
    letterSpacing: -0.3,
  },
  faqList: {
    gap: 12,
    marginBottom: 28,
  },
  faqCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden',
  },
  faqTouchable: {
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  faqBadge: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  faqQuestion: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
    lineHeight: 20,
  },
  faqAnswerWrap: {
    marginTop: 12,
    paddingLeft: 44,
  },
  faqAnswerRule: {
    height: 1,
    marginBottom: 10,
    borderRadius: 1,
  },
  faqAnswer: {
    color: 'rgba(248,250,252,0.78)',
    fontSize: 14,
    lineHeight: 21,
  },
  emailSupportCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    marginBottom: 8,
  },
  emailSupportGradient: {
    padding: 16,
  },
  emailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  emailIcon: {
    width: 44,
    height: 44,
  },
  emailCopy: {
    flex: 1,
  },
  emailSupportTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  emailSupportSubtitle: {
    marginTop: 2,
    fontSize: 13,
    fontWeight: '600',
  },
  legalLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 11,
  },
  legalLinkText: {
    fontSize: 15,
    fontWeight: '600',
  },
  deleteCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(248,113,113,0.35)',
    backgroundColor: 'rgba(239,68,68,0.1)',
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  deleteIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239,68,68,0.16)',
  },
  deleteCopy: {
    flex: 1,
    minWidth: 0,
  },
  deleteTitle: {
    color: '#FCA5A5',
    fontSize: 15,
    fontWeight: '800',
  },
  deleteSub: {
    marginTop: 2,
    color: 'rgba(248,250,252,0.55)',
    fontSize: 12,
    fontWeight: '600',
  },
  appInfoCard: {
    alignItems: 'center',
    paddingVertical: 20,
    gap: 4,
  },
  appInfoIcon: {
    width: 40,
    height: 40,
    marginBottom: 6,
  },
  appInfoTitle: {
    color: 'rgba(248,250,252,0.62)',
    fontSize: 13,
    fontWeight: '700',
  },
  appInfoVersion: {
    color: 'rgba(248,250,252,0.4)',
    fontSize: 12,
  },
});
