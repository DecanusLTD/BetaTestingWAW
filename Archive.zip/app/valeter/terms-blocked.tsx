import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import ValeterScreenHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/valeter/ValeterScreenHeader';

export default function ValeterTermsBlocked() {
  const { theme } = useAccountTheme();
  const primary = theme.primary ?? '#38BDF8';
  const bg = (theme.background || ['#0A1929', '#152238']) as [string, string];

  return (
    <SafeAreaView style={styles.safe} edges={[]}>
      <LinearGradient colors={bg} style={StyleSheet.absoluteFill} />
      <ValeterScreenHeader title="Terms declined" />
      <View style={[styles.content, { paddingTop: HEADER_CONTENT_OFFSET }]}>
        <Ionicons name="lock-closed-outline" size={34} color={primary} />
        <Text style={styles.title}>Terms declined</Text>
        <Text style={styles.body}>
          This valeter account cannot continue until the terms are accepted.
        </Text>
        <TouchableOpacity style={[styles.btn, { backgroundColor: primary }]} onPress={() => router.replace('/valeter/terms' as any)}>
          <Text style={styles.btnText}>Open terms</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24, gap: 14 },
  title: { color: '#fff', fontSize: 28, fontWeight: '800' },
  body: { color: 'rgba(255,255,255,0.75)', fontSize: 15, lineHeight: 22, textAlign: 'center' },
  btn: { marginTop: 8, paddingHorizontal: 18, paddingVertical: 13, borderRadius: 16 },
  btnText: { color: '#0A1929', fontWeight: '800' },
});
