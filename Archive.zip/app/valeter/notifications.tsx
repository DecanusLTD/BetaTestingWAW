import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  FlatList,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

type DocumentType = 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';

type DocumentStatus = 'pending' | 'approved' | 'rejected' | 'not_uploaded';

type ValeterNotificationType = 'job' | 'document' | 'compliance' | 'system';

interface ValeterNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: ValeterNotificationType;
  status?: string;
  priority?: 'low' | 'medium' | 'high';
  actionRoute?: string;
  actionParams?: Record<string, string>;
}

interface BookingRow {
  id: string;
  status: JobStatus;
  service_type: string | null;
  service_name: string | null;
  location_address: string | null;
  updated_at: string | null;
  created_at: string | null;
}

interface ValeterDocumentRow {
  id: string;
  type: DocumentType;
  status: DocumentStatus;
  name: string | null;
  rejection_reason?: string | null;
  uploaded_at?: string | null;
  updated_at?: string | null;
}

const DOC_LABELS: Record<DocumentType, string> = {
  id_proof: 'Proof of Identity',
  selfie: 'Selfie Photo',
  profile_photo: 'Profile Photo',
  disclaimer_signed: 'Terms & Conditions',
};

export default function ValeterNotifications() {
  const { user } = useAuth();
  
  const [notifications, setNotifications] = useState<ValeterNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const formatRelativeTime = useCallback((dateString: string) => {
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return '';
    const diff = Date.now() - date.getTime();
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (diff < minute) return 'Just now';
    if (diff < hour) {
      const m = Math.floor(diff / minute);
      return `${m} min${m === 1 ? '' : 's'} ago`;
    }
    if (diff < day) {
      const h = Math.floor(diff / hour);
      return `${h} hr${h === 1 ? '' : 's'} ago`;
    }
    const d = Math.floor(diff / day);
    if (d < 7) {
      return `${d} day${d === 1 ? '' : 's'} ago`;
    }
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }, []);

  const mapJobNotification = useCallback((job: BookingRow): ValeterNotification => {
    const statusCopy: Record<JobStatus, { title: string; message: string; priority: 'low' | 'medium' | 'high' }> = {
      pending_payment: {
        title: 'Awaiting Payment',
        message: 'Customer needs to complete payment before work can begin.',
        priority: 'medium',
      },
      confirmed: {
        title: 'Job Confirmed',
        message: 'Payment received. You can start travelling when ready.',
        priority: 'medium',
      },
      en_route: {
        title: 'En Route',
        message: 'Marked as en route. Keep the customer updated.',
        priority: 'low',
      },
      arrived: {
        title: 'Arrived On Site',
        message: 'Remember to start the service when you begin washing.',
        priority: 'medium',
      },
      in_progress: {
        title: 'Service In Progress',
        message: 'Complete the checklist before finishing the job.',
        priority: 'low',
      },
      completed: {
        title: 'Job Completed',
        message: 'Nice work! Submit photos and completion details if required.',
        priority: 'low',
      },
    };

    const copy = statusCopy[job.status] ?? statusCopy.confirmed;
    const serviceName = job.service_name || job.service_type || 'Service';

    return {
      id: `job-${job.id}-${job.status}`,
      title: `${copy.title} · ${serviceName}`,
      message: copy.message,
      createdAt: job.updated_at || job.created_at || new Date().toISOString(),
      type: 'job',
      status: job.status,
      priority: copy.priority,
      actionRoute: '/valeter/jobs/tracking',
      actionParams: { jobId: job.id },
    };
  }, []);

  const mapDocumentNotification = useCallback((doc: ValeterDocumentRow): ValeterNotification => {
    const baseTitle = DOC_LABELS[doc.type] || 'Document';
    let title = baseTitle;
    let message = '';
    let priority: ValeterNotification['priority'] = 'low';

    switch (doc.status) {
      case 'pending':
        title = `${baseTitle} pending review`;
        message = 'Hang tight—our compliance team is reviewing this upload.';
        priority = 'low';
        break;
      case 'approved':
        title = `${baseTitle} approved`;
        message = 'You are all set for this requirement.';
        priority = 'low';
        break;
      case 'rejected':
        title = `${baseTitle} rejected`;
        message = doc.rejection_reason
          ? doc.rejection_reason
          : 'Please resubmit this document with the requested corrections.';
        priority = 'high';
        break;
      case 'not_uploaded':
      default:
        title = `${baseTitle} missing`;
        message = 'Upload this document to stay compliant.';
        priority = 'high';
        break;
    }

    return {
      id: `doc-${doc.id}`,
      title,
      message,
      createdAt: doc.updated_at || doc.uploaded_at || new Date().toISOString(),
      type: 'document',
      status: doc.status,
      priority,
      actionRoute: '/valeter/profile/valeter-legal-compliance',
    };
  }, []);

  const computeComplianceReminder = useCallback(
    (documents: ValeterDocumentRow[] = [], profilePhotoUrl?: string | null): ValeterNotification | null => {
      const requiredTypes: DocumentType[] = ['id_proof', 'selfie', 'profile_photo', 'disclaimer_signed'];
      const uploadedTypes = documents.map((doc) => doc.type);
      let missingTypes = requiredTypes.filter((type) => !uploadedTypes.includes(type));

      const hasApprovedProfilePhoto = profilePhotoUrl || documents.some(
        (doc) => doc.type === 'profile_photo' && doc.status === 'approved'
      );
      if (!hasApprovedProfilePhoto && !missingTypes.includes('profile_photo')) {
        missingTypes = [...missingTypes, 'profile_photo'];
      }

      if (missingTypes.length === 0) {
        return null;
      }

      const missingNames = missingTypes.map((type) => DOC_LABELS[type]);

      return {
        id: `compliance-${missingTypes.join('-')}`,
        title: missingTypes.length === 1 ? 'Document Required' : 'Documents Required',
        message: `Upload ${missingNames.join(', ')} to stay compliant.`,
        createdAt: new Date().toISOString(),
        type: 'compliance',
        priority: missingTypes.length > 1 ? 'high' : 'medium',
        actionRoute: '/valeter/profile/valeter-legal-compliance',
      };
    },
    []
  );

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) return;
    if (!refreshing) setLoading(true);
    try {
      const [jobsRes, docsRes, profileRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,updated_at,created_at')
          .eq('valeter_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(30),
        supabase
          .from('valeter_documents')
          .select('id,type,status,name,rejection_reason,uploaded_at,updated_at')
          .eq('user_id', user.id),
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
      ]);

      const jobNotifications =
        jobsRes.data?.map((job) => mapJobNotification(job as BookingRow)) ?? [];
      const documentNotifications =
        docsRes.data?.map((doc) => mapDocumentNotification(doc as ValeterDocumentRow)) ?? [];

      const complianceNotification = computeComplianceReminder(
        docsRes.data as ValeterDocumentRow[] | undefined,
        profileRes.data?.profile_photo_url
      );

      const combined = [
        ...jobNotifications,
        ...documentNotifications,
        ...(complianceNotification ? [complianceNotification] : []),
      ].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      setNotifications(combined);
    } catch (error) {
      console.error('[ValeterNotifications] Failed to load notifications', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, mapJobNotification, mapDocumentNotification, computeComplianceReminder, refreshing]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    if (!user?.id) return;
    const jobChannel = supabase
      .channel(`valeter-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    const docChannel = supabase
      .channel(`valeter-docs-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_documents',
          filter: `user_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(jobChannel);
      supabase.removeChannel(docChannel);
    };
  }, [user?.id, fetchNotifications]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    fetchNotifications();
  }, [fetchNotifications]);

  const handleNotificationPress = useCallback((notification: ValeterNotification) => {
    if (notification.actionRoute) {
      router.push({
        pathname: notification.actionRoute as any,
        params: (notification.actionParams || {}) as any,
      });
    }
  }, []);

  const listEmptyComponent = useMemo(
    () => (
      <View style={styles.emptyState}>
        <Ionicons name="notifications-off" size={32} color={colors.SKY} style={{ marginBottom: 12 }} />
        <Text style={styles.emptyTitle}>All caught up</Text>
        <Text style={styles.emptySubtitle}>
          You will receive job updates and compliance reminders here.
        </Text>
      </View>
    ),
    []
  );

  const renderNotification = ({ item }: { item: ValeterNotification }) => {
    const iconMeta = getIconMeta(item.type, item.status);

    return (
      <GlassCard
        style={styles.notificationCard}
        accountType="valeter"
        onPress={() => handleNotificationPress(item)}
      >
        <View style={styles.notificationHeader}>
          <View style={[styles.iconWrapper, { backgroundColor: iconMeta.background }]}>
            <Ionicons name={iconMeta.icon as any} size={18} color={iconMeta.color} />
          </View>
          <View style={styles.headerTextBlock}>
            <Text style={styles.notificationTitle}>{item.title}</Text>
            <Text style={styles.notificationTime}>{formatRelativeTime(item.createdAt)}</Text>
          </View>
          {item.priority && (
            <View style={[styles.priorityBadge, getPriorityStyle(item.priority)]}>
              <Text style={styles.priorityText}>{item.priority}</Text>
            </View>
          )}
        </View>
        <Text style={styles.notificationMessage}>{item.message}</Text>
      </GlassCard>
    );
  };

  if (loading && notifications.length === 0) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[colors.BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Notifications" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.SKY} />
          <Text style={styles.loadingText}>Fetching notifications...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[colors.BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader title="Notifications" accountType="valeter" />

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={renderNotification}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET,
          paddingHorizontal: 20,
          paddingBottom: 32,
        }}
        style={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: 16 }} />}
        ListEmptyComponent={listEmptyComponent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={colors.SKY}
            colors={[colors.SKY]}
          />
        }
      />
    </SafeAreaView>
  );
}

const getIconMeta = (
  type: ValeterNotificationType,
  status?: string
): { icon: string; color: string; background: string } => {
  switch (type) {
    case 'job':
      return {
        icon: status === 'completed' ? 'checkmark-done' : 'briefcase-outline',
        color: '#10B981',
        background: 'rgba(16,185,129,0.15)',
      };
    case 'document':
      return {
        icon: status === 'rejected' ? 'close-circle' : status === 'approved' ? 'checkmark-circle' : 'document-text',
        color: status === 'rejected' ? '#F87171' : status === 'approved' ? '#10B981' : colors.SKY,
        background:
          status === 'rejected'
            ? 'rgba(248,113,113,0.15)'
            : status === 'approved'
            ? 'rgba(16,185,129,0.15)'
            : 'rgba(135,206,235,0.15)',
      };
    case 'compliance':
      return {
        icon: 'shield-half',
        color: '#FBBF24',
        background: 'rgba(251,191,36,0.2)',
      };
    default:
      return {
        icon: 'notifications',
        color: colors.SKY,
        background: 'rgba(135,206,235,0.15)',
      };
  }
};

const getPriorityStyle = (priority: 'low' | 'medium' | 'high') => {
  switch (priority) {
    case 'high':
      return { backgroundColor: 'rgba(248,113,113,0.2)', borderColor: '#F87171' };
    case 'medium':
      return { backgroundColor: 'rgba(251,191,36,0.2)', borderColor: '#FBBF24' };
    default:
      return { backgroundColor: 'rgba(135,206,235,0.2)', borderColor: colors.SKY };
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.BG,
  },
  list: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: HEADER_CONTENT_OFFSET + 28,
  },
  loadingText: {
    marginTop: 12,
    color: colors.SKY,
  },
  notificationCard: {
    padding: 18,
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  headerTextBlock: {
    flex: 1,
  },
  notificationTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  notificationTime: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    marginTop: 2,
  },
  notificationMessage: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    lineHeight: 20,
  },
  priorityBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
  },
  priorityText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  emptyState: {
    marginTop: 40,
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  emptySubtitle: {
    color: 'rgba(249,250,251,0.7)',
    textAlign: 'center',
    lineHeight: 20,
  },
});


