import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  StatusBar,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { colors } from '../../src/constants/colors';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function ValeterOnboarding() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const steps = [
    {
      title: "Welcome to the Wish a Wash Team!",
      subtitle: "Your professional valeting journey begins here",
      description: "You're now part of an elite network of professional valeters. Get ready to build your business and deliver exceptional service to customers.",
      icon: 'sparkles',
      color: "#10B981"
    },
    {
      title: "Flexible Work, Maximum Earnings",
      subtitle: "Work when you want, earn what you deserve",
      description: "Set your own schedule, choose your working area, and keep up to 85% of your earnings. Build your business on your terms.",
      icon: 'cash',
      color: "#F59E0B"
    },
    {
      title: "Professional Tools & Support",
      subtitle: "Everything you need to succeed",
      description: "Access to professional equipment, training resources, and dedicated support. We're here to help you grow your valeting business.",
      icon: 'construct',
      color: "#3B82F6"
    },
    {
      title: "Build Your Reputation",
      subtitle: "Earn reviews and grow your customer base",
      description: "Every satisfied customer helps build your reputation. Great reviews lead to more bookings and higher earnings potential.",
      icon: 'star',
      color: "#8B5CF6"
    },
    {
      title: "Rewards & Recognition",
      subtitle: "Earn points and unlock exclusive benefits",
      description: "Complete washes, earn positive reviews, and unlock rewards like equipment upgrades, training courses, and priority support.",
      icon: 'trophy',
      color: "#EF4444"
    },
    {
      title: "You're Ready to Start!",
      subtitle: "Your professional journey awaits",
      description: "Your account is set up and ready! Go online to start accepting bookings and begin your journey as a Wish a Wash professional.",
      icon: 'rocket',
      color: "#10B981"
    }
  ];

  useEffect(() => {
    animateStep();
  }, [currentStep]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      await AsyncStorage.setItem('valeter_onboarding_seen', 'true');
      router.replace('/valeter/valeter-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      router.replace('/valeter/valeter-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const skipOnboarding = () => {
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#0A1929']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top }]}>
        <View style={styles.headerContent}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
        
        <View style={styles.progressContainer}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentStep && styles.progressDotActive,
                index < currentStep && styles.progressDotCompleted
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
        </View>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.iconContainer}>
            <LinearGradient
              colors={[currentStepData.color, currentStepData.color + '80']}
              style={styles.iconGradient}
            >
            <Ionicons name={currentStepData.icon as any} size={44} color="#0A1929" />
            </LinearGradient>
          </View>

          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStepData.subtitle}</Text>
          
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

          {/* Step-specific content */}
          {currentStep === 0 && (
            <View style={styles.welcomeCard}>
              <Text style={styles.welcomeText}>
                Hello, {user?.name || 'Professional Valeter'}!
              </Text>
              <Text style={styles.welcomeSubtext}>
                Welcome to the most trusted valeting network in the UK.
              </Text>
            </View>
          )}

          {currentStep === 1 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Your Benefits:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="time" size={20} color={SKY} />
                <Text style={styles.featureText}>Set your own schedule</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="location" size={20} color={SKY} />
                <Text style={styles.featureText}>Choose your working area</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="cash" size={20} color={SKY} />
                <Text style={styles.featureText}>Keep 85% of earnings</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="wallet" size={20} color={SKY} />
                <Text style={styles.featureText}>Receive tips directly</Text>
              </View>
            </View>
          )}

          {currentStep === 2 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Professional Support:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="construct" size={20} color={SKY} />
                <Text style={styles.featureText}>Equipment recommendations</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="library" size={20} color={SKY} />
                <Text style={styles.featureText}>Training resources</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="help-circle" size={20} color={SKY} />
                <Text style={styles.featureText}>Dedicated support team</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="shield-checkmark" size={20} color={SKY} />
                <Text style={styles.featureText}>Insurance guidance</Text>
              </View>
            </View>
          )}

          {currentStep === 3 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Build Your Business:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="star" size={20} color={SKY} />
                <Text style={styles.featureText}>Customer reviews & ratings</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="trending-up" size={20} color={SKY} />
                <Text style={styles.featureText}>Performance analytics</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="people" size={20} color={SKY} />
                <Text style={styles.featureText}>Growing customer base</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="trophy" size={20} color={SKY} />
                <Text style={styles.featureText}>Professional certification</Text>
              </View>
            </View>
          )}

          {currentStep === 4 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Earn Rewards:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="gift" size={20} color={SKY} />
                <Text style={styles.featureText}>Equipment upgrades</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="school" size={20} color={SKY} />
                <Text style={styles.featureText}>Advanced training courses</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="star" size={20} color={SKY} />
                <Text style={styles.featureText}>Priority support access</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="people-circle" size={20} color={SKY} />
                <Text style={styles.featureText}>Networking events</Text>
              </View>
            </View>
          )}

          {currentStep === 5 && (
            <View style={styles.finalCard}>
              <Text style={styles.finalTitle}>Ready to Go Online?</Text>
              <Text style={styles.finalText}>
                Your professional valeting business is ready to launch. Start accepting bookings and building your reputation today!
              </Text>
            </View>
          )}
        </Animated.View>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
        >
          <LinearGradient
            colors={['#10B981', '#059669']}
            style={styles.nextButtonGradient}
        >
          <Text style={styles.nextButtonText}>
            {currentStep === steps.length - 1 ? 'Start Working' : 'Next'}
          </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    borderRadius: 10,
  },
  skipText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
    opacity: 1,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(135,206,235,0.25)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  progressDotCompleted: {
    backgroundColor: '#10B981',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  stepContainer: {
    alignItems: 'center',
    paddingVertical: 28,
  },
  iconContainer: {
    marginBottom: 28,
  },
  iconGradient: {
    width: 96,
    height: 96,
    borderRadius: 48,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  stepTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 24 : 26,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 32,
  },
  stepSubtitle: {
    color: SKY,
    fontSize: isSmallScreen ? 15 : 17,
    textAlign: 'center',
    marginBottom: 18,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 15,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 28,
    opacity: 0.9,
  },
  welcomeCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 18,
    marginTop: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  welcomeText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  welcomeSubtext: {
    color: SKY,
    fontSize: 14,
    textAlign: 'center',
  },
  featureCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 18,
    marginTop: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  featureTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    gap: 10,
  },
  featureText: {
    color: '#FFFFFF',
    fontSize: 14,
    flex: 1,
  },
  finalCard: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: '#10B981',
    borderRadius: 16,
    padding: 18,
    marginTop: 20,
    alignItems: 'center',
  },
  finalTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  finalText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 22,
  },
  footer: {
    paddingHorizontal: 20,
    paddingBottom: 28,
    paddingTop: 16,
  },
  nextButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
});
