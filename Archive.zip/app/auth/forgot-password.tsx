import { useEffect } from 'react';
import { router, useLocalSearchParams } from 'expo-router';

/** Legacy route — open forgot-password as a sheet on the login screen. */
export default function ForgotPasswordRedirect() {
  const params = useLocalSearchParams<{ email?: string }>();

  useEffect(() => {
    router.replace({
      pathname: '/auth/login',
      params: {
        forgot: '1',
        ...(typeof params.email === 'string' && params.email.includes('@')
          ? { email: params.email }
          : {}),
      },
    } as any);
  }, [params.email]);

  return null;
}
