import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  StatusBar,
  Modal,
  Pressable,
  Linking,
  Image,
} from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import WWPrimaryButton from '../../src/components/ui/WWPrimaryButton';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import { AUTH_PAGES_VIDEO } from '../../assets/authExports';
import {
  sharedAuthStyleDefs,
  AUTH_GRADIENT_COLORS,
} from '../../src/constants/authStyles';

const NEW_AUTH_LOGO = require('../../assets/newauthlogo.png');

const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';
const HELP_URL = 'https://wishawash.com/help';

export default function SignupScreen() {
  const { register, registerWithApple } = useAuth();

  const [userType, setUserType] = useState<'valeter' | 'organization'>('valeter');
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const handlePressIn = () => {
    Animated.spring(buttonScale, { toValue: 0.98, useNativeDriver: true, speed: 50 }).start();
  };
  const handlePressOut = () => {
    Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true, speed: 50 }).start();
  };

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType,
        password: formData.password,
      });

      if (success) {
        setEmailModalVisible(false);
        router.replace('/');
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType });
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        Alert.alert(
          'Apple Sign Up',
          'Apple sign up needs to be wired to your backend via registerWithApple.'
        );
        return;
      }
      router.replace('/');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleSignup = () => {
    hapticFeedback('light');
    Alert.alert('Coming soon', 'Sign in with Google coming soon.');
  };

  const openEmailModal = () => {
    hapticFeedback('light');
    setEmailModalVisible(true);
  };

  const openLink = (url: string) => Linking.openURL(url).catch(() => {});

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <TouchableOpacity
        style={styles.topRightLink}
        onPress={() => router.replace('/auth/login')}
        activeOpacity={0.8}
      >
        <Text style={styles.topRightLinkText}>Sign in</Text>
      </TouchableOpacity>

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={styles.videoBackground}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <View pointerEvents="none" style={styles.authVideoShade} />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <Animated.View
          style={[styles.contentContainer, styles.signupContentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
        >
          <View style={styles.signupScreenBody}>
            <View style={styles.signupHeroPanel}>
              <View style={styles.signupHero}>
                <Image source={NEW_AUTH_LOGO} resizeMode="contain" style={styles.signupHeroLogo} />
                <Text style={styles.signupHeadline}>Create your account</Text>
                <Text style={styles.signupSubtext}>
                  Join Wish a Wash as a pro or business - professional car care, not just washes.
                </Text>
              </View>
            </View>

            <View style={styles.signupActionsPanel}>
              <View style={styles.signupCardWrap}>
                <ContinueCTAButton
                  variant="secondary"
                  title="Continue with Email"
                  onPress={openEmailModal}
                  accentColor={colors.SKY}
                  showTrailingChevron={false}
                  leading={<Ionicons name="mail-outline" size={22} color={colors.textOnDarkPrimary} />}
                  style={styles.authGlassCta}
                />

                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <View style={styles.socialIconRow}>
                  {isAppleAvailable && (
                    <TouchableOpacity
                      style={[styles.socialIconButton, styles.socialIconApple]}
                      onPress={handleAppleSignup}
                      onPressIn={handlePressIn}
                      onPressOut={handlePressOut}
                      activeOpacity={0.9}
                      accessibilityLabel="Continue with Apple"
                    >
                      <Ionicons name="logo-apple" size={24} color="#000000" />
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    style={[
                      styles.socialIconButton,
                      styles.socialIconGoogle,
                      { backgroundColor: 'rgba(255,255,255,0.18)', borderColor: 'rgba(255,255,255,0.18)', opacity: 0.72 },
                    ]}
                    onPress={handleGoogleSignup}
                    onPressIn={handlePressIn}
                    onPressOut={handlePressOut}
                    activeOpacity={0.9}
                    accessibilityLabel="Continue with Google"
                  >
                    <Ionicons name="logo-google" size={22} color="rgba(255,255,255,0.55)" />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.signupFooter}>
                <View style={styles.trustCopy}>
                  <Text style={styles.trustCopyText}>
                    By continuing, you agree to{' '}
                    <Text style={styles.trustCopyLink} onPress={() => openLink(TERMS_URL)}>
                      Terms
                    </Text>
                    {' & '}
                    <Text style={styles.trustCopyLink} onPress={() => openLink(PRIVACY_URL)}>
                      Privacy Policy
                    </Text>
                  </Text>
                  <Text style={styles.secureNote}>Secure sign-in • No spam</Text>
                </View>

                <TouchableOpacity style={styles.helpLink} onPress={() => openLink(HELP_URL)} activeOpacity={0.8}>
                  <Ionicons name="help-circle-outline" size={18} color="rgba(255,255,255,0.7)" />
                  <Text style={styles.helpLinkText}> Help</Text>
                </TouchableOpacity>

                <View style={styles.signupCtaRow}>
                  <Text style={styles.signupCtaText}>Already have an account? </Text>
                  <TouchableOpacity onPress={() => router.replace('/auth/login')} activeOpacity={0.8}>
                    <Text style={[styles.signupCtaText, styles.signupCtaLink]}>Sign in</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.footer}>
                  <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2025</Text>
                </View>
              </View>
            </View>
          </View>
        </Animated.View>
      </KeyboardAvoidingView>

      <Modal
        visible={emailModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEmailModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setEmailModalVisible(false)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboardAvoid}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={60} tint="dark" style={styles.modalBlur}>
                <ScrollView
                  style={styles.modalScroll}
                  contentContainerStyle={styles.modalScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <View style={styles.modalInner}>
                    <View style={styles.modalHeader}>
                      <Text style={styles.modalTitle}>Create account with Email</Text>
                      <TouchableOpacity
                        onPress={() => setEmailModalVisible(false)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Ionicons name="close" size={28} color="rgba(255,255,255,0.9)" />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.userTypeSwitcher}>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('valeter'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'valeter' && styles.userTypeButtonTextActive]}>
                          Car Care Pro
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'organization' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('organization'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'organization' && styles.userTypeButtonTextActive]}>
                          Business
                        </Text>
                      </TouchableOpacity>
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="person-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder={userType === 'organization' ? 'Business name' : 'Full name'}
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.name}
                        onChangeText={(v) => updateFormData('name', v)}
                        autoComplete="name"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Email address"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.email}
                        onChangeText={(v) => updateFormData('email', v)}
                        autoCapitalize="none"
                        keyboardType="email-address"
                        autoComplete="email"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Password (min. 6 characters)"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={formData.password}
                        onChangeText={(v) => updateFormData('password', v)}
                        secureTextEntry
                        autoComplete="password-new"
                      />
                    </View>

                    {error && (
                      <View style={styles.errorContainer}>
                        <Ionicons name="warning" size={18} color="#FCA5A5" />
                        <Text style={styles.errorText}>{error}</Text>
                      </View>
                    )}

                    <WWPrimaryButton
                      title={isLoading ? 'Creating account…' : 'Create account'}
                      onPress={handleSignup}
                      disabled={isLoading}
                      loading={isLoading}
                      style={styles.signupButton}
                    />
                  </View>
                </ScrollView>
              </BlurView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  ...sharedAuthStyleDefs,
  loginContentContainer: {
    flex: 1,
  },
  signupContentContainer: {
    flex: 1,
  },
  signupScreenBody: {
    flex: 1,
    paddingTop: Platform.OS === 'ios' ? 46 : 34,
    paddingBottom: Platform.OS === 'ios' ? 10 : 8,
  },
  signupHeroPanel: {
    flex: 0.5,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 44,
    paddingBottom: 10,
  },
  signupHero: {
    alignItems: 'center',
    justifyContent: 'center',
    maxWidth: 350,
  },
  signupHeroLogo: {
    width: 560,
    height: 352,
  },
  signupHeadline: {
    marginTop: 2,
    fontSize: 32,
    lineHeight: 36,
    letterSpacing: -0.9,
    color: 'rgba(255,255,255,0.98)',
    textAlign: 'center',
    fontWeight: '700',
  },
  signupSubtext: {
    marginTop: 4,
    fontSize: 15,
    lineHeight: 21,
    maxWidth: 320,
    color: 'rgba(255,255,255,0.74)',
    textAlign: 'center',
    fontWeight: '500',
  },
  signupActionsPanel: {
    flex: 0.5,
    justifyContent: 'space-between',
    paddingTop: 42,
    paddingBottom: 0,
  },
  signupCardWrap: {
    justifyContent: 'flex-start',
    width: '100%',
    paddingHorizontal: 16,
  },
  signupFooter: {
    paddingTop: 18,
    paddingBottom: 0,
  },
  authGlassCta: { marginBottom: 0 },
  socialIconRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
  },
  socialIconButton: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  socialIconApple: { backgroundColor: '#FFFFFF' },
  socialIconGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  authVideoShade: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.18)',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  errorText: { color: '#FCA5A5', fontSize: 14 },
  signupButton: { marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalKeyboardAvoid: { width: '100%', maxHeight: '92%' },
  modalContent: { maxHeight: '92%', borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden' },
  modalBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    maxHeight: '100%',
  },
  modalScroll: { maxHeight: '100%' },
  modalScrollContent: { padding: 24, paddingBottom: 40 },
  modalInner: { padding: 0 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: 'rgba(255,255,255,0.95)' },
  userTypeSwitcher: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    padding: 3,
    marginBottom: 16,
    gap: 4,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userTypeButtonActive: { backgroundColor: '#237AE6' },
  userTypeButtonText: { fontSize: 14, fontWeight: '600', color: 'rgba(255,255,255,0.7)' },
  userTypeButtonTextActive: { color: '#FFFFFF', fontWeight: '700' },
});
