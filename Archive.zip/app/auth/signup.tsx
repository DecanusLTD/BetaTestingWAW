import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AuthGateShell from '../../src/components/auth/AuthGateShell';

const VALETER_USER_TYPE = 'valeter' as const;

export default function SignupScreen() {
  const { register, registerWithApple, registerWithGoogle } = useAuth();

  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [emailSheetOpen, setEmailSheetOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType: VALETER_USER_TYPE,
        password: formData.password,
      });

      if (success) {
        setEmailSheetOpen(false);
        router.replace('/');
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      await hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType: VALETER_USER_TYPE });
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        Alert.alert(
          'Apple Sign Up',
          'Apple sign up needs to be wired to your backend via registerWithApple.'
        );
        return;
      }
      router.replace('/');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await hapticFeedback('light');
      const ok = await registerWithGoogle({ userType: VALETER_USER_TYPE });
      if (!ok) {
        Alert.alert('Google Sign Up Failed', 'Please try again.');
        return;
      }
      router.replace('/');
    } catch (error: any) {
      if (error?.message !== 'oauth_redirect_timeout') {
        Alert.alert('Google Sign Up Failed', error?.message || 'Please try again.');
      }
    }
  };

  return (
    <AuthGateShell
      mode="signup"
      tagline="Join as a Car Care Pro and earn on your schedule."
      emailSheetTitle="Create account with Email"
      emailSheetOpen={emailSheetOpen}
      onOpenEmailSheet={() => {
        void hapticFeedback('light');
        setEmailSheetOpen(true);
      }}
      onCloseEmailSheet={() => setEmailSheetOpen(false)}
      onApple={handleAppleSignup}
      onGoogle={handleGoogleSignup}
      loading={isLoading}
      emailSheetChildren={
        <>
          <View style={styles.inputWrapper}>
            <View style={styles.inputIconContainer}>
              <BrandGlyph name="person-outline" size={20} color="rgba(255,255,255,0.7)" />
            </View>
            <TextInput
              style={styles.input}
              placeholder="Full name"
              placeholderTextColor="rgba(255,255,255,0.4)"
              value={formData.name}
              onChangeText={(v) => updateFormData('name', v)}
              autoComplete="name"
            />
          </View>

          <View style={styles.inputWrapper}>
            <View style={styles.inputIconContainer}>
              <BrandGlyph name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
            </View>
            <TextInput
              style={styles.input}
              placeholder="Email address"
              placeholderTextColor="rgba(255,255,255,0.4)"
              value={formData.email}
              onChangeText={(v) => updateFormData('email', v)}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
            />
          </View>

          <View style={styles.inputWrapper}>
            <View style={styles.inputIconContainer}>
              <BrandGlyph name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
            </View>
            <TextInput
              style={styles.input}
              placeholder="Password (min. 6 characters)"
              placeholderTextColor="rgba(255,255,255,0.4)"
              value={formData.password}
              onChangeText={(v) => updateFormData('password', v)}
              secureTextEntry={!showPassword}
              autoComplete="password-new"
            />
            <TouchableOpacity
              style={styles.inputIconContainer}
              onPress={() => setShowPassword((v) => !v)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <BrandGlyph
                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color="rgba(255,255,255,0.7)"
              />
            </TouchableOpacity>
          </View>

          {error ? (
            <View style={styles.errorContainer}>
              <BrandGlyph name="warning" size={18} color="#FCA5A5" />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={styles.luxuryCta}
            onPress={handleSignup}
            disabled={isLoading}
            activeOpacity={0.9}
          >
            <View style={styles.luxuryCtaInner}>
              <BlurView
                intensity={Platform.OS === 'ios' ? 40 : 28}
                tint="light"
                style={StyleSheet.absoluteFill}
                {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
              />
              <View style={styles.luxuryCtaTint} pointerEvents="none" />
              <LinearGradient
                colors={['rgba(255,255,255,0.45)', 'rgba(255,255,255,0.08)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={styles.luxuryCtaSheen}
                pointerEvents="none"
              />
              <View style={styles.luxuryCtaContent}>
                {isLoading ? (
                  <ActivityIndicator color="#F8FAFC" />
                ) : (
                  <>
                    <Text style={styles.luxuryCtaText}>Create account</Text>
                    <BrandGlyph name="arrow-forward" size={18} color="#F8FAFC" />
                  </>
                )}
              </View>
            </View>
          </TouchableOpacity>
        </>
      }
    />
  );
}

const styles = StyleSheet.create({
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    paddingRight: 12,
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  errorText: { color: '#FCA5A5', fontSize: 14, flex: 1 },
  luxuryCta: {
    marginTop: 4,
    borderRadius: 18,
    shadowColor: '#9EC9E0',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  luxuryCtaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.42)',
    backgroundColor: 'rgba(158,201,224,0.18)',
  },
  luxuryCtaTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(158,201,224,0.22)',
  },
  luxuryCtaSheen: {
    ...StyleSheet.absoluteFillObject,
  },
  luxuryCtaContent: {
    minHeight: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 18,
  },
  luxuryCtaText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
});
