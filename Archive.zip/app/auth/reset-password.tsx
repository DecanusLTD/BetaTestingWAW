import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Platform,
  StatusBar,
  KeyboardAvoidingView,
  ScrollView,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { AUTH_GRADIENT_COLORS } from '../../src/constants/authStyles';
import { AUTH_PAGES_VIDEO } from '../../assets/authExports';
import { supabase } from '../../src/lib/supabase';

export default function ResetPasswordScreen() {
  const insets = useSafeAreaInsets();
  const { updatePassword, logout } = useAuth();
  const params = useLocalSearchParams();

  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const boot = async () => {
      try {
        const code = typeof params.code === 'string' ? params.code : null;
        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) throw exchangeError;
        }

        const { data } = await supabase.auth.getSession();
        if (!data.session) {
          throw new Error('Reset link expired or invalid. Request a new one from sign in.');
        }
        if (!cancelled) setReady(true);
      } catch (e: any) {
        if (!cancelled) {
          setBootError(e?.message || 'Unable to open password reset.');
        }
      }
    };

    void boot();
    return () => {
      cancelled = true;
    };
  }, [params.code]);

  const handleSave = async () => {
    await hapticFeedback('medium');
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords don’t match.');
      return;
    }
    setError(null);
    setSaving(true);
    try {
      await updatePassword('', password);
      await hapticFeedback('success');
      try {
        if (typeof logout === 'function') await logout();
        else await supabase.auth.signOut();
      } catch {
        /* continue to login */
      }
      Alert.alert('Password updated', 'Sign in with your new password.', [
        { text: 'OK', onPress: () => router.replace('/auth/login') },
      ]);
    } catch (e: any) {
      setError(e?.message || 'Couldn’t update password. Try the reset link again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
      <Video
        source={AUTH_PAGES_VIDEO}
        style={StyleSheet.absoluteFill}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
      />
      <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} pointerEvents="none" />
      <LinearGradient
        colors={['rgba(12,42,72,0.35)', 'rgba(6,22,40,0.72)', 'rgba(3,12,24,0.97)']}
        locations={[0.18, 0.52, 1]}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={[
            styles.scroll,
            { paddingTop: insets.top + 16, paddingBottom: Math.max(insets.bottom, 20) + 16 },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.sheetOuter}>
            <BlurView
              intensity={Platform.OS === 'ios' ? 34 : 22}
              tint="dark"
              style={StyleSheet.absoluteFill}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            <View style={styles.sheetTint} pointerEvents="none" />

            <View style={styles.sheetContent}>
              <View style={styles.handle} />
              <View style={[styles.iconBadge, { borderColor: 'rgba(158,201,224,0.4)' }]}>
                <BrandGlyph name="lock-closed-outline" size={22} color="#9EC9E0" />
              </View>
              <Text style={styles.title}>Choose a new password</Text>
              <Text style={styles.subtitle}>
                Enter a new password for your CCP account, then sign in again.
              </Text>

              {!ready && !bootError ? (
                <View style={styles.loadingWrap}>
                  <ActivityIndicator color="#9EC9E0" />
                  <Text style={styles.loadingText}>Opening secure reset…</Text>
                </View>
              ) : null}

              {bootError ? (
                <>
                  <Text style={styles.errorText}>{bootError}</Text>
                  <TouchableOpacity
                    style={styles.cta}
                    onPress={() => router.replace('/auth/login')}
                    activeOpacity={0.9}
                  >
                    <View style={styles.ctaInner}>
                      <View style={styles.ctaContent}>
                        <Text style={styles.ctaText}>Back to sign in</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                </>
              ) : null}

              {ready ? (
                <>
                  <View style={styles.inputWrapper}>
                    <View style={styles.inputIcon}>
                      <BrandGlyph name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                    </View>
                    <TextInput
                      style={styles.input}
                      placeholder="New password"
                      placeholderTextColor="rgba(255,255,255,0.4)"
                      value={password}
                      onChangeText={(v) => {
                        setPassword(v);
                        if (error) setError(null);
                      }}
                      secureTextEntry={!showPassword}
                      autoComplete="new-password"
                      textContentType="newPassword"
                    />
                    <TouchableOpacity
                      style={styles.inputIcon}
                      onPress={() => setShowPassword((v) => !v)}
                      hitSlop={8}
                    >
                      <BrandGlyph
                        name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                        size={20}
                        color="rgba(255,255,255,0.7)"
                      />
                    </TouchableOpacity>
                  </View>

                  <View style={styles.inputWrapper}>
                    <View style={styles.inputIcon}>
                      <BrandGlyph name="shield-checkmark-outline" size={20} color="rgba(255,255,255,0.7)" />
                    </View>
                    <TextInput
                      style={styles.input}
                      placeholder="Confirm new password"
                      placeholderTextColor="rgba(255,255,255,0.4)"
                      value={confirm}
                      onChangeText={(v) => {
                        setConfirm(v);
                        if (error) setError(null);
                      }}
                      secureTextEntry={!showConfirm}
                      autoComplete="new-password"
                      textContentType="newPassword"
                      returnKeyType="done"
                      onSubmitEditing={() => {
                        void handleSave();
                      }}
                    />
                    <TouchableOpacity
                      style={styles.inputIcon}
                      onPress={() => setShowConfirm((v) => !v)}
                      hitSlop={8}
                    >
                      <BrandGlyph
                        name={showConfirm ? 'eye-off-outline' : 'eye-outline'}
                        size={20}
                        color="rgba(255,255,255,0.7)"
                      />
                    </TouchableOpacity>
                  </View>

                  {error ? <Text style={styles.errorText}>{error}</Text> : null}

                  <TouchableOpacity
                    style={styles.cta}
                    onPress={() => {
                      void handleSave();
                    }}
                    disabled={saving}
                    activeOpacity={0.9}
                  >
                    <View style={styles.ctaInner}>
                      <BlurView
                        intensity={Platform.OS === 'ios' ? 40 : 28}
                        tint="light"
                        style={StyleSheet.absoluteFill}
                        {...(Platform.OS === 'android'
                          ? { experimentalBlurMethod: 'dimezisBlurView' as const }
                          : {})}
                      />
                      <View style={styles.ctaTint} pointerEvents="none" />
                      <View style={styles.ctaContent}>
                        {saving ? (
                          <ActivityIndicator color="#F8FAFC" />
                        ) : (
                          <>
                            <Text style={styles.ctaText}>Save new password</Text>
                            <BrandGlyph name="checkmark" size={18} color="#F8FAFC" />
                          </>
                        )}
                      </View>
                    </View>
                  </TouchableOpacity>
                </>
              ) : null}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#061525' },
  flex: { flex: 1 },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 18,
    justifyContent: 'flex-end',
  },
  sheetOuter: {
    borderRadius: 28,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    backgroundColor: 'rgba(8,24,40,0.55)',
  },
  sheetTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(20,70,110,0.22)',
  },
  sheetContent: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 22,
  },
  handle: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.28)',
    marginBottom: 16,
  },
  iconBadge: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(158,201,224,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  title: {
    color: '#F8FAFC',
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.4,
    marginBottom: 8,
  },
  subtitle: {
    color: 'rgba(248,250,252,0.72)',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    marginBottom: 18,
  },
  loadingWrap: {
    alignItems: 'center',
    gap: 12,
    paddingVertical: 28,
  },
  loadingText: {
    color: 'rgba(248,250,252,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  inputIcon: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    paddingRight: 4,
  },
  errorText: {
    color: '#FCA5A5',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 10,
  },
  cta: {
    marginTop: 4,
    borderRadius: 18,
  },
  ctaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.42)',
    backgroundColor: 'rgba(158,201,224,0.18)',
  },
  ctaTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(158,201,224,0.22)',
  },
  ctaContent: {
    minHeight: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 18,
  },
  ctaText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
});
