import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons as BrandGlyph } from '@expo/vector-icons';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import AuthGateShell from '../../src/components/auth/AuthGateShell';
import ForgotPasswordSheet from '../../src/components/auth/ForgotPasswordSheet';
import {
  isValeterRole,
  isCustomerRole,
  isOrganizationRole,
  normalizeUserType,
} from '../../src/utils/authRole';

export default function LoginScreen() {
  const { login, logout, loginWithApple, loginWithGoogle } = useAuth();
  const params = useLocalSearchParams<{ forgot?: string; email?: string }>();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [emailSheetOpen, setEmailSheetOpen] = useState(false);
  const [forgotSheetOpen, setForgotSheetOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const finishRouting = () => {
    router.replace('/');
  };

  useEffect(() => {
    if (params.forgot === '1' || params.forgot === 'true') {
      if (typeof params.email === 'string' && params.email.includes('@')) {
        setEmail(params.email);
      }
      setEmailSheetOpen(false);
      setForgotSheetOpen(true);
    }
  }, [params.forgot, params.email]);

  const getEffectiveRole = async (): Promise<{ role: string; isRestricted: boolean }> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;
    const sbUser = authData?.user;
    if (!sbUser?.id) return { role: '', isRestricted: false };
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type, is_restricted')
      .eq('id', sbUser.id)
      .maybeSingle();
    if (profErr) throw profErr;
    return {
      role: normalizeUserType(profile?.user_type ?? (sbUser.user_metadata as any)?.userType, null) ?? '',
      isRestricted: !!profile?.is_restricted,
    };
  };

  const rejectRestricted = async () => {
    await safeLogout();
    Alert.alert(
      'Account Restricted',
      'Your account has been restricted. Please contact support if you believe this is a mistake.'
    );
  };

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') await logout();
      else await supabase.auth.signOut();
    } catch {}
  };

  const rejectNonValeter = async (role: string) => {
    await safeLogout();
    if (isCustomerRole(role)) {
      Alert.alert(
        'Owner account',
        'This app is for Wish a Washer CCP accounts only. Owner/customer accounts can’t sign in here.'
      );
      return;
    }
    if (isOrganizationRole(role)) {
      Alert.alert(
        'Business account',
        'This sign-in is for CCP accounts. Use the business app for organization accounts.'
      );
      return;
    }
    Alert.alert(
      'Not a CCP account',
      'This app is for Wish a Washer CCP accounts only. Sign in with a CCP account.'
    );
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    await hapticFeedback('medium');
    setIsLoading(true);
    try {
      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert(
          'Login Failed',
          'Invalid email or password. If you just signed up, check your inbox and verify your email address before logging in for the first time.'
        );
        return;
      }

      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        await rejectNonValeter(role);
        return;
      }

      setEmailSheetOpen(false);
      finishRouting();
    } catch (e: any) {
      Alert.alert('Login Failed', e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
      }

      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        await rejectNonValeter(role);
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await hapticFeedback('light');
      const ok = await loginWithGoogle();
      if (!ok) {
        Alert.alert('Google Sign In Failed', 'Please try again.');
        return;
      }
      const { role, isRestricted } = await getEffectiveRole();
      if (isRestricted) {
        await rejectRestricted();
        return;
      }
      if (!isValeterRole(role)) {
        await rejectNonValeter(role);
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.message !== 'oauth_redirect_timeout') {
        Alert.alert('Google Sign In Failed', error?.message || 'Please try again.');
      }
    }
  };

  const handleForgotPassword = async () => {
    await hapticFeedback('light');
    setEmailSheetOpen(false);
    setTimeout(() => setForgotSheetOpen(true), 280);
  };

  return (
    <>
      <AuthGateShell
        mode="login"
        tagline="Earn on your schedule."
        emailSheetTitle="Sign in with Email"
        emailSheetOpen={emailSheetOpen}
        onOpenEmailSheet={() => {
          void hapticFeedback('light');
          setEmailSheetOpen(true);
        }}
        onCloseEmailSheet={() => setEmailSheetOpen(false)}
        onApple={handleAppleLogin}
        onGoogle={handleGoogleLogin}
        loading={isLoading}
        emailSheetChildren={
          <>
            <View style={styles.inputWrapper}>
              <View style={styles.inputIconContainer}>
                <BrandGlyph name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
              </View>
              <TextInput
                style={styles.input}
                placeholder="Email address"
                placeholderTextColor="rgba(255,255,255,0.4)"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                autoComplete="email"
              />
            </View>

            <View style={styles.inputWrapper}>
              <View style={styles.inputIconContainer}>
                <BrandGlyph name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
              </View>
              <TextInput
                style={styles.input}
                placeholder="Password"
                placeholderTextColor="rgba(255,255,255,0.4)"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoComplete="password"
              />
              <TouchableOpacity
                style={styles.inputIconContainer}
                onPress={() => setShowPassword((v) => !v)}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <BrandGlyph
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color="rgba(255,255,255,0.7)"
                />
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.forgotPasswordLink} onPress={handleForgotPassword}>
              <Text style={styles.forgotPasswordText}>Forgot password?</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.luxuryCta}
              onPress={() => handleLogin()}
              disabled={isLoading}
              activeOpacity={0.9}
            >
              <View style={styles.luxuryCtaInner}>
                <BlurView
                  intensity={Platform.OS === 'ios' ? 40 : 28}
                  tint="light"
                  style={StyleSheet.absoluteFill}
                  {...(Platform.OS === 'android'
                    ? { experimentalBlurMethod: 'dimezisBlurView' as const }
                    : {})}
                />
                <View style={styles.luxuryCtaTint} pointerEvents="none" />
                <LinearGradient
                  colors={['rgba(255,255,255,0.45)', 'rgba(255,255,255,0.08)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={styles.luxuryCtaSheen}
                  pointerEvents="none"
                />
                <View style={styles.luxuryCtaContent}>
                  {isLoading ? (
                    <ActivityIndicator color="#F8FAFC" />
                  ) : (
                    <>
                      <Text style={styles.luxuryCtaText}>Continue</Text>
                      <BrandGlyph name="arrow-forward" size={18} color="#F8FAFC" />
                    </>
                  )}
                </View>
              </View>
            </TouchableOpacity>
          </>
        }
      />
      <ForgotPasswordSheet
        visible={forgotSheetOpen}
        initialEmail={email}
        onClose={() => setForgotSheetOpen(false)}
        onBackToSignIn={() => {
          setForgotSheetOpen(false);
          setTimeout(() => setEmailSheetOpen(true), 280);
        }}
      />
    </>
  );
}

const styles = StyleSheet.create({
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    paddingRight: 12,
  },
  forgotPasswordLink: { alignSelf: 'flex-end', marginBottom: 14 },
  forgotPasswordText: { color: '#3A7AAD', fontWeight: '700' },
  luxuryCta: {
    marginTop: 4,
    borderRadius: 18,
    shadowColor: '#9EC9E0',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  luxuryCtaInner: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.42)',
    backgroundColor: 'rgba(158,201,224,0.18)',
  },
  luxuryCtaTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(158,201,224,0.22)',
  },
  luxuryCtaSheen: {
    ...StyleSheet.absoluteFillObject,
  },
  luxuryCtaContent: {
    minHeight: 54,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 18,
  },
  luxuryCtaText: {
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
});
