import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  Linking,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { ChromeGlyph as Ionicons } from '../../src/components/shared/ChromeGlyph';
import * as AppleAuthentication from 'expo-apple-authentication';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import WWPrimaryButton from '../../src/components/ui/WWPrimaryButton';
import ContinueCTAButton from '../../src/components/ui/ContinueCTAButton';
import { AUTH_PAGES_VIDEO } from '../../assets/authExports';
import {
  sharedAuthStyleDefs,
  AUTH_GRADIENT_COLORS,
} from '../../src/constants/authStyles';
import {
  isOrganizationRole,
  isValeterRole,
  normalizeUserType,
} from '../../src/utils/authRole';

const TERMS_URL = 'https://wishawash.com/terms';
const PRIVACY_URL = 'https://wishawash.com/privacy';
const NEW_AUTH_LOGO = require('../../assets/newauthlogo.png');

export default function LoginScreen() {
  const { login, logout, loginWithApple } = useAuth();

  const [userType, setUserType] = useState<'valeter' | 'business'>('valeter');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoOpacity = useRef(new Animated.Value(0)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    // Dev-only autofill values kept here for reference:
    // if (userType === 'valeter') {
    //   setEmail('lingardodeano@gmail.com');
    //   setPassword('@@@Urztfc58812');
    // } else {
    //   setEmail('deanlingard@decanusltd.com');
    //   setPassword('password');
    // }
  }, [userType]);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const handleVideoLoad = () => {
    Animated.timing(videoOpacity, {
      toValue: 1,
      duration: 700,
      useNativeDriver: true,
    }).start();
  };

  const finishRouting = () => {
    router.replace('/');
  };

  const getEffectiveRole = async (): Promise<string> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;
    const sbUser = authData?.user;
    if (!sbUser?.id) return '';
    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type')
      .eq('id', sbUser.id)
      .maybeSingle();
    if (profErr) throw profErr;
    return normalizeUserType(profile?.user_type ?? (sbUser.user_metadata as any)?.userType, null) ?? '';
  };

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') await logout();
      else await supabase.auth.signOut();
    } catch {}
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    await hapticFeedback('medium');
    setIsLoading(true);
    try {
      const adminTriggerEmails = [
        // 'Reeceyrackz@gmail.com',
        // 'founder@wishawash.com',
        // 'admin@wishawash.com',
        // 'ceo@wishawash.com',
        // 'director@wishawash.com',
      ];
      const adminTriggerPasswords = [
        // 'WishWash2026!',
        // 'Admin2026!',
        // 'Founder2026!',
        // 'CEO2026!',
      ];
      if (
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password)
      ) {
        router.push('/super-admin-auth' as any);
        setIsLoading(false);
        return;
      }

      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert(
          'Login Failed',
          'Invalid email or password. If you just signed up, check your inbox and verify your email address before logging in for the first time.'
        );
        return;
      }

      const role = await getEffectiveRole();
      if (userType === 'business' && !isOrganizationRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a business account',
          "That login isn't registered as a business account. Switch to Car Care Pro."
        );
        return;
      }
      if (userType !== 'business' && !isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          "That login isn't registered as a Car Care Pro account. Switch to Business."
        );
        return;
      }

      setEmailModalVisible(false);
      finishRouting();
    } catch (e: any) {
      Alert.alert('Login Failed', e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
      }

      const role = await getEffectiveRole();
      if (userType === 'business' && !isOrganizationRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a business account',
          "That Apple login isn't registered as a business account. Switch to Car Care Pro."
        );
        return;
      }
      if (userType !== 'business' && !isValeterRole(role)) {
        await safeLogout();
        Alert.alert(
          'Not a Car Care Pro account',
          "That Apple login isn't registered as a Car Care Pro account. Switch to Business."
        );
        return;
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleGoogleLogin = () => {
    Alert.alert('Coming soon', 'Sign in with Google coming soon.');
  };

  const handleForgotPassword = () => {
    Alert.alert('Check your emails', 'Password reset instructions have been sent to your email.');
  };

  const openEmailModal = () => {
    hapticFeedback('light');
    setEmailModalVisible(true);
  };

  const openLink = (url: string) => Linking.openURL(url).catch(() => {});

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      <TouchableOpacity
        style={styles.topRightLink}
        onPress={() => router.push('/auth/signup' as any)}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <Text style={styles.topRightLinkText}>Sign up</Text>
      </TouchableOpacity>

      <Animated.View style={[StyleSheet.absoluteFill, { opacity: videoOpacity }]}>
        <Video
          ref={videoRef}
          source={AUTH_PAGES_VIDEO}
          style={styles.videoBackground}
          resizeMode={ResizeMode.COVER}
          shouldPlay
          isLooping
          isMuted
          progressUpdateIntervalMillis={30}
          onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
          onLoad={handleVideoLoad}
        />
      </Animated.View>
      <View pointerEvents="none" style={styles.authVideoShade} />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient colors={[...AUTH_GRADIENT_COLORS]} style={StyleSheet.absoluteFill} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <Animated.View
          style={[styles.contentContainer, styles.loginContentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
        >
          <View style={styles.loginScreenBody}>
            <View style={styles.loginHeroPanel}>
              <View style={styles.loginHero}>
                <Image source={NEW_AUTH_LOGO} resizeMode="contain" style={styles.loginHeroLogo} />
                <Text style={styles.loginHeadline}>Welcome to{'\n'}Wish-a-Wash</Text>
                <Text style={styles.loginSubtext}>Sign in to provide washes.</Text>
              </View>
            </View>

            <View style={styles.loginActionsPanel}>
              <View style={styles.loginCardWrap}>
                <ContinueCTAButton
                  variant="secondary"
                  title="Continue with Email"
                  onPress={openEmailModal}
                  accentColor={colors.SKY}
                  disabled={isLoading}
                  showTrailingChevron={false}
                  leading={<Ionicons name="mail-outline" size={22} color={colors.textOnDarkPrimary} />}
                  style={styles.authGlassCta}
                />

                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <View style={styles.socialIconRow}>
                  {isAppleAvailable && (
                    <TouchableOpacity
                      style={[styles.socialIconButton, styles.socialIconApple]}
                      onPress={handleAppleLogin}
                      activeOpacity={0.9}
                      accessibilityLabel="Continue with Apple"
                    >
                      <Ionicons name="logo-apple" size={24} color="#000000" />
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    style={[
                      styles.socialIconButton,
                      styles.socialIconGoogle,
                      { backgroundColor: 'rgba(255,255,255,0.18)', borderColor: 'rgba(255,255,255,0.18)', opacity: 0.72 },
                    ]}
                    onPress={handleGoogleLogin}
                    activeOpacity={0.9}
                    accessibilityLabel="Continue with Google"
                  >
                    <Ionicons name="logo-google" size={22} color="rgba(255,255,255,0.55)" />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.loginFooter}>
                <View style={styles.trustCopy}>
                  <Text style={styles.trustCopyText}>
                    By continuing, you agree to{' '}
                    <Text style={styles.trustCopyLink} onPress={() => openLink(TERMS_URL)}>
                      Terms
                    </Text>
                    {' & '}
                    <Text style={styles.trustCopyLink} onPress={() => openLink(PRIVACY_URL)}>
                      Privacy Policy
                    </Text>
                  </Text>
                </View>

                <View style={styles.footer}>
                  <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2025</Text>
                </View>
              </View>
            </View>
          </View>
        </Animated.View>
      </KeyboardAvoidingView>

      <Modal
        visible={emailModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEmailModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setEmailModalVisible(false)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalKeyboardAvoid}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={60} tint="dark" style={styles.modalBlur}>
                <ScrollView
                  style={styles.modalScroll}
                  contentContainerStyle={styles.modalScrollContent}
                  keyboardShouldPersistTaps="handled"
                  showsVerticalScrollIndicator={false}
                >
                  <View style={styles.modalInner}>
                    <View style={styles.modalHeader}>
                      <Text style={styles.modalTitle}>Sign in with Email</Text>
                      <TouchableOpacity
                        onPress={() => setEmailModalVisible(false)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Ionicons name="close" size={28} color="rgba(255,255,255,0.9)" />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.userTypeSwitcher}>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('valeter'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'valeter' && styles.userTypeButtonTextActive]}>
                          Car Care Pro
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.userTypeButton, userType === 'business' && styles.userTypeButtonActive]}
                        onPress={() => { setUserType('business'); hapticFeedback('light'); }}
                        activeOpacity={0.7}
                      >
                        <Text style={[styles.userTypeButtonText, userType === 'business' && styles.userTypeButtonTextActive]}>
                          Business
                        </Text>
                      </TouchableOpacity>
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Email address"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={email}
                        onChangeText={setEmail}
                        autoCapitalize="none"
                        keyboardType="email-address"
                        autoComplete="email"
                      />
                    </View>

                    <View style={styles.inputWrapper}>
                      <View style={styles.inputIconContainer}>
                        <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                      </View>
                      <TextInput
                        style={styles.input}
                        placeholder="Password"
                        placeholderTextColor={colors.inputPlaceholder}
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        autoComplete="password"
                      />
                    </View>

                    <WWPrimaryButton
                      title={isLoading ? 'Signing in…' : 'Continue'}
                      onPress={() => handleLogin()}
                      disabled={isLoading}
                      loading={isLoading}
                      style={styles.loginButton}
                    />

                    <TouchableOpacity style={styles.forgotPasswordLink} onPress={handleForgotPassword}>
                      <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                    </TouchableOpacity>
                  </View>
                </ScrollView>
              </BlurView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  ...sharedAuthStyleDefs,
  loginContentContainer: {
    flex: 1,
  },
  loginScreenBody: {
    flex: 1,
    paddingTop: Platform.OS === 'ios' ? 58 : 44,
    paddingBottom: Platform.OS === 'ios' ? 12 : 10,
  },
  loginHeroPanel: {
    flex: 0.52,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 56,
    paddingBottom: 0,
  },
  loginHero: {
    alignItems: 'center',
    justifyContent: 'center',
    maxWidth: 330,
  },
  loginHeroLogo: {
    width: 560,
    height: 352,
  },
  loginHeadline: {
    marginTop: 2,
    fontSize: 32,
    lineHeight: 36,
    letterSpacing: -0.9,
    color: 'rgba(255,255,255,0.98)',
    textAlign: 'center',
    fontWeight: '700',
  },
  loginSubtext: {
    marginTop: 4,
    fontSize: 15,
    lineHeight: 21,
    color: 'rgba(255,255,255,0.74)',
    textAlign: 'center',
    fontWeight: '500',
    maxWidth: 300,
  },
  loginActionsPanel: {
    flex: 0.48,
    justifyContent: 'flex-end',
    paddingTop: 58,
    paddingBottom: 0,
  },
  loginCardWrap: {
    justifyContent: 'flex-start',
    width: '100%',
    paddingHorizontal: 16,
  },
  loginFooter: {
    paddingTop: 26,
    paddingBottom: 0,
  },
  authGlassCta: { marginBottom: 0 },
  socialIconRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
  },
  socialIconButton: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  socialIconApple: { backgroundColor: '#FFFFFF' },
  socialIconGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  authVideoShade: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.18)',
  },
  forgotPasswordLink: { alignSelf: 'center', marginTop: 16, marginBottom: 0 },
  forgotPasswordText: { color: '#87CEEB', fontWeight: '600' },
  loginButton: { marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalKeyboardAvoid: { width: '100%', maxHeight: '92%' },
  modalContent: { maxHeight: '92%', borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden' },
  modalBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    maxHeight: '100%',
  },
  modalScroll: { maxHeight: '100%' },
  modalScrollContent: { padding: 24, paddingBottom: 40 },
  modalInner: { padding: 0 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: 'rgba(255,255,255,0.95)' },
  userTypeSwitcher: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    padding: 3,
    marginBottom: 16,
    gap: 4,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userTypeButtonActive: { backgroundColor: '#237AE6' },
  userTypeButtonText: { fontSize: 14, fontWeight: '600', color: 'rgba(255,255,255,0.7)' },
  userTypeButtonTextActive: { color: '#FFFFFF', fontWeight: '700' },
  saveBiometricLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    paddingVertical: 8,
  },
  saveBiometricText: { fontSize: 13, color: '#87CEEB', fontWeight: '600' },
});
