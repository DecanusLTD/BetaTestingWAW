/**
 * Terms of Service — magical interactive rulebook with the Wish a Wash magician.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Image,
  Animated,
  Easing,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../src/components/shared/ChromeGlyph';
import type { IconGlyphName } from '../src/components/shared/iconGlyphTypes';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import ValeterScreenHeader from '../src/components/valeter/ValeterScreenHeader';
import BubbleBackground from '../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../src/components/shared/AccountThemeProvider';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme, type AccountType } from '../src/constants/accountThemes';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { ICON } from '../src/constants/appAssetExports';
import { VALETER_CONTENT_BOTTOM_PAD } from '../src/components/valeter/ValeterNavSidebar';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const CONTACT_EMAIL = 'Admin@wishawashapp.com';
const ONBOARDING_EMAIL = 'Admin@wishawashapp.com';
const SPARKLE_COLORS = ['#E8C547', '#FFE08A', '#9EC9E0', '#FFFFFF', '#F59E0B'];

type TermChapter = {
  id: string;
  number: string;
  title: string;
  icon: IconGlyphName;
  emphasis?: 'important' | 'strict';
  paragraphs: string[];
  bullets?: string[];
  emails?: { label: string; email: string; icon: IconGlyphName }[];
};

const CHAPTERS: TermChapter[] = [
  {
    id: '1',
    number: '01',
    title: 'Acceptance of Terms',
    icon: 'checkmark-circle',
    paragraphs: [
      'By accessing or using Wish a Wash ("the Platform", "we", "us", or "our"), you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use our service.',
    ],
  },
  {
    id: '2',
    number: '02',
    title: 'Platform Nature',
    icon: 'globe',
    paragraphs: [
      'Wish a Wash is a technology platform and internet marketplace that connects customers with independent service providers (car care pros and car wash businesses). We provide a digital platform that facilitates bookings, payments, and communication between users and service providers.',
      'We do not provide car wash or valeting services directly. All services are provided by independent third-party service providers who are not employees, agents, or representatives of Wish a Wash.',
    ],
  },
  {
    id: '3',
    number: '03',
    title: 'Limitation of Liability & Damage Disclaimer',
    icon: 'shield',
    emphasis: 'important',
    paragraphs: [
      'IMPORTANT: Wish a Wash acts solely as an intermediary technology platform. We do not take responsibility for any damage, loss, or injury that car care pros or car wash businesses may cause to your vehicle, property, or person.',
      'Any claims for damage, loss, or injury must be directed to the service provider who performed the service. Service providers are independent contractors and are solely responsible for their work, conduct, and any damage they may cause.',
      'To the maximum extent permitted by law, Wish a Wash, its directors, employees, and affiliates shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the Platform or services provided by third parties.',
    ],
  },
  {
    id: '4',
    number: '04',
    title: 'Payment Processing & Security',
    icon: 'wallet-outline',
    paragraphs: [
      'All payments are processed securely through Stripe, a globally recognised payment processor that complies with PCI DSS (Payment Card Industry Data Security Standard) Level 1, the highest level of certification in the payments industry.',
      'Stripe uses industry-standard encryption and security measures to protect your payment information. We do not store your full card details on our servers. All payment data is encrypted in transit using TLS (Transport Layer Security) and at rest.',
      "By using our Platform, you authorise Stripe to process payments on our behalf. Stripe's terms of service and privacy policy apply to payment processing. You can review Stripe's security practices at stripe.com/security.",
    ],
  },
  {
    id: '5',
    number: '05',
    title: 'Prohibited Conduct - Customer Poaching',
    icon: 'ban',
    emphasis: 'strict',
    paragraphs: [
      'STRICT PROHIBITION: Service providers (car care pros and car wash businesses) are strictly prohibited from directly contacting, soliciting, or accepting bookings from customers they have met through the Wish a Wash platform outside of the Platform.',
      'If a service provider is found to have stolen, poached, or diverted even one customer from our Platform to conduct business directly (bypassing the Platform), the following penalties apply:',
      'This prohibition applies to all forms of direct contact including but not limited to: phone calls, text messages, email, social media, or in-person arrangements made outside the Platform.',
    ],
    bullets: [
      'Immediate and permanent lifetime ban from the Wish a Wash platform',
      'Payment of all earnings received through the Platform, OR',
      'Payment of a flat rate fee of £20,000 (whichever is greater)',
      'Legal action may be pursued for breach of contract and damages',
    ],
  },
  {
    id: '6',
    number: '06',
    title: 'User Responsibilities',
    icon: 'people',
    paragraphs: ['You are responsible for:'],
    bullets: [
      'Providing accurate information (vehicle details, contact information)',
      'Maintaining account security and password confidentiality',
      'Treating service providers and other users with respect',
      'Being at least 18 years old to use our service',
      'Ensuring your vehicle is accessible for service at the scheduled time',
      'Complying with all applicable laws and regulations',
    ],
  },
  {
    id: '7',
    number: '07',
    title: 'Cancellation Policy',
    icon: 'close-circle',
    paragraphs: ['Cancellation terms:'],
    bullets: [
      'Free cancellation up to 2 hours before scheduled time',
      'Cancellations within 2 hours may incur charges',
      'Service provider cancellations entitle you to a full refund',
      'No-show charges may apply if service provider arrives and service cannot be performed',
    ],
  },
  {
    id: '8',
    number: '08',
    title: 'Contact & Support',
    icon: 'mail',
    paragraphs: [
      'For general support, help, or inquiries:',
      'For business onboarding, partnership inquiries, or service provider applications:',
    ],
    emails: [
      { label: 'General support', email: CONTACT_EMAIL, icon: 'mail-outline' },
      { label: 'Onboarding & partnerships', email: ONBOARDING_EMAIL, icon: 'business-outline' },
    ],
  },
  {
    id: '9',
    number: '09',
    title: 'Modifications to Terms',
    icon: 'document',
    paragraphs: [
      'We reserve the right to modify these Terms of Service at any time. We will notify users of significant changes via email or through the Platform. Continued use of the Platform after changes constitutes acceptance of the modified terms.',
    ],
  },
  {
    id: '10',
    number: '10',
    title: 'Governing Law',
    icon: 'scale',
    paragraphs: [
      'These Terms of Service are governed by and construed in accordance with the laws of England and Wales. Any disputes arising from these terms or your use of the Platform shall be subject to the exclusive jurisdiction of the courts of England and Wales.',
    ],
  },
];

type SparkleSpec = {
  id: string;
  x: Animated.Value;
  y: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  rotate: Animated.Value;
  color: string;
  size: number;
};

function MagicSparkles({ burstKey }: Readonly<{ burstKey: number }>) {
  const sparkles = useRef<SparkleSpec[]>([]);
  const [, force] = useState(0);

  useEffect(() => {
    if (burstKey <= 0) return;

    const next: SparkleSpec[] = Array.from({ length: 12 }, (_, i) => ({
      id: `${burstKey}-${i}`,
      x: new Animated.Value(0),
      y: new Animated.Value(0),
      opacity: new Animated.Value(1),
      scale: new Animated.Value(0.2),
      rotate: new Animated.Value(0),
      color: SPARKLE_COLORS[i % SPARKLE_COLORS.length],
      size: 5 + (i % 4) * 2,
    }));

    sparkles.current = next;
    force((n) => n + 1);

    next.forEach((s, i) => {
      const angle = (Math.PI * 2 * i) / 12 + Math.random() * 0.3;
      const dist = 44 + Math.random() * 70;
      Animated.parallel([
        Animated.timing(s.x, {
          toValue: Math.cos(angle) * dist,
          duration: 700 + Math.random() * 260,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(s.y, {
          toValue: Math.sin(angle) * dist - 18,
          duration: 700 + Math.random() * 260,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.sequence([
          Animated.timing(s.scale, { toValue: 1.1, duration: 200, useNativeDriver: true }),
          Animated.timing(s.scale, { toValue: 0, duration: 480, useNativeDriver: true }),
        ]),
        Animated.timing(s.opacity, { toValue: 0, duration: 880, useNativeDriver: true }),
        Animated.timing(s.rotate, { toValue: 1, duration: 880, useNativeDriver: true }),
      ]).start();
    });
  }, [burstKey]);

  return (
    <View pointerEvents="none" style={styles.sparkleLayer}>
      {sparkles.current.map((s) => {
        const spin = s.rotate.interpolate({
          inputRange: [0, 1],
          outputRange: ['0deg', '160deg'],
        });
        return (
          <Animated.View
            key={s.id}
            style={[
              styles.sparkle,
              {
                width: s.size,
                height: s.size,
                backgroundColor: s.color,
                opacity: s.opacity,
                transform: [
                  { translateX: s.x },
                  { translateY: s.y },
                  { scale: s.scale },
                  { rotate: spin },
                ],
              },
            ]}
          />
        );
      })}
    </View>
  );
}

function MagicianHero({
  accent,
  gold,
  spinSignal,
  lastUpdated,
}: Readonly<{ accent: string; gold: string; spinSignal: number; lastUpdated: string }>) {
  const float = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const glow = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const bob = Animated.loop(
      Animated.sequence([
        Animated.timing(float, {
          toValue: 1,
          duration: 1900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(float, {
          toValue: 0,
          duration: 1900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    const shimmer = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 1500, useNativeDriver: true }),
        Animated.timing(glow, { toValue: 0, duration: 1500, useNativeDriver: true }),
      ])
    );
    bob.start();
    shimmer.start();
    return () => {
      bob.stop();
      shimmer.stop();
    };
  }, [float, glow]);

  useEffect(() => {
    if (spinSignal <= 0) return;
    spin.setValue(0);
    Animated.timing(spin, {
      toValue: 1,
      duration: 760,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [spinSignal, spin]);

  return (
    <View style={styles.hero}>
      <Animated.View
        style={[
          styles.heroIconWrap,
          {
            transform: [
              {
                translateY: float.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, -10],
                }),
              },
              {
                rotate: spin.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0deg', '360deg'],
                }),
              },
            ],
          },
        ]}
      >
        <Image source={ICON} style={styles.heroIcon} resizeMode="contain" />
      </Animated.View>
      <Text style={styles.heroTitle}>The rulebook</Text>
      <Text style={styles.heroSubtitle}>Tap a chapter — the magician reveals the fine print</Text>
      <Text style={[styles.lastUpdated, { color: gold }]}>Updated {lastUpdated}</Text>
    </View>
  );
}

function renderChapterBody(
  chapter: TermChapter,
  accent: string,
  gold: string,
  onEmail: (email: string) => void
) {
  if (chapter.id === '8' && chapter.emails) {
    return (
      <>
        <Text style={styles.chapterText}>{chapter.paragraphs[0]}</Text>
        <TouchableOpacity
          style={[styles.emailButton, { borderColor: `${accent}44` }]}
          onPress={() => onEmail(chapter.emails![0].email)}
        >
          <Ionicons name={chapter.emails[0].icon} size={16} color={accent} />
          <View style={styles.emailCopy}>
            <Text style={styles.emailLabel}>{chapter.emails[0].label}</Text>
            <Text style={[styles.emailText, { color: accent }]}>{chapter.emails[0].email}</Text>
          </View>
        </TouchableOpacity>
        <Text style={[styles.chapterText, { marginTop: 12 }]}>{chapter.paragraphs[1]}</Text>
        <TouchableOpacity
          style={[styles.emailButton, { borderColor: `${accent}44` }]}
          onPress={() => onEmail(chapter.emails![1].email)}
        >
          <Ionicons name={chapter.emails[1].icon} size={16} color={accent} />
          <View style={styles.emailCopy}>
            <Text style={styles.emailLabel}>{chapter.emails[1].label}</Text>
            <Text style={[styles.emailText, { color: accent }]}>{chapter.emails[1].email}</Text>
          </View>
        </TouchableOpacity>
      </>
    );
  }

  if (chapter.id === '5' && chapter.bullets) {
    return (
      <>
        <Text style={styles.chapterText}>{chapter.paragraphs[0]}</Text>
        <Text style={[styles.chapterText, { marginTop: 10 }]}>{chapter.paragraphs[1]}</Text>
        <View style={styles.bulletList}>
          {chapter.bullets.map((b) => (
            <View key={b} style={styles.bulletRow}>
              <Text style={[styles.bulletDot, { color: gold }]}>✦</Text>
              <Text style={styles.bulletText}>{b}</Text>
            </View>
          ))}
        </View>
        <Text style={[styles.chapterText, { marginTop: 10 }]}>{chapter.paragraphs[2]}</Text>
      </>
    );
  }

  return (
    <>
      {chapter.paragraphs.map((p, idx) => (
        <Text key={`${chapter.id}-p-${idx}`} style={[styles.chapterText, idx > 0 && { marginTop: 10 }]}>
          {p}
        </Text>
      ))}
      {chapter.bullets ? (
        <View style={styles.bulletList}>
          {chapter.bullets.map((b) => (
            <View key={b} style={styles.bulletRow}>
              <Text style={[styles.bulletDot, { color: gold }]}>✦</Text>
              <Text style={styles.bulletText}>{b}</Text>
            </View>
          ))}
        </View>
      ) : null}
    </>
  );
}

function TermChapterCard({
  chapter,
  open,
  accent,
  gold,
  onPress,
  onEmail,
}: Readonly<{
  chapter: TermChapter;
  open: boolean;
  accent: string;
  gold: string;
  onPress: () => void;
  onEmail: (email: string) => void;
}>) {
  const flip = useRef(new Animated.Value(open ? 1 : 0)).current;
  const wobble = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(flip, {
      toValue: open ? 1 : 0,
      friction: 7,
      tension: 80,
      useNativeDriver: true,
    }).start();

    if (open) {
      Animated.sequence([
        Animated.timing(wobble, { toValue: 1, duration: 110, useNativeDriver: true }),
        Animated.timing(wobble, { toValue: -1, duration: 110, useNativeDriver: true }),
        Animated.timing(wobble, { toValue: 0, duration: 110, useNativeDriver: true }),
      ]).start();
    }
  }, [open, flip, wobble]);

  const borderColor = open
    ? chapter.emphasis === 'strict'
      ? 'rgba(248,113,113,0.55)'
      : chapter.emphasis === 'important'
        ? `${gold}88`
        : `${accent}77`
    : 'rgba(255,255,255,0.12)';

  const bg = open
    ? chapter.emphasis === 'strict'
      ? 'rgba(248,113,113,0.1)'
      : chapter.emphasis === 'important'
        ? 'rgba(232,197,71,0.1)'
        : 'rgba(158,201,224,0.1)'
    : 'rgba(255,255,255,0.06)';

  return (
    <Animated.View
      style={[
        styles.chapterCard,
        {
          borderColor,
          backgroundColor: bg,
          transform: [
            {
              rotateZ: wobble.interpolate({
                inputRange: [-1, 0, 1],
                outputRange: ['-2deg', '0deg', '2deg'],
              }),
            },
            {
              scale: flip.interpolate({
                inputRange: [0, 1],
                outputRange: [1, 1.012],
              }),
            },
          ],
        },
      ]}
    >
      <TouchableOpacity onPress={onPress} activeOpacity={0.88} style={styles.chapterTouchable}>
        <View style={styles.chapterHeader}>
          <View style={[styles.chapterBadge, { backgroundColor: open ? `${gold}30` : `${accent}22` }]}>
            <Text style={[styles.chapterNumber, { color: open ? gold : accent }]}>{chapter.number}</Text>
          </View>
          <View style={styles.chapterTitleWrap}>
            <View style={styles.chapterTitleRow}>
              <Ionicons name={chapter.icon} size={16} color={open ? gold : accent} />
              <Text style={[styles.chapterTitle, open && { color: '#FFF8E7' }]} numberOfLines={2}>
                {chapter.title}
              </Text>
            </View>
            {chapter.emphasis ? (
              <Text
                style={[
                  styles.emphasisTag,
                  { color: chapter.emphasis === 'strict' ? '#FCA5A5' : gold },
                ]}
              >
                {chapter.emphasis === 'strict' ? 'STRICT RULE' : 'IMPORTANT'}
              </Text>
            ) : null}
          </View>
          <Animated.View
            style={{
              transform: [
                {
                  rotate: flip.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0deg', '180deg'],
                  }),
                },
              ],
            }}
          >
            <Ionicons name="chevron-down" size={18} color={open ? gold : accent} />
          </Animated.View>
        </View>

        {open ? (
          <View style={styles.chapterBody}>
            <View style={[styles.chapterRule, { backgroundColor: `${gold}40` }]} />
            {renderChapterBody(chapter, accent, gold, onEmail)}
          </View>
        ) : null}
      </TouchableOpacity>
    </Animated.View>
  );
}

export default function TermsOfService() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const accountContext = useAccountTheme();

  const accountType: AccountType =
    user?.userType === 'organization' ? 'business' : 'valeter';

  const theme = accountContext.theme ?? getAccountTheme(accountType);
  const accent = theme.primary || '#9EC9E0';
  const gold = theme.accentAlt || '#E8C547';
  const gradientBg = (theme.background || ['#6A9BB0', '#2A4660']) as [string, string];

  const [openId, setOpenId] = useState<string | null>(null);
  const [spinSignal, setSpinSignal] = useState(0);
  const [burstKey, setBurstKey] = useState(0);

  const lastUpdated = useMemo(
    () =>
      new Date().toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      }),
    []
  );

  const castChapter = useCallback(
    async (id: string) => {
      await hapticFeedback('medium');
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      const opening = openId !== id;
      setOpenId(opening ? id : null);
      if (opening) {
        setSpinSignal((n) => n + 1);
        setBurstKey((n) => n + 1);
      }
    },
    [openId]
  );

  const handleEmail = (email: string) => {
    Linking.openURL(`mailto:${email}`);
  };

  const bottomPad =
    accountType === 'valeter'
      ? VALETER_CONTENT_BOTTOM_PAD + insets.bottom + 20
      : insets.bottom + 40;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={gradientBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType={accountType} bubbleCount={5} />

      {accountType === 'valeter' ? (
        <ValeterScreenHeader
          title="Terms & Conditions"
          subtitle="Wish a Washer App"
        />
      ) : (
        <AppHeader
          title="Terms & Conditions"
          subtitle="Wish a Washer App"
          accountType="business"
          fullWidth
          flushTop
        />
      )}

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + HEADER_HEIGHT + 16,
            paddingBottom: bottomPad,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.stage}>
          <MagicianHero
            accent={accent}
            gold={gold}
            spinSignal={spinSignal}
            lastUpdated={lastUpdated}
          />
          <View style={styles.burstAnchor} pointerEvents="none">
            <MagicSparkles burstKey={burstKey} />
          </View>
        </View>

        <Text style={[styles.sectionEyebrow, { color: gold }]}>CHAPTERS</Text>
        <Text style={styles.sectionTitle}>Tap to reveal</Text>

        <View style={styles.chapterList}>
          {CHAPTERS.map((chapter) => (
            <TermChapterCard
              key={chapter.id}
              chapter={chapter}
              open={openId === chapter.id}
              accent={accent}
              gold={gold}
              onPress={() => castChapter(chapter.id)}
              onEmail={handleEmail}
            />
          ))}
        </View>

        <View style={styles.footer}>
          <Image source={ICON} style={styles.footerIcon} resizeMode="contain" />
          <Text style={styles.footerTitle}>Wish a Washer App</Text>
          <Text style={styles.footerSub}>Fair magic. Clear rules.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 20,
  },
  stage: {
    alignItems: 'center',
    marginBottom: 22,
    minHeight: 210,
  },
  burstAnchor: {
    position: 'absolute',
    top: 70,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  sparkleLayer: {
    width: 1,
    height: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sparkle: {
    position: 'absolute',
    borderRadius: 1,
    shadowColor: '#E8C547',
    shadowOpacity: 0.75,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 0 },
  },
  hero: {
    alignItems: 'center',
    paddingTop: 4,
  },
  heroIconWrap: {
    width: 108,
    height: 108,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  heroIcon: {
    width: 108,
    height: 108,
    borderRadius: 24,
  },
  heroTitle: {
    marginTop: 14,
    color: '#F8FAFC',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.7,
  },
  heroSubtitle: {
    marginTop: 6,
    color: 'rgba(248,250,252,0.68)',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 20,
    lineHeight: 20,
  },
  lastUpdated: {
    marginTop: 10,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  sectionEyebrow: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.6,
    marginBottom: 4,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 14,
    letterSpacing: -0.3,
  },
  chapterList: {
    gap: 12,
  },
  chapterCard: {
    borderRadius: 18,
    borderWidth: 1,
    overflow: 'hidden',
  },
  chapterTouchable: {
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  chapterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  chapterBadge: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chapterNumber: {
    fontSize: 13,
    fontWeight: '900',
    letterSpacing: 0.4,
  },
  chapterTitleWrap: {
    flex: 1,
    gap: 2,
  },
  chapterTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  chapterTitle: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  emphasisTag: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.1,
    marginTop: 2,
  },
  chapterBody: {
    marginTop: 12,
    paddingLeft: 50,
  },
  chapterRule: {
    height: 1,
    marginBottom: 12,
    borderRadius: 1,
  },
  chapterText: {
    color: 'rgba(248,250,252,0.8)',
    fontSize: 14,
    lineHeight: 21,
  },
  bulletList: {
    marginTop: 10,
    gap: 8,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  bulletDot: {
    fontSize: 11,
    marginTop: 3,
  },
  bulletText: {
    flex: 1,
    color: 'rgba(248,250,252,0.78)',
    fontSize: 13,
    lineHeight: 19,
  },
  emailButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  emailCopy: {
    flex: 1,
  },
  emailLabel: {
    color: 'rgba(248,250,252,0.55)',
    fontSize: 11,
    fontWeight: '700',
  },
  emailText: {
    fontSize: 14,
    fontWeight: '700',
    marginTop: 1,
  },
  footer: {
    alignItems: 'center',
    paddingTop: 28,
    paddingBottom: 8,
    gap: 4,
  },
  footerIcon: {
    width: 40,
    height: 40,
    marginBottom: 4,
  },
  footerTitle: {
    color: 'rgba(248,250,252,0.62)',
    fontSize: 13,
    fontWeight: '700',
  },
  footerSub: {
    color: 'rgba(248,250,252,0.4)',
    fontSize: 12,
  },
});
