import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import dvlaService from '../../../src/services/DVLAService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function VehicleManagement() {
  const { user } = useAuth();
    const [loading, setLoading] = useState(true);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    type: '',
    make: '',
    model: '',
    color: '',
    registration: '',
  });
  const [dvlaLoading, setDvlaLoading] = useState(false);
  const lookupTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  // Handle DVLA lookup when registration is entered
  const handleRegistrationChange = async (registration: string) => {
    // Clean registration: uppercase and remove spaces (consistent with DVLA service)
    const cleanRegistration = registration.replace(/\s/g, '').toUpperCase();
    
    // Update form data immediately
    setFormData((prev) => ({ ...prev, registration: cleanRegistration }));

    // Clear previous timeout
    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
    }

    // Validate registration format
    const validation = dvlaService.validateRegistration(cleanRegistration);
    if (!validation.isValid) {
      return; // Don't lookup if format is invalid
    }

    // Debounce the lookup - wait 1 second after user stops typing
    lookupTimeoutRef.current = setTimeout(async () => {
      setDvlaLoading(true);
      try {
        const result = await dvlaService.getVehicleDetails(cleanRegistration);
        
        if (result.success && result.data) {
          // Auto-fill form with DVLA data
          const vehicleType = dvlaService.inferVehicleType(
            result.data.make,
            result.data.model || ''
          );
          
          setFormData((prev) => ({
            ...prev,
            registration: result.data!.registrationNumber,
            make: result.data!.make,
            model: result.data!.model || '',
            color: result.data!.colour || '',
            type: vehicleType,
          }));
        } else {
          // Show error if lookup failed (but don't block user from continuing)
          if (result.error && !result.error.includes('mock')) {
            console.warn('[Vehicle Management] DVLA lookup failed:', result.error);
          }
        }
      } catch (error: any) {
        console.error('[Vehicle Management] DVLA lookup error:', error);
      } finally {
        setDvlaLoading(false);
      }
    }, 1000);
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (lookupTimeoutRef.current) {
        clearTimeout(lookupTimeoutRef.current);
      }
    };
  }, []);

  const handleAddVehicle = async () => {
    if (!user?.id) return;
    if (!formData.make || !formData.model || !formData.registration) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    try {
      const { error } = await supabase.from('customer_vehicles').insert({
        user_id: user.id,
        type: formData.type || 'Car',
        make: formData.make,
        model: formData.model,
        color: formData.color,
        registration: formData.registration,
        is_default: vehicles.length === 0,
      });

      if (error) throw error;
      setShowModal(false);
      setFormData({ type: '', make: '', model: '', color: '', registration: '' });
      setDvlaLoading(false);
      loadVehicles();
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to add vehicle');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="My Vehicles"
        rightAction={
          <TouchableOpacity onPress={() => setShowModal(true)} style={styles.addButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {vehicles.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="car-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Vehicles</Text>
            <Text style={styles.emptySubtitle}>Add your first vehicle to get started</Text>
            <TouchableOpacity
              style={styles.addButtonCard}
              onPress={() => setShowModal(true)}
            >
              <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.addButtonGradient}>
                <Ionicons name="add" size={20} color="#0A1929" />
                <Text style={styles.addButtonText}>Add Vehicle</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          vehicles.map((vehicle) => (
            <View key={vehicle.id} style={styles.vehicleCard}>
              <View style={styles.vehicleIconWrapper}>
                <Ionicons name="car" size={28} color={SKY} />
              </View>
              <View style={styles.vehicleContent}>
                <View style={styles.vehicleHeader}>
                  <Text style={styles.vehicleName}>
                    {vehicle.make} {vehicle.model}
                  </Text>
                  {vehicle.is_default && (
                    <View style={styles.defaultBadge}>
                      <Text style={styles.defaultText}>Default</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.vehicleReg}>{vehicle.registration}</Text>
                <Text style={styles.vehicleMeta}>
                  {vehicle.type} • {vehicle.color}
                </Text>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* Add Vehicle Modal */}
      <Modal visible={showModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Vehicle</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <Ionicons name="close" size={24} color="#F9FAFB" />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Make *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.make}
                  onChangeText={(text) => setFormData({ ...formData, make: text })}
                  placeholder="Auto-filled from DVLA lookup"
                  placeholderTextColor="#6B7280"
                  editable={!dvlaLoading}
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Model *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.model}
                  onChangeText={(text) => setFormData({ ...formData, model: text })}
                  placeholder="Auto-filled from DVLA lookup"
                  placeholderTextColor="#6B7280"
                  editable={!dvlaLoading}
                />
              </View>
              <View style={styles.inputGroup}>
                <View style={styles.inputLabelRow}>
                  <Text style={styles.inputLabel}>Registration *</Text>
                  {dvlaLoading && (
                    <View style={styles.lookupIndicator}>
                      <ActivityIndicator size="small" color={SKY} />
                      <Text style={styles.lookupText}>Looking up...</Text>
                    </View>
                  )}
                </View>
                <TextInput
                  style={styles.input}
                  value={formData.registration}
                  onChangeText={handleRegistrationChange}
                  placeholder="Enter UK registration (e.g., AB12 CDE)"
                  placeholderTextColor="#6B7280"
                  autoCapitalize="characters"
                  editable={!dvlaLoading}
                />
                <Text style={styles.inputHint}>
                  Enter your UK vehicle registration number and we'll automatically fill in the make, model, and colour from DVLA
                </Text>
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Colour</Text>
                <TextInput
                  style={styles.input}
                  value={formData.color}
                  onChangeText={(text) => setFormData({ ...formData, color: text })}
                  placeholder="Auto-filled from DVLA lookup"
                  placeholderTextColor="#6B7280"
                  editable={!dvlaLoading}
                />
              </View>
              <TouchableOpacity style={styles.saveButton} onPress={handleAddVehicle}>
                <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveButtonGradient}>
                  <Text style={styles.saveButtonText}>Save Vehicle</Text>
                </LinearGradient>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  addButtonCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  addButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
  vehicleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  vehicleIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  vehicleContent: {
    flex: 1,
  },
  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginRight: 8,
  },
  defaultBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 2,
    paddingHorizontal: 8,
    borderRadius: 6,
  },
  defaultText: {
    color: '#059669',
    fontSize: 11,
    fontWeight: '700',
  },
  vehicleReg: {
    color: '#1E3A8A',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleMeta: {
    color: '#1E3A8A',
    fontSize: 13,
    opacity: 0.8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  modalBody: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    color: '#1E3A8A',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  inputLabelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  lookupIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  lookupText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '500',
  },
  inputHint: {
    color: '#6B7280',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  saveButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});

