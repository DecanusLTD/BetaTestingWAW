import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../../../src/lib/supabase';
import { ecoServiceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { generateTimeSlots } from '../../../../src/utils/timeSlots';

const SKY = colors.SKY;
const ECO_GREEN = colors.ECO_GREEN;
const BG = colors.BG;
const { width } = Dimensions.get('window');

export default function EcoSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ locationId?: string; serviceId?: string; vehicleId?: string; washType?: string }>();
  const locationId = params.locationId as string | undefined;
  const incomingServiceId = params.serviceId as string | undefined;
  const vehicleId = params.vehicleId as string | undefined;
  const washType = params.washType as string | undefined;
  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const serviceId = incomingServiceId || null;
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const timeSlots = useMemo(() => generateTimeSlots(), []);
  const service = ecoServiceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    if (!locationId) return;
    const loadHub = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address')
        .eq('id', locationId)
        .maybeSingle();
      if (!error && data) {
        setHub(data);
      } else {
        setHub(null);
      }
      setLoading(false);
    };
    loadHub();
  }, [locationId]);

  const handleContinue = async () => {
    if (!serviceId || !selectedSlot || !locationId) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/eco/confirm',
      params: {
        locationId,
        serviceId,
        vehicleId: vehicleId || '',
        washType: washType || '',
        scheduledAt: selectedSlot,
      },
    });
  };

  if (!locationId || !serviceId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient colors={[BG, '#065F46']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Pick eco service & time" />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={ECO_GREEN} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]} showsVerticalScrollIndicator={false}>
          {hub && (
            <View style={styles.hubSummary}>
              <View style={styles.ecoBadge}>
                <Ionicons name="leaf" size={14} color={ECO_GREEN} />
                <Text style={styles.ecoBadgeText}>Eco-Friendly</Text>
              </View>
              <Text style={styles.hubLabel}>Location</Text>
              <Text style={styles.hubName}>{hub.name}</Text>
              <Text style={styles.hubAddress}>{hub.address}</Text>
            </View>
          )}

          {service && (
            <View style={styles.serviceSummary}>
              <View style={styles.serviceHeader}>
                <Ionicons name={service.icon as any} size={24} color={ECO_GREEN} />
                <Text style={styles.serviceName}>{service.name}</Text>
              </View>
              <Text style={styles.serviceDesc}>{service.desc}</Text>
              <View style={styles.serviceMeta}>
                <View style={styles.metaItem}>
                  <Ionicons name="time-outline" size={14} color={ECO_GREEN} />
                  <Text style={styles.metaText}>{service.dur}</Text>
                </View>
                <Text style={styles.servicePrice}>£{service.price}</Text>
              </View>
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose a time slot</Text>
            <View style={styles.slotGrid}>
              {timeSlots.map((slot) => {
                const date = new Date(slot);
                const isSelected = selectedSlot === slot;
                return (
                  <TouchableOpacity
                    key={slot}
                    style={[styles.slotCard, isSelected && styles.slotCardSelected]}
                    onPress={() => setSelectedSlot(slot)}
                    activeOpacity={0.85}
                  >
                    <Text style={styles.slotDay}>
                      {date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}
                    </Text>
                    <Text style={styles.slotTime}>
                      {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        </ScrollView>
      )}

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[
            styles.continueButton,
            (!serviceId || !selectedSlot) && { opacity: 0.5 },
          ]}
          disabled={!serviceId || !selectedSlot}
          onPress={handleContinue}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={[ECO_GREEN, '#059669']}
            style={styles.continueGradient}
          >
            <Text style={styles.continueText}>Continue</Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 120,
    gap: 24,
  },
  hubSummary: {
    backgroundColor: 'rgba(16,185,129,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.2)',
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  ecoBadgeText: {
    color: ECO_GREEN,
    fontSize: 11,
    fontWeight: '700',
  },
  hubLabel: {
    color: 'rgba(16,185,129,0.8)',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  hubName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  hubAddress: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    marginTop: 4,
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  serviceSummary: {
    backgroundColor: 'rgba(16,185,129,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.2)',
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    marginBottom: 10,
  },
  serviceMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    color: '#E5E7EB',
    fontSize: 13,
  },
  servicePrice: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 18,
  },
  slotGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  slotCard: {
    width: (width - 20 * 2 - 12) / 2,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    paddingVertical: 12,
    paddingHorizontal: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  slotCardSelected: {
    borderColor: ECO_GREEN,
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  slotDay: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  slotTime: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 2,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

