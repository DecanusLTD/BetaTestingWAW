import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { generateTimeSlots } from '../../../../src/utils/timeSlots';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../app/components/NavigationTab';

const SKY = colors.SKY;
const BG = colors.BG;
const LIGHT_SKY = colors.LIGHT_SKY;
const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SLOT_WIDTH = 140;

export default function PhysicalSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
  }>();

  const locationId = params.locationId as string | undefined;
  const serviceId = params.serviceId as string | undefined;
  const vehicleId = params.vehicleId as string | undefined;
  const washType = params.washType as string | undefined;

  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const timeSlots = useMemo(() => generateTimeSlots(), []);
  const service = serviceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    if (!locationId) return;

    const loadHub = async () => {
      setLoading(true);
      const { data } = await supabase
        .from('car_wash_locations')
        .select('id,name,address')
        .eq('id', locationId)
        .maybeSingle();

      setHub(data ?? null);
      setLoading(false);
    };

    loadHub();
  }, [locationId]);

  const handleContinue = async () => {
    if (!serviceId || !selectedSlot || !locationId || !vehicleId) return;
    await hapticFeedback('medium');

    router.push({
      pathname: '/owner/booking/physical/confirm',
      params: {
        locationId,
        serviceId,
        vehicleId,
        washType: washType || '',
        scheduledAt: selectedSlot,
      },
    });
  };

  if (!locationId || !serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const getServiceIcon = () => {
    const name = (service?.name || '').toLowerCase();
    if (name.includes('interior')) return 'car-sport-outline';
    if (name.includes('detail')) return 'sparkles-outline';
    if (name.includes('premium')) return 'diamond-outline';
    if (name.includes('wash')) return 'water-outline';
    return 'pricetag-outline';
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Pick time slot" />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + 120,
            },
          ]}
        >
          {/* Location */}
          {hub && (
            <GlassCard style={styles.hubSummary} accountType="customer">
              <Text style={styles.label}>Location</Text>
              <Text style={styles.title}>{hub.name}</Text>
              <Text style={styles.sub}>{hub.address}</Text>
            </GlassCard>
          )}

          {/* Service */}
          {service && (
            <GlassCard style={styles.serviceCard} accountType="customer">
              <View style={styles.serviceHeader}>
                <View style={styles.iconWrap}>
                  <Ionicons name={getServiceIcon() as any} size={18} color={SKY} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Service</Text>
                  <Text style={styles.title}>{service.name}</Text>
                </View>
                <View style={styles.pricePill}>
                  <Text style={styles.priceText}>£{service.price}</Text>
                </View>
              </View>

              <Text style={styles.sub}>{service.desc}</Text>

              <View style={styles.metaRow}>
                <Text style={styles.meta}>⏱ {service.dur}</Text>
                {washType && <Text style={styles.meta}>🌱 {washType}</Text>}
              </View>
            </GlassCard>
          )}

          {/* Time slots (horizontal) */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose a time slot</Text>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.slotRow}
            >
              {timeSlots.map((slot) => {
                const date = new Date(slot);
                const isSelected = selectedSlot === slot;

                return (
                  <GlassCard
                    key={slot}
                    onPress={() => setSelectedSlot(slot)}
                    style={[
                      styles.slotCard,
                      isSelected && styles.slotSelected,
                    ]}
                    accountType="customer"
                  >
                    <Text style={styles.slotDay}>
                      {date.toLocaleDateString('en-GB', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short',
                      })}
                    </Text>
                    <Text style={styles.slotTime}>
                      {date.toLocaleTimeString('en-GB', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </Text>

                    {isSelected && (
                      <View style={styles.tick}>
                        <Ionicons name="checkmark" size={12} color={BG} />
                      </View>
                    )}
                  </GlassCard>
                );
              })}
            </ScrollView>
          </View>
        </ScrollView>
      )}

      {/* Fixed footer */}
      <View
        style={[
          styles.footer,
          { paddingBottom: insets.bottom + TAB_BAR_TOTAL_HEIGHT },
        ]}
      >
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedSlot}
          activeOpacity={0.85}
          style={[
            styles.continueButton,
            !selectedSlot && { opacity: 0.5 },
          ]}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color={BG} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  scrollContent: {
    paddingHorizontal: isSmallScreen ? 14 : 20,
    gap: 16,
  },

  label: {
    color: 'rgba(135,206,235,0.9)',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  title: { color: '#F9FAFB', fontSize: 16, fontWeight: '800' },
  sub: { color: 'rgba(249,250,251,0.85)', fontSize: 13, marginTop: 4 },

  hubSummary: { padding: 16 },
  serviceCard: { padding: 16 },

  serviceHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pricePill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: SKY,
    borderRadius: 999,
  },
  priceText: { color: BG, fontWeight: '900', fontSize: 12 },

  metaRow: { flexDirection: 'row', gap: 12, marginTop: 10 },
  meta: { color: '#E5E7EB', fontSize: 12, fontWeight: '700' },

  section: { gap: 12, paddingTop: 8 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },

  slotRow: { paddingVertical: 4, gap: 12 },
  slotCard: {
    width: SLOT_WIDTH,
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  slotSelected: {
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  slotDay: { color: '#E5E7EB', fontSize: 12, fontWeight: '700' },
  slotTime: { color: '#F9FAFB', fontSize: 16, fontWeight: '900', marginTop: 2 },

  tick: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },

  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: isSmallScreen ? 14 : 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  continueButton: {
    backgroundColor: SKY,
    borderRadius: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueText: { color: BG, fontSize: 16, fontWeight: '900' },
});
