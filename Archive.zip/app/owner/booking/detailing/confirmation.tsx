import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../../src/constants/customerTheme';

const PREMIUM_PURPLE = '#8B5CF6';

export default function DetailingConfirmation() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ bookingId?: string }>();
  const bookingId = params.bookingId as string | undefined;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Detailing confirmed" showBack={false} />

      <View style={styles.content}>
        <View style={styles.iconWrapper}>
          <Ionicons name="diamond" size={40} color={PREMIUM_PURPLE} />
        </View>
        <Text style={styles.title}>Premium appointment booked!</Text>
        <Text style={styles.subtitle}>
          Your detailing appointment has been confirmed. Arrive 10 minutes early for your premium service.
        </Text>
        <View style={styles.premiumBadge}>
          <Ionicons name="diamond" size={16} color={PREMIUM_PURPLE} />
          <Text style={styles.premiumBadgeText}>Premium Service</Text>
        </View>
        {bookingId && (
          <View style={styles.bookingTag}>
            <Text style={styles.bookingTagText}>Booking ID: {bookingId.slice(0, 8)}</Text>
          </View>
        )}
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={styles.primaryButton}
          onPress={() => router.replace('/owner/wash-history')}
        >
          <Text style={styles.primaryText}>View my bookings</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => router.replace('/owner/owner-dashboard')}
        >
          <Text style={styles.secondaryText}>Back to dashboard</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    gap: 16,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  iconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
  },
  subtitle: {
    color: 'rgba(249,250,251,0.8)',
    textAlign: 'center',
    lineHeight: 20,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(139,92,246,0.15)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  premiumBadgeText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '700',
  },
  bookingTag: {
    marginTop: 8,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  bookingTagText: {
    color: '#E5E7EB',
    fontSize: 13,
    letterSpacing: 0.5,
  },
  footer: {
    paddingHorizontal: 20,
    gap: 12,
  },
  primaryButton: {
    borderRadius: 18,
    backgroundColor: PREMIUM_PURPLE,
    paddingVertical: 14,
    alignItems: 'center',
  },
  primaryText: {
    color: '#0A1929',
    fontWeight: '700',
    fontSize: 16,
  },
  secondaryButton: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 14,
    alignItems: 'center',
  },
  secondaryText: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 16,
  },
});

