import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AppHeader, { HEADER_HEIGHT } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

export default function DetailingBooking() {
  const insets = useSafeAreaInsets();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        friction: 8,
        tension: 60,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Premium Detailing" 
        rightAction={
          <TouchableOpacity
            onPress={() => router.push('/owner/booking/detailing/info')}
            style={styles.infoButton}
            activeOpacity={0.7}
          >
            <Ionicons name="information-circle-outline" size={24} color={PREMIUM_PURPLE} />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingTop: insets.top + HEADER_HEIGHT + 32,
            paddingBottom: Math.max(insets.bottom, 24),
          },
        ]}
      >
        <View style={styles.deliveryOptions}>
          <Text style={styles.deliveryTitle}>Choose Service Delivery</Text>
          <Text style={styles.deliverySubtitle}>How would you like to receive your detailing service?</Text>
          
          <TouchableOpacity
            style={styles.deliveryOption}
            onPress={() => router.push('/owner/booking/detailing/create')}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[PREMIUM_PURPLE, '#7C3AED']}
              style={styles.deliveryGradient}
            >
              <View style={styles.deliveryIconWrapper}>
                <Ionicons name="car" size={32} color="#FFFFFF" />
              </View>
              <View style={styles.deliveryContent}>
                <Text style={styles.deliveryOptionTitle}>They Come to You</Text>
                <Text style={styles.deliveryOptionDesc}>On-demand valeter service at your location</Text>
              </View>
              <Ionicons name="arrow-forward" size={24} color="#FFFFFF" />
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.deliveryOption}
            onPress={() => router.push('/owner/booking/detailing/vehicle')}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(139,92,246,0.3)', 'rgba(124,58,237,0.3)']}
              style={styles.deliveryGradient}
            >
              <View style={styles.deliveryIconWrapper}>
                <Ionicons name="business" size={32} color={PREMIUM_PURPLE} />
              </View>
              <View style={styles.deliveryContent}>
                <Text style={styles.deliveryOptionTitleLight}>You Go to Them</Text>
                <Text style={styles.deliveryOptionDescLight}>Visit our premium detailing facility</Text>
              </View>
              <Ionicons name="arrow-forward" size={24} color={PREMIUM_PURPLE} />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  content: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 24,
    justifyContent: 'center',
  },
  infoButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(139,92,246,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  deliveryOptions: {
    gap: 16,
  },
  deliveryTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  deliverySubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 20,
  },
  deliveryOption: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  deliveryGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    gap: 16,
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  deliveryIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deliveryContent: {
    flex: 1,
  },
  deliveryOptionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  deliveryOptionDesc: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    lineHeight: 18,
  },
  deliveryOptionTitleLight: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  deliveryOptionDescLight: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    lineHeight: 18,
  },
});
