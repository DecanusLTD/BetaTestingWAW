import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { 
  calculateDisplayPrice, 
  getVehicleSize, 
  mapServiceIdToWashId,
  FrontendPricingInput 
} from '../../../src/pricing/pricingEngine';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function BookingCreate() {
  const { user } = useAuth();
    const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    // Reset wash type when service changes
    if (serviceId !== 'bronze-wash') {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const handleContinue = async () => {
    if (!selectedService || !selectedVehicle) {
      return;
    }
    // Require wash type selection for bronze wash
    if (selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/location',
      params: {
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        washType: washType || '',
      },
    });
  };

  const selectedServiceData = serviceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  // Calculate price using pricing engine
  const pricingBreakdown = selectedService && selectedVehicleData ? (() => {
    const washId = mapServiceIdToWashId(selectedService);
    if (!washId) return null;
    
    const vehicleSize = getVehicleSize(selectedVehicleData);
    const input: FrontendPricingInput = {
      washId,
      vehicleSize,
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(), // Will be recalculated when time is selected
    };
    
    return calculateDisplayPrice(input);
  })() : null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Create Booking" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Service Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Service</Text>
            <Text style={styles.sectionSubtitle}>Choose the perfect wash for your vehicle</Text>
            
            <View style={styles.serviceGrid}>
              {serviceOptions.map((service, index) => {
                const isSelected = selectedService === service.id;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      {
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(135,206,235,0.3)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '30', service.colors[1] + '20'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceContent}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={26} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceDetails}>
                          <Text
                            style={[styles.serviceName, isSelected && { color: service.colors[0] }]}
                            numberOfLines={1}
                          >
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={SKY} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>
                        <View style={styles.priceColumn}>
                          <Text style={styles.priceLabel}>From</Text>
                          <Text style={[styles.servicePriceText, isSelected && { color: service.colors[0] }]}>
                            £{service.price}
                          </Text>
                          {isSelected && pricingBreakdown && pricingBreakdown.surgeMultiplier > 1 && (
                            <View style={styles.surgeBadge}>
                              <Ionicons name="flash" size={10} color="#F59E0B" />
                              <Text style={styles.surgeBadgeText}>{pricingBreakdown.surgeLabel}</Text>
                            </View>
                          )}
                        </View>
                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: service.colors[0] }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {/* Wash Type Selection for Bronze Wash */}
          {selectedService === 'bronze-wash' && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Select Wash Type</Text>
              <Text style={styles.sectionSubtitle}>Choose what you'd like cleaned</Text>
              
              <View style={styles.washTypeGrid}>
                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('exterior')}
                  style={[styles.washTypeCard, washType === 'exterior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'exterior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="car-sport-outline" 
                      size={32} 
                      color={washType === 'exterior' ? SKY : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'exterior' && { color: SKY }]}>
                      Exterior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{selectedServiceData?.price || 15}</Text>
                  </View>
                  {washType === 'exterior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('interior')}
                  style={[styles.washTypeCard, washType === 'interior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'interior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="home-outline" 
                      size={32} 
                      color={washType === 'interior' ? SKY : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'interior' && { color: SKY }]}>
                      Interior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{selectedServiceData?.price || 15}</Text>
                  </View>
                  {washType === 'interior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('both')}
                  style={[styles.washTypeCard, washType === 'both' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'both' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="sparkles-outline" 
                      size={32} 
                      color={washType === 'both' ? SKY : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'both' && { color: SKY }]}>
                      Both
                    </Text>
                    <Text style={styles.washTypePrice}>£{(selectedServiceData?.price || 15) * 1.5}</Text>
                    <View style={styles.premiumBadge}>
                      <Text style={styles.premiumBadgeText}>Premium</Text>
                    </View>
                  </View>
                  {washType === 'both' && (
                    <View style={[styles.selectedBadge, { backgroundColor: SKY }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Vehicle Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Vehicle</Text>
            <Text style={styles.sectionSubtitle}>Choose the vehicle for this service</Text>
            
            {loading ? (
              <View style={styles.loadingContainer}>
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="car-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <TouchableOpacity
                    onPress={() => router.push('/owner/settings/vehicle-management')}
                    style={styles.addVehicleButton}
                  >
                    <Text style={styles.addVehicleText}>Add Vehicle</Text>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ) : (
              <View style={styles.vehicleList}>
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <GlassCard
                      key={vehicle.id}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedVehicle(vehicle.id);
                      }}
                      style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                      borderColor={isSelected ? SKY : 'rgba(135,206,235,0.3)'}
                    >
                      <View style={styles.vehicleContent}>
                        <View style={styles.vehicleIconWrapper}>
                          <Ionicons name="car-sport" size={24} color={SKY} />
                        </View>
                        <View style={styles.vehicleInfo}>
                          <Text style={styles.vehicleName}>
                            {vehicle.make} {vehicle.model}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {vehicle.color} • {vehicle.registration}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={styles.selectedCheck}>
                            <Ionicons name="checkmark-circle" size={24} color={SKY} />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
            )}
          </View>

          {/* Continue Button */}
          {selectedService && selectedVehicle && (selectedService !== 'bronze-wash' || washType) && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#3B82F6']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 20, // Consistent top padding after AppHeader
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  serviceGrid: {
    gap: 16,
  },
  serviceCardWrapper: {
    width: '100%',
  },
  serviceCard: {
    padding: 16,
  },
  serviceCardSelected: {
    elevation: 12,
    shadowColor: SKY,
    shadowOpacity: 0.4,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  serviceIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceDetails: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'left',
  },
  serviceDesc: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
    lineHeight: 16,
  },
  serviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 0,
  },
  serviceMetaText: {
    color: SKY,
    fontSize: 10,
  },
  priceColumn: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    minWidth: 70,
  },
  priceLabel: {
    color: '#94A3B8',
    fontSize: 12,
    marginBottom: 4,
  },
  servicePriceText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleList: {
    gap: 12,
  },
  vehicleCard: {
    padding: 16,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: SKY,
    shadowOpacity: 0.4,
  },
  vehicleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  vehicleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleDetails: {
    color: '#1E3A8A',
    fontSize: 12,
  },
  selectedCheck: {
    marginLeft: 'auto',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    marginTop: 12,
    marginBottom: 20,
  },
  addVehicleButton: {
    backgroundColor: SKY,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  washTypeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  washTypeCard: {
    flex: 1,
    minWidth: (width - 52) / 3,
    borderRadius: 16,
    padding: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    position: 'relative',
  },
  washTypeCardSelected: {
    borderColor: SKY,
    elevation: 8,
    shadowColor: SKY,
    shadowOpacity: 0.4,
  },
  washTypeContent: {
    alignItems: 'center',
    gap: 8,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  washTypePrice: {
    color: SKY,
    fontSize: 16,
    fontWeight: 'bold',
  },
  premiumBadge: {
    marginTop: 4,
    backgroundColor: SKY + '20',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  premiumBadgeText: {
    color: SKY,
    fontSize: 10,
    fontWeight: '600',
  },
  surgeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
    backgroundColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  surgeBadgeText: {
    color: '#F59E0B',
    fontSize: 9,
    fontWeight: '600',
  },
});

