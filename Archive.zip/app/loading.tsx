/**
 * Expo Router async route loading UI — same splash as app index bootstrap.
 */
import LoadingScreen from '../src/components/LoadingScreen';

export default function AppLoadingRoute() {
  return <LoadingScreen overlay={false} />;
}
