// app/_layout.tsx (RootLayout)
import { Stack } from 'expo-router';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { useEffect, useRef, useState } from 'react';
import { LogBox, Platform, View, StyleSheet } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import {
  Rubik_400Regular,
  Rubik_500Medium,
  Rubik_600SemiBold,
  Rubik_700Bold,
} from '@expo-google-fonts/rubik';
import Constants from 'expo-constants';
import NavTabWrapper from './components/NavTabWrapper';
import { GlobalThemeProvider, useGlobalTheme } from '../src/components/shared/GlobalThemeContext';
import AccountThemeByRoute from './components/AccountThemeByRoute';

/** Prefer `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY` (EAS env / .env); fallback for local dev only. */
const STRIPE_PUBLISHABLE_FALLBACK =
  'pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU';
const stripePublishableKey =
  (typeof process !== 'undefined' && process.env?.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY) ||
  (Constants.expoConfig?.extra as { stripePublishableKey?: string } | undefined)?.stripePublishableKey ||
  STRIPE_PUBLISHABLE_FALLBACK;

function StatusBarByTheme() {
  const { mode } = useGlobalTheme();
  const isLight = mode === 'light';
  return (
    <StatusBar
      style={isLight ? 'dark' : 'light'}
      backgroundColor={isLight ? '#4A7A8E' : '#0F2847'}
    />
  );
}

function LayoutBackground({ children }: Readonly<{ children: React.ReactNode }>) {
  const { mode } = useGlobalTheme();
  const bg = mode === 'light' ? '#4A7A8E' : '#0F2847';
  return <View style={[StyleSheet.absoluteFill, { backgroundColor: bg }]}>{children}</View>;
}

// Conditionally import Stripe only on native platforms
let StripeProvider: any = ({ children }: Readonly<{ children: React.ReactNode }>) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    console.warn('Stripe not available:', e);
  }
}

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);
  const splashRegisteredRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        try {
          await SplashScreen.preventAutoHideAsync();
          splashRegisteredRef.current = true;
        } catch (splashErr) {
          console.warn('[Splash] preventAutoHideAsync error:', splashErr);
          splashRegisteredRef.current = false;
        }

        const startTime = Date.now();
        
        // Preload assets
        const imageAssets = [
          require('../assets/icon-auth.png'),
          require('../assets/icon.png'),
        ];

        const cacheImages = imageAssets.map(image => {
          return Asset.fromModule(image).downloadAsync();
        });

        await Promise.all(cacheImages);
        
        // Load Rubik fonts
        await Font.loadAsync({
          ...Ionicons.font,
          Rubik_400Regular,
          Rubik_500Medium,
          Rubik_600SemiBold,
          Rubik_700Bold,
        });
        
        await new Promise(requestAnimationFrame);
        
        // Ensure splash screen shows for at least 3 seconds
        const minDisplayTime = 3000; // 3 seconds
        
        // Calculate remaining time to reach 3 seconds
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, minDisplayTime - elapsed);
        
        if (remaining > 0) {
          await new Promise(resolve => setTimeout(resolve, remaining));
        }
        
        setAppReady(true);
      } catch (e) {
        console.error('[RootLayout] boot error:', e);
        setAppReady(true); // don't deadlock the splash
      }
    })();
  }, []);

  useEffect(() => {
    const hide = async () => {
      if (appReady && !hideOnceRef.current && splashRegisteredRef.current) {
        hideOnceRef.current = true;
        try {
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn('[Splash] hideAsync error:', e);
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StripeProvider
        publishableKey={stripePublishableKey}
        merchantIdentifier="merchant.com.wishawash"                                   // Apple Pay (iOS)
        urlScheme="waw"                                                         // Optional: 3DS redirect on Android
      >
        <GlobalThemeProvider>
          <AuthProvider>
            <AccountThemeByRoute>
              <StatusBarByTheme />
              <LayoutBackground>
                <NavTabWrapper>
                  <Stack
                    screenOptions={{
                      headerShown: false,
                      contentStyle: { backgroundColor: 'transparent' },
                      animation: 'fade',
                      animationDuration: 400,
                      gestureEnabled: true,
                    }}
                  />
                </NavTabWrapper>
              </LayoutBackground>
            </AccountThemeByRoute>
          </AuthProvider>
        </GlobalThemeProvider>
      </StripeProvider>
    </GestureHandlerRootView>
  );
}
