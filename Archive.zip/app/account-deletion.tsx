import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChromeGlyph as Ionicons } from '../src/components/shared/ChromeGlyph';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { normalizeUserType } from '../src/utils/authRole';
import { supabase } from '../src/lib/supabase';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import GlassCard from '../src/components/booking/GlassCard';
import BubbleBackground from '../src/components/shared/BubbleBackground';
import LoadingScreen from '../src/components/LoadingScreen';
import { useAccountTheme } from '../src/components/shared/AccountThemeProvider';
import { getAccountTheme } from '../src/constants/accountThemes';

type AccountDeletionRow = {
  id: string;
  user_id: string;
  user_type: string | null;
  email: string | null;
  account_name: string | null;
  reason?: string | null;
  notes?: string | null;
  created_at?: string | null;
};

function formatDate(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

export default function AccountDeletionScreen() {
  const { user, isLoading, authReady } = useAuth();
  const { theme } = useAccountTheme();
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const role = normalizeUserType(user?.userType, null);
  const accountType = role === 'organization' ? 'business' : 'valeter';
  const fallbackTheme = useMemo(
    () => getAccountTheme(accountType),
    [accountType]
  );

  const [loadingRequest, setLoadingRequest] = useState(true);
  const [existingRequest, setExistingRequest] = useState<AccountDeletionRow | null>(null);
  const [accountName, setAccountName] = useState<string>('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [retracting, setRetracting] = useState(false);

  const resolvedTheme = theme ?? fallbackTheme;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 450,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  useEffect(() => {
    if (!authReady || isLoading) return;
    if (!user) {
      router.replace('/auth/login');
    }
  }, [authReady, isLoading, user]);

  useEffect(() => {
    let alive = true;

    const loadRequest = async () => {
      if (!user || !role) {
        if (alive) setLoadingRequest(false);
        return;
      }

      setLoadingRequest(true);
      try {
        let resolvedName = (user.name || '').trim() || 'Account';

        if (role === 'organization' && user.organizationId) {
          const { data: orgRow } = await supabase
            .from('organizations')
            .select('name')
            .eq('id', user.organizationId)
            .maybeSingle();
          const orgName = (orgRow as { name?: string } | null)?.name?.trim();
          if (orgName) resolvedName = orgName;
        }

        const { data, error } = await supabase
          .from('account_deletions')
          .select('*')
          .eq('user_id', user.id)
          .eq('user_type', role)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (error) throw error;

        if (!alive) return;
        setAccountName(resolvedName);
        const row = (data as AccountDeletionRow | null) ?? null;
        setExistingRequest(row);
        setReason(row?.reason ?? '');
        setNotes(row?.notes ?? '');
      } catch (e) {
        console.error('[AccountDeletion] load error:', e);
        Alert.alert('Error', 'We could not load your account deletion request right now.');
      } finally {
        if (alive) setLoadingRequest(false);
      }
    };

    void loadRequest();

    return () => {
      alive = false;
    };
  }, [user?.id, user?.userType, user?.organizationId, role]);

  const roleLabel = role === 'organization' ? 'Business account' : 'Valeter account';
  const requestCreatedAt = formatDate(existingRequest?.created_at);
  const canSubmit = reason.trim().length > 0 && notes.trim().length > 0 && !submitting;

  const handleSubmit = async () => {
    if (!user || !role || existingRequest || !canSubmit) return;

    try {
      setSubmitting(true);
      await hapticFeedback('light');

      const insertPayload = {
        user_id: user.id,
        user_type: role,
        email: user.email,
        account_name: accountName || user.name || 'Account',
        reason: reason.trim(),
        notes: notes.trim(),
      };

      const { data, error } = await supabase
        .from('account_deletions')
        .insert(insertPayload)
        .select('*')
        .maybeSingle();

      if (error) throw error;

      const inserted = (data as AccountDeletionRow | null) ?? {
        ...insertPayload,
        id: `${Date.now()}`,
        created_at: new Date().toISOString(),
      };
      setExistingRequest(inserted);
      setReason(inserted.reason ?? reason.trim());
      setNotes(inserted.notes ?? notes.trim());
      Alert.alert('Request sent', 'Your account deletion request has been received.');
    } catch (e: any) {
      console.error('[AccountDeletion] submit error:', e);
      Alert.alert('Error', e?.message || 'We could not send your deletion request.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRetract = async () => {
    if (!existingRequest?.id) return;

    Alert.alert(
      'Retract deletion request?',
      'This will remove your request from our system and keep your account active.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Retract request',
          style: 'destructive',
          onPress: async () => {
            try {
              setRetracting(true);
              await hapticFeedback('medium');
              const { error } = await supabase.from('account_deletions').delete().eq('id', existingRequest.id);
              if (error) throw error;
              setExistingRequest(null);
              setReason('');
              setNotes('');
            } catch (e: any) {
              console.error('[AccountDeletion] retract error:', e);
              Alert.alert('Error', e?.message || 'We could not retract your request.');
            } finally {
              setRetracting(false);
            }
          },
        },
      ]
    );
  };

  if (!authReady || isLoading || loadingRequest) {
    return <LoadingScreen message="Loading account deletion…" />;
  }

  if (!user) {
    return <LoadingScreen message="Redirecting to login…" overlay={false} />;
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={resolvedTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType={accountType} />

      <SafeAreaView style={styles.container} edges={['top']}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <Animated.View style={{ opacity: fadeAnim }}>
              <View style={styles.headerRow}>
                <View style={styles.headerSpacer} />
                <Text style={styles.headerTitle}>Close account</Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.back();
                  }}
                  activeOpacity={0.8}
                  style={styles.headerCloseButton}
                  accessibilityRole="button"
                  accessibilityLabel="Close page"
                >
                  <Ionicons name="close" size={22} color={resolvedTheme.primary} />
                </TouchableOpacity>
              </View>

              <GlassCard style={styles.heroCard as any} accountType={accountType} borderColor={`${resolvedTheme.primary}30`}>
                <View style={styles.heroTopRow}>
                  <View style={styles.heroBadge}>
                    <Ionicons name="trash-outline" size={18} color={resolvedTheme.primary} />
                  </View>
                  <Text style={styles.heroKicker}>Account deletion request</Text>
                </View>
                <Text style={styles.heroTitle}>
                  {existingRequest ? 'Your request has been sent' : 'Tell us why you want to close this account'}
                </Text>
                <Text style={styles.heroSubtitle}>
                  {existingRequest
                    ? 'We have received your request and it is now queued for review.'
                    : 'Fill in the form below so we can process your request safely.'}
                </Text>
              </GlassCard>

              {existingRequest ? (
                <>
                  <GlassCard style={styles.sectionCard as any} accountType={accountType} borderColor="rgba(239,68,68,0.3)">
                    <View style={styles.sectionHeaderRow}>
                      <Text style={styles.sectionTitle}>Request details</Text>
                      <View style={styles.statusPill}>
                        <View style={styles.statusDot} />
                        <Text style={styles.statusPillText}>Sent</Text>
                      </View>
                    </View>

                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Account</Text>
                      <Text style={styles.detailValue}>{existingRequest.account_name || accountName || 'Account'}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Email</Text>
                      <Text style={styles.detailValue}>{existingRequest.email || user.email}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Type</Text>
                      <Text style={styles.detailValue}>{roleLabel}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Requested</Text>
                      <Text style={styles.detailValue}>{requestCreatedAt}</Text>
                    </View>
                    <View style={styles.detailRowStacked}>
                      <Text style={styles.detailLabel}>Reason</Text>
                      <Text style={styles.detailValueBlock}>{existingRequest.reason || '—'}</Text>
                    </View>
                    <View style={styles.detailRowStacked}>
                      <Text style={styles.detailLabel}>Notes</Text>
                      <Text style={styles.detailValueBlock}>{existingRequest.notes || '—'}</Text>
                    </View>
                  </GlassCard>

                  <GlassCard style={styles.noticeCard as any} accountType={accountType} borderColor="rgba(96,165,250,0.22)">
                    <Text style={styles.noticeText}>
                      All account deletions happen within 28 working days, this allows us to determine any remaining payouts and remove all your data from the wish system
                    </Text>
                  </GlassCard>

                  <TouchableOpacity
                    onPress={handleRetract}
                    activeOpacity={0.9}
                    disabled={retracting}
                    style={[styles.primaryButton, styles.retractButton, retracting && { opacity: 0.7 }]}
                  >
                    <Text style={styles.primaryButtonText}>
                      {retracting ? 'Retracting…' : 'Retract deletion'}
                    </Text>
                  </TouchableOpacity>
                </>
              ) : (
                <>
                  <GlassCard style={styles.sectionCard as any} accountType={accountType} borderColor={`${resolvedTheme.primary}28`}>
                    <View style={styles.sectionHeaderRow}>
                      <Text style={styles.sectionTitle}>Request form</Text>
                      <Text style={styles.sectionSubtitle}>Required</Text>
                    </View>

                    <View style={styles.fieldBlock}>
                      <Text style={styles.fieldLabel}>Reason</Text>
                      <TextInput
                        value={reason}
                        onChangeText={setReason}
                        placeholder="Tell us why you're closing the account"
                        placeholderTextColor="rgba(249,250,251,0.45)"
                        style={styles.fieldInput}
                        multiline
                        textAlignVertical="top"
                      />
                    </View>

                    <View style={styles.fieldBlock}>
                      <Text style={styles.fieldLabel}>Notes</Text>
                      <TextInput
                        value={notes}
                        onChangeText={setNotes}
                        placeholder="Anything else we should know?"
                        placeholderTextColor="rgba(249,250,251,0.45)"
                        style={[styles.fieldInput, styles.notesInput]}
                        multiline
                        textAlignVertical="top"
                      />
                    </View>
                  </GlassCard>

                  <TouchableOpacity
                    onPress={handleSubmit}
                    activeOpacity={0.9}
                    disabled={!canSubmit}
                    style={[styles.primaryButton, !canSubmit && { opacity: 0.55 }]}
                  >
                    {submitting ? (
                      <ActivityIndicator color="#0F2847" />
                    ) : (
                      <Text style={styles.primaryButtonText}>Confirm deletion request</Text>
                    )}
                  </TouchableOpacity>
                </>
              )}
            </Animated.View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  scroll: { flex: 1 },
  content: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 28,
    gap: 18,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingTop: 4,
  },
  headerSpacer: {
    width: 36,
    height: 36,
  },
  headerTitle: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  headerCloseButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroCard: {
    padding: 20,
  },
  heroTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
  },
  heroBadge: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  heroKicker: {
    color: 'rgba(249,250,251,0.72)',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  heroTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '900',
    lineHeight: 30,
    marginBottom: 10,
  },
  heroSubtitle: {
    color: 'rgba(249,250,251,0.74)',
    fontSize: 14,
    lineHeight: 22,
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.62)',
    fontSize: 12,
    fontWeight: '700',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.22)',
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: '#10B981',
  },
  statusPillText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '800',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.14)',
  },
  detailRowStacked: {
    gap: 8,
    paddingTop: 14,
  },
  detailLabel: {
    color: 'rgba(249,250,251,0.68)',
    fontSize: 12,
    fontWeight: '700',
    flexShrink: 0,
  },
  detailValue: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'right',
    flex: 1,
  },
  detailValueBlock: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  noticeCard: {
    padding: 18,
  },
  noticeText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '600',
  },
  fieldBlock: {
    gap: 8,
    marginBottom: 14,
  },
  fieldLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
  },
  fieldInput: {
    minHeight: 56,
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: '#F9FAFB',
    backgroundColor: 'rgba(15,40,71,0.34)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.18)',
    fontSize: 14,
    fontWeight: '600',
  },
  notesInput: {
    minHeight: 120,
  },
  primaryButton: {
    minHeight: 56,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
    backgroundColor: '#F9FAFB',
    marginTop: 4,
  },
  retractButton: {
    backgroundColor: 'rgba(239,68,68,0.16)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.28)',
  },
  primaryButtonText: {
    color: '#0F2847',
    fontSize: 15,
    fontWeight: '900',
  },
});
