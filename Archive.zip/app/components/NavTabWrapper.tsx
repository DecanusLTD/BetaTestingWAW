import React, { useEffect, useMemo } from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import NavigationTab from './NavigationTab';
import { ValeterNavProvider } from '../../src/components/valeter/ValeterNavSidebar';
import { ValeterGlobalDock } from '../../src/components/valeter/ValeterDashboardFloatingDock';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import LoadingScreen from '../../src/components/LoadingScreen';
import {
  isBusinessRoutePath,
  isValeterRoutePath,
  normalizeUserType,
} from '../../src/utils/authRole';
import {
  isValeterDashboardRoute,
  isValeterImmersiveRoute,
} from '../../src/utils/valeterNavigation';
import { useValeterAlertNotifications } from '../../src/hooks/useValeterAlertNotifications';

/** Routes where business NavigationTab stays hidden. */
const HIDDEN_ROUTES = new Set([
  '/auth/login',
  '/auth/signup',
  '/auth/logout-test',
  '/onboarding',
  '/valeter/valeter-onboarding',
  '/valeter/terms',
  '/valeter/terms-blocked',
  '/valeter/dev-work',
  '/organisation/organization-onboarding',
  '/business/onboarding',
  '/business/terms',
  '/business/terms-blocked',
  '/business/stripe-connect',
  '/business/dev-work',
  '/business/settings',
  '/account-deletion',
]);

type NavTabWrapperProps = Readonly<{ children: React.ReactNode }>;

export default function NavTabWrapper({ children }: NavTabWrapperProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isLoading, authReady } = useAuth();
  const currentPath = pathname || '';
  useValeterAlertNotifications();

  const redirectTarget = useMemo(() => {
    if (!authReady || isLoading) return null;
    if (currentPath === '/' || currentPath.startsWith('/auth/')) return null;

    const isBusinessOnboardingPath = currentPath === '/business/onboarding';
    const isValeterOnboardingPath = currentPath === '/valeter/valeter-onboarding';
    const isAnyOnboardingPath = currentPath.includes('onboarding');

    const userRole = normalizeUserType(user?.userType, null);

    if (!user) {
      if (isBusinessRoutePath(currentPath) || isValeterRoutePath(currentPath) || isAnyOnboardingPath) {
        return '/auth/login';
      }
      return null;
    }

    if (userRole === 'organization' && isValeterRoutePath(currentPath)) {
      return '/business/dashboard';
    }

    if (userRole === 'organization' && isValeterOnboardingPath) {
      return '/business/onboarding';
    }

    if (userRole === 'valeter' && isBusinessRoutePath(currentPath)) {
      return '/valeter/valeter-dashboard';
    }

    if (userRole === 'valeter' && isBusinessOnboardingPath) {
      return '/valeter/valeter-onboarding';
    }

    return null;
  }, [authReady, currentPath, isLoading, user?.userType]);

  useEffect(() => {
    if (redirectTarget && redirectTarget !== currentPath) {
      router.replace(redirectTarget);
    }
  }, [currentPath, redirectTarget, router]);

  const isValeterUser = normalizeUserType(user?.userType, null) === 'valeter';
  const onValeterRoute = isValeterRoutePath(currentPath);
  const onValeterDashboard = isValeterDashboardRoute(currentPath);

  /** Business floating NavigationTab — never used for valeter (sheet/global dock instead). */
  const shouldHideBusinessTab = (): boolean => {
    if (isValeterUser && onValeterRoute) return true;
    if (currentPath === '/business/dashboard') return false;

    const isBusinessRoute =
      currentPath.includes('/business/') ||
      currentPath.includes('/organisation/') ||
      currentPath.includes('/organization/');

    if (isLoading || !authReady) return true;
    if (HIDDEN_ROUTES.has(currentPath)) return true;
    if (currentPath.includes('/auth/') || currentPath.includes('onboarding')) return true;
    if (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/bookings/tracking')
    ) {
      return true;
    }
    if (!user) return !isBusinessRoute;
    return false;
  };

  const showValeterGlobalDock = Boolean(
    user &&
      isValeterUser &&
      onValeterRoute &&
      !onValeterDashboard &&
      !isValeterImmersiveRoute(currentPath) &&
      !HIDDEN_ROUTES.has(currentPath) &&
      !currentPath.includes('onboarding') &&
      !currentPath.includes('/auth/')
  );

  const hideBusinessTab = shouldHideBusinessTab();
  const showValeterNav = Boolean(user && isValeterUser && onValeterRoute);

  if (redirectTarget) {
    return <LoadingScreen overlay={false} />;
  }

  const shell = (
    <View style={styles.container} pointerEvents="box-none">
      <View style={styles.contentWrapper} pointerEvents="box-none">
        {children}
      </View>
      {!hideBusinessTab && <NavigationTab />}
      {showValeterGlobalDock ? <ValeterGlobalDock /> : null}
    </View>
  );

  if (showValeterNav) {
    return <ValeterNavProvider>{shell}</ValeterNavProvider>;
  }

  return shell;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
});
