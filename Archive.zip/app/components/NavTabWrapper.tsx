import React, { useEffect, useMemo } from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname, useRouter, type Href } from 'expo-router';
import NavigationTab from './NavigationTab';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import LoadingScreen from '../../src/components/LoadingScreen';
import {
  isBusinessRoutePath,
  isValeterRoutePath,
  normalizeUserType,
} from '../../src/utils/authRole';

// Routes where tab bar should be hidden
const HIDDEN_ROUTES = new Set([
  '/auth/login',
  '/auth/signup',
  '/auth/logout-test',
  '/onboarding',
  '/valeter/valeter-onboarding',
  '/valeter/profile/valeter-vehicle-info',
  '/valeter/profile/valeter-personal-info',
  '/valeter/valeter-wash-history',
  '/valeter/settings/distance-covering',
  '/valeter/settings/working-hours',
  '/valeter/profile/valeter-services',
  '/valeter/profile/valeter-notification-preferences',
  '/valeter/terms',
  '/valeter/terms-blocked',
  '/valeter/stripe-connect',
  '/valeter/dev-work',
  '/organisation/organization-onboarding',
  '/business/onboarding',
  '/business/terms',
  '/business/terms-blocked',
  '/business/stripe-connect',
  '/business/dev-work',
  '/business/settings',
  '/account-deletion',
]);

type NavTabWrapperProps = Readonly<{ children: React.ReactNode }>;

export default function NavTabWrapper({ children }: NavTabWrapperProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isLoading, authReady } = useAuth();
  const currentPath = pathname || '';

  const redirectTarget = useMemo(() => {
    if (!authReady || isLoading) return null;
    if (currentPath === '/' || currentPath.startsWith('/auth/')) return null;

    const isBusinessOnboardingPath = currentPath === '/business/onboarding';
    const isValeterOnboardingPath = currentPath === '/valeter/valeter-onboarding';
    const isAnyOnboardingPath = currentPath.includes('onboarding');

    const userRole = normalizeUserType(user?.userType, null);

    if (!user) {
      if (isBusinessRoutePath(currentPath) || isValeterRoutePath(currentPath) || isAnyOnboardingPath) {
        return '/auth/login';
      }
      return null;
    }

    if (userRole === 'organization' && isValeterRoutePath(currentPath)) {
      return '/business/dashboard';
    }

    if (userRole === 'organization' && isValeterOnboardingPath) {
      return '/business/onboarding';
    }

    if (userRole === 'valeter' && isBusinessRoutePath(currentPath)) {
      return '/valeter/valeter-dashboard';
    }

    if (userRole === 'valeter' && isBusinessOnboardingPath) {
      return '/valeter/valeter-onboarding';
    }

    return null;
  }, [authReady, currentPath, isLoading, user?.userType]);

  useEffect(() => {
    if (redirectTarget && redirectTarget !== currentPath) {
      router.replace(redirectTarget as Href);
    }
  }, [currentPath, redirectTarget, router]);

  const shouldHideTab = (): boolean => {
    const currentPath = pathname || '';
    if (currentPath === '/business/dashboard') return false;

    const isBusinessRoute =
      currentPath.includes('/business/') ||
      currentPath.includes('/organisation/') ||
      currentPath.includes('/organization/');

    // Keep tab hidden while auth/app bootstrap is still showing loading screens.
    if (isLoading || !authReady) return true;

    if (HIDDEN_ROUTES.has(currentPath)) return true;
    if (currentPath.includes('/auth/') || currentPath.includes('onboarding')) return true;

    if (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/bookings/tracking') ||
      currentPath.includes('/jobs/tracking') ||
      currentPath.includes('/jobs/accept') ||
      currentPath.includes('/chat')
    ) {
      return true;
    }

    if (!user) return !isBusinessRoute;
    return false;
  };

  const hideTab = shouldHideTab();

  if (redirectTarget) {
    return <LoadingScreen overlay={false} />;
  }

  return (
    <View style={styles.container} pointerEvents="box-none">
      <View style={styles.contentWrapper} pointerEvents="box-none">
        {children}
      </View>

      {!hideTab && <NavigationTab />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // ✅ don’t paint a background here (let each screen own the background)
    backgroundColor: 'transparent',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
});
