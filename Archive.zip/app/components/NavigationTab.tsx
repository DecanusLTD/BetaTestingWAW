import React, { useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, type Href } from 'expo-router';
import type { IconGlyphName } from '../../src/components/shared/iconGlyphTypes';
import { LocationStyleIconBox } from '../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../src/utils/accentGradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getIconColors, getTextColors } from '../../src/constants/themeColors';
import { useGlobalTheme } from '../../src/components/shared/GlobalThemeContext';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { isBusinessRoutePath, normalizeUserType } from '../../src/utils/authRole';

const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 72;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 36;
const TABLET_BREAKPOINT = 768;
const TABLET_MAX_BAR_WIDTH = 560;

/** Match AppHeader: strong blur + light tint so list content under the bar reads frosted */
const TAB_BLUR_IOS = 92;
const TAB_BLUR_ANDROID = 72;
const TAB_CHROME_TINT_OPACITY = 0.18;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT - 18;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: IconGlyphName;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs' },
      { name: 'Trips', icon: 'navigate', route: '/valeter/trips' },
      { name: 'Chat', icon: 'chatbubbles', route: '/valeter/inbox' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'briefcase', route: '/business/bookings' },
      { name: 'Chat', icon: 'chatbubbles', route: '/business/inbox' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }
  return getTabs('valeter');
};

/** First matching rule wins; order matters (e.g. bookings/activity before bookings/). */
const ACTIVE_INDEX_RULES: ReadonlyArray<{
  pathMatches: (pathname: string) => boolean;
  tabMatches: (t: Tab) => boolean;
}> = [
  { pathMatches: (p) => p.includes('/valeter/jobs'), tabMatches: (t) => t.route === '/valeter/jobs' },
  { pathMatches: (p) => p.includes('/valeter/trips'), tabMatches: (t) => t.route === '/valeter/trips' },
  {
    pathMatches: (p) => p.includes('/valeter/inbox') || p.includes('/valeter/jobs/chat'),
    tabMatches: (t) => t.route === '/valeter/inbox',
  },
  {
    pathMatches: (p) => p.includes('/valeter/settings/distance-covering') || p.includes('/valeter/settings/'),
    tabMatches: (t) => t.route === '/valeter/profile/valeter-profile',
  },
  {
    pathMatches: (p) => p.includes('/valeter/profile/valeter-profile') || p.includes('/valeter/valeter-profile'),
    tabMatches: (t) => t.route === '/valeter/profile/valeter-profile',
  },
  { pathMatches: (p) => p.includes('/business/dashboard'), tabMatches: (t) => t.route === '/business/dashboard' },
  { pathMatches: (p) => p.includes('/business/locations'), tabMatches: (t) => t.route === '/business/locations' },
  { pathMatches: (p) => p.includes('/business/bookings'), tabMatches: (t) => t.route === '/business/bookings' },
  { pathMatches: (p) => p.includes('/business/inbox'), tabMatches: (t) => t.route === '/business/inbox' },
  { pathMatches: (p) => p.includes('/business/team'), tabMatches: (t) => t.route === '/business/bookings' },
  { pathMatches: (p) => p.includes('/business/profile'), tabMatches: (t) => t.route === '/business/profile' },
  {
    pathMatches: (p) => p.includes('/business/settings'),
    tabMatches: (t) => t.route === '/business/profile',
  },
];

function firstTabIndex(tabs: Tab[], tabMatches: (t: Tab) => boolean): number {
  return Math.max(0, tabs.findIndex(tabMatches));
}

function getActiveIndex(pathname: string, tabs: Tab[]): number {
  for (const rule of ACTIVE_INDEX_RULES) {
    if (rule.pathMatches(pathname)) {
      return firstTabIndex(tabs, rule.tabMatches);
    }
  }

  for (let i = 0; i < tabs.length; i++) {
    const route = tabs[i].route;
    if (pathname === route || pathname.startsWith(`${route}/`)) {
      return i;
    }
  }

  return 0;
}

function resolveTabs(
  pathname: string,
  business: boolean,
  userType: 'customer' | 'valeter' | 'organization' | undefined
): Tab[] {
  const canonicalRole = normalizeUserType(userType, null);
  if (canonicalRole === 'organization' || business) {
    return getTabs('organization');
  }
  if (canonicalRole === 'valeter') {
    return getTabs('valeter');
  }
  if (pathname.includes('/valeter/')) {
    return getTabs('valeter');
  }
  if (pathname.includes('/business/')) {
    return getTabs('organization');
  }
  return getTabs(normalizeUserType(userType, null) === 'organization' ? 'organization' : 'valeter');
}

function computeHideTabBar(pathname: string): boolean {
  const hideRoutes = [
    '/auth/',
    '/onboarding',
    '/valeter/valeter-onboarding',
    '/valeter/terms',
    '/valeter/terms-blocked',
    '/valeter/stripe-connect',
    '/valeter/dev-work',
    '/organisation/organization-onboarding',
    '/account-deletion',
    '/business/onboarding',
    '/business/terms',
    '/business/terms-blocked',
    '/business/stripe-connect',
    '/business/settings',
    '/business/dev-work',
  ];
  if (hideRoutes.some((route) => pathname.includes(route))) {
    return true;
  }

  const isBusinessLocationsDetail = pathname.startsWith('/business/locations/') && pathname !== '/business/locations';

  return isBusinessLocationsDetail;
}

type ThemeShape = ReturnType<typeof getAccountTheme>;

interface NavigationTabItemProps {
  tab: Tab;
  index: number;
  activeIndex: number;
  slotW: number;
  accent: string;
  inactiveIcon: string;
  inactiveLabel: string;
  enhancedGlow: boolean;
  router: { push: (href: Href) => void };
  isBusinessRoute: boolean;
}

function NavigationTabItem({
  tab,
  index,
  activeIndex,
  slotW,
  accent,
  inactiveIcon,
  inactiveLabel,
  enhancedGlow,
  router,
  isBusinessRoute,
}: Readonly<NavigationTabItemProps>) {
  const isActive = index === activeIndex;
  const isProfile = tab.name === 'Profile';

  const onPress = useCallback(async () => {
    if (isActive && !isProfile) {
      return;
    }
    if (isProfile && isBusinessRoute) {
      await hapticFeedback('light');
      router.push('/business/profile' as Href);
      return;
    }
    if (!isActive) {
      await hapticFeedback('light');
      router.push(tab.route as Href);
    }
  }, [isActive, isProfile, isBusinessRoute, router, tab.route]);

  const glowStyles = enhancedGlow ? [styles.iconGlowValeter, { shadowColor: accent }] : undefined;
  const iconExtraStyles = enhancedGlow ? [styles.iconActiveValeter, { shadowColor: accent }] : undefined;

  return (
    <TouchableOpacity
      style={[styles.tab, { width: slotW, opacity: isActive && !isProfile ? 0.6 : 1 }]}
      onPress={onPress}
      activeOpacity={isActive && !isProfile ? 1 : 0.85}
      disabled={isActive && !isProfile}
      accessibilityRole="tab"
      accessibilityLabel={tab.name}
      accessibilityState={{ selected: isActive }}
    >
      <View style={[styles.iconContainer, isActive && styles.iconContainerActive]}>
        {isActive && <View style={[styles.iconGlow, { backgroundColor: `${accent}25` }, glowStyles]} />}
        <View
          style={[
            styles.icon,
            isActive && styles.iconActive,
            isActive && iconExtraStyles,
            !isActive && { opacity: 0.78 },
          ]}
        >
          <LocationStyleIconBox
            variant="nav"
            elevated={isActive}
            icon={isActive ? tab.icon : (`${String(tab.icon)}-outline` as IconGlyphName)}
            {...(isActive
              ? { colors: accentToGradient(accent) }
              : { preset: 'gray' as const })}
          />
        </View>
      </View>

      <Text
        style={[styles.label, { color: isActive ? accent : inactiveLabel }, isActive && styles.labelActive]}
        numberOfLines={1}
        adjustsFontSizeToFit
        minimumFontScale={0.75}
      >
        {tab.name}
      </Text>
    </TouchableOpacity>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();

  const isBusinessRoute = useMemo(() => isBusinessRoutePath(pathname), [pathname]);

  const currentTheme: ThemeShape = useMemo(() => {
    if (pathname.includes('/valeter/')) return getAccountTheme('valeter', mode);
    if (isBusinessRoute) return getAccountTheme('business', mode);
    return getAccountTheme('valeter', mode);
  }, [pathname, isBusinessRoute, mode]);

  const tabs = useMemo(
    () => resolveTabs(pathname, isBusinessRoute, user?.userType),
    [pathname, isBusinessRoute, user?.userType]
  );

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent = currentTheme?.primary || colors.navActive;

  const iconColors = currentTheme
    ? getIconColors(currentTheme)
    : { active: colors.navActive, inactive: 'rgba(255,255,255,0.65)' };
  const textColors = currentTheme
    ? getTextColors(currentTheme)
    : { primary: '#F9FAFB', secondary: 'rgba(255,255,255,0.8)' };

  const headerBackground =
    currentTheme?.headerBackground ||
    currentTheme?.background ||
    ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];

  const fullWidth = width - BAR_MARGIN_H * 2;
  const barWidth =
    width >= TABLET_BREAKPOINT ? Math.min(fullWidth, TABLET_MAX_BAR_WIDTH) : fullWidth;
  const pad = 12;
  const slotW = (barWidth - pad * 2) / tabs.length;

  const shouldHideTab = useMemo(() => computeHideTabBar(pathname), [pathname]);

  const inactiveIcon = iconColors.inactive;
  const inactiveLabel = textColors.secondary;

  const bottomPad = Math.max(insets.bottom, 10);
  const enhancedGlow = pathname.includes('/valeter/') || isBusinessRoute;

  if (shouldHideTab) {
    return null;
  }

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View
        pointerEvents="none"
        style={[
          styles.underlay,
          {
            top: 0,
            bottom: 0,
          },
        ]}
      />

      <View style={[styles.bar, { width: barWidth, borderRadius: BAR_RADIUS, marginBottom: bottomPad }]}>
        <BlurView
          intensity={Platform.OS === 'ios' ? TAB_BLUR_IOS : TAB_BLUR_ANDROID}
          tint={currentTheme?.mode === 'light' ? 'light' : 'dark'}
          style={StyleSheet.absoluteFill}
        >
          <View style={[StyleSheet.absoluteFill, { opacity: TAB_CHROME_TINT_OPACITY }]} pointerEvents="none">
            <LinearGradient
              colors={[`${headerBackground[0]}AA`, `${headerBackground[1] || headerBackground[0]}88`]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <LinearGradient
              colors={[`${accent}16`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
          </View>
        </BlurView>

        <View style={[styles.glassStroke, { borderColor: currentTheme?.glassBorder || 'rgba(255,255,255,0.08)' }]} />

        <View
          style={[
            styles.glowLine,
            {
              backgroundColor: `${accent}42`,
              shadowColor: accent,
            },
          ]}
        />

        <View style={[styles.row, { paddingHorizontal: pad }]}>
          {tabs.map((tab, index) => (
            <NavigationTabItem
              key={tab.route}
              tab={tab}
              index={index}
              activeIndex={activeIndex}
              slotW={slotW}
              accent={accent}
              inactiveIcon={inactiveIcon}
              inactiveLabel={inactiveLabel}
              enhancedGlow={enhancedGlow}
              router={router}
              isBusinessRoute={isBusinessRoute}
            />
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },

  underlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },

  bar: {
    height: TAB_BAR_HEIGHT,
    marginHorizontal: BAR_MARGIN_H,
    overflow: 'hidden',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,12,18,0.08)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.22,
    shadowRadius: 18,
    elevation: 18,
  },

  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: BAR_RADIUS,
  },

  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  tab: {
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 1,
    minWidth: 60,
  },

  iconContainer: {
    position: 'relative',
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width: 26,
    height: 26,
    borderRadius: 13,
  },

  iconContainerActive: {},

  icon: {
    zIndex: 2,
  },

  iconActive: {
    transform: [{ scale: 1.05 }],
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },

  iconActiveValeter: {
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    transform: [{ scale: 1.1 }],
  },

  iconGlow: {
    position: 'absolute',
    width: 38,
    height: 38,
    borderRadius: 19,
    zIndex: 1,
    opacity: 0.4,
  },

  iconGlowValeter: {
    width: 40,
    height: 40,
    borderRadius: 20,
    opacity: 0.5,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
    marginTop: 2,
    textAlign: 'center',
    width: '100%',
    paddingHorizontal: 1,
  },

  labelActive: {
    fontWeight: '900',
    letterSpacing: 0.4,
  },

  avatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarWrapActive: {
    borderWidth: 2.5,
    borderColor: '#87CEEB',
    shadowColor: '#87CEEB',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },

  avatarBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 14,
    borderWidth: 0,
    zIndex: 1,
    pointerEvents: 'none',
  },

  avatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 0,
    resizeMode: 'cover',
  },

  avatarGlow: {
    position: 'absolute',
    top: -3,
    left: -3,
    right: -3,
    bottom: -3,
    borderRadius: 14,
    zIndex: -1,
    opacity: 0.5,
  },
});
