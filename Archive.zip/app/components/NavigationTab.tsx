import React, { useMemo, useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, Image, Platform, Modal, Pressable } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useAnimatedStyle, useSharedValue, withSpring, interpolate } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const TAB_BAR_HEIGHT = 60;
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT + 20; // Include safe area padding

export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      { name: 'Trip', icon: 'navigate', route: '/valeter/jobs/tracking' },
      { name: 'Earnings', icon: 'cash', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }
  
  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }
  
  // Customer (default)
  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Book', icon: 'calendar', route: '/owner/booking' },
    { name: 'History', icon: 'time', route: '/owner/wash-history' },
    { name: 'Rewards', icon: 'gift', route: '/owner/features/rewards' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  // Handle booking routes
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex(t => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }
  
  // Handle rewards
  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex(t => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }
  
  // Handle valeter routes
  if (pathname.includes('/valeter/jobs/')) {
    if (pathname.includes('/valeter/jobs/tracking') || pathname.includes('/valeter/jobs/accept') || pathname.includes('/valeter/jobs/complete')) {
      const tripIndex = tabs.findIndex(t => t.route === '/valeter/jobs/tracking');
      return tripIndex >= 0 ? tripIndex : 0;
    }
    const jobsIndex = tabs.findIndex(t => t.route === '/valeter/jobs/queue');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }
  
  if (pathname.includes('/valeter/valeter-wash-history')) {
    const earningsIndex = tabs.findIndex(t => t.route === '/valeter/valeter-wash-history');
    return earningsIndex >= 0 ? earningsIndex : 0;
  }
  
  if (pathname.includes('/valeter/valeter-rewards-system')) {
    const rewardsIndex = tabs.findIndex(t => t.route === '/valeter/valeter-rewards-system');
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }
  
  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex(t => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }
  
  // Handle business routes
  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex(t => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex(t => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex(t => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex(t => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex(t => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }
  
  if (pathname.includes('/business/analytics')) {
    // Legacy support - redirect to profile if analytics is accessed
    const profileIndex = tabs.findIndex(t => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }
  
  // Exact match or starts with
  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) {
      return i;
    }
  }
  
  return 0;
};

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [showProfileActions, setShowProfileActions] = useState(false);
  
  // Determine if we're on business routes to use business theme colors
  const isBusinessRoute = pathname.includes('/business/') || pathname.includes('/Business/') || pathname.includes('/organisation/') || pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;
  
  // Determine if we're on customer routes to use customer theme colors
  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;
  
  const tabs = useMemo(() => {
    const userType = user?.userType;
    
    // CRITICAL FIX: If we're on customer routes (/owner/), force customer tabs regardless of userType
    // This prevents showing valeter tabs when userType is incorrectly set
    if (pathname.includes('/owner/') || pathname.includes('/customer')) {
      return getTabs('customer');
    }
    
    // If we're on valeter routes, use valeter tabs
    if (pathname.includes('/valeter/')) {
      return getTabs('valeter');
    }
    
    // If we're on business routes, use business tabs (check both cases)
    if (pathname.includes('/business/') || pathname.includes('/Business/') || pathname.includes('/organisation/') || pathname.includes('/Organization/')) {
      return getTabs('organization');
    }
    
    // Safety check: if userType is undefined or invalid, default to customer
    const safeUserType = (userType === 'valeter' || userType === 'organization' || userType === 'business') 
      ? userType 
      : 'customer';
    
    // Additional safety: if userType is 'valeter' but we're not on valeter routes, use customer
    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }
    
    const result = getTabs(safeUserType);
    return result;
  }, [user?.userType, user?.email, pathname]);
  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);
  
  const tabWidth = width / tabs.length;
  const indicatorWidth = tabWidth - 16;
  const indicatorPosition = useSharedValue(activeIndex);
  
  // Load profile picture
  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!user?.id) return;
      
      try {
        // Try to get from user context first
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
          return;
        }
        
        // For business/organization users, check multiple sources
        if (user.userType === 'organization' || user.userType === 'business') {
          // First try profiles table
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('avatar_url, profile_picture')
            .eq('id', user.id)
            .maybeSingle();
          
          if (!profileError && profileData) {
            const picUrl = profileData.avatar_url || profileData.profile_picture;
            if (picUrl) {
              setProfilePicture(picUrl);
              return;
            }
          }
          
          // Fallback: check if there's a logo in organizations table
          // (Note: organizations table doesn't have logo field in schema, but check anyway)
          const { data: orgData, error: orgError } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.id)
            .maybeSingle();
          
          // If organizations table has a logo/profile_picture field in the future
          if (!orgError && orgData && (orgData as any).logo) {
            setProfilePicture((orgData as any).logo);
            return;
          }
        } else {
          // For valeter and customer users, use existing logic
          const tableName = user.userType === 'valeter' ? 'valeter_profiles' : 'customer_profiles';
          
          const { data, error } = await supabase
            .from(tableName)
            .select('avatar_url, profile_picture')
            .eq('user_id', user.id)
            .maybeSingle();
          
          if (!error && data) {
            const picUrl = data.avatar_url || data.profile_picture;
            if (picUrl) setProfilePicture(picUrl);
          }
        }
      } catch (error) {
        console.error('[NavigationTab] Error loading profile picture:', error);
      }
    };
    
    loadProfilePicture();
  }, [user?.id, user?.profilePicture, user?.userType]);
  
  React.useEffect(() => {
    indicatorPosition.value = withSpring(activeIndex, {
      damping: 20,
      stiffness: 150,
    });
  }, [activeIndex]);
  
  const indicatorStyle = useAnimatedStyle(() => {
    const translateX = interpolate(
      indicatorPosition.value,
      [0, tabs.length - 1],
      [20 + (tabWidth - indicatorWidth) / 2, 20 + (tabs.length - 1) * tabWidth + (tabWidth - indicatorWidth) / 2]
    );
    
    return {
      transform: [{ translateX }],
      width: indicatorWidth,
    };
  });
  
  const shouldHideTab = () => {
    const hideRoutes = ['/auth/', '/onboarding', '/customer-onboarding', '/valeter/valeter-onboarding', '/organisation/organization-onboarding'];
    return hideRoutes.some(route => pathname.includes(route));
  };
  
  if (shouldHideTab()) {
    return null;
  }
  
  const isProfileTab = (tab: Tab) => tab.name === 'Profile';
  const profileTabIndex = tabs.findIndex(t => isProfileTab(t));
  
  return (
    <View style={[styles.wrapper, { paddingBottom: insets.bottom }]}>
      <BlurView
        intensity={Platform.OS === 'ios' ? 30 : 25}
        tint="dark"
        style={StyleSheet.absoluteFill}
      >
        {/* Glass overlay with blue/grey tint, customer header colors, or business green tint */}
        <View style={styles.glassOverlay}>
          <LinearGradient
            colors={isBusinessRoute && businessTheme 
              ? [`rgba(132,204,22,0.25)`, `rgba(6,95,70,0.15)`] // Business lime green to dark green
              : isCustomerRoute && customerTheme
              ? [`rgba(135,206,235,0.3)`, `rgba(30,58,138,0.25)`] // Sky blue to navy blue mix matching customer UI gradient
              : [colors.navGlassBg, 'rgba(30,58,138,0.15)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
            opacity={0.85}
          />
        </View>
      </BlurView>

      {/* Glass border at top */}
      <View style={[
        styles.glassBorder,
        isBusinessRoute && businessTheme && {
          backgroundColor: businessTheme.glassBorder,
          shadowColor: businessTheme.primary,
        },
        isCustomerRoute && customerTheme && {
          backgroundColor: customerTheme.glassBorder,
          shadowColor: customerTheme.primary,
        }
      ]} />

      <View style={styles.container}>
        {tabs.map((tab, index) => {
          const isActive = index === activeIndex;
          const isProfile = isProfileTab(tab);
          const showProfilePic = isProfile && profilePicture;
          
          const handleTabPress = async () => {
            if (isProfile && isBusinessRoute) {
              // Show action sheet for business profile tab
              await hapticFeedback('light');
              setShowProfileActions(true);
            } else {
              router.push(tab.route as any);
            }
          };

          return (
            <TouchableOpacity
              key={tab.route}
              style={styles.tab}
              onPress={handleTabPress}
              activeOpacity={0.7}
            >
              {showProfilePic ? (
                <View style={[
                  styles.profileImageContainer, 
                  isActive && styles.profileImageContainerActive,
                  isActive && isBusinessRoute && businessTheme && {
                    backgroundColor: `${businessTheme.primary}26`,
                    borderColor: `${businessTheme.primary}40`,
                    shadowColor: businessTheme.primary,
                  },
                  isActive && isCustomerRoute && customerTheme && {
                    backgroundColor: `${customerTheme.primary}26`,
                    borderColor: `${customerTheme.primary}40`,
                    shadowColor: customerTheme.primary,
                  }
                ]}>
                  <Image 
                    source={{ uri: profilePicture }} 
                    style={styles.profileImage}
                  />
                </View>
              ) : (
              <Ionicons
                name={isActive ? tab.icon : (`${tab.icon}-outline` as any)}
                size={24}
                color={isActive 
                  ? (isBusinessRoute && businessTheme ? businessTheme.primary 
                    : isCustomerRoute && customerTheme ? customerTheme.primary 
                    : colors.navActive)
                  : (isCustomerRoute && customerTheme ? 'rgba(135,206,235,0.6)' : colors.navInactive)}
              />
              )}
              <Text style={[
                styles.tabLabel, 
                isActive && styles.tabLabelActive,
                isActive && isBusinessRoute && businessTheme && {
                  color: businessTheme.primary,
                },
                isActive && isCustomerRoute && customerTheme && {
                  color: customerTheme.primary,
                }
              ]}>
                {tab.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <View style={[
        styles.poweredByContainer,
        isBusinessRoute && businessTheme && {
          borderTopColor: businessTheme.glassBorder,
        },
        isCustomerRoute && customerTheme && {
          borderTopColor: customerTheme.glassBorder,
        }
      ]}>
        <Text style={[
          styles.poweredByText,
          isBusinessRoute && businessTheme && {
            color: colors.greyMedium,
          },
          isCustomerRoute && customerTheme && {
            color: colors.greyMedium,
          }
        ]}>Powered by</Text>
        <Text style={[
          styles.brandText,
          isBusinessRoute && businessTheme && {
            color: businessTheme.primary,
          },
          isCustomerRoute && customerTheme && {
            color: customerTheme.primary,
          }
        ]}>Wish a Wash</Text>
      </View>

      {/* Profile Actions Modal for Business */}
      <Modal
        visible={showProfileActions}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowProfileActions(false)}
      >
        <Pressable 
          style={styles.modalOverlay}
          onPress={() => setShowProfileActions(false)}
        >
          <Pressable 
            style={[
              styles.actionSheet,
              isBusinessRoute && businessTheme && {
                backgroundColor: businessTheme.background?.[0] || 'rgba(15, 23, 42, 0.95)',
                borderColor: businessTheme.primary,
              }
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.actionSheetHeader}>
              <Text style={[
                styles.actionSheetTitle,
                isBusinessRoute && businessTheme && { color: businessTheme.primary }
              ]}>Profile Options</Text>
              <TouchableOpacity
                onPress={() => setShowProfileActions(false)}
                style={styles.actionSheetClose}
              >
                <Ionicons 
                  name="close" 
                  size={24} 
                  color={isBusinessRoute && businessTheme ? businessTheme.primary : colors.navActive} 
                />
              </TouchableOpacity>
            </View>
            
            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/profile' as any);
              }}
            >
              <View style={[
                styles.actionSheetIconWrapper,
                isBusinessRoute && businessTheme && { backgroundColor: `${businessTheme.primary}26` }
              ]}>
                <Ionicons 
                  name="person" 
                  size={20} 
                  color={isBusinessRoute && businessTheme ? businessTheme.primary : colors.navActive} 
                />
              </View>
              <Text style={styles.actionSheetItemText}>Business Profile</Text>
              <Ionicons name="chevron-forward" size={18} color={colors.navInactive} />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/settings' as any);
              }}
            >
              <View style={[
                styles.actionSheetIconWrapper,
                isBusinessRoute && businessTheme && { backgroundColor: `${businessTheme.primary}26` }
              ]}>
                <Ionicons 
                  name="settings" 
                  size={20} 
                  color={isBusinessRoute && businessTheme ? businessTheme.primary : colors.navActive} 
                />
              </View>
              <Text style={styles.actionSheetItemText}>Settings</Text>
              <Ionicons name="chevron-forward" size={18} color={colors.navInactive} />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    zIndex: 9999,
    elevation: 20,
    shadowColor: colors.navActive,
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  glassOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'transparent',
  },
  glassBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: colors.navGlassBorder,
    shadowColor: colors.navActive,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    zIndex: 1,
  },
  container: {
    flexDirection: 'row',
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'space-around',
    position: 'relative',
    paddingHorizontal: 8,
    zIndex: 1,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    zIndex: 1,
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: colors.navInactive,
    marginTop: 2,
  },
  tabLabelActive: {
    color: colors.navActive,
    fontWeight: '700',
  },
  profileImageContainer: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: `rgba(191,219,254,0.15)`,
    borderWidth: 1,
    borderColor: 'rgba(191,219,254,0.25)',
  },
  profileImageContainerActive: {
    shadowColor: colors.navActive,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
    borderColor: 'rgba(191,219,254,0.5)',
  },
  profileImage: {
    width: '100%',
    height: '100%',
    borderRadius: 14,
  },
  poweredByContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderTopWidth: 1,
    borderTopColor: colors.navGlassBorder,
    gap: 4,
    zIndex: 1,
    backgroundColor: 'transparent',
  },
  poweredByText: {
    fontSize: 9,
    color: colors.greyMedium,
    fontWeight: '500',
  },
  brandText: {
    fontSize: 9,
    color: colors.accentMedium,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 20,
    paddingBottom: 40,
    borderTopWidth: 1,
    borderColor: colors.navGlassBorder,
  },
  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    marginBottom: 12,
  },
  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#F9FAFB',
  },
  actionSheetClose: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 16,
  },
  actionSheetIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(191, 219, 254, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
});
