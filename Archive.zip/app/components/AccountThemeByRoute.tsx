import React, { useMemo } from 'react';
import { usePathname } from 'expo-router';
import type { AccountType } from '../../src/constants/accountThemes';
import { AccountThemeProvider } from '../../src/components/shared/AccountThemeProvider';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { normalizeUserType } from '../../src/utils/authRole';

export default function AccountThemeByRoute({ children }: Readonly<{ children: React.ReactNode }>) {
  const pathname = usePathname();
  const { user } = useAuth();
  const accountType: AccountType = useMemo(() => {
    if (pathname.includes('/valeter/')) return 'valeter';
    if (pathname.includes('/business/')) return 'business';
    if (pathname === '/account-deletion') {
      return normalizeUserType(user?.userType, null) === 'organization' ? 'business' : 'valeter';
    }
    return 'valeter';
  }, [pathname, user?.userType]);

  return <AccountThemeProvider accountType={accountType}>{children}</AccountThemeProvider>;
}
