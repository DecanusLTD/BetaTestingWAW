create extension if not exists pgcrypto;

alter table if exists public.profiles
  add column if not exists referral_code text,
  add column if not exists referred_by uuid references public.profiles(id) on delete set null;

create unique index if not exists profiles_referral_code_key
  on public.profiles (referral_code)
  where referral_code is not null;

create index if not exists profiles_referred_by_idx
  on public.profiles (referred_by);

alter table if exists public.bookings
  add column if not exists loyalty_reward_processed_at timestamptz;

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id) on delete cascade,
  referee_id uuid not null references public.profiles(id) on delete cascade,
  referral_code text not null,
  status text not null default 'pending' check (status in ('pending', 'completed', 'rewarded')),
  reward_amount integer not null default 5,
  reward_granted_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (referrer_id, referee_id),
  unique (referee_id)
);

create index if not exists referrals_referrer_id_idx
  on public.referrals (referrer_id, created_at desc);

create index if not exists referrals_referee_id_idx
  on public.referrals (referee_id);

create table if not exists public.reward_redemptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  reward_id text not null,
  reward_title text not null,
  points_spent integer not null,
  status text not null default 'redeemed',
  created_at timestamptz not null default now()
);

create index if not exists reward_redemptions_user_id_idx
  on public.reward_redemptions (user_id, created_at desc);
