/**
 * Supabase Edge Function: send Expo push when `bookings.status` changes.
 *
 * Deploy: `supabase functions deploy booking-status-push --no-verify-jwt`
 * Set secrets: BOOKING_PUSH_WEBHOOK_SECRET (optional but recommended)
 *
 * Database webhook (Dashboard → Database → Webhooks): table `bookings`, event UPDATE,
 * URL `https://<ref>.supabase.co/functions/v1/booking-status-push`,
 * HTTP Header `x-webhook-secret: <BOOKING_PUSH_WEBHOOK_SECRET>`.
 */
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.0';

const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';

function statusMessage(status: string): { title: string; body: string } {
  switch (status) {
    case 'confirmed':
    case 'valeter_assigned':
      return { title: 'Pro assigned', body: 'Your wash is confirmed.' };
    case 'en_route':
      return { title: 'On the way', body: 'Your pro is heading to you.' };
    case 'arrived':
      return { title: 'Arrived', body: 'Your pro has arrived.' };
    case 'in_progress':
      return { title: 'Wash in progress', body: 'Your service has started.' };
    case 'completed':
      return { title: 'Service complete', body: 'Tap to rate your experience.' };
    case 'cancelled':
      return { title: 'Booking update', body: 'Your booking was cancelled.' };
    default:
      return { title: 'Booking update', body: 'Your booking status changed.' };
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: { 'Access-Control-Allow-Origin': '*' } });
  }

  try {
    const webhookSecret = Deno.env.get('BOOKING_PUSH_WEBHOOK_SECRET');
    const incomingSecret = req.headers.get('x-webhook-secret');
    if (webhookSecret && incomingSecret !== webhookSecret) {
      return new Response(JSON.stringify({ error: 'unauthorized' }), { status: 401 });
    }

    const body = await req.json();
    const record = body.record ?? body;
    const oldRecord = body.old_record;

    if (!record?.id || !record?.user_id) {
      return new Response(JSON.stringify({ error: 'invalid payload' }), { status: 400 });
    }

    const newStatus = record.status as string | undefined;
    const oldStatus = oldRecord?.status as string | undefined;
    if (newStatus && oldStatus !== undefined && newStatus === oldStatus) {
      return new Response(JSON.stringify({ skipped: true, reason: 'same status' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { data: devices, error: devErr } = await supabase
      .from('user_devices')
      .select('expo_push_token')
      .eq('user_id', record.user_id);

    if (devErr) {
      return new Response(JSON.stringify({ error: devErr.message }), { status: 500 });
    }

    const tokens = (devices ?? [])
      .map((d: { expo_push_token?: string | null }) => d.expo_push_token)
      .filter((t): t is string => typeof t === 'string' && t.length > 0);

    if (tokens.length === 0) {
      return new Response(JSON.stringify({ ok: true, sent: 0 }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { title, body: msgBody } = statusMessage(newStatus ?? '');
    const pushType =
      newStatus === 'completed' ? 'booking_completed' : 'booking_status';

    const messages = tokens.map((to) => ({
      to,
      title,
      body: msgBody,
      sound: 'default',
      priority: 'high' as const,
      channelId: 'booking-updates',
      data: {
        bookingId: record.id,
        booking_id: record.id,
        bookingStatus: newStatus,
        type: pushType,
        ...(newStatus === 'completed' ? { screen: 'completion' } : {}),
      },
    }));

    const res = await fetch(EXPO_PUSH_URL, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(messages),
    });

    const expoResult = await res.json();
    return new Response(JSON.stringify({ ok: true, sent: tokens.length, expo: expoResult }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
