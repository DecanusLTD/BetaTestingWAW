/**
 * Supabase Edge Function: create Stripe PaymentIntents for booking charges.
 *
 * Supports:
 * - main booking payments
 * - booking chat payment requests
 * - tips / extra charges
 *
 * The intent is created as a Stripe Connect destination charge so the connected
 * valeter/business account receives the booking share while Wish a Wash keeps
 * the platform fee as `application_fee_amount`.
 */
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.56.0';
import Stripe from 'https://esm.sh/stripe@16.12.0?target=deno&no-check';

type RequestBody = {
  action?: 'create_payment_intent';
  bookingId?: string;
  requestMessageId?: string;
  amount?: number;
  currency?: string;
  customerId?: string;
  description?: string;
};

type BookingRow = {
  id: string;
  user_id: string;
  valeter_id: string | null;
  location_id: string | null;
  platform_fee_amount: number | null;
  platform_fee_context: 'valeter' | 'physical' | null;
  price: number | null;
  service_name: string | null;
  service_type: string | null;
};

type BookingMessageRow = {
  id: string;
  booking_id: string;
  sender_id: string;
  sender_role: string;
  message_type: string;
  content: string | null;
};

type ProfileRow = {
  id: string;
  stripe_account_id: string | null;
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    },
  });
}

function toPence(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.round(n * 100);
}

function fromPence(value: number): number {
  return Math.round(value);
}

async function getStripeAccountForValeter(
  supabase: ReturnType<typeof createClient>,
  valeterId: string
): Promise<string | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, stripe_account_id')
    .eq('id', valeterId)
    .maybeSingle();

  if (error || !data) return null;
  const row = data as ProfileRow;
  return row.stripe_account_id || null;
}

async function getStripeAccountForBusiness(
  supabase: ReturnType<typeof createClient>,
  locationId: string
): Promise<string | null> {
  const { data: location, error: locationError } = await supabase
    .from('car_wash_locations')
    .select('organization_id')
    .eq('id', locationId)
    .maybeSingle();
  if (locationError || !location?.organization_id) return null;

  const { data: org, error: orgError } = await supabase
    .from('organizations')
    .select('owner_user_id')
    .eq('id', location.organization_id)
    .maybeSingle();
  if (orgError || !org?.owner_user_id) return null;

  return getStripeAccountForValeter(supabase, org.owner_user_id);
}

async function resolveDestinationStripeAccount(
  supabase: ReturnType<typeof createClient>,
  booking: BookingRow
): Promise<string | null> {
  if (booking.valeter_id) {
    return getStripeAccountForValeter(supabase, booking.valeter_id);
  }
  if (booking.location_id) {
    return getStripeAccountForBusiness(supabase, booking.location_id);
  }
  return null;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return json({ ok: true });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceRole = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');

    if (!supabaseUrl || !supabaseServiceRole || !stripeSecretKey) {
      return json({ error: 'Missing Supabase or Stripe env vars' }, 500);
    }

    const supabase = createClient(supabaseUrl, supabaseServiceRole);
    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2024-06-20',
    });

    const body = (await req.json()) as RequestBody;
    if (body.action !== 'create_payment_intent') {
      return json({ error: 'Unsupported action' }, 400);
    }
    if (!body.bookingId) {
      return json({ error: 'bookingId is required' }, 400);
    }

    const { data: bookingData, error: bookingError } = await supabase
      .from('bookings')
      .select('id,user_id,valeter_id,location_id,platform_fee_amount,platform_fee_context,price,service_name,service_type')
      .eq('id', body.bookingId)
      .maybeSingle();

    if (bookingError || !bookingData) {
      return json({ error: 'Booking not found' }, 404);
    }

    const booking = bookingData as BookingRow;

    if (body.customerId && booking.user_id !== body.customerId) {
      return json({ error: 'Booking does not belong to this customer' }, 403);
    }

    let amountPence = 0;
    let platformFeePence = 0;
    let description = body.description || `Wish a Wash booking ${booking.id}`;
    let currency = (body.currency || 'gbp').toLowerCase();

    if (body.requestMessageId) {
      const { data: messageData, error: messageError } = await supabase
        .from('booking_messages')
        .select('id, booking_id, sender_id, sender_role, message_type, content')
        .eq('id', body.requestMessageId)
        .eq('booking_id', body.bookingId)
        .maybeSingle();

      if (messageError || !messageData) {
        return json({ error: 'Payment request not found' }, 404);
      }

      const message = messageData as BookingMessageRow;
      let parsed: any = {};
      try {
        parsed = message.content ? JSON.parse(message.content) : {};
      } catch {
        parsed = {};
      }

      amountPence = toPence(parsed.amount);
      if (!amountPence) {
        return json({ error: 'Invalid payment request amount' }, 400);
      }
      platformFeePence = toPence(parsed.platformFee);
      currency = String(parsed.currency || body.currency || 'gbp').toLowerCase();
      description = parsed.reason || description;
    } else {
      amountPence = body.amount || 0;
      if (!Number.isFinite(amountPence) || amountPence <= 0) {
        amountPence = toPence(booking.price);
      }
      if (!Number.isFinite(amountPence) || amountPence <= 0) {
        return json({ error: 'Invalid amount' }, 400);
      }
      platformFeePence = toPence(booking.platform_fee_amount);
    }

    const destinationAccount = await resolveDestinationStripeAccount(supabase, booking);
    if (!destinationAccount) {
      return json({
        error: 'No connected Stripe account is configured for this booking destination',
      }, 400);
    }

    if (!platformFeePence && booking.platform_fee_context) {
      const { data: feeRow, error: feeError } = await supabase
        .from('waw_platform_fees')
        .select('percent')
        .eq('context', booking.platform_fee_context)
        .maybeSingle();
      if (!feeError && feeRow?.percent != null) {
        const percent = Number(feeRow.percent);
        if (Number.isFinite(percent) && percent >= 0) {
          platformFeePence = Math.round((amountPence * percent) / 100);
        }
      }
    }

    if (platformFeePence < 0) platformFeePence = 0;
    if (platformFeePence > amountPence) platformFeePence = amountPence;

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountPence,
      currency,
      automatic_payment_methods: { enabled: true },
      application_fee_amount: platformFeePence || undefined,
      transfer_data: {
        destination: destinationAccount,
      },
      metadata: {
        booking_id: booking.id,
        bookingId: booking.id,
        customer_id: booking.user_id,
        destination_account: destinationAccount,
        platform_fee_amount: String(fromPence(platformFeePence)),
        source: body.requestMessageId ? 'booking_message' : 'booking_payment',
        request_message_id: body.requestMessageId || '',
      },
      description,
    });

    if (body.requestMessageId) {
      const { data: messageData, error: messageError } = await supabase
        .from('booking_messages')
        .select('content')
        .eq('id', body.requestMessageId)
        .maybeSingle();
      if (!messageError && messageData) {
        let parsed: any = {};
        try {
          parsed = messageData.content ? JSON.parse(messageData.content) : {};
        } catch {
          parsed = {};
        }
        const updated = {
          ...parsed,
          kind: parsed.kind || 'booking_payment_request',
          amount: fromPence(amountPence) / 100,
          currency,
          platformFee: fromPence(platformFeePence) / 100,
          paymentIntentId: paymentIntent.id,
          paymentIntentClientSecret: paymentIntent.client_secret,
          status: 'pending',
        };
        await supabase
          .from('booking_messages')
          .update({ content: JSON.stringify(updated) })
          .eq('id', body.requestMessageId);
      }
    }

    return json({
      ok: true,
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
      amount: amountPence / 100,
      currency,
      platformFee: platformFeePence / 100,
      destinationAccount,
    });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
