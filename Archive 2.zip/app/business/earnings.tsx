import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface EarningsSummary {
  totalEarnings: number;
  thisMonth: number;
  lastMonth: number;
  pendingPayouts: number;
  nextPayoutDate?: string;
}

export default function BusinessEarnings() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [earnings, setEarnings] = useState<EarningsSummary>({
    totalEarnings: 0,
    thisMonth: 0,
    lastMonth: 0,
    pendingPayouts: 0,
  });

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadEarnings();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadEarnings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load earnings data from database
      // This would query your earnings/payouts table
      setEarnings({
        totalEarnings: 12500,
        thisMonth: 3200,
        lastMonth: 2800,
        pendingPayouts: 1200,
        nextPayoutDate: '2026-01-31',
      });
    } catch (error) {
      console.error('Error loading earnings:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Earnings & Payouts" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Earnings & Payouts"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {/* Summary Cards */}
          <View style={styles.summaryGrid}>
            <GlassCard style={styles.summaryCard} accountType="business">
              <View style={styles.summaryContent}>
                <Ionicons name="cash" size={24} color="#8B5CF6" />
                <Text style={styles.summaryValue}>£{earnings.totalEarnings.toLocaleString()}</Text>
                <Text style={styles.summaryLabel}>Total Earnings</Text>
              </View>
            </GlassCard>

            <GlassCard style={styles.summaryCard} accountType="business">
              <View style={styles.summaryContent}>
                <Ionicons name="calendar" size={24} color="#8B5CF6" />
                <Text style={styles.summaryValue}>£{earnings.thisMonth.toLocaleString()}</Text>
                <Text style={styles.summaryLabel}>This Month</Text>
              </View>
            </GlassCard>

            <GlassCard style={styles.summaryCard} accountType="business">
              <View style={styles.summaryContent}>
                <Ionicons name="time" size={24} color="#8B5CF6" />
                <Text style={styles.summaryValue}>£{earnings.pendingPayouts.toLocaleString()}</Text>
                <Text style={styles.summaryLabel}>Pending</Text>
              </View>
            </GlassCard>
          </View>

          {/* Payout Information */}
          <GlassCard style={styles.infoCard} accountType="business">
            <View style={styles.infoContent}>
              <View style={styles.infoHeader}>
                <Ionicons name="wallet-outline" size={20} color="#8B5CF6" />
                <Text style={styles.infoTitle}>Next Payout</Text>
              </View>
              {earnings.nextPayoutDate ? (
                <>
                  <Text style={styles.infoValue}>
                    {new Date(earnings.nextPayoutDate).toLocaleDateString('en-GB', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.infoSubtext}>
                    Payouts are processed monthly on the last day
                  </Text>
                </>
              ) : (
                <Text style={styles.infoText}>No scheduled payout</Text>
              )}
            </View>
          </GlassCard>

          {/* Payout History */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Payout History</Text>
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="receipt-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
                <Text style={styles.emptyTitle}>No payout history yet</Text>
                <Text style={styles.emptyText}>
                  Your payout history will appear here after your first payment
                </Text>
              </View>
            </GlassCard>
          </View>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.xl,
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.md,
  },
  summaryCard: {
    width: getMetricCardWidth(3, SPACING.md),
    ...CARD_SIZES.small,
  },
  summaryContent: {
    padding: CARD_SIZES.small.padding,
    alignItems: 'center',
    gap: SPACING.sm,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
  },
  summaryLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
    textAlign: 'center',
  },
  infoCard: {
    ...CARD_SIZES.medium,
  },
  infoContent: {
    padding: CARD_SIZES.medium.padding,
    gap: SPACING.md,
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  infoValue: {
    color: '#8B5CF6',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 4,
  },
  infoSubtext: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    marginTop: 2,
  },
  infoText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
  },
  section: {
    gap: SPACING.md,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
    padding: CARD_SIZES.large.padding,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});

