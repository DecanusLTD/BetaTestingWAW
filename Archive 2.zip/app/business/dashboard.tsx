import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import GradientNotificationBell from '../../src/components/shared/GradientNotificationBell';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
}

type BookingStatus =
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'confirmed'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | string;

export default function BusinessDashboard() {
  const { user } = useAuth();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [businessName, setBusinessName] = useState<string>('');
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [businessRating, setBusinessRating] = useState<number>(0);
  const [notificationCount, setNotificationCount] = useState<number>(0);

  const [stats, setStats] = useState({
    totalLocations: 0,
    activeBookings: 0,
    valetersOnline: 0,
    todayRevenue: 0, // we keep this but we won't query unknown columns
    totalRevenue: 0, // same
    completionRate: 0,
    averageRating: 0,
    bookingsThisWeek: 0,
  });

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      loadData();
      fetchNotificationCount();

      const interval = setInterval(fetchNotificationCount, 45000);
      return () => clearInterval(interval);
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  const loadData = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      const [locs, orgData, rating, bookingMetrics, teamCount] = await Promise.all([
        loadLocations(),
        loadOrganizationData(),
        calculateBusinessRating(),
        loadBookingMetrics(),
        loadTeamCount(),
      ]);

      if (orgData) {
        setBusinessName(orgData.name || '');
        setBusinessAddress(orgData.address || '');
      }

      setBusinessRating(rating);

      setStats({
        totalLocations: locs.length,
        activeBookings: bookingMetrics.activeBookings,
        valetersOnline: teamCount, // if you have a real "online" field later, we can replace this
        todayRevenue: 0,
        totalRevenue: 0,
        completionRate: bookingMetrics.completionRate,
        averageRating: rating,
        bookingsThisWeek: bookingMetrics.bookingsThisWeek,
      });
    } catch (error: any) {
      console.error('Error loading business data:', error);
      Alert.alert('Error', error?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const loadLocations = async (): Promise<Location[]> => {
    if (!organizationId) return [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const list = (data || []) as Location[];
      setLocations(list);
      return list;
    } catch (error) {
      console.error('Error loading locations:', error);
      return [];
    }
  };

  const loadOrganizationData = async () => {
    if (!organizationId) return null;
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('name, address')
        .eq('id', organizationId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    } catch (error) {
      console.error('Error loading organization data:', error);
      return null;
    }
  };

  /**
   * ✅ IMPORTANT FIX:
   * Your bookings table DOES NOT have bookings.location_id.
   * We scope bookings to this business using location_address matching
   * the org's car_wash_locations.address list.
   */
  const loadBookingMetrics = async () => {
    if (!organizationId) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    // 1) Get addresses for this org
    const { data: locs, error: locErr } = await supabase
      .from('car_wash_locations')
      .select('address')
      .eq('organization_id', organizationId);

    if (locErr) throw locErr;

    const addresses = (locs || [])
      .map((l: any) => l.address)
      .filter((a: any) => typeof a === 'string' && a.trim().length > 0) as string[];

    if (addresses.length === 0) {
      // No locations = no location-scoped bookings
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    // 2) Load bookings for those addresses (select only columns we KNOW exist)
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select('id, status, created_at')
      .in('location_address', addresses)
      .order('created_at', { ascending: false })
      .limit(500);

    if (error) throw error;

    const rows = (bookings || []) as { id: string; status: BookingStatus; created_at: string }[];

    const ACTIVE_STATUSES: BookingStatus[] = ['confirmed', 'in_progress', 'pending_business_acceptance', 'pending_valeter_acceptance'];
    const COMPLETE_STATUSES: BookingStatus[] = ['completed'];
    const CANCEL_STATUSES: BookingStatus[] = ['cancelled'];

    const activeBookings = rows.filter((b) => ACTIVE_STATUSES.includes(b.status)).length;

    const bookingsThisWeek = rows.filter((b) => {
      const t = new Date(b.created_at).getTime();
      return Number.isFinite(t) && t >= weekAgo.getTime();
    }).length;

    const completed = rows.filter((b) => COMPLETE_STATUSES.includes(b.status)).length;
    const cancelled = rows.filter((b) => CANCEL_STATUSES.includes(b.status)).length;
    const finished = completed + cancelled;

    // Completion rate: completed / (completed+cancelled) * 100
    const completionRate = finished > 0 ? Math.round((completed / finished) * 100) : 0;

    return { activeBookings, bookingsThisWeek, completionRate };
  };

  const loadTeamCount = async (): Promise<number> => {
    if (!organizationId) return 0;

    try {
      // count valeters belonging to this org
      const { count, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (error) throw error;
      return count || 0;
    } catch (e) {
      console.warn('Error loading team count:', e);
      return 0;
    }
  };

  const fetchNotificationCount = async () => {
    if (!organizationId) return;

    try {
      // Get all valeters belonging to this organization
      const { data: valeters } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      const valeterIds = valeters?.map((v: any) => v.id) || [];

      let newBookingsCount = 0;
      if (valeterIds.length > 0) {
        const { count } = await supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .in('valeter_id', valeterIds)
          .in('status', ['pending', 'pending_valeter_acceptance', 'pending_payment', 'confirmed', 'valeter_assigned']);
        newBookingsCount = count || 0;
      }

      const { count: teamRequestsCount } = await supabase
        .from('team_requests')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('status', 'pending');

      setNotificationCount(newBookingsCount + (teamRequestsCount || 0));
    } catch (error) {
      console.error('Error fetching notification count:', error);
      setNotificationCount(0);
    }
  };

  const calculateBusinessRating = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valetersError) throw valetersError;
      if (!valeters || valeters.length === 0) return 0;

      const valeterIds = valeters.map((v: any) => v.id);

      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('rating, status, valeter_id')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('rating', 'is', null);

      if (bookingsError) throw bookingsError;
      if (!bookings || bookings.length === 0) return 0;

      const ratings = bookings
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);

      if (ratings.length === 0) return 0;

      const average = ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length;
      return Math.round(average * 10) / 10;
    } catch (error) {
      console.error('Error calculating business rating:', error);
      return 0;
    }
  };

  const quickActions = [
    {
      id: 'bookings',
      title: 'View Bookings',
      subtitle: 'Manage all',
      icon: 'calendar',
      gradient: ['#3B82F6', '#2563EB'],
      route: '/business/bookings',
    },
    {
      id: 'services',
      title: 'Services & Pricing',
      subtitle: 'View options',
      icon: 'list',
      gradient: ['#8B5CF6', '#7C3AED'],
      route: '/business/services',
    },
    {
      id: 'locations',
      title: 'Locations',
      subtitle: 'Manage sites',
      icon: 'location',
      gradient: ['#10B981', '#059669'],
      route: '/business/locations',
    },
    {
      id: 'team',
      title: 'Team',
      subtitle: 'Manage staff',
      icon: 'people',
      gradient: ['#F59E0B', '#D97706'],
      route: '/business/team',
    },
    {
      id: 'analytics',
      title: 'Analytics',
      subtitle: 'View insights',
      icon: 'stats-chart',
      gradient: [businessTheme.primary, businessTheme.primaryAlt],
      route: '/business/analytics',
    },
    {
      id: 'settings',
      title: 'Settings',
      subtitle: 'Configure',
      icon: 'settings',
      gradient: [businessTheme.primaryAlt, businessTheme.primary],
      route: '/business/settings',
    },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Dashboard" showBack={false} accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading business data...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader
        title={businessName || 'Business Overview'}
        subtitle={businessAddress || `${getGreeting()}${user?.name ? `, ${user.name.split(' ')[0]}` : ''}`}
        variant="dashboard"
        accountType="business"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        businessName={businessName}
        businessAddress={businessAddress}
        businessRating={businessRating}
        rightAction={
          <GradientNotificationBell
            count={notificationCount}
            onPress={() => router.push('/business/notifications')}
            accentColor={businessTheme.primary}
          />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET }]}
      >
        {/* Key Metrics */}
        <View style={styles.metricsSection}>
          <Text style={styles.sectionTitle}>Key Metrics</Text>
          <View style={styles.metricsGrid}>
            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="calendar" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.activeBookings}</Text>
                      <Text style={styles.metricLabel}>Active Bookings</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${Math.min((stats.activeBookings / 20) * 100, 100)}%`,
                            backgroundColor: businessTheme.primaryAlt,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>{stats.bookingsThisWeek} this week</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="location" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.totalLocations}</Text>
                      <Text style={styles.metricLabel}>Locations</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${Math.min((stats.totalLocations / 10) * 100, 100)}%`,
                            backgroundColor: businessTheme.primary,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>Managed sites</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="people" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.valetersOnline}</Text>
                      <Text style={styles.metricLabel}>Team Members</Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${Math.min((stats.valetersOnline / 10) * 100, 100)}%`,
                            backgroundColor: businessTheme.primary,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>Assigned to org</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>

            <Animated.View style={[{ opacity: fadeAnim }]}>
              <GlassCard style={styles.metricCard} accountType="business">
                <View style={styles.metricContent}>
                  <View style={styles.metricHeader}>
                    <View style={styles.metricIconWrapper}>
                      <Ionicons name="trending-up" size={20} color={businessTheme.primary} />
                    </View>
                    <View style={styles.metricText}>
                      <Text style={styles.metricValue}>{stats.completionRate}%</Text>
                      <Text style={styles.metricLabel} numberOfLines={1}>
                        Completion Rate
                      </Text>
                    </View>
                  </View>
                  <View style={styles.metricProgressContainer}>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${Math.min(stats.completionRate, 100)}%`,
                            backgroundColor: businessTheme.primary,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>Completed vs cancelled</Text>
                  </View>
                </View>
              </GlassCard>
            </Animated.View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickActionsContainer}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                activeOpacity={0.85}
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push(action.route as any);
                }}
                style={styles.quickActionCard}
              >
                <View style={styles.quickActionContent}>
                  <View style={styles.quickActionIconWrapper}>
                    <Ionicons name={action.icon as any} size={18} color={businessTheme.primary} />
                  </View>
                  <View style={styles.quickActionTextContainer}>
                    <Text style={styles.quickActionTitle}>{action.title}</Text>
                    <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Locations Summary */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Locations</Text>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/locations');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {locations.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>Add your first physical location to start accepting bookings</Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    router.push('/business/locations');
                  }}
                  style={styles.addButton}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={['#10B981', '#059669']} style={styles.addButtonGradient}>
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          ) : (
            <View style={styles.locationsList}>
              {locations.slice(0, 3).map((location, index) => (
                <Animated.View
                  key={location.id}
                  style={[
                    { opacity: fadeAnim },
                    {
                      transform: [
                        {
                          translateY: fadeAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: [30 + index * 10, 0],
                          }),
                        },
                      ],
                    },
                  ]}
                >
                  <GlassCard
                    onPress={async () => {
                      await hapticFeedback('light');
                      router.push(`/business/locations/${location.id}` as any);
                    }}
                    style={styles.locationCard}
                    accountType="business"
                  >
                    <View style={styles.locationContent}>
                      <View style={styles.locationIconWrapper}>
                        <Ionicons name="location" size={20} color={businessTheme.primary} />
                      </View>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationAddress} numberOfLines={1}>
                          {location.address || 'Address not set'}
                        </Text>
                      </View>
                      <Ionicons name="chevron-forward" size={18} color={businessTheme.primary} />
                    </View>
                  </GlassCard>
                </Animated.View>
              ))}
              {locations.length > 3 && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push('/business/locations');
                  }}
                  style={styles.viewMoreButton}
                >
                  <Text style={styles.viewMoreText}>
                    View {locations.length - 3} more location{locations.length - 3 !== 1 ? 's' : ''}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        <View style={styles.poweredBySection}>
          <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },

  scrollView: { flex: 1 },
  scrollContent: { padding: isSmallScreen ? 16 : 20, paddingBottom: 100 },

  metricsSection: { marginBottom: 32 },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  metricCard: { width: getMetricCardWidth(2, SPACING.md), ...CARD_SIZES.small },
  metricContent: { padding: CARD_SIZES.small.padding },
  metricHeader: { flexDirection: 'row', alignItems: 'center', gap: SPACING.md, marginBottom: SPACING.lg },
  metricIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: `${businessTheme.primary}26`,
  },
  metricText: { flex: 1 },
  metricValue: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginBottom: 2 },
  metricLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '500' },
  metricProgressContainer: { alignItems: 'center' },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressFill: { height: '100%', borderRadius: 2 },
  progressText: { color: 'rgba(249,250,251,0.6)', fontSize: 9, fontWeight: '500' },

  quickActionsSection: { marginBottom: 32 },
  quickActionsContainer: { paddingRight: isSmallScreen ? 16 : 20 },
  quickActionCard: {
    borderRadius: 16,
    backgroundColor: `${businessTheme.primary}1A`,
    borderWidth: 1,
    borderColor: `${businessTheme.primary}33`,
    width: 130,
    marginRight: 12,
  },
  quickActionContent: { padding: SPACING.md, gap: SPACING.sm },
  quickActionIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  quickActionTextContainer: { gap: 2 },
  quickActionTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '700', letterSpacing: 0.1 },
  quickActionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '500' },

  section: { marginBottom: 32 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  viewAllText: { color: SKY, fontSize: 14, fontWeight: '600' },

  locationsList: { gap: 12 },
  locationCard: { ...CARD_SIZES.small },
  locationContent: { flexDirection: 'row', alignItems: 'center', gap: SPACING.lg, padding: CARD_SIZES.small.padding },
  locationIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${businessTheme.primary}26`,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: { flex: 1 },
  locationName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 4, letterSpacing: 0.2 },
  locationAddress: { color: 'rgba(249,250,251,0.7)', fontSize: 13, lineHeight: 18 },

  emptyCard: { ...CARD_SIZES.large },
  emptyContent: { alignItems: 'center' },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginTop: 20, marginBottom: 12 },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, textAlign: 'center', marginBottom: 24, lineHeight: 20 },

  addButton: { borderRadius: 16, overflow: 'hidden' },
  addButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 22 },
  addButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800' },

  viewMoreButton: { padding: 12, alignItems: 'center' },
  viewMoreText: { color: SKY, fontSize: 14, fontWeight: '600' },

  poweredBySection: { alignItems: 'center', paddingVertical: 24, marginTop: 8 },
  poweredByText: { color: SKY, fontSize: 12, opacity: 0.8, fontWeight: '600' },
});
