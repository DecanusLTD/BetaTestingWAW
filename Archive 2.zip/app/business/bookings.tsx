import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusBadge from '../../src/components/booking/StatusBadge';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface BookingUI {
  id: string;
  customer_name: string;
  service_type: string;
  location_address: string | null;
  scheduled_time: string | null;
  status: string;
  assigned_valeter_name: string | null;
  created_at: string;
  customer_on_way?: boolean;
  cancelled?: boolean;
  has_report?: boolean;
}

type RawBookingRow = {
  id: string;
  status?: string | null;
  created_at: string;

  // optional columns (may or may not exist)
  customer_name?: string | null;
  service_type?: string | null;
  location_address?: string | null;
  valeter_id?: string | null;

  // time column (unknown name) — we’ll read it dynamically
  [key: string]: any;
};

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

/**
 * Your DB uses an enum booking_status.
 * This error happens when we pass a value that enum doesn't support.
 * So we MUST NOT send unknown status values in a SQL filter.
 *
 * We'll *try* a status filter, and if Postgres rejects it (22P02),
 * we retry WITHOUT filtering by status and then filter client-side.
 */
const STATUS_CANDIDATES_TO_TRY = [
  // These are *app-level* expectations; DB may differ.
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'confirmed',
  'in_progress',
  'completed',
  'cancelled',
];

const TIME_CANDIDATES = [
  'scheduled_time',
  'scheduled_at',
  'scheduled_for',
  'start_time',
  'start_at',
  'booking_time',
  'booked_for',
  'date_time',
  'datetime',
  'scheduled_datetime',
];

export default function BusinessBookings() {
  const { user } = useAuth();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [bookings, setBookings] = useState<BookingUI[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();

    if (isOrgUser && organizationId) {
      loadBookings();
    } else {
      setBookings([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser, filterStatus]);

  const loadBookings = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);

      // 1) Fetch org locations
      const { data: locations, error: locErr } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('organization_id', organizationId);

      if (locErr) throw locErr;

      const locationAddresses = (locations || [])
        .map((l: any) => (typeof l.address === 'string' ? l.address.trim() : ''))
        .filter((a: string) => a.length > 0);

      if (locationAddresses.length === 0) {
        setBookings([]);
        return;
      }

      // 2) Fetch bookings safely (no enum assumptions)
      const { rows, resolvedTimeField } = await fetchBookingsForAddresses(locationAddresses);

      // 3) Resolve valeter names if valeter_id exists
      const valeterIds = Array.from(new Set(rows.map(r => r.valeter_id).filter(Boolean))) as string[];
      const profileMap = new Map<string, string>();

      if (valeterIds.length > 0) {
        const { data: profiles, error: profErr } = await supabase
          .from('profiles')
          .select('id, full_name, name')
          .in('id', valeterIds);

        if (profErr) {
          console.warn('[BusinessBookings] valeter name lookup error:', profErr.message);
        } else {
          (profiles || []).forEach((p: any) => {
            profileMap.set(p.id, (p.full_name || p.name || 'Valeter') as string);
          });
        }
      }

      const enriched: BookingUI[] = rows.map((b) => {
        const scheduledValue =
          resolvedTimeField && b[resolvedTimeField] ? String(b[resolvedTimeField]) : null;

        const status = String(b.status ?? 'unknown');

        return {
          id: b.id,
          customer_name: (b.customer_name || 'Customer') as string,
          service_type: (b.service_type || 'Service') as string,
          location_address: b.location_address ?? null,
          scheduled_time: scheduledValue,
          status,
          assigned_valeter_name: b.valeter_id ? profileMap.get(b.valeter_id) || null : null,
          created_at: b.created_at,
          customer_on_way: status === 'in_progress',
          cancelled: status === 'cancelled',
          has_report: false,
        };
      });

      // Filter client-side (safe even if DB enum doesn't match our labels)
      const filtered = filterStatus ? enriched.filter((b) => b.status === filterStatus) : enriched;
      setBookings(filtered);
    } catch (error: any) {
      console.error('Error loading bookings:', error);
      Alert.alert('Error', error?.message || 'Failed to load bookings');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Fetch bookings matching location_address in a schema-safe way.
   * - never touches customer_id
   * - never assumes scheduled_time exists
   * - never assumes our status values exist in DB enum (retries without status filter if rejected)
   */
  const fetchBookingsForAddresses = async (
    locationAddresses: string[]
  ): Promise<{ rows: RawBookingRow[]; resolvedTimeField: string | null }> => {
    // Base select that *might* exist; we’ll remove missing ones on the fly
    const baseFields = ['id', 'created_at', 'status', 'location_address', 'service_type', 'customer_name', 'valeter_id'];

    // Try time fields; if none exist, fetch without time field
    const timeAttempts = [...TIME_CANDIDATES, null] as (string | null)[];

    let lastErr: any = null;

    // If DB rejects our enum filter once, never try it again in this call
    let disableStatusFilter = false;

    for (const timeField of timeAttempts) {
      // Build select list
      const fields = timeField ? [...baseFields, timeField] : [...baseFields];

      // We might have removed some baseFields in prior loops; ensure uniqueness
      const uniqueFields = Array.from(new Set(fields));

      // Build query
      let q = supabase
        .from('bookings')
        .select(uniqueFields.join(','))
        .in('location_address', locationAddresses as any)
        .order('created_at', { ascending: false })
        .limit(100);

      // Try to pre-filter by status ONLY if not disabled (but this may be rejected by enum)
      if (!disableStatusFilter) {
        q = q.in('status', STATUS_CANDIDATES_TO_TRY as any);
      }

      const { data, error } = await q;

      if (!error) {
        return {
          rows: (data || []) as RawBookingRow[],
          resolvedTimeField: timeField,
        };
      }

      lastErr = error;

      // 🔥 Enum rejection: "invalid input value for enum booking_status"
      // Postgres error code 22P02 -> retry WITHOUT status filter
      if (error?.code === '22P02' && /enum\s+booking_status/i.test(error?.message || '')) {
        disableStatusFilter = true;
        // retry same timeField immediately without status filter
        const { data: data2, error: err2 } = await supabase
          .from('bookings')
          .select(uniqueFields.join(','))
          .in('location_address', locationAddresses as any)
          .order('created_at', { ascending: false })
          .limit(100);

        if (!err2) {
          return {
            rows: (data2 || []) as RawBookingRow[],
            resolvedTimeField: timeField,
          };
        }

        lastErr = err2;
        // continue loop (maybe missing columns too)
      }

      // Missing column? Try next combination.
      const missing = getMissingColumn(error?.message);
      if (error?.code === '42703' && missing) {
        // If the missing column is one of the base fields, remove it and retry this timeField
        if (baseFields.includes(missing)) {
          const idx = baseFields.indexOf(missing);
          if (idx >= 0) baseFields.splice(idx, 1);
          // retry same timeField after removing missing base field
          continue;
        }

        // If missing is the timeField, move on
        continue;
      }

      // Non-schema error -> throw
      throw error;
    }

    throw lastErr ?? new Error('Failed to load bookings');
  };

  // NOTE: These are UI filters. If your DB enum uses different labels,
  // update these values to match what’s actually stored in bookings.status.
  const statusFilters = [
    { label: 'All', value: null },
    { label: 'Pending', value: 'pending_business_acceptance' },
    { label: 'Confirmed', value: 'confirmed' },
    { label: 'In Progress', value: 'in_progress' },
    { label: 'Completed', value: 'completed' },
    { label: 'Cancelled', value: 'cancelled' },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading bookings...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Bookings"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {/* Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.filtersContainer}
          contentContainerStyle={styles.filtersContent}
        >
          {statusFilters.map((filter) => (
            <TouchableOpacity
              key={filter.value || 'all'}
              onPress={async () => {
                await hapticFeedback('light');
                setFilterStatus(filter.value);
              }}
              style={styles.filterButton}
            >
              <GlassCard
                style={[styles.filterCard, filterStatus === filter.value && styles.filterCardActive]}
                accountType="business"
              >
                <Text style={[styles.filterText, filterStatus === filter.value && styles.filterTextActive]}>
                  {filter.label}
                </Text>
              </GlassCard>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* List */}
        {bookings.length === 0 ? (
          <Animated.View style={[styles.emptyContainer, { opacity: fadeAnim }]}>
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="calendar-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
                <Text style={styles.emptyTitle}>No bookings yet</Text>
                <Text style={styles.emptyText}>
                  {filterStatus
                    ? `No ${statusFilters.find((f) => f.value === filterStatus)?.label.toLowerCase()} bookings`
                    : 'Bookings will appear here as customers book your services'}
                </Text>
              </View>
            </GlassCard>
          </Animated.View>
        ) : (
          <View style={styles.bookingsList}>
            {bookings.map((booking, index) => (
              <Animated.View
                key={booking.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateY: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [30 + index * 10, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push(`/business/bookings/${booking.id}` as any);
                  }}
                  style={styles.bookingCard}
                  accountType="business"
                >
                  <View style={styles.bookingHeader}>
                    <View style={styles.bookingInfo}>
                      <Text style={styles.customerName}>{booking.customer_name}</Text>
                      <Text style={styles.serviceType}>{booking.service_type}</Text>
                    </View>
                    <StatusBadge status={booking.status as any} size="small" />
                  </View>

                  <View style={styles.bookingDetails}>
                    {booking.location_address && (
                      <View style={styles.detailRow}>
                        <Ionicons name="location" size={16} color={SKY} />
                        <Text style={styles.detailText} numberOfLines={1}>
                          {booking.location_address}
                        </Text>
                      </View>
                    )}

                    {booking.scheduled_time && (
                      <View style={styles.detailRow}>
                        <Ionicons name="time" size={16} color={SKY} />
                        <Text style={styles.detailText}>
                          {new Date(booking.scheduled_time).toLocaleString()}
                        </Text>
                      </View>
                    )}

                    {booking.assigned_valeter_name && (
                      <View style={styles.detailRow}>
                        <Ionicons name="person" size={16} color={SKY} />
                        <Text style={styles.detailText}>{booking.assigned_valeter_name}</Text>
                      </View>
                    )}
                  </View>

                  <View style={styles.bookingActions}>
                    <TouchableOpacity
                      onPress={async (e: any) => {
                        e?.stopPropagation?.();
                        await hapticFeedback('light');
                        router.push(`/business/bookings/${booking.id}` as any);
                      }}
                      style={styles.actionButton}
                    >
                      <Text style={styles.actionText}>View Details</Text>
                      <Ionicons name="chevron-forward" size={16} color={SKY} />
                    </TouchableOpacity>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </View>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },

  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  filtersContainer: { marginBottom: 12 },
  filtersContent: { gap: 12, paddingRight: 20 },
  filterButton: { marginRight: 8 },
  filterCard: { paddingHorizontal: 16, paddingVertical: 10 },
  filterCardActive: { backgroundColor: 'rgba(135,206,235,0.15)' },
  filterText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, fontWeight: '600' },
  filterTextActive: { color: SKY, fontWeight: '700' },

  emptyContainer: { flex: 1, justifyContent: 'center', minHeight: 300, marginTop: 8 },
  emptyCard: { padding: 40 },
  emptyContent: { alignItems: 'center' },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginTop: 20, marginBottom: 12 },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, textAlign: 'center', lineHeight: 20 },

  bookingsList: { gap: 16 },
  bookingCard: { padding: 16 },

  bookingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  bookingInfo: { flex: 1 },
  customerName: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  serviceType: { color: 'rgba(249,250,251,0.7)', fontSize: 14 },

  bookingDetails: { gap: 8, marginBottom: 12 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  detailText: { color: 'rgba(249,250,251,0.7)', fontSize: 13, flex: 1 },

  bookingActions: { paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(135,206,235,0.15)' },
  actionButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  actionText: { color: SKY, fontSize: 14, fontWeight: '600' },
});
