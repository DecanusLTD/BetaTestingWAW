// app/business/locations/[id].tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Animated,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  ScrollView,
  Dimensions,
  Platform,
  KeyboardAvoidingView,
  Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';

import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type AnyRow = Record<string, any>;

interface LocationRow {
  id: string;
  organization_id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at?: string;
}

interface LocationServiceRow {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
  created_at?: string;
}

const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

export default function BusinessLocationDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [location, setLocation] = useState<LocationRow | null>(null);

  // editable fields
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [isActive, setIsActive] = useState(true);

  // services
  const [services, setServices] = useState<LocationServiceRow[]>([]);
  const [servicesEnabled, setServicesEnabled] = useState(true);
  const [servicesTableOk, setServicesTableOk] = useState(true);

  const [showAddService, setShowAddService] = useState(false);
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState('');
  const [newServiceDuration, setNewServiceDuration] = useState('');

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!id || !isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isOrgUser, organizationId]);

  const loadAll = async () => {
    try {
      setLoading(true);
      await Promise.all([loadLocation(), loadServices()]);
    } catch (e) {
      console.error('[LocationDetails] loadAll error:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadLocation = async () => {
    if (!id || !organizationId) return;

    const { data, error } = await supabase
      .from('car_wash_locations')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    if (!data) {
      setLocation(null);
      return;
    }

    // Security: ensure org owns this location
    if ((data as AnyRow).organization_id !== organizationId) {
      setLocation(null);
      Alert.alert('Access denied', 'That location does not belong to this business.');
      router.back();
      return;
    }

    const row = data as LocationRow;
    setLocation(row);

    setName(row.name ?? '');
    setAddress(row.address ?? '');
    setStatus(((row.status ?? (row.is_active ? 'active' : 'inactive')) as any) === 'inactive' ? 'inactive' : 'active');
    setIsActive(row.is_active === null || row.is_active === undefined ? (row.status !== 'inactive') : !!row.is_active);
  };

  const loadServices = async () => {
    if (!id) return;

    // If you don’t have this table yet, this will error — we catch and show a nice message.
    const { data, error } = await supabase
      .from('location_services')
      .select('*')
      .eq('location_id', id)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[LocationDetails] location_services not available (or policy denied):', error.message);
      setServicesTableOk(false);
      setServices([]);
      return;
    }

    setServicesTableOk(true);
    setServices((data || []) as LocationServiceRow[]);
  };

  const handleSaveLocation = async () => {
    if (!location?.id) return;

    if (!name.trim()) {
      Alert.alert('Missing info', 'Location name is required.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const nextStatus = isActive ? 'active' : 'inactive';

      const { error } = await supabase
        .from('car_wash_locations')
        .update({
          name: name.trim(),
          address: address.trim() ? address.trim() : null,
          status: nextStatus,
          is_active: isActive,
        })
        .eq('id', location.id);

      if (error) throw error;

      await loadLocation();
      Alert.alert('Saved', 'Location updated.');
    } catch (e: any) {
      console.error('[LocationDetails] save error:', e);
      Alert.alert('Error', e?.message || 'Failed to save location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = async () => {
    if (!location?.id) return;

    Alert.alert(
      'Delete location',
      'Are you sure? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              setSaving(true);
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('car_wash_locations')
                .delete()
                .eq('id', location.id);

              if (error) throw error;

              Alert.alert('Deleted', 'Location removed.');
              router.back();
            } catch (e: any) {
              console.error('[LocationDetails] delete error:', e);
              Alert.alert('Error', e?.message || 'Failed to delete location');
            } finally {
              setSaving(false);
            }
          },
        },
      ]
    );
  };

  const handleToggleService = async (service: LocationServiceRow, next: boolean) => {
    if (!servicesTableOk) return;

    try {
      await hapticFeedback('light');

      const { error } = await supabase
        .from('location_services')
        .update({ is_enabled: next })
        .eq('id', service.id);

      if (error) throw error;

      setServices((prev) =>
        prev.map((s) => (s.id === service.id ? { ...s, is_enabled: next } : s))
      );
    } catch (e: any) {
      console.error('[LocationDetails] toggle service error:', e);
      Alert.alert('Error', e?.message || 'Failed to update service');
    }
  };

  const handleSaveServiceInline = async (service: LocationServiceRow, patch: Partial<LocationServiceRow>) => {
    if (!servicesTableOk) return;

    try {
      const { error } = await supabase
        .from('location_services')
        .update(patch)
        .eq('id', service.id);

      if (error) throw error;

      setServices((prev) =>
        prev.map((s) => (s.id === service.id ? { ...s, ...patch } : s))
      );
    } catch (e: any) {
      console.error('[LocationDetails] save service inline error:', e);
      Alert.alert('Error', e?.message || 'Failed to update pricing');
    }
  };

  const handleAddService = async () => {
    if (!servicesTableOk) {
      Alert.alert(
        'Not configured',
        'The services/pricing table is not set up yet. Ask me and I’ll generate the SQL for it.'
      );
      return;
    }

    if (!newServiceName.trim()) {
      Alert.alert('Missing info', 'Service name is required.');
      return;
    }

    const price = newServicePrice.trim() ? Number(newServicePrice) : null;
    const duration = newServiceDuration.trim() ? Number(newServiceDuration) : null;

    if (newServicePrice.trim() && (!Number.isFinite(price!) || price! < 0)) {
      Alert.alert('Invalid price', 'Enter a valid number.');
      return;
    }
    if (newServiceDuration.trim() && (!Number.isFinite(duration!) || duration! < 0)) {
      Alert.alert('Invalid duration', 'Enter minutes as a number.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('location_services')
        .insert({
          location_id: id,
          service_name: newServiceName.trim(),
          is_enabled: true,
          price,
          duration_minutes: duration,
        });

      if (error) throw error;

      setShowAddService(false);
      setNewServiceName('');
      setNewServicePrice('');
      setNewServiceDuration('');

      await loadServices();
      Alert.alert('Added', 'Service created.');
    } catch (e: any) {
      console.error('[LocationDetails] add service error:', e);
      Alert.alert('Error', e?.message || 'Failed to add service');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteService = async (serviceId: string) => {
    if (!servicesTableOk) return;

    Alert.alert('Remove service', 'Delete this service from the location?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setSaving(true);
            await hapticFeedback('medium');

            const { error } = await supabase.from('location_services').delete().eq('id', serviceId);
            if (error) throw error;

            setServices((prev) => prev.filter((s) => s.id !== serviceId));
          } catch (e: any) {
            console.error('[LocationDetails] delete service error:', e);
            Alert.alert('Error', e?.message || 'Failed to delete service');
          } finally {
            setSaving(false);
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading location...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!location) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={36} color={SKY} style={{ opacity: 0.8 }} />
          <Text style={styles.loadingText}>Location not found.</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={[styles.primaryBtn, { marginTop: 12 }]}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
              <Text style={styles.primaryBtnText}>Go back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={location.name || 'Location'}
        subtitle={location.address || 'Edit details & services'}
        accountType="business"
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              handleSaveLocation();
            }}
            style={styles.headerSaveBtn}
            disabled={saving}
          >
            <Ionicons name="save-outline" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={16}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* DETAILS */}
          <Animated.View style={{ opacity: fadeAnim }}>
            <Text style={styles.sectionTitle}>Location Details</Text>

            <GlassCard style={styles.card} accountType="business">
              <View style={styles.field}>
                <Text style={styles.label}>Location name</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder="e.g., Main Car Wash Hub"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={styles.input}
                  />
                </GlassCard>
              </View>

              <View style={styles.field}>
                <Text style={styles.label}>Address</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={address}
                    onChangeText={setAddress}
                    placeholder="Enter full address"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={[styles.input, styles.textArea]}
                    multiline
                    numberOfLines={3}
                  />
                </GlassCard>
              </View>

              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Active</Text>
                  <Text style={styles.miniText}>
                    If off, this location won’t show for bookings.
                  </Text>
                </View>
                <Switch
                  value={isActive}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setIsActive(v);
                    setStatus(v ? 'active' : 'inactive');
                  }}
                />
              </View>

              <View style={styles.actionsRow}>
                <TouchableOpacity
                  onPress={handleSaveLocation}
                  disabled={saving}
                  style={[styles.primaryBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={[businessTheme.primary, businessTheme.primaryAlt]}
                    style={styles.primaryBtnGrad}
                  >
                    {saving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#fff" />
                        <Text style={styles.primaryBtnText}>Save changes</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={handleDeleteLocation}
                  disabled={saving}
                  style={[styles.dangerBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <View style={styles.dangerBtnInner}>
                    <Ionicons name="trash-outline" size={18} color="#EF4444" />
                    <Text style={styles.dangerBtnText}>Delete</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Animated.View>

          {/* SERVICES + PRICING */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Services & Pricing</Text>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setShowAddService(true);
                }}
                style={styles.smallAddBtn}
                activeOpacity={0.85}
              >
                <Ionicons name="add" size={18} color={SKY} />
              </TouchableOpacity>
            </View>

            {!servicesTableOk ? (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 10 }}>
                  <View style={styles.row}>
                    <Ionicons name="information-circle-outline" size={18} color={SKY} />
                    <Text style={styles.infoText}>
                      Services/pricing isn’t wired up yet (missing table or policy).
                    </Text>
                  </View>
                  <Text style={styles.miniText}>
                    If you want, I can generate the SQL + RLS policies for a per-location services table.
                  </Text>
                </View>
              </GlassCard>
            ) : (
              <GlassCard style={styles.card} accountType="business">
                {services.length === 0 ? (
                  <View style={{ alignItems: 'center', gap: 10, paddingVertical: 6 }}>
                    <Ionicons name="pricetags-outline" size={34} color={SKY} style={{ opacity: 0.6 }} />
                    <Text style={styles.emptyTitle}>No services yet</Text>
                    <Text style={styles.miniText}>
                      Add services and set pricing for this location.
                    </Text>

                    <TouchableOpacity
                      onPress={async () => {
                        await hapticFeedback('medium');
                        setShowAddService(true);
                      }}
                      style={[styles.primaryBtn, { marginTop: 6 }]}
                      activeOpacity={0.85}
                    >
                      <LinearGradient colors={['#10B981', '#059669']} style={styles.primaryBtnGrad}>
                        <Ionicons name="add" size={18} color="#fff" />
                        <Text style={styles.primaryBtnText}>Add a service</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  </View>
                ) : (
                  <View style={{ gap: 12 }}>
                    {services.map((s) => (
                      <View key={s.id} style={styles.serviceRow}>
                        <View style={{ flex: 1 }}>
                          <View style={styles.rowBetween}>
                            <Text style={styles.serviceName} numberOfLines={1}>
                              {s.service_name}
                            </Text>

                            <TouchableOpacity
                              onPress={() => handleDeleteService(s.id)}
                              style={styles.iconBtn}
                              activeOpacity={0.85}
                            >
                              <Ionicons name="trash-outline" size={18} color="#EF4444" />
                            </TouchableOpacity>
                          </View>

                          <View style={styles.serviceMetaRow}>
                            <View style={styles.serviceChip}>
                              <Text style={styles.serviceChipText}>£{money(s.price)}</Text>
                            </View>
                            <View style={styles.serviceChip}>
                              <Text style={styles.serviceChipText}>
                                {s.duration_minutes ? `${s.duration_minutes} min` : '— min'}
                              </Text>
                            </View>
                          </View>

                          {/* Inline edit */}
                          <View style={styles.inlineEditRow}>
                            <View style={{ flex: 1 }}>
                              <Text style={styles.inlineLabel}>Price (£)</Text>
                              <GlassCard style={styles.inlineInputCard} accountType="business">
                                <TextInput
                                  defaultValue={s.price === null || s.price === undefined ? '' : String(s.price)}
                                  placeholder="0"
                                  placeholderTextColor="rgba(249,250,251,0.45)"
                                  keyboardType="decimal-pad"
                                  style={styles.inlineInput}
                                  onEndEditing={(e) => {
                                    const raw = (e.nativeEvent.text || '').trim();
                                    const v = raw ? Number(raw) : null;
                                    if (raw && (!Number.isFinite(v as any) || (v as any) < 0)) return;
                                    handleSaveServiceInline(s, { price: v });
                                  }}
                                />
                              </GlassCard>
                            </View>

                            <View style={{ width: 110 }}>
                              <Text style={styles.inlineLabel}>Minutes</Text>
                              <GlassCard style={styles.inlineInputCard} accountType="business">
                                <TextInput
                                  defaultValue={
                                    s.duration_minutes === null || s.duration_minutes === undefined
                                      ? ''
                                      : String(s.duration_minutes)
                                  }
                                  placeholder="—"
                                  placeholderTextColor="rgba(249,250,251,0.45)"
                                  keyboardType="number-pad"
                                  style={styles.inlineInput}
                                  onEndEditing={(e) => {
                                    const raw = (e.nativeEvent.text || '').trim();
                                    const v = raw ? Number(raw) : null;
                                    if (raw && (!Number.isFinite(v as any) || (v as any) < 0)) return;
                                    handleSaveServiceInline(s, { duration_minutes: v });
                                  }}
                                />
                              </GlassCard>
                            </View>
                          </View>
                        </View>

                        <View style={{ alignItems: 'flex-end', gap: 8 }}>
                          <Text style={styles.inlineLabel}>Available</Text>
                          <Switch
                            value={!!s.is_enabled}
                            onValueChange={(v) => handleToggleService(s, v)}
                          />
                        </View>
                      </View>
                    ))}
                  </View>
                )}
              </GlassCard>
            )}
          </Animated.View>

          <View style={{ height: 28 }} />
        </Animated.ScrollView>
      </KeyboardAvoidingView>

      {/* ADD SERVICE MODAL */}
      <Modal visible={showAddService} animationType="slide" transparent onRequestClose={() => setShowAddService(false)}>
        <View style={styles.modalOverlay}>
          <GlassCard style={styles.modalCard} accountType="business">
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Service</Text>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setShowAddService(false);
                }}
                style={styles.iconBtn}
              >
                <Ionicons name="close" size={22} color={SKY} />
              </TouchableOpacity>
            </View>

            <View style={{ gap: 12 }}>
              <View style={styles.field}>
                <Text style={styles.label}>Service name</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={newServiceName}
                    onChangeText={setNewServiceName}
                    placeholder="e.g., Exterior Wash"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={styles.input}
                  />
                </GlassCard>
              </View>

              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Price (£)</Text>
                  <GlassCard style={styles.inputCard} accountType="business">
                    <TextInput
                      value={newServicePrice}
                      onChangeText={setNewServicePrice}
                      placeholder="e.g., 25"
                      placeholderTextColor="rgba(249,250,251,0.5)"
                      keyboardType="decimal-pad"
                      style={styles.input}
                    />
                  </GlassCard>
                </View>

                <View style={{ width: 140 }}>
                  <Text style={styles.label}>Duration (min)</Text>
                  <GlassCard style={styles.inputCard} accountType="business">
                    <TextInput
                      value={newServiceDuration}
                      onChangeText={setNewServiceDuration}
                      placeholder="e.g., 45"
                      placeholderTextColor="rgba(249,250,251,0.5)"
                      keyboardType="number-pad"
                      style={styles.input}
                    />
                  </GlassCard>
                </View>
              </View>

              <TouchableOpacity
                onPress={handleAddService}
                disabled={saving}
                style={[styles.primaryBtn, saving && { opacity: 0.7 }]}
                activeOpacity={0.85}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.primaryBtnGrad}>
                  {saving ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name="checkmark" size={18} color="#fff" />
                      <Text style={styles.primaryBtnText}>Create service</Text>
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>

              {!servicesTableOk && (
                <Text style={styles.miniText}>
                  Heads up: your DB table/policy for services isn’t set up yet.
                </Text>
              )}
            </View>
          </GlassCard>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  card: { padding: 16 },

  field: { gap: 8, marginBottom: 12 },
  label: { color: 'rgba(249,250,251,0.85)', fontSize: 13, fontWeight: '700' },
  miniText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, lineHeight: 18 },

  inputCard: { padding: 0, overflow: 'hidden' },
  input: { color: '#F9FAFB', fontSize: 16, padding: 14, minHeight: 48 },
  textArea: { minHeight: 92, textAlignVertical: 'top' },

  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },

  actionsRow: { flexDirection: 'row', gap: 12, marginTop: 6 },
  primaryBtn: { flex: 1, borderRadius: 16, overflow: 'hidden' },
  primaryBtnGrad: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  dangerBtn: {
    width: 110,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.35)',
    backgroundColor: 'rgba(239,68,68,0.12)',
    overflow: 'hidden',
    justifyContent: 'center',
  },
  dangerBtnInner: { paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  dangerBtnText: { color: '#EF4444', fontSize: 13, fontWeight: '800' },

  headerSaveBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  smallAddBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  infoText: { color: 'rgba(249,250,251,0.8)', fontSize: 13, fontWeight: '700', flex: 1 },

  emptyTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800' },

  serviceRow: {
    flexDirection: 'row',
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceName: { color: '#F9FAFB', fontSize: 15, fontWeight: '800', flex: 1 },
  serviceMetaRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  serviceChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  serviceChipText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '700' },

  inlineEditRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inlineLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '800', marginBottom: 6 },
  inlineInputCard: { padding: 0, overflow: 'hidden' },
  inlineInput: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.72)',
    padding: 18,
    justifyContent: 'center',
  },
  modalCard: { padding: 16, maxWidth: 460, alignSelf: 'center', width: '100%' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '900' },
});
