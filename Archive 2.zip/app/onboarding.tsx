import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  FlatList,
  ViewToken,
  StatusBar,
  Image,
  Platform,
} from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../src/components/shared/AppHeader';
import { ONBOARDING_VIDEO } from '../src/constants/appAssets';
import { ICON_AUTH } from '../assets/assetExports';

const { width } = Dimensions.get('window');

/** Single primary CTA colour for trust and consistency (Wish Green). */
const WISH_GREEN = '#10B981';

interface Slide {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  accent: string;
}

const SLIDES: Slide[] = [
  {
    id: '1',
    title: "You're In",
    subtitle: 'Clean car. Zero effort.',
    description: "Valeter comes to you — or book at local wash & detail hubs when you're on the go.",
    iconName: 'car-sport',
    accent: '#5B8FA8',
  },
  {
    id: '2',
    title: 'Track your wash live',
    subtitle: 'See ETA, photos and updates in real time.',
    description: 'Watch your valeter on the map from book to finish.',
    iconName: 'navigate',
    accent: '#3B82F6',
  },
  {
    id: '3',
    title: 'Rewards that add up',
    subtitle: 'Earn on every wash. Spend on your next one.',
    description: 'Clear pricing, no surprises — you see the price before you book.',
    iconName: 'wallet',
    accent: '#8B5CF6',
  },
  {
    id: '4',
    title: 'Vetted Valeters',
    subtitle: 'Your car, professionally cared for.',
    description: 'Background-checked experts and quality products, every time.',
    iconName: 'shield-checkmark',
    accent: '#F59E0B',
  },
  {
    id: '5',
    title: 'Book in seconds',
    subtitle: 'Pick service, place and time. We do the rest.',
    description: 'At your door or at a hub — one tap to a gleaming car, no queue.',
    iconName: 'sparkles',
    accent: '#10B981',
  },
];

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const [index, setIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(1)).current;
  const iconPulse = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
    }
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(progressAnim, {
        toValue: (index + 1) / SLIDES.length,
        duration: 400,
        useNativeDriver: false,
      }),
      Animated.spring(slideAnim, {
        toValue: 1,
        tension: 50,
        friction: 9,
        useNativeDriver: true,
      }),
    ]).start();
  }, [index]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(iconPulse, {
          toValue: 1.06,
          duration: 750,
          useNativeDriver: true,
        }),
        Animated.timing(iconPulse, {
          toValue: 1,
          duration: 750,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.index != null) {
      setIndex(viewableItems[0].index);
    }
  }).current;

  const handleNext = () => {
    if (index < SLIDES.length - 1) {
      flatListRef.current?.scrollToIndex({ index: index + 1, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleGetStarted = async () => {
    try {
      await AsyncStorage.setItem('onboarding_seen', 'true');
    } catch {
      // ignore
    }
    router.replace('/auth/login');
  };

  const renderSlide = ({ item }: { item: Slide }) => (
    <View style={[styles.slide, { width }]}>
      <Animated.View
        style={[
          styles.iconWrap,
          {
            backgroundColor: item.accent + '22',
            borderColor: item.accent + '44',
            transform: [{ scale: Animated.multiply(slideAnim, iconPulse) }],
          },
        ]}
      >
        {item.id === '1' ? (
          <Image source={ICON_AUTH} style={styles.heroIconImage} resizeMode="contain" />
        ) : (
          <Ionicons name={item.iconName} size={64} color={item.accent} />
        )}
      </Animated.View>

      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.subtitle}>{item.subtitle}</Text>
      <Text style={styles.description}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Video
        ref={videoRef}
        source={ONBOARDING_VIDEO}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />
      </View>
      <LinearGradient
        colors={['rgba(10,25,41,0.85)', 'rgba(26,47,74,0.75)', 'rgba(10,25,41,0.9)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <SafeAreaView style={[styles.safe, { paddingTop: insets.top + HEADER_CONTENT_OFFSET }]} edges={[]}>
        <AppHeader title="Wish a Wash" />
        {/* Progress row – below header with clear gap */}
        <View style={styles.progressRow}>
          <View style={styles.progressTrack}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%'],
                  }),
                },
              ]}
            />
          </View>
        </View>

        {/* Slides */}
        <FlatList
          ref={flatListRef}
          data={SLIDES}
          renderItem={renderSlide}
          keyExtractor={(s) => s.id}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }}
          getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
          scrollEventThrottle={16}
        />

        {/* Footer */}
        <View style={styles.footer}>
          <View style={styles.dots}>
            {SLIDES.map((slide, i) => (
              <View
                key={slide.id}
                style={[
                  styles.dot,
                  i === index && styles.dotActive,
                  i < index && styles.dotDone,
                ]}
              />
            ))}
          </View>
          <TouchableOpacity
            style={styles.nextBtn}
            onPress={handleNext}
            activeOpacity={0.9}
          >
            <Text style={styles.nextText}>
              {index === SLIDES.length - 1 ? 'Get Started' : 'Next'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  videoBackground: {
    ...StyleSheet.absoluteFillObject,
  },
  safe: {
    flex: 1,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 12,
    paddingBottom: 16,
  },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: WISH_GREEN,
    borderRadius: 2,
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingBottom: 24,
  },
  iconWrap: {
    width: 130,
    height: 130,
    borderRadius: 65,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
    borderWidth: 2,
    overflow: 'hidden',
  },
  heroIconImage: {
    width: 88,
    height: 88,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 17,
    color: '#5B8FA8',
    textAlign: 'center',
    marginBottom: 16,
    fontWeight: '600',
  },
  description: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.88)',
    textAlign: 'center',
    lineHeight: 25,
    maxWidth: 320,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop: 24,
    alignItems: 'center',
    gap: 20,
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.45)',
  },
  dotActive: {
    width: 26,
    height: 10,
    borderRadius: 5,
    backgroundColor: WISH_GREEN,
  },
  dotDone: {
    backgroundColor: 'rgba(16,185,129,0.65)',
  },
  nextBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 14,
    minWidth: 180,
    gap: 8,
    backgroundColor: WISH_GREEN,
    ...(Platform.OS === 'ios'
      ? { shadowColor: WISH_GREEN, shadowOffset: { width: 0, height: 0 }, shadowRadius: 12, shadowOpacity: 0.5 }
      : { elevation: 8 }),
  },
  nextText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
  },
});
