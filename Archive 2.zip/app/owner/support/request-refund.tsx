import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { accentToGradient } from '../../../src/utils/accentGradient';
import { BORDER_RADIUS, FONT_SIZES, SPACING } from '../../../src/constants/designTokens';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

export default function RequestRefund() {
  const scrollPad = useOwnerScrollContentPadding(true);
  useAuth();
  const [selectedBooking, setSelectedBooking] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [refundAmount, setRefundAmount] = useState('');

  const refundReasons = [
    { id: 'service', label: 'Service Not Completed', icon: 'close-circle' },
    { id: 'quality', label: 'Poor Quality', icon: 'thumbs-down' },
    { id: 'cancelled', label: 'Cancelled by Valeter', icon: 'ban' },
    { id: 'other', label: 'Other', icon: 'help-circle' },
  ];

  const handleSubmit = () => {
    if (!selectedBooking || !refundReason) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    Alert.alert('Success', 'Your refund request has been submitted. We\'ll review it within 24-48 hours.');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Request Refund"
        subtitle="Fast review within 24-48 hours"
        variant="dashboard"
        accountType="customer"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Selection */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Booking ID *</Text>
          <TextInput
            style={styles.input}
            value={selectedBooking}
            onChangeText={setSelectedBooking}
            placeholder="Enter booking ID"
            placeholderTextColor="#6B7280"
          />
        </View>

        {/* Refund Reason */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Refund Reason *</Text>
          <View style={styles.reasonGrid}>
            {refundReasons.map((reason) => (
              <TouchableOpacity
                key={reason.id}
                style={[
                  styles.reasonCard,
                  refundReason === reason.id && styles.reasonCardSelected,
                ]}
                onPress={() => setRefundReason(reason.id)}
              >
                <GradientIconBox
                  icon={reason.icon as keyof typeof Ionicons.glyphMap}
                  colors={
                    refundReason === reason.id ? accentToGradient('#0A1929') : accentToGradient(SKY)
                  }
                  boxSize={44}
                  size={22}
                  borderRadius={14}
                  elevated
                />
                <Text
                  style={[
                    styles.reasonLabel,
                    refundReason === reason.id && styles.reasonLabelSelected,
                  ]}
                >
                  {reason.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Refund Amount */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Refund Amount (£) *</Text>
          <TextInput
            style={styles.input}
            value={refundAmount}
            onChangeText={setRefundAmount}
            placeholder="Enter amount"
            placeholderTextColor="#6B7280"
            keyboardType="decimal-pad"
          />
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          <GradientIconBox icon="information-circle" preset="sky" boxSize={40} size={20} borderRadius={14} elevated />
          <Text style={styles.infoText}>
            Refunds are typically processed within 5-7 business days. You'll receive a confirmation email once your request is reviewed.
          </Text>
        </View>

        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.submitGradient}>
            <Ionicons name="card" size={20} color="#0A1929" />
            <Text style={styles.submitText}>Submit Refund Request</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? SPACING.md : SPACING.xl },
  section: {
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? FONT_SIZES.base : FONT_SIZES.lg,
    fontWeight: '700',
    marginBottom: SPACING.md,
  },
  inputLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderRadius: BORDER_RADIUS.sm,
    padding: SPACING.md,
    color: '#F9FAFB',
    fontSize: FONT_SIZES.base,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 1,
  },
  reasonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  reasonCard: {
    width: (width - (isSmallScreen ? 48 : 60)) / 2 - 6,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  reasonCardSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  reasonLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 8,
    textAlign: 'center',
  },
  reasonLabelSelected: {
    color: '#0A1929',
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoText: {
    flex: 1,
    color: '#87CEEB',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  submitButton: {
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 20,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  submitGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  submitText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});

