/**
 * Hub details – hero, wash/detailing cards, Book again (if last wash here), sticky CTA.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useThemeOptional } from '../../src/contexts/ThemeContext';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding, HEADER_CONTENT_OFFSET, TAB_BAR_TOTAL_HEIGHT } from '../../src/constants/layoutConstants';
import { colors } from '../../src/constants/colors';
import { serviceOptions, detailingServiceOptions } from '../../src/constants/serviceOptions';
import { CARWASH_IMAGE, BRONZE_IMAGE, SILVER_IMAGE, GOLD_IMAGE, PLATINUM_IMAGE, EMERALD_IMAGE, DETAILING_IMAGE, CERAMIC_DETAIL_IMAGE, SOFTOP_DETAIL_IMAGE, MOULD_DETAIL_IMAGE, HEADLIGHT_DETAIL_IMAGE } from '../assets/assetExports';

const SKY = colors.SKY;
const BG = colors.BG ?? '#0A1929';
const TEXT_LIGHT = '#F9FAFB';
const TEXT_MUTED = '#94A3B8';
const CARD_BG_DARK = 'rgba(30,41,59,0.6)';
const CARD_BG_LIGHT = 'rgba(74,122,142,0.42)';
const CARD_BORDER_DARK = 'rgba(148,163,184,0.2)';
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];


type HubInfo = {
  id: string;
  name: string;
  address: string | null;
  status?: string | null;
  rating?: number | null;
  total_reviews?: number | null;
  base_price?: number | null;
  priority_price?: number | null;
  detailing_offered?: boolean | null;
};

type ServicePrice = {
  service_name: string;
  price: number;
  duration_minutes: number;
  is_enabled: boolean;
};

type OpeningHour = {
  day_of_week: number;
  is_open: boolean;
  open_time?: string | null;
  close_time?: string | null;
};

type LastWashHere = {
  service_name: string;
  completed_at: string;
  price?: number;
};

type HubReview = {
  rating: number;
  review: string | null;
  reviewerName: string;
  completed_at?: string;
};

function money(n: unknown): number {
  if (typeof n === 'number' && Number.isFinite(n)) return n;
  if (typeof n === 'string') return Number(n) || 0;
  return 0;
}

function formatLastWashDate(iso: string): string {
  try {
    const d = new Date(iso);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - d.getTime()) / (24 * 60 * 60 * 1000));
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 14) return '1 week ago';
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: d.getFullYear() !== now.getFullYear() ? 'numeric' : undefined });
  } catch {
    return '';
  }
}

export default function HubDetails() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ locationId: string }>();
  const locationId = params.locationId;
  const themeContext = useThemeOptional();
  const isDark = themeContext?.isDark ?? true;

  const { user } = useAuth();
  const [hub, setHub] = useState<HubInfo | null>(null);
  const [services, setServices] = useState<ServicePrice[]>([]);
  const [openingHours, setOpeningHours] = useState<OpeningHour[]>([]);
  const [lastWash, setLastWash] = useState<LastWashHere | null>(null);
  const [reviews, setReviews] = useState<HubReview[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadHub = useCallback(async () => {
    if (!locationId) {
      setError('Missing location');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const selectHub = 'id,name,address,status,rating,total_reviews,base_price,priority_price,detailing_offered';
      const { data: hubData, error: hubError } = await supabase
        .from('car_wash_locations')
        .select(selectHub)
        .eq('id', locationId)
        .single();
      if (hubError) throw hubError;
      setHub(hubData as HubInfo);

      const { data: svcData, error: svcError } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);
      if (!svcError && svcData) {
        const list: ServicePrice[] = (svcData as any[]).map((r) => ({
          service_name: (r.service_name || '').trim(),
          price: money(r.price),
          duration_minutes: typeof r.duration_minutes === 'number' ? r.duration_minutes : 0,
          is_enabled: r.is_enabled !== false,
        })).filter((s) => s.service_name && s.is_enabled);
        setServices(list);
      }

      const { data: hoursData, error: hoursError } = await supabase
        .from('location_opening_hours')
        .select('day_of_week,is_open,open_time,close_time')
        .eq('location_id', locationId)
        .order('day_of_week');
      if (!hoursError && hoursData) {
        setOpeningHours((hoursData as OpeningHour[]).sort((a, b) => a.day_of_week - b.day_of_week));
      }

      const { data: reviewRows } = await supabase
        .from('bookings')
        .select('user_id, rating, review, completed_at')
        .eq('location_id', locationId)
        .eq('status', 'completed')
        .not('rating', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(15);
      const rows = (reviewRows || []) as { user_id: string; rating: number; review: string | null; completed_at?: string }[];
      if (rows.length > 0) {
        const userIds = [...new Set(rows.map((r) => r.user_id))];
        const { data: profilesData } = await supabase.from('profiles').select('id, full_name').in('id', userIds);
        const nameByUserId = new Map<string, string>();
        (profilesData || []).forEach((p: { id: string; full_name?: string | null }) => {
          nameByUserId.set(p.id, (p.full_name?.trim() || 'Customer'));
        });
        setReviews(rows.map((r) => ({
          rating: Number(r.rating) || 0,
          review: r.review ?? null,
          reviewerName: nameByUserId.get(r.user_id) || 'Customer',
          completed_at: r.completed_at,
        })));
      } else {
        setReviews([]);
      }
    } catch (e: any) {
      setError(e?.message || 'Failed to load hub');
      setHub(null);
      setServices([]);
      setReviews([]);
    } finally {
      setLoading(false);
    }
  }, [locationId]);

  useEffect(() => {
    loadHub();
  }, [loadHub]);

  const loadLastWash = useCallback(async () => {
    if (!user?.id || !locationId) {
      setLastWash(null);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('service_name, completed_at, price')
        .eq('user_id', user.id)
        .eq('location_id', locationId)
        .not('completed_at', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error || !data) {
        setLastWash(null);
        return;
      }
      setLastWash({
        service_name: (data as any).service_name ?? 'Wash',
        completed_at: (data as any).completed_at ?? '',
        price: data?.price != null ? money((data as any).price) : undefined,
      });
    } catch {
      setLastWash(null);
    }
  }, [user?.id, locationId]);

  useEffect(() => {
    if (hub?.id && user?.id) loadLastWash();
  }, [hub?.id, user?.id, loadLastWash]);

  const handleBook = () => {
    if (!hub?.id) return;
    hapticFeedback('light');
    router.push({
      pathname: '/owner/booking/physical/vehicle',
      params: { locationId: hub.id },
    });
  };

  const serviceNameToTier = (name: string): { id: string; label: string } | null => {
    const n = (name || '').trim();
    if (n === 'Bronze Wash') return { id: 'bronze-wash', label: 'Bronze' };
    if (n === 'Silver Wash') return { id: 'silver-wash', label: 'Silver' };
    if (n === 'Gold Wash') return { id: 'gold-wash', label: 'Gold' };
    if (n === 'Platinum Wash') return { id: 'platinum-wash', label: 'Platinum' };
    if (n === 'Emerald Wash') return { id: 'emerald-wash', label: 'Emerald' };
    return null;
  };

  const tierImageMap: Record<string, ReturnType<typeof require>> = {
    'bronze-wash': BRONZE_IMAGE,
    'silver-wash': SILVER_IMAGE,
    'gold-wash': GOLD_IMAGE,
    'platinum-wash': PLATINUM_IMAGE,
    'emerald-wash': EMERALD_IMAGE,
  };

  const handleWashCardPress = (tierId: string) => {
    hapticFeedback('light');
    router.push({
      pathname: '/owner/booking/physical/vehicle',
      params: { locationId: hub!.id, serviceId: tierId },
    });
  };

  // Dark: match Explore. Light: match dashboard (transparent = layout gradient, same card colours)
  const screenBg = isDark ? BG : 'transparent';
  const textPrimary = isDark ? TEXT_LIGHT : '#F0F9FF';
  const textMuted = isDark ? TEXT_MUTED : 'rgba(240,249,255,0.85)';
  const cardBg = isDark ? CARD_BG_DARK : 'rgba(255,255,255,0.06)';
  const borderColor = isDark ? CARD_BORDER_DARK : 'rgba(135,206,235,0.15)';
  const accent = SKY;
  const { paddingBottom } = getScrollContentPadding(insets, true);
  const stickyCtaBottom = TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + 20;
  const scrollBottomWithCta = paddingBottom + 80;

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
        <AppHeader title="Hub details" showBack onBack={() => { hapticFeedback('light'); router.back(); }} accountType="customer" />
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  if (error || !hub) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
        <AppHeader title="Hub details" showBack onBack={() => { hapticFeedback('light'); router.back(); }} accountType="customer" />
        <View style={styles.centered}>
          <Text style={[styles.errorText, { color: textMuted }]}>{error || 'Hub not found'}</Text>
          <TouchableOpacity style={[styles.backBtn, { backgroundColor: SKY }]} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const rating = hub.rating != null ? Number(hub.rating) : null;
  const reviewCount = hub.total_reviews != null ? Number(hub.total_reviews) : null;
  const openingHoursByDay = new Map(openingHours.map((h) => [h.day_of_week, h]));
  const openingHoursLabel =
    openingHours.length === 0
      ? ''
      : DAY_NAMES.map((name, i) => {
          const h = openingHoursByDay.get(i);
          if (!h) return `${name} —`;
          if (h.is_open && h.open_time && h.close_time) {
            return `${name} ${(h.open_time || '').slice(0, 5)}–${(h.close_time || '').slice(0, 5)}`;
          }
          return `${name} Closed`;
        }).join(' · ');

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
      <AppHeader
        title={hub.name}
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />
      <View style={[styles.contentBelowHeader, { paddingTop: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET }]}>
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingTop: 0, paddingBottom: scrollBottomWithCta }]}
          showsVerticalScrollIndicator={false}
        >
          {/* Hero – Uber Eats style cover */}
          <View style={[styles.heroWrap, { borderColor }]}>
            <Image source={CARWASH_IMAGE} style={styles.heroImageFull} resizeMode="cover" />
            <LinearGradient
              colors={isDark ? ['transparent', 'rgba(10,25,41,0.85)'] : ['transparent', 'rgba(21,34,56,0.75)']}
              style={styles.heroGradient}
            />
            <View style={styles.heroBottom}>
              {rating != null && (
                <View style={[styles.ratingPill, { backgroundColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.4)' }]}>
                  <Ionicons name="star" size={14} color="#FBBF24" />
                  <Text style={[styles.ratingPillText, { color: textPrimary }]}>{Number(rating).toFixed(1)}</Text>
                  {reviewCount != null && reviewCount > 0 && (
                    <Text style={[styles.ratingPillSub, { color: textMuted }]}> · {reviewCount}</Text>
                  )}
                </View>
              )}
            </View>
          </View>

          {/* Info strip: address + hours */}
          <View style={[styles.infoStrip, { backgroundColor: cardBg, borderColor }]}>
            {hub.address ? (
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={18} color={accent} />
                <Text style={[styles.infoStripText, { color: textPrimary }]} numberOfLines={2}>{hub.address}</Text>
              </View>
            ) : null}
            {openingHours.length > 0 && (
              <View style={[styles.infoRow, hub.address ? styles.infoRowBorder : undefined, { borderTopColor: borderColor }]}>
                <Ionicons name="time-outline" size={18} color={accent} />
                <Text style={[styles.infoStripText, { color: textPrimary }]} numberOfLines={4}>{openingHoursLabel}</Text>
              </View>
            )}
          </View>

          {/* Book again – last wash at this hub */}
          {lastWash && (
            <View style={[styles.bookAgainCard, { backgroundColor: cardBg, borderColor }]}>
              <Text style={[styles.bookAgainLabel, { color: textMuted }]}>Last wash here</Text>
              <Text style={[styles.bookAgainService, { color: textPrimary }]} numberOfLines={1}>{lastWash.service_name}</Text>
              {lastWash.completed_at ? (
                <Text style={[styles.bookAgainDate, { color: textMuted }]}>
                  {formatLastWashDate(lastWash.completed_at)}
                </Text>
              ) : null}
              <TouchableOpacity
                style={[styles.bookAgainBtn, { backgroundColor: accent }]}
                onPress={() => { hapticFeedback('light'); handleBook(); }}
                activeOpacity={0.9}
              >
                <Text style={styles.bookAgainBtnText}>Book again</Text>
                <Ionicons name="refresh" size={18} color="#fff" />
              </TouchableOpacity>
            </View>
          )}

          {/* Wash services – horizontal cards with photo */}
          <View style={styles.menuSection}>
            <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Wash services</Text>
            {services.length === 0 ? (
              <View style={[styles.menuCard, { backgroundColor: cardBg, borderColor }]}>
                <Text style={[styles.menuItemMuted, { color: textMuted }]}>No wash tiers configured. See booking for options.</Text>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.serviceOptionsScroll}
              >
                {(['Bronze Wash', 'Silver Wash', 'Gold Wash', 'Platinum Wash', 'Emerald Wash'] as const)
                  .map((name) => services.find((s) => (s.service_name || '').trim() === name))
                  .filter(Boolean)
                  .map((s) => {
                    const tier = serviceNameToTier(s!.service_name)!;
                    const option = serviceOptions.find((o) => o.id === tier.id);
                    const label = option?.name ?? tier.label + ' Wash';
                    const dur = s!.duration_minutes > 0 ? `${s!.duration_minutes} min` : '';
                    const tierImage = tierImageMap[tier.id] ?? CARWASH_IMAGE;
                    return (
                      <Pressable
                        key={s!.service_name}
                        style={({ pressed }) => [styles.serviceOptionCard, { backgroundColor: cardBg, borderColor }, pressed && styles.menuItemPressed]}
                        onPress={() => handleWashCardPress(tier.id)}
                      >
                        <View style={styles.serviceOptionImageWrap}>
                          <Image source={tierImage} style={styles.serviceOptionImage} resizeMode="cover" />
                        </View>
                        <View style={styles.serviceOptionBody}>
                          <Text style={[styles.serviceOptionTitle, { color: textPrimary }]} numberOfLines={1}>{label}</Text>
                          {dur ? <Text style={[styles.serviceOptionMeta, { color: textMuted }]}>{dur}</Text> : null}
                          <Text style={[styles.serviceOptionPrice, { color: accent }]}>£{s!.price.toFixed(0)}</Text>
                        </View>
                      </Pressable>
                    );
                  })}
              </ScrollView>
            )}
          </View>

          {/* Detailing – horizontal cards with photo */}
          {hub.detailing_offered && (
            <View style={styles.menuSection}>
              <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Detailing</Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.serviceOptionsScroll}
              >
                {detailingServiceOptions.slice(0, 6).map((d) => {
                  let detailBgImage = DETAILING_IMAGE;
                  if (d.id === 'ceramic-coating') detailBgImage = CERAMIC_DETAIL_IMAGE;
                  else if (d.id === 'soft-top-restoration') detailBgImage = SOFTOP_DETAIL_IMAGE;
                  else if (d.id === 'mould-removal') detailBgImage = MOULD_DETAIL_IMAGE;
                  else if (d.id === 'headlight-restoration') detailBgImage = HEADLIGHT_DETAIL_IMAGE;
                  return (
                  <Pressable
                    key={d.id}
                    style={({ pressed }) => [styles.serviceOptionCard, { backgroundColor: cardBg, borderColor }, pressed && styles.menuItemPressed]}
                    onPress={() => hapticFeedback('light')}
                  >
                    <View style={styles.serviceOptionImageWrap}>
                      <Image source={detailBgImage} style={styles.serviceOptionImage} resizeMode="cover" />
                    </View>
                    <View style={styles.serviceOptionBody}>
                      <Text style={[styles.serviceOptionTitle, { color: textPrimary }]} numberOfLines={2}>{d.name}</Text>
                      <Text style={[styles.serviceOptionPrice, { color: accent }]}>from £{d.price}</Text>
                    </View>
                  </Pressable>
                  );
                })}
              </ScrollView>
              <Text style={[styles.menuItemMuted, { color: textMuted, marginTop: 6 }]}>Exact pricing in booking.</Text>
            </View>
          )}

          {/* Reviews – horizontal scrolling cards with star rating and who by */}
          <View style={styles.menuSection}>
            <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Reviews</Text>
            {reviews.length === 0 ? (
              <View style={[styles.reviewsEmptyBox, { backgroundColor: cardBg, borderColor }]}>
                <Ionicons name="chatbubble-ellipses-outline" size={32} color={textMuted} />
                <Text style={[styles.reviewsEmptyText, { color: textMuted }]}>Reviews will appear here when customers leave feedback.</Text>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.reviewsScroll}
              >
                {reviews.map((rev, idx) => (
                  <View key={`${rev.reviewerName}-${rev.rating}-${idx}`} style={[styles.reviewCard, { backgroundColor: cardBg, borderColor }]}>
                    <View style={styles.reviewStarsRow}>
                      <Ionicons name="star" size={16} color="#FBBF24" />
                      <Text style={[styles.reviewRatingText, { color: textPrimary }]}>{rev.rating.toFixed(1)}</Text>
                    </View>
                    {rev.review ? (
                      <Text style={[styles.reviewBody, { color: textPrimary }]} numberOfLines={4}>{rev.review}</Text>
                    ) : (
                      <Text style={[styles.reviewBody, { color: textMuted }]}>No comment</Text>
                    )}
                    <Text style={[styles.reviewBy, { color: textMuted }]}>— {rev.reviewerName}</Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </View>
        </ScrollView>

        {/* Sticky CTA – above nav tab */}
        <View style={[styles.stickyCtaWrap, { backgroundColor: cardBg, borderTopColor: borderColor, bottom: stickyCtaBottom }]}>
          <TouchableOpacity style={[styles.bookBtn, { backgroundColor: accent }]} onPress={handleBook} activeOpacity={0.9}>
            <Text style={styles.bookBtnText}>Book this hub</Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  contentBelowHeader: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16 },
  errorText: { fontSize: 16, marginBottom: 16, textAlign: 'center' },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12 },
  backBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  heroWrap: {
    marginHorizontal: -16,
    marginBottom: 12,
    height: 180,
    overflow: 'hidden',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  heroImageFull: { width: '100%', height: '100%' },
  heroGradient: { ...StyleSheet.absoluteFillObject },
  heroBottom: {
    position: 'absolute',
    bottom: 12,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    gap: 4,
  },
  ratingPillText: { fontSize: 14, fontWeight: '700' },
  ratingPillSub: { fontSize: 13 },
  infoStrip: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 20,
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoRowBorder: { borderTopWidth: 1, paddingTop: 12, marginTop: 12 },
  infoStripText: { flex: 1, fontSize: 14 },
  bookAgainCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 20,
  },
  bookAgainLabel: { fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  bookAgainService: { fontSize: 16, fontWeight: '700', marginBottom: 2 },
  bookAgainDate: { fontSize: 13, marginBottom: 12 },
  bookAgainBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 12,
  },
  bookAgainBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  menuSection: { marginBottom: 20 },
  menuSectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10, letterSpacing: 0.3 },
  serviceOptionsScroll: { paddingRight: 16 },
  serviceOptionCard: {
    width: 160,
    marginRight: 12,
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
  },
  serviceOptionImageWrap: {
    height: 100,
    width: '100%',
    backgroundColor: 'rgba(0,0,0,0.15)',
    position: 'relative',
  },
  serviceOptionImage: { width: '100%', height: '100%' },
  serviceOptionBody: { padding: 12 },
  serviceOptionTitle: { fontSize: 15, fontWeight: '600', marginBottom: 2 },
  serviceOptionMeta: { fontSize: 12, marginBottom: 4 },
  serviceOptionPrice: { fontSize: 15, fontWeight: '700' },
  reviewsScroll: { paddingRight: 16 },
  reviewCard: {
    width: 220,
    marginRight: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
  },
  reviewStarsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  reviewRatingText: { fontSize: 16, fontWeight: '700' },
  reviewBody: { fontSize: 14, lineHeight: 20, marginBottom: 8 },
  reviewBy: { fontSize: 12, fontStyle: 'italic' },
  reviewsEmptyBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
  },
  reviewsEmptyText: { fontSize: 14, textAlign: 'center', marginTop: 8 },
  menuCard: {
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 14,
  },
  menuItemBorder: { borderTopWidth: 1 },
  menuItemPressed: { opacity: 0.7 },
  menuItemLeft: { flex: 1 },
  menuItemTitle: { fontSize: 16, fontWeight: '600' },
  menuItemMeta: { fontSize: 13, marginTop: 2 },
  menuItemPrice: { fontSize: 16, fontWeight: '700' },
  menuItemMuted: { fontSize: 14, paddingHorizontal: 14, paddingBottom: 6 },
  stickyCtaWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    borderTopWidth: 1,
  },
  bookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    borderRadius: 14,
  },
  bookBtnText: { color: '#fff', fontWeight: '700', fontSize: 17 },
});
