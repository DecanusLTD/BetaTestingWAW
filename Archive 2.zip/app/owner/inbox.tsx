import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  ScrollView,
  Dimensions,
  Animated as RNAnimated,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import LoadingScreen from '../../src/components/LoadingScreen';
import EmptyState from '../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../src/constants/layoutConstants';
import { CONTENT_PADDING_H, sectionHeader as sectionHeaderStyle, sectionHeaderIcon } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { fetchProfileById } from '../../src/utils/customerProfiles';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { VALETER_IMAGE, CARWASH_IMAGE } from '../assets/assetExports';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const CARD_RADIUS = 16;
const CARD_BG_DARK = 'rgba(30,41,59,0.6)';
const CARD_BORDER_DARK = 'rgba(148,163,184,0.2)';
const TEXT_MUTED_LIGHT = '#94A3B8';

/** Bookings that can have support chat: have a valeter or hub assigned. Only use values that exist in DB enum booking_status. */
const INBOX_BOOKING_STATUSES: string[] = [
  'scheduled',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'completed',
];

type InboxThread = {
  id: string;
  bookingId: string;
  proName: string;
  serviceDisplayName: string;
  status: string;
  address?: string | null;
  updatedAt: string;
  /** Valeter thread: id for profile/avatar and stats */
  valeterId?: string | null;
  profilePhoto?: string | null;
  rating?: number;
  totalJobs?: number;
  /** True when thread is with a hub (location) only, not a valeter */
  isHub?: boolean;
};

function formatRelativeDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

export default function InboxScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new RNAnimated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [threads, setThreads] = useState<InboxThread[]>([]);

  const loadThreads = useCallback(async () => {
    if (!user?.id) {
      setThreads([]);
      setLoading(false);
      return;
    }
    try {
      const { data: rows, error } = await supabase
        .from('bookings')
        .select(
          'id, service_type, service_name, valeter_id, location_id, valeter_name, status, location_address, updated_at, created_at'
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .in('status', INBOX_BOOKING_STATUSES)
        .or('valeter_id.not.is.null,location_id.not.is.null')
        .order('updated_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const list: InboxThread[] = [];
      for (const row of rows || []) {
        const r = row as any;
        let proName = r.valeter_name || 'Valeter';
        let profilePhoto: string | null = null;
        let rating: number | undefined;
        let totalJobs: number | undefined;
        const isHub = !r.valeter_id && !!r.location_id;

        if (r.valeter_id) {
          if (!r.valeter_name) {
            const profile = await fetchProfileById(r.valeter_id);
            proName = profile?.full_name || 'Valeter';
          }
          const { data: vp } = await supabase
            .from('valeter_profiles')
            .select('profile_photo_url')
            .eq('user_id', r.valeter_id)
            .maybeSingle();
          profilePhoto = (vp as any)?.profile_photo_url ?? null;
          if (!profilePhoto) {
            const { data: prof } = await supabase.from('profiles').select('profile_picture').eq('id', r.valeter_id).maybeSingle();
            profilePhoto = (prof as any)?.profile_picture ?? null;
          }
          const stats = await ValeterStatsService.getValeterStats(r.valeter_id).catch(() => null);
          if (stats) {
            rating = stats.averageRating;
            totalJobs = stats.totalJobs;
          }
        } else if (r.location_id) {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name')
            .eq('id', r.location_id)
            .maybeSingle();
          proName = (hub as any)?.name || 'Wash Hub';
        }

        list.push({
          id: r.id,
          bookingId: r.id,
          proName,
          serviceDisplayName: getServiceDisplayName(r.service_type, r.service_name),
          status: r.status || 'scheduled',
          address: r.location_address,
          updatedAt: r.updated_at || r.created_at || new Date().toISOString(),
          valeterId: r.valeter_id ?? null,
          profilePhoto: profilePhoto ?? null,
          rating,
          totalJobs,
          isHub,
        });
      }
      setThreads(list);
    } catch (e) {
      console.error('[inbox] load error', e);
      setThreads([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadThreads();
  }, [loadThreads]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadThreads();
  }, [loadThreads]);

  const openChat = useCallback(
    (bookingId: string) => {
      hapticFeedback('light');
      router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
    },
    []
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Inbox"
        subtitle="Support messages with your valeter during jobs"
        showBack
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
        scrollY={scrollY}
        enableScrollAnimation
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: CONTENT_PADDING_H, ...getScrollContentPadding(insets, true) },
        ]}
        showsVerticalScrollIndicator={false}
        onScroll={RNAnimated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {threads.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyContainer}>
            <EmptyState
              icon="chatbubbles-outline"
              title="No support messages yet"
              subtitle="When you have an active or recent booking, you can message your valeter here. Tap a thread to open the chat."
              actionLabel="View bookings"
              onAction={() => router.push('/owner/track')}
              iconColor={SKY}
              style={styles.emptyState}
            />
          </Animated.View>
        ) : (
          <>
            <View style={styles.sectionContainer}>
              <View style={[sectionHeaderStyle, styles.sectionHeaderRow]}>
                <View style={sectionHeaderIcon}>
                  <Ionicons name="mail-open" size={18} color={SKY} />
                </View>
                <View style={styles.sectionHeaderText}>
                  <Text style={styles.sectionHeading}>Support messages</Text>
                  <Text style={styles.sectionSubtitleText}>
                    {threads.length} conversation{threads.length === 1 ? '' : 's'} with pros
                  </Text>
                </View>
              </View>
            </View>

            {threads.map((thread, index) => (
              <Animated.View
                key={thread.bookingId}
                entering={FadeInDown.delay(80 + index * 60)}
                style={styles.threadCardWrap}
              >
                {thread.isHub ? (
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={() => openChat(thread.bookingId)}
                    style={styles.threadTouchable}
                  >
                    <View style={[styles.inboxHubCard, styles.inboxCard]}>
                      <View style={styles.hubHero}>
                        <View style={styles.typeBadgeHub}>
                          <Ionicons name="business" size={12} color="#fff" />
                          <Text style={styles.typeBadgeText}>Hub</Text>
                        </View>
                        <LinearGradient
                          colors={[SKY + '40', SKY + '15']}
                          style={StyleSheet.absoluteFill}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 1 }}
                        />
                        <Image source={CARWASH_IMAGE} style={styles.hubHeroImage} resizeMode="contain" />
                      </View>
                      <View style={styles.inboxHubCardBody}>
                        <View style={styles.hubNameRow}>
                          <Text style={styles.uberCardTitle} numberOfLines={1}>{thread.proName}</Text>
                          <Text style={styles.threadDate}>{formatRelativeDate(thread.updatedAt)}</Text>
                        </View>
                        {thread.address ? (
                          <View style={styles.addressRow}>
                            <Ionicons name="location-outline" size={14} color={TEXT_MUTED_LIGHT} />
                            <Text style={styles.addressText} numberOfLines={2}>{thread.address}</Text>
                          </View>
                        ) : null}
                        <Text style={styles.threadService} numberOfLines={1}>{thread.serviceDisplayName}</Text>
                        <View style={styles.hubCardFooter}>
                          <View style={styles.openChatBtn}>
                            <Ionicons name="chatbubble-outline" size={18} color="#fff" />
                            <Text style={styles.openChatBtnText}>Open chat</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={() => openChat(thread.bookingId)}
                    style={styles.threadTouchable}
                  >
                    <View style={[styles.uberValeterCard, styles.inboxCard]}>
                      <View style={styles.valeterCardMain}>
                        <View style={styles.valeterAvatarWrap}>
                          <View style={styles.typeBadgeValeter}>
                            <Ionicons name="car-sport" size={10} color="#fff" />
                            <Text style={styles.typeBadgeTextSmall}>Mobile</Text>
                          </View>
                          {thread.profilePhoto ? (
                            <Image source={{ uri: thread.profilePhoto }} style={styles.valeterAvatar} resizeMode="cover" />
                          ) : (
                            <View style={styles.valeterAvatarPlaceholder}>
                              <Image source={VALETER_IMAGE} style={styles.valeterAvatar} resizeMode="cover" />
                            </View>
                          )}
                        </View>
                        <View style={styles.valeterCardBody}>
                          <View style={styles.valeterNameRow}>
                            <Text style={styles.uberCardTitle} numberOfLines={1}>{formatDisplayName(thread.proName)}</Text>
                            <Text style={styles.threadDate}>{formatRelativeDate(thread.updatedAt)}</Text>
                          </View>
                          <View style={styles.valeterStatsRow}>
                            <View style={styles.statItem}>
                              <Ionicons name="star" size={12} color="#FBBF24" />
                              <Text style={styles.statItemText}>{thread.rating != null && thread.rating > 0 ? thread.rating.toFixed(1) : 'New'}</Text>
                            </View>
                            <View style={styles.statItem}>
                              <Ionicons name="checkmark-done-outline" size={12} color={TEXT_MUTED_LIGHT} />
                              <Text style={styles.statItemText}>{thread.totalJobs ?? 0} jobs</Text>
                            </View>
                          </View>
                          <Text style={styles.inboxServiceLine} numberOfLines={1}>{thread.serviceDisplayName}</Text>
                          {thread.address ? (
                            <View style={styles.addressRow}>
                              <Ionicons name="location-outline" size={12} color={TEXT_MUTED_LIGHT} />
                              <Text style={styles.addressText} numberOfLines={1}>{thread.address}</Text>
                            </View>
                          ) : null}
                          <View style={styles.valeterCardFooter}>
                            <View style={styles.openChatBtn}>
                              <Ionicons name="chatbubble-outline" size={18} color="#fff" />
                              <Text style={styles.openChatBtnText}>Open chat</Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              </Animated.View>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  emptyContainer: {
    flex: 1,
    minHeight: 280,
    justifyContent: 'center',
  },
  emptyState: {
    marginHorizontal: 8,
  },
  sectionContainer: {
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  sectionHeaderText: {
    flex: 1,
  },
  sectionHeading: {
    fontSize: 18,
    fontWeight: '800',
    color: '#F1F5F9',
    letterSpacing: 0.2,
  },
  sectionSubtitleText: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(241,245,249,0.7)',
    marginTop: 2,
  },
  threadCardWrap: {
    marginBottom: 14,
  },
  threadTouchable: {
    width: '100%',
  },
  inboxCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: CARD_BORDER_DARK,
  },
  // Valeter profile card (same as explore)
  uberValeterCard: {
    padding: 14,
    backgroundColor: CARD_BG_DARK,
  },
  valeterCardMain: { flexDirection: 'row' },
  typeBadgeValeter: {
    position: 'absolute',
    top: -2,
    left: -2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: SKY,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 6,
    zIndex: 1,
  },
  typeBadgeTextSmall: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  valeterAvatarWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginRight: 12,
    position: 'relative',
  },
  valeterAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  valeterAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    overflow: 'hidden',
    backgroundColor: SKY + '25',
  },
  valeterCardBody: { flex: 1, minWidth: 0 },
  valeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
    gap: 8,
  },
  uberCardTitle: {
    fontSize: 17,
    fontWeight: '800',
    flex: 1,
    color: '#F9FAFB',
  },
  valeterStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 4,
  },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statItemText: { fontSize: 12, color: TEXT_MUTED_LIGHT },
  inboxServiceLine: {
    fontSize: 13,
    fontWeight: '600',
    color: SKY,
    marginTop: 6,
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  addressText: {
    flex: 1,
    fontSize: 12,
    color: TEXT_MUTED_LIGHT,
  },
  valeterCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  openChatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: SKY,
  },
  openChatBtnText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '800',
  },
  // Hub card (same as explore) for inbox
  inboxHubCard: {
    backgroundColor: CARD_BG_DARK,
  },
  hubHero: {
    height: 72,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  typeBadgeHub: {
    position: 'absolute',
    top: 8,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.8)',
    zIndex: 2,
  },
  typeBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  hubHeroImage: {
    width: 64,
    height: 48,
    zIndex: 1,
  },
  inboxHubCardBody: {
    padding: 14,
  },
  hubNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
    gap: 8,
  },
  hubCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  threadBody: {
    flex: 1,
    minWidth: 0,
  },
  threadProName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#F1F5F9',
    marginBottom: 2,
  },
  threadService: {
    fontSize: 13,
    fontWeight: '600',
    color: SKY,
    marginTop: 4,
    marginBottom: 1,
  },
  threadAddress: {
    fontSize: 11,
    fontWeight: '500',
    color: 'rgba(241,245,249,0.6)',
  },
  threadMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  threadDate: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(241,245,249,0.5)',
  },
});
