import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function OwnerAnalytics() {
  const { user } = useAuth();
    const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
    cancelledServices: 0,
    favoriteService: 'Basic Wash',
    monthlySpending: [0, 0, 0, 0, 0, 0],
  });

  const loadStats = async () => {
    if (!user?.id) return;
    try {
      // Load user bookings from Supabase
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const bookingsList = bookings || [];
      const completed = bookingsList.filter((b: any) => ['completed', 'rated'].includes(b.status));
      const cancelled = bookingsList.filter((b: any) => b.status === 'cancelled');
      const totalSpent = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      const ratings = completed.filter((b: any) => b.rating).map((b: any) => b.rating);
      const avgRating = ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;

      setStats({
        totalBookings: bookingsList.length,
        totalSpent,
        averageRating: avgRating,
        completedServices: completed.length,
        cancelledServices: cancelled.length,
        favoriteService: 'Basic Wash',
        monthlySpending: [0, 0, 0, 0, 0, 0],
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadStats();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Analytics" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(135,206,235,0.15)', 'rgba(30,58,138,0.2)']} style={styles.statCardGradient}>
              <View style={styles.statIconContainer}>
                <Ionicons name="calendar" size={24} color={SKY} />
              </View>
              <Text style={styles.statNumber}>{stats.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(135,206,235,0.15)', 'rgba(30,58,138,0.2)']} style={styles.statCardGradient}>
              <View style={styles.statIconContainer}>
                <Ionicons name="cash" size={24} color={SKY} />
              </View>
              <Text style={styles.statNumber}>£{stats.totalSpent.toFixed(0)}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(135,206,235,0.15)', 'rgba(30,58,138,0.2)']} style={styles.statCardGradient}>
              <View style={styles.statIconContainer}>
                <Ionicons name="star" size={24} color="#F59E0B" />
              </View>
              <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(135,206,235,0.15)', 'rgba(30,58,138,0.2)']} style={styles.statCardGradient}>
              <View style={styles.statIconContainer}>
                <Ionicons name="checkmark-circle" size={24} color="#10B981" />
              </View>
              <Text style={styles.statNumber}>{stats.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </LinearGradient>
          </View>
        </View>

        {/* Additional Info Cards */}
        <View style={styles.infoSection}>
          <View style={styles.infoCard}>
            <View style={styles.infoIconWrapper}>
              <Ionicons name="car-sport" size={24} color={SKY} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Favourite Service</Text>
              <Text style={styles.infoValue}>{stats.favoriteService}</Text>
            </View>
          </View>

          <View style={styles.infoCard}>
            <View style={styles.infoIconWrapper}>
              <Ionicons name="close-circle" size={24} color="#EF4444" />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Cancelled Services</Text>
              <Text style={styles.infoValue}>{stats.cancelledServices}</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  statCardGradient: {
    padding: 16,
    alignItems: 'center',
    gap: 8,
  },
  statIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  statNumber: {
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#87CEEB',
    textAlign: 'center',
    fontWeight: '600',
  },
  infoSection: {
    gap: 12,
    marginBottom: 24,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 4,
  },
  infoValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
  },
});

