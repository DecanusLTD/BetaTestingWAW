import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Platform,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import EmptyState from '../../../src/components/shared/EmptyState';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY ?? '#7DD3FC';
const SUPPORT_EMAIL = 'support@wishawash.com';
const RATING_GOLD = '#FBBF24';
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';

function getRelativeDate(dateLike: Date | string | number | undefined | null): string {
  if (!dateLike) return '';
  const d = new Date(dateLike);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 14) return 'Last week';
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  if (diffDays < 60) return 'Last month';
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
  const years = Math.floor(diffDays / 365);
  return years > 1 ? `${years} years ago` : '1 year ago';
}

function getSectionLabel(key: string): string {
  switch (key) {
    case 'this_month': return 'This month';
    case 'last_month': return 'Last month';
    case 'older': return 'Older';
    default: return key;
  }
}

function getSectionKey(completedAt: string | null, createdAt: string): string {
  const d = new Date(completedAt || createdAt);
  const now = new Date();
  const thisMonth = now.getFullYear() * 12 + now.getMonth();
  const thatMonth = d.getFullYear() * 12 + d.getMonth();
  const diff = thisMonth - thatMonth;
  if (diff === 0) return 'this_month';
  if (diff === 1) return 'last_month';
  return 'older';
}

function getServiceAccent(serviceType: string | null, serviceName: string | null): string {
  const t = ((serviceType ?? serviceName ?? '').toString()).toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

function getServiceIconName(accent: string): 'leaf' | 'sparkles' | 'water' {
  if (accent === ECO_GREEN) return 'leaf';
  if (accent === DETAILING_YELLOW) return 'sparkles';
  return 'water';
}

const PLATFORM_FEE = 1.5;

type CompletedBooking = {
  id: string;
  service_name: string | null;
  service_type: string | null;
  price: number;
  completed_at: string | null;
  created_at: string;
  valeter_name: string | null;
  valeter_organization_name: string | null;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  tip_amount: number | null;
  rating: number | null;
  payment_completed_at: string | null;
};

function getBookingSortTimestamp(order: CompletedBooking): number {
  const completedTs = order.completed_at ? new Date(order.completed_at).getTime() : NaN;
  if (Number.isFinite(completedTs)) return completedTs;
  const createdTs = order.created_at ? new Date(order.created_at).getTime() : NaN;
  if (Number.isFinite(createdTs)) return createdTs;
  return 0;
}

// Light-mode receipt to match app UI – clean, readable, print-friendly
const RECEIPT_LIGHT = {
  bg: '#FAFBFC',
  card: '#FFFFFF',
  text: '#1E293B',
  textSecondary: '#475569',
  textMuted: '#64748B',
  border: '#E2E8F0',
  accent: '#7EB8D4',
  accentSoft: 'rgba(126,184,212,0.15)',
  totalBorder: '#7EB8D4',
};

function buildReceiptHTML(
  booking: CompletedBooking,
  customerName: string,
  customerEmail: string
): string {
  const date = booking.completed_at || booking.created_at;
  const formattedDate = new Date(date).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const serviceName = getServiceDisplayName(booking.service_type, booking.service_name);
  const price = Number(booking.price) || 0;
  const serviceAmount = Math.max(0, price - PLATFORM_FEE);
  const tip = Number(booking.tip_amount) || 0;
  const total = price + tip;

  const paymentStatus = booking.payment_completed_at
    ? `Paid on ${new Date(booking.payment_completed_at).toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })}`
    : 'Payment completed';

  const valeterLine =
    booking.valeter_name || booking.valeter_organization_name
      ? [
          booking.valeter_name ? `Valeter: ${booking.valeter_name}` : null,
          booking.valeter_organization_name ? `(${booking.valeter_organization_name})` : null,
        ]
          .filter(Boolean)
          .join(' ')
      : '';

  const c = RECEIPT_LIGHT;
  return `
    <div class="receipt" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 28px 24px; max-width: 400px; margin: 0 auto; background: ${c.bg}; min-height: 100vh; color: ${c.text}; font-size: 15px; line-height: 1.45;">
      <header style="text-align: center; margin-bottom: 28px; padding-bottom: 20px; border-bottom: 2px solid ${c.accent};">
        <h1 style="color: ${c.accent}; font-size: 24px; margin: 0 0 4px 0; font-weight: 700; letter-spacing: 0.3px;">Wish a Wash</h1>
        <p style="color: ${c.textSecondary}; font-size: 13px; margin: 0; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Wash Receipt</p>
      </header>
      <div style="background: ${c.card}; border-radius: 12px; border: 1px solid ${c.border}; padding: 18px 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.06);">
        <p style="margin: 0 0 10px 0; font-size: 12px; color: ${c.textMuted}; font-weight: 600; text-transform: uppercase;">Receipt #</p>
        <p style="margin: 0 0 12px 0; font-size: 16px; font-weight: 700; color: ${c.text}; letter-spacing: 0.5px;">${String(booking.id).slice(0, 8).toUpperCase()}</p>
        <p style="margin: 0 0 6px 0; font-size: 14px; color: ${c.text};"><span style="color: ${c.textMuted};">Date</span> ${formattedDate}</p>
        <p style="margin: 0; font-size: 14px; color: ${c.text};"><span style="color: ${c.textMuted};">Payment</span> ${paymentStatus}</p>
      </div>
      <div style="background: ${c.card}; border-radius: 12px; border: 1px solid ${c.border}; padding: 18px 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.06);">
        <p style="margin: 0 0 8px 0; font-size: 12px; color: ${c.textMuted}; font-weight: 600; text-transform: uppercase;">Customer</p>
        <p style="margin: 0 0 4px 0; font-size: 15px; font-weight: 600; color: ${c.text};">${customerName || '—'}</p>
        <p style="margin: 0; font-size: 14px; color: ${c.textSecondary};">${customerEmail || '—'}</p>
      </div>
      <div style="background: ${c.card}; border-radius: 12px; border: 1px solid ${c.border}; padding: 18px 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.06);">
        <p style="margin: 0 0 8px 0; font-size: 15px; font-weight: 700; color: ${c.text};">${serviceName}</p>
        ${valeterLine ? `<p style="margin: 6px 0 0 0; font-size: 14px; color: ${c.textSecondary};">${valeterLine}</p>` : ''}
        ${booking.location_address ? `<p style="margin: 8px 0 0 0; font-size: 13px; color: ${c.textMuted}; line-height: 1.4;">${booking.location_address}</p>` : ''}
      </div>
      <div style="background: ${c.card}; border-radius: 12px; border: 1px solid ${c.border}; padding: 18px 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.06);">
        <p style="margin: 0 0 14px 0; font-size: 12px; color: ${c.textMuted}; font-weight: 600; text-transform: uppercase;">Pricing breakdown</p>
        <div style="display: flex; justify-content: space-between; margin: 10px 0; font-size: 15px; color: ${c.text};">
          <span>${serviceName}</span>
          <span>£${serviceAmount.toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin: 10px 0; font-size: 15px; color: ${c.text};">
          <span>Platform fee</span>
          <span>£${PLATFORM_FEE.toFixed(2)}</span>
        </div>
        ${tip > 0 ? `
        <div style="display: flex; justify-content: space-between; margin: 10px 0; font-size: 15px; color: ${c.text};">
          <span>Tip</span>
          <span>£${tip.toFixed(2)}</span>
        </div>
        ` : ''}
        <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: 700; margin-top: 16px; padding-top: 14px; border-top: 2px solid ${c.totalBorder}; color: ${c.text};">
          <span>Total</span>
          <span style="color: ${c.accent};">£${total.toFixed(2)}</span>
        </div>
      </div>
      <p style="color: ${c.textMuted}; font-size: 12px; text-align: center; margin: 0;">Thank you for choosing Wish a Wash</p>
    </div>
  `;
}

export default function PastWashesScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [orders, setOrders] = useState<CompletedBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_name, service_type, price, completed_at, created_at, valeter_name, location_address, location_lat, location_lng, tip_amount, rating, payment_completed_at, valeter_id')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      const rows = data || [];
      const valeterIds = [...new Set(rows.map((r) => (r as any).valeter_id).filter(Boolean))] as string[];
      let orgByValeter: Record<string, string> = {};
      if (valeterIds.length > 0) {
        try {
          const { data: profiles } = await supabase
            .from('profiles')
            .select('id, organization_name')
            .in('id', valeterIds);
          if (profiles) {
            orgByValeter = Object.fromEntries(
              profiles
                .map((p) => [p.id, (p as { organization_name?: string }).organization_name ?? ''] as [string, string])
                .filter(([, v]) => v.length > 0)
            );
          }
        } catch {
          // ignore
        }
      }
      const normalizedOrders = rows
        .map((r) => {
          const raw = r as any;
          const lat = raw.location_lat != null ? Number(raw.location_lat) : null;
          const lng = raw.location_lng != null ? Number(raw.location_lng) : null;
          return {
            id: r.id,
            service_name: r.service_name,
            service_type: r.service_type,
            price: Number(r.price) || 0,
            completed_at: r.completed_at,
            created_at: r.created_at,
            valeter_name: r.valeter_name ?? null,
            valeter_organization_name: raw.valeter_organization || (raw.valeter_id && orgByValeter[raw.valeter_id]) || null,
            location_address: r.location_address ?? null,
            location_lat: Number.isFinite(lat) ? lat : null,
            location_lng: Number.isFinite(lng) ? lng : null,
            tip_amount: r.tip_amount == null ? null : Number(r.tip_amount),
            rating: r.rating == null ? null : Number(r.rating),
            payment_completed_at: r.payment_completed_at ?? null,
          };
        })
        .sort((a, b) => getBookingSortTimestamp(b) - getBookingSortTimestamp(a));
      setOrders(normalizedOrders);
    } catch (e) {
      console.error('[Past washes] load error:', e);
      Alert.alert('Error', 'Failed to load past washes');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadOrders();
  }, [loadOrders]);

  const handleGeneratePDF = async (booking: CompletedBooking) => {
    if (Platform.OS === 'web') {
      Alert.alert('PDF', 'PDF receipts are not available on web. Try the mobile app.');
      return;
    }
    setGeneratingId(booking.id);
    try {
      const printFn = Print.printToFileAsync;
      if (typeof printFn === 'function') {
        const customerName =
          (user?.user_metadata?.full_name as string) || (user?.user_metadata?.name as string) || user?.email?.split('@')[0] || '';
        const customerEmail = user?.email || '';
        const html = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Wash Receipt – Wish a Wash</title>
          <style>
            * { box-sizing: border-box; }
            body { margin: 0; padding: 0; background: #FAFBFC; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            @media print { body { background: #FAFBFC; } }
          </style>
        </head>
        <body>${buildReceiptHTML(booking, customerName, customerEmail)}</body>
        </html>
      `;

        const { uri } = await printFn({
          html,
          base64: false,
          width: 595,
          height: 842,
        });

        const canShare = await Sharing.isAvailableAsync();
        if (canShare) {
          await Sharing.shareAsync(uri, {
            mimeType: 'application/pdf',
            dialogTitle: `Wash receipt - ${getServiceDisplayName(booking.service_type, booking.service_name)}`,
          });
        } else {
          Alert.alert('Receipt saved', `PDF saved to: ${uri}`);
        }
      } else {
        Alert.alert('Error', 'PDF generation is not available on this device.');
      }
    } catch (e: any) {
      console.error('[Orders] PDF error:', e);
      Alert.alert('Error', e?.message || 'Failed to generate receipt');
    } finally {
      setGeneratingId(null);
    }
  };

  const formatFullDate = (d: string | null) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const groupedBySection = useMemo(() => {
    const map = new Map<string, CompletedBooking[]>();
    orders.forEach((o) => {
      const key = getSectionKey(o.completed_at, o.created_at);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    });
    const order = ['this_month', 'last_month', 'older'];
    return order
      .map((key) => ({
        key,
        items: [...(map.get(key) ?? [])].sort(
          (a, b) => getBookingSortTimestamp(b) - getBookingSortTimestamp(a)
        ),
      }))
      .filter((g) => g.items.length > 0);
  }, [orders]);

  const handleRepeatBooking = (order: CompletedBooking) => {
    hapticFeedback('light');
    const serviceType = (order.service_type || order.service_name || '').toLowerCase();
    const hasLocation = order.location_lat != null && order.location_lng != null;
    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(order.location_address && { address: order.location_address }),
          ...(hasLocation && { latitude: String(order.location_lat), longitude: String(order.location_lng) }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(order.location_address && { address: order.location_address }),
          ...(hasLocation && { latitude: String(order.location_lat), longitude: String(order.location_lng) }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(order.location_address && { address: order.location_address }),
          ...(hasLocation && { latitude: String(order.location_lat), longitude: String(order.location_lng) }),
        },
      });
    }
  };

  const handleHelpEmail = (order: CompletedBooking) => {
    hapticFeedback('light');
    const customerName =
      (user?.user_metadata?.full_name as string) ||
      (user?.user_metadata?.name as string) ||
      user?.email?.split('@')[0] ||
      'Customer';
    const customerEmail = user?.email || '';
    const serviceName = getServiceDisplayName(order.service_type, order.service_name) ?? order.service_name ?? 'Car Wash';
    const completedDate = order.completed_at || order.created_at;
    const dateStr = completedDate
      ? new Date(completedDate).toLocaleDateString('en-GB', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        })
      : '—';
    const proOrHub =
      order.valeter_name || order.valeter_organization_name
        ? `Valeter: ${[order.valeter_name, order.valeter_organization_name].filter(Boolean).join(' ')}`
        : order.location_address
          ? `Wash hub / location: ${order.location_address}`
          : 'Pro or wash hub: N/A (e.g. if job was cancelled)';
    const body = [
      '--- JOB DETAILS ---',
      `Booking ID: ${order.id}`,
      `Service: ${serviceName}`,
      `Date: ${dateStr}`,
      `Price: £${(order.price + (order.tip_amount || 0)).toFixed(2)}`,
      `Address: ${order.location_address || '—'}`,
      '',
      '--- CUSTOMER ---',
      `Name: ${customerName}`,
      `Email: ${customerEmail}`,
      '',
      '--- PRO / WASH HUB (completed or was meant to complete this job) ---',
      proOrHub,
      '',
      '---',
      'To the customer: Please in detail explain your issue below and add photo proof if needed.',
      '',
      '[Describe your issue here and attach any photos]',
    ].join('\n');
    const subject = `Support: Past wash ${order.id}`;
    const url = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    Linking.openURL(url).catch(() => {
      Alert.alert('Cannot open email', 'Please email support@wishawash.com with the above details.');
    });
  };

  const washPluralSuffix = orders.length === 1 ? '' : 'es';
  const subtitleText = loading ? 'Loading…' : `${orders.length} past wash${washPluralSuffix}`;

  let mainContent: React.ReactNode;
  if (loading) {
    mainContent = (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={SKY} />
        <Text style={styles.loadingText}>Loading past washes…</Text>
      </View>
    );
  } else if (orders.length === 0) {
    mainContent = (
      <View style={styles.centerContainer}>
        <EmptyState
          icon="checkmark-done-circle-outline"
          title="No past washes yet"
          subtitle="Your completed washes will appear here"
          actionLabel="Book a Wash"
          onAction={() => router.push('/owner/booking')}
          iconColor={SKY}
        />
      </View>
    );
  } else {
    mainContent = (
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: CONTENT_PADDING_H },
          getScrollContentPadding(insets, true),
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />
        }
      >
        {groupedBySection.map(({ key, items }) => (
          <View key={key} style={styles.section}>
            <Text style={styles.sectionTitle}>{getSectionLabel(key)}</Text>
            {items.map((order, index) => {
              const accent = getServiceAccent(order.service_type, order.service_name);
              const displayName = getServiceDisplayName(order.service_type, order.service_name) ?? order.service_name ?? 'Car Wash';
              const relativeDate = getRelativeDate(order.completed_at ?? order.created_at);
              const fullDate = formatFullDate(order.completed_at || order.created_at);
              const animDelay = Math.min(index * 50, 400);
              return (
                <Animated.View
                  key={order.id}
                  entering={FadeInDown.delay(animDelay)}
                  style={styles.cardWrap}
                >
                  <View style={styles.card}>
                    <View style={[styles.cardAccent, { backgroundColor: accent }]} />
                    <View style={styles.cardContent}>
                      <View style={styles.cardBody}>
                        <View style={styles.cardTopRow}>
                          <View style={[styles.cardIconWrap, { backgroundColor: accent + '22', borderColor: accent + '44' }]}>
                            <Ionicons name={getServiceIconName(accent)} size={22} color={accent} />
                          </View>
                          <View style={styles.cardMain}>
                            <Text style={styles.cardService} numberOfLines={1}>{displayName}</Text>
                            <Text style={styles.cardRelative}>{relativeDate}</Text>
                            <Text style={styles.cardFullDate} numberOfLines={1}>{fullDate}</Text>
                          </View>
                          <View style={styles.cardRight}>
                            <Text style={styles.cardPrice}>£{(order.price + (order.tip_amount || 0)).toFixed(2).replace(/\.00$/, '')}</Text>
                            {order.rating != null && (
                              <View style={styles.ratingPill}>
                                <Ionicons name="star" size={12} color={RATING_GOLD} />
                                <Text style={styles.ratingNum}>{order.rating}</Text>
                              </View>
                            )}
                          </View>
                        </View>
                        {(order.valeter_name || order.location_address) && (
                          <View style={styles.cardMeta}>
                            {order.valeter_name && (
                              <View style={styles.metaRow}>
                                <Ionicons name="person-outline" size={14} color={SKY} />
                                <Text style={styles.metaText} numberOfLines={1}>{order.valeter_name}</Text>
                              </View>
                            )}
                            {order.location_address && (
                              <View style={styles.metaRow}>
                                <Ionicons name="location-outline" size={14} color={SKY} />
                                <Text style={styles.metaText} numberOfLines={1}>{order.location_address}</Text>
                              </View>
                            )}
                          </View>
                        )}
                        <View style={styles.cardActionsRow}>
                          <TouchableOpacity
                            onPress={() => handleHelpEmail(order)}
                            style={[styles.helpBtn, { backgroundColor: accent + '28', borderColor: accent + '50' }]}
                            activeOpacity={0.85}
                          >
                            <Ionicons name="help-circle-outline" size={18} color={accent} />
                            <Text style={[styles.helpBtnText, { color: accent }]}>Help</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.receiptBtn}
                            onPress={() => handleGeneratePDF(order)}
                            disabled={!!generatingId}
                            activeOpacity={0.8}
                          >
                            {generatingId === order.id ? (
                              <ActivityIndicator size="small" color={SKY} />
                            ) : (
                              <>
                                <Ionicons name="document-text-outline" size={18} color={SKY} />
                                <Text style={styles.receiptBtnText}>Receipt</Text>
                              </>
                            )}
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </Animated.View>
              );
            })}
          </View>
        ))}
      </ScrollView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Past washes"
        subtitle={orders.length > 0 ? `${orders.length} past wash${orders.length === 1 ? '' : 'es'}` : subtitleText}
        variant="dashboard"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        rightAction={
          <View style={styles.headerActions}>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); router.push('/owner/booking'); }}
              style={styles.headerBookBtn}
              hitSlop={8}
            >
              <Ionicons name="add" size={24} color={SKY} />
            </TouchableOpacity>
          </View>
        }
      />

      {mainContent}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  scrollView: { flex: 1 },
  scrollContent: {
    paddingBottom: 40,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerBookBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  section: { marginBottom: 28 },
  sectionTitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.6,
    marginBottom: 12,
    textTransform: 'uppercase',
  },
  cardWrap: { marginBottom: 12 },
  card: {
    flexDirection: 'row',
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  cardAccent: {
    width: 4,
    borderRadius: 2,
  },
  cardContent: { flex: 1, minWidth: 0 },
  cardBody: { flex: 1, padding: 16, paddingLeft: 14 },
  cardTopRow: { flexDirection: 'row', alignItems: 'flex-start' },
  cardIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
  },
  cardMain: { flex: 1, minWidth: 0 },
  cardService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  cardRelative: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  cardFullDate: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '500',
  },
  cardRight: { alignItems: 'flex-end', gap: 4 },
  cardPrice: {
    color: LIGHT_SKY,
    fontSize: 17,
    fontWeight: '800',
  },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: RATING_GOLD + '22',
  },
  ratingNum: {
    color: RATING_GOLD,
    fontSize: 12,
    fontWeight: '700',
  },
  cardMeta: { marginTop: 12, gap: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metaText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
  },
  cardActionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
  },
  helpBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  helpBtnText: {
    fontSize: 14,
    fontWeight: '700',
  },
  receiptBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  receiptBtnText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
});
