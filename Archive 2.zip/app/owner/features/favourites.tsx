import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function Favourites() {
  const { user } = useAuth();
    const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [favourites, setFavourites] = useState<any[]>([]);

  const loadFavourites = async () => {
    if (!user?.id) return;
    try {
      // TODO: Load from favourites table
      setFavourites([]);
    } catch (error) {
      console.error('Error loading favourites:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadFavourites();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadFavourites();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Favourites" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {favourites.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="star-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Favourites Yet</Text>
            <Text style={styles.emptySubtitle}>Save your favourite valeters for quick booking</Text>
          </View>
        ) : (
          favourites.map((valeter) => (
            <View key={valeter.id} style={styles.valeterCard}>
              <View style={styles.valeterIconWrapper}>
                <Ionicons name="person" size={24} color={SKY} />
              </View>
              <View style={styles.valeterContent}>
                <Text style={styles.valeterName}>{valeter.name}</Text>
                <View style={styles.valeterMeta}>
                  <Ionicons name="star" size={14} color="#F59E0B" />
                  <Text style={styles.valeterRating}>{valeter.rating?.toFixed(1) || '4.5'}</Text>
                  {valeter.distance && (
                    <>
                      <Text style={styles.metaSeparator}>•</Text>
                      <Text style={styles.valeterDistance}>{(valeter.distance * 0.621371).toFixed(1)}mi</Text>
                    </>
                  )}
                </View>
              </View>
              <TouchableOpacity style={styles.bookButton}>
                <Ionicons name="calendar" size={20} color={SKY} />
              </TouchableOpacity>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  valeterCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  valeterIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  valeterContent: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  valeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterRating: {
    color: '#F59E0B',
    fontSize: 13,
    fontWeight: '600',
  },
  metaSeparator: {
    color: '#87CEEB',
    fontSize: 13,
  },
  valeterDistance: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
  bookButton: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
});



