/**
 * Valeter details – hero, stats, what they offer (specializations), Book now CTA.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  Alert,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useThemeOptional } from '../../src/contexts/ThemeContext';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding, HEADER_CONTENT_OFFSET, TAB_BAR_TOTAL_HEIGHT } from '../../src/constants/layoutConstants';
import { colors } from '../../src/constants/colors';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import {
  VALETER_IMAGE,
  CARWASH_IMAGE,
  BRONZE_IMAGE,
  SILVER_IMAGE,
  GOLD_IMAGE,
  PLATINUM_IMAGE,
  EMERALD_IMAGE,
  DETAILING_IMAGE,
  CERAMIC_DETAIL_IMAGE,
  SOFTOP_DETAIL_IMAGE,
  MOULD_DETAIL_IMAGE,
  HEADLIGHT_DETAIL_IMAGE,
} from '../assets/assetExports';
import { serviceOptions, detailingServiceOptions } from '../../src/constants/serviceOptions';

const SKY = colors.SKY;
const BG = colors.BG ?? '#0A1929';
const TEXT_LIGHT = '#F9FAFB';
const TEXT_MUTED = '#94A3B8';
const CARD_BG_DARK = 'rgba(30,41,59,0.6)';
const CARD_BORDER_DARK = 'rgba(148,163,184,0.2)';

type ValeterProfile = {
  user_id: string;
  full_name?: string | null;
  profile_photo_url?: string | null;
  specializations?: string[] | null;
};

type ValeterReview = {
  rating: number;
  review: string | null;
  reviewerName: string;
  completed_at?: string;
};

const WASH_TIER_IDS = ['bronze-wash', 'silver-wash', 'gold-wash', 'platinum-wash', 'emerald-wash'] as const;
const tierImageMap: Record<string, ReturnType<typeof require>> = {
  'bronze-wash': BRONZE_IMAGE,
  'silver-wash': SILVER_IMAGE,
  'gold-wash': GOLD_IMAGE,
  'platinum-wash': PLATINUM_IMAGE,
  'emerald-wash': EMERALD_IMAGE,
};

export default function ValeterDetails() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams<{ valeterId?: string | string[] }>();
  let valeterId: string | undefined;
  if (typeof params.valeterId === 'string') valeterId = params.valeterId;
  else if (Array.isArray(params.valeterId) && params.valeterId[0]) valeterId = params.valeterId[0];
  else valeterId = undefined;
  const themeContext = useThemeOptional();
  const isDark = themeContext?.isDark ?? true;

  const [profile, setProfile] = useState<ValeterProfile | null>(null);
  const [isOnline, setIsOnline] = useState(false);
  const [rating, setRating] = useState<number>(0);
  const [totalJobs, setTotalJobs] = useState<number>(0);
  const [reviews, setReviews] = useState<ValeterReview[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [profileImageFailed, setProfileImageFailed] = useState(false);

  const loadValeter = useCallback(async () => {
    if (!valeterId || valeterId.trim() === '') {
      setError('Missing valeter');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, specializations')
        .eq('user_id', valeterId)
        .maybeSingle();
      let resolved: ValeterProfile;
      if (profileError || !profileData) {
        if (profileError) console.warn('[valeter-details] profile error', profileError);
        resolved = { user_id: valeterId, full_name: 'Valeter', profile_photo_url: null, specializations: null };
        const { data: prof } = await supabase.from('profiles').select('full_name, profile_picture').eq('id', valeterId).maybeSingle();
        const p = prof as { full_name?: string; profile_picture?: string } | null;
        if (p?.full_name) resolved = { ...resolved, full_name: p.full_name };
        if (p?.profile_picture) resolved = { ...resolved, profile_photo_url: p.profile_picture };
      } else {
        resolved = profileData as ValeterProfile;
        if (!resolved.full_name || !resolved.profile_photo_url) {
          const { data: prof } = await supabase
            .from('profiles')
            .select('full_name, profile_picture')
            .eq('id', valeterId)
            .maybeSingle();
          const p = prof as { full_name?: string; profile_picture?: string } | null;
          if (p?.full_name) resolved = { ...resolved, full_name: p.full_name };
          if (p?.profile_picture) resolved = { ...resolved, profile_photo_url: p.profile_picture };
        }
      }
      setProfile(resolved);
      setProfileImageFailed(false);

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', valeterId)
        .maybeSingle();
      setIsOnline((presenceData as { is_online?: boolean } | null)?.is_online ?? false);

      const stats = await ValeterStatsService.getValeterStats(valeterId).catch(() => null);
      if (stats) {
        setRating(stats.averageRating ?? 0);
        setTotalJobs(stats.totalJobs ?? 0);
      }

      const { data: reviewRows } = await supabase
        .from('bookings')
        .select('user_id, rating, review, completed_at')
        .eq('valeter_id', valeterId)
        .eq('status', 'completed')
        .not('rating', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(20);
      const rows = (reviewRows || []) as { user_id: string; rating: number; review: string | null; completed_at?: string }[];
      if (rows.length > 0) {
        const userIds = [...new Set(rows.map((r) => r.user_id))];
        const { data: profilesData } = await supabase.from('profiles').select('id, full_name').in('id', userIds);
        const nameByUserId = new Map<string, string>();
        (profilesData || []).forEach((p: { id: string; full_name?: string | null }) => {
          const name = p.full_name?.trim() || 'Customer';
          nameByUserId.set(p.id, name);
        });
        const list: ValeterReview[] = rows.map((r) => ({
          rating: Number(r.rating) || 0,
          review: r.review ?? null,
          reviewerName: nameByUserId.get(r.user_id) || 'Customer',
          completed_at: r.completed_at,
        }));
        setReviews(list);
      } else {
        setReviews([]);
      }
    } catch (e: unknown) {
      console.warn('[valeter-details] load error', e);
      setProfile({ user_id: valeterId, full_name: 'Valeter', profile_photo_url: null, specializations: null });
      setError(null);
    } finally {
      setLoading(false);
    }
  }, [valeterId]);

  useEffect(() => {
    loadValeter();
  }, [loadValeter]);

  const handleBook = useCallback(async () => {
    if (!valeterId) return;
    hapticFeedback('light');
    if (user?.id) {
      const active = await getActiveBookingForCustomer(user.id);
      if (active) {
        Alert.alert(
          'One booking at a time',
          'Finish or cancel your current booking first.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'View booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
          ]
        );
        return;
      }
    }
    router.push({ pathname: '/owner/booking/create', params: { preferredValeterId: valeterId } } as any);
  }, [valeterId, user?.id]);

  const screenBg = isDark ? BG : 'transparent';
  const textPrimary = isDark ? TEXT_LIGHT : '#F0F9FF';
  const textMuted = isDark ? TEXT_MUTED : 'rgba(240,249,255,0.85)';
  const cardBg = isDark ? CARD_BG_DARK : 'rgba(255,255,255,0.06)';
  const borderColor = isDark ? CARD_BORDER_DARK : 'rgba(135,206,235,0.15)';
  const { paddingBottom } = getScrollContentPadding(insets, true);
  const stickyCtaBottom = TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + 20;
  const scrollBottomWithCta = paddingBottom + 80;

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
        <AppHeader title="Valeter details" showBack onBack={() => { hapticFeedback('light'); router.back(); }} accountType="customer" />
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  if (error && !profile) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
        <AppHeader title="Valeter details" showBack onBack={() => { hapticFeedback('light'); router.back(); }} accountType="customer" />
        <View style={styles.centered}>
          <Text style={[styles.errorText, { color: textMuted }]}>{error}</Text>
          <TouchableOpacity style={[styles.backBtn, { backgroundColor: SKY }]} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
  if (!profile) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
        <AppHeader title="Valeter details" showBack onBack={() => { hapticFeedback('light'); router.back(); }} accountType="customer" />
        <View style={styles.centered}>
          <Text style={[styles.errorText, { color: textMuted }]}>Valeter not found</Text>
          <TouchableOpacity style={[styles.backBtn, { backgroundColor: SKY }]} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const name = profile.full_name || 'Valeter';
  const specializations = Array.isArray(profile.specializations) ? profile.specializations : [];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: screenBg }]} edges={[]}>
      <AppHeader
        title={formatDisplayName(name)}
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />
      <View style={[styles.contentBelowHeader, { paddingTop: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET }]}>
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingTop: 0, paddingBottom: scrollBottomWithCta }]}
          showsVerticalScrollIndicator={false}
        >
          {/* Hero – profile photo or placeholder PNG (same as top valeter cards) */}
          <View style={[styles.heroWrap, { borderColor }]}>
            {profile.profile_photo_url && !profileImageFailed ? (
              <Image
                source={{ uri: profile.profile_photo_url }}
                style={styles.heroImageFull}
                resizeMode="cover"
                onError={() => setProfileImageFailed(true)}
              />
            ) : (
              <Image source={VALETER_IMAGE} style={styles.heroImageFull} resizeMode="cover" />
            )}
            <LinearGradient
              colors={isDark ? ['transparent', 'rgba(10,25,41,0.85)'] : ['transparent', 'rgba(21,34,56,0.75)']}
              style={styles.heroGradient}
            />
            <View style={styles.heroBottom}>
              {rating > 0 && (
                <View style={[styles.ratingPill, { backgroundColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.4)' }]}>
                  <Ionicons name="star" size={14} color="#FBBF24" />
                  <Text style={[styles.ratingPillText, { color: textPrimary }]}>{rating.toFixed(1)}</Text>
                </View>
              )}
              {isOnline && (
                <View style={[styles.onlinePill, { backgroundColor: 'rgba(16,185,129,0.9)' }]}>
                  <View style={styles.onlineDot} />
                  <Text style={styles.onlinePillText}>Available</Text>
                </View>
              )}
            </View>
          </View>

          {/* Info strip: stats */}
          <View style={[styles.infoStrip, { backgroundColor: cardBg, borderColor }]}>
            <View style={styles.infoRow}>
              <Ionicons name="checkmark-done-outline" size={18} color={SKY} />
              <Text style={[styles.infoStripText, { color: textPrimary }]}>{totalJobs} completed jobs</Text>
            </View>
            {rating > 0 && (
              <View style={[styles.infoRow, styles.infoRowBorder, { borderTopColor: borderColor }]}>
                <Ionicons name="star" size={18} color="#FBBF24" />
                <Text style={[styles.infoStripText, { color: textPrimary }]}>{rating.toFixed(1)} average rating</Text>
              </View>
            )}
          </View>

          {/* Wash services – same cards as hub with tier PNGs */}
          <View style={styles.menuSection}>
            <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Wash services</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.serviceOptionsScroll}
            >
              {WASH_TIER_IDS.map((tierId) => {
                const option = serviceOptions.find((o) => o.id === tierId);
                if (!option) return null;
                const tierImage = tierImageMap[tierId] ?? CARWASH_IMAGE;
                return (
                  <Pressable
                    key={tierId}
                    style={({ pressed }) => [styles.serviceOptionCard, { backgroundColor: cardBg, borderColor }, pressed && styles.menuItemPressed]}
                    onPress={() => hapticFeedback('light')}
                  >
                    <View style={styles.serviceOptionImageWrap}>
                      <Image source={tierImage} style={styles.serviceOptionImage} resizeMode="cover" />
                    </View>
                    <View style={styles.serviceOptionBody}>
                      <Text style={[styles.serviceOptionTitle, { color: textPrimary }]} numberOfLines={1}>{option.name}</Text>
                      {option.dur ? <Text style={[styles.serviceOptionMeta, { color: textMuted }]}>{option.dur}</Text> : null}
                      <Text style={[styles.serviceOptionPrice, { color: SKY }]}>from £{option.price}</Text>
                    </View>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>

          {/* Detailing – same cards as hub with PNGs */}
          <View style={styles.menuSection}>
            <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Detailing</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.serviceOptionsScroll}
            >
              {detailingServiceOptions.slice(0, 6).map((d) => {
                let detailBgImage = DETAILING_IMAGE;
                if (d.id === 'ceramic-coating') detailBgImage = CERAMIC_DETAIL_IMAGE;
                else if (d.id === 'soft-top-restoration') detailBgImage = SOFTOP_DETAIL_IMAGE;
                else if (d.id === 'mould-removal') detailBgImage = MOULD_DETAIL_IMAGE;
                else if (d.id === 'headlight-restoration') detailBgImage = HEADLIGHT_DETAIL_IMAGE;
                return (
                  <Pressable
                    key={d.id}
                    style={({ pressed }) => [styles.serviceOptionCard, { backgroundColor: cardBg, borderColor }, pressed && styles.menuItemPressed]}
                    onPress={() => hapticFeedback('light')}
                  >
                    <View style={styles.serviceOptionImageWrap}>
                      <Image source={detailBgImage} style={styles.serviceOptionImage} resizeMode="cover" />
                    </View>
                    <View style={styles.serviceOptionBody}>
                      <Text style={[styles.serviceOptionTitle, { color: textPrimary }]} numberOfLines={2}>{d.name}</Text>
                      <Text style={[styles.serviceOptionPrice, { color: SKY }]}>from £{d.price}</Text>
                    </View>
                  </Pressable>
                );
              })}
            </ScrollView>
            <Text style={[styles.menuItemMuted, { color: textMuted, marginTop: 6 }]}>Exact pricing in booking.</Text>
          </View>

          {/* Reviews – horizontal scrolling cards with star rating and who by */}
          <View style={styles.menuSection}>
            <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>Reviews</Text>
            {reviews.length === 0 ? (
              <View style={[styles.reviewsEmptyBox, { backgroundColor: cardBg, borderColor }]}>
                <Ionicons name="chatbubble-ellipses-outline" size={32} color={textMuted} />
                <Text style={[styles.reviewsEmptyText, { color: textMuted }]}>Reviews will appear here when customers leave feedback.</Text>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.reviewsScroll}
              >
                {reviews.map((rev, idx) => (
                  <View key={`${rev.reviewerName}-${rev.rating}-${idx}`} style={[styles.reviewCard, { backgroundColor: cardBg, borderColor }]}>
                    <View style={styles.reviewStarsRow}>
                      <Ionicons name="star" size={16} color="#FBBF24" />
                      <Text style={[styles.reviewRatingText, { color: textPrimary }]}>{rev.rating.toFixed(1)}</Text>
                    </View>
                    {rev.review ? (
                      <Text style={[styles.reviewBody, { color: textPrimary }]} numberOfLines={4}>{rev.review}</Text>
                    ) : (
                      <Text style={[styles.reviewBody, { color: textMuted }]}>No comment</Text>
                    )}
                    <Text style={[styles.reviewBy, { color: textMuted }]}>— {rev.reviewerName}</Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </View>

          {/* What they offer (specializations) */}
          {specializations.length > 0 && (
            <View style={styles.menuSection}>
              <Text style={[styles.menuSectionTitle, { color: textPrimary }]}>What they offer</Text>
              <View style={styles.chipWrap}>
                {specializations.map((s) => (
                  <View key={s} style={[styles.offerChip, { backgroundColor: cardBg, borderColor }]}>
                    <Ionicons name="checkmark-circle" size={16} color={SKY} />
                    <Text style={[styles.offerChipText, { color: textPrimary }]}>{s}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </ScrollView>

        {/* Sticky CTA */}
        <View style={[styles.stickyCtaWrap, { backgroundColor: cardBg, borderTopColor: borderColor, bottom: stickyCtaBottom }]}>
          <TouchableOpacity style={[styles.bookBtn, { backgroundColor: SKY }]} onPress={handleBook} activeOpacity={0.9}>
            <Text style={styles.bookBtnText}>Book this valeter</Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  contentBelowHeader: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16 },
  errorText: { fontSize: 16, marginBottom: 16, textAlign: 'center' },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12 },
  backBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  heroWrap: {
    marginHorizontal: -16,
    marginBottom: 12,
    height: 200,
    overflow: 'hidden',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  heroImageFull: { width: '100%', height: '100%' },
  heroGradient: { ...StyleSheet.absoluteFillObject },
  heroBottom: {
    position: 'absolute',
    bottom: 12,
    left: 16,
    right: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    gap: 4,
  },
  ratingPillText: { fontSize: 14, fontWeight: '700' },
  onlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    gap: 6,
  },
  onlineDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#fff' },
  onlinePillText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  infoStrip: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 20,
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoRowBorder: { borderTopWidth: 1, paddingTop: 12, marginTop: 12 },
  infoStripText: { flex: 1, fontSize: 14 },
  menuSection: { marginBottom: 20 },
  menuSectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 10, letterSpacing: 0.3 },
  serviceOptionsScroll: { paddingRight: 16 },
  serviceOptionCard: {
    width: 160,
    marginRight: 12,
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
  },
  serviceOptionImageWrap: {
    height: 100,
    width: '100%',
    backgroundColor: 'rgba(0,0,0,0.15)',
    position: 'relative',
  },
  serviceOptionImage: { width: '100%', height: '100%' },
  serviceOptionBody: { padding: 12 },
  serviceOptionTitle: { fontSize: 15, fontWeight: '600', marginBottom: 2 },
  serviceOptionMeta: { fontSize: 12, marginBottom: 4 },
  serviceOptionPrice: { fontSize: 15, fontWeight: '700' },
  menuItemPressed: { opacity: 0.7 },
  menuItemMuted: { fontSize: 14, paddingHorizontal: 0 },
  reviewsScroll: { paddingRight: 16 },
  reviewCard: {
    width: 220,
    marginRight: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
  },
  reviewStarsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  reviewRatingText: { fontSize: 16, fontWeight: '700' },
  reviewBody: { fontSize: 14, lineHeight: 20, marginBottom: 8 },
  reviewBy: { fontSize: 12, fontStyle: 'italic' },
  reviewsEmptyBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
  },
  reviewsEmptyText: { fontSize: 14, textAlign: 'center', marginTop: 8 },
  offerCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
  },
  offerEmptyText: { fontSize: 14, lineHeight: 22 },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  offerChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  offerChipText: { fontSize: 14, fontWeight: '600', flex: 1 },
  stickyCtaWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    borderTopWidth: 1,
  },
  bookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    borderRadius: 14,
  },
  bookBtnText: { color: '#fff', fontWeight: '700', fontSize: 17 },
});
