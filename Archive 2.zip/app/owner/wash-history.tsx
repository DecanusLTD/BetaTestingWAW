import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
  Alert,
  Animated as RNAnimated,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import LoadingScreen from '../../src/components/LoadingScreen';
import EmptyState from '../../src/components/shared/EmptyState';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../src/constants/layoutConstants';
import { CONTENT_PADDING_H } from '../../src/constants/pageStyles';
import { colors } from '../../src/constants/colors';
import { customerTheme } from '../../src/constants/customerTheme';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import Animated, { FadeInDown } from 'react-native-reanimated';
import MapView, { Marker } from 'react-native-maps';
import { BOOKING_MAP_STYLE, MAP_LOCKED_DARK } from '../../src/constants/mapConstants';
import { CAR_IMAGE } from '../assets/assetExports';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const RATING_GOLD = '#FBBF24';
const ECO_GREEN = colors.ECO_GREEN ?? '#10B981';
const DETAILING_YELLOW = colors.DETAILING_YELLOW ?? '#EAB308';

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'closed',
  'archived',
  'complete',
]);

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

function getRelativeDate(dateLike: Date | string | number | undefined | null): string {
  if (!dateLike) return '';
  const d = new Date(dateLike);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 14) return 'Last week';
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  if (diffDays < 60) return 'Last month';
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
  const years = Math.floor(diffDays / 365);
  return years > 1 ? `${years} years ago` : '1 year ago';
}

function getSectionLabel(key: string): string {
  switch (key) {
    case 'this_month':
      return 'This month';
    case 'last_month':
      return 'Last month';
    case 'older':
      return 'Older';
    default:
      return key;
  }
}

function getSectionKey(completion: NormalizedCompletion): string {
  const d = new Date((completion.completedAt ?? completion.createdAt ?? 0) as any);
  const now = new Date();
  const thisMonth = now.getFullYear() * 12 + now.getMonth();
  const thatMonth = d.getFullYear() * 12 + d.getMonth();
  const diff = thisMonth - thatMonth;
  if (diff === 0) return 'this_month';
  if (diff === 1) return 'last_month';
  return 'older';
}

function getServiceAccent(completion: NormalizedCompletion): string {
  const t = (completion.service_type ?? completion.serviceName ?? '').toLowerCase();
  if (t.includes('detailing')) return DETAILING_YELLOW;
  if (t.includes('eco')) return ECO_GREEN;
  return SKY;
}

function getServiceIconName(accent: string): 'leaf' | 'sparkles' | 'water' {
  if (accent === ECO_GREEN) return 'leaf';
  if (accent === DETAILING_YELLOW) return 'sparkles';
  return 'water';
}

export default function WashHistory() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();
  const insets = useSafeAreaInsets();

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const scrollY = useRef(new RNAnimated.Value(0)).current;

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null,
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null,
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const groupedBySection = useMemo(() => {
    const sorted = [...washCompletions].sort(sortByCompletedAtDesc);
    const map = new Map<string, NormalizedCompletion[]>();
    sorted.forEach((c) => {
      const key = getSectionKey(c);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(c);
    });
    const order = ['this_month', 'last_month', 'older'];
    return order.map((key) => ({ key, items: map.get(key) ?? [] })).filter((g) => g.items.length > 0);
  }, [washCompletions]);

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `id, user_id, status, service_name, service_type, wash_type, price, scheduled_at, created_at, completed_at, valeter_name, location_address, location_lat, location_lng, rating, customer_review, tip_amount, special_instructions, cancelled_at`
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .or('completed_at.not.is.null,status.eq.completed')
        .order('completed_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const completedList = normalizeFromBookings(completedRows || [])
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);

      setWashCompletions(completedList);
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const performDeleteOne = useCallback(async (completion: NormalizedCompletion) => {
    if (!user?.id) return;
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .eq('id', completion.id)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions((prev) => prev.filter((c) => c.id !== completion.id));
    } catch (e) {
      console.error('[wash-history] Delete error:', e);
      Alert.alert('Error', 'Could not remove from history');
    }
  }, [user?.id]);

  const handleDeleteOne = useCallback((completion: NormalizedCompletion) => {
    Alert.alert(
      'Remove from history',
      `Remove "${getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'this booking'}" from your history?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => void performDeleteOne(completion) },
      ]
    );
  }, [performDeleteOne]);

  const performClearAll = useCallback(async () => {
    if (!user?.id) return;
    try {
      const ids = washCompletions.map((c) => c.id);
      const { error } = await supabase
        .from('bookings')
        .update({ cancelled_at: new Date().toISOString() })
        .in('id', ids)
        .eq('user_id', user.id);
      if (error) throw error;
      setWashCompletions([]);
    } catch (e) {
      console.error('[wash-history] Clear all error:', e);
      Alert.alert('Error', 'Could not clear history');
    }
  }, [user?.id, washCompletions]);

  const handleClearAll = useCallback(() => {
    if (washCompletions.length === 0) return;
    Alert.alert(
      'Clear all history',
      `Remove all ${washCompletions.length} booking${washCompletions.length === 1 ? '' : 's'}? This can't be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Clear all', style: 'destructive', onPress: () => void performClearAll() },
      ]
    );
  }, [washCompletions.length, performClearAll]);

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    hapticFeedback('light');
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();
    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: String(completion.location.latitude) }),
          ...(completion.location?.longitude && { longitude: String(completion.location.longitude) }),
        },
      });
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="History"
        subtitle={washCompletions.length > 0 ? `${washCompletions.length} completed` : undefined}
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={
          <View style={styles.headerActions}>
            {washCompletions.length > 0 && (
              <TouchableOpacity onPress={() => { hapticFeedback('light'); handleClearAll(); }} style={styles.headerClearBtn} hitSlop={8}>
                <Ionicons name="trash-outline" size={20} color="#94A3B8" />
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={() => { hapticFeedback('light'); router.push('/owner/booking'); }} style={styles.headerBookBtn}>
              <Ionicons name="add" size={24} color={SKY} />
            </TouchableOpacity>
          </View>
        }
      />

      <RNAnimated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...getScrollContentPadding(insets, true) }]}
        showsVerticalScrollIndicator={false}
        onScroll={RNAnimated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {washCompletions.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyWrap}>
            <EmptyState
              icon="time-outline"
              title="No history yet"
              subtitle="Completed washes and details will show here"
              actionLabel="Book a service"
              onAction={() => router.push('/owner/booking')}
              iconColor={SKY}
              style={styles.emptyState}
            />
          </Animated.View>
        ) : (
          <>
            {groupedBySection.map(({ key, items }) => (
              <View key={key} style={styles.section}>
                <Text style={styles.sectionTitle}>{getSectionLabel(key)}</Text>
                {items.map((completion, index) => {
                  const isHighlighted = highlightId === completion.id;
                  const accent = getServiceAccent(completion);
                  const displayName = getServiceDisplayName(completion.service_type, completion.serviceName) ?? completion.serviceName ?? 'Car Wash';
                  const relativeDate = getRelativeDate(completion.completedAt ?? completion.createdAt);
                  const fullDate = formatDate(completion.completedAt ?? completion.createdAt);

                  return (
                    <Animated.View
                      key={completion.id}
                      entering={FadeInDown.delay(index * 60)}
                      style={styles.cardWrap}
                    >
                      <View style={[styles.card, isHighlighted && styles.cardHighlight]}>
                        <View style={[styles.cardAccent, { backgroundColor: accent }]} />
                        <View style={styles.cardContent}>
                          {completion.location?.latitude != null && completion.location?.longitude != null && (
                            <View style={styles.cardMapWrap}>
                              <MapView
                                style={styles.cardMap}
                                region={{
                                  latitude: completion.location.latitude,
                                  longitude: completion.location.longitude,
                                  latitudeDelta: 0.002,
                                  longitudeDelta: 0.002,
                                }}
                                scrollEnabled={false}
                                zoomEnabled={false}
                                pitchEnabled={false}
                                rotateEnabled={false}
                                customMapStyle={BOOKING_MAP_STYLE}
                                userInterfaceStyle={MAP_LOCKED_DARK}
                              >
                                <Marker
                                  coordinate={{
                                    latitude: completion.location.latitude,
                                    longitude: completion.location.longitude,
                                  }}
                                  anchor={{ x: 0.5, y: 0.5 }}
                                >
                                  <View style={styles.cardMapMarkerWrap}>
                                    <Image source={CAR_IMAGE} style={styles.cardMapMarker} resizeMode="contain" />
                                  </View>
                                </Marker>
                              </MapView>
                              <LinearGradient
                                colors={['transparent', 'rgba(30,41,59,0.85)']}
                                style={styles.cardMapGradient}
                              />
                            </View>
                          )}
                          <View style={styles.cardBody}>
                          <View style={styles.cardTopRow}>
                            <View style={[styles.cardIconWrap, { backgroundColor: accent + '22', borderColor: accent + '44' }]}>
                              <Ionicons
                                name={getServiceIconName(accent)}
                                size={22}
                                color={accent}
                              />
                            </View>
                            <View style={styles.cardMain}>
                              <Text style={styles.cardService} numberOfLines={1}>{displayName}</Text>
                              <Text style={styles.cardRelative}>{relativeDate}</Text>
                              <Text style={styles.cardFullDate} numberOfLines={1}>{fullDate}</Text>
                            </View>
                            <View style={styles.cardRight}>
                              <Text style={styles.cardPrice}>{formatCurrency(completion.price)}</Text>
                              {completion.rating != null && (
                                <View style={styles.ratingPill}>
                                  <Ionicons name="star" size={12} color={RATING_GOLD} />
                                  <Text style={styles.ratingNum}>{completion.rating}</Text>
                                </View>
                              )}
                              <TouchableOpacity
                                onPress={() => handleDeleteOne(completion)}
                                style={styles.deleteBtn}
                                hitSlop={12}
                              >
                                <Ionicons name="trash-outline" size={18} color="#94A3B8" />
                              </TouchableOpacity>
                            </View>
                          </View>

                          {(completion.valeterName || completion.address) && (
                            <View style={styles.cardMeta}>
                              {completion.valeterName && (
                                <View style={styles.metaRow}>
                                  <Ionicons name="person-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>{completion.valeterName}</Text>
                                </View>
                              )}
                              {completion.address && (
                                <View style={styles.metaRow}>
                                  <Ionicons name="location-outline" size={14} color={SKY} />
                                  <Text style={styles.metaText} numberOfLines={1}>{completion.address}</Text>
                                </View>
                              )}
                            </View>
                          )}

                          <TouchableOpacity
                            onPress={() => handleRepeatBooking(completion)}
                            style={[styles.repeatBtn, { backgroundColor: accent + '28', borderColor: accent + '50' }]}
                            activeOpacity={0.85}
                          >
                            <Ionicons name="repeat" size={18} color={accent} />
                            <Text style={[styles.repeatLabel, { color: accent }]}>Book again</Text>
                          </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    </Animated.View>
                  );
                })}
              </View>
            ))}
          </>
        )}
      </RNAnimated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {},

  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerClearBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBookBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },

  emptyWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyState: { minHeight: 260 },

  section: { marginBottom: 28 },
  sectionTitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.6,
    marginBottom: 12,
    textTransform: 'uppercase',
  },

  cardWrap: { marginBottom: 12 },
  card: {
    flexDirection: 'row',
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
  },
  cardHighlight: {
    borderColor: SKY + '60',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  cardAccent: {
    width: 4,
    borderRadius: 2,
  },
  cardContent: { flex: 1, minWidth: 0 },
  cardMapWrap: {
    height: 100,
    width: '100%',
    overflow: 'hidden',
    position: 'relative',
  },
  cardMap: {
    ...StyleSheet.absoluteFillObject,
  },
  cardMapGradient: {
    ...StyleSheet.absoluteFillObject,
    pointerEvents: 'none',
  },
  cardMapMarkerWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardMapMarker: {
    width: 36,
    height: 36,
  },
  cardBody: { flex: 1, padding: 16, paddingLeft: 14 },
  cardTopRow: { flexDirection: 'row', alignItems: 'flex-start' },
  cardIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
  },
  cardMain: { flex: 1, minWidth: 0 },
  cardService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  cardRelative: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  cardFullDate: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '500',
  },
  cardRight: { alignItems: 'flex-end', gap: 4 },
  cardPrice: {
    color: LIGHT_SKY,
    fontSize: 17,
    fontWeight: '800',
  },
  ratingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: RATING_GOLD + '22',
  },
  ratingNum: {
    color: RATING_GOLD,
    fontSize: 12,
    fontWeight: '700',
  },
  deleteBtn: { padding: 4, marginTop: 2 },

  cardMeta: { marginTop: 12, gap: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metaText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
  },

  repeatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 14,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  repeatLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
});
