/**
 * Post-auth profile setup — required name + vehicle reg, optional profile photo.
 * Used after Apple Sign In (and any customer missing those fields).
 */
import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { WWPrimaryButton } from '../../src/components/ui';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { addVehicleByRegistration, cleanVehicleReg } from '../../src/utils/vehicleQuickAdd';
import { hasUsableDisplayName, resolvePostAuthRoute } from '../../src/utils/profileSetupGate';
import {
  profilePicturePathFromUrl,
  uploadProfilePictureBytes,
} from '../../src/utils/profilePictureStorage';

const SKY = colors.SKY ?? '#38BDF8';
const BRAND_YELLOW = '#F8D70C';
const STEPS = ['Name', 'Vehicle', 'Photo'] as const;

const base64ToUint8Array = (base64: string) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  let str = base64.replace(/[^A-Za-z0-9+/=]/g, '');
  let output = '';
  let bc = 0;
  let bs = 0;
  let buffer: string;
  let idx = 0;
  while ((buffer = str.charAt(idx++))) {
    const val = chars.indexOf(buffer);
    if (val === -1) continue;
    bs = bc % 4 ? bs * 64 + val : val;
    if (bc++ % 4) output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6)));
  }
  const bytes = new Uint8Array(output.length);
  for (let i = 0; i < output.length; i += 1) bytes[i] = output.charCodeAt(i);
  return bytes;
};

const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  return anyPicker.MediaType?.Images ?? anyPicker.MediaTypeOptions?.Images ?? 'Images';
};

export default function ProfileSetupScreen() {
  const { user, updateUser } = useAuth();
  const insets = useSafeAreaInsets();

  const initialStep = hasUsableDisplayName(user?.name) ? 1 : 0;
  const [step, setStep] = useState(initialStep);
  const [name, setName] = useState(() => (hasUsableDisplayName(user?.name) ? user!.name.trim() : ''));
  const [registration, setRegistration] = useState('');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const progress = useMemo(() => (step + 1) / STEPS.length, [step]);

  const finishAndRoute = async () => {
    if (!user?.id) {
      router.replace('/owner/owner-dashboard');
      return;
    }
    // Refresh name on local user object for routing helper
    const next = await resolvePostAuthRoute({ ...user, name: name.trim() || user.name });
    // If still incomplete somehow, stay; else go to onboarding/dashboard
    if (next === '/owner/profile-setup') {
      router.replace('/owner/customer-onboarding');
      return;
    }
    router.replace(next);
  };

  const handleSaveName = async () => {
    const trimmed = name.trim();
    if (!hasUsableDisplayName(trimmed)) {
      setError('Please enter your full name');
      return;
    }
    await hapticFeedback('medium');
    setLoading(true);
    setError(null);
    try {
      await updateUser({ name: trimmed });
      setStep(1);
    } catch (e: any) {
      setError(e?.message || 'Could not save your name. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveVehicle = async () => {
    if (!user?.id) return;
    const reg = cleanVehicleReg(registration);
    if (reg.length < 2) {
      setError('Enter your vehicle registration');
      return;
    }
    await hapticFeedback('medium');
    setLoading(true);
    setError(null);
    try {
      const result = await addVehicleByRegistration({
        userId: user.id,
        registration: reg,
        isFirstVehicle: true,
      });
      if (!result.ok) {
        setError(result.message);
        return;
      }
      setStep(2);
    } catch (e: any) {
      setError(e?.message || 'Could not add that vehicle. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const pickPhoto = async () => {
    try {
      await hapticFeedback('light');
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        setError('Photo library permission is needed to upload a profile picture.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.85,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      setPhotoUri(result.assets[0].uri);
      setError(null);
    } catch (e: any) {
      setError(e?.message || 'Could not open photo library.');
    }
  };

  const uploadPhotoIfNeeded = async () => {
    if (!user?.id || !photoUri) return;
    const base64 = await FileSystem.readAsStringAsync(photoUri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const bytes = base64ToUint8Array(base64);
    const previous = profilePicturePathFromUrl(user.profilePicture);
    const uploadedUrl = await uploadProfilePictureBytes(user.id, bytes, {
      previousUrl: previous,
    });
    const clean = String(uploadedUrl || '').split('?')[0];
    if (!clean) throw new Error('Could not upload profile picture');
    await supabase.from('profiles').update({ profile_picture: clean }).eq('id', user.id);
    await updateUser({ profilePicture: clean });
  };

  const handleFinishPhoto = async (skip: boolean) => {
    await hapticFeedback('medium');
    setLoading(true);
    setError(null);
    try {
      if (!skip && photoUri) {
        await uploadPhotoIfNeeded();
      }
      try {
        await AsyncStorage.setItem('customer_profile_setup_complete', 'true');
      } catch {
        /* ignore */
      }
      await finishAndRoute();
    } catch (e: any) {
      setError(e?.message || 'Could not finish setup. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#020A18', '#0A1929', '#020A18']}
        style={StyleSheet.absoluteFill}
      />
      <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={8}
        >
          <View style={[styles.header, { paddingTop: Math.max(insets.top > 0 ? 8 : 16, 8) }]}>
            <Text style={styles.kicker}>ALMOST THERE</Text>
            <Text style={styles.headline}>Confirm your details</Text>
            <Text style={styles.subcopy}>
              Name and vehicle reg are required. Profile photo is optional.
            </Text>

            <View style={styles.stepRow}>
              {STEPS.map((label, i) => {
                const active = i === step;
                const done = i < step;
                return (
                  <View key={label} style={styles.stepItem}>
                    <View
                      style={[
                        styles.stepDot,
                        (active || done) && styles.stepDotActive,
                        done && styles.stepDotDone,
                      ]}
                    >
                      {done ? (
                        <Ionicons name="checkmark" size={12} color="#0B1220" />
                      ) : (
                        <Text style={[styles.stepNum, active && styles.stepNumActive]}>{i + 1}</Text>
                      )}
                    </View>
                    <Text style={[styles.stepLabel, active && styles.stepLabelActive]}>{label}</Text>
                  </View>
                );
              })}
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
            </View>
          </View>

          <ScrollView
            style={styles.flex}
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.card}>
              <BlurView intensity={Platform.OS === 'ios' ? 28 : 40} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient
                colors={['rgba(14,165,233,0.16)', 'rgba(8,20,38,0.55)']}
                style={StyleSheet.absoluteFill}
              />

              {step === 0 ? (
                <>
                  <Text style={styles.cardTitle}>What’s your name?</Text>
                  <Text style={styles.cardHint}>We’ll use this on bookings and messages.</Text>
                  <View style={styles.inputWrapper}>
                    <View style={styles.inputIcon}>
                      <Ionicons name="person-outline" size={20} color={SKY} />
                    </View>
                    <TextInput
                      style={styles.input}
                      placeholder="Full name"
                      placeholderTextColor="rgba(148,163,184,0.75)"
                      value={name}
                      onChangeText={(t) => {
                        setName(t);
                        setError(null);
                      }}
                      autoComplete="name"
                      autoCapitalize="words"
                      accessibilityLabel="Full name"
                    />
                  </View>
                </>
              ) : null}

              {step === 1 ? (
                <>
                  <Text style={styles.cardTitle}>Add your vehicle</Text>
                  <Text style={styles.cardHint}>Enter the registration — we’ll pull the details for you.</Text>
                  <View style={styles.inputWrapper}>
                    <View style={styles.inputIcon}>
                      <Ionicons name="car-outline" size={20} color={SKY} />
                    </View>
                    <TextInput
                      style={styles.input}
                      placeholder="e.g. AB12 CDE"
                      placeholderTextColor="rgba(148,163,184,0.75)"
                      value={registration}
                      onChangeText={(t) => {
                        setRegistration(t.toUpperCase());
                        setError(null);
                      }}
                      autoCapitalize="characters"
                      autoCorrect={false}
                      accessibilityLabel="Vehicle registration"
                    />
                  </View>
                </>
              ) : null}

              {step === 2 ? (
                <>
                  <Text style={styles.cardTitle}>Profile photo</Text>
                  <Text style={styles.cardHint}>Optional — Pros recognise you easier. You can skip.</Text>
                  <TouchableOpacity style={styles.avatarBtn} onPress={() => void pickPhoto()} activeOpacity={0.85}>
                    {photoUri ? (
                      <Image source={{ uri: photoUri }} style={styles.avatarImage} />
                    ) : (
                      <View style={styles.avatarPlaceholder}>
                        <Ionicons name="camera-outline" size={32} color={SKY} />
                        <Text style={styles.avatarPlaceholderText}>Add photo</Text>
                      </View>
                    )}
                  </TouchableOpacity>
                  {photoUri ? (
                    <TouchableOpacity onPress={() => setPhotoUri(null)} style={styles.clearPhoto}>
                      <Text style={styles.clearPhotoText}>Remove photo</Text>
                    </TouchableOpacity>
                  ) : null}
                </>
              ) : null}

              {error ? (
                <View style={styles.errorRow}>
                  <Ionicons name="warning-outline" size={16} color="#F87171" />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              ) : null}
            </View>
          </ScrollView>

          <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 12) }]}>
            {step === 0 ? (
              <WWPrimaryButton
                title={loading ? 'Saving…' : 'Continue'}
                onPress={() => void handleSaveName()}
                disabled={loading}
                loading={loading}
              />
            ) : null}
            {step === 1 ? (
              <WWPrimaryButton
                title={loading ? 'Looking up…' : 'Continue'}
                onPress={() => void handleSaveVehicle()}
                disabled={loading}
                loading={loading}
              />
            ) : null}
            {step === 2 ? (
              <View style={styles.photoActions}>
                <TouchableOpacity
                  style={styles.skipBtn}
                  onPress={() => void handleFinishPhoto(true)}
                  disabled={loading}
                  activeOpacity={0.85}
                >
                  <Text style={styles.skipText}>Skip for now</Text>
                </TouchableOpacity>
                <View style={styles.photoPrimary}>
                  <WWPrimaryButton
                    title={loading ? 'Finishing…' : photoUri ? 'Save & continue' : 'Continue'}
                    onPress={() => void handleFinishPhoto(!photoUri)}
                    disabled={loading}
                    loading={loading}
                  />
                </View>
              </View>
            ) : null}
            {loading && step === 1 ? (
              <View style={styles.lookupHint}>
                <ActivityIndicator size="small" color={SKY} />
                <Text style={styles.lookupHintText}>Checking DVLA…</Text>
              </View>
            ) : null}
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#020A18' },
  safe: { flex: 1 },
  flex: { flex: 1 },
  header: {
    paddingHorizontal: 22,
    paddingBottom: 8,
  },
  kicker: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
    marginBottom: 6,
  },
  headline: {
    color: '#F8FAFC',
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subcopy: {
    marginTop: 8,
    color: BRAND_YELLOW,
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
  },
  stepRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    marginBottom: 12,
  },
  stepItem: { alignItems: 'center', flex: 1 },
  stepDot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.55)',
    marginBottom: 6,
  },
  stepDotActive: {
    borderColor: SKY,
    backgroundColor: 'rgba(56,189,248,0.2)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  stepNum: { color: 'rgba(226,232,240,0.55)', fontSize: 12, fontWeight: '800' },
  stepNumActive: { color: SKY },
  stepLabel: { color: 'rgba(148,163,184,0.75)', fontSize: 12, fontWeight: '700' },
  stepLabelActive: { color: '#F8FAFC' },
  progressTrack: {
    height: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(148,163,184,0.2)',
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 999,
  },
  scrollContent: {
    paddingHorizontal: 22,
    paddingTop: 16,
    paddingBottom: 20,
  },
  card: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
    padding: 18,
    backgroundColor: 'rgba(8,20,38,0.45)',
  },
  cardTitle: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  cardHint: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(8,20,38,0.65)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.28)',
  },
  inputIcon: {
    width: 46,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '600',
    paddingRight: 14,
    paddingVertical: 14,
  },
  avatarBtn: {
    alignSelf: 'center',
    width: 132,
    height: 132,
    borderRadius: 66,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(125,211,252,0.4)',
    marginTop: 4,
  },
  avatarImage: { width: '100%', height: '100%' },
  avatarPlaceholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(8,20,38,0.7)',
    gap: 6,
  },
  avatarPlaceholderText: { color: SKY, fontWeight: '800', fontSize: 13 },
  clearPhoto: { alignSelf: 'center', marginTop: 12 },
  clearPhotoText: { color: 'rgba(226,232,240,0.7)', fontWeight: '700', fontSize: 13 },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 14,
  },
  errorText: { flex: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600' },
  footer: {
    paddingHorizontal: 22,
    paddingTop: 8,
    gap: 10,
  },
  photoActions: {
    gap: 10,
  },
  skipBtn: {
    alignSelf: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  skipText: {
    color: 'rgba(226,232,240,0.75)',
    fontWeight: '700',
    fontSize: 14,
  },
  photoPrimary: { width: '100%' },
  lookupHint: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  lookupHintText: { color: 'rgba(226,232,240,0.7)', fontSize: 12, fontWeight: '600' },
});
