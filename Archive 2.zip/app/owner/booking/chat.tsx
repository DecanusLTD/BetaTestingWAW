import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
  Pressable,
  Alert,
  Linking,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { colors } from '../../../src/constants/colors';
import { supabase } from '../../../src/lib/supabase';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { CAR_IMAGE, VALETER_IMAGE } from '../../../assets/assetExports';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import {
  BookingChatMessageRow,
  BookingPaymentRequestStatus,
  loadBookingChatMessages,
  parseBookingChatPaymentRequest,
  sendBookingChatMessage,
  subscribeToBookingChatMessages,
} from '../../../src/services/BookingChatService';

let useStripe: any = null;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripe = stripe.useStripe;
  } catch {}
}

const SKY = colors.SKY;
const CARD_RADIUS = 16;
const CARD_BG = 'rgba(30,41,59,0.6)';
const CARD_BORDER = 'rgba(148,163,184,0.2)';
const TEXT_MUTED = '#94A3B8';

type BookingRow = {
  id: string;
  user_id?: string | null;
  service_type: string;
  service_name?: string | null;
  valeter_id?: string | null;
  location_id?: string | null;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  location_address?: string | null;
};

type Message = {
  id: string;
  senderRole: 'customer' | 'valeter';
  content: string;
  time: string;
  mine: boolean;
  messageType?: 'text' | 'image' | 'voice' | 'payment_request';
  mediaUrl?: string | null;
  voiceDurationSeconds?: number | null;
  paymentRequest?: ParsedPaymentRequest | null;
};

type ParsedPaymentRequest = {
  amount: number;
  currency: string;
  reason: string;
  note?: string | null;
  platformFee?: number | null;
  valeterShare?: number | null;
  status: BookingPaymentRequestStatus;
  paymentIntentId?: string | null;
  paymentIntentClientSecret?: string | null;
  requestedAt?: string | null;
  paidAt?: string | null;
  requestedBy?: string | null;
  requestedByRole?: string | null;
};

export default function BookingChat() {
  const { user } = useAuth();
  const currentUserId = user?.id ?? null;
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const insets = useSafeAreaInsets();

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [proName, setProName] = useState<string>('Valeter');
  const [proPhoto, setProPhoto] = useState<string | null>(null);
  const [rating, setRating] = useState<number>(0);
  const [jobsCompleted, setJobsCompleted] = useState<number>(0);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [optionsExpanded, setOptionsExpanded] = useState(false);
  const [valeterVehicle, setValeterVehicle] = useState<string | null>(null);
  const [valeterBio, setValeterBio] = useState<string | null>(null);
  const [proPhone, setProPhone] = useState<string | null>(null);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [paymentProcessingMessageId, setPaymentProcessingMessageId] = useState<string | null>(null);
  const scrollRef = useRef<ScrollView>(null);
  const stripeHook = useStripe ? useStripe() : null;
  const initPaymentSheet = typeof stripeHook?.initPaymentSheet === 'function' ? stripeHook.initPaymentSheet : undefined;
  const presentPaymentSheet = typeof stripeHook?.presentPaymentSheet === 'function' ? stripeHook.presentPaymentSheet : undefined;

  useEffect(() => {
    const show = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow', () => setKeyboardVisible(true));
    const hide = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', () => setKeyboardVisible(false));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    const load = async () => {
      try {
        const { data: bookingData, error: bookingError } = await supabase
          .from('bookings')
          .select('id, user_id, service_type, service_name, valeter_id, location_id, vehicle_type, vehicle_info, location_address')
          .eq('id', bookingId)
          .single();

        if (bookingError || !bookingData) {
          setBooking(null);
          setLoading(false);
          return;
        }

        const row = bookingData as BookingRow;
        setBooking(row);

        if (row.valeter_id) {
          const [profile, stats] = await Promise.all([
            fetchProfileById(row.valeter_id),
            ValeterStatsService.getValeterStats(row.valeter_id),
          ]);
          setProName(profile?.full_name || 'Valeter');
          setProPhone(profile?.phone ?? null);
          setRating(stats.averageRating);
          setJobsCompleted(stats.totalJobs);
          setReviewCount(stats.customerReviews);

          const { data: vp } = await supabase
            .from('valeter_profiles')
            .select('profile_photo_url')
            .eq('user_id', row.valeter_id)
            .maybeSingle();
          if ((vp as any)?.profile_photo_url) setProPhoto((vp as any).profile_photo_url);
          else {
            const { data: prof } = await supabase.from('profiles').select('profile_picture').eq('id', row.valeter_id).maybeSingle();
            if ((prof as any)?.profile_picture) setProPhoto((prof as any).profile_picture);
          }
        } else if (row.location_id) {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name, phone')
            .eq('id', row.location_id)
            .maybeSingle();
          const hubRow = hub as { name?: string; phone?: string } | null;
          setProName(hubRow?.name || 'Car Wash');
          setProPhone(hubRow?.phone ?? null);
        } else {
          setProName('Valeter');
        }

        setValeterBio(
          [getServiceDisplayName(row.service_type, row.service_name), row.location_address].filter(Boolean).join(' · ') || null
        );
      } catch (e) {
        console.error('Chat load error', e);
        setBooking(null);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [bookingId]);

  const mapPaymentRequest = useCallback((content?: string | null): ParsedPaymentRequest | null => {
    const parsed = parseBookingChatPaymentRequest(content);
    if (!parsed) return null;
    const amount = Number(parsed.amount);
    const platformFee = parsed.platformFee != null ? Number(parsed.platformFee) : null;
    const valeterShare = parsed.valeterShare != null ? Number(parsed.valeterShare) : null;
    return {
      amount: Number.isFinite(amount) ? amount : 0,
      currency: String(parsed.currency || 'gbp').toLowerCase(),
      reason: String(parsed.reason || 'Additional charge'),
      note: parsed.note ?? null,
      platformFee: Number.isFinite(platformFee as number) ? (platformFee as number) : null,
      valeterShare: Number.isFinite(valeterShare as number) ? (valeterShare as number) : null,
      status: parsed.status === 'paid' || parsed.status === 'failed' ? parsed.status : 'pending',
      paymentIntentId: parsed.paymentIntentId ?? null,
      paymentIntentClientSecret: parsed.paymentIntentClientSecret ?? null,
      requestedAt: parsed.requestedAt ?? null,
      paidAt: parsed.paidAt ?? null,
      requestedBy: parsed.requestedBy ?? null,
      requestedByRole: parsed.requestedByRole ?? null,
    };
  }, []);

  const loadMessages = useCallback(async () => {
    if (!bookingId) {
      setMessages([]);
      return;
    }
    try {
      const rows = await loadBookingChatMessages(bookingId);
        setMessages(
          rows.map((row: BookingChatMessageRow) => ({
            id: row.id,
            senderRole: row.sender_role,
            content: row.content || (row.message_type === 'image' ? 'Photo' : row.message_type === 'voice' ? 'Voice note' : ''),
            time: new Date(row.created_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
            mine: currentUserId != null && row.sender_id === currentUserId,
            messageType: row.message_type,
            mediaUrl: row.media_url ?? null,
            voiceDurationSeconds: row.voice_duration_seconds ?? null,
            paymentRequest: row.message_type === 'payment_request' ? mapPaymentRequest(row.content) : null,
          })),
        );
      } catch (e) {
      console.error('Chat message load error', e);
      setMessages([]);
    }
  }, [bookingId, currentUserId]);

  useEffect(() => {
    void loadMessages();
  }, [loadMessages]);

  useEffect(() => {
    if (!bookingId) return undefined;
    const channel = subscribeToBookingChatMessages(bookingId, () => {
      void loadMessages();
    });
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, loadMessages]);

  const sendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed || !bookingId) return;
    if (!currentUserId) {
      Alert.alert('Sign in required', 'Please sign in again before sending a message.');
      return;
    }
    await hapticFeedback('light');
    setSendingMessage(true);
    try {
      await sendBookingChatMessage({
        bookingId,
        senderId: currentUserId,
        senderRole: 'customer',
        content: trimmed,
      });
      setInputText('');
      await loadMessages();
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e: any) {
      console.error('Send chat message error', e);
      Alert.alert('Message not sent', e?.message || 'Please try again.');
    } finally {
      setSendingMessage(false);
    }
  };

  const extractPaymentClientSecret = (data: any): string | null => {
    return (
      data?.clientSecret ??
      data?.client_secret ??
      data?.paymentIntentClientSecret ??
      data?.payment_intent_client_secret ??
      data?.paymentIntent?.clientSecret ??
      data?.paymentIntent?.client_secret ??
      data?.payment_intent?.client_secret ??
      null
    );
  };

  const handlePayPaymentRequest = useCallback(
    async (messageId: string) => {
      if (!bookingId || !currentUserId || !booking?.user_id || booking.user_id !== currentUserId) return;
      const message = messages.find((msg) => msg.id === messageId);
      if (!message?.paymentRequest || message.mine) return;
      if (message.paymentRequest.status !== 'pending') return;
      if (Platform.OS === 'web') {
        Alert.alert('Payment not available', 'Please use the mobile app to pay this request.');
        return;
      }
      if (!initPaymentSheet || !presentPaymentSheet) {
        Alert.alert('Payment not available', 'Stripe is not ready on this device.');
        return;
      }

      const request = message.paymentRequest;
      setPaymentProcessingMessageId(messageId);
      try {
        let clientSecret = request.paymentIntentClientSecret ?? null;
        if (!clientSecret) {
          const { data, error } = await supabase.functions.invoke('booking-extra-charge', {
            body: {
              action: 'create_payment_intent',
              bookingId,
              requestMessageId: messageId,
            },
          });
          if (error) throw error;
          clientSecret = extractPaymentClientSecret(data);
          if (!clientSecret) throw new Error('No payment secret returned.');
        }

        const { error: initErr } = await initPaymentSheet({
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'Wish a Wash',
          returnURL: 'waw://stripe-redirect',
          style: 'automatic',
        });
        if (initErr) throw initErr;

        const { error: presentErr } = await presentPaymentSheet();
        if (presentErr) {
          if (presentErr.code === 'Canceled') return;
          throw presentErr;
        }

        await loadMessages();
        setTimeout(() => {
          void loadMessages();
        }, 600);
      } catch (e: any) {
        console.error('[BookingChat] payment request pay failed', e);
        Alert.alert('Payment failed', e?.message || 'Please try again.');
      } finally {
        setPaymentProcessingMessageId(null);
      }
    },
    [booking?.user_id, bookingId, currentUserId, initPaymentSheet, loadMessages, messages, presentPaymentSheet]
  );

  const addPhotoMessage = async (imageUri?: string | null) => {
    if (!bookingId || !currentUserId) return;
    try {
      await sendBookingChatMessage({
        bookingId,
        senderId: currentUserId,
        senderRole: 'customer',
        content: '📷 Photo',
        mediaUrl: imageUri ?? null,
        messageType: imageUri ? 'image' : 'text',
      });
      await loadMessages();
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e: any) {
      console.error('Send photo message error', e);
      Alert.alert('Photo not sent', e?.message || 'Please try again.');
    }
  };

  const handleCall = async () => {
    await hapticFeedback('light');
    if (proPhone?.trim()) {
      const url = `tel:${proPhone.trim()}`;
      const can = await Linking.canOpenURL(url);
      if (can) Linking.openURL(url);
      else Alert.alert('Cannot call', 'This device cannot place phone calls.');
    } else {
      Alert.alert('No number', 'Phone number is not available for this contact.');
    }
  };

  const handleVoice = () => {
    hapticFeedback('light');
    Alert.alert('Voice message', 'Voice messages will be available in a future update.');
  };

  const handlePickImage = async () => {
    await hapticFeedback('light');
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow photo library access to send a photo.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      void addPhotoMessage(result.assets[0].uri);
      setOptionsExpanded(false);
    }
  };

  const handleTakePhoto = async () => {
    await hapticFeedback('light');
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow camera access to take a photo.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      void addPhotoMessage(result.assets[0].uri);
      setOptionsExpanded(false);
    }
  };

  const vehicleDisplay = booking?.vehicle_type || booking?.vehicle_info
    ? [booking.vehicle_type, booking.vehicle_info].filter(Boolean).join(' • ')
    : '—';
  const isBookingCustomer = Boolean(booking?.user_id && currentUserId && booking.user_id === currentUserId);

  const moneyGBP = (value: unknown) => {
    const n = Number(value);
    if (!Number.isFinite(n)) return '0.00';
    return n.toFixed(2);
  };

  const renderPaymentRequestCard = (msg: Message) => {
    const request = msg.paymentRequest;
    const status: BookingPaymentRequestStatus = request?.status ?? 'pending';
    const amount = request?.amount ?? 0;
    const currency = String(request?.currency || 'gbp').toUpperCase();
    const canPay = status === 'pending' && !msg.mine && isBookingCustomer && paymentProcessingMessageId !== msg.id;
    const platformFee = request?.platformFee ?? null;
    const valeterShare = request?.valeterShare ?? (platformFee != null ? Math.max(0, amount - platformFee) : null);
    const statusLabel = status === 'paid' ? 'Paid' : status === 'failed' ? 'Failed' : 'Pending';
    const statusColor = status === 'paid' ? '#34D399' : status === 'failed' ? '#F87171' : SKY;

    return (
      <View style={[styles.paymentCard, msg.mine ? styles.paymentCardMine : styles.paymentCardPro]}>
        <View style={styles.paymentCardHeader}>
          <View style={[styles.paymentCardIcon, { backgroundColor: `${statusColor}22`, borderColor: `${statusColor}44` }]}>
            <Ionicons name="card-outline" size={18} color={statusColor} />
          </View>
          <View style={styles.paymentCardHeaderText}>
            <Text style={styles.paymentCardTitle}>Payment request</Text>
            <Text style={[styles.paymentCardStatus, { color: statusColor }]}>{statusLabel}</Text>
          </View>
        </View>

        <Text style={styles.paymentCardAmount}>
          {currency === 'GBP' ? '£' : `${currency} `}{moneyGBP(amount)}
        </Text>
        <Text style={styles.paymentCardReason}>{request?.reason || 'Additional charge'}</Text>
        {request?.note ? <Text style={styles.paymentCardNote}>{request.note}</Text> : null}

        <View style={styles.paymentCardBreakdown}>
          <View style={styles.paymentCardBreakdownRow}>
            <Text style={styles.paymentCardBreakdownLabel}>Platform fee</Text>
            <Text style={styles.paymentCardBreakdownValue}>£{moneyGBP(platformFee ?? 0)}</Text>
          </View>
          <View style={styles.paymentCardBreakdownRow}>
            <Text style={styles.paymentCardBreakdownLabel}>Valeter share</Text>
            <Text style={styles.paymentCardBreakdownValue}>£{moneyGBP(valeterShare ?? 0)}</Text>
          </View>
        </View>

        {status === 'failed' ? (
          <Text style={[styles.paymentCardHint, { color: '#FCA5A5' }]}>This request failed. Please wait for a new one.</Text>
        ) : null}
        {status === 'paid' ? (
          <Text style={[styles.paymentCardHint, { color: '#86EFAC' }]}>Payment completed</Text>
        ) : null}

        {canPay ? (
          <TouchableOpacity
            style={styles.paymentCardButton}
            onPress={() => void handlePayPaymentRequest(msg.id)}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.paymentCardButtonGradient}>
              <Text style={styles.paymentCardButtonText}>
                {paymentProcessingMessageId === msg.id ? 'Preparing…' : 'Pay now'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        ) : null}
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={[styles.loadingWrap, { paddingTop: insets.top + 18 }]}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading chat…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={[styles.emptyWrap, { paddingTop: insets.top + 18 }]}>
          <Text style={styles.emptyText}>Booking not found.</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.8}>
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.backBtnGradient}>
              <Text style={styles.backBtnText}>Back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const isHub = Boolean(booking.location_id && !booking.valeter_id);
  const serviceDisplay = getServiceDisplayName(booking.service_type, booking.service_name);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <KeyboardAvoidingView
        style={[styles.keyboardView, { paddingTop: insets.top + 14 }]}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingTop: 20, paddingBottom: 140 + (insets?.bottom ?? 0) }]}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
        >
          <View style={styles.messagesBlock}>
            {messages.map((msg) => (
              <View
                key={msg.id}
                style={[styles.messageRow, msg.mine ? styles.messageRowCustomer : styles.messageRowPro]}
              >
                {msg.messageType === 'payment_request' ? (
                  <>
                    {!msg.mine ? (
                      <View style={[styles.msgAvatar, styles.hubCameraAvatar]}>
                        <Ionicons name="card-outline" size={18} color={SKY} />
                      </View>
                    ) : (
                      <View style={styles.customerAvatarWrap}>
                        <Image source={CAR_IMAGE} style={styles.customerAvatar} resizeMode="contain" />
                      </View>
                    )}
                    {renderPaymentRequestCard(msg)}
                  </>
                ) : msg.mine ? (
                  <>
                    <View style={[styles.bubble, styles.bubbleCustomer]}>
                      {msg.messageType === 'image' && msg.mediaUrl ? (
                        <Image source={{ uri: msg.mediaUrl }} style={styles.messageImage} />
                      ) : null}
                      {msg.messageType === 'voice' ? (
                        <View style={styles.voiceNotePill}>
                          <Ionicons name="mic" size={14} color={SKY} />
                          <Text style={styles.voiceNoteText}>
                            Voice note{msg.voiceDurationSeconds ? ` · ${msg.voiceDurationSeconds}s` : ''}
                          </Text>
                        </View>
                      ) : null}
                      <Text style={styles.bubbleText}>{msg.content}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                    <View style={styles.customerAvatarWrap}>
                      <Image source={CAR_IMAGE} style={styles.customerAvatar} resizeMode="contain" />
                    </View>
                  </>
                ) : (
                  <>
                    {isHub ? (
                      <View style={[styles.msgAvatar, styles.hubCameraAvatar]}>
                        <Ionicons name="camera-outline" size={18} color={SKY} />
                      </View>
                    ) : proPhoto ? (
                      <Image source={{ uri: proPhoto }} style={styles.msgAvatar} />
                    ) : (
                      <Image source={VALETER_IMAGE} style={styles.msgAvatar} resizeMode="cover" />
                    )}
                    <View style={[styles.bubble, styles.bubblePro]}>
                      {msg.messageType === 'image' && msg.mediaUrl ? (
                        <Image source={{ uri: msg.mediaUrl }} style={styles.messageImage} />
                      ) : null}
                      {msg.messageType === 'voice' ? (
                        <View style={styles.voiceNotePill}>
                          <Ionicons name="mic" size={14} color={SKY} />
                          <Text style={styles.voiceNoteText}>
                            Voice note{msg.voiceDurationSeconds ? ` · ${msg.voiceDurationSeconds}s` : ''}
                          </Text>
                        </View>
                      ) : null}
                      <Text style={styles.bubbleText}>{msg.content}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                  </>
                )}
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Input bar attached to keypad when keyboard is open */}
        <View style={[styles.inputBottomSheet, { paddingBottom: keyboardVisible ? 4 : Math.max(insets?.bottom ?? 0, 10) + 10 }]}>
          {/* Expanded options: Photo, Voice, Call as floating icons */}
          {optionsExpanded && (
            <View style={styles.floatingOptionsRow}>
              <TouchableOpacity
                onPress={handlePickImage}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="image-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleVoice}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="mic-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleCall}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="call-outline" size={24} color={SKY} />
              </TouchableOpacity>
            </View>
          )}
          {/* Main row: attach, input pill, options toggle, send */}
          <View style={styles.floatingInputRow}>
            <TouchableOpacity
              onPress={handleTakePhoto}
              style={styles.floatingIconBtn}
              activeOpacity={0.8}
            >
              <Ionicons name="camera-outline" size={24} color={SKY} />
            </TouchableOpacity>
            <TextInput
              style={styles.floatingInput}
              placeholder="Type a message…"
              placeholderTextColor="#64748B"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable
            />
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOptionsExpanded((v) => !v); }}
              style={[styles.floatingIconBtn, optionsExpanded && styles.floatingIconBtnActive]}
              activeOpacity={0.8}
            >
              <Ionicons name="ellipsis-horizontal" size={24} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={sendMessage}
              style={[
                styles.floatingSendBtn,
                (!inputText.trim() || sendingMessage) && styles.floatingSendBtnDisabled,
              ]}
              activeOpacity={0.85}
              disabled={!inputText.trim() || sendingMessage}
            >
              <Ionicons name="send" size={20} color={inputText.trim() && !sendingMessage ? '#FFFFFF' : '#64748B'} />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>

      {/* Profile card modal — hub or valeter, only when user taps header */}
      <Modal
        visible={profileModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setProfileModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setProfileModalVisible(false)}>
          <Pressable style={styles.modalCard} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={[SKY + '15', 'rgba(15,23,42,0.95)']} style={StyleSheet.absoluteFill} />
            <View style={[styles.modalStroke, { borderColor: SKY + '35' }]} />
            <View style={styles.modalCloseRow}>
              <Text style={styles.modalTitle}>{isHub ? proName : 'Valeter profile'}</Text>
              <TouchableOpacity
                onPress={() => { hapticFeedback('light'); setProfileModalVisible(false); }}
                style={styles.modalCloseBtn}
                hitSlop={12}
              >
                <Ionicons name="close" size={24} color="#F1F5F9" />
              </TouchableOpacity>
            </View>
            {isHub ? (
              <>
                <View style={styles.modalAvatarSection}>
                  <View style={[styles.modalAvatarHub, styles.hubCameraAvatarLarge]}>
                    <Ionicons name="camera-outline" size={40} color={SKY} />
                  </View>
                  <Text style={styles.modalName}>{proName}</Text>
                </View>
                {booking?.location_address ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Address</Text>
                    <Text style={styles.modalSectionBody}>{booking.location_address}</Text>
                  </View>
                ) : null}
                {serviceDisplay ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Service</Text>
                    <Text style={styles.modalSectionBody}>{serviceDisplay}</Text>
                  </View>
                ) : null}
                {proPhone ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Phone</Text>
                    <TouchableOpacity onPress={handleCall}>
                      <Text style={[styles.modalSectionBody, { color: SKY }]}>{proPhone}</Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </>
            ) : (
              <>
                <View style={styles.modalAvatarSection}>
                  {proPhoto ? (
                    <Image source={{ uri: proPhoto }} style={styles.modalAvatar} />
                  ) : (
                    <Image source={VALETER_IMAGE} style={styles.modalAvatar} resizeMode="cover" />
                  )}
                  <Text style={styles.modalName}>{formatDisplayName(proName)}</Text>
                  <View style={styles.modalRatingRow}>
                    <Ionicons name="star" size={16} color="#FBBF24" />
                    <Text style={styles.modalRatingText}>{rating > 0 ? rating.toFixed(1) : '—'}</Text>
                    <Text style={styles.modalMetaText}> · {jobsCompleted} jobs</Text>
                    <Text style={styles.modalMetaText}> · {reviewCount} reviews</Text>
                  </View>
                </View>
                {valeterBio ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>This wash</Text>
                    <Text style={styles.modalSectionBody}>{valeterBio}</Text>
                  </View>
                ) : null}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Valeter vehicle</Text>
                  <Text style={styles.modalSectionBody}>{valeterVehicle || '—'}</Text>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: { color: SKY, fontSize: 15 },
  emptyWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: { color: '#94A3B8', fontSize: 16, marginBottom: 20 },
  keyboardView: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  chatHeaderPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 24,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    maxWidth: '100%',
  },
  chatHeaderPillAvatarWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.6)',
  },
  hubCameraAvatar: {
    backgroundColor: 'rgba(30,41,59,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  hubCameraAvatarLarge: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(30,41,59,0.95)',
  },
  chatHeaderPillAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  chatHeaderPillName: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    minWidth: 0,
  },
  chatHeaderCard: {
    flex: 1,
    minWidth: 0,
  },
  chatHubCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    backgroundColor: CARD_BG,
    borderWidth: 1,
    borderColor: CARD_BORDER,
  },
  hubHero: {
    height: 72,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  typeBadgeHub: {
    position: 'absolute',
    top: 8,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.8)',
    zIndex: 2,
  },
  typeBadgeText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  hubHeroImage: { width: 64, height: 48, zIndex: 1 },
  chatHubCardBody: { padding: 12, paddingTop: 10 },
  chatCardTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '700', marginBottom: 4 },
  chatAddressRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  chatAddressText: { color: TEXT_MUTED, fontSize: 13, flex: 1 },
  chatServiceSub: { color: TEXT_MUTED, fontSize: 13 },
  chatValeterCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    backgroundColor: CARD_BG,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    padding: 12,
  },
  valeterCardMain: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  valeterAvatarWrap: { position: 'relative' },
  typeBadgeValeter: {
    position: 'absolute',
    top: -4,
    left: -4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    backgroundColor: SKY,
    zIndex: 2,
  },
  typeBadgeTextSmall: { color: '#fff', fontSize: 10, fontWeight: '600' },
  valeterAvatar: { width: 56, height: 56, borderRadius: 12 },
  valeterCardBody: { flex: 1, minWidth: 0 },
  valeterStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 4, marginBottom: 4 },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statItemText: { color: TEXT_MUTED, fontSize: 12 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
  },
  modalStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 18,
  },
  modalCloseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 8,
  },
  modalTitle: { color: '#F1F5F9', fontSize: 18, fontWeight: '700' },
  modalCloseBtn: { padding: 4 },
  modalAvatarSection: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  modalAvatar: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY + '50' },
  modalAvatarHub: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY + '50' },
  modalAvatarPlaceholder: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: SKY + '20',
    borderWidth: 2,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalName: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', marginTop: 12 },
  modalRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 4,
  },
  modalRatingText: { color: '#FBBF24', fontSize: 15, fontWeight: '700' },
  modalMetaText: { color: '#94A3B8', fontSize: 13 },
  modalSection: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  modalSectionTitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  modalSectionBody: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
  },
  headerProfileWrap: { paddingHorizontal: 16 },
  proCardAsHeader: { padding: 14, borderRadius: 14 },
  proCardInner: { flexDirection: 'row', alignItems: 'center' },
  proAvatarWrap: { marginRight: 12 },
  proAvatar: { width: 48, height: 48, borderRadius: 24 },
  proAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  proInfo: { flex: 1, minWidth: 0 },
  proName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  proStatsRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 },
  proStat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  proStatText: { color: '#94A3B8', fontSize: 12 },
  proStatDot: { color: '#64748B', fontSize: 12 },
  vehicleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  vehicleIcon: { width: 18, height: 18 },
  vehicleText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addressText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  chatHeaderOuter: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  chatHeaderBar: {
    flexDirection: 'row',
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: SKY + '20',
    minHeight: 72,
    position: 'relative',
  },
  chatHeaderBack: {
    width: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
  },
  chatHeaderInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 14,
    paddingLeft: 18,
    flex: 1,
  },
  chatHeaderAvatarWrap: { marginRight: 12 },
  chatHeaderAvatar: {
    width: 44,
    height: 44,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: SKY + '40',
  },
  chatHeaderAvatarPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 18,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    borderColor: SKY + '35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderInfo: { flex: 1, minWidth: 0 },
  chatHeaderName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  chatHeaderService: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  chatHeaderMeta: { gap: 2 },
  chatHeaderMetaText: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  messagesBlock: { gap: 16 },
  messageRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  messageRowPro: { justifyContent: 'flex-start' },
  messageRowCustomer: { justifyContent: 'flex-end' },
  msgAvatar: { width: 28, height: 28, borderRadius: 14 },
  msgAvatarPlaceholder: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bubble: {
    maxWidth: '80%',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  bubblePro: {
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderBottomLeftRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bubbleCustomer: {
    backgroundColor: SKY + '30',
    borderBottomRightRadius: 6,
    borderWidth: 1,
    borderColor: SKY + '45',
  },
  bubbleText: {
    color: '#F1F5F9',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  bubbleTime: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    marginTop: 6,
    fontWeight: '500',
  },
  paymentCard: {
    maxWidth: '82%',
    padding: 14,
    borderRadius: 20,
    borderWidth: 1,
    gap: 10,
    backgroundColor: 'rgba(15,23,42,0.9)',
  },
  paymentCardPro: {
    borderBottomLeftRadius: 6,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  paymentCardMine: {
    borderBottomRightRadius: 6,
    borderColor: 'rgba(148,163,184,0.25)',
  },
  paymentCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  paymentCardIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentCardHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  paymentCardTitle: {
    color: '#F8FAFC',
    fontSize: 14,
    fontWeight: '800',
  },
  paymentCardStatus: {
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    marginTop: 2,
  },
  paymentCardAmount: {
    color: '#F8FAFC',
    fontSize: 24,
    fontWeight: '900',
  },
  paymentCardReason: {
    color: '#E2E8F0',
    fontSize: 15,
    fontWeight: '700',
  },
  paymentCardNote: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  paymentCardBreakdown: {
    gap: 6,
    paddingTop: 2,
  },
  paymentCardBreakdownRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  paymentCardBreakdownLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  paymentCardBreakdownValue: {
    color: '#F8FAFC',
    fontSize: 12,
    fontWeight: '800',
  },
  paymentCardHint: {
    fontSize: 12,
    fontWeight: '700',
  },
  paymentCardButton: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  paymentCardButtonGradient: {
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paymentCardButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  messageImage: {
    width: 220,
    height: 180,
    borderRadius: 14,
    marginBottom: 10,
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  voiceNotePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.18)',
    marginBottom: 8,
  },
  voiceNoteText: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '600',
  },
  customerAvatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '20',
    borderWidth: 1,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerAvatar: { width: 16, height: 16 },
  inputWrap: {
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.12)',
    overflow: 'hidden',
    position: 'relative',
  },
  inputWrapFloating: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
    backgroundColor: 'transparent',
  },
  inputBottomSheet: {
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 16,
  },
  floatingOptionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 10,
    marginBottom: 10,
  },
  floatingIconBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderWidth: 1,
    borderColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingIconBtnActive: {
    backgroundColor: SKY + '30',
    borderColor: SKY + '50',
  },
  floatingInputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  floatingInput: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.5)',
    shadowOpacity: 0,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  input: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '22',
  },
  sendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.4)',
  },
  backBtn: { borderRadius: 14, overflow: 'hidden' },
  backBtnGradient: {
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  backBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
