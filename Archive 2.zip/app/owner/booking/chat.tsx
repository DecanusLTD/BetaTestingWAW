import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
  Pressable,
  Alert,
  Linking,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { colors } from '../../../src/constants/colors';
import { supabase } from '../../../src/lib/supabase';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';
import { CAR_IMAGE, VALETER_IMAGE, CARWASH_IMAGE } from '../../assets/assetExports';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';

const SKY = colors.SKY;
const CARD_RADIUS = 16;
const CARD_BG = 'rgba(30,41,59,0.6)';
const CARD_BORDER = 'rgba(148,163,184,0.2)';
const TEXT_MUTED = '#94A3B8';

type BookingRow = {
  id: string;
  service_type: string;
  service_name?: string | null;
  valeter_id?: string | null;
  location_id?: string | null;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  location_address?: string | null;
};

type Message = {
  id: string;
  sender: 'customer' | 'pro';
  text: string;
  time: string;
};

export default function BookingChat() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const headerMarginH = adaptive.headerMarginH;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [proName, setProName] = useState<string>('Valeter');
  const [proPhoto, setProPhoto] = useState<string | null>(null);
  const [rating, setRating] = useState<number>(0);
  const [jobsCompleted, setJobsCompleted] = useState<number>(0);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [optionsExpanded, setOptionsExpanded] = useState(false);
  const [valeterVehicle, setValeterVehicle] = useState<string | null>(null);
  const [valeterBio, setValeterBio] = useState<string | null>(null);
  const [proPhone, setProPhone] = useState<string | null>(null);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    const show = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow', () => setKeyboardVisible(true));
    const hide = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', () => setKeyboardVisible(false));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    const load = async () => {
      try {
        const { data: bookingData, error: bookingError } = await supabase
          .from('bookings')
          .select('id, service_type, service_name, valeter_id, location_id, vehicle_type, vehicle_info, location_address')
          .eq('id', bookingId)
          .single();

        if (bookingError || !bookingData) {
          setBooking(null);
          setLoading(false);
          return;
        }

        const row = bookingData as BookingRow;
        setBooking(row);

        if (row.valeter_id) {
          const [profile, stats] = await Promise.all([
            fetchProfileById(row.valeter_id),
            ValeterStatsService.getValeterStats(row.valeter_id),
          ]);
          setProName(profile?.full_name || 'Valeter');
          setProPhone(profile?.phone ?? null);
          setRating(stats.averageRating);
          setJobsCompleted(stats.totalJobs);
          setReviewCount(stats.customerReviews);

          const { data: vp } = await supabase
            .from('valeter_profiles')
            .select('profile_photo_url')
            .eq('user_id', row.valeter_id)
            .maybeSingle();
          if ((vp as any)?.profile_photo_url) setProPhoto((vp as any).profile_photo_url);
          else {
            const { data: prof } = await supabase.from('profiles').select('profile_picture').eq('id', row.valeter_id).maybeSingle();
            if ((prof as any)?.profile_picture) setProPhoto((prof as any).profile_picture);
          }
        } else if (row.location_id) {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name, phone')
            .eq('id', row.location_id)
            .maybeSingle();
          const hubRow = hub as { name?: string; phone?: string } | null;
          setProName(hubRow?.name || 'Wash Hub');
          setProPhone(hubRow?.phone ?? null);
        } else {
          setProName('Valeter');
        }

        setValeterBio(
          [getServiceDisplayName(row.service_type, row.service_name), row.location_address].filter(Boolean).join(' · ') || null
        );
        // Messages load from backend when chat/messages API is available; start empty
        setMessages([]);
      } catch (e) {
        console.error('Chat load error', e);
        setBooking(null);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [bookingId]);

  const sendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed) return;
    await hapticFeedback('light');
    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'customer',
      text: trimmed,
      time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const addPhotoMessage = () => {
    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'customer',
      text: '📷 Photo',
      time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, newMsg]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const handleCall = async () => {
    await hapticFeedback('light');
    if (proPhone?.trim()) {
      const url = `tel:${proPhone.trim()}`;
      const can = await Linking.canOpenURL(url);
      if (can) Linking.openURL(url);
      else Alert.alert('Cannot call', 'This device cannot place phone calls.');
    } else {
      Alert.alert('No number', 'Phone number is not available for this contact.');
    }
  };

  const handleVoice = () => {
    hapticFeedback('light');
    Alert.alert('Voice message', 'Voice messages will be available in a future update.');
  };

  const handlePickImage = async () => {
    await hapticFeedback('light');
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow photo library access to send a photo.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      addPhotoMessage();
      setOptionsExpanded(false);
    }
  };

  const handleTakePhoto = async () => {
    await hapticFeedback('light');
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow camera access to take a photo.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      addPhotoMessage();
      setOptionsExpanded(false);
    }
  };

  const vehicleDisplay = booking?.vehicle_type || booking?.vehicle_info
    ? [booking.vehicle_type, booking.vehicle_info].filter(Boolean).join(' • ')
    : '—';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.loadingWrap}>
          <TouchableOpacity onPress={() => router.back()} style={{ padding: 16 }} activeOpacity={0.8}>
            <Ionicons name="chevron-back" size={24} color={SKY} />
          </TouchableOpacity>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading chat…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.emptyWrap}>
          <TouchableOpacity onPress={() => router.back()} style={styles.chatBackBtn} activeOpacity={0.8}>
            <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.emptyText}>Booking not found.</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.8}>
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.backBtnGradient}>
              <Text style={styles.backBtnText}>Back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const isHub = Boolean(booking.location_id && !booking.valeter_id);
  const serviceDisplay = getServiceDisplayName(booking.service_type, booking.service_name);

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {/* Top area: back left, compact avatar + name right — tap to open profile card */}
      <View style={[styles.chatTopWrap, { paddingTop: (insets?.top ?? 0) + 8, paddingHorizontal: headerMarginH }]}>
        <TouchableOpacity
          onPress={() => { hapticFeedback('light'); router.back(); }}
          style={styles.chatBackBtn}
          hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
        >
          <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
        </TouchableOpacity>

        <Pressable
          onPress={() => { hapticFeedback('light'); setProfileModalVisible(true); }}
          style={styles.chatHeaderPill}
        >
          <View style={styles.chatHeaderPillAvatarWrap}>
            {isHub && <Image source={CARWASH_IMAGE} style={styles.chatHeaderPillAvatar} resizeMode="contain" />}
            {!isHub && proPhoto && <Image source={{ uri: proPhoto }} style={styles.chatHeaderPillAvatar} resizeMode="cover" />}
            {!isHub && !proPhoto && <Image source={VALETER_IMAGE} style={styles.chatHeaderPillAvatar} resizeMode="cover" />}
          </View>
          <Text style={styles.chatHeaderPillName} numberOfLines={1}>
            {isHub ? proName : formatDisplayName(proName)}
          </Text>
          <Ionicons name="chevron-forward" size={16} color="rgba(255,255,255,0.5)" />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: 140 + (insets?.bottom ?? 0) }]}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
        >
          <View style={styles.messagesBlock}>
            {messages.map((msg) => (
              <View
                key={msg.id}
                style={[styles.messageRow, msg.sender === 'customer' ? styles.messageRowCustomer : styles.messageRowPro]}
              >
                {msg.sender === 'pro' ? (
                  <>
                    {proPhoto ? (
                      <Image source={{ uri: proPhoto }} style={styles.msgAvatar} />
                    ) : (
                      <Image source={VALETER_IMAGE} style={styles.msgAvatar} resizeMode="cover" />
                    )}
                    <View style={[styles.bubble, styles.bubblePro]}>
                      <Text style={styles.bubbleText}>{msg.text}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                  </>
                ) : (
                  <>
                    <View style={[styles.bubble, styles.bubbleCustomer]}>
                      <Text style={styles.bubbleText}>{msg.text}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                    <View style={styles.customerAvatarWrap}>
                      <Image source={CAR_IMAGE} style={styles.customerAvatar} resizeMode="contain" />
                    </View>
                  </>
                )}
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Input bar attached to keypad when keyboard is open */}
        <View style={[styles.inputBottomSheet, { paddingBottom: keyboardVisible ? 4 : Math.max(insets?.bottom ?? 0, 10) + 10 }]}>
          {/* Expanded options: Photo, Voice, Call as floating icons */}
          {optionsExpanded && (
            <View style={styles.floatingOptionsRow}>
              <TouchableOpacity
                onPress={handlePickImage}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="image-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleVoice}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="mic-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleCall}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="call-outline" size={24} color={SKY} />
              </TouchableOpacity>
            </View>
          )}
          {/* Main row: attach, input pill, options toggle, send */}
          <View style={styles.floatingInputRow}>
            <TouchableOpacity
              onPress={handleTakePhoto}
              style={styles.floatingIconBtn}
              activeOpacity={0.8}
            >
              <Ionicons name="camera-outline" size={24} color={SKY} />
            </TouchableOpacity>
            <TextInput
              style={styles.floatingInput}
              placeholder="Type a message…"
              placeholderTextColor="#64748B"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable
            />
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOptionsExpanded((v) => !v); }}
              style={[styles.floatingIconBtn, optionsExpanded && styles.floatingIconBtnActive]}
              activeOpacity={0.8}
            >
              <Ionicons name="ellipsis-horizontal" size={24} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={sendMessage}
              style={[styles.floatingSendBtn, !inputText.trim() && styles.floatingSendBtnDisabled]}
              activeOpacity={0.85}
              disabled={!inputText.trim()}
            >
              <Ionicons name="send" size={20} color={inputText.trim() ? '#FFFFFF' : '#64748B'} />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>

      {/* Profile card modal — hub or valeter, only when user taps header */}
      <Modal
        visible={profileModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setProfileModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setProfileModalVisible(false)}>
          <Pressable style={styles.modalCard} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={[SKY + '15', 'rgba(15,23,42,0.95)']} style={StyleSheet.absoluteFill} />
            <View style={[styles.modalStroke, { borderColor: SKY + '35' }]} />
            <View style={styles.modalCloseRow}>
              <Text style={styles.modalTitle}>{isHub ? proName : 'Valeter profile'}</Text>
              <TouchableOpacity
                onPress={() => { hapticFeedback('light'); setProfileModalVisible(false); }}
                style={styles.modalCloseBtn}
                hitSlop={12}
              >
                <Ionicons name="close" size={24} color="#F1F5F9" />
              </TouchableOpacity>
            </View>
            {isHub ? (
              <>
                <View style={styles.modalAvatarSection}>
                  <Image source={CARWASH_IMAGE} style={styles.modalAvatarHub} resizeMode="contain" />
                  <Text style={styles.modalName}>{proName}</Text>
                </View>
                {booking?.location_address ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Address</Text>
                    <Text style={styles.modalSectionBody}>{booking.location_address}</Text>
                  </View>
                ) : null}
                {serviceDisplay ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Service</Text>
                    <Text style={styles.modalSectionBody}>{serviceDisplay}</Text>
                  </View>
                ) : null}
                {proPhone ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>Phone</Text>
                    <TouchableOpacity onPress={handleCall}>
                      <Text style={[styles.modalSectionBody, { color: SKY }]}>{proPhone}</Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </>
            ) : (
              <>
                <View style={styles.modalAvatarSection}>
                  {proPhoto ? (
                    <Image source={{ uri: proPhoto }} style={styles.modalAvatar} />
                  ) : (
                    <Image source={VALETER_IMAGE} style={styles.modalAvatar} resizeMode="cover" />
                  )}
                  <Text style={styles.modalName}>{formatDisplayName(proName)}</Text>
                  <View style={styles.modalRatingRow}>
                    <Ionicons name="star" size={16} color="#FBBF24" />
                    <Text style={styles.modalRatingText}>{rating > 0 ? rating.toFixed(1) : '—'}</Text>
                    <Text style={styles.modalMetaText}> · {jobsCompleted} jobs</Text>
                    <Text style={styles.modalMetaText}> · {reviewCount} reviews</Text>
                  </View>
                </View>
                {valeterBio ? (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalSectionTitle}>This wash</Text>
                    <Text style={styles.modalSectionBody}>{valeterBio}</Text>
                  </View>
                ) : null}
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Valeter vehicle</Text>
                  <Text style={styles.modalSectionBody}>{valeterVehicle || '—'}</Text>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: { color: SKY, fontSize: 15 },
  emptyWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: { color: '#94A3B8', fontSize: 16, marginBottom: 20 },
  keyboardView: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  chatTopWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  chatBackBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15,23,42,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 24,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    maxWidth: '100%',
  },
  chatHeaderPillAvatarWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.6)',
  },
  chatHeaderPillAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  chatHeaderPillName: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 15,
    fontWeight: '700',
    minWidth: 0,
  },
  chatHeaderCard: {
    flex: 1,
    minWidth: 0,
  },
  chatHubCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    backgroundColor: CARD_BG,
    borderWidth: 1,
    borderColor: CARD_BORDER,
  },
  hubHero: {
    height: 72,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  typeBadgeHub: {
    position: 'absolute',
    top: 8,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(15,23,42,0.8)',
    zIndex: 2,
  },
  typeBadgeText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  hubHeroImage: { width: 64, height: 48, zIndex: 1 },
  chatHubCardBody: { padding: 12, paddingTop: 10 },
  chatCardTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: '700', marginBottom: 4 },
  chatAddressRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  chatAddressText: { color: TEXT_MUTED, fontSize: 13, flex: 1 },
  chatServiceSub: { color: TEXT_MUTED, fontSize: 13 },
  chatValeterCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    backgroundColor: CARD_BG,
    borderWidth: 1,
    borderColor: CARD_BORDER,
    padding: 12,
  },
  valeterCardMain: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  valeterAvatarWrap: { position: 'relative' },
  typeBadgeValeter: {
    position: 'absolute',
    top: -4,
    left: -4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    backgroundColor: SKY,
    zIndex: 2,
  },
  typeBadgeTextSmall: { color: '#fff', fontSize: 10, fontWeight: '600' },
  valeterAvatar: { width: 56, height: 56, borderRadius: 12 },
  valeterCardBody: { flex: 1, minWidth: 0 },
  valeterStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 4, marginBottom: 4 },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statItemText: { color: TEXT_MUTED, fontSize: 12 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
  },
  modalStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 18,
  },
  modalCloseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 8,
  },
  modalTitle: { color: '#F1F5F9', fontSize: 18, fontWeight: '700' },
  modalCloseBtn: { padding: 4 },
  modalAvatarSection: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  modalAvatar: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY + '50' },
  modalAvatarHub: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY + '50' },
  modalAvatarPlaceholder: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: SKY + '20',
    borderWidth: 2,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalName: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', marginTop: 12 },
  modalRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 4,
  },
  modalRatingText: { color: '#FBBF24', fontSize: 15, fontWeight: '700' },
  modalMetaText: { color: '#94A3B8', fontSize: 13 },
  modalSection: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  modalSectionTitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  modalSectionBody: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
  },
  headerProfileWrap: { paddingHorizontal: 16 },
  proCardAsHeader: { padding: 14, borderRadius: 14 },
  proCardInner: { flexDirection: 'row', alignItems: 'center' },
  proAvatarWrap: { marginRight: 12 },
  proAvatar: { width: 48, height: 48, borderRadius: 24 },
  proAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  proInfo: { flex: 1, minWidth: 0 },
  proName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  proStatsRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 },
  proStat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  proStatText: { color: '#94A3B8', fontSize: 12 },
  proStatDot: { color: '#64748B', fontSize: 12 },
  vehicleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  vehicleIcon: { width: 18, height: 18 },
  vehicleText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addressText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  chatHeaderOuter: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  chatHeaderBar: {
    flexDirection: 'row',
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: SKY + '20',
    minHeight: 72,
    position: 'relative',
  },
  chatHeaderBack: {
    width: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
  },
  chatHeaderInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 14,
    paddingLeft: 18,
    flex: 1,
  },
  chatHeaderAvatarWrap: { marginRight: 12 },
  chatHeaderAvatar: {
    width: 44,
    height: 44,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: SKY + '40',
  },
  chatHeaderAvatarPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 18,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    borderColor: SKY + '35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderInfo: { flex: 1, minWidth: 0 },
  chatHeaderName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  chatHeaderService: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  chatHeaderMeta: { gap: 2 },
  chatHeaderMetaText: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  messagesBlock: { gap: 16 },
  messageRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  messageRowPro: { justifyContent: 'flex-start' },
  messageRowCustomer: { justifyContent: 'flex-end' },
  msgAvatar: { width: 28, height: 28, borderRadius: 14 },
  msgAvatarPlaceholder: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bubble: {
    maxWidth: '80%',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  bubblePro: {
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderBottomLeftRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bubbleCustomer: {
    backgroundColor: SKY + '30',
    borderBottomRightRadius: 6,
    borderWidth: 1,
    borderColor: SKY + '45',
  },
  bubbleText: {
    color: '#F1F5F9',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  bubbleTime: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    marginTop: 6,
    fontWeight: '500',
  },
  customerAvatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '20',
    borderWidth: 1,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerAvatar: { width: 16, height: 16 },
  inputWrap: {
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.12)',
    overflow: 'hidden',
    position: 'relative',
  },
  inputWrapFloating: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
    backgroundColor: 'transparent',
  },
  inputBottomSheet: {
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 16,
  },
  floatingOptionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 10,
    marginBottom: 10,
  },
  floatingIconBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderWidth: 1,
    borderColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingIconBtnActive: {
    backgroundColor: SKY + '30',
    borderColor: SKY + '50',
  },
  floatingInputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  floatingInput: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.5)',
    shadowOpacity: 0,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  input: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '22',
  },
  sendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.4)',
  },
  backBtn: { borderRadius: 14, overflow: 'hidden' },
  backBtnGradient: {
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  backBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
