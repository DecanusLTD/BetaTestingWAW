import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function DetailingVehicleSelection() {
  const { user } = useAuth();
    const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/detailing/location',
      params: { vehicleId: selectedVehicle },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#4C1D95']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Select Vehicle" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Vehicle</Text>
            <Text style={styles.sectionSubtitle}>Select the vehicle for detailing service</Text>
            
            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="car-outline" size={48} color={PREMIUM_PURPLE} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <TouchableOpacity
                    onPress={() => router.push('/owner/settings/vehicle-management')}
                    style={styles.addVehicleButton}
                  >
                    <Text style={styles.addVehicleText}>Add Vehicle</Text>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ) : (
              <View style={styles.vehicleList}>
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <GlassCard
                      key={vehicle.id}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedVehicle(vehicle.id);
                      }}
                      style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                      borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.3)'}
                    >
                      <View style={styles.vehicleContent}>
                        <View style={styles.vehicleIconWrapper}>
                          <Ionicons name="car-sport" size={24} color={PREMIUM_PURPLE} />
                        </View>
                        <View style={styles.vehicleInfo}>
                          <Text style={styles.vehicleName}>
                            {vehicle.make} {vehicle.model}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {vehicle.color} • {vehicle.registration}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={styles.selectedCheck}>
                            <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
            )}
          </View>

          {selectedVehicle && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[PREMIUM_PURPLE, '#7C3AED']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    marginTop: 12,
    marginBottom: 20,
  },
  addVehicleButton: {
    backgroundColor: PREMIUM_PURPLE,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  vehicleList: {
    gap: 12,
  },
  vehicleCard: {
    padding: 16,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.4,
  },
  vehicleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  vehicleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleDetails: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
  },
  selectedCheck: {
    marginLeft: 'auto',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

