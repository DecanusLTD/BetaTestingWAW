import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import AISchedulingSuggestions from '../../../../src/components/booking/AISchedulingSuggestions';
import { supabase } from '../../../../src/lib/supabase';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { generateTimeSlots } from '../../../../src/utils/timeSlots';

const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const { width } = Dimensions.get('window');

export default function DetailingSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ serviceId?: string; vehicleId?: string; locationId?: string; latitude?: string; longitude?: string; address?: string; customerOffersWater?: string; customerOffersElectricity?: string; discountAmount?: string }>();
  const { serviceId, vehicleId, locationId, latitude, longitude, address, customerOffersWater, customerOffersElectricity, discountAmount } = params;
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(false);
  const timeSlots = useMemo(() => generateTimeSlots(), []);
  const service = detailingServiceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    if (!locationId) return;
    const loadHub = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address')
        .eq('id', locationId)
        .maybeSingle();
      if (!error && data) {
        setHub(data);
      }
      setLoading(false);
    };
    loadHub();
  }, [locationId]);

  const handleContinue = async () => {
    if (!selectedSlot || !serviceId || !vehicleId) return;
    await hapticFeedback('medium');
    
    // For "You Go to Them" (has locationId), use locationId
    // For "They Come to You" (has latitude/longitude), use coordinates
    if (locationId) {
      router.push({
        pathname: '/owner/booking/detailing/confirm',
        params: {
          serviceId,
          vehicleId,
          locationId,
          scheduledAt: selectedSlot,
        },
      });
    } else if (latitude && longitude && address) {
      router.push({
        pathname: '/owner/booking/detailing/confirm',
        params: {
          serviceId,
          vehicleId,
          latitude,
          longitude,
          address,
          scheduledAt: selectedSlot,
          customerOffersWater: customerOffersWater || 'false',
          customerOffersElectricity: customerOffersElectricity || 'false',
          discountAmount: discountAmount || '0',
        },
      });
    }
  };

  if (!serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[colors.BG, colors.premiumPurple]} style={StyleSheet.absoluteFill} />

      <AppHeader title="Schedule appointment" />

      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]} showsVerticalScrollIndicator={false}>
        {service && (
          <View style={styles.serviceSummary}>
            <View style={styles.serviceHeader}>
              <Ionicons name={service.icon as any} size={24} color={PREMIUM_PURPLE} />
              <Text style={styles.serviceName}>{service.name}</Text>
            </View>
            <Text style={styles.serviceDesc}>{service.desc}</Text>
            <View style={styles.serviceMeta}>
              <View style={styles.metaItem}>
                <Ionicons name="time-outline" size={14} color={PREMIUM_PURPLE} />
                <Text style={styles.metaText}>{service.dur}</Text>
              </View>
              <Text style={styles.servicePrice}>£{service.price}</Text>
            </View>
          </View>
        )}

        {locationId && hub && (
          <View style={styles.locationSummary}>
            <View style={styles.locationHeader}>
              <Ionicons name="location" size={20} color={PREMIUM_PURPLE} />
              <Text style={styles.locationLabel}>Location</Text>
            </View>
            <Text style={styles.locationAddress} numberOfLines={2}>{hub.name}</Text>
            {hub.address && <Text style={styles.locationAddress} numberOfLines={2}>{hub.address}</Text>}
          </View>
        )}

        {!locationId && address && (
          <View style={styles.locationSummary}>
            <View style={styles.locationHeader}>
              <Ionicons name="location" size={20} color={PREMIUM_PURPLE} />
              <Text style={styles.locationLabel}>Location</Text>
            </View>
            <Text style={styles.locationAddress} numberOfLines={2}>{address}</Text>
          </View>
        )}

        {/* AI Scheduling Suggestions */}
        {!locationId && latitude && longitude && (
          <AISchedulingSuggestions
            location={{ latitude: parseFloat(latitude), longitude: parseFloat(longitude) }}
            onSelectSuggestion={(date, timeSlot) => {
              // Find matching slot
              const matchingSlot = timeSlots.find(slot => {
                const slotDate = new Date(slot);
                const slotDateStr = slotDate.toISOString().split('T')[0];
                const slotTime = slotDate.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
                return slotDateStr === date && slotTime === timeSlot;
              });
              if (matchingSlot) {
                setSelectedSlot(matchingSlot);
              }
            }}
          />
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose appointment time</Text>
          <Text style={styles.sectionSubtitle}>Select your preferred time slot</Text>
          <View style={styles.slotGrid}>
            {timeSlots.map((slot) => {
              const date = new Date(slot);
              const isSelected = selectedSlot === slot;
              return (
                <TouchableOpacity
                  key={slot}
                  style={[styles.slotCard, isSelected && styles.slotCardSelected]}
                  onPress={() => setSelectedSlot(slot)}
                  activeOpacity={0.85}
                >
                  <Text style={styles.slotDay}>
                    {date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </Text>
                  <Text style={styles.slotTime}>
                    {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[
            styles.continueButton,
            (!selectedSlot) && { opacity: 0.5 },
          ]}
          disabled={!selectedSlot}
          onPress={handleContinue}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#0A1929" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollContent: {
    padding: 20,
    paddingBottom: 120,
    gap: 20,
  },
  serviceSummary: {
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    marginBottom: 10,
  },
  serviceMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    color: '#E5E7EB',
    fontSize: 13,
  },
  servicePrice: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 18,
  },
  locationSummary: {
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.15)',
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  locationLabel: {
    color: 'rgba(139,92,246,0.8)',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  locationAddress: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    marginBottom: 4,
  },
  slotGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  slotCard: {
    width: (width - 20 * 2 - 12) / 2,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    paddingVertical: 12,
    paddingHorizontal: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  slotCardSelected: {
    borderColor: PREMIUM_PURPLE,
    backgroundColor: 'rgba(139,92,246,0.12)',
  },
  slotDay: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  slotTime: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 2,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: '#0A1929',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  continueButton: {
    backgroundColor: PREMIUM_PURPLE,
    borderRadius: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});

