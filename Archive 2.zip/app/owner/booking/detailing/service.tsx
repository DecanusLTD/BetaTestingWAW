import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import { BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const DETAILING_YELLOW_DARK = colors.DETAILING_YELLOW_DARK;

export default function DetailingServiceSelection() {
    const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  
  const [selectedService, setSelectedService] = useState<string | null>(null);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
  };

  const handleContinue = async () => {
    if (!selectedService || !locationId || !vehicleId) return;
    await hapticFeedback('medium');
    
    router.push({
      pathname: '/owner/booking/detailing/schedule',
      params: {
        serviceId: selectedService,
        vehicleId,
        locationId,
      },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader title="Select Detailing Service" showBack onBack={() => { hapticFeedback('light'); router.back(); }} primaryColor={DETAILING_YELLOW} />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Service</Text>
            <Text style={styles.sectionSubtitle}>Select your preferred detailing package</Text>
            
            <View style={styles.serviceGrid}>
              {detailingServiceOptions.map((service, index) => {
                const isSelected = selectedService === service.id;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      styles.serviceCardStrip,
                      {
                        opacity: fadeAnim,
                        borderLeftColor: DETAILING_YELLOW,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(234,179,8,0.3)'}
                      borderRadius={BOOKING_CARD.BORDER_RADIUS}
                      intensity={52}
                      accountType="customer"
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '30', service.colors[1] + '20'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceContent}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={26} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceDetails}>
                          <Text
                            style={[styles.serviceName, isSelected && { color: service.colors[0] }]}
                            numberOfLines={1}
                          >
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          {isSelected && service.id === 'machine-polishing' && (
                            <Text style={styles.serviceReinforcement}>Results vary by paint condition – inspection included</Text>
                          )}
                          {isSelected && service.id === 'ceramic-coating' && (
                            <Text style={styles.serviceReinforcement}>Paint prep included; best on clean or corrected paint</Text>
                          )}
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={DETAILING_YELLOW} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>
                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: service.colors[0] }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {selectedService && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <Text style={styles.conditionMicrocopy}>
                Detailing is condition-based. Results vary by vehicle condition.
              </Text>
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[DETAILING_YELLOW, '#7C3AED']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
    marginBottom: 8,
    letterSpacing: -0.5,
  },
  sectionSubtitle: {
    color: DETAILING_YELLOW,
    fontSize: 15,
    marginBottom: 24,
    opacity: 0.9,
    fontWeight: '600',
  },
  serviceGrid: {
    gap: 18,
  },
  serviceCardWrapper: {
    width: '100%',
  },
  serviceCardStrip: {
    borderLeftWidth: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  serviceCard: {
    padding: 18,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    ...BOOKING_CARD.CURVED,
  },
  serviceCardSelected: {
    elevation: 4,
    shadowColor: DETAILING_YELLOW,
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 10,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  serviceIconWrapper: {
    width: 54,
    height: 54,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.35)',
  },
  serviceDetails: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
    textAlign: 'left',
    letterSpacing: -0.2,
  },
  serviceDesc: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
    lineHeight: 18,
    opacity: 0.9,
  },
  serviceReinforcement: {
    color: '#FACC15',
    fontSize: 11,
    marginBottom: 6,
    fontStyle: 'italic',
  },
  serviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 0,
  },
  serviceMetaText: {
    color: DETAILING_YELLOW,
    fontSize: 12,
    fontWeight: '700',
  },
  priceColumn: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    minWidth: 70,
  },
  priceLabel: {
    color: '#94A3B8',
    fontSize: 12,
    marginBottom: 4,
  },
  servicePriceText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBadge: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: DETAILING_YELLOW,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  conditionMicrocopy: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
    fontStyle: 'italic',
  },
  continueButton: {
    marginTop: 12,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: DETAILING_YELLOW,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 36,
    gap: 10,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 19,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
});

