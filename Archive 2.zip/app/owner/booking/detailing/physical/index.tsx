import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import useLiveLocation from '@/hooks/useLiveLocation';
import * as Location from 'expo-location';
import { useAuth } from '@/providers/enhanced-auth-context';
import { supabase } from '@/lib/supabase';
import { hapticFeedback } from '@/services/HapticFeedbackService';
import UnifiedBookingCard from '@/components/booking/UnifiedBookingCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '@/components/shared/AppHeader';
import InfoIconButton from '@/components/shared/InfoIconButton';
import { colors } from '@/constants/colors';
import { customerTheme } from '@/constants/customerTheme';
import { BOOKING_CARD } from '@/constants/bookingCardTheme';
import { BlurView } from 'expo-blur';
import { VehicleInfoOverlay } from '@/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '@/utils/vehicleStats';
import { DEFAULT_MAP_REGION, MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '@/constants/mapConstants';
import { CAR_IMAGE } from '@/constants/appAssets';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../components/NavigationTab';
import { HEADER_BORDER_RADIUS } from '@/constants/layoutConstants';
import { useAdaptiveLayout } from '@/constants/adaptiveLayout';

const ACCENT = colors.DETAILING_YELLOW;
const ACCENT_DARK = colors.DETAILING_YELLOW_DARK;

// Uber-style dark map theme (same as mobile valeter wash flow)
const uberDarkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#263c3f' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#6b9a76' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#38414e' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#212a37' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#9ca5b3' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#746855' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#1f2835' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#f3d19c' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2f3948' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#17263c' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#515c6d' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#17263c' }] },
];

type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  created_at?: string | null;
  photo?: string | null;
  size?: VehicleSize | null;
};

function formatVehicleSize(size: VehicleSize | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export default function DetailingPhysicalVehicleSelection() {
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const detailCardWidth =
    Math.min(adaptive.contentMaxWidth, adaptive.width) - adaptive.horizontalPadding * 2;
  const detailSnapInterval = detailCardWidth + 12;
  const { user } = useAuth();
  const params = useLocalSearchParams<{ locationId?: string; scheduledAt?: string }>();
  const locationId = params.locationId;
  const scheduledAt = params.scheduledAt;

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedImageUri, setExpandedImageUri] = useState<string | null>(null);
  const [infoModalVehicle, setInfoModalVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });

  const { coords: liveCoords } = useLiveLocation();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    if (liveCoords) {
      const coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else {
      getCurrentLocation();
    }
  }, [liveCoords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
      setUserLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } catch {}
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });
      if (error) throw error;
      const toSize = (s: unknown): VehicleSize | null =>
        s === 'small' || s === 'medium' || s === 'large' || s === 'xl' || s === 'xxl' ? s : null;
      const rows = (data || []).map((r: any) => ({
        ...r,
        image_url: r.image_url ?? r.photo ?? null,
        created_at: r.created_at ?? null,
        size: toSize(r.size),
      }));
      setVehicles(rows);
      if (rows.length > 0) setSelectedVehicle(rows.find((v: Vehicle) => v.is_default)?.id ?? rows[0].id);
    } catch (e) {
      console.error('Failed to load vehicles', e);
    } finally {
      setLoading(false);
    }
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoModalVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  const handleSelect = async (vehicleId: string) => {
    await hapticFeedback('light');
    setSelectedVehicle(vehicleId);
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    if (locationId) {
      router.push({
        pathname: '/owner/booking/detailing/physical/service',
        params: {
          locationId,
          vehicleId: selectedVehicle,
          ...(scheduledAt && { scheduledAt }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/detailing/physical/location',
        params: { vehicleId: selectedVehicle },
      });
    }
  };

  function renderVehicleCardsContent() {
    if (loading) {
      return (
        <View style={[styles.cardWrapper, { width: detailCardWidth, marginRight: 0 }]}>
          <UnifiedBookingCard stripColor={ACCENT}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={ACCENT} />
              <Text style={styles.loadingText}>Loading vehicles…</Text>
            </View>
          </UnifiedBookingCard>
        </View>
      );
    }
    if (vehicles.length === 0) {
      return (
        <View style={[styles.cardWrapper, { width: detailCardWidth, marginRight: 0 }]}>
          <UnifiedBookingCard stripColor={ACCENT}>
            <View style={styles.emptyContent}>
              <View style={[styles.iconWrap, { backgroundColor: ACCENT + '20', borderColor: ACCENT + '40' }]}>
                <Ionicons name="car-outline" size={28} color={ACCENT} />
              </View>
              <Text style={styles.emptyText}>No vehicles found</Text>
              <Text style={styles.emptySubtext}>Add a vehicle to continue</Text>
              <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                <LinearGradient colors={[ACCENT, ACCENT_DARK]} style={styles.addButtonGradient}>
                  <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.addButtonText}>Add Vehicle</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </UnifiedBookingCard>
        </View>
      );
    }
    return (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.cardsScrollContent}
        snapToInterval={detailSnapInterval}
        decelerationRate="fast"
        snapToAlignment="start"
      >
        {vehicles.map((vehicle) => {
          const isSelected = selectedVehicle === vehicle.id;
          return (
            <View key={vehicle.id} style={[styles.cardWrapper, { width: detailCardWidth }]}>
              <UnifiedBookingCard
                stripColor={ACCENT}
                onPress={() => handleSelect(vehicle.id)}
              >
                <View style={styles.vehicleCardInner}>
                  {isSelected && (
                    <LinearGradient colors={[ACCENT + '15', ACCENT + '08', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                  )}
                  <View style={styles.vehicleCardInfoIcon}>
                    <InfoIconButton
                      onPress={() => { hapticFeedback('light'); openVehicleInfo(vehicle); }}
                      accentColor={ACCENT}
                    />
                  </View>
                  <View style={styles.cardTop}>
                    <View style={[styles.vehicleCardCarIcon, { backgroundColor: (isSelected ? ACCENT : '#94A3B8') + '18', borderColor: (isSelected ? ACCENT : '#94A3B8') + '30' }]}>
                      <Ionicons name="car-sport" size={28} color={isSelected ? ACCENT : '#94A3B8'} />
                    </View>
                    <View style={styles.cardContent}>
                      <Text style={styles.cardTitle} numberOfLines={1}>{vehicle.make} {vehicle.model}</Text>
                      <View style={styles.cardColourRow}>
                        <Text style={styles.cardSubtitle} numberOfLines={1}>{vehicle.color}</Text>
                        {vehicle.is_default && (
                          <View style={[styles.quickHint, { backgroundColor: '#10B98115' }]}>
                            <Ionicons name="star" size={12} color="#10B981" />
                            <Text style={[styles.quickHintText, { color: '#10B981' }]}>Default vehicle</Text>
                          </View>
                        )}
                      </View>
                      <View style={styles.cardMetaRow}>
                        <View style={[styles.quickHint, styles.quickHintReg, { backgroundColor: (isSelected ? ACCENT : '#94A3B8') + '18' }]}>
                          <Ionicons name="card-outline" size={12} color={isSelected ? ACCENT : '#94A3B8'} />
                          <Text style={[styles.quickHintText, { color: isSelected ? ACCENT : '#94A3B8' }]} numberOfLines={1}>{vehicle.registration}</Text>
                        </View>
                        {vehicle.size ? (
                          <View style={[styles.quickHint, styles.quickHintSize, { backgroundColor: (isSelected ? ACCENT : '#94A3B8') + '18' }]}>
                            <Text style={[styles.quickHintText, { color: isSelected ? ACCENT : '#94A3B8' }]}>{formatVehicleSize(vehicle.size)}</Text>
                          </View>
                        ) : null}
                      </View>
                    </View>
                    {vehicle.image_url ? (
                      <View style={styles.carPhotoBox}>
                        <TouchableOpacity
                          onPress={(e) => {
                            e.stopPropagation();
                            hapticFeedback('light');
                            setExpandedImageUri(vehicle.image_url || null);
                          }}
                          activeOpacity={0.9}
                          style={styles.carPhotoTouch}
                        >
                          <Image source={{ uri: vehicle.image_url }} style={styles.carPhotoSmall} resizeMode="cover" />
                          <View style={styles.carPhotoExpandHint}>
                            <Ionicons name="expand" size={12} color="#fff" />
                          </View>
                        </TouchableOpacity>
                      </View>
                    ) : null}
                  </View>
                </View>
              </UnifiedBookingCard>
            </View>
          );
        })}
      </ScrollView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image source={CAR_IMAGE} style={styles.userMarker} resizeMode="contain" />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={() => {
          hapticFeedback('light');
          if (userLocation) {
            setRegion({ ...userLocation, latitudeDelta: 0.001, longitudeDelta: 0.001 });
          } else {
            getCurrentLocation();
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={ACCENT} />
      </TouchableOpacity>

      <AppHeader
        title="Detail Hub"
        subtitle="Select vehicle for detailing"
        showBack
        onBack={() => router.back()}
        primaryColor={ACCENT}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            paddingHorizontal: adaptive.horizontalPadding,
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {renderVehicleCardsContent()}
      </Animated.View>

      {/* Floating Continue button - same position as other booking steps */}
      {!loading && vehicles.length > 0 && (
        <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12, left: adaptive.horizontalPadding, right: adaptive.horizontalPadding }]}>
          <TouchableOpacity
            onPress={handleContinue}
            disabled={!selectedVehicle}
            style={[styles.ctaButton, { width: detailCardWidth }]}
            activeOpacity={0.9}
          >
            <LinearGradient
              colors={selectedVehicle ? [ACCENT, ACCENT_DARK] : ['#475569', '#334155']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.ctaGradient}
            >
              <Text style={styles.ctaText}>{selectedVehicle ? 'Continue' : 'Select a vehicle'}</Text>
              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      <VehicleInfoOverlay
        visible={!!infoModalVehicle}
        vehicle={infoModalVehicle ? { ...infoModalVehicle, mot_expiry: (infoModalVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoModalVehicle as any).mot_expiry_date ?? null, mileage: (infoModalVehicle as any).mileage ?? null, tax_status: (infoModalVehicle as any).tax_status ?? null, tax_due_date: (infoModalVehicle as any).tax_due_date ?? null, tax_expiry: (infoModalVehicle as any).tax_expiry ?? null } : null}
        stats={vehicleStats}
        accentColor={ACCENT}
        onClose={() => setInfoModalVehicle(null)}
      />

      <Modal visible={!!expandedImageUri} transparent animationType="fade" onRequestClose={() => setExpandedImageUri(null)}>
        <Pressable style={styles.imageModalOverlay} onPress={() => setExpandedImageUri(null)}>
          <Pressable onPress={(e) => e.stopPropagation()} style={styles.imageModalContent}>
            {expandedImageUri && (
              <Image source={{ uri: expandedImageUri }} style={styles.imageModalImage} resizeMode="contain" />
            )}
            <TouchableOpacity onPress={() => setExpandedImageUri(null)} style={styles.imageModalClose} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
              <Ionicons name="close-circle" size={36} color="#fff" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  userMarkerContainer: { alignItems: 'center', justifyContent: 'center' },
  userMarker: { width: 48, height: 48 },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: ACCENT + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: { paddingRight: 16 },
  cardWrapper: { marginRight: 12 },
  vehicleCardInner: {
    position: 'relative',
    padding: 20,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 14,
    right: 14,
    zIndex: 1,
  },
  vehicleCardCarIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
    marginBottom: 4,
  },
  cardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
  },
  badgeSmall: { paddingHorizontal: 6, paddingVertical: 4, borderRadius: 10, borderWidth: 1 },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'nowrap',
    gap: 8,
    marginTop: 6,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  quickHintReg: {
    flex: 1,
    minWidth: 0,
  },
  quickHintSize: {
    flexShrink: 0,
  },
  quickHintText: {
    fontSize: 12,
    fontWeight: '600',
  },
  infoIconBtn: { padding: 6, borderRadius: 10 },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: { color: '#FFFFFF', fontSize: 17, fontWeight: '900' },
  emptyContent: { alignItems: 'center', paddingVertical: 24 },
  emptyText: { color: '#F9FAFB', fontSize: 17, fontWeight: '800', marginTop: 14, marginBottom: 4 },
  emptySubtext: { color: '#94A3B8', fontSize: 13, textAlign: 'center', marginBottom: 16 },
  loadingContainer: { paddingVertical: 40, paddingHorizontal: 20, alignItems: 'center', gap: 16 },
  loadingText: { color: ACCENT, fontSize: 15, fontWeight: '700' },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: ACCENT,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800', letterSpacing: 0.3 },
  carPhotoBox: { width: 56, height: 56, borderRadius: 14, overflow: 'hidden', marginLeft: 10 },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  carPhotoSmall: { width: 56, height: 56 },
  carPhotoExpandHint: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', alignItems: 'center' },
  imageModalContent: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
  imageModalImage: { width: '100%', height: '80%' },
  imageModalClose: { position: 'absolute', top: 60, right: 24 },
  // Vehicle info modal – same card background as wash option cards
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: 'transparent',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 20,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
    overflow: 'hidden',
  },
  infoModalHeader: {
    position: 'relative' as const,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  infoModalPhoto: { width: '100%', height: 120, backgroundColor: 'rgba(0,0,0,0.2)' },
  infoModalPhotoPlaceholder: {
    width: '100%',
    height: 120,
    backgroundColor: customerTheme.primary + '18',
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
  },
  infoModalTitleRow: {
    position: 'absolute' as const,
    top: 12,
    left: 12,
    right: 12,
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
  },
  infoModalTitle: {
    color: customerTheme.primary,
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
  },
  infoModalBody: {
    padding: 16,
    gap: 10,
    marginBottom: 16,
  },
  infoModalRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoModalText: {
    color: colors.headerSubtext,
    fontSize: 13,
    opacity: 0.95,
  },
  infoModalDone: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: customerTheme.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
