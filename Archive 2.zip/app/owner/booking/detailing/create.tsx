import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/providers/enhanced-auth-context';
import { supabase } from '@/lib/supabase';
import { hapticFeedback } from '@/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import AppHeader from '@/components/shared/AppHeader';
import InfoIconButton from '@/components/shared/InfoIconButton';
import { VehicleInfoOverlay } from '@/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '@/utils/vehicleStats';
import { colors } from '@/constants/colors';
import { customerTheme, BOOKING_CARD } from '@/constants/customerTheme';
import { HEADER_BORDER_RADIUS } from '@/constants/layoutConstants';

const { width } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const ACCENT = colors.DETAILING_YELLOW;
const ACCENT_DARK = colors.DETAILING_YELLOW_DARK;

type Vehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  photo?: string | null;
  type?: string | null;
  size?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  mileage?: string | number | null;
};

export default function DetailingCreate() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });
      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) setSelectedVehicle(rows.find((v: Vehicle) => v.is_default)?.id ?? rows[0].id);
    } catch (e) {
      console.error('Failed to load vehicles', e);
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: { vehicleId: selectedVehicle, serviceType: 'detailing' },
    } as any);
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Mobile Detailing"
        subtitle="Choose your vehicle"
        showBack
        onBack={() => router.back()}
        primaryColor={ACCENT}
      />

      <Animated.View style={[styles.content, { opacity: fadeAnim, paddingTop: 100, paddingBottom: insets.bottom + 100 }]}>
        {loading ? (
          <ActivityIndicator size="large" color={ACCENT} />
        ) : vehicles.length === 0 ? (
          <GlassCard style={styles.emptyCard} borderColor={ACCENT + '40'} borderRadius={BOOKING_CARD.BORDER_RADIUS} intensity={48}>
            <Ionicons name="car-outline" size={48} color={ACCENT} />
            <Text style={styles.emptyTitle}>No vehicles yet</Text>
            <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')}>
              <Text style={[styles.addLink, { color: ACCENT }]}>Add a vehicle</Text>
            </TouchableOpacity>
          </GlassCard>
        ) : (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            <Text style={styles.sectionLabel}>Select vehicle for detailing</Text>
            {vehicles.map((vehicle) => {
              const selected = selectedVehicle === vehicle.id;
              return (
                <TouchableOpacity
                  key={vehicle.id}
                  onPress={() => {
                    hapticFeedback('light');
                    setSelectedVehicle(vehicle.id);
                  }}
                  activeOpacity={0.85}
                >
                  <GlassCard
                    style={[styles.vehicleCard, selected && styles.vehicleCardSelected]}
                    borderColor={selected ? ACCENT : undefined}
                    borderRadius={BOOKING_CARD.BORDER_RADIUS}
                    intensity={48}
                  >
                    <View style={styles.vehicleRow}>
                      <View style={styles.vehicleInfoIconWrap}>
                        <InfoIconButton onPress={() => openVehicleInfo(vehicle)} accentColor={ACCENT} />
                      </View>
                      <View style={[styles.vehicleIconWrap, { backgroundColor: ACCENT + '25' }]}>
                        <Ionicons name="car-sport" size={24} color={ACCENT} />
                      </View>
                      <View style={styles.vehicleInfo}>
                        <Text style={styles.vehicleName}>{vehicle.make} {vehicle.model}</Text>
                        <Text style={styles.vehicleMeta}>{vehicle.color} • {vehicle.registration}</Text>
                        {vehicle.is_default && (
                          <View style={styles.defaultBadge}>
                            <Ionicons name="star" size={10} color="#10B981" />
                            <Text style={styles.defaultText}>Default</Text>
                          </View>
                        )}
                      </View>
                      {selected && <Ionicons name="checkmark-circle" size={24} color={ACCENT} />}
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        )}

        {!loading && vehicles.length > 0 && (
          <View style={[styles.ctaWrap, { paddingBottom: insets.bottom + 16 }]}>
            <TouchableOpacity onPress={handleContinue} disabled={!selectedVehicle} activeOpacity={0.9}>
              <LinearGradient
                colors={selectedVehicle ? [ACCENT, ACCENT_DARK] : ['#475569', '#334155']}
                style={styles.ctaButton}
              >
                <Text style={styles.ctaText}>{selectedVehicle ? 'Find a detailer' : 'Select a vehicle'}</Text>
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </Animated.View>

      <VehicleInfoOverlay
        visible={!!infoVehicle}
        vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: infoVehicle.mot_expiry ?? null, mot_expiry_date: infoVehicle.mot_expiry_date ?? null, mileage: infoVehicle.mileage ?? null, tax_status: infoVehicle.tax_status ?? null, tax_due_date: infoVehicle.tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
        stats={vehicleStats}
        accentColor={ACCENT}
        onClose={() => setInfoVehicle(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 20 },
  scrollContent: { paddingBottom: 24 },
  sectionLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  vehicleCard: {
    padding: 16,
    marginBottom: 12,
    overflow: 'hidden',
    ...BOOKING_CARD.CURVED,
  },
  vehicleCardSelected: { borderWidth: 2 },
  vehicleRow: { position: 'relative', flexDirection: 'row', alignItems: 'center' },
  vehicleInfoIconWrap: { position: 'absolute', top: 0, right: 0, zIndex: 1 },
  vehicleIconWrap: { width: 48, height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  vehicleInfo: { flex: 1 },
  vehicleName: { color: '#F9FAFB', fontSize: 17, fontWeight: '800' },
  vehicleMeta: { color: '#94A3B8', fontSize: 13, marginTop: 2 },
  defaultBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  defaultText: { color: '#10B981', fontSize: 12, fontWeight: '700' },
  emptyCard: {
    padding: 32,
    alignItems: 'center',
    gap: 12,
    overflow: 'hidden',
    ...BOOKING_CARD.CURVED,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  addLink: { fontWeight: '800', marginTop: 8 },
  ctaWrap: { position: 'absolute', left: 20, right: 20, bottom: 0 },
  ctaButton: { borderRadius: HEADER_BORDER_RADIUS, paddingVertical: 18, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10 },
  ctaText: { color: '#FFFFFF', fontSize: 17, fontWeight: '900' },
});
