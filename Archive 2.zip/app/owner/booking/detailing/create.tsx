import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';

import { colors } from '../../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function DetailingCreate() {
  const { user } = useAuth();
    const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [gettingLocation, setGettingLocation] = useState(false);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
  };

  const handleContinue = async () => {
    if (!selectedService || !selectedVehicle) {
      return;
    }
    await hapticFeedback('medium');
    setGettingLocation(true);
    
    try {
      // Get user's current location for valeter selection
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to find nearby valeters.');
        setGettingLocation(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };

      // Reverse geocode to get address
      const [result] = await Location.reverseGeocodeAsync(coords);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim()
        : 'Current Location';

      router.push({
        pathname: '/owner/booking/detailing/valeter-selection',
        params: {
          serviceId: selectedService,
          vehicleId: selectedVehicle,
          latitude: coords.latitude.toString(),
          longitude: coords.longitude.toString(),
          address: addr,
        },
      });
    } catch (error) {
      console.error('Error getting location:', error);
      Alert.alert('Error', 'Could not get your location. Please try again.');
      setGettingLocation(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#4C1D95']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Detailing Service" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Service Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Service</Text>
            <Text style={styles.sectionSubtitle}>Choose your premium detailing package</Text>
            
            <View style={styles.serviceGrid}>
              {detailingServiceOptions.map((service, index) => {
                const isSelected = selectedService === service.id;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      {
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(139,92,246,0.3)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '30', service.colors[1] + '20'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceContent}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={26} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceDetails}>
                          <Text
                            style={[styles.serviceName, isSelected && { color: service.colors[0] }]}
                            numberOfLines={1}
                          >
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={PREMIUM_PURPLE} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>
                        <View style={styles.priceColumn}>
                          <Text style={styles.priceLabel}>From</Text>
                          <Text style={[styles.servicePriceText, isSelected && { color: service.colors[0] }]}>
                            £{service.price}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: service.colors[0] }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {/* Vehicle Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Vehicle</Text>
            <Text style={styles.sectionSubtitle}>Choose the vehicle for this service</Text>
            
            {loading ? (
              <View style={styles.loadingContainer}>
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="car-outline" size={48} color={PREMIUM_PURPLE} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <TouchableOpacity
                    onPress={() => router.push('/owner/settings/vehicle-management')}
                    style={styles.addVehicleButton}
                  >
                    <Text style={styles.addVehicleText}>Add Vehicle</Text>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ) : (
              <View style={styles.vehicleList}>
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <GlassCard
                      key={vehicle.id}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedVehicle(vehicle.id);
                      }}
                      style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                      borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.3)'}
                    >
                      <View style={styles.vehicleContent}>
                        <View style={styles.vehicleIconWrapper}>
                          <Ionicons name="car-sport" size={24} color={PREMIUM_PURPLE} />
                        </View>
                        <View style={styles.vehicleInfo}>
                          <Text style={styles.vehicleName}>
                            {vehicle.make} {vehicle.model}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {vehicle.color} • {vehicle.registration}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={styles.selectedCheck}>
                            <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
            )}
          </View>

          {/* Continue Button */}
          {selectedService && selectedVehicle && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
                disabled={gettingLocation}
              >
                <LinearGradient
                  colors={[PREMIUM_PURPLE, '#7C3AED']}
                  style={styles.continueGradient}
                >
                  {gettingLocation ? (
                    <>
                      <ActivityIndicator size="small" color="#FFFFFF" />
                      <Text style={styles.continueText}>Getting Location...</Text>
                    </>
                  ) : (
                    <>
                      <Text style={styles.continueText}>Continue</Text>
                      <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  serviceGrid: {
    gap: 16,
    flexDirection: 'column',
  },
  serviceCardWrapper: {
    width: '100%',
    marginBottom: 0,
  },
  serviceCard: {
    padding: 16,
    minHeight: 100,
  },
  serviceCardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.4,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  serviceIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceDetails: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'left',
  },
  serviceDesc: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
    lineHeight: 16,
  },
  serviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 0,
  },
  serviceMetaText: {
    color: PREMIUM_PURPLE,
    fontSize: 10,
  },
  priceColumn: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    minWidth: 70,
  },
  priceLabel: {
    color: '#C8C5FF',
    fontSize: 12,
    marginBottom: 4,
  },
  servicePriceText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleList: {
    gap: 12,
  },
  vehicleCard: {
    padding: 16,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.4,
  },
  vehicleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  vehicleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleDetails: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
  },
  selectedCheck: {
    marginLeft: 'auto',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    marginTop: 12,
    marginBottom: 20,
  },
  addVehicleButton: {
    backgroundColor: PREMIUM_PURPLE,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

