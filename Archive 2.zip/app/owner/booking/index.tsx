import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress'];

const washTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Valeter',
    description: 'We send a vetted valeter to your location with live tracking.',
    icon: 'car-outline',
    borderColor: 'rgba(135,206,235,0.3)',
    iconColor: colors.SKY,
    route: '/owner/booking/create',
    bulletPoints: ['Live status + tracking', 'Pay only after acceptance', 'Perfect for home/office'],
  },
  {
    id: 'physical',
    title: 'Physical Wash Hub',
    description: 'Drive to a premium Wish a Wash hub and get instant service.',
    icon: 'business-outline',
    borderColor: 'rgba(59,130,246,0.3)',
    iconColor: '#3B82F6',
    route: '/owner/booking/physical/vehicle',
    bulletPoints: ['Certified wash locations', 'Book date & time slot', 'Ideal for nearby errands'],
  },
  {
    id: 'eco',
    title: 'Eco Wash',
    description: 'Environmentally friendly car wash with biodegradable products.',
    icon: 'leaf-outline',
    borderColor: 'rgba(16,185,129,0.3)',
    iconColor: colors.ECO_GREEN,
    route: '/owner/booking/eco',
    bulletPoints: ['Eco-friendly products', 'Carbon-neutral process', 'Better for environment'],
  },
] as const;

type ActiveBooking = { id: string; status: DbBookingStatus };

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, friction: 8, tension: 60, useNativeDriver: true }),
    ]).start();
  }, []);

  const loadActiveBooking = async () => {
    if (!user?.id) return;
    try {
      setCheckingActive(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[WashTypeSelection] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({ id: data.id, status: data.status as DbBookingStatus });
    } catch (e) {
      console.warn('[WashTypeSelection] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setCheckingActive(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    loadActiveBooking();

    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;
          const status = updated?.status as DbBookingStatus | undefined;

          if (!updated?.id || !status) {
            loadActiveBooking();
            return;
          }

          if (ACTIVE_STATUSES.includes(status)) {
            setActiveBooking({ id: updated.id, status });
          } else if (activeBooking?.id === updated.id) {
            setActiveBooking(null);
          } else {
            loadActiveBooking();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleEcoPress = () => {
    Alert.alert('Eco Wash', 'Eco wash is coming soon.', [{ text: 'OK' }]);
  };

  const handleSelect = (option: (typeof washTypes)[number]) => {
    const isEco = option.id === 'eco';

    if (isEco) {
      handleEcoPress();
      return;
    }

    if (checkingActive) return;

    if (activeBooking?.id) {
      Alert.alert(
        'Active booking in progress',
        'You already have an active booking. Want to go back to tracking it?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }

    router.push(option.route as any);
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="How would you like to book?" subtitle="Select your preferred booking method" showBack={false} />

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        style={[
          styles.cardsWrapper,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET,
          paddingBottom: Math.max(insets.bottom, 24),
        }}
      >
        {washTypes.map((option) => {
          const isEco = option.id === 'eco';

          return (
            <View key={option.id} style={isEco ? styles.ecoCardWrapper : null}>
              {isEco && (
                <LinearGradient
                  colors={['rgba(16,185,129,0.15)', 'rgba(5,150,105,0.1)']}
                  style={StyleSheet.absoluteFill}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                />
              )}

              <GlassCard
                onPress={() => handleSelect(option)}
                style={[
                  styles.card,
                  isEco && styles.ecoCard,
                  checkingActive && !isEco ? styles.cardDisabled : null,
                ]}
                borderColor={isEco ? 'rgba(16,185,129,0.5)' : option.borderColor}
                accountType="customer"
              >
                <View style={styles.cardHeader}>
                  <View style={[styles.iconWrapper, { backgroundColor: option.iconColor + '20' }]}>
                    <Ionicons name={option.icon as any} size={20} color={option.iconColor} />
                  </View>

                  <Text style={styles.cardTitle}>{option.title}</Text>

                  {isEco && (
                    <View style={styles.comingSoonPill}>
                      <Text style={styles.comingSoonText}>COMING SOON</Text>
                    </View>
                  )}
                </View>

                <Text style={styles.cardDescription} numberOfLines={2}>
                  {option.description}
                </Text>

                <View style={styles.bullets}>
                  {option.bulletPoints.slice(0, 2).map((point) => (
                    <View key={point} style={styles.bulletRow}>
                      <Ionicons
                        name="checkmark-circle"
                        size={12}
                        color={option.iconColor}
                        style={{ opacity: isEco ? 0.55 : 0.8 }}
                      />
                      <Text style={[styles.bulletText, isEco && styles.ecoMuted]} numberOfLines={1}>
                        {point}
                      </Text>
                    </View>
                  ))}
                </View>

                <View style={styles.cardCTA}>
                  <Text style={[styles.cardCTAText, isEco && styles.ecoMuted]}>
                    {isEco ? 'Learn more' : activeBooking ? 'View active booking' : 'Continue'}
                  </Text>
                  <Ionicons
                    name={isEco ? 'information-circle-outline' : 'arrow-forward'}
                    size={16}
                    color={isEco ? 'rgba(249,250,251,0.75)' : '#F9FAFB'}
                  />
                </View>

                {/* Disabled overlay for Eco */}
                {isEco && (
                  <View pointerEvents="none" style={styles.ecoOverlay}>
                    <LinearGradient
                      colors={['rgba(0,0,0,0.0)', 'rgba(0,0,0,0.18)', 'rgba(0,0,0,0.28)']}
                      style={StyleSheet.absoluteFill}
                    />
                  </View>
                )}
              </GlassCard>
            </View>
          );
        })}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  cardsWrapper: {
    paddingHorizontal: isSmallScreen ? 16 : 24,
    paddingTop: 8,
    flex: 1,
  },

  ecoCardWrapper: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 12,
  },

  card: {
    padding: isSmallScreen ? 16 : 18,
    marginBottom: 12,
  },
  ecoCard: {
    marginBottom: 0,
  },
  cardDisabled: {
    opacity: 0.95,
  },

  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  iconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    flex: 1,
  },
  cardDescription: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    marginBottom: 8,
    lineHeight: 16,
  },
  bullets: {
    gap: 4,
    marginBottom: 10,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bulletText: {
    color: '#E5E7EB',
    fontSize: 11,
    flex: 1,
  },

  cardCTA: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 6,
  },
  cardCTAText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },

  comingSoonPill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.9)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.35)',
  },
  comingSoonText: {
    color: '#06261D',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.4,
  },

  ecoOverlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
  },
  ecoMuted: {
    opacity: 0.78,
  },
});
