import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../../../src/constants/colors';

export default function WaitingAcceptanceRedirectToTracking() {
  const params = useLocalSearchParams();
  const bookingId = typeof params.bookingId === 'string' ? params.bookingId : '';

  useEffect(() => {
    if (bookingId) {
      router.replace({ pathname: '/owner/booking/tracking', params: { bookingId } } as any);
      return;
    }
    router.replace('/owner/track' as any);
  }, [bookingId]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={styles.loaderWrap}>
        <ActivityIndicator size="small" color={colors.SKY} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  loaderWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
