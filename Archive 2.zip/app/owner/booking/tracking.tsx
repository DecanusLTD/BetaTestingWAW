import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Callout, Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { BOOKING_CARD, BOOKING_INDEX_CARDS_BOTTOM_PADDING } from '../../../src/constants/bookingCardTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, MAP_CAMERA_ANIMATION_DURATION, RECENTER_BUTTON_LEFT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { distanceKm, etaMinutes, distanceMiles, regionForCoordinates, FIT_PADDING } from '../../../src/utils/mapUtils';
import { customerTheme } from '../../../src/constants/customerTheme';
import { startLiveActivity, updateLiveActivity, endLiveActivity } from '../../../src/services/LiveActivityService';
import PulsingBorderLoader from '../../../src/components/booking/PulsingBorderLoader';
import ValeterDeclinedOverlay from '../../../src/components/booking/ValeterDeclinedOverlay';
import { WashHubStatsService } from '../../../src/services/WashHubStatsService';
import { CAR_IMAGE, CARWASH_IMAGE, VALETER_MAP_IMAGE, DETAILING_HUB_IMAGE } from '../../assets/assetExports';
import {
  type BookingStatus,
  getStatusProgress,
  getStages,
  getStatusMessage,
  getStepCardConfig,
  getRingColorForStep,
  getStageProgressPercent,
} from '@/utils/trackingStatusHelpers';

const SKY = colors.SKY ?? '#38BDF8';

type WashHubReview = { rating: number; review?: string | null };
const { width } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

// Bubble configs for "washing" state – float inside the tracking card
const BUBBLE_CONFIG = [
  { size: 8, left: 12, top: 75 }, { size: 6, left: 28, top: 85 }, { size: 10, left: 50, top: 70 },
  { size: 7, left: 72, top: 80 }, { size: 9, left: 88, top: 65 }, { size: 6, left: 18, top: 55 },
  { size: 8, left: 45, top: 90 }, { size: 7, left: 65, top: 60 }, { size: 10, left: 82, top: 72 },
  { size: 6, left: 35, top: 78 }, { size: 8, left: 55, top: 85 }, { size: 7, left: 90, top: 55 },
];

type BookingRow = {
  id: string;
  status: BookingStatus;
  service_type: string;
  service_name?: string | null;
  price: number | string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  location_id?: string | null;
};

type WashHub = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  rating?: number;
  jobsCompleted?: number;
  joinedAt?: string | null;
  reviews?: WashHubReview[];
};

function getTrackingDestination(
  booking: BookingRow | null,
  washHub: WashHub | null
): { latitude: number; longitude: number } | null {
  if (washHub?.latitude != null && washHub?.longitude != null) {
    return { latitude: washHub.latitude, longitude: washHub.longitude };
  }
  if (booking?.location_lat != null && booking?.location_lng != null) {
    return { latitude: booking.location_lat, longitude: booking.location_lng };
  }
  return null;
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- tracking screen with loading/empty/active states and live updates
export default function BookingTracking() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const bookingId = typeof params.bookingId === 'string' ? params.bookingId : undefined;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterName, setValeterName] = useState<string>('Valeter');
  const [status, setStatus] = useState<BookingStatus>('pending_payment');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [washHub, setWashHub] = useState<WashHub | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [markingArrived, setMarkingArrived] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [showCompletedConfetti, setShowCompletedConfetti] = useState(false);
  const [showValeterDeclinedOverlay, setShowValeterDeclinedOverlay] = useState(false);

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [liveRegion, setLiveRegion] = useState<Region | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const bubbleAnims = useRef(
    BUBBLE_CONFIG.map(() => ({ y: new Animated.Value(0) }))
  ).current;
  const bubbleLoopsRef = useRef<Animated.CompositeAnimation[]>([]);
  const bookingChannelRef = useRef<any>(null);
  const presenceChannelRef = useRef<any>(null);
  const presenceValeterIdRef = useRef<string | null>(null);
  const mapRef = useRef<MapView>(null);
  const lastFitTimeRef = useRef<number>(0);
  const lastValeterLocRef = useRef<{ lat: number; lng: number } | null>(null);

  const markerPulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    markerPulseLoopRef.current = loop;
    loop.start();
    return () => {
      if (markerPulseLoopRef.current) {
        markerPulseLoopRef.current.stop();
        markerPulseLoopRef.current = null;
      }
    };
  }, []);

  // Floating bubbles when status is in_progress (washing)
  useEffect(() => {
    if (status !== 'in_progress') {
      bubbleLoopsRef.current.forEach((loop) => loop.stop());
      bubbleLoopsRef.current = [];
      return;
    }
    bubbleAnims.forEach((b, i) => b.y.setValue(0));
    bubbleLoopsRef.current = bubbleAnims.map((b, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(b.y, {
            toValue: -280,
            duration: 2800 + i * 180,
            useNativeDriver: true,
          }),
          Animated.timing(b.y, { toValue: 0, duration: 0, useNativeDriver: true }),
        ])
      )
    );
    bubbleLoopsRef.current.forEach((loop) => loop.start());
    return () => {
      bubbleLoopsRef.current.forEach((loop) => loop.stop());
      bubbleLoopsRef.current = [];
    };
  }, [status]);

  useEffect(() => {
    if (!bookingId) return;

    const start = async () => {
      await loadBooking();
      subscribeToBooking();
    };

    start();

    return () => {
      if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);
      if (presenceChannelRef.current) supabase.removeChannel(presenceChannelRef.current);
      bookingChannelRef.current = null;
      presenceChannelRef.current = null;
      presenceValeterIdRef.current = null;
    };
  }, [bookingId]);

  // Poll for updates every 4s - ensures tracking updates even if Realtime is delayed
  useEffect(() => {
    if (!bookingId || !booking) return;
    if (status === 'completed' || status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout') return;

    const interval = setInterval(() => loadBooking(), 4000);
    return () => clearInterval(interval);
  }, [bookingId, booking?.id, status]);

  // Refetch immediately when screen gains focus (e.g. returning from payment)
  useFocusEffect(
    React.useCallback(() => {
      if (bookingId) loadBooking();
    }, [bookingId])
  );

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;

      const row = data as BookingRow;
      setBooking(row);
      setStatus(row.status);

      if (row.valeter_id) {
        const profile = await fetchProfileById(row.valeter_id);
        setValeterName(profile?.full_name || 'Valeter');
        ensurePresenceSubscription(row.valeter_id);
        await loadValeterPresenceOnce(row.valeter_id);
      } else {
        setValeterName('Valeter');
      }

      if (row.location_id) {
        await loadWashHub(row.location_id);
      }

      updateMapRegion(row);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    if (!bookingId || bookingChannelRef.current) return;

    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;
          setBooking(updated);
          setStatus(updated.status);

          if (updated.valeter_id) {
            const profile = await fetchProfileById(updated.valeter_id);
            setValeterName(profile?.full_name || 'Valeter');
            ensurePresenceSubscription(updated.valeter_id);
            await loadValeterPresenceOnce(updated.valeter_id);
          }

          if (updated.location_id && !washHub) {
            await loadWashHub(updated.location_id);
          }

          if (updated.status === 'completed') {
            setShowCompletedConfetti(true);
          }

          if (
            updated.status === 'cancelled' ||
            updated.status === 'valeter_declined' ||
            updated.status === 'valeter_timeout'
          ) {
            setTimeout(() => setShowValeterDeclinedOverlay(true), 700);
          }

          updateMapRegion(updated);
        }
      )
      .subscribe();

    bookingChannelRef.current = channel;
  };

  const ensurePresenceSubscription = (valeterId: string) => {
    if (presenceValeterIdRef.current === valeterId && presenceChannelRef.current) return;
    if (presenceChannelRef.current) {
      supabase.removeChannel(presenceChannelRef.current);
      presenceChannelRef.current = null;
    }
    presenceValeterIdRef.current = valeterId;

    const channel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            setValeterLocation({ latitude: updated.last_lat, longitude: updated.last_lng });
          }
        }
      )
      .subscribe();

    presenceChannelRef.current = channel;
  };

  const loadValeterPresenceOnce = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) return;
      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ latitude: data.last_lat, longitude: data.last_lng });
      }
    } catch {}
  };

  const loadWashHub = async (locationId: string) => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude, rating, total_reviews, created_at')
        .eq('id', locationId)
        .maybeSingle();

      if (error) throw error;
      if (!data) return;
      if (data.latitude == null || data.longitude == null) return;

      const [stats, { data: reviewRows }] = await Promise.all([
        WashHubStatsService.getHubStats(locationId),
        supabase
          .from('bookings')
          .select('rating, review')
          .eq('location_id', locationId)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(5),
      ]);

      const reviews: WashHubReview[] = (reviewRows || []).map((row: { rating: number; review?: string | null }) => ({
        rating: Number(row.rating) || 0,
        review: row.review ?? null,
      }));

      const hubRow = data as { rating?: number; total_reviews?: number; created_at?: string };
      setWashHub({
        id: data.id,
        name: data.name || 'Wash Hub',
        address: data.address,
        latitude: data.latitude,
        longitude: data.longitude,
        rating: Number(hubRow.rating) || stats.averageRating || 0,
        jobsCompleted: stats.totalJobs || Number(hubRow.total_reviews) || 0,
        joinedAt: hubRow.created_at ?? null,
        reviews: reviews.length > 0 ? reviews : undefined,
      });
    } catch (error) {
      console.error('Error loading wash hub:', error);
    }
  };

  const updateMapRegion = (bookingData: BookingRow) => {
    const points: Array<{ latitude: number; longitude: number }> = [];

    if (bookingData.location_lat && bookingData.location_lng) {
      points.push({ latitude: bookingData.location_lat, longitude: bookingData.location_lng });
    }
    if (valeterLocation) {
      points.push(valeterLocation);
    }
    if (washHub?.latitude && washHub?.longitude) {
      points.push({ latitude: washHub.latitude, longitude: washHub.longitude });
    }

    if (points.length === 0 && bookingData.location_lat && bookingData.location_lng) {
      const r = {
        latitude: bookingData.location_lat,
        longitude: bookingData.location_lng,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      };
      setRegion(r);
      mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
      return;
    }

    if (points.length > 0) {
      const now = Date.now();
      const throttleMs = 12000;
      const valeterMoved =
        !lastValeterLocRef.current ||
        (valeterLocation &&
          (Math.abs(valeterLocation.latitude - lastValeterLocRef.current.lat) > 0.0003 ||
            Math.abs(valeterLocation.longitude - lastValeterLocRef.current.lng) > 0.0003));
      if (valeterLocation) lastValeterLocRef.current = { lat: valeterLocation.latitude, lng: valeterLocation.longitude };
      if (!valeterMoved && now - lastFitTimeRef.current < throttleMs) return;
      lastFitTimeRef.current = now;

      const r = regionForCoordinates(points, 0.5);
      setRegion(r);
      mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
    }
  };

  useEffect(() => {
    if (booking) updateMapRegion(booking);
  }, [booking, valeterLocation, washHub]);

  const handleRecenterMap = () => {
    hapticFeedback('light');
    const coords: Array<{ latitude: number; longitude: number }> = [];
    if (booking?.location_lat != null && booking?.location_lng != null) {
      coords.push({ latitude: booking.location_lat, longitude: booking.location_lng });
    }
    if (valeterLocation) coords.push(valeterLocation);
    if (washHub?.latitude != null && washHub?.longitude != null) {
      coords.push({ latitude: washHub.latitude, longitude: washHub.longitude });
    }
    if (coords.length >= 1 && mapRef.current) {
      mapRef.current.fitToCoordinates(coords, { edgePadding: FIT_PADDING, animated: true });
    }
  };

  const destinationForPolyline = getTrackingDestination(booking, washHub);
  const etaMins = valeterLocation && destinationForPolyline ? etaMinutes(distanceKm(valeterLocation, destinationForPolyline)) : 0;
  const distMiles = valeterLocation && destinationForPolyline ? distanceMiles(valeterLocation, destinationForPolyline) : 0;

  useEffect(() => {
    if (liveCoords) {
      setLiveRegion({
        latitude: liveCoords.latitude,
        longitude: liveCoords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          setLiveRegion({
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
            latitudeDelta: 0.001,
            longitudeDelta: 0.001,
          });
        })
        .catch(() => {});
    }
  }, [liveCoords]);

  const canCancel =
    status !== 'completed' &&
    status !== 'cancelled' &&
    status !== 'valeter_declined' &&
    status !== 'valeter_timeout';

  const cancelBooking = async () => {
    if (!bookingId || !user?.id || !canCancel) return;
    try {
      setCancelling(true);
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer',
        })
        .eq('id', bookingId);

      if (error) throw error;
      setStatus('cancelled');
    } catch (e) {
      console.warn('[BookingTracking] cancelBooking error', e);
      Alert.alert('Could not cancel', 'Please try again in a moment.');
    } finally {
      setCancelling(false);
    }
  };

  const handleMarkArrived = async () => {
    if (!bookingId || !washHub) return;
    try {
      setMarkingArrived(true);
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'arrived' })
        .eq('id', bookingId);
      if (error) throw error;
      setStatus('arrived');
      hapticFeedback('medium');
    } catch (e) {
      console.warn('[BookingTracking] handleMarkArrived error', e);
      Alert.alert('Could not update', 'Please try again.');
    } finally {
      setMarkingArrived(false);
    }
  };

  const showArrivedButton =
    washHub &&
    ['confirmed', 'valeter_assigned', 'en_route', 'scheduled'].includes(status);

  /** Wash hub: customer has arrived or wash in progress – hide navigate, disable cancel on ring */
  const washHubArrivedOrInProgress = washHub && (status === 'arrived' || status === 'in_progress');

  const onPressCancel = () => {
    Alert.alert(
      'Cancel booking?',
      'This will cancel your booking. If a valeter is already on the way, you may still be charged depending on your policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: () => { void cancelBooking(); } },
      ]
    );
  };

  const statusProgress = getStatusProgress(status);
  const stages = getStages(status);
  const stageProgressPercent = getStageProgressPercent(status);
  const statusMessage = getStatusMessage(status, washHub);

  // Dynamic Island / Live Activity (iOS): start once, then update on changes; end when done or unmount
  const liveActivityStartedRef = useRef(false);
  useEffect(() => {
    if (!booking?.id || status === 'completed' || status === 'cancelled' || status === 'valeter_declined' || status === 'valeter_timeout') {
      endLiveActivity();
      liveActivityStartedRef.current = false;
      return;
    }
    const serviceName = getServiceDisplayName(booking.service_type, booking.service_name);
    const locationName = booking.location_address || washHub?.name || '';
    const statusLabel = statusMessage;
    if (liveActivityStartedRef.current) {
      updateLiveActivity(booking.id, status, statusLabel, serviceName, locationName);
    } else {
      startLiveActivity(booking.id, status, statusLabel, serviceName, locationName);
      liveActivityStartedRef.current = true;
    }
  }, [booking?.id, status, booking?.service_type, booking?.service_name, booking?.location_address, washHub?.name, statusMessage]);

  useEffect(() => {
    return () => {
      endLiveActivity();
      liveActivityStartedRef.current = false;
    };
  }, []);

  const stepCard = getStepCardConfig(status, valeterName, washHub);
  const ringColor = getRingColorForStep(status);

  const mapRegion = booking ? region : liveRegion;
  const isLoading = !booking && !!bookingId;

  const locationDisplay = washHub ? washHub.name : (booking?.location_address || '—');

  const renderCardContent = () => {
    if (isLoading) {
      return (
        <View style={styles.emptyOverlay}>
          <UnifiedBookingCard stripColor={SKY} style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.loadingText}>Loading booking…</Text>
            </View>
          </UnifiedBookingCard>
        </View>
      );
    }
    if (!booking) {
      return (
        <View style={styles.emptyOverlay}>
          <View style={styles.emptyCardWrapper}>
            <UnifiedBookingCard stripColor={SKY} style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Active Booking</Text>
                <Text style={styles.emptyText}>
                  We couldn't find an active booking to track. Head to the home screen to book a wash.
                </Text>
                <TouchableOpacity
                  style={styles.backButton}
                  onPress={() => router.replace('/owner/owner-dashboard')}
                  activeOpacity={0.8}
                >
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.backButtonGradient}>
                    <Text style={styles.backButtonText}>Go to Dashboard</Text>
                    <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </UnifiedBookingCard>
            <PulsingBorderLoader color={SKY} borderRadius={BOOKING_CARD.BORDER_RADIUS} style={StyleSheet.absoluteFill} />
          </View>
        </View>
      );
    }
    return (
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            bottom: TAB_BAR_TOTAL_HEIGHT + Math.max(insets?.bottom ?? 0, 14) + BOOKING_INDEX_CARDS_BOTTOM_PADDING,
          },
        ]}
      >
        <View style={styles.cardWrapper}>
          <UnifiedBookingCard stripColor={SKY} intensity={28}>
            <View style={styles.trackingCard}>
              <LinearGradient
                colors={[colors.SKY + '06', colors.SKY + '03', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              <View style={styles.cardTopRow}>
                <View style={[styles.stepIconWrap, { backgroundColor: stepCard.stepAccent + '18' }]}>
                  <Ionicons name={stepCard.stepIcon} size={30} color={stepCard.stepAccent} />
                </View>
                <View style={styles.cardHeaderText}>
                  <Text style={styles.stepServiceLabel} numberOfLines={1}>
                    {getServiceDisplayName(booking.service_type, booking.service_name)}
                  </Text>
                  <Text style={[styles.stepTitle, { color: stepCard.stepAccent }]} numberOfLines={1}>
                    {stepCard.stepTitle}
                  </Text>
                  <Text style={styles.stepSubtitle} numberOfLines={2}>
                    {stepCard.stepSubtitle}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setInfoModalVisible(true);
                  }}
                  style={styles.infoBox}
                  activeOpacity={0.8}
                >
                  <View style={styles.infoBoxInner}>
                    <Ionicons name="information-circle-outline" size={22} color={SKY} />
                  </View>
                </TouchableOpacity>
              </View>
              <View style={styles.ringRow}>
                <View style={styles.ringCenter}>
                  <AnimatedProgress progress={statusProgress} size={80} strokeWidth={8} percentageFontSize={12} color={ringColor} colorCycle={[SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
                </View>
              </View>
              {status === 'pending_payment' && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    if (bookingId) router.push({ pathname: '/owner/booking/payment', params: { bookingId } } as any);
                  }}
                  style={styles.payButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient colors={[SKY, '#0EA5E9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.payButtonGradient}>
                    <Ionicons name="wallet" size={20} color="#FFFFFF" />
                    <Text style={styles.payButtonText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}
              {showArrivedButton && (
                <TouchableOpacity onPress={handleMarkArrived} disabled={markingArrived} style={styles.arrivedButton} activeOpacity={0.9}>
                  <LinearGradient colors={['#10B981', '#059669']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.arrivedButtonGradient}>
                    {markingArrived ? <ActivityIndicator size="small" color="#FFFFFF" /> : (
                      <>
                        <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.arrivedButtonText}>I've arrived</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              )}
              {status === 'in_progress' && (
                <View style={StyleSheet.absoluteFill} pointerEvents="none">
                  {BUBBLE_CONFIG.map((bubble, i) => (
                    <Animated.View
                      key={`bubble-${bubble.left}-${bubble.top}-${bubble.size}`}
                      style={[styles.bubble, { width: bubble.size, height: bubble.size, borderRadius: bubble.size / 2, left: `${bubble.left}%`, top: `${bubble.top}%`, transform: [{ translateY: bubbleAnims[i].y }] }]}
                    />
                  ))}
                </View>
              )}
              <View style={styles.cardProgressStrip}>
                <View style={styles.cardProgressTrack}>
                  <View style={[styles.cardProgressFill, { width: `${stageProgressPercent}%`, backgroundColor: ringColor }]} />
                </View>
                <View style={styles.cardProgressDots}>
                  {stages.map((stage) => (
                    <View key={stage.label} style={[styles.cardProgressDot, stage.done && styles.cardProgressDotDone, stage.current && styles.cardProgressDotCurrent]}>
                      {stage.done ? <Ionicons name="checkmark" size={8} color="#FFFFFF" /> : null}
                    </View>
                  ))}
                </View>
              </View>
            </View>
          </UnifiedBookingCard>
        </View>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[] as any}>
      <View style={{ flex: 1 }}>
      <View style={StyleSheet.absoluteFill}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        region={mapRegion ?? DEFAULT_MAP_REGION}
        showsUserLocation={true}
        showsMyLocationButton={false}
        customMapStyle={BOOKING_MAP_STYLE}
        userInterfaceStyle={MAP_LOCKED_DARK}
        mapPadding={{
            top: 0,
            right: 0,
            bottom: 220 + TAB_BAR_TOTAL_HEIGHT + Math.max(insets?.bottom ?? 0, 14) + BOOKING_INDEX_CARDS_BOTTOM_PADDING + 16,
            left: 0,
          }}
      >
          {/* Customer / job location – car.png, pulse only (no full colour) */}
          {booking?.location_lat && booking?.location_lng && (
            <Marker
              coordinate={{
                latitude: booking.location_lat,
                longitude: booking.location_lng,
              }}
              title="Your Location"
            >
              <Animated.View
                style={[styles.markerContainer, { transform: [{ scale: markerPulse }] }]}
              >
                <View style={styles.carMarkerWrap}>
                  <Image
                    source={CAR_IMAGE}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}

          {/* Valeter (pro) location – their icon, pulse only (no full colour) */}
          {valeterLocation && (
            <Marker coordinate={valeterLocation} title={valeterName}>
              <Animated.View
                style={[styles.markerContainer, { transform: [{ scale: markerPulse }] }]}
              >
                <View style={styles.valeterMarker}>
                  <Image
                    source={VALETER_MAP_IMAGE}
                    style={styles.valeterMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
              {(etaMins > 0 || distMiles > 0) && (
                <Callout tooltip>
                  <View style={styles.etaCallout}>
                    <Text style={styles.etaCalloutText}>~{etaMins} min</Text>
                    <Text style={styles.etaCalloutSubtext}>{distMiles.toFixed(1)} mi away</Text>
                  </View>
                </Callout>
              )}
            </Marker>
          )}

          {/* Wash hub / detail hub – pulse only (no full colour) */}
          {washHub?.latitude && washHub?.longitude && (
            <Marker
              coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}
              title={washHub.name}
            >
              <Animated.View
                style={[styles.markerContainer, { transform: [{ scale: markerPulse }] }]}
              >
                <View style={styles.hubMarkerPulse}>
                  <Image
                    source={
                      booking?.service_type?.toLowerCase().includes('detail') ||
                      (booking?.service_name && /detail|platinum/i.test(booking.service_name))
                        ? DETAILING_HUB_IMAGE
                        : CARWASH_IMAGE
                    }
                    style={styles.hubMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}
      </MapView>
      </View>

      {/* Left stack: Navigate (when applicable) above Recenter – leaves room for Chat & Cancel on the right */}
      {booking && (
        <View
          style={[
            styles.leftMapButtons,
            {
              top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS,
              left: RECENTER_BUTTON_LEFT,
            },
          ]}
          pointerEvents="box-none"
        >
          {washHub && booking?.location_lat != null && booking?.location_lng != null && !washHubArrivedOrInProgress && (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push({
                  pathname: '/owner/navigate',
                  params: {
                    destLat: String(booking.location_lat),
                    destLng: String(booking.location_lng),
                    address: (washHub?.name ?? booking?.location_address) || 'Service location',
                  },
                } as any);
              }}
              style={styles.mapActionBtn}
              activeOpacity={0.85}
            >
              <View style={styles.mapActionBtnInner}>
                <Ionicons name="navigate" size={24} color={SKY} />
              </View>
            </TouchableOpacity>
          )}
          {(valeterLocation || booking?.location_lat) && (
            <TouchableOpacity
              onPress={handleRecenterMap}
              style={styles.recenterButton}
              activeOpacity={0.85}
            >
              <View style={styles.recenterButtonInner}>
                <Ionicons name="locate" size={22} color={SKY} />
              </View>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* Chat & Cancel floating on map – mobile valeter tracking (no navigate) */}
      {booking && (
        <View style={[styles.mapActionButtons, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 16 }]} pointerEvents="box-none">
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              if (bookingId) router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
            }}
            style={styles.mapActionBtn}
            activeOpacity={0.85}
          >
            <View style={styles.mapActionBtnInner}>
              <Ionicons name="chatbubble-ellipses-outline" size={24} color={SKY} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              if (canCancel && !washHubArrivedOrInProgress) onPressCancel();
            }}
            disabled={!canCancel || cancelling || washHubArrivedOrInProgress}
            style={[styles.mapActionBtn, (!canCancel || washHubArrivedOrInProgress) && styles.mapActionBtnDisabled]}
            activeOpacity={0.85}
          >
            <View style={[styles.mapActionBtnInner, (!canCancel || washHubArrivedOrInProgress) && styles.mapActionBtnInnerDisabled]}>
              {cancelling ? (
                <ActivityIndicator size="small" color="#EF4444" />
              ) : (
                <Ionicons name="close-circle-outline" size={24} color={canCancel && !washHubArrivedOrInProgress ? '#EF4444' : '#64748B'} />
              )}
            </View>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.headerOverlay}>
        <AppHeader
          title="Tracking"
          subtitle="Your wash in progress"
          showBack
          onBack={() => { hapticFeedback('light'); router.back(); }}
          rightAction={
            <TouchableOpacity
              onPress={() => router.replace('/owner/owner-dashboard')}
              style={styles.headerExitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          }
        />
      </View>

      {renderCardContent()}

      {booking != null && (
        <>
          <SuccessOverlay
            visible={showCompletedConfetti}
            type="completed"
            message="Boom! You're super clean now"
            onComplete={() => {
              setShowCompletedConfetti(false);
              router.replace({
                pathname: '/owner/booking/completion',
                params: { bookingId, celebrated: '1' },
              } as any);
            }}
          />
          <ValeterDeclinedOverlay
            visible={showValeterDeclinedOverlay}
            onFindNewValeter={() => {
              setShowValeterDeclinedOverlay(false);
              void (async () => {
                try {
                  if (!bookingId) {
                    router.replace('/owner/owner-dashboard');
                    return;
                  }
                  const { error } = await supabase
                    .from('bookings')
                    .update({
                      status: 'pending_valeter_acceptance',
                      valeter_id: null,
                      request_sent_at: new Date().toISOString(),
                    })
                    .eq('id', bookingId);
                  if (error) throw error;
                  router.replace({ pathname: '/owner/booking/valeter-selection', params: { bookingId } } as any);
                } catch (e) {
                  console.error('Error reopening booking:', e);
                  router.replace('/owner/owner-dashboard');
                }
              })();
            }}
            onBackToDashboard={() => {
              setShowValeterDeclinedOverlay(false);
              router.replace('/owner/owner-dashboard');
            }}
          />
          <Modal
              visible={infoModalVisible}
              transparent
              animationType="fade"
              onRequestClose={() => setInfoModalVisible(false)}
            >
              <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
                <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
                  <View style={styles.infoModalHeader}>
                    <Text style={styles.infoModalTitle}>Booking Details</Text>
                    <TouchableOpacity
                      onPress={() => setInfoModalVisible(false)}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={24} color={customerTheme.primary} />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.infoModalBody}>
                    {/* Wash you're getting */}
                    <View style={styles.infoModalSection}>
                      <Text style={styles.infoModalSectionTitle}>Wash you're getting</Text>
                      <View style={styles.infoRow}>
                        <Ionicons name="water-outline" size={18} color={customerTheme.primary} />
                        <Text style={styles.infoText}>
                          {getServiceDisplayName(booking.service_type, booking.service_name)}
                        </Text>
                      </View>
                      <View style={styles.infoRow}>
                        <Ionicons name="cash-outline" size={18} color={customerTheme.primary} />
                        <Text style={styles.infoText}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
                      </View>
                    </View>
                    {/* Company profile card (wash hub) – same as dashboard info icon */}
                    {washHub && (
                      <View style={styles.infoModalSection}>
                        <Text style={styles.infoModalSectionTitle}>Wash Hub</Text>
                        <Text style={styles.washHubModalName}>{washHub.name}</Text>
                        {washHub.address ? (
                          <View style={styles.washHubModalAddressRow}>
                            <Ionicons name="location-outline" size={14} color={SKY} />
                            <Text style={styles.washHubModalAddress} numberOfLines={2}>{washHub.address}</Text>
                          </View>
                        ) : null}
                        {(washHub.rating != null || washHub.jobsCompleted != null) && (
                          <View style={styles.washHubModalStats}>
                            {washHub.rating != null && (
                              <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                                <Ionicons name="star" size={14} color="#FBBF24" />
                                <Text style={[styles.washHubModalStatText, { color: '#FBBF24' }]}>{Number(washHub.rating).toFixed(1)}</Text>
                              </View>
                            )}
                            {washHub.jobsCompleted != null && (
                              <View style={[styles.washHubModalStat, { backgroundColor: customerTheme.primary + '22' }]}>
                                <Ionicons name="car-outline" size={14} color={customerTheme.primary} />
                                <Text style={[styles.washHubModalStatText, { color: customerTheme.primary }]}>{washHub.jobsCompleted} washes</Text>
                              </View>
                            )}
                          </View>
                        )}
                        {washHub.joinedAt && (
                          <View style={styles.washHubModalJoinedRow}>
                            <Ionicons name="calendar-outline" size={14} color={SKY} />
                            <Text style={styles.washHubModalJoinedText}>
                              Joined {new Date(washHub.joinedAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                            </Text>
                          </View>
                        )}
                        {washHub.reviews && washHub.reviews.length > 0 ? (
                          <View style={styles.washHubModalSection}>
                            <Text style={styles.washHubModalSectionTitle}>Reviews</Text>
                            {washHub.reviews.slice(0, 3).map((rev, idx) => (
                              <View key={`rev-${idx}-${rev.rating}`} style={styles.washHubModalReviewItem}>
                                <View style={styles.washHubModalReviewHeader}>
                                  <Ionicons name="star" size={12} color="#FBBF24" />
                                  <Text style={styles.washHubModalReviewRating}>{rev.rating.toFixed(1)}</Text>
                                </View>
                                {rev.review ? <Text style={styles.washHubModalReviewText} numberOfLines={2}>{rev.review}</Text> : null}
                              </View>
                            ))}
                          </View>
                        ) : (
                          <View style={styles.washHubModalReviewsPlaceholder}>
                            <Ionicons name="chatbubble-ellipses-outline" size={24} color="rgba(148,163,184,0.6)" />
                            <Text style={styles.washHubModalPlaceholderText}>Reviews appear here when available</Text>
                          </View>
                        )}
                      </View>
                    )}
                    {/* Valeter & location when not wash hub */}
                    {!washHub && (
                      <>
                        {booking.valeter_id && (
                          <View style={styles.infoRow}>
                            <Ionicons name="person-outline" size={18} color={customerTheme.primary} />
                            <Text style={styles.infoText}>{valeterName}</Text>
                          </View>
                        )}
                        <View style={styles.infoRow}>
                          <Ionicons name="location-outline" size={18} color={customerTheme.primary} />
                          <Text style={styles.infoText}>{locationDisplay}</Text>
                        </View>
                      </>
                    )}
                    <View style={styles.infoModalProgress}>
                      <Text style={styles.infoModalProgressLabel}>Progress</Text>
                      <AnimatedProgress progress={statusProgress} size={80} percentageFontSize={12} />
                    </View>
                  </View>
                  {status === 'pending_payment' && (
                    <TouchableOpacity
                      onPress={() => {
                        setInfoModalVisible(false);
                        if (bookingId) {
                          router.push({ pathname: '/owner/booking/payment', params: { bookingId } } as any);
                        }
                      }}
                      style={styles.infoModalPayButton}
                      activeOpacity={0.9}
                    >
                      <LinearGradient
                        colors={[customerTheme.primary, customerTheme.skyBlue]}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.infoModalPayGradient}
                      >
                        <Ionicons name="wallet" size={20} color="#FFFFFF" />
                        <Text style={styles.infoModalPayText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    onPress={() => setInfoModalVisible(false)}
                    style={[styles.infoModalDone, status === 'pending_payment' && { marginTop: 8 }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </Pressable>
              </Pressable>
            </Modal>
        </>
      )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  bubble: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.45)',
    shadowColor: '#fff',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 2,
    elevation: 1,
  },
  cardProgressStrip: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
    paddingTop: 10,
    marginTop: 12,
    paddingHorizontal: 4,
    paddingBottom: 4,
  },
  cardProgressTrack: {
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 8,
  },
  cardProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  cardProgressDots: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  cardProgressDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(100,116,139,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardProgressDotDone: {
    backgroundColor: '#10B981',
  },
  cardProgressDotCurrent: {
    backgroundColor: SKY,
  },
  headerProgressStrip: {
    paddingHorizontal: 24,
    paddingTop: 4,
    paddingBottom: 6,
    backgroundColor: 'rgba(10,25,41,0.75)',
  },
  headerProgressTrack: {
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 6,
  },
  headerProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  headerProgressDots: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  headerProgressDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(100,116,139,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerProgressDotDone: {
    backgroundColor: '#10B981',
  },
  headerProgressDotCurrent: {
    backgroundColor: SKY,
  },
  headerExitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 25, 41, 0.7)',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  emptyOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    padding: 20,
  },
  emptyCardWrapper: {
    position: 'relative',
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyCard: {
    padding: 40,
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  backButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  backButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  carMarkerWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterMarker: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubMarkerPulse: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerPulse: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: SKY,
    opacity: 0.25,
  },
  carMarkerImage: {
    width: 32,
    height: 32,
  },
  valeterMarkerImage: {
    width: 36,
    height: 36,
  },
  hubMarkerImage: {
    width: 44,
    height: 44,
  },
  leftMapButtons: {
    position: 'absolute',
    zIndex: 100,
    flexDirection: 'column',
    gap: 8,
  },
  recenterButton: {},
  recenterButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  etaCallout: {
    backgroundColor: 'rgba(15,23,42,0.95)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    minWidth: 80,
    alignItems: 'center',
  },
  etaCalloutText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  etaCalloutSubtext: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  mapActionButtons: {
    position: 'absolute',
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: {
    width: 48,
    height: 48,
  },
  mapActionBtnDisabled: {
    opacity: 0.6,
  },
  mapActionBtnInner: {
    width: '100%',
    height: '100%',
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.25)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  cardWrapper: {
    width: '100%',
    maxWidth: CARD_WIDTH,
    position: 'relative',
  },
  trackingCard: {
    padding: 24,
    minHeight: 220,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
  },
  cardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    minWidth: 0,
  },
  cardHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  ringRow: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  ringCenter: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  stagesWrapper: {
    marginTop: 16,
    width: '100%',
    maxWidth: 260,
    alignSelf: 'center',
  },
  stagesTrack: {
    height: 4,
    backgroundColor: 'rgba(148,163,184,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 14,
  },
  stagesTrackFill: {
    height: '100%',
    borderRadius: 2,
  },
  stagesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  stageItem: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
  },
  stageDotWrap: {
    width: 28,
    height: 28,
    borderRadius: 18,
    backgroundColor: 'rgba(100,116,139,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  stageDotWrapDone: {
    backgroundColor: '#10B981',
    borderWidth: 0,
    borderColor: 'transparent',
  },
  stageDotWrapCurrent: {
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderColor: SKY,
    borderWidth: 2.5,
  },
  stageDotCheck: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  stageDotIcon: {
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.8,
  },
  stageDotIconCurrent: {
    opacity: 1,
  },
  stageLabelWrap: {
    paddingHorizontal: 4,
    paddingVertical: 4,
    borderRadius: 8,
  },
  stageLabelWrapCurrent: {
    backgroundColor: SKY + '20',
  },
  stageLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    textAlign: 'center',
  },
  stageLabelDone: {
    color: '#10B981',
    fontWeight: '700',
  },
  stageLabelCurrent: {
    color: SKY,
    fontWeight: '800',
    fontSize: 12,
  },
  ringSideButton: {
    width: 44,
    height: 44,
  },
  ringSideButtonDisabled: {
    opacity: 0.5,
  },
  ringSideButtonInner: {
    width: '100%',
    height: '100%',
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringSideButtonInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.2)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  payButton: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 8,
  },
  payButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  navigateButton: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 8,
  },
  navigateButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  navigateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  arrivedButton: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 8,
  },
  arrivedButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  arrivedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  trackingIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackingIcon: {
    width: 24,
    height: 24,
  },
  stepIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  stepServiceLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  stepTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  stepSubtitle: {
    color: '#94A3B8',
    fontSize: 15,
    fontWeight: '500',
    lineHeight: 20,
  },
  trackingServiceName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  trackingStatusMessage: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
  },
  infoBox: {
    width: 40,
    height: 40,
  },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 18,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: 'transparent',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  infoModalTitle: {
    color: customerTheme.primary,
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: {
    gap: 10,
    marginBottom: 18,
  },
  infoModalSection: {
    marginTop: 4,
  },
  infoModalSectionTitle: {
    color: customerTheme.primary,
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 8,
  },
  washHubModalName: {
    color: colors.headerSubtext,
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  washHubModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalAddress: {
    color: colors.headerSubtext,
    fontSize: 14,
    flex: 1,
    opacity: 0.9,
  },
  washHubModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  washHubModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  washHubModalStatText: {
    fontSize: 12,
    fontWeight: '700',
  },
  washHubModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalJoinedText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  washHubModalSection: {
    marginTop: 4,
  },
  washHubModalSectionTitle: {
    color: colors.headerSubtext,
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 8,
  },
  washHubModalReviewItem: {
    padding: 10,
    marginBottom: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  washHubModalReviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  washHubModalReviewRating: {
    color: '#FBBF24',
    fontSize: 12,
    fontWeight: '700',
  },
  washHubModalReviewText: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 18,
    opacity: 0.9,
  },
  washHubModalReviewsPlaceholder: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    gap: 6,
  },
  washHubModalPlaceholderText: {
    color: colors.headerSubtext,
    fontSize: 13,
    opacity: 0.7,
  },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '20',
  },
  infoModalProgressLabel: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  infoModalPayButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  infoModalPayGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  infoModalPayText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDone: {
    backgroundColor: customerTheme.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: {
    color: colors.headerSubtext,
    fontSize: 13,
    flex: 1,
    opacity: 0.95,
  },
  cancelButton: {
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.5)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
    marginTop: 12,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
