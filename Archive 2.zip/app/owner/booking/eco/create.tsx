import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import InfoIconButton from '@/components/shared/InfoIconButton';
import { VehicleInfoOverlay } from '@/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '@/utils/vehicleStats';
import { ecoServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const ECO_GREEN = colors.ECO_GREEN;

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  photo?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  mileage?: string | number | null;
};

export default function EcoCreate() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const deliveryType = params.deliveryType as string; // 'comeToYou' or 'goToThem'
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    // Reset wash type when service changes
    if (serviceId !== 'eco-bronze-wash') {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const handleContinue = async () => {
    if (!selectedService || !selectedVehicle) {
      return;
    }
    // Require wash type selection for eco bronze wash
    if (selectedService === 'eco-bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');

    // Route to location selection for both delivery types
    router.push({
      pathname: '/owner/booking/eco/location',
      params: {
        deliveryType: deliveryType || 'goToThem',
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        washType: washType || '',
      },
    });
  };

  const selectedServiceData = ecoServiceOptions.find(s => s.id === selectedService);

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader title="Eco Wash Service" showBack onBack={() => { hapticFeedback('light'); router.back(); }} />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Service Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Service</Text>
            <Text style={styles.sectionSubtitle}>Choose your eco-friendly package</Text>
            
            <View style={styles.serviceGrid}>
              {ecoServiceOptions.map((service, index) => {
                const isSelected = selectedService === service.id;
                const priceRange = service.minPrice && service.maxPrice 
                  ? `£${service.minPrice}-${service.maxPrice}`
                  : `£${service.price}`;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      {
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(16,185,129,0.3)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '30', service.colors[1] + '20'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceContent}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={26} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceDetails}>
                          <Text
                            style={[styles.serviceName, isSelected && { color: service.colors[0] }]}
                            numberOfLines={1}
                          >
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={ECO_GREEN} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>
                        <View style={styles.priceColumn}>
                          <Text style={styles.priceLabel}>From</Text>
                          <Text style={[styles.servicePriceText, isSelected && { color: service.colors[0] }]}>
                            {priceRange}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: service.colors[0] }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {/* Wash Type Selection for Eco Bronze Wash */}
          {selectedService === 'eco-bronze-wash' && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Select Wash Type</Text>
              <Text style={styles.sectionSubtitle}>Choose what you'd like cleaned</Text>
              
              <View style={styles.washTypeGrid}>
                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('exterior')}
                  style={[styles.washTypeCard, washType === 'exterior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'exterior' ? [ECO_GREEN + '30', ECO_GREEN + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="car-sport-outline" 
                      size={32} 
                      color={washType === 'exterior' ? ECO_GREEN : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'exterior' && { color: ECO_GREEN }]}>
                      Exterior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{selectedServiceData?.price || 18}</Text>
                  </View>
                  {washType === 'exterior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: ECO_GREEN }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('interior')}
                  style={[styles.washTypeCard, washType === 'interior' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'interior' ? [ECO_GREEN + '30', ECO_GREEN + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="home-outline" 
                      size={32} 
                      color={washType === 'interior' ? ECO_GREEN : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'interior' && { color: ECO_GREEN }]}>
                      Interior Only
                    </Text>
                    <Text style={styles.washTypePrice}>£{selectedServiceData?.price || 18}</Text>
                  </View>
                  {washType === 'interior' && (
                    <View style={[styles.selectedBadge, { backgroundColor: ECO_GREEN }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('both')}
                  style={[styles.washTypeCard, washType === 'both' && styles.washTypeCardSelected]}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={washType === 'both' ? [ECO_GREEN + '30', ECO_GREEN + '20'] : ['transparent', 'transparent']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.washTypeContent}>
                    <Ionicons 
                      name="sparkles-outline" 
                      size={32} 
                      color={washType === 'both' ? ECO_GREEN : '#9CA3AF'} 
                    />
                    <Text style={[styles.washTypeTitle, washType === 'both' && { color: ECO_GREEN }]}>
                      Both
                    </Text>
                    <Text style={styles.washTypePrice}>£{(selectedServiceData?.price || 18) * 1.5}</Text>
                    <View style={styles.premiumBadge}>
                      <Text style={styles.premiumBadgeText}>Premium</Text>
                    </View>
                  </View>
                  {washType === 'both' && (
                    <View style={[styles.selectedBadge, { backgroundColor: ECO_GREEN }]}>
                      <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Vehicle Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Vehicle</Text>
            <Text style={styles.sectionSubtitle}>Choose the vehicle for this service</Text>
            
            {loading ? (
              <View style={styles.loadingContainer}>
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="car-outline" size={48} color={ECO_GREEN} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <TouchableOpacity
                    onPress={() => router.push('/owner/settings/vehicle-management')}
                    style={styles.addVehicleButton}
                  >
                    <Text style={styles.addVehicleText}>Add Vehicle</Text>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ) : (
              <View style={styles.vehicleList}>
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <GlassCard
                      key={vehicle.id}
                      onPress={() => {
                        hapticFeedback('light');
                        setSelectedVehicle(vehicle.id);
                      }}
                      style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                      borderColor={isSelected ? ECO_GREEN : 'rgba(16,185,129,0.3)'}
                    >
                      <View style={styles.vehicleContent}>
                        <View style={styles.vehicleInfoIconWrap}>
                          <InfoIconButton onPress={() => openVehicleInfo(vehicle)} accentColor={ECO_GREEN} />
                        </View>
                        <View style={styles.vehicleIconWrapper}>
                          <Ionicons name="car-sport" size={24} color={ECO_GREEN} />
                        </View>
                        <View style={styles.vehicleInfo}>
                          <Text style={styles.vehicleName}>
                            {vehicle.make} {vehicle.model}
                          </Text>
                          <Text style={styles.vehicleDetails}>
                            {vehicle.color} • {vehicle.registration}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={styles.selectedCheck}>
                            <Ionicons name="checkmark-circle" size={24} color={ECO_GREEN} />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
            )}
          </View>

          {/* Continue Button */}
          {selectedService && selectedVehicle && (selectedService !== 'eco-bronze-wash' || washType) && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[ECO_GREEN, '#059669']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>

      <VehicleInfoOverlay
        visible={!!infoVehicle}
        vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: infoVehicle.mot_expiry ?? null, mot_expiry_date: infoVehicle.mot_expiry_date ?? null, mileage: infoVehicle.mileage ?? null, tax_status: (infoVehicle as any).tax_status ?? null, tax_due_date: (infoVehicle as any).tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
        stats={vehicleStats}
        accentColor={ECO_GREEN}
        onClose={() => setInfoVehicle(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: ECO_GREEN,
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  serviceGrid: {
    gap: 16,
  },
  serviceCardWrapper: {
    width: '100%',
  },
  serviceCard: {
    padding: 16,
  },
  serviceCardSelected: {
    elevation: 4,
    shadowColor: ECO_GREEN,
    shadowOpacity: 0.18,
    shadowRadius: 8,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  serviceIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceDetails: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'left',
  },
  serviceDesc: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
    lineHeight: 16,
  },
  serviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 0,
  },
  serviceMetaText: {
    color: ECO_GREEN,
    fontSize: 10,
  },
  priceColumn: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    minWidth: 70,
  },
  priceLabel: {
    color: '#94A3B8',
    fontSize: 12,
    marginBottom: 4,
  },
  servicePriceText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleList: {
    gap: 12,
  },
  vehicleCard: {
    padding: 16,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: ECO_GREEN,
    shadowOpacity: 0.4,
  },
  vehicleContent: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  vehicleInfoIconWrap: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 1,
  },
  vehicleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  vehicleDetails: {
    color: ECO_GREEN,
    fontSize: 12,
  },
  selectedCheck: {
    marginLeft: 'auto',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    color: ECO_GREEN,
    fontSize: 14,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    marginTop: 12,
    marginBottom: 20,
  },
  addVehicleButton: {
    backgroundColor: ECO_GREEN,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  washTypeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  washTypeCard: {
    flex: 1,
    minWidth: (width - 52) / 3,
    borderRadius: 18,
    padding: 16,
    borderWidth: 2,
    borderColor: 'rgba(16,185,129,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    position: 'relative',
  },
  washTypeCardSelected: {
    borderColor: ECO_GREEN,
    elevation: 8,
    shadowColor: ECO_GREEN,
    shadowOpacity: 0.4,
  },
  washTypeContent: {
    alignItems: 'center',
    gap: 8,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  washTypePrice: {
    color: ECO_GREEN,
    fontSize: 16,
    fontWeight: 'bold',
  },
  premiumBadge: {
    marginTop: 4,
    backgroundColor: ECO_GREEN + '20',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  premiumBadgeText: {
    color: ECO_GREEN,
    fontSize: 10,
    fontWeight: '600',
  },
});

