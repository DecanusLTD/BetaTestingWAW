import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../../src/constants/customerTheme';

import { colors } from '../../../../src/constants/colors';

const ECO_GREEN = colors.ECO_GREEN;

export default function EcoConfirmation() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ bookingId?: string }>();
  const bookingId = params.bookingId as string | undefined;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Eco booking confirmed" showBack={false} />

      <View style={styles.content}>
        <View style={styles.iconWrapper}>
          <Ionicons name="leaf" size={40} color={ECO_GREEN} />
        </View>
        <Text style={styles.title}>You're all set!</Text>
        <Text style={styles.subtitle}>
          Drive to the selected eco hub at your chosen time. Show this booking to the concierge for priority service.
        </Text>
        <View style={styles.ecoBadge}>
          <Ionicons name="leaf" size={16} color={ECO_GREEN} />
          <Text style={styles.ecoBadgeText}>100% Eco-Friendly</Text>
        </View>
        {bookingId && (
          <View style={styles.bookingTag}>
            <Text style={styles.bookingTagText}>Booking ID: {bookingId.slice(0, 8)}</Text>
          </View>
        )}
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={styles.primaryButton}
          onPress={() => router.replace('/owner/wash-history')}
        >
          <Text style={styles.primaryText}>View my bookings</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => router.replace('/owner/owner-dashboard')}
        >
          <Text style={styles.secondaryText}>Back to dashboard</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    gap: 16,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  iconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: ECO_GREEN,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
  },
  subtitle: {
    color: 'rgba(249,250,251,0.8)',
    textAlign: 'center',
    lineHeight: 20,
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  ecoBadgeText: {
    color: ECO_GREEN,
    fontSize: 14,
    fontWeight: '700',
  },
  bookingTag: {
    marginTop: 8,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  bookingTagText: {
    color: '#E5E7EB',
    fontSize: 13,
    letterSpacing: 0.5,
  },
  footer: {
    paddingHorizontal: 20,
    gap: 12,
  },
  primaryButton: {
    borderRadius: 18,
    backgroundColor: ECO_GREEN,
    paddingVertical: 14,
    alignItems: 'center',
  },
  primaryText: {
    color: '#0A1929',
    fontWeight: '700',
    fontSize: 16,
  },
  secondaryButton: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 14,
    alignItems: 'center',
  },
  secondaryText: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 16,
  },
});

