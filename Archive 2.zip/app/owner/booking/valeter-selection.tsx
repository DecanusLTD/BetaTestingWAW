import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { BOOKING_CARD, CURVED_BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { HEADER_BORDER_RADIUS } from '../../../src/constants/layoutConstants';
import { getActiveBookingForCustomer } from '../../../src/utils/activeBookingGuard';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, MAP_CAMERA_ANIMATION_DURATION, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { CAR_IMAGE, VALETER_IMAGE, VALETER_MAP_IMAGE } from '../../assets/assetExports';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';

const { width, height: windowHeight } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
  isVerified?: boolean;
  responseTime?: number;
  eta?: number;
  vehicleRegistration?: string;
  vehicleType?: string;
  providesWater?: boolean;
  providesElectricity?: boolean;
}

type ReassignBooking = {
  id: string;
  service_type: string;
  service_name: string | null;
  location_lat: number | null;
  location_lng: number | null;
  location_address: string | null;
};

function toFiniteOrNull(value: unknown): number | null {
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''));
  return Number.isFinite(n) ? n : null;
}

const ValeterMapMarker = memo(function ValeterMapMarker({
  valeter,
  isSelected,
  onSelect,
}: {
  valeter: Valeter;
  isSelected: boolean;
  onSelect: (id: string) => void;
}) {
  const handlePress = useCallback(() => {
    onSelect(valeter.id);
  }, [valeter.id, onSelect]);
  if (valeter.lastLat == null || valeter.lastLng == null) return null;
  return (
    <Marker
      coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
      onPress={handlePress}
    >
      <View style={[
        styles.valeterMarkerContainer,
        { transform: [{ scale: isSelected ? 1.15 : 1 }], opacity: isSelected ? 1 : 0.6 },
        isSelected && styles.valeterMarkerSelectedGlow,
      ]}>
        <Image
          source={VALETER_MAP_IMAGE}
          style={[styles.valeterMarker, isSelected && styles.valeterMarkerSelected]}
          resizeMode="contain"
        />
        {valeter.isOnline && (
          <View style={styles.valeterOnlineBadge}>
            <View style={styles.valeterOnlineDot} />
          </View>
        )}
      </View>
    </Marker>
  );
});

export default function ValeterSelection() {
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const valeterCardWidth =
    Math.min(adaptive.contentMaxWidth, adaptive.width) - adaptive.horizontalPadding * 2;
  const valeterSnapInterval = valeterCardWidth + 12;
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingIdParam = params.bookingId as string | undefined;
  const serviceId = params.serviceId as string;
  const paramLat = toFiniteOrNull(params.latitude as string);
  const paramLng = toFiniteOrNull(params.longitude as string);
  const address = params.address as string;
  const customerOffersWater = params.customerOffersWater === 'true';
  const customerOffersElectricity = params.customerOffersElectricity === 'true';
  const discountAmount = Number.parseFloat(params.discountAmount as string) || 0;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;
  const addOnIds = (params.addOnIds as string) || '';
  const addOnsTotal = Number.parseFloat((params.addOnsTotal as string) || '0') || 0;
  const preferredValeterId = (params.preferredValeterId as string) || null;

  const [reassignBooking, setReassignBooking] = useState<ReassignBooking | null>(null);
  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [showConfirmValeterModal, setShowConfirmValeterModal] = useState(false);
  const [sendingRequest, setSendingRequest] = useState(false);
  const [loading, setLoading] = useState(true);
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);

  const effectiveServiceId = reassignBooking?.service_type ?? serviceId;
  const latitude =
    toFiniteOrNull(center?.lat) ??
    toFiniteOrNull(reassignBooking?.location_lat) ??
    paramLat ??
    toFiniteOrNull(liveCoords?.latitude) ??
    0;
  const longitude =
    toFiniteOrNull(center?.lng) ??
    toFiniteOrNull(reassignBooking?.location_lng) ??
    paramLng ??
    toFiniteOrNull(liveCoords?.longitude) ??
    0;

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const searchRingRotate = useRef(new Animated.Value(0)).current;

  // Reassign mode: load existing booking when only bookingId is passed (e.g. after valeter declined/cancelled)
  useEffect(() => {
    if (!bookingIdParam || !user?.id) return;
    let cancelled = false;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, service_type, service_name, location_lat, location_lng, location_address')
          .eq('id', bookingIdParam)
          .eq('user_id', user.id)
          .single();
        if (cancelled || error || !data) {
          if (!cancelled) setLoading(false);
          return;
        }
        const b = data as ReassignBooking;
        setReassignBooking(b);
        if (b.location_lat != null && b.location_lng != null) {
          setCenter({ lat: b.location_lat, lng: b.location_lng });
          setRegion({ latitude: b.location_lat, longitude: b.location_lng, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        }
      } catch {
        if (!cancelled) setLoading(false);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [bookingIdParam, user?.id]);

  useEffect(() => {
    if (bookingIdParam) return;
    const lat = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLat : liveCoords?.latitude;
    const lng = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLng : liveCoords?.longitude;
    if (lat != null && lng != null) {
      setCenter({ lat, lng });
      setRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else if (liveCoords) {
      setCenter({ lat: liveCoords.latitude, lng: liveCoords.longitude });
      setRegion({ latitude: liveCoords.latitude, longitude: liveCoords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          setCenter({ lat: loc.coords.latitude, lng: loc.coords.longitude });
          setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        })
        .catch(() => {});
    }
  }, [bookingIdParam, paramLat, paramLng, liveCoords]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    loadNearbyValeters();
    // We intentionally include center so distance re-computes when customer location resolves.
  }, [user?.id, center]);

  // Pre-select preferred valeter when coming from Explore favourites
  useEffect(() => {
    if (!preferredValeterId || valeters.length === 0) return;
    const found = valeters.some((v) => v.id === preferredValeterId);
    if (found) setSelectedValeter(preferredValeterId);
  }, [preferredValeterId, valeters]);

  // Continuous search ring animation when no valeters available
  useEffect(() => {
    if (valeters.length > 0 || loading) return;
    searchRingRotate.setValue(0);
    const loop = Animated.loop(
      Animated.timing(searchRingRotate, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [valeters.length, loading]);

  const searchRingSpin = searchRingRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  // Fit map so user and all valeter locations are always visible above the card
  const mapPaddingBottom = Math.round(windowHeight * 0.48);
  useEffect(() => {
    if (!center) return;
    const coords: { latitude: number; longitude: number }[] = [{ latitude: center.lat, longitude: center.lng }];
    valeters.forEach((v) => {
      if (v.lastLat != null && v.lastLng != null) coords.push({ latitude: v.lastLat, longitude: v.lastLng });
    });
    const t = setTimeout(() => {
      mapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 100, right: 48, bottom: mapPaddingBottom, left: 48 },
        animated: true,
      });
    }, 400);
    return () => clearTimeout(t);
  }, [center, valeters.map((v) => `${v.lastLat}-${v.lastLng}`).join(','), mapPaddingBottom]);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, verification_status, is_self_sufficient')
        .in('user_id', userIds);
      if (profilesError) {
        console.warn('[valeter-selection] profiles fetch failed; continuing without profile data', profilesError);
      }

      const { data: vehiclesData, error: vehiclesError } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, type')
        .in('user_id', userIds)
        .eq('is_default', true);
      if (vehiclesError) {
        console.warn('[valeter-selection] vehicle fetch failed; continuing without vehicle data', vehiclesError);
      }

      const statsPromises = userIds.map(userId =>
        ValeterStatsService.getValeterStats(userId).catch(() => null)
      );
      const statsResults = await Promise.all(statsPromises);
      const statsMap = new Map(
        userIds.map((userId, index) => [userId, statsResults[index]])
      );

      const valetersList: Valeter[] = await Promise.all(
        presenceData.map(async (presence) => {
          const profile = (profilesData || []).find(p => p.user_id === presence.user_id);
          const hasValeterCoords =
            Number.isFinite(presence.last_lat as number) && Number.isFinite(presence.last_lng as number);
          const hasCustomerCoords = Number.isFinite(latitude) && Number.isFinite(longitude);
          const distance = hasValeterCoords && hasCustomerCoords
            ? calculateDistance(latitude, longitude, presence.last_lat as number, presence.last_lng as number)
            : 999;

          const stats = statsMap.get(presence.user_id);
          const displayName = profile?.full_name || 'Valeter';
          const isVerified = profile?.verification_status === 'verified';
          const vehicle = (vehiclesData || []).find(v => v.user_id === presence.user_id);
          const estimatedETA = Math.round(distance * 2);
          const isSelfSufficient = Boolean((profile as any)?.is_self_sufficient);

          return {
            id: presence.user_id,
            name: displayName,
            rating: stats?.averageRating || 0,
            totalJobs: stats?.totalJobs || 0,
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
            isVerified: isVerified,
            responseTime: 5,
            eta: estimatedETA,
            vehicleRegistration: vehicle?.registration,
            vehicleType: vehicle?.type,
            providesWater: isSelfSufficient,
            providesElectricity: isSelfSufficient,
          };
        })
      );

      const nearbyValeters = valetersList
        .filter((v) => Number.isFinite(v.distance) && v.distance <= 10)
        .sort((a, b) => a.distance - b.distance);
      const onlineWithCoords = valetersList
        .filter((v) => Number.isFinite(v.distance) && v.distance < 999)
        .sort((a, b) => a.distance - b.distance);
      const onlineWithoutCoords = valetersList
        .filter((v) => !Number.isFinite(v.distance) || v.distance >= 999);

      const filteredValeters = nearbyValeters.length > 0
        ? nearbyValeters
        : [...onlineWithCoords, ...onlineWithoutCoords];

      setValeters(filteredValeters);
    } catch (error) {
      const errorService = await import('../../../src/services/ErrorHandlingService').then(m => m.errorHandlingService);
      errorService.handleBookingError(error as Error, 'valeter_selection');
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    setSelectedValeter(valeterId);
    const v = valeters.find((x) => x.id === valeterId);
    if (v?.lastLat != null && v?.lastLng != null && mapRef.current) {
      const r = { latitude: v.lastLat, longitude: v.lastLng, latitudeDelta: 0.001, longitudeDelta: 0.001 };
      setRegion(r);
      mapRef.current.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
    }
  };

  const selectedServiceOption = serviceOptions.find((option) => option.id === effectiveServiceId);

  const handleContinue = async () => {
    if (!selectedValeter || !user?.id) return;
    if (!reassignBooking && !selectedServiceOption) return;
    await hapticFeedback('medium');

    if (!reassignBooking) {
      const active = await getActiveBookingForCustomer(user.id);
      if (active) {
        Alert.alert(
          'One booking at a time',
          'You already have an active booking. Please complete or cancel it before starting a new one.',
          [
            { text: 'OK', style: 'cancel' },
            { text: 'View my booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
          ]
        );
        return;
      }
    }

    try {
      if (reassignBooking) {
        const { error } = await supabase
          .from('bookings')
          .update({
            valeter_id: selectedValeter,
            status: 'pending_valeter_acceptance',
            request_sent_at: new Date().toISOString(),
          })
          .eq('id', reassignBooking.id)
          .eq('user_id', user.id);
        if (error) throw error;
        router.push({
          pathname: '/owner/booking/waiting-acceptance',
          params: { bookingId: reassignBooking.id },
        });
        return;
      }

      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption!.price || 25;
      const serviceTotal = basePrice - discountAmount;
      const finalPrice = serviceTotal + addOnsTotal;

      const insertRow: Record<string, unknown> = {
        user_id: user.id,
        valeter_id: selectedValeter,
        service_type: serviceId,
        service_name: selectedServiceOption!.name || serviceId,
        status: 'pending_valeter_acceptance',
        price: finalPrice,
        location_address: address,
        location_lat: latitude,
        location_lng: longitude,
        customer_offers_water: customerOffersWater,
        customer_offers_electricity: customerOffersElectricity,
        discount_amount: discountAmount,
        wash_type: washType,
        request_sent_at: new Date().toISOString(),
        scheduled_at: scheduledAt,
      };
      if (addOnIds) insertRow.add_on_ids = addOnIds;
      if (addOnsTotal > 0) insertRow.add_ons_total = addOnsTotal;

      let result = await supabase.from('bookings').insert(insertRow).select().single();
      if (result.error && (result.error.message?.includes('add_on') || result.error.message?.includes('add_ons'))) {
        delete insertRow.add_on_ids;
        delete insertRow.add_ons_total;
        result = await supabase.from('bookings').insert(insertRow).select().single();
      }
      const { data, error } = result;

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      setSendingRequest(false);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  const handleConfirmValeterPress = () => {
    if (!selectedValeter) return;
    setShowConfirmValeterModal(true);
  };

  const handleSendRequest = () => {
    if (sendingRequest) return;
    setSendingRequest(true);
    setShowConfirmValeterModal(false);
    handleContinue();
  };

  const renderValeterStats = (valeter: Valeter) => {
    const ratingText = valeter.rating > 0 ? `${valeter.rating.toFixed(1)}` : 'New';
    const jobsText = `${valeter.totalJobs} ${valeter.totalJobs === 1 ? 'job' : 'jobs'} completed`;
    const distanceText = `${valeter.distance.toFixed(1)} mi`;
    const etaText = valeter.eta && valeter.eta > 0 ? `${valeter.eta} min` : null;

    return (
      <View style={styles.uberValeterStats}>
        <View style={styles.uberStatItem}>
          <Ionicons name="star" size={14} color="#FBBF24" />
          <Text style={styles.uberStatText}>{ratingText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="checkmark-done-outline" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{jobsText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="location" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{distanceText}</Text>
        </View>
        {etaText && (
          <View style={styles.uberStatItem}>
            <Ionicons name="time" size={14} color="#60A5FA" />
            <Text style={[styles.uberStatText, { color: '#60A5FA' }]}>{etaText}</Text>
          </View>
        )}
      </View>
    );
  };

  let valeterHeaderSubtitle: string;
  if (loading) valeterHeaderSubtitle = 'Searching for valeters…';
  else if (valeters.length === 0) valeterHeaderSubtitle = 'No valeters in your area';
  else valeterHeaderSubtitle = "We've found nearby valeters";

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          mapPadding={{ top: 0, right: 0, bottom: Math.round(windowHeight * 0.48), left: 0 }}
        >
          {center && (
            <Marker coordinate={{ latitude: center.lat, longitude: center.lng }}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {valeters.map((valeter) => (
            <ValeterMapMarker
              key={valeter.id}
              valeter={valeter}
              isSelected={selectedValeter === valeter.id}
              onSelect={handleValeterSelect}
            />
          ))}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          let lat = liveCoords?.latitude ?? latitude;
          let lng = liveCoords?.longitude ?? longitude;
          if (lat == null || lng == null || !Number.isFinite(lat) || !Number.isFinite(lng)) {
            try {
              const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              lat = loc.coords.latitude;
              lng = loc.coords.longitude;
            } catch {}
          }
          if (lat != null && lng != null && Number.isFinite(lat) && Number.isFinite(lng)) {
            const r = { latitude: lat, longitude: lng, latitudeDelta: 0.001, longitudeDelta: 0.001 };
            setRegion(r);
            mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Confirm your valeter"
        subtitle={valeterHeaderSubtitle}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            top: windowHeight * 0.52,
            paddingHorizontal: adaptive.horizontalPadding,
            paddingBottom: 56 + Math.max(insets.bottom, 14) + 12 + TAB_BAR_TOTAL_HEIGHT,
          },
        ]}
      >
        {(() => {
          if (loading || valeters.length === 0) {
            return (
              <View style={[styles.cardWrapper, { width: valeterCardWidth, marginRight: 0 }]}>
                <UnifiedBookingCard stripColor={SKY} intensity={18}>
                  <View style={[styles.valeterCard, styles.searchStateCard]}>
                    <View style={styles.loadingContainer}>
                      {loading ? (
                        <ActivityIndicator size="large" color={SKY} />
                      ) : (
                        <View style={styles.searchRingWrap}>
                          <Animated.View
                            style={[
                              styles.searchRingOuter,
                              { transform: [{ rotate: searchRingSpin }] },
                            ]}
                          />
                          <View style={styles.searchRingInner}>
                            <Ionicons name="search" size={28} color={SKY} />
                          </View>
                        </View>
                      )}
                      <Text style={styles.loadingText}>
                        {loading ? 'Searching for valeters…' : 'Searching for a valeter'}
                      </Text>
                      <Text style={styles.loadingSubtext}>
                        {loading ? "Checking who's available near you" : "We'll keep looking in your area"}
                      </Text>
                    </View>
                  </View>
                </UnifiedBookingCard>
              </View>
            );
          }
          return (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={valeterSnapInterval}
              decelerationRate="fast"
              pagingEnabled
            >
              {valeters.map((valeter, index) => {
                const isSelected = selectedValeter === valeter.id;
                const isBestMatch = index === 0;
                const arrivalMins = valeter.eta && valeter.eta > 0 ? valeter.eta : Math.max(2, Math.round(valeter.distance * 2));
                return (
                  <View key={valeter.id} style={[styles.cardWrapper, { width: valeterCardWidth }]}>
                    <UnifiedBookingCard
                      stripColor={SKY}
                      intensity={18}
                      onPress={() => handleValeterSelect(valeter.id)}
                    >
                    {isBestMatch && (
                      <View style={styles.bestMatchBadge}>
                        <Ionicons name="star" size={12} color="#FBBF24" />
                        <Text style={styles.bestMatchText}>Best match for you</Text>
                      </View>
                    )}
                    {isSelected && (
                      <LinearGradient
                        colors={[SKY + '15', SKY + '08', 'transparent']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                    )}
                    <View style={[styles.valeterCard, isSelected && styles.valeterCardSelected]}>
                      <View style={styles.valeterCardTop}>
                        <View style={styles.valeterAvatarWrap}>
                          {valeter.profilePicture ? (
                            <Image source={{ uri: valeter.profilePicture }} style={styles.valeterAvatar} />
                          ) : (
                            <Image source={VALETER_IMAGE} style={styles.valeterAvatar} resizeMode="cover" />
                          )}
                          {valeter.isOnline && (
                            <View style={styles.valeterOnlineBadgeSmall}>
                              <View style={styles.valeterOnlineDotSmall} />
                            </View>
                          )}
                        </View>
                        <View style={styles.valeterCardContent}>
                          <View style={styles.valeterTitleRow}>
                            <Text style={styles.valeterName} numberOfLines={1}>{formatDisplayName(valeter.name)}</Text>
                          </View>
                          {(valeter.vehicleType || valeter.vehicleRegistration) && (
                            <View style={styles.valeterVehicleRow}>
                              <Ionicons name="car-sport-outline" size={12} color={SKY} />
                              <Text style={styles.valeterVehicleText} numberOfLines={1}>
                                {[valeter.vehicleType, valeter.vehicleRegistration].filter(Boolean).join(' • ')}
                              </Text>
                            </View>
                          )}
                          <View style={styles.utilityLabelsRow}>
                            <View style={[styles.utilityChip, valeter.providesWater ? styles.utilityChipOn : styles.utilityChipOff]}>
                              <Ionicons
                                name={valeter.providesWater ? 'water' : 'water-outline'}
                                size={11}
                                color={valeter.providesWater ? '#10B981' : '#94A3B8'}
                              />
                              <Text style={[styles.utilityChipText, valeter.providesWater ? styles.utilityChipTextOn : styles.utilityChipTextOff]}>
                                {valeter.providesWater ? 'Brings Water' : 'Needs Water'}
                              </Text>
                            </View>
                            <View style={[styles.utilityChip, valeter.providesElectricity ? styles.utilityChipOn : styles.utilityChipOff]}>
                              <Ionicons
                                name={valeter.providesElectricity ? 'flash' : 'flash-outline'}
                                size={11}
                                color={valeter.providesElectricity ? '#10B981' : '#94A3B8'}
                              />
                              <Text style={[styles.utilityChipText, valeter.providesElectricity ? styles.utilityChipTextOn : styles.utilityChipTextOff]}>
                                {valeter.providesElectricity ? 'Brings Power' : 'Needs Power'}
                              </Text>
                            </View>
                          </View>
                          {renderValeterStats(valeter)}
                          <View style={styles.arrivalRow}>
                            <Ionicons name="time-outline" size={14} color="#60A5FA" />
                            <Text style={styles.arrivalText}>Arrives in ~{arrivalMins} mins</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                    </UnifiedBookingCard>
                  </View>
                );
              })}
            </ScrollView>
          );
        })()}
      </Animated.View>

      {/* Floating Continue button - opens confirmation modal */}
      {(() => {
        const selectedValeterData = selectedValeter ? valeters.find(v => v.id === selectedValeter) : null;
        let ratingDisplay = '';
        if (selectedValeterData) {
          ratingDisplay = selectedValeterData.rating > 0 ? selectedValeterData.rating.toFixed(1) : '5.0';
        }
        let ctaLabel: string;
        let ctaDisabled = true;
        if (selectedValeterData) {
          ctaLabel = `Confirm ${formatDisplayName(selectedValeterData.name).split(' ')[0]} (${ratingDisplay})`;
          ctaDisabled = false;
        } else if (loading) {
          ctaLabel = 'Searching…';
        } else if (valeters.length === 0) {
          ctaLabel = 'No valeters – try again later';
        } else {
          ctaLabel = "We've found valeters – pick one";
          ctaDisabled = false;
        }
        return (
          <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
            <TouchableOpacity
              onPress={handleConfirmValeterPress}
              disabled={ctaDisabled || !selectedValeter}
              style={[styles.ctaButton, { width: valeterCardWidth }]}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={!ctaDisabled && selectedValeter ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText} numberOfLines={1}>
                  {ctaLabel}
                </Text>
                {selectedValeterData ? (
                  <Ionicons name="star" size={16} color="#FBBF24" style={{ marginLeft: 4, marginRight: 6 }} />
                ) : null}
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );
      })()}

      {/* Confirm valeter choice modal - confirm before sending request */}
      <Modal
        visible={showConfirmValeterModal}
        transparent
        animationType="fade"
        onRequestClose={() => !sendingRequest && setShowConfirmValeterModal(false)}
      >
        <Pressable
          style={styles.confirmModalOverlay}
          onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
        >
          <Pressable style={styles.confirmModalContent} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={36} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(15,23,42,0.97)', 'rgba(30,41,59,0.95)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.confirmModalInner}>
              {(() => {
                const v = selectedValeter ? valeters.find(x => x.id === selectedValeter) : null;
                if (!v) return null;
                const arrivalMins = v.eta && v.eta > 0 ? v.eta : Math.max(2, Math.round(v.distance * 2));
                const ratingText = v.rating > 0 ? v.rating.toFixed(1) : '5.0';
                const firstName = formatDisplayName(v.name).split(' ')[0];
                const serviceName = selectedServiceOption?.name ?? 'Wash';
                const basePrice = selectedServiceOption?.price ?? 25;
                const serviceTotal = basePrice - discountAmount;
                const finalPrice = serviceTotal + addOnsTotal;
                return (
                  <>
                    <View style={styles.confirmModalHeader}>
                      <View style={styles.confirmModalTitleRow}>
                        <View style={styles.confirmModalIconWrap}>
                          <Ionicons name="person-circle-outline" size={28} color={SKY} />
                        </View>
                        <Text style={styles.confirmModalTitle}>Send request to {firstName}?</Text>
                      </View>
                      <TouchableOpacity
                        onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
                        hitSlop={12}
                        disabled={sendingRequest}
                        style={styles.confirmModalCloseBtn}
                      >
                        <Ionicons name="close" size={24} color="#94A3B8" />
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.confirmModalSubtitle}>
                      {firstName} will have a few minutes to accept. You can cancel the request anytime before they accept.
                    </Text>

                    <View style={styles.confirmValeterSummary}>
                      <View style={styles.confirmValeterAvatarWrap}>
                        {v.profilePicture ? (
                          <Image source={{ uri: v.profilePicture }} style={styles.confirmValeterAvatar} />
                        ) : (
                          <Image source={VALETER_IMAGE} style={styles.confirmValeterAvatar} resizeMode="cover" />
                        )}
                        {v.isOnline && (
                          <View style={styles.confirmValeterOnlineBadge}>
                            <View style={styles.confirmValeterOnlineDot} />
                          </View>
                        )}
                      </View>
                      <View style={styles.confirmValeterDetails}>
                        <Text style={styles.confirmValeterName}>{formatDisplayName(v.name)}</Text>
                        <View style={styles.confirmValeterMeta}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.confirmValeterMetaText}>{ratingText}</Text>
                          <Text style={styles.confirmValeterMetaDot}>·</Text>
                          <Ionicons name="time-outline" size={12} color="#94A3B8" />
                          <Text style={styles.confirmValeterMetaText}>~{arrivalMins} min</Text>
                        </View>
                      </View>
                    </View>

                    <View style={styles.confirmServiceRow}>
                      <Ionicons name="car-wash-outline" size={18} color={SKY} />
                      <Text style={styles.confirmServiceLabel}>{serviceName}</Text>
                      <Text style={styles.confirmServicePrice}>£{finalPrice.toFixed(2)}</Text>
                    </View>

                    <Text style={styles.confirmModalHint}>No charge until the valeter accepts.</Text>

                    <View style={styles.confirmModalActions}>
                      <TouchableOpacity
                        style={styles.confirmModalCancel}
                        onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
                        disabled={sendingRequest}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.confirmModalCancelText}>Go back</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.confirmModalSend, sendingRequest && styles.confirmModalSendDisabled]}
                        onPress={handleSendRequest}
                        disabled={sendingRequest}
                        activeOpacity={0.9}
                      >
                        <LinearGradient
                          colors={[SKY, '#0EA5E9']}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={styles.confirmModalSendGradient}
                        >
                          {sendingRequest ? (
                            <>
                              <ActivityIndicator size="small" color="#FFFFFF" />
                              <Text style={styles.confirmModalSendText}>Sending…</Text>
                            </>
                          ) : (
                            <>
                              <Ionicons name="rocket" size={18} color="#FFFFFF" />
                              <Text style={styles.confirmModalSendText}>GO!</Text>
                            </>
                          )}
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </>
                );
              })()}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelected: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelectedGlow: {
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 15,
    shadowOpacity: 0.6,
    elevation: 8,
  },
  valeterOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  confirmModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  confirmModalContent: {
    width: '100%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  confirmModalInner: {
    padding: 24,
  },
  confirmModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  confirmModalTitleRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingRight: 8,
  },
  confirmModalIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: -0.3,
  },
  confirmModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 18,
    paddingRight: 4,
  },
  confirmValeterSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  confirmValeterAvatarWrap: {
    marginRight: 14,
    position: 'relative',
  },
  confirmValeterAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
  },
  confirmValeterAvatarPlaceholder: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: SKY + '22',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  confirmValeterOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.9)',
  },
  confirmValeterOnlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  confirmValeterDetails: {
    flex: 1,
    minWidth: 0,
  },
  confirmValeterName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: -0.2,
  },
  confirmValeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  confirmValeterMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  confirmValeterMetaDot: {
    color: '#64748B',
    fontSize: 13,
  },
  confirmServiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginBottom: 10,
  },
  confirmServiceLabel: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 15,
    fontWeight: '700',
  },
  confirmServicePrice: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  confirmModalHint: {
    color: '#64748B',
    fontSize: 12,
    marginBottom: 20,
    textAlign: 'center',
  },
  confirmModalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  confirmModalCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalCancelText: {
    color: '#E2E8F0',
    fontSize: 16,
    fontWeight: '700',
  },
  confirmModalSend: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  confirmModalSendDisabled: {
    opacity: 0.85,
  },
  confirmModalSendGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  confirmModalSendText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  cardWrapper: {
    marginRight: 12,
  },
  curvedCard: {
    borderRadius: CURVED_BOOKING_CARD.borderRadius,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  valeterSearchCard: {
    backgroundColor: 'rgba(15,23,42,0.75)',
    overflow: 'hidden',
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  valeterCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
    zIndex: 1,
  },
  bestMatchBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 5,
    backgroundColor: 'rgba(251, 191, 36, 0.18)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(251, 191, 36, 0.4)',
  },
  bestMatchText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FBBF24',
  },
  arrivalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
  },
  arrivalText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#60A5FA',
  },
  stickySummary: {
    position: 'absolute',
    left: 16,
    right: 16,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.9)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    zIndex: 50,
  },
  stickySummaryText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#E2E8F0',
    textAlign: 'center',
  },
  valeterCard: {
    padding: 18,
    overflow: 'hidden',
    minHeight: 140,
  },
  /** Searching/empty state card – same height as valeter cards */
  searchStateCard: {
    minHeight: 140,
  },
  valeterVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    marginBottom: 2,
  },
  valeterVehicleText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  utilityLabelsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 7,
    marginBottom: 2,
  },
  utilityChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    borderRadius: 999,
    borderWidth: 1,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  utilityChipOn: {
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderColor: 'rgba(16,185,129,0.32)',
  },
  utilityChipOff: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderColor: 'rgba(148,163,184,0.22)',
  },
  utilityChipText: {
    fontSize: 10,
    fontWeight: '700',
  },
  utilityChipTextOn: {
    color: '#10B981',
  },
  utilityChipTextOff: {
    color: '#94A3B8',
  },
  valeterCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 3,
  },
  valeterCardTop: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  valeterAvatarWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  valeterAvatar: {
    width: '100%',
    height: '100%',
  },
  valeterAvatarPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '40',
  },
  valeterOnlineBadgeSmall: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  valeterCardContent: {
    flex: 1,
    minWidth: 0,
  },
  valeterTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  valeterSelectedBadge: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: '#10B98120',
    borderWidth: 1,
    borderColor: '#10B98140',
  },
  valeterCtaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  valeterCtaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
  },
  valeterCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  valeterCtaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  valeterEmptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  uberValeterCard: {
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterCardSelected: {
    borderColor: '#60A5FA',
    shadowColor: '#60A5FA',
    shadowOpacity: 0.3,
  },
  uberValeterCardContent: {
    width: '100%',
  },
  uberValeterHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  uberValeterLeft: {
    position: 'relative',
  },
  uberProfileImage: {
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 2,
    borderColor: '#60A5FA',
  },
  uberOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  uberOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  uberValeterInfo: {
    flex: 1,
  },
  uberValeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  uberValeterName: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: 0.2,
  },
  uberSelectedBadge: {
    marginLeft: 8,
  },
  uberValeterActionRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterButton: {
    backgroundColor: '#60A5FA',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberValeterButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  searchRingWrap: {
    width: 64,
    height: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchRingOuter: {
    position: 'absolute',
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 3,
    borderColor: SKY + '50',
    borderTopColor: SKY,
    borderRightColor: SKY,
  },
  searchRingInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: SKY + '12',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 14,
  },
  loadingSubtext: {
    color: '#94A3B8',
    fontSize: 13,
  },
  emptyContent: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  uberValeterStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  uberStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  uberStatText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
});
