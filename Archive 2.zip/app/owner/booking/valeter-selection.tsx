import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { findServiceOptionById } from '../../../src/constants/serviceOptions';
import { getVehicleSize } from '../../../src/pricing/pricingEngine';
import AppHeader from '../../../src/components/shared/AppHeader';
import { BookingHeaderMapControlButton } from '../../../src/components/shared/BookingHeaderMapControlButton';
import { colors } from '../../../src/constants/colors';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import {
  BOOKING_CARD,
  BOOKING_H_CARD_GAP,
  CURVED_BOOKING_CARD,
  getIndexTrackingCardWidth,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../../src/constants/bookingCardTheme';
import { getActiveBookingForCustomer } from '../../../src/utils/activeBookingGuard';
import IndexTrackingCardShell, { indexTrackingCardStyles as ix } from '../../../src/components/booking/IndexTrackingCardShell';
import BookingSheetPremiumLayers from '../../../src/components/booking/BookingSheetPremiumLayers';
import BookingBottomSheetOverlay from '../../../src/components/booking/BookingBottomSheetOverlay';
import { WWPrimaryButton } from '../../../src/components/ui';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, MAP_CAMERA_ANIMATION_DURATION } from '../../../src/constants/mapConstants';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';
import { getActivePlatformFeePercent, resolveValeterBookingPrice } from '../../../src/services/ValeterPricingService';
import {
  MapMarkerCustomerVehicle,
  MapMarkerValeterCandidate,
} from '../../../src/components/maps/MapMarkerViews';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';

const SKY = colors.SKY;

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string | null;
  lastLat?: number | null;
  lastLng?: number | null;
  isVerified?: boolean;
  responseTime?: number;
  eta?: number;
  vehicleRegistration?: string | null;
  vehicleType?: string | null;
  providesWater?: boolean;
  providesElectricity?: boolean;
  bookingPrice?: number | null;
  offersSelectedService?: boolean | null;
}

type ValeterServiceSettings = {
  valeter_id: string;
  eco_washing: boolean;
  detailing_offered: boolean;
  detailing_menu: Record<string, unknown> | null;
  tier_pricing: Record<string, unknown> | null;
  repairs_offered: boolean;
  repair_menu: Record<string, unknown> | null;
};

type ReassignBooking = {
  id: string;
  service_type: string;
  service_name: string | null;
  location_lat: number | null;
  location_lng: number | null;
  location_address: string | null;
};

function toFiniteOrNull(value: unknown): number | null {
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''));
  return Number.isFinite(n) ? n : null;
}

const ValeterMapMarker = memo(function ValeterMapMarker({
  valeter,
  isSelected,
  onSelect,
  pulseScale,
}: {
  valeter: Valeter;
  isSelected: boolean;
  onSelect: (id: string) => void;
  pulseScale: Animated.Value;
}) {
  const handlePress = useCallback(() => {
    onSelect(valeter.id);
  }, [valeter.id, onSelect]);
  if (valeter.lastLat == null || valeter.lastLng == null) return null;
  return (
    <Marker
      coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
      onPress={handlePress}
    >
      <View
        style={[
          { opacity: isSelected ? 1 : 0.72 },
          isSelected && styles.valeterMarkerSelectedGlow,
        ]}
      >
        <Animated.View style={isSelected ? { transform: [{ scale: pulseScale }] } : undefined}>
          <MapMarkerValeterCandidate size={50} isSelected={isSelected} isOnline={valeter.isOnline} />
        </Animated.View>
      </View>
    </Marker>
  );
});

export default function ValeterSelection() {
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const valeterCardWidth = getIndexTrackingCardWidth(adaptive.width);
  const valeterSnapInterval = valeterCardWidth + BOOKING_H_CARD_GAP;
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingIdParam = params.bookingId as string | undefined;
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string | undefined;
  const paramLat = toFiniteOrNull(params.latitude as string);
  const paramLng = toFiniteOrNull(params.longitude as string);
  const address = params.address as string;
  const customerOffersWater = params.customerOffersWater === 'true';
  const customerOffersElectricity = params.customerOffersElectricity === 'true';
  const discountAmount = Number.parseFloat(params.discountAmount as string) || 0;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;
  const addOnIds = (params.addOnIds as string) || '';
  const addOnsTotal = Number.parseFloat((params.addOnsTotal as string) || '0') || 0;
  const paramServiceBasePrice = Number.parseFloat((params.serviceBasePriceGBP as string) || '');
  const preferredValeterId = (params.preferredValeterId as string) || null;

  const [reassignBooking, setReassignBooking] = useState<ReassignBooking | null>(null);
  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [sendingRequest, setSendingRequest] = useState(false);
  const [loading, setLoading] = useState(true);
  const [valeterInfoModal, setValeterInfoModal] = useState<Valeter | null>(null);
  const [isValeterScrolling, setIsValeterScrolling] = useState(false);
  const [customerVehicle, setCustomerVehicle] = useState<{ id: string; type?: string; make?: string; model?: string; size?: string } | null>(null);
  const [platformFeePercent, setPlatformFeePercent] = useState<number>(0.2);
  const [serviceSettingsByValeterId, setServiceSettingsByValeterId] = useState<Record<string, ValeterServiceSettings>>({});
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);

  const effectiveServiceId = reassignBooking?.service_type ?? serviceId;
  const selectedServiceOption = findServiceOptionById(effectiveServiceId);
  const customerVehicleSize = customerVehicle ? getVehicleSize(customerVehicle) : null;
  const latitude =
    toFiniteOrNull(center?.lat) ??
    toFiniteOrNull(reassignBooking?.location_lat) ??
    paramLat ??
    toFiniteOrNull(liveCoords?.latitude) ??
    0;
  const longitude =
    toFiniteOrNull(center?.lng) ??
    toFiniteOrNull(reassignBooking?.location_lng) ??
    paramLng ??
    toFiniteOrNull(liveCoords?.longitude) ??
    0;

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const searchRingRotate = useRef(new Animated.Value(0)).current;
  const valeterMarkerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const fee = await getActivePlatformFeePercent();
      if (!cancelled) setPlatformFeePercent(fee);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!user?.id || !vehicleId) return;
    let cancelled = false;
    void (async () => {
      const { data } = await supabase
        .from('customer_vehicles')
        .select('id, type, make, model, size')
        .eq('user_id', user.id)
        .eq('id', vehicleId)
        .maybeSingle();

      if (cancelled || !data) return;
      setCustomerVehicle(data as { id: string; type?: string; make?: string; model?: string; size?: string });
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id, vehicleId]);

  // Reassign mode: load existing booking when only bookingId is passed (e.g. after valeter declined/cancelled)
  useEffect(() => {
    if (!bookingIdParam || !user?.id) return;
    let cancelled = false;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, service_type, service_name, location_lat, location_lng, location_address')
          .eq('id', bookingIdParam)
          .eq('user_id', user.id)
          .single();
        if (cancelled || error || !data) {
          if (!cancelled) setLoading(false);
          return;
        }
        const b = data as ReassignBooking;
        setReassignBooking(b);
        if (b.location_lat != null && b.location_lng != null) {
          setCenter({ lat: b.location_lat, lng: b.location_lng });
          setRegion({ latitude: b.location_lat, longitude: b.location_lng, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        }
      } catch {
        if (!cancelled) setLoading(false);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [bookingIdParam, user?.id]);

  useEffect(() => {
    if (bookingIdParam) return;
    const lat = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLat : liveCoords?.latitude;
    const lng = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLng : liveCoords?.longitude;
    if (lat != null && lng != null) {
      setCenter({ lat, lng });
      setRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else if (liveCoords) {
      setCenter({ lat: liveCoords.latitude, lng: liveCoords.longitude });
      setRegion({ latitude: liveCoords.latitude, longitude: liveCoords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          setCenter({ lat: loc.coords.latitude, lng: loc.coords.longitude });
          setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        })
        .catch(() => {});
    }
  }, [bookingIdParam, paramLat, paramLng, liveCoords]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    loadNearbyValeters();
    // We intentionally include center so distance re-computes when customer location resolves.
  }, [
    user?.id,
    center,
    effectiveServiceId,
    customerVehicleSize,
    platformFeePercent,
    paramServiceBasePrice,
    selectedServiceOption?.price,
    addOnsTotal,
    latitude,
    longitude,
  ]);

  // Pre-select preferred valeter when coming from Explore favourites
  useEffect(() => {
    if (!preferredValeterId || valeters.length === 0) return;
    const found = valeters.some((v) => v.id === preferredValeterId);
    if (found) setSelectedValeter(preferredValeterId);
  }, [preferredValeterId, valeters]);

  useEffect(() => {
    if (!selectedValeter) return;
    if (valeters.some((v) => v.id === selectedValeter)) return;
    setSelectedValeter(null);
  }, [selectedValeter, valeters]);

  // Continuous search ring animation when no valeters available
  useEffect(() => {
    if (valeters.length > 0 || loading) return;
    searchRingRotate.setValue(0);
    const loop = Animated.loop(
      Animated.timing(searchRingRotate, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [valeters.length, loading]);

  useEffect(() => {
    if (!isValeterScrolling) {
      valeterMarkerPulse.setValue(1);
      return;
    }
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(valeterMarkerPulse, { toValue: 1.12, duration: 420, useNativeDriver: true }),
        Animated.timing(valeterMarkerPulse, { toValue: 1, duration: 420, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [isValeterScrolling, valeterMarkerPulse]);

  const searchRingSpin = searchRingRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  // Match `create` vehicle/service map insets so the strip sits at the same vertical level as other booking sheets
  const mapPaddingBottom = 190 + Math.max(insets.bottom, 10);
  const legalLabelBottom = mapPaddingBottom + Math.max(insets.bottom, 6) - 24;
  useEffect(() => {
    if (!center) return;
    const coords: { latitude: number; longitude: number }[] = [{ latitude: center.lat, longitude: center.lng }];
    valeters.forEach((v) => {
      if (v.lastLat != null && v.lastLng != null) coords.push({ latitude: v.lastLat, longitude: v.lastLng });
    });
    const t = setTimeout(() => {
      mapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 100, right: 48, bottom: mapPaddingBottom, left: 48 },
        animated: true,
      });
    }, 400);
    return () => clearTimeout(t);
  }, [center, valeters.map((v) => `${v.lastLat}-${v.lastLng}`).join(','), mapPaddingBottom]);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url')
        .in('user_id', userIds);
      if (profilesError) {
        console.warn('[valeter-selection] profiles fetch failed; continuing without profile data', profilesError);
      }

      const { data: settingsData, error: settingsError } = await supabase
        .from('valeter_service_settings')
        .select('valeter_id, eco_washing, detailing_offered, detailing_menu, tier_pricing, repairs_offered, repair_menu')
        .in('valeter_id', userIds);
      if (settingsError) {
        console.warn('[valeter-selection] settings fetch failed; continuing without service settings', settingsError);
      }

      const { data: fallbackProfilesData, error: fallbackProfilesError } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);
      if (fallbackProfilesError) {
        console.warn('[valeter-selection] fallback profiles fetch failed; continuing without fallback names', fallbackProfilesError);
      }

      const { data: vehiclesData, error: vehiclesError } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, type')
        .in('user_id', userIds)
        .eq('is_default', true);
      if (vehiclesError) {
        console.warn('[valeter-selection] vehicle fetch failed; continuing without vehicle data', vehiclesError);
      }

      const settingsMap = Object.fromEntries((settingsData || []).map((row) => [row.valeter_id, row as ValeterServiceSettings]));
      setServiceSettingsByValeterId(settingsMap);

      const statsPromises = userIds.map(userId =>
        ValeterStatsService.getValeterStats(userId).catch(() => null)
      );
      const statsResults = await Promise.all(statsPromises);
      const statsMap = new Map(
        userIds.map((userId, index) => [userId, statsResults[index]])
      );

      const valetersList: Valeter[] = await Promise.all(
        presenceData.map(async (presence) => {
          const profile = (profilesData || []).find(p => p.user_id === presence.user_id) as
            | ({
                user_id: string;
                full_name?: string | null;
                profile_photo_url?: string | null;
              } & Record<string, unknown>)
            | undefined;
          const settings = (settingsData || []).find((row) => row.valeter_id === presence.user_id) as ValeterServiceSettings | undefined;
          const hasValeterCoords =
            Number.isFinite(presence.last_lat as number) && Number.isFinite(presence.last_lng as number);
          const hasCustomerCoords = Number.isFinite(latitude) && Number.isFinite(longitude);
          const distance = hasValeterCoords && hasCustomerCoords
            ? calculateDistance(latitude, longitude, presence.last_lat as number, presence.last_lng as number)
            : 999;

          const stats = statsMap.get(presence.user_id);
          const fallbackProfile = (fallbackProfilesData || []).find((p: any) => p.id === presence.user_id);
          const displayName = profile?.full_name || fallbackProfile?.full_name || 'Valeter';
          const isVerified = profile?.verification_status === 'verified';
          const vehicle = (vehiclesData || []).find(v => v.user_id === presence.user_id);
          const estimatedETA = Math.round(distance * 2);
          const isSelfSufficient = Boolean((profile as any)?.is_self_sufficient);
          const resolvedPricing = resolveValeterBookingPrice({
            serviceId: effectiveServiceId,
            vehicleSize: customerVehicleSize,
            fallbackBasePrice: Number.isFinite(paramServiceBasePrice) && paramServiceBasePrice > 0 ? paramServiceBasePrice : selectedServiceOption?.price ?? 0,
            settings: settings
              ? ({
                  eco_washing: settings.eco_washing,
                  detailing_offered: settings.detailing_offered,
                  detailing_menu: settings.detailing_menu,
                  tier_pricing: settings.tier_pricing,
                  repairs_offered: settings.repairs_offered,
                  repair_menu: settings.repair_menu,
                } as Parameters<typeof resolveValeterBookingPrice>[0]['settings'])
              : null,
            platformFeePercent,
          });

          return {
            id: presence.user_id,
            name: displayName,
            rating: stats?.averageRating || 0,
            totalJobs: stats?.totalJobs || 0,
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url ?? null,
            lastLat: presence.last_lat ?? null,
            lastLng: presence.last_lng ?? null,
            isVerified: isVerified,
            responseTime: 5,
            eta: estimatedETA,
            vehicleRegistration: vehicle?.registration ?? null,
            vehicleType: vehicle?.type ?? null,
            providesWater: isSelfSufficient,
            providesElectricity: isSelfSufficient,
            bookingPrice: Number((resolvedPricing.customerTotalPrice + addOnsTotal).toFixed(2)),
            offersSelectedService: resolvedPricing.available,
          };
        })
      );

      const availableValeters = valetersList.filter((v) => v.offersSelectedService !== false);
      const onlineWithCoords = availableValeters
        .filter((v) => Number.isFinite(v.distance) && v.distance < 999)
        .sort((a, b) => a.distance - b.distance);
      const onlineWithoutCoords = availableValeters
        .filter((v) => !Number.isFinite(v.distance) || v.distance >= 999);

      // Show all online valeters in mobile flow; nearby first, then unknown distance.
      const filteredValeters = [...onlineWithCoords, ...onlineWithoutCoords];

      setValeters(filteredValeters);
    } catch (error) {
      const errorService = await import('../../../src/services/ErrorHandlingService').then(m => m.errorHandlingService);
      errorService.handleBookingError(error as Error, 'valeter_selection');
    } finally {
      setLoading(false);
    }
  };

  const focusValeterOnMap = (valeterId: string) => {
    setSelectedValeter(valeterId);
    const v = valeters.find((x) => x.id === valeterId);
    if (v?.lastLat != null && v?.lastLng != null && mapRef.current) {
      const r = { latitude: v.lastLat, longitude: v.lastLng, latitudeDelta: 0.001, longitudeDelta: 0.001 };
      setRegion(r);
      mapRef.current.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    focusValeterOnMap(valeterId);
  };

  const handleValeterScrollSnap = (offsetX: number) => {
    if (!valeters.length) return;
    const snappedIndex = Math.max(0, Math.min(valeters.length - 1, Math.round(offsetX / valeterSnapInterval)));
    const snappedValeter = valeters[snappedIndex];
    if (!snappedValeter) return;
    if (snappedValeter.id === selectedValeter) return;
    focusValeterOnMap(snappedValeter.id);
  };

  /** Single tap: select valeter only; explicit CTA sends request. */
  const handleValeterCardPress = async (valeterId: string) => {
    await handleValeterSelect(valeterId);
  };

  const handleContinue = async (valeterIdOverride?: string) => {
    const valeterId = valeterIdOverride ?? selectedValeter;
    if (!valeterId || !user?.id) {
      setSendingRequest(false);
      return;
    }
    if (!reassignBooking && !selectedServiceOption) {
      setSendingRequest(false);
      return;
    }
    await hapticFeedback('medium');

    if (!reassignBooking) {
      const active = await getActiveBookingForCustomer(user.id);
      if (active) {
        setSendingRequest(false);
        Alert.alert(
          'One booking at a time',
          'You already have an active booking. Please complete or cancel it before starting a new one.',
          [
            { text: 'OK', style: 'cancel' },
            { text: 'View my booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
          ]
        );
        return;
      }
    }

    try {
      if (reassignBooking) {
        const { error } = await supabase
          .from('bookings')
          .update({
            valeter_id: valeterId,
            status: 'pending_valeter_acceptance',
            request_sent_at: new Date().toISOString(),
          })
          .eq('id', reassignBooking.id)
          .eq('user_id', user.id);
        if (error) throw error;
        router.push({
          pathname: '/owner/booking/tracking',
          params: { bookingId: reassignBooking.id },
        });
        return;
      }

      const scheduledAt = new Date().toISOString();
      const resolvedPricing = resolveValeterBookingPrice({
        serviceId: effectiveServiceId,
        vehicleSize: customerVehicleSize,
        fallbackBasePrice: Number.isFinite(paramServiceBasePrice) && paramServiceBasePrice > 0 ? paramServiceBasePrice : selectedServiceOption?.price ?? 0,
        settings: serviceSettingsByValeterId[valeterId]
          ? ({
              eco_washing: serviceSettingsByValeterId[valeterId].eco_washing,
              detailing_offered: serviceSettingsByValeterId[valeterId].detailing_offered,
              detailing_menu: serviceSettingsByValeterId[valeterId].detailing_menu,
              tier_pricing: serviceSettingsByValeterId[valeterId].tier_pricing,
              repairs_offered: serviceSettingsByValeterId[valeterId].repairs_offered,
              repair_menu: serviceSettingsByValeterId[valeterId].repair_menu,
            } as Parameters<typeof resolveValeterBookingPrice>[0]['settings'])
          : null,
        platformFeePercent,
      });

      if (!resolvedPricing.available) {
        setSendingRequest(false);
        Alert.alert('Unavailable', 'This valeter does not currently offer the selected service.');
        return;
      }

      const serviceTotal = resolvedPricing.basePrice + resolvedPricing.platformFeeAmount - discountAmount;
      const finalPrice = serviceTotal + addOnsTotal;

      const insertRow: Record<string, unknown> = {
        user_id: user.id,
        valeter_id: valeterId,
        service_type: serviceId,
        service_name: selectedServiceOption!.name || serviceId,
        status: 'pending_valeter_acceptance',
        price: finalPrice,
        location_address: address,
        location_lat: latitude,
        location_lng: longitude,
        customer_offers_water: customerOffersWater,
        customer_offers_electricity: customerOffersElectricity,
        discount_amount: discountAmount,
        wash_type: washType,
        platform_fee_percent: resolvedPricing.platformFeePercent * 100,
        platform_fee_amount: resolvedPricing.platformFeeAmount,
        request_sent_at: new Date().toISOString(),
        scheduled_at: scheduledAt,
      };
      if (addOnIds) insertRow.add_on_ids = addOnIds;
      if (addOnsTotal > 0) insertRow.add_ons_total = addOnsTotal;

      let result = await supabase.from('bookings').insert(insertRow).select().single();
      if (result.error && (result.error.message?.includes('add_on') || result.error.message?.includes('add_ons'))) {
        delete insertRow.add_on_ids;
        delete insertRow.add_ons_total;
        result = await supabase.from('bookings').insert(insertRow).select().single();
      }
      const { data, error } = result;

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/tracking',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      setSendingRequest(false);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  const handleSendRequest = (explicitValeterId?: string) => {
    const id = explicitValeterId ?? selectedValeter;
    if (!id) return;
    if (sendingRequest) return;
    setSendingRequest(true);
    void handleContinue(id);
  };

  const renderValeterStats = (valeter: Valeter) => {
    const ratingText = valeter.rating > 0 ? `${valeter.rating.toFixed(1)}` : 'New';
    const jobsText = `${valeter.totalJobs} ${valeter.totalJobs === 1 ? 'job' : 'jobs'} completed`;
    const hasDistance = Number.isFinite(valeter.distance) && valeter.distance < 999;
    const distanceText = hasDistance ? `${valeter.distance.toFixed(1)} mi` : 'Distance unavailable';
    const etaText = hasDistance && valeter.eta && valeter.eta > 0 ? `${valeter.eta} min` : null;
    const priceText = Number.isFinite(valeter.bookingPrice ?? NaN) ? `Total so far (incl. fee): £${Number(valeter.bookingPrice).toFixed(2)}` : 'Price unavailable';

    return (
      <View style={styles.uberValeterStats}>
        <View style={styles.uberStatItem}>
          <Ionicons name="star" size={14} color="#FBBF24" />
          <Text style={styles.uberStatText}>{ratingText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="checkmark-done-outline" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{jobsText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="location" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{distanceText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="pricetag-outline" size={14} color="#60A5FA" />
          <Text style={[styles.uberStatText, { color: '#60A5FA' }]}>{priceText}</Text>
        </View>
        {etaText && (
          <View style={styles.uberStatItem}>
            <Ionicons name="time" size={14} color="#60A5FA" />
            <Text style={[styles.uberStatText, { color: '#60A5FA' }]}>{etaText}</Text>
          </View>
        )}
      </View>
    );
  };

  let valeterHeaderSubtitle: string;
  if (loading) valeterHeaderSubtitle = 'Searching for valeters…';
  else if (valeters.length === 0) valeterHeaderSubtitle = 'No valeters in your area for this service';
  else valeterHeaderSubtitle = "We've found nearby valeters";

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          legalLabelInsets={{ top: 0, right: 8, bottom: legalLabelBottom, left: 8 }}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          mapPadding={{ top: 0, right: 0, bottom: mapPaddingBottom, left: 0 }}
        >
          {center && (
            <Marker coordinate={{ latitude: center.lat, longitude: center.lng }}>
              <MapMarkerCustomerVehicle size={44} variant="pin" />
            </Marker>
          )}

          {valeters.map((valeter) => (
            <ValeterMapMarker
              key={valeter.id}
              valeter={valeter}
              isSelected={selectedValeter === valeter.id}
              onSelect={handleValeterSelect}
              pulseScale={valeterMarkerPulse}
            />
          ))}
        </MapView>
        {isValeterScrolling ? <View pointerEvents="none" style={styles.mapPrivacyTint} /> : null}
      </View>

      <AppHeader
        title="Confirm your valeter"
        subtitle={valeterHeaderSubtitle}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <BookingHeaderMapControlButton
            onPress={() => {
              void (async () => {
                hapticFeedback('light');
                let lat = liveCoords?.latitude ?? latitude;
                let lng = liveCoords?.longitude ?? longitude;
                if (lat == null || lng == null || !Number.isFinite(lat) || !Number.isFinite(lng)) {
                  try {
                    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                    lat = loc.coords.latitude;
                    lng = loc.coords.longitude;
                  } catch { /* keep map as-is */ }
                }
                if (lat != null && lng != null && Number.isFinite(lat) && Number.isFinite(lng)) {
                  const r = { latitude: lat, longitude: lng, latitudeDelta: 0.001, longitudeDelta: 0.001 };
                  setRegion(r);
                  mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
                }
              })();
            }}
            accentColor={SKY}
          />
        }
      />

      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: -24,
            paddingHorizontal: 0,
            paddingBottom: 0,
          },
        ]}
      >
        <View style={[styles.valeterSheetShell, { paddingBottom: Math.max(insets.bottom, 12) + 10 }]}>
          <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.valeterSheetSheen}
          />
          <BookingSheetPremiumLayers />
          <View style={styles.valeterSheetHandle} />
          {(() => {
            if (loading || valeters.length === 0) {
              return (
                <View style={[styles.cardWrapper, { width: valeterCardWidth, marginRight: 0, marginHorizontal: adaptive.horizontalPadding }]}>
                  <View style={[ix.cardWrap, { width: valeterCardWidth }]}>
                    <IndexTrackingCardShell accentColor={SKY}>
                      <View style={[styles.valeterCard, styles.searchStateCard]}>
                        <View style={styles.loadingContainer}>
                          {loading ? (
                            <ActivityIndicator size="large" color={SKY} />
                          ) : (
                            <View style={styles.searchRingWrap}>
                              <Animated.View
                                style={[
                                  styles.searchRingOuter,
                                  { transform: [{ rotate: searchRingSpin }] },
                                ]}
                              />
                              <View style={styles.searchRingInner}>
                                <Ionicons name="search" size={28} color={SKY} />
                              </View>
                            </View>
                          )}
                          <Text style={styles.loadingText}>
                            {loading ? 'Searching for valeters…' : 'Searching for a valeter'}
                          </Text>
                          <Text style={styles.loadingSubtext}>
                            {loading ? "Checking who's available near you" : "We'll keep looking in your area"}
                          </Text>
                        </View>
                      </View>
                    </IndexTrackingCardShell>
                  </View>
                </View>
              );
            }
            return (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={[styles.cardsScrollContent, { paddingHorizontal: adaptive.horizontalPadding }]}
                snapToInterval={valeterSnapInterval}
                decelerationRate="fast"
                onScrollBeginDrag={() => setIsValeterScrolling(true)}
                onMomentumScrollEnd={(e) => {
                  handleValeterScrollSnap(e.nativeEvent.contentOffset.x);
                  setIsValeterScrolling(false);
                }}
              >
                {valeters.map((valeter) => {
                  return (
                    <View key={valeter.id} style={[styles.cardWrapper, { width: valeterCardWidth }]}>
                      <TouchableOpacity
                        activeOpacity={0.92}
                        onPress={() => void handleValeterCardPress(valeter.id)}
                        style={[ix.cardWrap, { width: valeterCardWidth }]}
                        accessibilityRole="button"
                        accessibilityLabel={`Confirm ${formatDisplayName(valeter.name) || valeter.name} and send request`}
                      >
                        <IndexTrackingCardShell accentColor={SKY}>
                          <View style={ix.optionCardTopRow}>
                            <View style={[ix.optionIconBadge, { borderColor: SKY + '55', backgroundColor: SKY + '35' }]}>
                              {valeter.profilePicture ? (
                                <Image source={{ uri: valeter.profilePicture }} style={styles.valeterSheetAvatarFill} />
                              ) : (
                                <Ionicons name="person" size={22} color={SKY} />
                              )}
                            </View>
                            <View style={ix.optionTitleMain}>
                              <Text style={ix.optionKicker}>MOBILE VALETER</Text>
                              <Text style={ix.optionTitle} numberOfLines={1}>
                                {formatDisplayName(valeter.name) || valeter.name}
                              </Text>
                              <Text style={ix.optionSubtitle} numberOfLines={1}>
                                {' '}
                              </Text>
                              {(() => {
                                const hasDistance = Number.isFinite(valeter.distance) && valeter.distance < 999;
                                const showEta = hasDistance && valeter.eta != null && valeter.eta > 0;
                                return (
                                  <View style={styles.valeterCardTrustBlock}>
                                    <View style={styles.valeterCardTrustLine}>
                                      <Ionicons name="star" size={13} color="#FBBF24" />
                                      <Text style={styles.valeterCardTrustText}>
                                        {valeter.rating > 0 ? valeter.rating.toFixed(1) : 'New'}
                                        {valeter.totalJobs > 0 ? ` (${valeter.totalJobs} jobs)` : ''}
                                      </Text>
                                    </View>
                                    <View style={[styles.valeterCardTrustLine, !showEta && styles.valeterCardTrustLineHidden]}>
                                      <Ionicons name="time-outline" size={13} color="#60A5FA" />
                                      <Text style={[styles.valeterCardTrustText, { color: '#93C5FD' }]}>
                                        ETA: {showEta ? `${valeter.eta} mins` : '--'}
                                      </Text>
                                    </View>
                                    <View style={styles.valeterCardTrustLine}>
                                      <Ionicons name="location-outline" size={13} color="rgba(255,255,255,0.6)" />
                                      <Text style={styles.valeterCardTrustText}>
                                        {hasDistance ? `Distance: ${valeter.distance.toFixed(1)} miles` : 'Distance unavailable'}
                                      </Text>
                                    </View>
                                    <View style={styles.valeterCardTrustLine}>
                                      <Ionicons name="pricetag-outline" size={13} color="#60A5FA" />
                                      <Text style={[styles.valeterCardTrustText, { color: '#93C5FD' }]}>
                                        {Number.isFinite(valeter.bookingPrice ?? NaN)
                                          ? `Total so far (incl. fee): £${Number(valeter.bookingPrice).toFixed(2)}`
                                          : 'Price unavailable'}
                                      </Text>
                                    </View>
                                  </View>
                                );
                              })()}
                            </View>
                            <TouchableOpacity
                              style={[ix.optionInfoBtn, { borderColor: SKY + '40', backgroundColor: SKY + '15' }]}
                              onPress={() => {
                                hapticFeedback('light');
                                setValeterInfoModal(valeter);
                              }}
                              activeOpacity={0.85}
                              accessibilityLabel="Valeter details"
                              accessibilityRole="button"
                            >
                              <Ionicons name="information-circle-outline" size={22} color={SKY} />
                            </TouchableOpacity>
                          </View>
                          <View style={ix.optionFooterRow}>
                            <View style={ix.optionFooterLeft}>
                              <View
                                style={[
                                  ix.optionStatusPill,
                                  {
                                    backgroundColor: (valeter.isOnline ? '#10B981' : '#64748B') + '22',
                                    borderColor: (valeter.isOnline ? '#10B981' : '#64748B') + '38',
                                  },
                                ]}
                              >
                                <View style={[ix.optionStatusDot, { backgroundColor: valeter.isOnline ? '#10B981' : '#94A3B8' }]} />
                                <Text style={[ix.optionStatusText, { color: valeter.isOnline ? '#10B981' : '#94A3B8' }]}>
                                  {valeter.isOnline ? 'Available' : 'Offline'}
                                </Text>
                              </View>
                            </View>
                            {sendingRequest && selectedValeter === valeter.id ? (
                              <ActivityIndicator size="small" color={SKY} style={{ marginRight: 4 }} />
                            ) : null}
                          </View>
                        </IndexTrackingCardShell>
                      </TouchableOpacity>
                    </View>
                  );
                })}
              </ScrollView>
            );
          })()}
          {!loading && valeters.length > 0 ? (
            <View style={[styles.requestCtaRow, { width: valeterCardWidth, alignSelf: 'center' }]}>
              <WWPrimaryButton
                title="Request valeter"
                onPress={() => handleSendRequest()}
                disabled={!selectedValeter || sendingRequest}
                loading={sendingRequest}
                leftIconName="send-outline"
                leftIconSize={18}
              />
            </View>
          ) : null}
        </View>
      </Animated.View>

      <BookingBottomSheetOverlay
        visible={!!valeterInfoModal}
        onClose={() => setValeterInfoModal(null)}
        maxHeightRatio={0.55}
      >
        {valeterInfoModal ? (
          <ScrollView style={styles.valeterInfoScroll} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>
            <Text style={[styles.valeterInfoTitle, { color: SKY }]} numberOfLines={2}>
              {formatDisplayName(valeterInfoModal.name) || valeterInfoModal.name}
            </Text>
            <Text style={styles.valeterInfoSub}>Mobile valeter</Text>
            {renderValeterStats(valeterInfoModal)}
            {valeterInfoModal.isVerified ? (
              <View style={styles.valeterInfoRow}>
                <Ionicons name="shield-checkmark" size={18} color="#10B981" />
                <Text style={styles.valeterInfoRowText}>Verified pro</Text>
              </View>
            ) : null}
            <Text style={styles.valeterInfoHint}>Tap a valeter card once to send your cleaning request.</Text>
          </ScrollView>
        ) : null}
      </BookingBottomSheetOverlay>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  mapPrivacyTint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(15,23,42,0.46)',
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelected: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelectedGlow: {
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 15,
    shadowOpacity: 0.6,
    elevation: 8,
  },
  valeterOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingTop: 0,
  },
  valeterSheetShell: {
    paddingTop: 6,
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  valeterSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.95,
  },
  valeterSheetHandle: {
    width: 42,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 6,
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.55)',
  },
  valeterSheetHeader: {
    paddingHorizontal: 14,
    marginBottom: 8,
  },
  valeterSheetTitle: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },
  valeterSheetSubtitle: {
    marginTop: 2,
    color: 'rgba(226,232,240,0.82)',
    fontSize: 12,
    fontWeight: '600',
  },
  requestCtaRow: {
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 2,
    alignItems: 'center',
  },
  exploreLikeCard: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    minHeight: 148,
  },
  exploreLikeCardSelected: {
    borderColor: SKY + '90',
    shadowColor: SKY,
    shadowOpacity: 0.28,
    shadowRadius: 12,
    elevation: 6,
  },
  exploreLikeCardPad: {
    padding: 12,
  },
  exploreLikeTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  exploreLikeIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(167,139,250,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(167,139,250,0.45)',
    marginRight: 10,
  },
  exploreLikeAvatar: {
    width: '100%',
    height: '100%',
  },
  exploreLikeMain: {
    flex: 1,
    minWidth: 0,
  },
  exploreLikeKicker: {
    color: 'rgba(226,232,240,0.74)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.75,
    textTransform: 'uppercase',
    marginBottom: 3,
  },
  exploreLikeTitle: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  exploreLikeStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 6,
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  exploreLikeStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexWrap: 'nowrap',
  },
  exploreLikeStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  exploreLikeStatusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  bestMatchInlineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.45)',
    backgroundColor: 'rgba(251,191,36,0.14)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  bestMatchInlineText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#FBBF24',
  },
  exploreLikeBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(126,184,212,0.2)',
  },
  exploreLikeMetaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexWrap: 'wrap',
    flex: 1,
  },
  exploreLikeMetaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.28)',
    backgroundColor: 'rgba(30,41,59,0.45)',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  exploreLikeMetaText: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 11,
    fontWeight: '700',
  },
  confirmModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  confirmModalContent: {
    width: '100%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  confirmModalInner: {
    padding: 24,
  },
  confirmModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  confirmModalTitleRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingRight: 8,
  },
  confirmModalIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: -0.3,
  },
  confirmModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 18,
    paddingRight: 4,
  },
  confirmValeterSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  confirmValeterAvatarWrap: {
    marginRight: 14,
    position: 'relative',
  },
  confirmValeterAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
  },
  confirmValeterAvatarPlaceholder: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: SKY + '22',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  confirmValeterOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.9)',
  },
  confirmValeterOnlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  confirmValeterDetails: {
    flex: 1,
    minWidth: 0,
  },
  confirmValeterName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: -0.2,
  },
  confirmValeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  confirmValeterMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  confirmValeterMetaDot: {
    color: '#64748B',
    fontSize: 13,
  },
  confirmServiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginBottom: 10,
  },
  confirmServiceLabel: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 15,
    fontWeight: '700',
  },
  confirmServicePrice: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  confirmModalHint: {
    color: '#64748B',
    fontSize: 12,
    marginBottom: 20,
    textAlign: 'center',
  },
  confirmModalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  confirmModalCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalCancelText: {
    color: '#E2E8F0',
    fontSize: 16,
    fontWeight: '700',
  },
  confirmModalSend: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  confirmModalSendDisabled: {
    opacity: 0.85,
  },
  confirmModalSendGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  confirmModalSendText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  valeterSheetAvatarFill: {
    width: '100%',
    height: '100%',
  },
  valeterInfoOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'center',
    padding: 22,
  },
  valeterInfoCard: {
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    maxHeight: '85%',
  },
  valeterInfoInner: {
    padding: 18,
  },
  valeterInfoHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 4,
  },
  valeterInfoTitle: {
    flex: 1,
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
  },
  valeterInfoSub: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 12,
  },
  valeterInfoScroll: {
    maxHeight: 320,
  },
  valeterInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  valeterInfoRowText: {
    color: '#E2E8F0',
    fontSize: 14,
    fontWeight: '600',
  },
  valeterInfoHint: {
    marginTop: 16,
    color: 'rgba(148,163,184,0.95)',
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 18,
  },
  cardWrapper: {
    marginRight: 12,
  },
  curvedCard: {
    borderRadius: CURVED_BOOKING_CARD.borderRadius,
    overflow: 'hidden',
  },
  valeterSearchCard: {
    backgroundColor: 'rgba(15,23,42,0.75)',
    overflow: 'hidden',
  },
  cardsScrollContent: {
    paddingRight: 16,
    paddingBottom: 14,
  },
  valeterCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
    zIndex: 1,
  },
  bestMatchBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 5,
    backgroundColor: 'rgba(251, 191, 36, 0.18)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(251, 191, 36, 0.4)',
  },
  bestMatchText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#FBBF24',
  },
  arrivalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(96,165,250,0.35)',
    backgroundColor: 'rgba(96,165,250,0.14)',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  arrivalText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#60A5FA',
  },
  stickySummary: {
    position: 'absolute',
    left: 16,
    right: 16,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.9)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    zIndex: 50,
  },
  stickySummaryText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#E2E8F0',
    textAlign: 'center',
  },
  valeterCard: {
    padding: 14,
    overflow: 'hidden',
    minHeight: 154,
    borderRadius: 20,
  },
  /** Searching/empty state card – same height as valeter cards */
  searchStateCard: {
    minHeight: 140,
  },
  valeterVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    marginBottom: 2,
  },
  valeterVehicleText: {
    color: 'rgba(226,232,240,0.82)',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  utilityLabelsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 7,
    marginBottom: 2,
  },
  utilityChip: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    borderRadius: 999,
    borderWidth: 1,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  utilityChipOn: {
    backgroundColor: 'rgba(16,185,129,0.14)',
    borderColor: 'rgba(16,185,129,0.32)',
  },
  utilityChipOff: {
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderColor: 'rgba(148,163,184,0.22)',
  },
  utilityChipText: {
    fontSize: 10,
    fontWeight: '700',
  },
  utilityChipTextOn: {
    color: '#10B981',
  },
  utilityChipTextOff: {
    color: '#94A3B8',
  },
  valeterCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 3,
  },
  valeterCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  valeterAvatarWrap: {
    width: 58,
    height: 58,
    borderRadius: 16,
    marginRight: 12,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.35)',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  valeterAvatar: {
    width: '100%',
    height: '100%',
  },
  valeterAvatarPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '40',
  },
  valeterOnlineBadgeSmall: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  valeterCardContent: {
    flex: 1,
    minWidth: 0,
  },
  valeterKicker: {
    color: 'rgba(226,232,240,0.72)',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.7,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  valeterTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
  },
  valeterStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginBottom: 6,
  },
  valeterStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  valeterStatusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  valeterCardBottomRow: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(126,184,212,0.2)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  valeterSelectedBadge: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: '#10B98120',
    borderWidth: 1,
    borderColor: '#10B98140',
  },
  valeterCtaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  valeterCtaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
  },
  valeterCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  valeterCtaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  valeterEmptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  uberValeterCard: {
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterCardSelected: {
    borderColor: '#60A5FA',
    shadowColor: '#60A5FA',
    shadowOpacity: 0.3,
  },
  uberValeterCardContent: {
    width: '100%',
  },
  uberValeterHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  uberValeterLeft: {
    position: 'relative',
  },
  uberProfileImage: {
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 2,
    borderColor: '#60A5FA',
  },
  uberOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  uberOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  uberValeterInfo: {
    flex: 1,
  },
  uberValeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  uberValeterName: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: 0.2,
  },
  uberSelectedBadge: {
    marginLeft: 8,
  },
  uberValeterActionRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterButton: {
    backgroundColor: '#60A5FA',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberValeterButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  searchRingWrap: {
    width: 64,
    height: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchRingOuter: {
    position: 'absolute',
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 3,
    borderColor: SKY + '50',
    borderTopColor: SKY,
    borderRightColor: SKY,
  },
  searchRingInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: SKY + '12',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 14,
  },
  loadingSubtext: {
    color: '#94A3B8',
    fontSize: 13,
  },
  emptyContent: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 50,
    height: 50,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '8A',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  valeterCardTrustBlock: {
    marginTop: 8,
    gap: 4,
  },
  valeterCardTrustLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterCardTrustLineHidden: {
    opacity: 0.35,
  },
  valeterCardTrustText: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '600',
  },
  uberValeterStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexWrap: 'nowrap',
  },
  uberStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.28)',
    backgroundColor: 'rgba(30,41,59,0.45)',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  uberStatText: {
    color: 'rgba(226,232,240,0.86)',
    fontSize: 11,
    fontWeight: '700',
  },
});
