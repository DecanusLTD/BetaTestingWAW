import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import InfoIconButton from '../../../../src/components/shared/InfoIconButton';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { DEFAULT_MAP_REGION, MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../src/constants/mapConstants';
import UnifiedBookingCard from '../../../../src/components/booking/UnifiedBookingCard';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { getVehicleSize } from '../../../../src/pricing/pricingEngine';
import { CAR_IMAGE, CARWASH_IMAGE } from '../../../assets/assetExports';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

type TierId = 'bronze-wash' | 'silver-wash' | 'gold-wash' | 'platinum-wash' | 'emerald-wash';

const TIER_COLORS = {
  'bronze-wash': { main: '#CD7F32', light: 'rgba(205,127,50,0.25)', border: 'rgba(205,127,50,0.5)' },
  'silver-wash': { main: '#A8A8A8', light: 'rgba(168,168,168,0.2)', border: 'rgba(168,168,168,0.5)' },
  'gold-wash': { main: '#FFD700', light: 'rgba(255,215,0,0.2)', border: 'rgba(255,215,0,0.5)' },
  'platinum-wash': { main: '#E5E4E2', light: 'rgba(229,228,226,0.2)', border: 'rgba(229,228,226,0.5)' },
  'emerald-wash': { main: '#059669', light: 'rgba(5,150,105,0.25)', border: 'rgba(5,150,105,0.5)' },
} as const;

type ServiceUI = {
  id: TierId;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number;
  is_enabled: boolean;
  badge?: 'Best Value' | 'Most Popular' | 'Premium Detail';
  bulletPoints?: string[];
  descriptionTitle?: string;
};

const TIERS: Array<{
  id: TierId;
  service_name: 'Bronze Wash' | 'Silver Wash' | 'Gold Wash' | 'Platinum Wash' | 'Emerald Wash';
  defaultDesc: string;
  defaultMinutes: number;
  badge?: 'Best Value' | 'Most Popular' | 'Premium Detail';
}> = [
  {
    id: 'bronze-wash',
    service_name: 'Bronze Wash',
    defaultDesc: 'Quick Refresh. Perfect for maintaining a clean car between deeper valets. Fast, affordable maintenance clean.',
    defaultMinutes: 30,
  },
  {
    id: 'silver-wash',
    service_name: 'Silver Wash',
    defaultDesc: 'Essential Valet. A complete inside & outside clean to keep your vehicle looking its best. Most popular choice.',
    defaultMinutes: 60,
  },
  {
    id: 'gold-wash',
    service_name: 'Gold Wash',
    defaultDesc: 'Deep Restore. A thorough deep clean designed to reset heavily used vehicles. Ideal for overdue cleans.',
    defaultMinutes: 90,
    badge: 'Most Popular',
  },
  {
    id: 'platinum-wash',
    service_name: 'Platinum Wash',
    defaultDesc: 'Showroom Detail. Our most advanced valet for maximum restoration and protection. Near showroom condition.',
    defaultMinutes: 120,
    badge: 'Premium Detail',
  },
  {
    id: 'emerald-wash',
    service_name: 'Emerald Wash',
    defaultDesc: 'Interior Deep Clean. A thorough interior clean bringing your cabin back to a like-new condition.',
    defaultMinutes: 105,
    badge: 'Best Value',
  },
];

function money(n: any) {
  let v: number;
  if (typeof n === 'string') v = Number(n);
  else if (typeof n === 'number') v = n;
  else v = 0;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  const scheduledAt = params.scheduledAt as string | undefined;
  const preSelectedServiceId = params.serviceId as TierId | undefined;

  const [selectedService, setSelectedService] = useState<TierId | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [infoModalService, setInfoModalService] = useState<ServiceUI | null>(null);
  const [washTypeModalVisible, setWashTypeModalVisible] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const [hubPulseVisible, setHubPulseVisible] = useState(false);
  const hubPulseScale = useRef(new Animated.Value(1)).current;
  const hubPulseOpacity = useRef(new Animated.Value(0.5)).current;
  const hubPulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  /** Vehicle size for pricing: small / medium / large / xl / xxl (from selected vehicle) */
  const [vehicleSizeKey, setVehicleSizeKey] = useState<'small' | 'medium' | 'large' | 'xl' | 'xxl'>('medium');

  useEffect(() => {
    if (liveCoords) {
      setUserLocation({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
      setRegion({ latitude: liveCoords.latitude, longitude: liveCoords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    }
  }, [liveCoords]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // After 1–2s on select service screen, tint and pulse the hub location on the map
  useEffect(() => {
    if (!hubLocation) {
      setHubPulseVisible(false);
      hubPulseScale.setValue(1);
      hubPulseOpacity.setValue(0.5);
      hubPulseLoopRef.current = null;
      return;
    }
    const timer = setTimeout(() => {
      setHubPulseVisible(true);
      hubPulseScale.setValue(1);
      hubPulseOpacity.setValue(0.5);
      const pulseOut = Animated.parallel([
        Animated.timing(hubPulseScale, { toValue: 1.85, duration: 1200, useNativeDriver: true }),
        Animated.timing(hubPulseOpacity, { toValue: 0, duration: 1200, useNativeDriver: true }),
      ]);
      const reset = Animated.parallel([
        Animated.timing(hubPulseScale, { toValue: 1, duration: 1, useNativeDriver: true }),
        Animated.timing(hubPulseOpacity, { toValue: 0.5, duration: 1, useNativeDriver: true }),
      ]);
      hubPulseLoopRef.current = Animated.loop(Animated.sequence([pulseOut, Animated.delay(200), reset]));
      hubPulseLoopRef.current.start();
    }, 1500);
    return () => {
      clearTimeout(timer);
      hubPulseLoopRef.current?.stop();
    };
  }, [hubLocation?.latitude, hubLocation?.longitude]);

  useEffect(() => {
    getCurrentLocation();
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    loadTierPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  // Load vehicle to get size for pricing (cards show price for your vehicle size)
  useEffect(() => {
    if (!vehicleId) {
      setVehicleSizeKey('medium');
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('vehicles')
        .select('id, make, model, type, size')
        .eq('id', vehicleId)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setVehicleSizeKey('medium');
        return;
      }
      const v = data as { make?: string; model?: string; type?: string; size?: string };
      if (v.size === 'small' || v.size === 'medium' || v.size === 'large' || v.size === 'xl' || v.size === 'xxl') {
        setVehicleSizeKey(v.size);
        return;
      }
      const engineSize = getVehicleSize({ make: v.make, model: v.model, type: v.type });
      let key: 'small' | 'medium' | 'large' | 'xl' | 'xxl' = 'medium';
      if (engineSize === 'SMALL') key = 'small';
      else if (engineSize === 'XXL') key = 'xxl';
      else if (engineSize === 'XL') key = 'xl';
      else if (engineSize === 'LARGE') key = 'large';
      setVehicleSizeKey(key);
    })();
    return () => { cancelled = true; };
  }, [vehicleId]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data?.latitude != null && data?.longitude != null) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Wash Hub',
          address: data.address || '',
        };
        setHubLocation(hub);
        setRegion({
          latitude: hub.latitude,
          longitude: hub.longitude,
latitudeDelta: 0.001,
      longitudeDelta: 0.001,
        });
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadTierPrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      const built: ServiceUI[] = TIERS.map((t) => {
        const hit = map.get(t.service_name);
        const minutes = hit?.minutes ? hit.minutes : t.defaultMinutes;
        const durText = `${minutes} min`;
        const serviceOption = serviceOptions.find(so => so.id === t.id);

        return {
          id: t.id,
          name: serviceOption?.name ?? t.service_name,
          desc: serviceOption?.desc ?? t.defaultDesc,
          minutes,
          dur: durText,
          price: hit?.price ?? 0,
          is_enabled: hit?.enabled ?? false,
          badge: t.badge,
          bulletPoints: serviceOption?.bulletPoints || [],
          descriptionTitle: serviceOption?.descriptionTitle,
        };
      }).filter((s) => s.is_enabled);

      setServices(built);

      if (preSelectedServiceId && built.some((b) => b.id === preSelectedServiceId)) {
        setSelectedService(preSelectedServiceId);
        if (preSelectedServiceId !== 'bronze-wash') setWashType('both');
      } else {
        setSelectedService((prev) => {
          if (!prev) return prev;
          const stillThere = built.some((b) => b.id === prev);
          return stillThere ? prev : null;
        });
      }
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadTierPrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: TierId) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setWashType(null);
      setWashTypeModalVisible(true);
    } else {
      setWashType('both');
    }
  };

  // When opening from hub details with a pre-selected service, scroll to that card so user sees price and can continue
  useEffect(() => {
    if (services.length === 0 || !selectedService) return;
    const index = services.findIndex((s) => s.id === selectedService);
    if (index < 0) return;
    const timer = setTimeout(() => {
      scrollViewRef.current?.scrollTo({
        x: index * BOOKING_CARD.SNAP_INTERVAL,
        animated: true,
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [services, selectedService]);

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
    setWashTypeModalVisible(false);
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  // Calculate pricing tiers (S/M/L/XL/XXL) – same as info icon modal
  const getPriceTiers = (basePrice: number) => {
    return {
      small: basePrice,
      medium: Math.round(basePrice * 1.2 * 100) / 100,
      large: Math.round(basePrice * 1.4 * 100) / 100,
      xl: Math.round(basePrice * 1.6 * 100) / 100,
      xxl: Math.round(basePrice * 1.85 * 100) / 100,
    };
  };

  /** Price for the selected vehicle size (used on cards and for booking) */
  const getPriceForVehicleSize = (basePrice: number) => {
    const tiers = getPriceTiers(basePrice);
    return tiers[vehicleSizeKey];
  };

  const bronzeExteriorPrice = selectedServiceData ? getPriceForVehicleSize(selectedServiceData.price) : 0;
  const bronzeInteriorPrice = selectedServiceData ? getPriceForVehicleSize(selectedServiceData.price) : 0;

  const canContinue =
    !!selectedService &&
    !!locationId &&
    !!vehicleId &&
    (selectedService !== 'bronze-wash' || !!washType);

  const handleContinue = async () => {
    if (!canContinue) return;

    if (!selectedServiceData || !Number.isFinite(selectedServiceData.price) || selectedServiceData.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    await hapticFeedback('medium');

    let finalPrice = getPriceForVehicleSize(selectedServiceData.price);
    if (selectedService === 'bronze-wash') {
      if (washType === 'interior') finalPrice = bronzeInteriorPrice;
      else finalPrice = bronzeExteriorPrice; // Default to exterior if not specified
    }

    const baseParams = {
      serviceId: selectedService,
      vehicleId,
      locationId,
      washType: washType || '',
      price: String(finalPrice),
    };

    if (scheduledAt) {
      router.push({
        pathname: '/owner/booking/physical/confirm',
        params: { ...baseParams, scheduledAt },
      });
    } else {
      router.push({
        pathname: '/owner/booking/physical/schedule',
        params: baseParams,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hubLocation) {
      setRegion({
        latitude: hubLocation.latitude,
        longitude: hubLocation.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    }
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadTierPrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.latitude, longitude: hubLocation.longitude }}>
              <View style={styles.hubMarkerContainer}>
                {hubPulseVisible && (
                  <Animated.View
                    style={[
                      styles.hubMarkerPulseRing,
                      {
                        transform: [{ scale: hubPulseScale }],
                        opacity: hubPulseOpacity,
                      },
                    ]}
                  />
                )}
                <Image
                  source={CARWASH_IMAGE}
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={handleRecenter}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity 
            onPress={handleExitBooking} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Service cards - floating at bottom */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            bottom: 72 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
          contentContainerStyle={styles.cardsScrollContent}
          onMomentumScrollEnd={(e) => {
            const index = Math.round(e.nativeEvent.contentOffset.x / BOOKING_CARD.SNAP_INTERVAL);
            if (services[index]) {
              handleServiceSelect(services[index].id);
            }
          }}
        >
          {services.map((service) => {
            const isSelected = selectedService === service.id;
            const tierColor = TIER_COLORS[service.id];
            const serviceIcon = serviceOptions.find((o) => o.id === service.id)?.icon ?? 'water-outline';

            return (
              <View key={service.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <UnifiedBookingCard
                  style={styles.serviceCardFill}
                  stripColor={tierColor.main}
                  onPress={() => handleServiceSelect(service.id)}
                >
                  {isSelected && (
                    <LinearGradient colors={[tierColor.main + '15', tierColor.main + '08', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                  )}
                  <View style={[styles.modernCard, isSelected && styles.modernCardSelected]}>
                    <View style={styles.cardTop}>
                      <View style={[styles.iconWrap, { backgroundColor: tierColor.main + '25', borderColor: tierColor.main + '40' }]}>
                        <Ionicons name={serviceIcon as any} size={22} color={tierColor.main} />
                      </View>
                      <View style={styles.cardContent}>
                        <View style={styles.titleRow}>
                          <View style={styles.titleAndBadge}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{service.name}</Text>
                            {service.badge ? (
                              <View style={[styles.serviceBadgePill, { backgroundColor: tierColor.main + '30', borderColor: tierColor.main + '50' }]}>
                                <Text style={[styles.serviceBadgePillText, { color: tierColor.main }]} numberOfLines={1}>{service.badge}</Text>
                              </View>
                            ) : null}
                          </View>
                          <InfoIconButton
                            onPress={() => { hapticFeedback('light'); setInfoModalService(service); }}
                            accentColor={tierColor.main}
                            icon="information-circle"
                          />
                        </View>
                        <Text style={styles.cardSubtitle}>{service.dur}</Text>
                        {isSelected && service.id === 'platinum-wash' && (
                          <Text style={styles.serviceReinforcement}>Deep clean — no paint correction</Text>
                        )}
                        <View style={styles.cardMetaRow}>
                          <View style={[styles.quickHint, { backgroundColor: tierColor.main + '15' }]}>
                            <Text style={[styles.quickHintText, { color: tierColor.main }]}>
                              From £{getPriceForVehicleSize(service.price).toFixed(0)}
                            </Text>
                          </View>
                          {isSelected && selectedService === 'bronze-wash' && (
                            <TouchableOpacity
                              onPress={() => setWashTypeModalVisible(true)}
                              style={[styles.washTypeChipSmall, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}
                              activeOpacity={0.8}
                            >
                              {washType ? (
                                <>
                                  <Ionicons
                                    name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                                    size={14}
                                    color={tierColor.main}
                                  />
                                  <Text style={[styles.washTypeChipSmallText, { color: tierColor.main }]}>
                                    {washType === 'exterior' ? 'Exterior' : 'Interior'}
                                  </Text>
                                  <Ionicons name="chevron-forward" size={12} color={tierColor.main} />
                                </>
                              ) : (
                                <Text style={[styles.washTypeChipSmallText, { color: tierColor.main }]}>Exterior / Interior</Text>
                              )}
                            </TouchableOpacity>
                          )}
                        </View>
                      </View>
                    </View>
                  </View>
                </UnifiedBookingCard>
              </View>
            );
          })}
        </ScrollView>
      </Animated.View>

      {/* Continue button - same structure as vehicle step (full-width, same size) */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
          <TouchableOpacity
          onPress={handleContinue}
          disabled={!canContinue}
          style={[styles.ctaButton, { width: CARD_WIDTH }]}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={canContinue ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.ctaGradient}
          >
            <Text style={styles.ctaText}>
              {(() => {
                if (!canContinue) return 'Select a service';
                if (selectedService === 'bronze-wash' && washType == null) return 'Select wash type';
                return 'Continue';
              })()}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Service info popup – updated UI (same as detailing) */}
      <Modal
        visible={!!infoModalService}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setInfoModalService(null)}
      >
        <View style={styles.infoModalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setInfoModalService(null)} />
          <View
            style={[
              styles.infoModalCard,
              infoModalService && { borderColor: TIER_COLORS[infoModalService.id].border, shadowColor: TIER_COLORS[infoModalService.id].main },
            ]}
            pointerEvents="box-none"
          >
            {infoModalService && (() => {
              const tc = TIER_COLORS[infoModalService.id];
              return (
                <>
                  <View style={[styles.infoModalHeader, { backgroundColor: tc.light + '18', borderBottomColor: tc.light + '40' }]}>
                    <View style={[styles.infoModalAccent, { backgroundColor: tc.main }]} />
                    <View style={styles.infoModalHeaderContent}>
                      <Text style={[styles.infoModalTitle, { color: colors.headerText }]}>{infoModalService.name}</Text>
                      {infoModalService.badge && (
                        <View style={[styles.infoModalBadge, { backgroundColor: tc.light, borderColor: tc.border }]}>
                          <Text style={[styles.infoModalBadgeText, { color: tc.main }]}>{infoModalService.badge}</Text>
                        </View>
                      )}
                    </View>
                    <TouchableOpacity
                      onPress={() => setInfoModalService(null)}
                      style={styles.infoModalCloseBtn}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={22} color="#94A3B8" />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.infoModalScrollWrap}>
                    <ScrollView
                      style={styles.infoModalScroll}
                      contentContainerStyle={styles.infoModalScrollContent}
                      showsVerticalScrollIndicator={true}
                      bounces={true}
                    >
                    <View style={[styles.infoModalPriceRow, { borderLeftColor: tc.main }]}>
                      <Text style={[styles.infoModalPrice, { color: tc.main }]}>£{infoModalService.price.toFixed(0)}</Text>
                      <View style={styles.infoModalDuration}>
                        <Ionicons name="time-outline" size={14} color="#64748B" />
                        <Text style={styles.infoModalDurationText}>{infoModalService.dur}</Text>
                      </View>
                    </View>
                    {infoModalService.descriptionTitle ? (
                      <Text style={[styles.infoModalDescTitle, { color: tc.main }]}>{infoModalService.descriptionTitle}</Text>
                    ) : null}
                    <Text style={styles.infoModalDesc}>{infoModalService.desc}</Text>
                    {infoModalService.bulletPoints && infoModalService.bulletPoints.length > 0 && (
                      <View style={styles.infoModalSection}>
                        <View style={styles.infoModalSectionTitleRow}>
                          <Ionicons name="checkmark-done-circle" size={16} color={tc.main} />
                          <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Includes</Text>
                        </View>
                        {infoModalService.bulletPoints.map((f) => (
                          <View key={f} style={styles.infoModalFeatureRow}>
                            <Ionicons name="checkmark-circle" size={18} color={tc.main} />
                            <Text style={styles.infoModalFeatureText}>{f}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                    <View style={[styles.infoModalSection, { borderTopColor: tc.light + '50' }]}>
                      <View style={styles.infoModalSectionTitleRow}>
                        <Ionicons name="car-sport-outline" size={16} color={tc.main} />
                        <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Price by size</Text>
                      </View>
                      <View style={styles.infoModalTiers}>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>S</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).small.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>M</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).medium.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>L</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).large.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).xl.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>XXL</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).xxl.toFixed(0)}</Text>
                        </View>
                      </View>
                    </View>
                    </ScrollView>
                  </View>
                  <TouchableOpacity
                    onPress={() => setInfoModalService(null)}
                    style={[styles.infoModalDoneBtn, { backgroundColor: tc.main }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </>
              );
            })()}
          </View>
        </View>
      </Modal>

      {/* Bronze wash type selection overlay - recreated, rendered at root */}
      <Modal
        visible={washTypeModalVisible}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setWashTypeModalVisible(false)}
      >
        <View style={styles.washModalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setWashTypeModalVisible(false)} />
          <Pressable style={styles.washTypeModalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.washTypeModalHeader}>
              <View style={styles.washTypeModalHeaderTop}>
                <View style={[styles.washTypeModalBadge, { backgroundColor: TIER_COLORS['bronze-wash'].main }]}>
                  <MaterialCommunityIcons name="car-wash" size={18} color="#0F172A" />
                  <Text style={styles.washTypeModalBadgeText}>Bronze Wash</Text>
                </View>
                <TouchableOpacity
                  onPress={() => setWashTypeModalVisible(false)}
                  style={styles.washTypeModalClose}
                  hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                >
                  <Ionicons name="close" size={22} color="#94A3B8" />
                </TouchableOpacity>
              </View>
              <Text style={styles.washTypeModalTitle}>What do you want cleaned?</Text>
              <Text style={styles.washTypeModalSubtitle}>Exterior or interior — both include our quick & affordable bronze treatment</Text>
            </View>
            <View style={styles.washTypeModalOptions}>
              <TouchableOpacity
                onPress={() => handleWashTypeSelect('exterior')}
                style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
                activeOpacity={0.85}
              >
                <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
                  <Ionicons name="car-sport-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
                </View>
                <View style={styles.washTypeModalOptionBody}>
                  <Text style={styles.washTypeModalOptionLabel}>Exterior</Text>
                  <Text style={styles.washTypeModalOptionDesc}>Wheels & arches, snow foam, hand wash, rinse, dry, windows & mirrors</Text>
                </View>
                <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
                  £{(bronzeExteriorPrice || 0).toFixed(0)}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleWashTypeSelect('interior')}
                style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
                activeOpacity={0.85}
              >
                <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
                  <Ionicons name="layers-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
                </View>
                <View style={styles.washTypeModalOptionBody}>
                  <Text style={styles.washTypeModalOptionLabel}>Interior</Text>
                  <Text style={styles.washTypeModalOptionDesc}>Vacuum, wipe-down, steering wheel, glass & air freshener</Text>
                </View>
                <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
                  £{(bronzeInteriorPrice || 0).toFixed(0)}
                </Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
    zIndex: 100,
  },
  cardsScrollContent: {
    paddingRight: 16,
    height: 148,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 64,
    height: 64,
  },
  hubMarkerPulseRing: {
    position: 'absolute',
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: SKY,
  },
  hubMarkerImage: {
    width: 64,
    height: 64,
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },

  cardWrapper: {
    marginRight: 12,
    height: '100%',
  },
  serviceCardFill: {
    flex: 1,
  },
  modernCard: {
    padding: 10,
    overflow: 'hidden',
  },
  modernCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 10,
    marginRight: 8,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  titleAndBadge: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  serviceCardSelected: {
    elevation: 4,
    shadowOpacity: 0.18,
    shadowRadius: 10,
  },
  badgePill: {
    alignSelf: 'flex-start',
    marginBottom: 6,
    zIndex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 2,
  },
  badgePillIconWrap: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(15,23,42,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgePillText: {
    color: '#0F172A',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.25,
    maxWidth: 110,
  },
  cardInner: {
    padding: 16,
    paddingTop: 14,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  serviceIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: -0.2,
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 6,
    fontStyle: 'italic',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.12)',
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  serviceCardInfoBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    zIndex: 10,
  },
  tierBadgeBox: {
    width: 72,
    height: 72,
    marginLeft: 14,
  },
  tierBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  washTypeChipSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 5,
    paddingHorizontal: 9,
    borderRadius: 8,
    borderWidth: 1,
    gap: 4,
  },
  washTypeChipSmallText: {
    fontSize: 11,
    fontWeight: '700',
  },
  washTypeModalContent: {
    width: '100%',
    maxWidth: 360,
    marginHorizontal: 24,
    backgroundColor: '#1E293B',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(205,127,50,0.4)',
    overflow: 'hidden',
  },
  washTypeModalHeader: {
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(205,127,50,0.2)',
  },
  washTypeModalHeaderTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  washTypeModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  washTypeModalBadgeText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washTypeModalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  washTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  washTypeModalOptions: {
    padding: 20,
    gap: 12,
  },
  washTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    backgroundColor: 'rgba(205,127,50,0.06)',
  },
  washTypeModalOptionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  washTypeModalOptionBody: {
    flex: 1,
    minWidth: 0,
  },
  washTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  washTypeModalOptionPrice: {
    fontSize: 18,
    fontWeight: '800',
    marginLeft: 12,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal – clean, matches app
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  washModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(5,15,30,0.88)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalCard: {
    width: '100%',
    maxWidth: 360,
    height: '88%',
    maxHeight: '88%',
    backgroundColor: '#1E293B',
    borderRadius: 24,
    borderWidth: 1.5,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    paddingLeft: 24,
    borderBottomWidth: 1,
    position: 'relative',
  },
  infoModalAccent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 2,
    borderBottomLeftRadius: 2,
  },
  infoModalHeaderContent: { flex: 1, marginLeft: 8 },
  infoModalTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
    color: '#F9FAFB',
  },
  infoModalBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
  },
  infoModalBadgeText: { fontSize: 12, fontWeight: '700' },
  infoModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 18,
    paddingBottom: 24,
  },
  infoModalPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingLeft: 14,
    borderLeftWidth: 4,
    borderRadius: 2,
  },
  infoModalPrice: { fontSize: 26, fontWeight: '800' },
  infoModalDuration: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoModalDurationText: { color: '#94A3B8', fontSize: 14, fontWeight: '600' },
  infoModalDescTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 20,
  },
  infoModalSection: {
    marginBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalSectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  infoModalSectionTitle: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  infoModalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  infoModalFeatureText: {
    color: '#E2E8F0',
    fontSize: 14,
    flex: 1,
    lineHeight: 21,
  },
  infoModalTiers: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 6,
  },
  infoModalTierItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  infoModalTierLabel: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoModalTierValue: { fontSize: 16, fontWeight: '800' },
  infoModalDoneBtn: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '800' },

  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
});
