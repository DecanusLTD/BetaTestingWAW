import React, { useEffect, useMemo, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Alert,
  Image,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../src/constants/mapConstants';
import UnifiedBookingCard from '../../../../src/components/booking/UnifiedBookingCard';
import { colors } from '../../../../src/constants/colors';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { CAR_IMAGE, CARWASH_IMAGE } from '../../../assets/assetExports';

const SKY = colors.SKY;
const BG = colors.BG;
const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

type LocationRow = {
  id: string;
  name: string | null;
  address: string | null;
};

type OpeningHoursRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null; // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number; // 30
};

type LocationServiceRow = {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
};

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

function parseHHMM(raw: string | null): { h: number; m: number } | null {
  const s = String(raw || '').trim();
  if (!s) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return { h: hh, m: mm };
}

// Convert JS getDay (0=Sun..6=Sat) -> our DB day (0=Mon..6=Sun)
function jsDayToDbDay(jsDay: number) {
  // Sun(0)->6, Mon(1)->0, Tue(2)->1 ... Sat(6)->5
  return (jsDay + 6) % 7;
}

function buildSlotsFromHours(hours: OpeningHoursRow[], daysAhead = 7) {
  const now = new Date();
  const slots: string[] = [];

  // map day -> hours row
  const byDay = new Map<number, OpeningHoursRow>();
  for (const r of hours) byDay.set(r.day_of_week, r);

  for (let offset = 0; offset < daysAhead; offset++) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + offset);

    const dbDay = jsDayToDbDay(d.getDay());
    const row = byDay.get(dbDay);
    if (!row?.is_open) continue;

    const open = parseHHMM(row.open_time);
    const close = parseHHMM(row.close_time);
    const step = Number(row.slot_minutes || 30);

    if (!open || !close) continue;
    if (!Number.isFinite(step) || step <= 0) continue;

    const start = new Date(d);
    start.setHours(open.h, open.m, 0, 0);

    const end = new Date(d);
    end.setHours(close.h, close.m, 0, 0);

    // if close <= open, ignore (bad config)
    if (end.getTime() <= start.getTime()) continue;

    // generate slots up to (but not including) end
    for (let t = start.getTime(); t + step * 60_000 <= end.getTime(); t += step * 60_000) {
      const slotDate = new Date(t);

      // don't show past slots for today
      if (slotDate.getTime() < now.getTime() + 2 * 60_000) continue;

      slots.push(slotDate.toISOString());
    }
  }

  // sort ascending
  slots.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  return slots;
}

export default function PhysicalSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
    price?: string;
  }>();

  const locationId = params.locationId;
  const serviceId = params.serviceId;
  const vehicleId = params.vehicleId;
  const washType = params.washType;
  const priceFromParams = params.price;

  const [location, setLocation] = useState<LocationRow & { latitude?: number; longitude?: number } | null>(null);
  const [serviceRow, setServiceRow] = useState<LocationServiceRow | null>(null);

  const [loading, setLoading] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(true);

  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);
  const { coords } = useLiveLocation();

  useEffect(() => {
    if (coords) {
      setUserLocation({ latitude: coords.latitude, longitude: coords.longitude });
      setRegion({ latitude: coords.latitude, longitude: coords.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    }
  }, [coords]);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;

  // fallback (if your booking flow still passes a local serviceId from constants)
  const fallbackService = useMemo(
    () => serviceOptions.find((opt) => opt.id === serviceId),
    [serviceId]
  );

  // Check if a string is a valid UUID format
  const isValidUUID = (str: string | undefined): boolean => {
    if (!str) return false;
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str);
  };

  useEffect(() => {
    if (!locationId) return;

    const loadAll = async () => {
      try {
        setLoading(true);

        // Only query location_services if serviceId is a valid UUID
        const shouldQueryService = serviceId && isValidUUID(serviceId);

        const [{ data: loc, error: locErr }, svcRes] = await Promise.all([
          supabase
            .from('car_wash_locations')
            .select('id,name,address,latitude,longitude')
            .eq('id', locationId)
            .maybeSingle(),
          shouldQueryService
            ? supabase
                .from('location_services')
                .select('id,location_id,service_name,is_enabled,price,duration_minutes')
                .eq('id', serviceId)
                .maybeSingle()
            : Promise.resolve({ data: null, error: null } as any),
        ]);

        if (locErr) throw locErr;

        const locationData = (loc as LocationRow & { latitude?: number; longitude?: number }) ?? null;
        setLocation(locationData);
        
        // Update map region if location has coordinates
        if (locationData?.latitude && locationData?.longitude) {
          setRegion({
            latitude: Number(locationData.latitude),
            longitude: Number(locationData.longitude),
            latitudeDelta: 0.001,
            longitudeDelta: 0.001,
          });
        }

        // Only accept service if it belongs to this location (prevents mismatched IDs)
        if (svcRes?.error) {
          // don’t hard fail, we can still show fallback service from constants
          console.warn('[PhysicalSchedule] service load error:', svcRes.error.message);
          setServiceRow(null);
        } else {
          const svc = (svcRes?.data ?? null) as LocationServiceRow | null;
          if (svc?.location_id === locationId) setServiceRow(svc);
          else setServiceRow(null);
        }
      } catch (e: any) {
        console.error('[PhysicalSchedule] loadAll error:', e);
        Alert.alert('Error', e?.message || 'Failed to load booking info');
        setLocation(null);
        setServiceRow(null);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [locationId, serviceId]);

  const loadSlots = async () => {
    if (!locationId) return;

    try {
      setLoadingSlots(true);

      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('id,location_id,day_of_week,is_open,open_time,close_time,slot_minutes')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as OpeningHoursRow[];
      const slots = buildSlotsFromHours(rows, 7);

      setTimeSlots(slots);

      // if previously selected slot is no longer valid
      if (selectedSlot && !slots.includes(selectedSlot)) setSelectedSlot(null);
    } catch (e: any) {
      console.error('[PhysicalSchedule] loadSlots error:', e);

      // If table doesn't exist yet / not migrated in this env, show a helpful empty state
      setTimeSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  useEffect(() => {
    loadSlots();
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };
        setUserLocation(coords);
      }
    } catch {}
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    }
  };

  const handleContinue = async () => {
    const hasRequired = Boolean(serviceId && selectedSlot && locationId && vehicleId);
    if (hasRequired) {
      await hapticFeedback('medium');
      const priceToPass = (() => {
        if (priceFromParams && !Number.isNaN(Number(priceFromParams))) return priceFromParams;
        if (serviceRow?.price != null) return String(serviceRow.price);
        if (fallbackService?.price != null) return String(fallbackService.price);
        return undefined;
      })();
      router.push({
        pathname: '/owner/booking/physical/confirm',
        params: {
          locationId,
          serviceId,
          vehicleId,
          washType: washType || '',
          scheduledAt: selectedSlot,
          ...(priceToPass && { price: priceToPass }),
        },
      });
    }
  };

  const hasRequiredParams = Boolean(locationId && serviceId && vehicleId);
  if (!hasRequiredParams) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  function renderSlotCardContent() {
    if (loading) {
      return (
        <UnifiedBookingCard stripColor={SKY}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading time slots...</Text>
          </View>
        </UnifiedBookingCard>
      );
    }
    if (loadingSlots) {
      return (
        <UnifiedBookingCard stripColor={SKY}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading available slots...</Text>
          </View>
        </UnifiedBookingCard>
      );
    }
    if (timeSlots.length === 0) {
      return (
        <UnifiedBookingCard stripColor={SKY}>
          <View style={styles.emptySlotsCard}>
            <Ionicons name="time-outline" size={22} color={SKY} style={{ opacity: 0.9 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.emptyTitle}>No slots available</Text>
              <Text style={styles.emptySub}>
                This location hasn't set opening hours yet (or they're closed for the next 7 days).
              </Text>
            </View>
          </View>
        </UnifiedBookingCard>
      );
    }
    return (
      <>
        <View style={styles.slotHeader}>
          <Text style={styles.slotHeaderTitle}>Choose a time slot</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadSlots();
            }}
            activeOpacity={0.85}
            style={styles.refreshBtn}
          >
            {loadingSlots ? (
              <ActivityIndicator size="small" color={SKY} />
            ) : (
              <Ionicons name="refresh" size={18} color={SKY} />
            )}
          </TouchableOpacity>
        </View>
        {selectedSlot && (
          <View style={styles.digitalClockBanner}>
            <View style={styles.digitalClockInner}>
              <Text style={styles.digitalClockTime}>
                {new Date(selectedSlot).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false })}
              </Text>
              <Text style={styles.digitalClockDate}>
                {new Date(selectedSlot).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
              </Text>
            </View>
            <Ionicons name="time" size={24} color={SKY} style={{ opacity: 0.8 }} />
          </View>
        )}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
          contentContainerStyle={styles.slotRow}
        >
          {timeSlots.map((slot) => {
            const date = new Date(slot);
            const isSelected = selectedSlot === slot;
            const timeStr = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
            const dateStr = date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
            return (
              <View key={slot} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <UnifiedBookingCard
                  stripColor={SKY}
                  onPress={() => {
                    hapticFeedback('light');
                    setSelectedSlot(slot);
                  }}
                >
                  <View style={[styles.slotCard, isSelected && styles.slotSelected]}>
                    <View style={styles.slotCardContentRow}>
                      <View style={styles.slotCardMain}>
                        <View style={styles.slotCardHeader}>
                          <Ionicons name="time-outline" size={28} color={isSelected ? SKY : '#94A3B8'} />
                          {isSelected && <Ionicons name="checkmark-circle" size={22} color={SKY} />}
                        </View>
                        <Text style={styles.slotDateText}>{dateStr}</Text>
                        <Text style={styles.slotMetaText}>
                          {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                      </View>
                      <View style={styles.slotClockBox}>
                        <View style={[styles.digitalClockFace, isSelected && styles.digitalClockFaceSelected]}>
                          <Text style={styles.digitalClockDigits}>{timeStr}</Text>
                          <Text style={styles.digitalClockLabel}>time</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </UnifiedBookingCard>
              </View>
            );
          })}
        </ScrollView>
      </>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {location?.latitude && location?.longitude && (
            <Marker coordinate={{ latitude: Number(location.latitude), longitude: Number(location.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Image
                  source={CARWASH_IMAGE}
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={handleRecenter}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader 
        title="Pick time slot" 
        subtitle={location?.name || 'Select your preferred time'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity 
            onPress={handleExitBooking} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Time slot cards - same position as vehicle/location/service */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            bottom: 96 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        <View>
              {renderSlotCardContent()}
        </View>
      </Animated.View>

      {/* Continue button - same structure as vehicle/service (full-width, same size) */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedSlot}
          style={[styles.ctaButton, { width: CARD_WIDTH }]}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={selectedSlot ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.ctaGradient}
          >
            <Text style={styles.ctaText}>{selectedSlot ? 'Continue' : 'Select a time slot'}</Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 64,
    height: 64,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slotHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  slotHeaderTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  refreshBtn: {
    width: 38,
    height: 38,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(135,206,235,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotRow: { 
    paddingVertical: 4, 
    paddingRight: 28,
  },
  cardWrapper: {
    width: CARD_WIDTH,
    marginRight: 12,
  },
  slotCard: {
    width: '100%',
    padding: 20,
    overflow: 'hidden',
  },
  slotSelected: {},
  slotCardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  slotCardMain: {
    flex: 1,
    minWidth: 0,
  },
  slotCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  slotDateText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  slotMetaText: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  slotClockBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  digitalClockFace: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  digitalClockFaceSelected: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderColor: SKY,
  },
  digitalClockDigits: {
    color: SKY,
    fontSize: 18,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
    letterSpacing: 1,
  },
  digitalClockLabel: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 9,
    fontWeight: '600',
    marginTop: 2,
    textTransform: 'uppercase',
  },
  digitalClockBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  digitalClockInner: {
    flex: 1,
  },
  digitalClockTime: {
    color: SKY,
    fontSize: 28,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
    letterSpacing: 2,
  },
  digitalClockDate: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
  },
  emptySlotsCard: {
    padding: 14,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '900' },
  emptySub: { color: 'rgba(249,250,251,0.75)', fontSize: 12, marginTop: 4, lineHeight: 18 },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
});
