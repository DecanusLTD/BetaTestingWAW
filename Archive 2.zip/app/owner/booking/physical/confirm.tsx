import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
  Animated,
  StatusBar,
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../src/constants/mapConstants';
import InfoIconButton from '../../../../src/components/shared/InfoIconButton';
import { customerTheme } from '../../../../src/constants/customerTheme';
import UnifiedBookingCard from '../../../../src/components/booking/UnifiedBookingCard';
import { VehicleInfoOverlay } from '../../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../../src/utils/vehicleStats';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';
import { getActiveBookingForCustomer } from '../../../../src/utils/activeBookingGuard';
import { CAR_IMAGE, CARWASH_IMAGE } from '../../../assets/assetExports';
import { useAdaptiveLayout } from '../../../../src/constants/adaptiveLayout';

type ConfirmVehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  image_url?: string | null;
  photo?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  mileage?: string | number | null;
  type?: string | null;
  size?: string | null;
};

const SKY = colors.SKY;
const BG = colors.BG;
const { width } = Dimensions.get('window');

export default function PhysicalConfirm() {
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const confirmCardWidth =
    Math.min(adaptive.contentMaxWidth, adaptive.width) - adaptive.horizontalPadding * 2;
  const { user } = useAuth();

  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
    scheduledAt?: string;
    price?: string;
  }>();

  const { locationId, serviceId, vehicleId, washType, scheduledAt, price: priceParam } = params;

  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [confirmVehicle, setConfirmVehicle] = useState<ConfirmVehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });
  const [vehicleInfoVisible, setVehicleInfoVisible] = useState(false);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
latitudeDelta: 0.001,
        longitudeDelta: 0.001,
  });
  const { coords } = useLiveLocation();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const service = serviceOptions.find((opt) => opt.id === serviceId);
  const displayPrice = priceParam && !Number.isNaN(Number(priceParam)) ? Number(priceParam) : (service?.price ?? 0);

  /* ------------------ Load location ------------------ */
  useEffect(() => {
    if (!locationId) return;

    const fetchHub = async () => {
      setLoading(true);

      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (!error && data) {
        const hubData = data as Hub;
        setHub(hubData);
        
        // Update map region if hub has coordinates
        if (hubData.latitude && hubData.longitude) {
          setRegion({
            latitude: Number(hubData.latitude),
            longitude: Number(hubData.longitude),
latitudeDelta: 0.001,
        longitudeDelta: 0.001,
          });
        }
      } else {
        setHub(null);
      }

      setLoading(false);
    };

    fetchHub();
    getCurrentLocation();
  }, [locationId]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
    }
  }, [coords]);

  /* Load selected vehicle and stats for confirm page */
  useEffect(() => {
    if (!vehicleId) return;
    let cancelled = false;
    (async () => {
      try {
        const { data: vData, error: vErr } = await supabase
          .from('customer_vehicles')
          .select('*')
          .eq('id', vehicleId)
          .maybeSingle();
        if (vErr || !vData || cancelled) return;
        const v = vData as any;
        setConfirmVehicle({
          id: v.id,
          make: v.make ?? '',
          model: v.model ?? '',
          color: v.color ?? '',
          registration: v.registration ?? '',
          image_url: v.image_url ?? v.photo ?? null,
          photo: v.photo ?? null,
          mot_expiry: v.mot_expiry ?? null,
          mot_expiry_date: v.mot_expiry_date ?? null,
          mileage: v.mileage ?? null,
          type: v.type ?? null,
          size: v.size ?? null,
        });
        const stats = await fetchVehicleStats(vehicleId);
        if (!cancelled) setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
      } catch {
        if (!cancelled) setConfirmVehicle(null);
      }
    })();
    return () => { cancelled = true; };
  }, [vehicleId]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hub?.latitude && hub?.longitude) {
      setRegion({
        latitude: Number(hub.latitude),
        longitude: Number(hub.longitude),
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } else if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    }
  };

  /* ------------------ Confirm booking ------------------ */
  const handleConfirm = async () => {
    if (!user?.id || !service || !hub || !scheduledAt || !vehicleId) return;

    const active = await getActiveBookingForCustomer(user.id);
    if (active) {
      Alert.alert(
        'One booking at a time',
        'You already have an active booking. Please complete or cancel it before starting a new one.',
        [
          { text: 'OK', style: 'cancel' },
          { text: 'View my booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
        ]
      );
      return;
    }

    try {
      setSubmitting(true);
      await hapticFeedback('medium');

      // ✅ IMPORTANT:
      // Your DB does NOT have `customer_id`. Most schemas use `user_id` for the customer.
      // If yours is different (eg `owner_id`), change THIS ONE KEY.
      const BOOKING_CUSTOMER_COL = 'user_id';

      const insertPayload: any = {
        [BOOKING_CUSTOMER_COL]: user.id,
        vehicle_id: vehicleId,
        location_id: hub.id,
        service_type: service.id,
        service_name: service.name,
        price: displayPrice,
        wash_type: washType || null,
        status: 'pending_payment',
        scheduled_at: scheduledAt,
        location_address: hub.address,
        location_lat: hub.latitude,
        location_lng: hub.longitude,
        // created_at: new Date().toISOString(), // usually handled by DB default
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert(insertPayload)
        .select('id')
        .single();

      if (error) throw error;

      router.replace({
        pathname: '/owner/booking/payment',
        params: { bookingId: data.id },
      });
    } catch (err: any) {
      console.error('[physical-confirm] booking error', err);
      Alert.alert('Error', err?.message || 'Unable to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  /* ------------------ Guard ------------------ */
  if (!service || !scheduledAt || !locationId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const formattedDate = new Date(scheduledAt).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
  const formattedTime = new Date(scheduledAt).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
  });

  /* ------------------ UI ------------------ */
  // Custom map style to blur/hide labels for privacy
  const mapStyle = [
    {
      featureType: 'all',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'road',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'transit',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden={true} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={mapStyle}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={CAR_IMAGE} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hub?.latitude && hub?.longitude && (
            <Marker coordinate={{ latitude: Number(hub.latitude), longitude: Number(hub.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={CARWASH_IMAGE} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={handleRecenter}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Confirm booking"
        subtitle={hub?.name || 'Review & confirm'}
        showBack
        onBack={() => router.back()}
      />

      {/* Booking summary card - same size as prior cards */}
      <Animated.View
        style={[
          styles.summaryContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: 96 + Math.max(insets.bottom, 14),
            paddingHorizontal: adaptive.horizontalPadding,
          },
        ]}
      >
        {loading ? (
          <View style={[styles.cardWrapper, { width: confirmCardWidth }]}>
            <UnifiedBookingCard stripColor={SKY}>
              <View style={styles.loadingCard}>
                <ActivityIndicator size="large" color={SKY} />
                <Text style={styles.loadingText}>Loading booking details...</Text>
              </View>
            </UnifiedBookingCard>
          </View>
        ) : (
          <View style={[styles.cardWrapper, { width: confirmCardWidth }]}>
            <UnifiedBookingCard stripColor={SKY}>
              <View style={styles.summaryCard}>
                <View style={styles.cardHeader}>
                  <View style={styles.summaryIconWrap}>
                    <Ionicons name="calendar-outline" size={28} color={SKY} />
                  </View>
                  <InfoIconButton
                    onPress={() => {
                      hapticFeedback('light');
                      setInfoModalVisible(true);
                    }}
                    accentColor={SKY}
                  />
                </View>
                <ScrollView
                  style={styles.summaryCardScroll}
                  contentContainerStyle={styles.summaryCardScrollContent}
                  showsVerticalScrollIndicator={true}
                  bounces={true}
                >
                  <Text style={styles.summaryWash}>{service?.name || 'Service'}</Text>
                  {service?.confirmationSummary && service.confirmationSummary.length > 0 && (
                    <View style={styles.summaryReassurance}>
                      <Text style={styles.summaryReassuranceTitle}>You've selected: {service.name}</Text>
                      {service.confirmationSummary.map((line) => (
                        <View key={line} style={styles.summaryReassuranceRow}>
                          <Ionicons name="checkmark-circle" size={14} color={SKY} />
                          <Text style={styles.summaryReassuranceText}>{line}</Text>
                        </View>
                      ))}
                    </View>
                  )}
                  <View style={styles.summaryMetaRow}>
                    <Ionicons name="calendar" size={12} color="#94A3B8" />
                    <Text style={styles.summaryMetaText}>{formattedDate}</Text>
                  </View>
                  <View style={styles.summaryMetaRow}>
                    <Ionicons name="time-outline" size={12} color="#94A3B8" />
                    <Text style={styles.summaryMetaText}>{formattedTime}</Text>
                  </View>
                  {hub?.address && (
                    <View style={styles.summaryMetaRow}>
                      <Ionicons name="location-outline" size={12} color="#94A3B8" />
                      <Text style={styles.summaryMetaText} numberOfLines={2}>{hub.address}</Text>
                    </View>
                  )}
                  {confirmVehicle && (
                    <View style={styles.summaryMetaRow}>
                      <Ionicons name="car-sport-outline" size={12} color="#94A3B8" />
                      <Text style={styles.summaryMetaText} numberOfLines={1}>{confirmVehicle.make} {confirmVehicle.model}</Text>
                      <InfoIconButton
                        onPress={() => { hapticFeedback('light'); setVehicleInfoVisible(true); }}
                        accentColor={SKY}
                      />
                    </View>
                  )}
                </ScrollView>
              </View>
            </UnifiedBookingCard>
          </View>
        )}
      </Animated.View>

      {/* Info modal - full booking summary */}
      <Modal
        visible={infoModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Booking Summary</Text>
              <TouchableOpacity onPress={() => setInfoModalVisible(false)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                <Ionicons name="close" size={24} color={customerTheme.primary} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
              <View style={styles.modalSection}>
                <Text style={styles.modalLabel}>Service</Text>
                <Text style={styles.modalValue}>
                  {service?.name || 'Service'}
                  {washType && washType !== 'both' ? ` (${washType.charAt(0).toUpperCase() + washType.slice(1)})` : ''}
                </Text>
                {service?.confirmationSummary && service.confirmationSummary.length > 0 && (
                  <View style={styles.modalReassurance}>
                    <Text style={styles.modalReassuranceTitle}>You've selected: {service.name}</Text>
                    {service.confirmationSummary.map((line) => (
                      <View key={line} style={styles.modalReassuranceRow}>
                        <Ionicons name="checkmark-circle" size={14} color={customerTheme.primary} />
                        <Text style={styles.modalReassuranceText}>{line}</Text>
                      </View>
                    ))}
                  </View>
                )}
                <Text style={styles.modalDesc}>{service?.desc || ''}</Text>
                <View style={styles.modalRow}>
                  <View style={styles.modalMeta}>
                    <Ionicons name="time-outline" size={14} color="#94A3B8" />
                    <Text style={styles.modalMetaText}>{service?.dur || ''}</Text>
                  </View>
                  <Text style={styles.modalPrice}>£{displayPrice}</Text>
                </View>
              </View>
              {hub && (
                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Location</Text>
                  <Text style={styles.modalValue}>{hub.name}</Text>
                  <Text style={styles.modalDesc}>{hub.address}</Text>
                </View>
              )}
              <View style={[styles.modalSection, { marginBottom: 0, paddingBottom: 0, borderBottomWidth: 0 }]}>
                <Text style={styles.modalLabel}>Time Slot</Text>
                <Text style={styles.modalValue}>{formattedDate} • {formattedTime}</Text>
                <Text style={styles.modalDesc}>Arrive 5 minutes early to keep your slot.</Text>
              </View>
            </ScrollView>
            <TouchableOpacity onPress={() => setInfoModalVisible(false)} style={styles.modalDone} activeOpacity={0.9}>
              <Text style={styles.modalDoneText}>Close</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      <VehicleInfoOverlay
        visible={vehicleInfoVisible && !!confirmVehicle}
        vehicle={confirmVehicle}
        stats={vehicleStats}
        accentColor={SKY}
        onClose={() => setVehicleInfoVisible(false)}
      />

      {/* Continue to payment screen */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12, left: adaptive.horizontalPadding, right: adaptive.horizontalPadding }]}>
          <TouchableOpacity
          onPress={() => handleConfirm()}
          style={[styles.ctaButton, { backgroundColor: SKY, width: confirmCardWidth }]}
          activeOpacity={0.85}
          disabled={submitting || loading || !hub}
        >
          {submitting ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <>
              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              <Text style={styles.ctaText}>
                {(() => {
                  if (!hub || loading) return 'Continue';
                  return displayPrice > 0 ? `Continue to pay – £${displayPrice}` : 'Continue – price from pro';
                })()}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

/* ------------------ Styles ------------------ */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 64,
    height: 64,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
  },
  cardWrapper: {},
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  summaryCard: {
    width: '100%',
    padding: 20,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
  },
  summaryCardScroll: {
    maxHeight: 280,
  },
  summaryCardScrollContent: {
    paddingBottom: 8,
  },
  cardMainOnly: {
    flex: 1,
    minWidth: 0,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtn: { padding: 4 },
  summaryWash: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 8,
  },
  summaryReassurance: {
    marginBottom: 12,
  },
  summaryReassuranceTitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
  },
  summaryReassuranceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  summaryReassuranceText: {
    color: '#94A3B8',
    fontSize: 12,
    flex: 1,
  },
  summaryMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  summaryMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
  },
  // Modal – booking summary (matches app info modals)
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '80%',
    backgroundColor: 'transparent',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitle: {
    color: customerTheme.primary,
    fontSize: 18,
    fontWeight: '800',
  },
  modalScroll: { maxHeight: 360, marginBottom: 14 },
  modalSection: {
    marginBottom: 18,
    paddingBottom: 18,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '18',
  },
  modalLabel: {
    color: customerTheme.primary,
    fontSize: 11,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 6,
    fontWeight: '700',
    opacity: 0.85,
  },
  modalValue: {
    color: colors.headerText,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  modalReassurance: {
    marginTop: 8,
    marginBottom: 10,
  },
  modalReassuranceTitle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
  },
  modalReassuranceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  modalReassuranceText: {
    color: colors.headerSubtext,
    fontSize: 13,
    flex: 1,
  },
  modalDesc: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    opacity: 0.95,
  },
  modalRow: {
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modalMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  modalMetaText: {
    color: colors.headerSubtext,
    fontSize: 13,
    fontWeight: '600',
  },
  modalPrice: {
    color: customerTheme.primary,
    fontSize: 17,
    fontWeight: '800',
  },
  modalDone: {
    backgroundColor: customerTheme.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    paddingVertical: 18,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  headerContainer: {
    position: 'absolute',
    left: 16,
    zIndex: 1000,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
});
