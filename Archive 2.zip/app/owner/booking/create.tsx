import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Alert,
  Image,
  ActivityIndicator,
  Modal,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { CTA_BUTTON_WIDTH, HEADER_BORDER_RADIUS } from '../../../src/constants/layoutConstants';
import { serviceOptions, detailingServiceOptions, addOnOptions, ADD_ON_SECTION_TITLE, ADD_ON_SECTION_SUBTITLE, getAvailableAddOnIdsForService } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import {
  calculateDisplayPrice,
  getVehicleSize,
  mapServiceIdToWashId,
  FrontendPricingInput
} from '../../../src/pricing/pricingEngine';


import { BOOKING_CARD, HEADER_STYLE_CARD_GRADIENT } from '../../../src/constants/bookingCardTheme';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import InfoIconButton from '../../../src/components/shared/InfoIconButton';
import { VehicleInfoOverlay } from '../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../src/utils/vehicleStats';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, MAP_CAMERA_ANIMATION_DURATION, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { CAR_IMAGE } from '../../assets/assetExports';
import { useAdaptiveLayout } from '../../../src/constants/adaptiveLayout';
import { geocodeAddress, fetchPlaceSuggestions, getPlaceDetails, type PlaceSuggestion } from '../../../src/services/GooglePlacesService';

const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const SKY = colors.SKY;
const LOCATION_CARD_GREEN = colors.ECO_GREEN;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;

const SAVED_LOCATIONS_KEY = 'customer_saved_locations';

type SavedLocationItem = {
  id: string;
  label: string;
  address: string;
  latitude: number;
  longitude: number;
};

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: string;
  image_url?: string | null;
  photo?: string | null;
};


/** Map vehicle color name to hex for card border; fallback SKY. */
function getVehicleBorderColor(color: string | null | undefined, fallback: string): string {
  if (!color?.trim()) return fallback;
  const c = color.trim().toLowerCase();
  const map: Record<string, string> = {
    black: '#111827',
    white: '#E5E7EB',
    silver: '#9CA3AF',
    grey: '#6B7280',
    gray: '#6B7280',
    red: '#DC2626',
    blue: '#2563EB',
    navy: '#1E3A8A',
    green: '#059669',
    yellow: '#EAB308',
    gold: '#B45309',
    orange: '#EA580C',
    brown: '#92400E',
    beige: '#A16207',
    tan: '#D4A574',
    purple: '#7C3AED',
    burgundy: '#881337',
    bronze: '#92400E',
    champagne: '#D6D3C4',
    cream: '#FEF3C7',
  };
  if (map[c]) return map[c];
  for (const [key, hex] of Object.entries(map)) {
    if (c.includes(key)) return hex;
  }
  return fallback;
}

/** Strip color for service card side border: wash tiers, or yellow for all detailing services. */
function getServiceStripColor(serviceId: string, fallback: string): string {
  const id = serviceId.toLowerCase();
  const washMap: Record<string, string> = {
    'bronze-wash': '#92400E',
    'eco-bronze-wash': '#92400E',
    'silver-wash': '#C0C0C0',
    'eco-silver-wash': '#C0C0C0',
    'gold-wash': '#EAB308',
    'eco-gold-wash': '#EAB308',
    'platinum-wash': '#334155',
    'eco-platinum-wash': '#334155',
  };
  if (washMap[id]) return washMap[id];
  const detailingIds = ['ceramic-coating', 'machine-polishing', 'soft-top-restoration', 'mould-removal'];
  if (detailingIds.includes(id)) return DETAILING_YELLOW;
  return fallback;
}

type BookingStep = 'location' | 'vehicle' | 'service';

type ServiceMode = 'wash' | 'detailing';

function getBookingHeaderConfig(step: BookingStep): { title: string; subtitle: string; backStep: BookingStep | null } {
  switch (step) {
    case 'location':
      return { title: 'Location & vehicle', subtitle: 'Set location on map and pick your vehicle', backStep: null };
    case 'vehicle':
      return { title: 'Confirm vehicle', subtitle: 'Swipe to see all vehicles', backStep: 'location' };
    default:
      return { title: 'Confirm service', subtitle: 'Swipe to see all services', backStep: 'location' };
  }
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- multi-step booking flow; logic split via getBookingHeaderConfig and step renderers
export default function BookingCreate() {
  const params = useLocalSearchParams<{ serviceMode?: string; customerOffersWater?: string; customerOffersElectricity?: string; preferredValeterId?: string }>();
  const [offersWater, setOffersWater] = useState(params.customerOffersWater === 'true');
  const [offersElectricity, setOffersElectricity] = useState(params.customerOffersElectricity === 'true');
  const [infoService, setInfoService] = useState<{ id?: string; name?: string; icon?: string; price?: number | string; desc?: string; bulletPoints?: string[]; descriptionTitle?: string } | null>(null);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState<PlaceSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const suggestDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [serviceMode] = useState<ServiceMode>(
    (params.serviceMode === 'detailing' ? 'detailing' : 'wash') as ServiceMode
  );
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [showAddOnsModal, setShowAddOnsModal] = useState(false);
  const [showBronzeWashTypeOverlay, setShowBronzeWashTypeOverlay] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const adaptive = useAdaptiveLayout();
  const locationVehicleCardWidth =
    Math.min(adaptive.contentMaxWidth, adaptive.width) - adaptive.horizontalPadding * 2;
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapLocation, setMapLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [savedLocations, setSavedLocations] = useState<SavedLocationItem[]>([]);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Get user location and use it as default for the location box (current location = default unless user changes it)
  useEffect(() => {
    const applyCoords = (coords: { latitude: number; longitude: number }) => {
      setUserLocation(coords);
      setMapLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    };

    if (liveCoords) {
      applyCoords({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
    } else {
      (async () => {
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
          applyCoords(coords);
        } catch (error) {
          console.warn('Error getting location:', error);
        }
      })();
    }
  }, [liveCoords]);

  // Default selectedLocation to current location when we first get userLocation (same as Wishv3 applyCoords)
  useEffect(() => {
    if (!userLocation || selectedLocation !== null) return;
    (async () => {
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        const addr = result
          ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location'
          : 'Current Location';
        setSelectedLocation({ ...userLocation, address: addr });
      } catch {
        setSelectedLocation({ ...userLocation, address: 'Current Location' });
      }
    })();
  }, [userLocation, selectedLocation]);

  // Load saved locations for the dropdown (same list as Settings > Saved locations)
  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(`${SAVED_LOCATIONS_KEY}_${user.id}`);
        if (!raw) {
          setSavedLocations([]);
          return;
        }
        const parsed = JSON.parse(raw);
        const list = Array.isArray(parsed) ? parsed : [];
        const labels: Record<string, string> = { home: 'Home', work: 'Work', gym: 'Gym', other: 'Other' };
        setSavedLocations(
          list.map((item: { id: string; label: string; customLabel?: string; address: string; latitude: number; longitude: number }) => ({
            id: item.id,
            label: item.customLabel || labels[item.label] || item.label,
            address: item.address,
            latitude: item.latitude,
            longitude: item.longitude,
          }))
        );
      } catch {
        setSavedLocations([]);
      }
    })();
  }, [user?.id]);

  // When service or wash type changes, drop any selected add-ons that are no longer allowed
  useEffect(() => {
    const allowed = selectedService
      ? getAvailableAddOnIdsForService(selectedService, washType ?? '', serviceMode === 'detailing')
      : [];
    setSelectedAddOns((prev) => prev.filter((id) => allowed.includes(id)));
  }, [selectedService, washType, serviceMode]);

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    setMapLocation(coords);
    setRegion({
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: 0.001,
      longitudeDelta: 0.001,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location';
        setSelectedLocation({ ...coords, address: addr });
        await hapticFeedback('light');
      }
    } catch (e) {
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (userLocation) {
      setMapLocation(userLocation);
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setSelectedLocation({ ...userLocation, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    }
  };

  const handlePickSavedLocation = (item: SavedLocationItem) => {
    hapticFeedback('light');
    const coords = { latitude: item.latitude, longitude: item.longitude };
    setMapLocation(coords);
    setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    setSelectedLocation({ ...coords, address: item.address });
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const closeAddressOverlayWithoutSaving = () => {
    setAddressSearchInput('');
    setAddressSuggestions([]);
    setShowAddressOverlay(false);
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  useEffect(() => {
    if (!showAddressOverlay) {
      setAddressSuggestions([]);
      return;
    }
    const q = addressSearchInput.trim();
    if (q.length < 2) {
      setAddressSuggestions([]);
      return;
    }
    if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    suggestDebounceRef.current = setTimeout(async () => {
      setLoadingSuggestions(true);
      try {
        const list = await fetchPlaceSuggestions(q);
        setAddressSuggestions(list);
      } catch {
        setAddressSuggestions([]);
      } finally {
        setLoadingSuggestions(false);
      }
    }, 320);
    return () => {
      if (suggestDebounceRef.current) clearTimeout(suggestDebounceRef.current);
    };
  }, [showAddressOverlay, addressSearchInput]);

  const handleSelectSuggestion = async (suggestion: PlaceSuggestion) => {
    setAddressSearching(true);
    setAddressSuggestions([]);
    try {
      const details = await getPlaceDetails(suggestion.placeId);
      if (details) {
        const coords = { latitude: details.latitude, longitude: details.longitude };
        const addr = details.formattedAddress || suggestion.description;
        setMapLocation(coords);
        setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      }
    } catch (e) {
      console.error('Place details error', e);
      Alert.alert('Error', 'Could not get address details. Try again.');
    } finally {
      setAddressSearching(false);
    }
  };

  const handleAddressSearch = async () => {
    const q = addressSearchInput.trim();
    if (!q) return;
    setAddressSearching(true);
    try {
      // Prefer Google Places Geocoding for address search (change location)
      const googleResults = await geocodeAddress(q);
      if (googleResults?.length > 0) {
        const first = googleResults[0];
        const coords = { latitude: first.latitude, longitude: first.longitude };
        const addr = first.formattedAddress || q;
        setMapLocation(coords);
        setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
        setAddressSearching(false);
        return;
      }
      // Fallback to Expo geocode
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        const coords = { latitude, longitude };
        setMapLocation(coords);
        setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
        const [rev] = await Location.reverseGeocodeAsync(coords);
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) {
        const defaultVehicle = rows.find((v: Vehicle) => v.is_default) || rows[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationAndVehicleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    if (!selectedVehicle) {
      Alert.alert('Vehicle Required', 'Please select a vehicle.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('service');
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    const nextOptions = serviceMode === 'wash' ? serviceOptions : detailingServiceOptions;
    const nextOption = nextOptions.find(s => s.id === serviceId);
    setSelectedAddOns((prev) => prev.filter((id) => !nextOption?.includedAddOnIds?.includes(id)));
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setShowBronzeWashTypeOverlay(true);
    } else {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
    setShowBronzeWashTypeOverlay(false);
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) return;
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');
    const baseForDiscount = basePrice ?? selectedServiceData?.price ?? 0;
    const discountAmount = (offersWater || offersElectricity) ? baseForDiscount * 0.25 : 0;

    const valeterParams: Record<string, string> = {
      serviceId: selectedService,
      vehicleId: selectedVehicle,
      latitude: selectedLocation.latitude.toString(),
      longitude: selectedLocation.longitude.toString(),
      address: selectedLocation.address,
      washType: washType || '',
      serviceMode: serviceMode,
      addOnIds: effectiveSelectedAddOns.length ? effectiveSelectedAddOns.join(',') : '',
      addOnsTotal: addOnsTotal.toString(),
      customerOffersWater: offersWater.toString(),
      customerOffersElectricity: offersElectricity.toString(),
      discountAmount: discountAmount.toString(),
    };
    if (params.preferredValeterId) valeterParams.preferredValeterId = params.preferredValeterId;
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: valeterParams,
    });
  };

  const currentServiceOptions = serviceMode === 'wash' ? serviceOptions : detailingServiceOptions;
  const selectedServiceData = currentServiceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  const allowedAddOnIds = selectedService
    ? getAvailableAddOnIdsForService(selectedService, washType ?? '', serviceMode === 'detailing')
    : [];
  const availableAddOnOptions = addOnOptions.filter(
    (a) => allowedAddOnIds.includes(a.id) && !selectedServiceData?.includedAddOnIds?.includes(a.id)
  );

  const effectiveSelectedAddOns = selectedAddOns.filter((id) => allowedAddOnIds.includes(id));
  const addOnsTotal = effectiveSelectedAddOns.reduce((sum, id) => {
    const addOn = addOnOptions.find(a => a.id === id);
    return sum + (addOn?.price ?? 0);
  }, 0);

  const basePrice = (() => {
    if (!selectedServiceData || !selectedVehicleData || selectedService == null) return null;
    const washId = mapServiceIdToWashId(selectedService);
    if (washId) {
      const vehicleSize = getVehicleSize(selectedVehicleData);
      const input: FrontendPricingInput = {
        washId,
        vehicleSize,
        isMobile: true,
        isPhysicalLocation: false,
        scheduledDateTime: new Date(),
      };
      const breakdown = calculateDisplayPrice(input);
      return breakdown?.finalDisplayPriceGBP ?? selectedServiceData.price;
    }
    return selectedServiceData.price;
  })();

  const totalWithAddOns = basePrice == null ? null : basePrice + addOnsTotal;

  const toggleAddOn = (id: string) => {
    hapticFeedback('light');
    setSelectedAddOns((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const headerConfig = getBookingHeaderConfig(currentStep);
  const headerTitle = headerConfig.title;
  const headerSubtitle = headerConfig.subtitle;
  const headerOnBack = headerConfig.backStep === null ? undefined : () => setCurrentStep(headerConfig.backStep!);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          onPress={currentStep === 'location' ? (e) => { void handleMapPress(e); } : () => {}}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          mapPadding={{
            top: 0,
            right: 0,
            bottom: TAB_BAR_TOTAL_HEIGHT + 280 + Math.max(insets.bottom, 14),
            left: 0,
          }}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <Animated.View style={[styles.userMarkerContainer, { transform: [{ scale: markerPulse }] }]}>
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </Animated.View>
            </Marker>
          )}
          {mapLocation && currentStep === 'location' && (
            <Marker coordinate={mapLocation}>
              <Animated.View style={[styles.selectedLocationMarker, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.selectedLocationMarkerInner}>
                  <Image source={CAR_IMAGE} style={styles.selectedLocationMarkerCar} resizeMode="contain" />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          if (currentStep === 'location') {
            await handleUseCurrentLocation();
          }
          const center = userLocation ?? selectedLocation ?? region;
          if (center && mapRef.current) {
            const r = { latitude: center.latitude, longitude: center.longitude, latitudeDelta: 0.001, longitudeDelta: 0.001 };
            setRegion(r);
            mapRef.current.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
          } else if (!userLocation && currentStep === 'location') {
            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status === 'granted') {
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                const coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
                setUserLocation(coords);
                setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
                mapRef.current?.animateToRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 }, MAP_CAMERA_ANIMATION_DURATION);
              }
            } catch {}
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title={headerTitle}
        subtitle={headerSubtitle}
        showBack={currentStep !== 'location'}
        onBack={headerOnBack ?? (() => {})}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Resources toggle – icon highlights when selected, no full fill */}
      {currentStep === 'service' && (
        <View
          style={[
            styles.resourcesToggleFixed,
            { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 12 },
          ]}
          pointerEvents="box-none"
        >
          <View style={styles.serviceModeToggle}>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOffersWater((v) => !v); }}
              activeOpacity={0.8}
              style={styles.serviceModePill}
            >
              <Ionicons name="water-outline" size={18} color={offersWater ? SKY : 'rgba(135,206,235,0.5)'} />
              <Text style={[styles.serviceModeLabel, offersWater && styles.serviceModeLabelHighlight]}>Water</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOffersElectricity((v) => !v); }}
              activeOpacity={0.8}
              style={styles.serviceModePill}
            >
              <Ionicons name="flash-outline" size={18} color={offersElectricity ? DETAILING_YELLOW : 'rgba(135,206,235,0.5)'} />
              <Text style={[styles.serviceModeLabel, offersElectricity && styles.serviceModeLabelHighlightYellow]}>Electricity</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.resourcesHelperText}>
            Select what you can provide for your valeter at the service location.
          </Text>
        </View>
      )}

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
            paddingHorizontal: adaptive.horizontalPadding,
          },
        ]}
      >
        <Animated.View style={{ transform: [{ translateX: stepSlideAnim }] }}>
        {/* Step 1: Location + Vehicle in one card */}
        {currentStep === 'location' && (
          <View style={[styles.cardWrapper, { width: locationVehicleCardWidth, marginRight: 0 }]}>
            <UnifiedBookingCard stripColor={LOCATION_CARD_GREEN}>
              {(selectedLocation || vehicles.length > 0) && (
                <LinearGradient
                  colors={[SKY + '12', SKY + '06', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={StyleSheet.absoluteFill}
                  pointerEvents="none"
                />
              )}
              <ScrollView style={styles.combinedCardScroll} showsVerticalScrollIndicator={false} nestedScrollEnabled>
                {/* Location section */}
                <View style={[styles.modernCard, selectedLocation == null ? styles.modernCardEmpty : undefined]}>
                  {selectedLocation == null ? (
                    <View style={styles.emptyContent}>
                      <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                        <Ionicons name="location-outline" size={28} color={SKY} />
                      </View>
                      <Text style={styles.emptyText}>Tap on the map</Text>
                      <Text style={styles.emptySubtext}>Tap to set where your washer will arrive</Text>
                    </View>
                  ) : (
                    <View style={styles.cardTop}>
                      <View style={[styles.iconWrap, { backgroundColor: SKY + '25', borderColor: SKY + '40' }]}>
                        <LinearGradient colors={BOOKING_CARD.GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.iconGradient}>
                          <Ionicons name="location" size={26} color="#FFFFFF" />
                        </LinearGradient>
                      </View>
                      <View style={styles.cardContent}>
                        <View style={styles.titleRow}>
                          <Text style={styles.cardTitle} numberOfLines={1}>Location</Text>
                          <View style={styles.titleRowRight}>
                            <TouchableOpacity
                              onPress={() => { hapticFeedback('light'); setAddressSearchInput(''); setAddressSuggestions([]); setShowAddressOverlay(true); }}
                              style={styles.changeBtn}
                              activeOpacity={0.8}
                            >
                              <Ionicons name="pencil" size={14} color={SKY} />
                              <Text style={styles.changeBtnText}>Change</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                        <Text style={styles.cardSubtitle} numberOfLines={2}>{selectedLocation.address}</Text>
                        <Text style={styles.locationMicrocopy}>Your washer will arrive here</Text>
                      </View>
                    </View>
                  )}
                </View>

                {/* Divider + Vehicle section inside same card */}
                <View style={styles.locationVehicleDivider} />
                <View style={styles.combinedVehicleSection}>
                  <Text style={styles.combinedVehicleSectionTitle}>Vehicle</Text>
                  {(() => {
                    if (loading) {
                      return (
                        <View style={styles.combinedVehicleLoading}>
                          <ActivityIndicator size="small" color={SKY} />
                          <Text style={styles.combinedVehicleLoadingText}>Loading vehicles…</Text>
                        </View>
                      );
                    }
                    if (vehicles.length === 0) {
                      return (
                        <View style={styles.combinedVehicleEmpty}>
                          <Text style={styles.combinedVehicleEmptyText}>No vehicles found</Text>
                          <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.addButtonGradient}>
                              <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                              <Text style={styles.addButtonText}>Add Vehicle</Text>
                            </LinearGradient>
                          </TouchableOpacity>
                        </View>
                      );
                    }
                    return (
                      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.combinedVehicleList}>
                        {vehicles.map((vehicle) => {
                          const isSelected = selectedVehicle === vehicle.id;
                          const vehicleBorderColor = getVehicleBorderColor(vehicle.color, SKY);
                          return (
                            <TouchableOpacity
                              key={vehicle.id}
                              onPress={() => { hapticFeedback('light'); setSelectedVehicle(vehicle.id); }}
                              activeOpacity={0.85}
                              style={[
                                styles.vehicleRowInCard,
                                isSelected && styles.vehicleRowInCardSelected,
                                isSelected && { borderColor: vehicleBorderColor + '99' },
                              ]}
                            >
                              <View style={[styles.vehicleRowIcon, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '20' }]}>
                                <Ionicons name="car-sport" size={22} color={isSelected ? SKY : '#94A3B8'} />
                              </View>
                              <View style={styles.vehicleRowContent}>
                                <Text style={[styles.vehicleRowTitle, isSelected && { color: SKY }]} numberOfLines={1}>{vehicle.make} {vehicle.model}</Text>
                                <Text style={styles.vehicleRowSubtitle} numberOfLines={1}>{vehicle.registration}</Text>
                              </View>
                              <TouchableOpacity
                                onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); openVehicleInfo(vehicle); }}
                                hitSlop={8}
                                style={styles.vehicleRowInfoBtn}
                              >
                                <Ionicons name="information-circle-outline" size={20} color={isSelected ? SKY : '#94A3B8'} />
                              </TouchableOpacity>
                            </TouchableOpacity>
                          );
                        })}
                      </ScrollView>
                    );
                  })()}
                </View>
              </ScrollView>
            </UnifiedBookingCard>
          </View>
        )}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={styles.serviceStepWrap}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {currentServiceOptions.map((service) => {
                const isSelected = selectedService === service.id;
                const serviceColor = service.colors[0];
                const serviceStripColor = getServiceStripColor(service.id, serviceColor);

                return (
                  <View key={service.id} style={[styles.cardWrapper, styles.serviceCardCurved, { width: CARD_WIDTH }]}>
                    <UnifiedBookingCard
                      stripColor={serviceStripColor}
                      onPress={() => handleServiceSelect(service.id)}
                      style={styles.serviceCardUnified}
                    >
                    {isSelected && (
                      <LinearGradient colors={[serviceColor + '15', serviceColor + '08', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    )}
                    <View style={[styles.modernCard, isSelected && styles.modernCardSelected]}>
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: serviceColor + '25', borderColor: serviceColor + '40' }]}>
                          <Ionicons name={service.icon as any} size={26} color={serviceColor} />
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <View style={styles.titleAndBadge}>
                              <Text style={styles.cardTitle} numberOfLines={1}>{service.name}</Text>
                              {service.badge ? (
                                <View style={[styles.serviceBadgePill, { backgroundColor: serviceColor + '30', borderColor: serviceColor + '50' }]}>
                                  <Text style={[styles.serviceBadgePillText, { color: serviceColor }]} numberOfLines={1}>{service.badge}</Text>
                                </View>
                              ) : null}
                            </View>
                            <InfoIconButton
                              onPress={() => { hapticFeedback('light'); setInfoService(service); }}
                              accentColor={serviceColor}
                              icon="information-circle"
                            />
                          </View>
                          <Text style={styles.cardSubtitle}>{service.dur}</Text>
                          {isSelected && (service.id === 'platinum-wash' || service.id === 'eco-platinum-wash') && (
                            <Text style={styles.serviceReinforcement}>Deep clean — no paint correction</Text>
                          )}
                          {isSelected && serviceMode === 'detailing' && service.id === 'machine-polishing' && (
                            <Text style={styles.serviceReinforcement}>Results vary by paint condition – inspection included</Text>
                          )}
                          {isSelected && serviceMode === 'detailing' && service.id === 'ceramic-coating' && (
                            <Text style={styles.serviceReinforcement}>Paint prep included; best on clean or corrected paint</Text>
                          )}
                          {/* Light price hint – full breakdown on payment screen; detailing priced by pro */}
                          <View style={styles.cardMetaRow}>
                            <View style={[styles.quickHint, { backgroundColor: serviceColor + '15' }]}>
                              <Text style={[styles.quickHintText, { color: serviceColor }]}>
                                {(() => {
                                  if (isSelected && totalWithAddOns != null) return `£${totalWithAddOns.toFixed(2)} total`;
                                  return `From £${service.price}`;
                                })()}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>

                      {/* Add-ons row – only when this service has add-ons available (correct set per tier/detailing) */}
                      {availableAddOnOptions.length > 0 ? (
                        <View style={styles.addOnsRow}>
                          <TouchableOpacity
                            onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setShowAddOnsModal(true); }}
                            style={styles.addOnsButton}
                            activeOpacity={0.8}
                          >
                            <View style={styles.addOnsButtonIconWrap}>
                              <Ionicons name="add-circle-outline" size={22} color={SKY} />
                            </View>
                            <View>
                              <Text style={styles.addOnsButtonText}>Enhance your clean</Text>
                              <Text style={styles.addOnsButtonHint}>
                                {effectiveSelectedAddOns.length > 0
                                  ? `${effectiveSelectedAddOns.length} selected · +£${addOnsTotal.toFixed(2)}`
                                  : 'Pet hair, stains, odour & more'}
                              </Text>
                            </View>
                            {effectiveSelectedAddOns.length > 0 && (
                              <View style={styles.addOnsBadge}>
                                <Text style={styles.addOnsBadgeText}>{effectiveSelectedAddOns.length}</Text>
                              </View>
                            )}
                            <Ionicons name="chevron-forward" size={18} color={SKY} />
                          </TouchableOpacity>
                        </View>
                      ) : null}

                    </View>
                    </UnifiedBookingCard>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}
        </Animated.View>

        {/* Floating Continue button – same width as cards */}
        <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12, left: adaptive.horizontalPadding, right: adaptive.horizontalPadding }]}>
          {currentStep === 'location' && (
            <TouchableOpacity
              onPress={handleLocationAndVehicleContinue}
              disabled={!selectedLocation || !selectedVehicle}
              style={[styles.ctaButton, { width: CTA_BUTTON_WIDTH }]}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={selectedLocation && selectedVehicle ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText}>
                  {(() => {
                    if (selectedLocation && selectedVehicle) return 'Continue';
                    if (selectedLocation) return 'Select a vehicle';
                    return 'Set location to continue';
                  })()}
                </Text>
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          )}
          {currentStep === 'service' && (
            <>
              {serviceMode === 'detailing' && selectedService ? (
                <Text style={styles.conditionMicrocopy}>
                  Detailing is condition-based. Results vary by vehicle condition.
                </Text>
              ) : null}
              <TouchableOpacity
                onPress={handleServiceContinue}
                disabled={!selectedVehicle || (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType)}
                style={[styles.ctaButton, { width: CTA_BUTTON_WIDTH }]}
                activeOpacity={0.9}
              >
                {(() => {
                  const serviceStepReady = selectedVehicle && (serviceMode !== 'wash' || selectedService !== 'bronze-wash' || washType);
                  return (
                <LinearGradient
                  colors={serviceStepReady ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.ctaGradient}
                >
                  <Text style={styles.ctaText}>
                    {serviceStepReady ? 'Confirm & continue' : 'Confirm service'}
                  </Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
                  );
                })()}
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Service Info Modal – redesigned popup */}
        <Modal
          visible={!!infoService}
          transparent
          animationType="fade"
          statusBarTranslucent
          onRequestClose={() => setInfoService(null)}
        >
          <View style={styles.infoModalOverlay}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setInfoService(null)} />
            <View style={styles.infoModalCard} onStartShouldSetResponder={() => true}>
              <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
              {infoService && (
                <>
                  <LinearGradient colors={[customerTheme.primary, customerTheme.primary + 'DD']} style={styles.infoModalHeaderBar}>
                    <Text style={styles.infoModalHeaderLabel}>SERVICE</Text>
                    <Text style={styles.infoModalHeaderTitle} numberOfLines={1}>
                      {infoService.name}
                      {infoService.id === 'bronze-wash' && washType && (
                        <Text style={styles.infoModalHeaderSubtitle}> · {washType === 'exterior' ? 'Exterior' : 'Interior'}</Text>
                      )}
                    </Text>
                    <Text style={styles.infoModalHeaderPrice}>£{infoService.price}</Text>
                    <TouchableOpacity onPress={() => setInfoService(null)} style={styles.infoModalCloseBtn} hitSlop={12}>
                      <Ionicons name="close" size={24} color="#FFFFFF" />
                    </TouchableOpacity>
                  </LinearGradient>
                  <View style={styles.infoModalScrollWrap}>
                    <ScrollView
                      style={styles.infoModalScroll}
                      contentContainerStyle={styles.infoModalScrollContent}
                      showsVerticalScrollIndicator={true}
                      bounces={true}
                    >
                    {infoService.descriptionTitle && (
                      <Text style={styles.infoModalDescTitle}>{infoService.descriptionTitle}</Text>
                    )}
                    <Text style={styles.infoModalDesc}>
                      {(() => {
                        if (infoService.id === 'bronze-wash' && washType === 'exterior') return 'A quick exterior refresh to keep your vehicle looking clean and presentable.';
                        if (infoService.id === 'bronze-wash' && washType === 'interior') return 'A light interior refresh designed to tidy and freshen your vehicle\'s cabin.';
                        return infoService.desc ?? '';
                      })()}
                    </Text>
                    {(() => {
                      let bulletPoints: string[];
                      if (infoService.id === 'bronze-wash' && washType === 'exterior') {
                        bulletPoints = ['Wheels and wheel arches cleaned', 'Snow foam pre-wash applied', 'Safe exterior hand wash', 'Vehicle fully rinsed', 'Exterior hand dried', 'Windows and mirrors cleaned', 'Ideal for regular maintenance washes and light dirt removal'];
                      } else if (infoService.id === 'bronze-wash' && washType === 'interior') {
                        bulletPoints = ['Rubbish removed', 'Interior vacuum (seats, carpets, and mats)', 'Dashboard and main surfaces wiped down', 'Steering wheel cleaned', 'Interior glass cleaned', 'Air freshener applied', 'Perfect for maintaining a clean and comfortable interior between deeper cleans'];
                      } else {
                        bulletPoints = infoService.bulletPoints ?? [];
                      }
                      return bulletPoints.length > 0 ? (
                      <View style={styles.infoModalBullets}>
                        {bulletPoints.map((point: string) => (
                          <View key={point} style={styles.infoModalBulletRow}>
                            <View style={[styles.infoModalBulletDot, { backgroundColor: customerTheme.primary }]} />
                            <Text style={styles.infoModalBulletText}>{point}</Text>
                          </View>
                        ))}
                      </View>
                      ) : null;
                    })()}
                    {effectiveSelectedAddOns.length > 0 && (
                      <View style={styles.infoModalAddOns}>
                        <Text style={styles.infoModalAddOnsTitle}>Selected add-ons</Text>
                        {effectiveSelectedAddOns.map((id) => {
                          const addOn = addOnOptions.find(a => a.id === id);
                          if (!addOn) return null;
                          return (
                            <View key={addOn.id} style={styles.infoModalAddOnRow}>
                              <Ionicons name={addOn.icon as any} size={18} color={customerTheme.primary} />
                              <Text style={styles.infoModalAddOnName}>{addOn.name}</Text>
                              <Text style={styles.infoModalAddOnPrice}>+£{addOn.price}</Text>
                            </View>
                          );
                        })}
                        <View style={styles.infoModalAddOnTotal}>
                          <Text style={styles.infoModalAddOnTotalLabel}>Total</Text>
                          <Text style={styles.infoModalAddOnTotalValue}>+£{addOnsTotal}</Text>
                        </View>
                      </View>
                    )}
                    </ScrollView>
                  </View>
                  <TouchableOpacity onPress={() => setInfoService(null)} style={styles.infoModalDoneWrap} activeOpacity={0.9}>
                    <LinearGradient colors={[customerTheme.primary, customerTheme.primary + 'E6']} style={styles.infoModalDoneBtn}>
                      <Text style={styles.infoModalDoneText}>Done</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        </Modal>

        <VehicleInfoOverlay
          visible={!!infoVehicle}
          vehicle={infoVehicle ? { ...infoVehicle, mot_expiry: (infoVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoVehicle as any).mot_expiry_date ?? null, mileage: (infoVehicle as any).mileage ?? null, tax_status: (infoVehicle as any).tax_status ?? null, tax_due_date: (infoVehicle as any).tax_due_date ?? null, tax_expiry: (infoVehicle as any).tax_expiry ?? null } : null}
          stats={vehicleStats}
          accentColor={customerTheme.primary}
          onClose={() => setInfoVehicle(null)}
        />

        {/* Address search overlay */}
        <Modal visible={showAddressOverlay} transparent animationType="fade" onRequestClose={closeAddressOverlayWithoutSaving}>
          <KeyboardAvoidingView
            style={styles.addressOverlayKeyboardWrap}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <Pressable style={styles.modalOverlay} onPress={closeAddressOverlayWithoutSaving}>
              <View style={styles.addressOverlayContent}>
                <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
                <Pressable style={styles.addressOverlayContentInner} onPress={(e) => e.stopPropagation()}>
                  <Text style={styles.addressOverlayTitle}>Change location</Text>
                  <Text style={styles.addressOverlaySubtitle}>Current location is default. Pick a saved place or search.</Text>
                  <TouchableOpacity
                    style={styles.addressOverlayUseCurrent}
                    onPress={async () => {
                      await handleUseCurrentLocation();
                      closeAddressOverlayWithoutSaving();
                    }}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="locate" size={18} color={SKY} />
                    <Text style={styles.addressOverlayUseCurrentText}>Use current location</Text>
                  </TouchableOpacity>
                  {savedLocations.length > 0 && (
                    <>
                      <Text style={styles.addressOverlaySavedLabel}>Saved locations</Text>
                      <ScrollView style={styles.addressOverlaySavedList} keyboardShouldPersistTaps="handled" nestedScrollEnabled>
                        {savedLocations.map((item) => (
                          <TouchableOpacity
                            key={item.id}
                            style={styles.addressOverlaySavedItem}
                            onPress={() => handlePickSavedLocation(item)}
                            activeOpacity={0.8}
                          >
                            <Ionicons name="location" size={18} color={SKY} />
                            <View style={styles.addressOverlaySavedItemText}>
                              <Text style={styles.addressOverlaySavedItemLabel}>{item.label}</Text>
                              <Text style={styles.addressOverlaySavedItemAddress} numberOfLines={1}>{item.address}</Text>
                            </View>
                            <Ionicons name="chevron-forward" size={18} color="#64748B" />
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    </>
                  )}
                  <Text style={styles.addressOverlaySearchLabel}>Or search for an address</Text>
                  <TextInput
                    style={styles.addressOverlayInput}
                    placeholder="Find your postcode..."
                    placeholderTextColor="#64748B"
                    value={addressSearchInput}
                    onChangeText={setAddressSearchInput}
                    onSubmitEditing={handleAddressSearch}
                    returnKeyType="search"
                    autoCapitalize="none"
                  />
                  {loadingSuggestions && (
                    <View style={styles.addressSuggestionsLoading}>
                      <ActivityIndicator size="small" color={SKY} />
                    </View>
                  )}
                  {!loadingSuggestions && addressSuggestions.length > 0 && (
                    <ScrollView
                      style={styles.addressSuggestionsList}
                      keyboardShouldPersistTaps="handled"
                      nestedScrollEnabled
                    >
                      {addressSuggestions.map((s) => (
                        <TouchableOpacity
                          key={s.placeId}
                          style={styles.addressSuggestionItem}
                          onPress={() => handleSelectSuggestion(s)}
                          activeOpacity={0.7}
                        >
                          <Ionicons name="location-outline" size={18} color={SKY} />
                          <Text style={styles.addressSuggestionText} numberOfLines={2}>{s.description}</Text>
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  )}
                  <View style={styles.addressOverlayButtons}>
                    <TouchableOpacity style={styles.addressOverlayCancel} onPress={closeAddressOverlayWithoutSaving} activeOpacity={0.8}>
                      <Text style={styles.addressOverlayCancelText}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.addressOverlaySearch, addressSearching && { opacity: 0.7 }]}
                      onPress={handleAddressSearch}
                      disabled={addressSearching}
                      activeOpacity={0.8}
                    >
                      {addressSearching ? (
                        <ActivityIndicator size="small" color="#fff" />
                      ) : (
                        <>
                          <Ionicons name="search" size={18} color="#fff" />
                          <Text style={styles.addressOverlaySearchText}>Search</Text>
                        </>
                      )}
                    </TouchableOpacity>
                  </View>
                </Pressable>
              </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Modal>

        {/* Add-ons modal – redesigned for reliable render and clearer UI */}
        <Modal visible={showAddOnsModal} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowAddOnsModal(false)}>
          <Pressable style={styles.addOnsModalOverlay} onPress={() => setShowAddOnsModal(false)}>
            <Pressable style={styles.addOnsModalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={36} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={['rgba(15,23,42,0.98)', 'rgba(30,41,59,0.96)']} style={StyleSheet.absoluteFill} />
              <View style={styles.addOnsModalContentInner}>
                <View style={styles.addOnsModalHeader}>
                  <View style={styles.addOnsModalTitleRow}>
                    <View style={styles.addOnsModalTitleIcon}>
                      <Ionicons name="add-circle" size={24} color={SKY} />
                    </View>
                    <Text style={styles.addOnsModalTitle}>{ADD_ON_SECTION_TITLE}</Text>
                  </View>
                  <TouchableOpacity onPress={() => setShowAddOnsModal(false)} style={styles.addOnsModalCloseBtn} hitSlop={12}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <Text style={styles.addOnsModalSubtitle}>{ADD_ON_SECTION_SUBTITLE}</Text>

                <ScrollView
                  style={styles.addOnsModalList}
                  contentContainerStyle={styles.addOnsModalListContent}
                  showsVerticalScrollIndicator={true}
                  bounces={true}
                >
                  {availableAddOnOptions.map((addOn) => {
                    const isSelected = selectedAddOns.includes(addOn.id);
                    return (
                      <TouchableOpacity
                        key={addOn.id}
                        onPress={() => toggleAddOn(addOn.id)}
                        style={[styles.addOnsModalRow, isSelected && styles.addOnsModalRowSelected]}
                        activeOpacity={0.75}
                      >
                        <View style={[styles.addOnsModalRowIcon, isSelected && styles.addOnsModalRowIconSelected]}>
                          <Ionicons name={(addOn.icon ?? 'add') as keyof typeof Ionicons.glyphMap} size={22} color={isSelected ? SKY : '#94A3B8'} />
                        </View>
                        <View style={styles.addOnsModalRowBody}>
                          <Text style={styles.addOnsModalRowName}>{addOn.name}</Text>
                          <Text style={styles.addOnsModalRowDesc} numberOfLines={2}>{addOn.desc}</Text>
                          <Text style={[styles.addOnsModalRowPriceInline, isSelected && styles.addOnsModalRowPriceSelected]}>+£{addOn.price}</Text>
                        </View>
                        <View style={[styles.addOnsModalCheck, isSelected && styles.addOnsModalCheckSelected]}>
                          {isSelected ? <Ionicons name="checkmark" size={14} color="#FFFFFF" /> : null}
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>

                {effectiveSelectedAddOns.length > 0 && (
                  <View style={styles.addOnsModalFooter}>
                    <Text style={styles.addOnsModalFooterLabel}>Add-ons total</Text>
                    <Text style={styles.addOnsModalFooterValue}>+£{addOnsTotal.toFixed(2)}</Text>
                  </View>
                )}
                <TouchableOpacity
                  onPress={() => { hapticFeedback('light'); setShowAddOnsModal(false); }}
                  style={styles.addOnsModalDone}
                  activeOpacity={0.85}
                >
                  <Text style={styles.addOnsModalDoneText}>Done</Text>
                </TouchableOpacity>
              </View>
            </Pressable>
          </Pressable>
        </Modal>

        {/* Bronze wash: Exterior / Interior – same opacity as bronze card (gradient + blur, no white) */}
        <Modal visible={showBronzeWashTypeOverlay} transparent animationType="fade" onRequestClose={() => setShowBronzeWashTypeOverlay(false)}>
          <Pressable style={styles.bronzeWashTypeOverlay} onPress={() => setShowBronzeWashTypeOverlay(false)}>
            <Pressable style={[styles.bronzeWashTypeModalContent, { borderColor: getServiceStripColor('bronze-wash', SKY) + '50' }]} onPress={(e) => e.stopPropagation()}>
              <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
              <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
              <View style={[styles.bronzeWashTypeModalAccent, { backgroundColor: getServiceStripColor('bronze-wash', SKY) }]} />
              <View style={styles.bronzeWashTypeModalContentInner}>
                <View style={styles.bronzeWashTypeModalHeader}>
                  <View>
                    <Text style={styles.bronzeWashTypeModalTitle}>Bronze Wash</Text>
                    <Text style={styles.bronzeWashTypeModalSubtitle}>What do you want cleaned?</Text>
                  </View>
                  <TouchableOpacity onPress={() => setShowBronzeWashTypeOverlay(false)} style={styles.bronzeWashTypeModalClose} hitSlop={12}>
                    <Ionicons name="close" size={22} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <View style={styles.bronzeWashTypeModalOptions}>
                  <TouchableOpacity onPress={() => handleWashTypeSelect('exterior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                    <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                      <Ionicons name="car-sport-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                    </View>
                    <View style={styles.bronzeWashTypeModalOptionText}>
                      <Text style={styles.bronzeWashTypeModalOptionLabel}>Exterior</Text>
                      <Text style={styles.bronzeWashTypeModalOptionDesc}>Snow foam, hand wash, wheels, dry & windows</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={18} color="#64748B" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleWashTypeSelect('interior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                    <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                      <Ionicons name="layers-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                    </View>
                    <View style={styles.bronzeWashTypeModalOptionText}>
                      <Text style={styles.bronzeWashTypeModalOptionLabel}>Interior</Text>
                      <Text style={styles.bronzeWashTypeModalOptionDesc}>Vacuum, wipe-down, glass & air freshener</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={18} color="#64748B" />
                  </TouchableOpacity>
                </View>
              </View>
            </Pressable>
          </Pressable>
        </Modal>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  selectedLocationMarkerCar: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  stepDots: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 100,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(148,163,184,0.4)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  modernCard: {
    padding: 14,
    overflow: 'hidden',
  },
  modernCardEmpty: {
    alignItems: 'center',
  },
  modernCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  titleAndBadge: {
    flex: 1,
    minWidth: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  serviceBadgePill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  serviceBadgePillText: {
    fontSize: 11,
    fontWeight: '700',
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  locationMicrocopy: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '600',
    color: SKY,
  },
  washTypeQuestion: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  titleRowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  changeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  changeBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  conditionMicrocopy: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 10,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#0EA5E9',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.4)',
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  vehicleStepWrap: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  locationRowAboveCards: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  locationRowValue: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  vehicleCardsScrollContent: {
    paddingRight: 16,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  serviceCardCurved: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  serviceCardUnified: {
    ...BOOKING_CARD.CURVED,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  vehicleCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  locationCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  /* Vehicle cards – compact, below location row */
  vehicleCard: {
    padding: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  vehicleCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  vehicleCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  vehicleCardCarIcon: {
    width: 44,
    height: 44,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 36,
  },
  vehicleCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  vehicleCardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  vehicleCardSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  vehicleCardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 4,
  },
  vehicleCardDefaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  vehicleCardDefaultText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FBBF24',
  },
  vehicleCardPhotoBox: {
    width: 44,
    height: 44,
    borderRadius: 10,
    overflow: 'hidden',
    marginLeft: 8,
  },
  vehicleCardPhotoSmall: {
    width: 44,
    height: 44,
  },
  vehicleCardPhotoPlaceholder: {
    width: 44,
    height: 44,
    backgroundColor: 'rgba(135,206,235,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardDivider: {
    height: 1,
    marginTop: 10,
    marginBottom: 8,
    borderRadius: 1,
    opacity: 0.6,
  },
  /* Combined location + vehicle single card */
  combinedCardScroll: {
    maxHeight: 340,
  },
  locationVehicleDivider: {
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.25)',
    marginHorizontal: 14,
    marginVertical: 4,
  },
  combinedVehicleSection: {
    paddingHorizontal: 14,
    paddingBottom: 14,
  },
  combinedVehicleSectionTitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  combinedVehicleLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
  },
  combinedVehicleLoadingText: {
    color: '#94A3B8',
    fontSize: 14,
  },
  combinedVehicleEmpty: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  combinedVehicleEmptyText: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 10,
  },
  combinedVehicleList: {
    paddingRight: 8,
    flexDirection: 'row',
  },
  vehicleRowInCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.25)',
    backgroundColor: 'rgba(15,23,42,0.4)',
    minWidth: 160,
    maxWidth: 200,
    marginRight: 10,
  },
  vehicleRowInCardSelected: {
    borderColor: SKY + '66',
    backgroundColor: SKY + '12',
  },
  vehicleRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  vehicleRowContent: {
    flex: 1,
    minWidth: 0,
  },
  vehicleRowTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  vehicleRowSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
  },
  vehicleRowInfoBtn: {
    padding: 4,
  },
  vehicleCardCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  vehicleCardCtaText: {
    fontSize: 14,
    fontWeight: '600',
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  washTypePillClean: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  washTypePillTextClean: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  bronzeWashTypeOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  bronzeWashTypeModalContent: {
    width: '100%',
    minHeight: 280,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 6,
  },
  bronzeWashTypeModalContentInner: {
    minHeight: 260,
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 20,
  },
  bronzeWashTypeModalAccent: {
    height: 4,
    width: '100%',
  },
  bronzeWashTypeModalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: 14,
  },
  bronzeWashTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 2,
  },
  bronzeWashTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  bronzeWashTypeModalClose: {
    padding: 4,
  },
  bronzeWashTypeModalOptions: {
    gap: 10,
  },
  bronzeWashTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bronzeWashTypeModalOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bronzeWashTypeModalOptionText: {
    flex: 1,
  },
  bronzeWashTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  bronzeWashTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  serviceStepWrap: {
    width: '100%',
  },
  resourcesToggleFixed: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 10,
  },
  resourcesHelperText: {
    marginTop: 8,
    paddingHorizontal: 8,
    color: 'rgba(241,245,249,0.85)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 4,
  },
  serviceModePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  serviceModeLabel: {
    color: 'rgba(135,206,235,0.6)',
    fontSize: 15,
    fontWeight: '700',
  },
  serviceModeLabelHighlight: {
    color: SKY,
  },
  serviceModeLabelHighlightYellow: {
    color: DETAILING_YELLOW,
  },
  addOnsRow: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  addOnsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  addOnsButtonIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: SKY + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsButtonText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  addOnsButtonHint: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 1,
  },
  addOnsBadge: {
    backgroundColor: SKY,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    marginLeft: 'auto',
  },
  addOnsBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },
  modalAddOnsSection: {
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '20',
  },
  modalAddOnsTitle: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  modalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  modalAddOnName: {
    color: colors.headerText,
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  modalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  modalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '18',
  },
  modalAddOnTotalLabel: {
    color: colors.headerSubtext,
    fontSize: 13,
    fontWeight: '600',
  },
  modalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 15,
    fontWeight: '800',
  },
  addOnsModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  addOnsModalContent: {
    width: '100%',
    height: '85%',
    maxHeight: 560,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    overflow: 'hidden',
  },
  addOnsModalContentInner: {
    flex: 1,
    padding: 20,
    minHeight: 320,
  },
  addOnsModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  addOnsModalTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  addOnsModalTitleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  addOnsModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },
  addOnsModalList: {
    flex: 1,
    minHeight: 200,
  },
  addOnsModalListContent: {
    paddingBottom: 16,
  },
  addOnsModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    marginBottom: 10,
  },
  addOnsModalRowSelected: {
    backgroundColor: SKY + '12',
    borderColor: SKY + '35',
  },
  addOnsModalRowIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  addOnsModalRowIconSelected: {
    backgroundColor: SKY + '25',
  },
  addOnsModalRowBody: {
    flex: 1,
    minWidth: 0,
  },
  addOnsModalRowName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  addOnsModalRowDesc: {
    color: '#94A3B8',
    fontSize: 12,
    lineHeight: 17,
    marginBottom: 4,
  },
  addOnsModalRowPriceInline: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '800',
  },
  addOnsModalRowPriceSelected: {
    color: SKY,
  },
  addOnsModalCheck: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: 'rgba(148,163,184,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  addOnsModalCheckSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  addOnsModalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    marginTop: 12,
    marginBottom: 12,
  },
  addOnsModalFooterLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '700',
  },
  addOnsModalFooterValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  addOnsModalDone: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    backgroundColor: SKY + '28',
    borderWidth: 1,
    borderColor: SKY + '50',
  },
  addOnsModalDoneText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceCardRight: {
    alignItems: 'flex-end',
    gap: 6,
  },
  servicePriceClean: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtnInCard: {
    padding: 4,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceBadgeBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  serviceBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeSection: {
    marginTop: 4,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  continueBtn: {
    height: 54,
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    width: '100%',
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Modal styles
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  infoModalCard: {
    width: '100%',
    height: '85%',
    maxHeight: '85%',
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.5)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.4,
    shadowRadius: 28,
    elevation: 16,
  },
  infoModalHeaderBar: {
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 20,
    position: 'relative',
  },
  infoModalHeaderLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginBottom: 4,
  },
  infoModalHeaderTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.2,
    paddingRight: 44,
  },
  infoModalHeaderSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    fontWeight: '600',
  },
  infoModalHeaderPrice: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 15,
    fontWeight: '700',
    marginTop: 4,
  },
  infoModalCloseBtn: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalDescTitle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  infoModalScrollWrap: {
    flex: 1,
    minHeight: 0,
  },
  infoModalScroll: {
    flex: 1,
    paddingHorizontal: 20,
  },
  infoModalScrollContent: {
    paddingTop: 18,
    paddingBottom: 24,
  },
  infoModalDesc: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 16,
  },
  infoModalBullets: {
    gap: 10,
    marginBottom: 16,
  },
  infoModalBulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalBulletDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  infoModalBulletText: {
    color: '#E2E8F0',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  infoModalAddOns: {
    marginTop: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  infoModalAddOnsTitle: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  infoModalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  infoModalAddOnName: {
    color: '#F1F5F9',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  infoModalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 14,
    fontWeight: '700',
  },
  infoModalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  infoModalAddOnTotalLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  infoModalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDoneWrap: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    borderRadius: 14,
    overflow: 'hidden',
  },
  infoModalDoneBtn: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoModalDoneText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  infoModalVehiclePhotoWrap: {
    height: 140,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  infoModalVehiclePhoto: {
    width: '100%',
    height: '100%',
  },
  infoModalVehiclePhotoPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: customerTheme.primary + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalVehicleTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 18,
    letterSpacing: -0.2,
  },
  infoModalVehicleRows: {
    gap: 12,
  },
  infoModalVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalVehicleRowText: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  addressOverlayKeyboardWrap: {
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(5,15,30,0.88)',
    justifyContent: 'flex-end',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 40,
  },
  addressOverlayContent: {
    width: '100%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '40',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayContentInner: {
    padding: 24,
  },
  addressOverlayTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  addressOverlaySubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    marginBottom: 12,
    lineHeight: 20,
  },
  addressOverlayUseCurrent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    marginBottom: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: SKY + '18',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  addressOverlayUseCurrentText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlaySavedList: {
    maxHeight: 160,
    marginBottom: 16,
  },
  addressOverlaySavedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(15,23,42,0.8)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    gap: 10,
  },
  addressOverlaySavedItemText: {
    flex: 1,
  },
  addressOverlaySavedItemLabel: {
    color: '#F1F5F9',
    fontSize: 15,
    fontWeight: '700',
  },
  addressOverlaySavedItemAddress: {
    color: '#94A3B8',
    fontSize: 13,
    marginTop: 2,
  },
  addressOverlaySearchLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  addressOverlayInput: {
    backgroundColor: '#0F172A',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: SKY + '30',
  },
  addressSuggestionsLoading: { paddingVertical: 12, alignItems: 'center' },
  addressSuggestionsList: { maxHeight: 200, marginTop: 8 },
  addressSuggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(15,23,42,0.8)',
    borderRadius: 12,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: SKY + '20',
  },
  addressSuggestionText: { color: '#F1F5F9', fontSize: 14, flex: 1 },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    alignItems: 'center',
  },
  addressOverlayCancelText: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlaySearchWrap: {
    flex: 1,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  addressOverlaySearch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  modalContent: {
    backgroundColor: 'transparent',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 24,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '35',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  modalContentTouch: {
    width: '100%',
    maxWidth: 320,
    maxHeight: '82%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '30',
  },
  modalContentBlur: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingBottom: 16,
  },
  modalHeaderHubStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitleHubStyle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScrollContent: {
    maxHeight: 360,
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  modalIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: customerTheme.primary + '25',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    color: colors.headerText,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  modalPrice: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  modalDescription: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 12,
    opacity: 0.95,
  },
  bulletPointsContainer: {
    gap: 8,
    marginBottom: 14,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  bulletPointText: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 18,
    flex: 1,
    opacity: 0.92,
  },
  modalCloseButton: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    shadowColor: customerTheme.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3,
  },
  modalCloseButtonGradient: {
    padding: 12,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 0.3,
  },
});
