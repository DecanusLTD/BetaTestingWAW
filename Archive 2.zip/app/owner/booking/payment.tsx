import React, { useCallback, useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import BookingPaymentSheet from '../../../src/components/booking/BookingPaymentSheet';

/**
 * Full-route payment: same Stripe flow as the tracking inline sheet, for hub flows that `replace` here after creating a pending-payment booking.
 */
export default function BookingPaymentScreen() {
  const { bookingId: bookingIdParam } = useLocalSearchParams<{ bookingId?: string }>();
  const bookingId = bookingIdParam ?? null;

  useEffect(() => {
    if (!bookingId) {
      router.back();
    }
  }, [bookingId]);

  const onClose = useCallback(() => {
    router.back();
  }, []);

  const onPaid = useCallback(() => {
    if (!bookingId) return;
    router.replace({ pathname: '/owner/booking/tracking', params: { bookingId } } as any);
  }, [bookingId]);

  if (!bookingId) {
    return <View style={styles.shell} />;
  }

  return (
    <View style={styles.shell}>
      <BookingPaymentSheet visible bookingId={bookingId} onClose={onClose} onPaid={onPaid} />
    </View>
  );
}

const styles = StyleSheet.create({
  shell: {
    flex: 1,
    backgroundColor: '#020617',
  },
});
