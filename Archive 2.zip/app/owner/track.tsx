import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View, Text } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { isBookingManuallyStarted } from '../../src/utils/activeBookingGuard';

const ACTIVE_STATUSES = [
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

export default function OwnerTrackEntry() {
  const params = useLocalSearchParams();
  const { user } = useAuth();
  const bookingId = typeof params.bookingId === 'string' ? params.bookingId : '';

  useEffect(() => {
    const go = async () => {
      if (bookingId) {
        router.replace({ pathname: '/owner/booking/tracking', params: { bookingId } } as any);
        return;
      }
      if (!user?.id) {
        router.replace('/owner/owner-dashboard' as any);
        return;
      }
      const { data } = await supabase
        .from('bookings')
        .select('id,status,scheduled_at')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES)
        .order('created_at', { ascending: false })
        .limit(20);

      let active: any | null = null;
      for (const row of data || []) {
        if (row.status !== 'scheduled' && row.status !== 'confirmed') {
          active = row;
          break;
        }
        const startAt = row.scheduled_at ? new Date(row.scheduled_at).getTime() : NaN;
        const withinLeadWindow = Number.isFinite(startAt) && startAt - Date.now() <= 60 * 60 * 1000;
        const manuallyStarted = await isBookingManuallyStarted(row.id);
        if (withinLeadWindow || manuallyStarted) {
          active = row;
          break;
        }
      }

      if (active?.id) {
        router.replace({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any);
      } else {
        router.replace('/owner/owner-dashboard' as any);
      }
    };
    void go();
  }, [bookingId, user?.id]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={styles.loaderWrap}>
        <ActivityIndicator size="small" color={colors.SKY} />
        <Text style={styles.loaderText}>Loading your live booking...</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  loaderWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  loaderText: {
    color: 'rgba(241,245,249,0.82)',
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
});
