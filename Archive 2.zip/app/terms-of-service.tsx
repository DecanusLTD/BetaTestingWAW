import React from 'react';
import { View, Text } from 'react-native';
import { useAuth } from '../src/providers/enhanced-auth-context';
import PolicyScreen, { policyScreenStyles } from '../src/components/shared/PolicyScreen';
import type { PolicySection } from '../src/components/shared/PolicyScreen';

export default function TermsOfService() {
  const { user } = useAuth();
  const accountType = (user?.userType === 'valeter' ? 'valeter' : user?.userType === 'organization' ? 'business' : 'customer') as 'customer' | 'valeter' | 'business';

  const sections: PolicySection[] = [
    {
      title: '1. Acceptance of Terms',
      icon: 'checkmark-circle',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          By using Wish a Wash, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use our service.
        </Text>
      ),
    },
    {
      title: '2. Service Description',
      icon: 'car',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          Wish a Wash connects customers with professional valeters for vehicle cleaning services. We facilitate bookings, payments, and communication between customers and service providers.
        </Text>
      ),
    },
    {
      title: '3. User Responsibilities',
      icon: 'people',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>You are responsible for:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Providing accurate information (vehicle details via DVLA integration)</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Maintaining account security</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Treating valeters and other users with respect</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Being at least 18 years old to use our service</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Ensuring your vehicle is accessible for service</Text>
          </View>
        </>
      ),
    },
    {
      title: '4. Payment Terms',
      icon: 'card',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          Payment is processed securely through our payment partners. Prices are displayed before booking confirmation. All payments are final unless cancelled according to our cancellation policy.
        </Text>
      ),
    },
    {
      title: '5. Cancellation Policy',
      icon: 'close-circle',
      content: (
        <>
          <Text style={policyScreenStyles.sectionText}>Cancellation terms:</Text>
          <View style={policyScreenStyles.bulletList}>
            <Text style={policyScreenStyles.bulletPoint}>• Free cancellation up to 2 hours before scheduled time</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Cancellations within 2 hours may incur charges</Text>
            <Text style={policyScreenStyles.bulletPoint}>• Valeter cancellations entitle you to a full refund</Text>
            <Text style={policyScreenStyles.bulletPoint}>• No-show charges may apply if valeter arrives and service cannot be performed</Text>
          </View>
        </>
      ),
    },
    {
      title: '6. Limitation of Liability',
      icon: 'shield',
      content: (
        <Text style={policyScreenStyles.sectionText}>
          Wish a Wash acts as an intermediary platform. We are not responsible for the quality of services provided by valeters, though we work to ensure high standards through our verification and rating systems.
        </Text>
      ),
    },
  ];

  return (
    <PolicyScreen
      title="Terms of Service"
      headerIcon="document-text"
      accountType={accountType}
      sections={sections}
    />
  );
}
