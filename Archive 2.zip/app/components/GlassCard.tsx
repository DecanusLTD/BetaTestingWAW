import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType } from '../../src/constants/accountThemes';
import { colors } from '../../src/constants/colors';

const SKY_BLUE_BORDER = 'rgba(91, 143, 168, 0.45)';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  borderRadius?: number;
  accountType?: AccountType;
}

export default function GlassCard({
  children,
  onPress,
  style,
  intensity = 40,
  tint = 'dark',
  borderColor,
  borderRadius = 18,
  accountType,
}: GlassCardProps) {
  const finalBorderColor = borderColor || SKY_BLUE_BORDER;

  const content = (
    <BlurView intensity={intensity} tint={tint} style={[styles.blurContainer, style, { borderRadius }]}>
      <LinearGradient
        colors={[colors.surfaceOverlayMid, colors.surfaceOverlay, 'rgba(255,255,255,0.02)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.border, { borderColor: finalBorderColor, borderRadius }]} />
      <View style={[styles.innerHighlight, { borderRadius }]} />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'transparent',
    elevation: 2,
    opacity: 0.9,
    shadowColor: 'rgba(91, 143, 168, 0.2)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
  },
  innerHighlight: {
    ...StyleSheet.absoluteFillObject,
    borderTopWidth: 1,
    borderTopColor: colors.surfaceOverlayStrong,
    pointerEvents: 'none',
  },
});
