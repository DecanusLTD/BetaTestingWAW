import { colors } from '../constants/colors';
import { detailingServiceOptions, repairServiceOptions } from '../constants/serviceOptions';

const SKY = colors.SKY ?? '#38BDF8';

const DETAILING_SERVICE_IDS = new Set([
  ...detailingServiceOptions.map((d) => d.id),
  ...repairServiceOptions.map((d) => d.id),
]);

/** True when the booking is a detailing job (customer UI: Detailing vs Washing labels). */
export function isCustomerDetailingService(serviceType?: string | null, serviceName?: string | null): boolean {
  if (serviceType && DETAILING_SERVICE_IDS.has(serviceType)) return true;
  const name = (serviceName || '').toLowerCase();
  if (name.includes('detail') || name.includes('ceramic') || name.includes('coating')) return true;
  return false;
}

export type BookingStatus =
  | 'pending'
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'valeter_declined'
  | 'valeter_timeout'
  | 'scheduled';

export type StepCardConfig = {
  stepTitle: string;
  stepSubtitle: string;
  stepIcon: 'time-outline' | 'wallet-outline' | 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles';
  stepAccent: string;
};

/** Map API/DB strings to the pro-app BookingStatus union (customer + pro alignment). */
export function normalizeStatusForTracking(raw: string): BookingStatus {
  const key = String(raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '_');
  switch (key) {
    case 'pending':
    case 'pending_business_acceptance':
    case 'pending_valeter_acceptance':
    case 'pending_payment':
    case 'confirmed':
    case 'valeter_assigned':
    case 'en_route':
    case 'arrived':
    case 'in_progress':
    case 'completed':
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
    case 'scheduled':
      return key as BookingStatus;
    default:
      return 'pending_valeter_acceptance';
  }
}

export function getStatusProgress(status: BookingStatus): number {
  switch (status) {
    case 'pending':
    case 'pending_business_acceptance':
      return 15;
    case 'pending_valeter_acceptance':
    case 'pending_payment':
    case 'scheduled':
      return 20;
    case 'confirmed':
    case 'valeter_assigned':
      return 40;
    case 'en_route':
      return 60;
    case 'arrived':
      return 80;
    case 'in_progress':
      return 90;
    case 'completed':
      return 100;
    case 'cancelled':
      return 0;
    default:
      return 0;
  }
}

export type StageItem = {
  label: string;
  done: boolean;
  current: boolean;
  icon: 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles' | 'wallet-outline';
};

/** Not yet in the “Accepted” stage (aligned with pro customer app + pool/business pending). */
const CUSTOMER_PRE_ACCEPT_STATUSES: BookingStatus[] = [
  'pending',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'pending_payment',
  'scheduled',
];

const customerPreAccept = (s: BookingStatus) => CUSTOMER_PRE_ACCEPT_STATUSES.includes(s);

/** Wash/valet stages (customer view): Accepted → On the way → Arrived → Washing → Done */
const WASH_STAGES = (s: BookingStatus): StageItem[] => [
  {
    label: 'Accepted',
    done: !customerPreAccept(s),
    current: ['confirmed', 'valeter_assigned'].includes(s),
    icon: 'checkmark-circle',
  },
  { label: 'On the way', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
  { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
  { label: 'Washing', done: s === 'completed', current: s === 'in_progress', icon: 'water' },
  { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
];

/** Detailing stages (customer view): Accepted → On the way → Arrived → Detailing → Done */
const DETAILING_STAGES = (s: BookingStatus): StageItem[] => [
  {
    label: 'Accepted',
    done: !customerPreAccept(s),
    current: ['confirmed', 'valeter_assigned'].includes(s),
    icon: 'checkmark-circle',
  },
  { label: 'On the way', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
  { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
  { label: 'Detailing', done: s === 'completed', current: s === 'in_progress', icon: 'sparkles' },
  { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
];

/**
 * Valeter (pro app) stages — included for parity with wishawasherwithconnect; customer screens pass forValeter=false.
 */
const VALETER_WASH_STAGES = (s: BookingStatus): StageItem[] => [
  {
    label: s === 'pending_valeter_acceptance' ? 'Accept job' : 'Awaiting payment',
    done: !['pending_valeter_acceptance', 'pending_payment'].includes(s),
    current: s === 'pending_valeter_acceptance' || s === 'pending_payment',
    icon: s === 'pending_valeter_acceptance' ? 'checkmark-circle' : 'wallet-outline',
  },
  {
    label: 'Paid',
    done: ['en_route', 'arrived', 'in_progress', 'completed'].includes(s),
    current: ['confirmed', 'valeter_assigned'].includes(s),
    icon: 'checkmark-circle',
  },
  { label: 'On the way', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
  { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
  { label: 'Washing', done: s === 'completed', current: s === 'in_progress', icon: 'water' },
  { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
];

const VALETER_DETAILING_STAGES = (s: BookingStatus): StageItem[] => [
  {
    label: s === 'pending_valeter_acceptance' ? 'Accept job' : 'Awaiting payment',
    done: !['pending_valeter_acceptance', 'pending_payment'].includes(s),
    current: s === 'pending_valeter_acceptance' || s === 'pending_payment',
    icon: s === 'pending_valeter_acceptance' ? 'checkmark-circle' : 'wallet-outline',
  },
  {
    label: 'Paid',
    done: ['en_route', 'arrived', 'in_progress', 'completed'].includes(s),
    current: ['confirmed', 'valeter_assigned'].includes(s),
    icon: 'checkmark-circle',
  },
  { label: 'On the way', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
  { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
  { label: 'Detailing', done: s === 'completed', current: s === 'in_progress', icon: 'sparkles' },
  { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
];

export function getStages(status: BookingStatus, isDetailing?: boolean, forValeter?: boolean): StageItem[] {
  if (forValeter) return isDetailing ? VALETER_DETAILING_STAGES(status) : VALETER_WASH_STAGES(status);
  return isDetailing ? DETAILING_STAGES(status) : WASH_STAGES(status);
}

function enRouteCustomerMessage(washHub: boolean, isDetailing: boolean | undefined): string {
  if (washHub) {
    return isDetailing ? 'Heading to detailer' : 'Heading to Car Wash';
  }
  return isDetailing ? 'Detailer on the way to you' : 'Valeter on the way to you';
}

function arrivedCustomerMessage(washHub: boolean, isDetailing: boolean | undefined): string {
  if (washHub) {
    return isDetailing ? 'At detailer' : 'At Car Wash';
  }
  return isDetailing ? 'Detailer has arrived' : 'Valeter has arrived';
}

function inProgressCustomerMessage(washHub: boolean, isDetailing: boolean | undefined): string {
  if (washHub) {
    return isDetailing ? 'Vehicle being detailed' : 'Vehicle being washed';
  }
  return isDetailing ? 'Detail in progress' : 'Service in progress';
}

export function getStatusMessage(
  status: BookingStatus,
  washHub: { name: string } | null,
  isDetailing?: boolean
): string {
  const hub = !!washHub;
  switch (status) {
    case 'pending':
    case 'pending_business_acceptance':
      return isDetailing ? 'Finding your detailer' : 'Finding your pro';
    case 'pending_valeter_acceptance':
      return isDetailing ? 'Connecting to your detailer' : 'Connecting to your pro';
    case 'pending_payment':
      return 'Waiting for payment';
    case 'scheduled':
      return isDetailing ? 'Detailing appointment scheduled' : 'Booking scheduled';
    case 'confirmed':
    case 'valeter_assigned':
      return isDetailing ? 'Detailer assigned – Ready to start' : 'Valeter assigned – Ready to start';
    case 'en_route':
      return enRouteCustomerMessage(hub, isDetailing);
    case 'arrived':
      return arrivedCustomerMessage(hub, isDetailing);
    case 'in_progress':
      return inProgressCustomerMessage(hub, isDetailing);
    case 'completed':
      return 'Service completed';
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
      return 'Booking cancelled';
    default:
      return 'Tracking your booking';
  }
}

type StepCardCtx = Readonly<{
  valeterName: string;
  washHub: { name: string } | null;
  isDetailing?: boolean;
}>;

function stepCardConnectingPro(c: StepCardCtx): StepCardConfig {
  const d = c.isDetailing;
  return {
    stepTitle: d ? 'Connecting to your detailer' : 'Connecting to your pro',
    stepSubtitle: d ? "We're connecting you with your detailer" : "We're connecting you with your pro",
    stepIcon: 'time-outline',
    stepAccent: '#F59E0B',
  };
}

function stepCardFindingPro(c: StepCardCtx): StepCardConfig {
  const d = c.isDetailing;
  return {
    stepTitle: d ? 'Finding your detailer' : 'Finding your pro',
    stepSubtitle: d ? 'We are matching you with a detailer' : 'We are matching you with a valeter',
    stepIcon: 'time-outline',
    stepAccent: '#F59E0B',
  };
}

const STEP_CARD_PENDING_PAYMENT: StepCardConfig = {
  stepTitle: 'Pay to confirm',
  stepSubtitle: 'Complete payment to lock in your booking',
  stepIcon: 'wallet-outline',
  stepAccent: '#F59E0B',
};

const STEP_CARD_SCHEDULED: StepCardConfig = {
  stepTitle: 'Scheduled',
  stepSubtitle: 'Booking is scheduled for later',
  stepIcon: 'time-outline',
  stepAccent: '#F59E0B',
};

function stepCardAccepted(c: StepCardCtx): StepCardConfig {
  return {
    stepTitle: 'Accepted',
    stepSubtitle: `${c.valeterName} is assigned – getting ready to head your way`,
    stepIcon: 'checkmark-circle',
    stepAccent: '#8B5CF6',
  };
}

function stepCardEnRoute(c: StepCardCtx): StepCardConfig {
  const hub = !!c.washHub;
  const d = c.isDetailing;
  let stepSubtitle: string;
  if (!hub) {
    stepSubtitle = `${c.valeterName} is on the way to you`;
  } else if (d) {
    stepSubtitle = 'Heading to the detailer';
  } else {
    stepSubtitle = 'Heading to the Car Wash';
  }
  return { stepTitle: 'On the way', stepSubtitle, stepIcon: 'car', stepAccent: SKY };
}

function stepCardArrived(c: StepCardCtx): StepCardConfig {
  const hub = !!c.washHub;
  const d = c.isDetailing;
  let stepSubtitle: string;
  if (!hub) {
    stepSubtitle = `${c.valeterName} has arrived at your location`;
  } else if (d) {
    stepSubtitle = "At the detailer – tap \"I've arrived\" when you're there";
  } else {
    stepSubtitle = "At the Car Wash – tap \"I've arrived\" when you're there";
  }
  return { stepTitle: 'Arrived', stepSubtitle, stepIcon: 'location', stepAccent: '#10B981' };
}

function stepCardInProgress(c: StepCardCtx): StepCardConfig {
  const d = c.isDetailing;
  return {
    stepTitle: d ? 'Detailing' : 'Washing',
    stepSubtitle: d ? 'Your vehicle is being detailed right now' : 'Your vehicle is being cleaned right now',
    stepIcon: d ? 'sparkles' : 'water',
    stepAccent: '#0EA5E9',
  };
}

const STEP_CARD_COMPLETED: StepCardConfig = {
  stepTitle: 'All done',
  stepSubtitle: 'Service completed – rate your experience',
  stepIcon: 'sparkles',
  stepAccent: '#10B981',
};

const STEP_CARD_CANCELLED: StepCardConfig = {
  stepTitle: 'Cancelled',
  stepSubtitle: 'This booking was cancelled',
  stepIcon: 'checkmark-circle',
  stepAccent: '#64748B',
};

const STEP_CARD_BY_STATUS: Partial<Record<BookingStatus, (c: StepCardCtx) => StepCardConfig>> = {
  pending: stepCardFindingPro,
  pending_business_acceptance: stepCardFindingPro,
  pending_valeter_acceptance: stepCardConnectingPro,
  pending_payment: () => STEP_CARD_PENDING_PAYMENT,
  scheduled: () => STEP_CARD_SCHEDULED,
  confirmed: stepCardAccepted,
  valeter_assigned: stepCardAccepted,
  en_route: stepCardEnRoute,
  arrived: stepCardArrived,
  in_progress: stepCardInProgress,
  completed: () => STEP_CARD_COMPLETED,
  cancelled: () => STEP_CARD_CANCELLED,
  valeter_declined: () => STEP_CARD_CANCELLED,
  valeter_timeout: () => STEP_CARD_CANCELLED,
};

export function getStepCardConfig(
  status: BookingStatus,
  valeterName: string,
  washHub: { name: string } | null,
  isDetailing?: boolean
): StepCardConfig {
  const builder = STEP_CARD_BY_STATUS[status];
  const ctx: StepCardCtx =
    isDetailing === undefined ? { valeterName, washHub } : { valeterName, washHub, isDetailing };
  if (builder) {
    return builder(ctx);
  }
  return {
    stepTitle: 'Tracking',
    stepSubtitle: getStatusMessage(status, washHub, isDetailing),
    stepIcon: 'car',
    stepAccent: SKY,
  };
}

export function getRingColorForStep(status: BookingStatus): string {
  switch (status) {
    case 'pending_business_acceptance':
    case 'pending':
      return '#F59E0B';
    case 'pending_valeter_acceptance':
    case 'pending_payment':
    case 'scheduled':
      return '#F59E0B';
    case 'confirmed':
    case 'valeter_assigned':
      return '#8B5CF6';
    case 'en_route':
      return SKY;
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return '#0EA5E9';
    case 'completed':
      return '#10B981';
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
      return '#64748B';
    default:
      return SKY;
  }
}

export function getActiveBookingStatusLabel(status: string): { label: string; icon: string; live?: boolean } {
  const map: Record<string, { label: string; icon: string; live?: boolean }> = {
    pending: { label: 'Pending', icon: 'time-outline' },
    pending_business_acceptance: { label: 'Pending', icon: 'time-outline' },
    pending_valeter_acceptance: { label: 'Finding valeter', icon: 'search-outline' },
    pending_payment: { label: 'Payment pending', icon: 'wallet-outline' },
    confirmed: { label: 'Confirmed', icon: 'checkmark-circle-outline' },
    scheduled: { label: 'Scheduled', icon: 'calendar-outline' },
    en_route: { label: 'On the way', icon: 'car-outline', live: true },
    arrived: { label: 'Arrived', icon: 'location-outline', live: true },
    in_progress: { label: 'In progress', icon: 'play', live: true },
  };
  return map[status] ?? { label: (status || '').replaceAll('_', ' '), icon: 'ellipse-outline' };
}

export function getStageProgressPercent(status: BookingStatus, isDetailing?: boolean, forValeter?: boolean): number {
  if (status === 'cancelled') return 0;
  const stages = getStages(status, isDetailing, forValeter);
  const n = stages.length;
  const doneCount = stages.filter((s) => s.done).length;
  const currentIndex = stages.findIndex((s) => s.current);
  const pctPerStage = 100 / n;
  if (currentIndex >= 0) return (currentIndex + 0.5) * pctPerStage;
  return doneCount * pctPerStage;
}

export function getStatusForStageIndex(index: number): BookingStatus | null {
  const statuses: BookingStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress', 'completed'];
  return statuses[index] ?? null;
}
