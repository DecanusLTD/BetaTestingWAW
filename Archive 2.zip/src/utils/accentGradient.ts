/**
 * Two-stop gradient for dynamic accent colors (e.g. service / brand hex).
 * Pairs with GradientIconBox `colors` prop.
 */
export function accentToGradient(accent: string): [string, string] {
  const a = accent.trim();
  if (/^#[0-9A-Fa-f]{6}$/i.test(a)) {
    return [a, `${a}E6`];
  }
  if (/^#[0-9A-Fa-f]{8}$/i.test(a)) {
    return [a.slice(0, 7), a];
  }
  return [a, a];
}
