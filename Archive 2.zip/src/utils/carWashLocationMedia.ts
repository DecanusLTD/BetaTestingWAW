/**
 * Reads a public image URL for a car wash / location row.
 * Supports multiple possible column names across schema versions.
 */
const PROFILE_URL_KEYS = [
  'profile_picture_url',
  'profile_image_url',
  'profile_picture',
  'image_url',
  'cover_image_url',
  'location_image_url',
  'photo_url',
] as const;

export function pickCarWashLocationProfileImageUrl(row: unknown): string | null {
  if (row == null || typeof row !== 'object') return null;
  const o = row as Record<string, unknown>;
  for (const k of PROFILE_URL_KEYS) {
    const v = o[k];
    if (typeof v === 'string' && v.trim().length > 0) return v.trim();
  }
  return null;
}
