/**
 * Map helpers: distance, ETA estimate, and fit region for showing multiple points.
 */
import type { Region } from 'react-native-maps';

type Coord = { latitude: number; longitude: number };

/** Haversine distance in km */
export function distanceKm(a: Coord, b: Coord): number {
  const R = 6371;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLon = ((b.longitude - a.longitude) * Math.PI) / 180;
  const lat1 = (a.latitude * Math.PI) / 180;
  const lat2 = (b.latitude * Math.PI) / 180;
  const x =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  return R * c;
}

/** Distance in miles */
export function distanceMiles(a: Coord, b: Coord): number {
  return distanceKm(a, b) * 0.621371;
}

/** Rough ETA minutes (assume ~25 km/h average in city) */
export function etaMinutes(distanceKmVal: number, avgSpeedKmh = 25): number {
  if (distanceKmVal <= 0) return 0;
  return Math.max(1, Math.ceil((distanceKmVal / avgSpeedKmh) * 60));
}

/** Build a region that fits all coordinates with padding */
export function regionForCoordinates(
  coords: Coord[],
  paddingFactor = 0.4
): Region {
  if (coords.length === 0) {
    return {
      latitude: 51.5074,
      longitude: -0.1278,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    };
  }
  if (coords.length === 1) {
    return {
      latitude: coords[0].latitude,
      longitude: coords[0].longitude,
      latitudeDelta: 0.008,
      longitudeDelta: 0.008,
    };
  }
  const lats = coords.map((c) => c.latitude);
  const lngs = coords.map((c) => c.longitude);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const latDelta = (maxLat - minLat) * (1 + paddingFactor);
  const lngDelta = (maxLng - minLng) * (1 + paddingFactor);
  return {
    latitude: (minLat + maxLat) / 2,
    longitude: (minLng + maxLng) / 2,
    latitudeDelta: Math.max(0.006, latDelta),
    longitudeDelta: Math.max(0.006, lngDelta),
  };
}

/** Edge padding for fitToCoordinates (top, right, bottom, left) */
export const FIT_PADDING = { top: 120, right: 48, bottom: 280, left: 48 };
