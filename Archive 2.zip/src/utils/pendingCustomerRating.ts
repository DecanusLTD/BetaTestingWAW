import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'pending_customer_rating_booking_id';

/** Remember a completed wash/detail booking so we can open Rate & Tip if auto-navigation was missed. */
export async function setPendingRatingBookingId(bookingId: string): Promise<void> {
  await AsyncStorage.setItem(KEY, bookingId);
}

export async function getPendingRatingBookingId(): Promise<string | null> {
  return AsyncStorage.getItem(KEY);
}

export async function clearPendingRatingBookingId(): Promise<void> {
  await AsyncStorage.removeItem(KEY);
}
