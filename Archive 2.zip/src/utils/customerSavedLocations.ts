import AsyncStorage from '@react-native-async-storage/async-storage';

/** Must match `app/owner/settings/saved-locations.tsx` storage key root. */
export const CUSTOMER_SAVED_LOCATIONS_KEY = 'customer_saved_locations';

export type CustomerSavedLocationLabelId = 'home' | 'work' | 'gym' | 'other';

export type CustomerSavedLocation = {
  id: string;
  label: CustomerSavedLocationLabelId;
  customLabel?: string;
  address: string;
  latitude: number;
  longitude: number;
};

export async function loadCustomerSavedLocations(userId: string): Promise<CustomerSavedLocation[]> {
  try {
    const raw = await AsyncStorage.getItem(`${CUSTOMER_SAVED_LOCATIONS_KEY}_${userId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as CustomerSavedLocation[]) : [];
  } catch {
    return [];
  }
}
