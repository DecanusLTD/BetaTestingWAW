import { supabase } from '../lib/supabase';

/**
 * One booking at a time: statuses that count as "customer has an active booking".
 * Customer cannot start a new booking while they have one in any of these statuses.
 */
export const ACTIVE_CUSTOMER_BOOKING_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'scheduled',
  'in_progress',
] as const;

export type ActiveBookingStatus = (typeof ACTIVE_CUSTOMER_BOOKING_STATUSES)[number];

/**
 * Returns the customer's current active booking (if any).
 * Use before creating a new booking to enforce one booking at a time.
 */
export async function getActiveBookingForCustomer(
  userId: string
): Promise<{ id: string; status: string } | null> {
  const { data, error } = await supabase
    .from('bookings')
    .select('id, status')
    .eq('user_id', userId)
    .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES])
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.warn('[activeBookingGuard] getActiveBookingForCustomer error:', error);
    return null;
  }
  return data ? { id: data.id, status: data.status } : null;
}
