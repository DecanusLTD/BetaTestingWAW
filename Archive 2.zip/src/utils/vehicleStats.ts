import { supabase } from '@/lib/supabase';

export type VehicleStats = {
  washCount: number;
  lastCleanedAt: string | null;
  cleanRating: number | null; // 0–5 average from completed bookings
};

export async function fetchVehicleStats(vehicleId: string): Promise<VehicleStats> {
  const result: VehicleStats = { washCount: 0, lastCleanedAt: null, cleanRating: null };

  try {
    const { data: completed, error } = await supabase
      .from('bookings')
      .select('id, completed_at, rating')
      .eq('vehicle_id', vehicleId)
      .eq('status', 'completed')
      .order('completed_at', { ascending: false });

    if (error) return result;
    const rows = completed ?? [];

    result.washCount = rows.length;
    if (rows.length > 0) {
      const withDate = rows.filter((r: { completed_at?: string }) => r.completed_at);
      if (withDate.length > 0) {
        result.lastCleanedAt = withDate[0].completed_at ?? null;
      }
      const withRating = rows.filter((r: { rating?: number }) => r.rating != null && !Number.isNaN(Number(r.rating)));
      if (withRating.length > 0) {
        const sum = withRating.reduce((s: number, r: { rating?: number }) => s + Number(r.rating), 0);
        result.cleanRating = Math.round((sum / withRating.length) * 10) / 10; // 1 decimal
      }
    }
  } catch {
    // keep defaults
  }
  return result;
}
