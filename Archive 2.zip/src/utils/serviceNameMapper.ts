/**
 * Service Name Mapper
 * Maps legacy service types to new service names and vice versa
 */

export const SERVICE_NAME_MAP: Record<string, string> = {
  // Legacy service types → New service names
  'instant_wash': 'Bronze Wash',
  'priority_wash': 'Silver Wash',
  'full_valet': 'Gold Wash',
  'premium_detail': 'Platinum Wash',
  'wash': 'Bronze Wash',
  'valet': 'Gold Wash',
  'basic-wash': 'Bronze Wash',
  'premium-wash': 'Silver Wash',
  
  // New service IDs → New service names
  'bronze-wash': 'Bronze Wash',
  'silver-wash': 'Silver Wash',
  'gold-wash': 'Gold Wash',
  'platinum-wash': 'Platinum Wash',
  'emerald-wash': 'Diamond Wash',
  /** Legacy ids — same display as standard tier (eco wash tier removed from booking). */
  'eco-bronze-wash': 'Bronze Wash',
  'eco-silver-wash': 'Silver Wash',
  'eco-gold-wash': 'Gold Wash',
  'eco-platinum-wash': 'Platinum Wash',
  'eco-emerald-wash': 'Diamond Wash',
  'headlight-restoration': 'Headlight Restoration',
  'scratch-removal': 'Scratch Removal',
  'paint-chip-repair': 'Paint Chip Repair',
  'trim-restoration': 'Trim Restoration',
  'leather-repair': 'Leather Repair',
};

export const REVERSE_SERVICE_MAP: Record<string, string> = {
  // New service names → Legacy service types (for backward compatibility)
  'Bronze Wash': 'instant_wash',
  'Silver Wash': 'priority_wash',
  'Gold Wash': 'full_valet',
  'Platinum Wash': 'premium_detail',
};

/**
 * Maps a service type/ID to a display name
 * @param serviceType - The service type from database (legacy or new)
 * @param serviceName - The service name from database (if available)
 * @returns The proper display name
 */
export function getServiceDisplayName(
  serviceType?: string | null,
  serviceName?: string | null
): string {
  // If we already have a proper service name, use it
  if (serviceName && /^Eco /.test(serviceName)) {
    if (serviceName === 'Eco Emerald Wash') return 'Diamond Wash';
    return serviceName.replace(/^Eco /, '');
  }

  if (
    serviceName &&
    [
      'Bronze Wash',
      'Silver Wash',
      'Gold Wash',
      'Gold Wash (Interior Focused)',
      'Platinum Wash',
      'Diamond Wash',
      'Emerald Wash',
    ].includes(serviceName)
  ) {
    if (serviceName === 'Emerald Wash') return 'Diamond Wash';
    return serviceName;
  }
  
  // Map legacy service types to new names
  if (serviceType && SERVICE_NAME_MAP[serviceType]) {
    return SERVICE_NAME_MAP[serviceType];
  }
  
  // If serviceName exists but isn't in our map, try to use it
  if (serviceName) {
    return serviceName;
  }
  
  // Fallback — avoid generic "Service" in customer UI when DB fields are empty
  return serviceType || 'Your wash';
}

/**
 * Gets service description based on service name
 */
export function getServiceDescription(serviceName: string): string {
  const descriptions: Record<string, string> = {
    'Bronze Wash': 'Quick exterior or light interior refresh',
    'Silver Wash': 'Balanced interior and exterior clean',
    'Gold Wash': 'Interior deep clean',
    'Gold Wash (Interior Focused)': 'Deeper interior clean at the car wash',
    'Platinum Wash': 'Full valet — interior and exterior',
    'Diamond Wash': 'Premium full detail',
  };

  return descriptions[serviceName] || 'Car care service';
}


