import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';

type TabBarInsetContextValue = {
  bottomReserve: number;
  setBottomReserve: (n: number) => void;
};

const TabBarInsetContext = createContext<TabBarInsetContextValue | null>(null);

export function TabBarInsetProvider({ children }: { children: React.ReactNode }) {
  const [bottomReserve, setBottomReserveState] = useState(0);
  const setBottomReserve = useCallback((n: number) => {
    setBottomReserveState((prev) => (prev === n ? prev : n));
  }, []);
  const value = useMemo(
    () => ({ bottomReserve, setBottomReserve }),
    [bottomReserve, setBottomReserve]
  );
  return <TabBarInsetContext.Provider value={value}>{children}</TabBarInsetContext.Provider>;
}

/** Pixels to leave above the screen bottom so scroll content is clipped below the floating nav tab. */
export function useTabBarBottomReserve(): number {
  return useContext(TabBarInsetContext)?.bottomReserve ?? 0;
}

export function useTabBarInsetSetter(): (n: number) => void {
  return useContext(TabBarInsetContext)?.setBottomReserve ?? (() => {});
}
