import React, { createContext, useContext, useState, useMemo } from 'react';

export type BookingFlowTheme = 'wash' | 'detailing' | null;

type BookingFlowThemeContextValue = {
  theme: BookingFlowTheme;
  setTheme: (theme: BookingFlowTheme) => void;
};

const BookingFlowThemeContext = createContext<BookingFlowThemeContextValue | null>(null);

export function BookingFlowThemeProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const [theme, setTheme] = useState<BookingFlowTheme>(null);
  const value = useMemo(
    () => ({ theme, setTheme }),
    [theme]
  );
  return (
    <BookingFlowThemeContext.Provider value={value}>
      {children}
    </BookingFlowThemeContext.Provider>
  );
}

export function useBookingFlowTheme() {
  const ctx = useContext(BookingFlowThemeContext);
  return ctx ?? { theme: null as BookingFlowTheme, setTheme: () => {} };
}
