// Boot context: single isBooting state at app root.
// Loading screen stays until auth is ready, critical assets are preloaded, and minimum time has elapsed.

import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { useAuth } from '../providers/enhanced-auth-context';
import { preloadBootAssets } from '../constants/appAssets';
import LoadingScreen from '../components/LoadingScreen';

/** Minimum time the loading screen is shown so app shell, navigation, and providers fully mount. */
const BOOT_MIN_DISPLAY_MS = 5500;

type BootContextType = {
  isBooting: boolean;
};

const BootContext = createContext<BootContextType>({ isBooting: true });

export function useBoot() {
  return useContext(BootContext);
}

export function BootProvider({ children }: { children: React.ReactNode }) {
  const { authReady } = useAuth();
  const [showLoading, setShowLoading] = useState(true);
  const [assetsReady, setAssetsReady] = useState(false);
  const [bootProgress, setBootProgress] = useState(0);
  const hideNativeOnce = useRef(false);
  const loadingShownAt = useRef<number>(Date.now());

  const isBooting = showLoading;

  // Animate progress bar from 0 to 1 over BOOT_MIN_DISPLAY_MS
  useEffect(() => {
    const interval = setInterval(() => {
      const elapsed = Date.now() - loadingShownAt.current;
      const p = Math.min(1, elapsed / BOOT_MIN_DISPLAY_MS);
      setBootProgress(p);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Preload all critical assets (videos, images) then hide native splash and show our loading screen
  useEffect(() => {
    let cancelled = false;
    let frameId: number | null = null;
    (async () => {
      await preloadBootAssets();
      if (cancelled) return;
      setAssetsReady(true);
      frameId = requestAnimationFrame(() => {
        if (!hideNativeOnce.current) {
          hideNativeOnce.current = true;
          // Delay hide to avoid "No native splash screen registered" on iOS
          setTimeout(() => {
            SplashScreen.hideAsync().catch(() => {});
          }, 100);
        }
      });
    })();
    return () => {
      cancelled = true;
      if (frameId != null) cancelAnimationFrame(frameId);
    };
  }, []);

  // Dismiss loading only when: auth ready + assets preloaded + minimum display time elapsed
  useEffect(() => {
    if (!authReady || !assetsReady) return;
    const elapsed = Date.now() - loadingShownAt.current;
    const remaining = Math.max(0, BOOT_MIN_DISPLAY_MS - elapsed);
    const t = setTimeout(() => setShowLoading(false), remaining);
    return () => clearTimeout(t);
  }, [authReady, assetsReady]);

  return (
    <BootContext.Provider value={{ isBooting }}>
      {children}
      {showLoading && (
        <View style={styles.loadingOverlay} pointerEvents="none">
          <LoadingScreen progress={bootProgress} />
        </View>
      )}
    </BootContext.Provider>
  );
}

const styles = StyleSheet.create({
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
  },
});
