// Boot context: single boot state at app root.
// Uses a premium animated launch overlay that exits as soon as startup is ready.
import React, { createContext, useContext, useState } from 'react';
import { useAuth } from '../providers/enhanced-auth-context';
import AppLaunchGate from '../components/loading/AppLaunchGate';

type BootContextType = {
  isBooting: boolean;
};

const BootContext = createContext<BootContextType>({ isBooting: true });

export function useBoot() {
  return useContext(BootContext);
}

export function BootProvider({ children }: { children: React.ReactNode }) {
  const { authReady } = useAuth();
  const [isBooting, setIsBooting] = useState(true);

  return (
    <BootContext.Provider value={{ isBooting }}>
      <AppLaunchGate startupReady={authReady} onBootStateChange={setIsBooting}>
        {children}
      </AppLaunchGate>
    </BootContext.Provider>
  );
}
