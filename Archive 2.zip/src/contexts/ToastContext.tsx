import React, { createContext, useCallback, useContext, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../constants/colors';
import { BORDER_RADIUS, SPACING } from '../constants/designTokens';

const { width } = Dimensions.get('window');
const TOAST_WIDTH = width - SPACING.xl * 2;

export type ToastType = 'success' | 'error' | 'info';

type ToastContextValue = {
  showToast: (message: string, type?: ToastType) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

const TOAST_CONFIG = {
  success: {
    icon: 'checkmark-circle' as const,
    bg: 'rgba(16,185,129,0.2)',
    border: 'rgba(16,185,129,0.5)',
    iconColor: '#10B981',
  },
  error: {
    icon: 'alert-circle' as const,
    bg: 'rgba(239,68,68,0.2)',
    border: 'rgba(239,68,68,0.5)',
    iconColor: '#EF4444',
  },
  info: {
    icon: 'information-circle' as const,
    bg: 'rgba(135,206,235,0.2)',
    border: 'rgba(135,206,235,0.5)',
    iconColor: colors.SKY,
  },
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  const [message, setMessage] = useState<string | null>(null);
  const [type, setType] = useState<ToastType>('success');
  const [anim] = useState(() => new Animated.Value(0));

  const showToast = useCallback((msg: string, toastType: ToastType = 'success') => {
    setMessage(msg);
    setType(toastType);
    anim.setValue(0);
    Animated.sequence([
      Animated.timing(anim, {
        toValue: 1,
        duration: 250,
        useNativeDriver: true,
      }),
      Animated.delay(2800),
      Animated.timing(anim, {
        toValue: 0,
        duration: 250,
        useNativeDriver: true,
      }),
    ]).start(() => setMessage(null));
  }, [anim]);

  const config = TOAST_CONFIG[type];
  const opacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const translateY = anim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] });

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {message != null && (
        <Animated.View
          pointerEvents="none"
          style={[
            styles.wrapper,
            {
              bottom: (Platform.OS === 'ios' ? insets.bottom : 24) + 80,
              opacity,
              transform: [{ translateY }],
            },
          ]}
        >
          <View style={[styles.toast, { backgroundColor: config.bg, borderColor: config.border }]}>
            <Ionicons name={config.icon} size={22} color={config.iconColor} />
            <Text style={styles.text} numberOfLines={2}>{message}</Text>
          </View>
        </Animated.View>
      )}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    return {
      showToast: (_msg: string, _type?: ToastType) => {},
    };
  }
  return ctx;
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    left: SPACING.xl,
    right: SPACING.xl,
    alignItems: 'center',
    zIndex: 99999,
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.lg,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 1,
    maxWidth: TOAST_WIDTH,
    gap: SPACING.sm,
  },
  text: {
    flex: 1,
    color: colors.textOnDarkPrimary,
    fontSize: 14,
    fontWeight: '600',
  },
});
