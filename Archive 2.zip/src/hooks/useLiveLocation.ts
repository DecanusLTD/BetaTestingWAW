import { useEffect, useState, useRef } from 'react';
import * as Location from 'expo-location';
import { AppState, AppStateStatus } from 'react-native';

export interface LiveLocationState {
  coords: Location.LocationObjectCoords | null;
  cityLabel: string | null;
  addressLine: string | null;
  permissionStatus: Location.PermissionStatus | null;
  loading: boolean;
  error?: string | null;
  requestPermission: () => Promise<void>;
  refresh: () => Promise<void>;
}

const GEO_EVERY_MS = 120000; // 2 minutes

export default function useLiveLocation(): LiveLocationState {
  const [coords, setCoords] = useState<Location.LocationObjectCoords | null>(null);
  const [cityLabel, setCityLabel] = useState<string | null>(null);
  const [addressLine, setAddressLine] = useState<string | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<Location.PermissionStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const watcherRef = useRef<Location.LocationSubscription | null>(null);
  const lastReverseGeocode = useRef<number>(0);
  const appState = useRef(AppState.currentState);

  const cleanupWatcher = () => {
    if (watcherRef.current) {
      watcherRef.current.remove();
      watcherRef.current = null;
    }
  };

  const reverseGeocode = async (latitude: number, longitude: number) => {
    try {
      const now = Date.now();
      if (now - lastReverseGeocode.current < GEO_EVERY_MS && cityLabel) {
        return;
      }
      lastReverseGeocode.current = now;
      const results = await Location.reverseGeocodeAsync({ latitude, longitude });
      if (results && results.length > 0) {
        const entry = results[0];
        const label = entry.city || entry.district || entry.subregion || entry.region || entry.country || 'Current Area';
        setCityLabel(label);
        const composed = [
          entry.name,
          entry.street,
          entry.district,
          entry.city,
          entry.postalCode,
        ]
          .filter(Boolean)
          .join(', ');
        if (composed.length > 0) {
          setAddressLine(composed);
        }
      }
    } catch (geoError) {
      console.warn('[useLiveLocation] reverse geocode error', geoError);
    }
  };

  const startWatcher = async () => {
    if (!coords && loading) {
      setLoading(true);
    }
    try {
      cleanupWatcher();
      watcherRef.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          distanceInterval: 200,
          timeInterval: 60000,
        },
        (loc) => {
          setCoords(loc.coords);
          reverseGeocode(loc.coords.latitude, loc.coords.longitude);
          setLoading(false);
        }
      );
    } catch (watchError) {
      console.warn('[useLiveLocation] watch error', watchError);
      setError('Could not access GPS');
      setLoading(false);
    }
  };

  const ensurePermission = async () => {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      setPermissionStatus(status);
      if (status === 'granted') return true;
      const request = await Location.requestForegroundPermissionsAsync();
      setPermissionStatus(request.status);
      if (request.status !== 'granted') {
        setError('Location permission is required to detect your area.');
        setLoading(false);
        return false;
      }
      return true;
    } catch (permError) {
      console.warn('[useLiveLocation] permission error', permError);
      setError('Unable to request location permission.');
      setLoading(false);
      return false;
    }
  };

  const requestPermission = async () => {
    await ensurePermission();
    if (permissionStatus === 'granted') {
      startWatcher();
    }
  };

  const refresh = async () => {
    const ok = await ensurePermission();
    if (ok) {
      startWatcher();
    }
  };

  useEffect(() => {
    let mounted = true;

    (async () => {
      const ok = await ensurePermission();
      if (!mounted) return;
      if (ok) {
        await startWatcher();
      }
      setLoading(false);
    })();

    const subscription = AppState.addEventListener('change', (nextState: AppStateStatus) => {
      if (appState.current.match(/inactive|background/) && nextState === 'active' && permissionStatus === 'granted') {
        refresh();
      }
      appState.current = nextState;
    });

    return () => {
      mounted = false;
      cleanupWatcher();
      subscription.remove();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return {
    coords,
    cityLabel,
    addressLine,
    permissionStatus,
    loading,
    error,
    requestPermission,
    refresh,
  };
}
