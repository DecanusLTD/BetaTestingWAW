import { useMemo } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TAB_BAR_TOTAL_HEIGHT } from '../constants/layoutConstants';
import { DASHBOARD_HEADER_CONTENT_OFFSET, HEADER_CONTENT_OFFSET } from '../components/shared/AppHeader';
import { useTabBarBottomReserve } from '../contexts/TabBarInsetContext';

const BOTTOM_PAD_EXTRA = 24;

/**
 * Scroll content padding for owner screens with dashboard/header.
 * The floating tab overlays the content, so keep enough bottom padding for the bar and safe area.
 */
export function useOwnerScrollContentPadding(useDashboardHeader = true) {
  const insets = useSafeAreaInsets();
  const tabBarReserve = useTabBarBottomReserve();

  return useMemo(() => {
    const headerOffset = useDashboardHeader ? DASHBOARD_HEADER_CONTENT_OFFSET : HEADER_CONTENT_OFFSET;
    const paddingBottom =
      tabBarReserve > 0
        ? Math.max(tabBarReserve, TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0)) + BOTTOM_PAD_EXTRA
        : TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + BOTTOM_PAD_EXTRA;
    return {
      paddingTop: (insets?.top ?? 0) + headerOffset,
      paddingBottom,
    };
  }, [insets, useDashboardHeader, tabBarReserve]);
}
