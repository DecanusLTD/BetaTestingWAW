import { Dimensions } from 'react-native';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export const CARD_SIZES = {
  small: {
    padding: 16,
    minHeight: 80,
    borderRadius: 16,
  },
  medium: {
    padding: 20,
    minHeight: 120,
    borderRadius: 18,
  },
  large: {
    padding: 24,
    minHeight: 160,
    borderRadius: 20,
  },
  fullWidth: {
    padding: 20,
    borderRadius: 20,
  },
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  section: 32,
};

export const getMetricCardWidth = (columns: number = 2, gap: number = SPACING.md) => {
  const padding = isSmallScreen ? 32 : 40;
  return (width - padding - gap * (columns - 1)) / columns;
};

