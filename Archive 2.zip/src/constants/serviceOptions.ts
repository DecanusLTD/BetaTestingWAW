/** Badge shown on service cards (e.g. "Popular", "Recommended", "Best value"). */
export type ServiceBadge = 'Quick & affordable' | 'Recommended' | 'Popular' | 'Best value' | 'Premium' | 'Most popular';

export interface ServiceOption {
  id: string;
  name: string;
  desc: string;
  dur: string;
  icon: string;
  colors: [string, string];
  price: number;
  minPrice?: number;
  maxPrice?: number;
  bulletPoints?: string[];
  /** Reassurance lines shown on confirmation (e.g. "✔ Complete interior & exterior clean"). */
  confirmationSummary?: string[];
  /** Optional badge for service card (e.g. "Popular", "Recommended"). */
  badge?: ServiceBadge;
  /** Add-on IDs already included in this service; these are hidden from the add-on picker when this service is selected. */
  includedAddOnIds?: string[];
  /** Title shown above the description in the info popup (e.g. "Essential Clean", "Showroom Finish"). */
  descriptionTitle?: string;
}

/* =======================
   STANDARD VALET SERVICES
======================= */

export const serviceOptions: ServiceOption[] = [
  {
    id: 'bronze-wash',
    name: 'Bronze Wash',
    descriptionTitle: 'Essential Clean',
    desc: 'Quick refresh to keep your vehicle looking tidy.',
    dur: '20–35 min',
    icon: 'water-outline',
    colors: ['#CD7F32', '#A0522D'],
    price: 15,
    bulletPoints: [
      'Exterior hand wash using safe shampoo',
      'Wheels and tyres cleaned',
      'Door shuts wiped',
      'Quick dry with microfiber towels',
      'Windows cleaned (exterior)',
      'Light interior tidy (dashboard & surfaces wipe)',
      'Rubbish removal',
      'Ideal for regular maintenance cleans',
      'Fast & affordable option',
    ],
    confirmationSummary: [
      'Essential clean – exterior wash, wheels, windows, light interior tidy',
      'Approx time: 20–35 mins',
      'Fast & affordable option',
    ],
  },
  {
    id: 'silver-wash',
    name: 'Silver Wash',
    descriptionTitle: 'Inside & Out Refresh',
    desc: 'A deeper clean for everyday drivers.',
    dur: '60–90 min',
    icon: 'sparkles-outline',
    colors: ['#C0C0C0', '#A8A8A8'],
    price: 25,
    bulletPoints: [
      'Everything in Bronze Wash',
      'Interior vacuum (seats, carpets & boot)',
      'Dashboard, centre console & trims cleaned',
      'Interior windows cleaned',
      'Tyres dressed for a fresh finish',
      'Spray wax protection for added shine',
      'Perfect weekly or bi-weekly clean',
      'Noticeably fresher interior & gloss finish',
    ],
    confirmationSummary: [
      'Inside & out refresh – vacuum, trims, interior glass, spray wax',
      'Approx time: 60–90 mins',
      'Perfect weekly or bi-weekly clean',
    ],
  },
  {
    id: 'gold-wash',
    name: 'Gold Wash',
    descriptionTitle: 'Deep Valet',
    desc: 'Thorough clean bringing your car back to life.',
    dur: '90–120 min',
    icon: 'trophy-outline',
    colors: ['#FFD700', '#FFA500'],
    price: 45,
    badge: 'Popular',
    bulletPoints: [
      'Everything in Silver Wash',
      'Deep interior vacuum & detailed wipe down',
      'Seats cleaned & refreshed',
      'Plastic trims restored',
      'Door panels & hard-to-reach areas cleaned',
      'High-quality wax sealant applied',
      'Wheel arches cleaned',
      'Enhanced tyre shine',
      'Best balance of value & transformation',
      'Ideal for neglected or family vehicles',
    ],
    confirmationSummary: [
      'Deep valet – seats refreshed, trims restored, wax sealant, wheel arches',
      'Approx time: 90–120 mins',
      'Best balance of value & transformation',
    ],
    includedAddOnIds: ['seat-shampoo'],
  },
  {
    id: 'platinum-wash',
    name: 'Platinum Wash',
    descriptionTitle: 'Showroom Finish',
    desc: 'Premium detailing experience for maximum results.',
    dur: '2–3 hours',
    icon: 'diamond-outline',
    colors: ['#E5E4E2', '#BCC6CC'],
    price: 85,
    badge: 'Premium',
    bulletPoints: [
      'Everything in Gold Wash',
      'Deep interior detail & sanitisation',
      'Upholstery or leather deep clean & condition',
      'Exterior decontamination treatment',
      'Hand polish for enhanced gloss',
      'Long-lasting paint protection applied',
      'Interior fragrance finish',
      'Attention to fine detailing areas',
      'Showroom-level finish',
      'Perfect before events, resale, or monthly premium care',
    ],
    confirmationSummary: [
      'Showroom finish – deep interior detail, decontamination, paint protection',
      'Approx time: 2–3 hours',
      'Perfect before events, resale, or monthly premium care',
    ],
  },
  {
    id: 'emerald-wash',
    name: 'Emerald Wash',
    descriptionTitle: 'Interior Deep Clean',
    desc: 'A comprehensive deep clean of the interior of your vehicle, bringing it back to a like-new condition. Ideal for family cars, daily drivers, or anyone who wants a thorough cabin refresh.',
    dur: '90–120 min',
    icon: 'sparkles',
    colors: ['#059669', '#047857'],
    price: 55,
    badge: 'Best value',
    bulletPoints: [
      'Rubbish cleared and cabin tidied',
      'Full interior hoovered and dusted',
      'Floors and carpets shampooed',
      'Seats shampooed and refreshed',
      'Leather cleaned and dressed where applicable',
      'Headliner and trim cleaned',
      'Steering wheel and touchpoints deep cleaned',
      'Full interior steam cleaned',
      'Pet hair removal available as add-on',
      'Stain removal and fabric protection available as add-ons',
      'Air freshener applied for a lasting finish',
    ],
    confirmationSummary: [
      'Interior deep clean – hoover, shampoo, trim, steam clean, steering wheel',
      'Approx time: 90–120 mins',
      'Ideal for neglected or family vehicles',
    ],
  },
];

/* =======================
   ECO VALET SERVICES
======================= */

export const ecoServiceOptions: ServiceOption[] = [
  {
    id: 'eco-bronze-wash',
    name: 'Eco Bronze Wash',
    desc: 'Same great clean, kinder to the planet. Biodegradable products, less water.',
    dur: '15–20 min',
    icon: 'leaf-outline',
    colors: ['#10B981', '#059669'],
    price: 18,
    minPrice: 15,
    maxPrice: 22,
    bulletPoints: [
      'Exterior or interior',
      'Eco shampoo, low-water wash',
      'Wheels & interior vacuum',
    ],
  },
  {
    id: 'eco-silver-wash',
    name: 'Eco Silver Wash',
    desc: 'Full inside & out with eco products. Same result, smaller footprint.',
    dur: '25–30 min',
    icon: 'leaf',
    colors: ['#34D399', '#10B981'],
    price: 28,
    minPrice: 25,
    maxPrice: 32,
    badge: 'Best value',
    bulletPoints: [
      'Eco wash, wheels & dry',
      'Vacuum, trims & all glass',
    ],
  },
  {
    id: 'eco-gold-wash',
    name: 'Eco Gold Wash',
    desc: 'Full eco valet – tyre dressing, interior refresh, natural deodoriser.',
    dur: '45–60 min',
    icon: 'reload-outline',
    colors: ['#059669', '#047857'],
    price: 48,
    minPrice: 45,
    maxPrice: 55,
    bulletPoints: [
      'Eco Silver + wheel & tyre dressing',
      'Fabric refresh, leather-safe conditioner',
      'Natural deodoriser',
    ],
    includedAddOnIds: ['seat-shampoo'],
  },
  {
    id: 'eco-platinum-wash',
    name: 'Eco Platinum Wash',
    desc: 'Premium eco detail – decon, sealant, deep interior & protection.',
    dur: '2–3 hours',
    icon: 'earth-outline',
    colors: ['#047857', '#065F46'],
    price: 90,
    minPrice: 85,
    maxPrice: 100,
    bulletPoints: [
      'Eco Gold + paint decontamination',
      'Eco wax or sealant',
      'Steam interior, odour & fabric guard',
    ],
  },
  {
    id: 'eco-emerald-wash',
    name: 'Eco Emerald Wash',
    desc: 'A comprehensive interior deep clean using eco-friendly products. Brings your cabin back to a like-new condition with a smaller environmental footprint.',
    dur: '90–120 min',
    icon: 'sparkles',
    colors: ['#059669', '#047857'],
    price: 58,
    minPrice: 52,
    maxPrice: 62,
    bulletPoints: [
      'Rubbish cleared and cabin tidied',
      'Full interior hoovered and dusted',
      'Floors and carpets shampooed (eco shampoo)',
      'Seats shampooed, leather dressed where applicable',
      'Headliner and trim cleaned',
      'Steering wheel and touchpoints deep cleaned',
      'Eco-friendly products throughout',
      'Air freshener applied',
    ],
  },
];

/* =======================
   DETAILING SERVICES
======================= */

export const detailingServiceOptions: ServiceOption[] = [
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    desc: 'Long-lasting paint protection with a premium ceramic layer that bonds to your paint. Delivers a deep gloss and makes washing easier for years.',
    dur: '6–8 hours',
    icon: 'shield-checkmark-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 350,
    badge: 'Popular',
    bulletPoints: [
      'Full exterior wash and paint decontamination',
      'Paint preparation and light correction if needed',
      'Professional-grade ceramic coating application',
      'Hydrophobic finish – water beads and runs off',
      'Strong UV, chemical, and oxidation protection',
      'Enhanced gloss and colour depth',
      'Typically 1–3+ years protection (depends on product and care)',
      'Best for: New or freshly corrected paint, low-maintenance shine',
    ],
  },
  {
    id: 'machine-polishing',
    name: 'Machine Polishing',
    desc: 'Professional paint correction using dual-action or rotary polishers. Removes swirls, light scratches, and defects to restore clarity and gloss.',
    dur: '4–6 hours',
    icon: 'color-filter-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 300,
    badge: 'Recommended',
    bulletPoints: [
      'Full wash and decontamination first',
      'Paint inspected under proper lighting',
      'Multi-stage machine polish (cut and refine)',
      'Removal of swirl marks, light scratches, and oxidation',
      'Noticeable improvement in gloss and depth',
      'Sealant or wax applied to protect the finish',
      'Level of correction depends on paint condition',
      'Best for: Dull or scratched paint, pre-ceramic prep, enthusiasts',
    ],
  },
  {
    id: 'soft-top-restoration',
    name: 'Soft Top Restoration',
    desc: 'Specialist care for fabric and vinyl convertible hoods. Cleans, reconditions, and protects to restore appearance and weather resistance.',
    dur: '2–3 hours',
    icon: 'brush-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 150,
    badge: 'Premium',
    bulletPoints: [
      'Gentle wash to remove dirt and stains',
      'Mould and mildew treatment if present',
      'Fabric or vinyl cleaner suited to your roof type',
      'Conditioning to restore colour and suppleness',
      'Water-repellent / UV protection product applied',
      'Seals and stitching checked',
      'Best for: Convertibles, cabriolets, fabric or vinyl soft tops',
    ],
  },
  {
    id: 'mould-removal',
    name: 'Mould Removal',
    desc: 'Professional removal of mould, mildew and musty odours from interior surfaces, air-con systems and cabin filters. Restores a fresh, clean interior.',
    dur: '1–2 hours',
    icon: 'water-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 95,
    badge: 'Premium',
    bulletPoints: [
      'Inspection of cabin filter, vents and ducting',
      'Air-con system sanitisation and treatment',
      'Dashboard, trim and upholstery mould treatment',
      'Odour neutralisation for a fresh cabin',
      'Prevention tips to reduce recurrence',
      'Best for: Musty smell, visible mould, after flooding or damp storage',
    ],
  },
  {
    id: 'headlight-restoration',
    name: 'Headlight Restoration',
    desc: 'Restore cloudy or yellowed headlights for clearer vision and a like-new look. Professional treatment to remove oxidation and restore clarity.',
    dur: '1–2 hours',
    icon: 'bulb-outline',
    colors: ['#EAB308', '#CA8A04'],
    price: 35,
    bulletPoints: [
      'Inspection of headlight condition',
      'Surface cleaned and prepared',
      'Oxidation and yellowing removed',
      'Polish and refinement for clarity',
      'UV sealant applied to slow future hazing',
      'Improved night-time visibility and appearance',
      'Best for: Cloudy, yellowed, or hazy headlights',
    ],
  },
];

/* =======================
   ADD-ON OPTIONS (wash & detail)
   "Enhance Your Clean" (Optional)
======================= */

export const ADD_ON_SECTION_TITLE = 'Enhance your clean';
export const ADD_ON_SECTION_SUBTITLE = 'Add extra treatments to your booking:';

export interface AddOnOption {
  id: string;
  name: string;
  desc: string;
  price: number;
  icon: string;
}

export const addOnOptions: AddOnOption[] = [
  {
    id: 'pet-hair',
    name: 'Pet hair removal',
    desc: 'Removes stubborn embedded pet hair from seats and carpets.',
    price: 12,
    icon: 'paw-outline',
  },
  {
    id: 'stain-removal',
    name: 'Stain removal treatment',
    desc: 'Targeted treatment for stubborn stains on seats and carpets.',
    price: 15,
    icon: 'water-outline',
  },
  {
    id: 'engine-bay',
    name: 'Engine bay clean',
    desc: 'Safe exterior engine bay clean and dress.',
    price: 25,
    icon: 'construct-outline',
  },
  {
    id: 'headlight-restoration',
    name: 'Headlight restoration',
    desc: 'Restore cloudy or yellowed headlights for clearer vision and a like-new look.',
    price: 35,
    icon: 'bulb-outline',
  },
  {
    id: 'seat-shampoo',
    name: 'Interior shampoo',
    desc: 'Deep fabric and upholstery cleaning to remove dirt and refresh seats and carpets.',
    price: 15,
    icon: 'water-outline',
  },
  {
    id: 'ceramic-spray',
    name: 'Ceramic spray protection upgrade',
    desc: 'Longer-lasting hydrophobic protection and enhanced gloss for your paintwork.',
    price: 25,
    icon: 'sparkles-outline',
  },
  {
    id: 'floor-mats-carpet-shampoo',
    name: 'Floor mats & carpet shampoo',
    desc: 'Deep clean and shampoo of footwells, floor mats and carpets.',
    price: 18,
    icon: 'water-outline',
  },
  {
    id: 'clay-bar-treatment',
    name: 'Clay bar treatment',
    desc: 'Paint decontamination to remove bonded contaminants and restore smoothness.',
    price: 35,
    icon: 'color-filter-outline',
  },
  {
    id: 'iron-tar-decontamination',
    name: 'Iron and tar decontamination',
    desc: 'Removes industrial fallout, tar spots and embedded particles from paintwork.',
    price: 40,
    icon: 'construct-outline',
  },
];

/** Wash tier ids that support interior/exterior add-on filtering (Bronze, Emerald). */
const BRONZE_EMERALD_WASH_IDS = ['bronze-wash', 'emerald-wash', 'eco-bronze-wash', 'eco-emerald-wash'];

/** Add-on ids shown only for interior (Bronze/Emerald interior). */
const ADD_ON_IDS_INTERIOR = ['pet-hair', 'stain-removal', 'seat-shampoo', 'floor-mats-carpet-shampoo'];

/** Add-on ids shown only for exterior (Bronze exterior). */
const ADD_ON_IDS_EXTERIOR = ['clay-bar-treatment', 'iron-tar-decontamination'];

/** Detailing service that may show exterior add-ons (clay bar, iron/tar). */
const SOFT_TOP_RESTORATION_ID = 'soft-top-restoration';

/**
 * Returns add-on ids that are available for the given service and (for wash) wash type.
 * - Bronze + interior: pet hair, stain removal, seats shampoo, floor mats & carpet shampoo
 * - Bronze + exterior: clay bar, iron and tar decontamination only
 * - Silver: all add-ons
 * - Gold: pet hair removal only
 * - Emerald / Platinum: no add-ons
 * - Detailing: no add-ons except soft-top-restoration gets clay bar + iron/tar
 */
export function getAvailableAddOnIdsForService(
  serviceId: string,
  washType: 'interior' | 'exterior' | 'both' | '' | null,
  isDetailing: boolean
): string[] {
  const allIds = addOnOptions.map((a) => a.id);
  if (isDetailing) {
    if (serviceId === SOFT_TOP_RESTORATION_ID) return ADD_ON_IDS_EXTERIOR;
    return [];
  }
  switch (serviceId) {
    case 'bronze-wash':
    case 'eco-bronze-wash':
      if (washType === 'interior') return ADD_ON_IDS_INTERIOR;
      if (washType === 'exterior') return ADD_ON_IDS_EXTERIOR;
      return [];
    case 'silver-wash':
    case 'eco-silver-wash':
      return allIds;
    case 'gold-wash':
    case 'eco-gold-wash':
      return ['pet-hair'];
    case 'emerald-wash':
    case 'eco-emerald-wash':
    case 'platinum-wash':
    case 'eco-platinum-wash':
      return [];
    default:
      return allIds;
  }
}
