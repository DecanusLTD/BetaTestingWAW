import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

/** Proportional scale for full Top Care Pro card tiles (avatar, type, stats). */
export const TOP_CARE_PRO_CARD_ZOOM = 0.92;

/** Global dashboard density — slightly tighter than before. */
const DASHBOARD_ZOOM = 0.82;
/** Book A Wish + Your Hub icons stay at the previous larger scale. */
const DASHBOARD_HERO_ZOOM = 0.9;

export const dz = (n: number) => Math.round(n * DASHBOARD_ZOOM);
/** Unchanged scale for Book A Wish CTA and Your Hub quick actions. */
export const dzHero = (n: number) => Math.round(n * DASHBOARD_HERO_ZOOM);
export const cpz = (n: number) => Math.round(n * TOP_CARE_PRO_CARD_ZOOM);

/** Phone-width carousel tile — shared by dashboard Top Care Pros and explore sheet. */
export function getTopCareProCardWidth(screenWidth: number = SCREEN_WIDTH): number {
  const isSmallScreen = screenWidth < 375;
  const inset = isSmallScreen ? 12 : 16;
  return Math.min(dz(300), screenWidth - inset * 2 - dz(12));
}
