// Standardized color scheme for headers, footers, and navigation
// Tuned for reduced brightness and better contrast (accessibility)

export const colors = {
  // Headers/Footers - Toned-down glassmorphism
  headerBg: '#1E3A8A',
  headerBgSecondary: 'rgba(135,206,235,0.12)',
  headerGradient: ['rgba(135,206,235,0.14)', 'rgba(191,219,254,0.1)'],
  headerBorder: 'rgba(148,163,184,0.35)',
  headerText: '#F1F5F9', // Softer than #F9FAFB for less glare, still WCAG AA on dark
  headerSubtext: '#94A3B8',

  // Glassmorphism - reduced intensity
  headerGlassBg: 'rgba(135,206,235,0.12)',
  headerGlassBorder: 'rgba(148,163,184,0.35)',
  headerGlassShadow: 'rgba(135,206,235,0.15)',
  headerGlassOverlay: 'rgba(30,58,138,0.08)',

  // Navigation Tab
  navBg: 'rgba(30,58,138,0.22)',
  navBorder: 'rgba(148,163,184,0.25)',
  navGlassBg: 'rgba(30,58,138,0.22)',
  navGlassBorder: 'rgba(148,163,184,0.25)',
  navActive: '#94A3B8', // Toned down from bright #BFDBFE
  navInactive: '#64748B',

  // Accents - toned down for less brightness
  accentLight: '#CBD5E1',
  accentMedium: '#94A3B8',
  accentDark: '#1E293B',
  greyLight: '#E2E8F0', // Was #F8FAFC - softer for clarity
  greyMedium: '#94A3B8',
  greyDark: '#64748B',

  // Surfaces (light-mode / overlays) - lower brightness, better contrast
  surfaceOverlay: 'rgba(255,255,255,0.04)',
  surfaceOverlayMid: 'rgba(255,255,255,0.06)',
  surfaceOverlayStrong: 'rgba(255,255,255,0.08)',
  borderLight: 'rgba(255,255,255,0.12)',
  borderLightStrong: 'rgba(255,255,255,0.18)',
  textOnDarkPrimary: '#F1F5F9',
  textOnDarkSecondary: 'rgba(241,245,249,0.88)',
  textOnDarkTertiary: 'rgba(241,245,249,0.7)',

  // Inputs - use for all TextInput placeholder and borders
  inputPlaceholder: 'rgba(255,255,255,0.5)',
  inputPlaceholderMuted: '#64748B',
  inputText: '#FFFFFF',
  inputBorder: 'rgba(148,163,184,0.25)',
  inputBorderFocused: 'rgba(135,206,235,0.6)',
  inputError: '#FCA5A5',
  inputErrorBorder: '#EF4444',

  // Background
  bgPrimary: '#0A1929',
  bgSecondary: '#1E293B',

  // Service-specific colors
  ecoGreen: '#10B981',
  premiumPurple: '#8B5CF6',
  /** Detailing flow accent (was purple, now yellow/gold). */
  detailingYellow: '#EAB308',
  detailingYellowDark: '#CA8A04',

  // Legacy / compatibility
  SKY: '#87CEEB',
  ICON_SKY: '#4AC8F6',
  ICON_SKY_DARK: '#2196C4',
  BG: '#0A1929',
  LIGHT_SKY: '#F1F5F9', // Toned down from #F9FAFB
  ECO_GREEN: '#10B981',
  PREMIUM_PURPLE: '#8B5CF6',
  /** Use for all detailing UI (booking, info hub, etc.). */
  DETAILING_YELLOW: '#EAB308',
  DETAILING_YELLOW_DARK: '#CA8A04',
};

