import type { AccountTheme } from './accountThemes';
import { colors } from './colors';

/** Icon accent palette – light theme uses light blue icons; dark uses colors.iconAccent. */
export const getIconAccentColors = (theme?: AccountTheme | null) => {
  if (theme?.mode === 'light') {
    const iconPrimary = theme.iconPrimary ?? theme.primary ?? '#7DD3FC';
    return {
      primary: iconPrimary,
      success: theme.statusOnlineAccent ?? '#22C55E',
      money: theme.iconHighlight ?? iconPrimary,
      highlight: theme.iconHighlight ?? iconPrimary,
      warning: '#F59E0B',
      destructive: '#EF4444',
    };
  }
  return {
    primary: colors.SKY,
    success: '#22C55E',
    money: colors.SKY,
    highlight: colors.SKY,
    warning: '#F59E0B',
    destructive: '#EF4444',
  };
};

/** Text colors for account chrome. */
export const getTextColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    primary: isLight ? (theme.textPrimary ?? '#F1F5F9') : '#F9FAFB',
    secondary: isLight ? (theme.textSecondary ?? 'rgba(241,245,249,0.88)') : 'rgba(249,250,251,0.88)',
    tertiary: isLight ? (theme.textOnBackground ?? 'rgba(241,245,249,0.7)') : 'rgba(249,250,251,0.75)',
    muted: isLight ? '#94A3B8' : 'rgba(249,250,251,0.68)',
    disabled: isLight ? 'rgba(241,245,249,0.5)' : 'rgba(249,250,251,0.48)',
    placeholder: isLight ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.4)',
  };
};

export const getIconColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  const primary = theme.iconPrimary ?? theme.accent;
  const highlight = theme.iconHighlight ?? primary;
  const inactiveLight = primary ? `${primary}CC` : '#93C5FD';
  return {
    primary: isLight ? primary : theme.accent,
    secondary: isLight ? (theme.textSecondary ?? 'rgba(249,250,251,0.9)') : 'rgba(255,255,255,0.88)',
    active: isLight ? primary : theme.accent,
    inactive: isLight ? inactiveLight : 'rgba(255,255,255,0.72)',
    highlight: isLight ? highlight : theme.accent,
  };
};

export const getBackgroundColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    card: isLight ? (theme.cardBackground ?? '#F8FBFF') : 'rgba(10,25,41,0.4)',
    cardBorder: isLight ? (theme.cardBorder ?? '#E3EEF9') : (theme.glassBorder || 'rgba(125,211,252,0.4)'),
  };
};
