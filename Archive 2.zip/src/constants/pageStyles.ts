/**
 * Shared styles for owner (and other) screens – consistent spacing, section headers, content cards.
 * Use with getScrollContentPadding from layoutConstants for full-page layout.
 */
import { StyleSheet } from 'react-native';
import { BORDER_RADIUS, SPACING, FONT_SIZES, FONT_WEIGHTS } from './designTokens';
import { colors } from './colors';

/** Horizontal padding for scroll content – use on contentContainerStyle */
export const CONTENT_PADDING_H = SPACING.xl;

/** Vertical rhythm helper for consistent section spacing across screens. */
export const SECTION_GAP = SPACING.lg;

/** Section title (e.g. "Wash History", "Payment methods") */
export const sectionTitle = {
  color: colors.textOnDarkPrimary,
  fontSize: FONT_SIZES.xl,
  fontWeight: FONT_WEIGHTS.bold,
  letterSpacing: 0.2,
  marginBottom: SPACING.xs,
} as const;

/** Section subtitle or description */
export const sectionSubtitle = {
  color: colors.textOnDarkTertiary,
  fontSize: FONT_SIZES.sm,
  lineHeight: 18,
  marginBottom: SPACING.lg,
} as const;

/** Wrapper for a block of content (card-like) – use with GlassCard or as container */
export const contentCard = {
  borderRadius: BORDER_RADIUS.lg,
  overflow: 'hidden' as const,
  marginBottom: SPACING.lg,
} as const;

/** Standard list item row (icon + text + optional right) */
export const listRow = {
  flexDirection: 'row' as const,
  alignItems: 'center' as const,
  paddingVertical: SPACING.md,
  paddingHorizontal: SPACING.lg,
  gap: SPACING.md,
} as const;

/** Primary text in a list row */
export const listRowTitle = {
  color: colors.textOnDarkPrimary,
  fontSize: FONT_SIZES.base,
  fontWeight: FONT_WEIGHTS.semibold,
  flex: 1,
} as const;

/** Secondary text in a list row */
export const listRowSubtitle = {
  color: colors.textOnDarkTertiary,
  fontSize: FONT_SIZES.sm,
  marginTop: 2,
} as const;

/** Accent border color for cards/inputs – use theme primary where context-specific */
export const accentBorder = colors.headerGlassBorder;

/** Soft background for section headers */
export const sectionHeaderBg = colors.headerGlassBg;

const styles = StyleSheet.create({
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
    paddingVertical: SPACING.sm,
  },
  sectionHeaderIcon: {
    width: 36,
    height: 36,
    borderRadius: BORDER_RADIUS.sm,
    backgroundColor: colors.headerGlassBg,
    borderWidth: 1,
    borderColor: colors.headerGlassBorder,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export { styles as pageStyles };
export const sectionHeader = styles.sectionHeader;
export const sectionHeaderIcon = styles.sectionHeaderIcon;
