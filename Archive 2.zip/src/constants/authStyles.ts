import { Dimensions, Platform, StyleSheet } from 'react-native';
import { colors } from './colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

/** Gradient overlay colors for auth video background (shared by login/signup). */
export const AUTH_GRADIENT_COLORS = [
  'rgba(10,25,41,0.4)',
  'rgba(10,25,41,0.65)',
  'rgba(10,25,41,0.92)',
] as const;

/** Content overlay: darker gradient behind glass card for readability */
export const AUTH_CONTENT_OVERLAY_COLORS = [
  'rgba(10,25,41,0.5)',
  'rgba(10,25,41,0.75)',
  'rgba(10,25,41,0.95)',
] as const;

const sharedAuthStyleDefs = {
  root: { flex: 1, backgroundColor: '#0A1929' as const },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 100 : 24,
    paddingBottom: 28,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: { flex: 1 },

  topRightLink: {
    position: 'absolute' as const,
    top: Platform.OS === 'ios' ? 50 : 24,
    right: 24,
    zIndex: 20,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  topRightLinkText: {
    color: '#B8E0F0',
    fontWeight: '700' as const,
    fontSize: 14,
  },

  videoBackground: StyleSheet.absoluteFillObject,

  logoContainer: {
    alignItems: 'center' as const,
    marginBottom: 10,
  },
  logoImageWrapper: {
    width: 560,
    height: 352,
    borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden' as const,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45,
    shadowRadius: 16,
    elevation: 16,
    borderWidth: 3,
    borderTopColor: 'rgba(255,255,255,0.45)',
    borderLeftColor: 'rgba(255,255,255,0.35)',
    borderRightColor: 'rgba(0,0,0,0.35)',
    borderBottomColor: 'rgba(0,0,0,0.45)',
  },
  logoImage: {
    width: 560,
    height: 352,
    borderRadius: 28,
    overflow: 'hidden' as const,
  },

  /** Headline + subtext under logo */
  headline: {
    fontSize: 22,
    fontWeight: '700' as const,
    color: 'rgba(255,255,255,0.98)',
    textAlign: 'center' as const,
    marginBottom: 4,
  },
  subtext: {
    fontSize: 15,
    fontWeight: '500' as const,
    color: 'rgba(255,255,255,0.72)',
    textAlign: 'center' as const,
    marginBottom: 22,
  },

  /** Glass card wrapper for primary actions */
  glassCard: {
    borderRadius: 22,
    overflow: 'hidden' as const,
    paddingHorizontal: 20,
    paddingTop: 22,
    paddingBottom: 22,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },

  /** Primary CTA: "Continue with Email" (not dropdown) */
  emailCtaButton: {
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 16,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    gap: 10,
  },
  emailCtaButtonText: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: 'rgba(255,255,255,0.95)',
  },

  toggleButton: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  toggleButtonContent: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 8,
  },
  toggleButtonText: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600' as const,
    color: 'rgba(255,255,255,0.9)',
  },

  formCard: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
    padding: 18,
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderRadius: 12,
    marginBottom: 12,
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  input: {
    flex: 1,
    color: colors.inputText,
    fontSize: 15,
    paddingRight: 12,
  },

  dividerContainer: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    marginTop: 18,
    marginBottom: 16,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600' as const,
  },

  /** Unified SSO: same height, radius, padding; icon left, text centered */
  ssoButton: {
    width: '100%' as const,
    height: 52,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    borderRadius: 14,
    paddingHorizontal: 20,
    marginBottom: 10,
    gap: 12,
  },
  ssoButtonApple: {
    backgroundColor: '#FFFFFF',
  },
  ssoButtonGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  ssoButtonLinkedIn: {
    backgroundColor: '#0A66C2',
  },
  ssoButtonText: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  ssoButtonTextLight: {
    color: '#1a1a1a',
  },
  ssoButtonTextWhite: {
    color: '#FFFFFF',
  },

  socialIconRow: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    gap: 14,
    marginTop: 2,
  },
  socialIconButton: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    backgroundColor: '#FFFFFF',
  },
  socialIconApple: {
    backgroundColor: '#FFFFFF',
  },
  socialIconGoogle: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },

  /** Trust & safety microcopy */
  trustCopy: {
    marginTop: 20,
    paddingHorizontal: 8,
  },
  trustCopyText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.55)',
    textAlign: 'center' as const,
    lineHeight: 18,
  },
  trustCopyLink: {
    color: '#87CEEB',
    fontWeight: '600' as const,
    textDecorationLine: 'underline' as const,
  },
  secureNote: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.45)',
    textAlign: 'center' as const,
    marginTop: 6,
  },

  /** Continue as Guest */
  guestLink: {
    marginTop: 12,
    alignSelf: 'center' as const,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  guestLinkText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: '500' as const,
  },

  footer: {
    marginTop: 24,
    alignItems: 'center' as const,
  },
  footerText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.4)',
  },
};

/** Shared auth style definitions. In login/signup use StyleSheet.create({ ...sharedAuthStyleDefs, ...screenSpecific }). */
export { sharedAuthStyleDefs };
