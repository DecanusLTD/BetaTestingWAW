/**
 * Central adaptive layout for iPad and large screens.
 * Use breakpoints and derived values so content doesn’t over-stretch and stays readable.
 */
import { Dimensions, ScaledSize, useWindowDimensions } from 'react-native';
import { useMemo } from 'react';

/** Breakpoints (width in dp). iPad mini ~768, iPad ~820, iPad Pro 12.9" ~1024. */
export const BREAKPOINTS = {
  /** Tablet: single column but wider padding and capped card width */
  tablet: 768,
  /** Large tablet / iPad Pro: max content width for readability */
  largeTablet: 1024,
} as const;

/** Minimum width treated as small phone (tight padding). */
export const SMALL_PHONE = 375;

export type AdaptiveLayout = {
  width: number;
  height: number;
  isSmallPhone: boolean;
  isTablet: boolean;
  isLargeTablet: boolean;
  /** Horizontal padding for main content (left/right). */
  horizontalPadding: number;
  /** Max width for centered content blocks (e.g. forms, cards container). */
  contentMaxWidth: number;
  /** Card width for booking cards and CTAs so they don’t stretch on iPad. */
  cardWidth: number;
  /** Snap interval for horizontal card lists (cardWidth + gap). */
  cardSnapInterval: number;
  /** Max width for tab bar so it doesn’t span full width on iPad. */
  tabBarMaxWidth: number;
  /** Horizontal margin for header. */
  headerMarginH: number;
};

function getLayoutFromDimensions({ width, height }: ScaledSize): AdaptiveLayout {
  const isSmallPhone = width < SMALL_PHONE;
  const isTablet = width >= BREAKPOINTS.tablet;
  const isLargeTablet = width >= BREAKPOINTS.largeTablet;

  let horizontalPadding: number;
  if (isTablet) horizontalPadding = 28;
  else if (isSmallPhone) horizontalPadding = 12;
  else horizontalPadding = 20;

  const contentMaxWidth = isLargeTablet ? 960 : isTablet ? 720 : undefined;
  const effectiveContentMax = contentMaxWidth ?? width;

  // Card: on phone min(width - 48, 340); on tablet cap so cards don’t get huge, leave margin
  const cardWidth = isTablet
    ? Math.min(400, Math.min(effectiveContentMax, width) - horizontalPadding * 2)
    : Math.min(width - 48, 340);

  const cardGap = 16;
  const cardSnapInterval = cardWidth + cardGap;

  // Tab bar: on tablet keep it a reasonable width and center
  const tabBarMaxWidth = isTablet ? 560 : width;

  const headerMarginH = isTablet ? 28 : isSmallPhone ? 16 : 20;

  return {
    width,
    height,
    isSmallPhone,
    isTablet,
    isLargeTablet,
    horizontalPadding,
    contentMaxWidth: contentMaxWidth ?? width,
    cardWidth,
    cardSnapInterval,
    tabBarMaxWidth,
    headerMarginH,
  };
}

/** One-time read from Dimensions (e.g. for StyleSheet or non-reactive layout). */
const initial = Dimensions.get('window');
export const ADAPTIVE_STATIC: AdaptiveLayout = getLayoutFromDimensions(initial);

/** Compute layout for a given size (e.g. from useWindowDimensions). */
export function getAdaptiveLayout(dimensions: ScaledSize): AdaptiveLayout {
  return getLayoutFromDimensions(dimensions);
}

/** Reactive layout that updates on orientation/resize (use in components). */
export function useAdaptiveLayout(): AdaptiveLayout {
  const dimensions = useWindowDimensions();
  return useMemo(() => getLayoutFromDimensions(dimensions), [dimensions.width, dimensions.height]);
}
