import type { Region } from 'react-native-maps';

/** Same zoom as booking and tracking maps (street-level, zoomed in on customer). */
export const MAP_ZOOM_DELTA = 0.001;

/** Duration for smooth camera animations (user location, valeter selected, booking confirmed). 700–900ms. */
export const MAP_CAMERA_ANIMATION_DURATION = 800;

/** Default map region when user location is not yet available (UK – London area). Same zoom as booking/tracking. */
export const DEFAULT_MAP_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: MAP_ZOOM_DELTA,
  longitudeDelta: MAP_ZOOM_DELTA,
};

/** Consistent position for floating recentre/locate button on all map views. Placed directly under the chat/cancel action row. Use: top = (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS. Left side: left = RECENTER_BUTTON_LEFT. Right side: right = RECENTER_BUTTON_RIGHT. */
export const RECENTER_BUTTON_LEFT = 16;
export const RECENTER_BUTTON_RIGHT = 16;
/** Top offset so the recenter button sits just below the chat/cancel action row (action row is HEADER_CONTENT_OFFSET + 16, height ~48, then 8px gap). */
export const RECENTER_BUTTON_TOP_BELOW_ACTIONS = 72;

/**
 * Lock map to dark style regardless of device Light/Dark system appearance (iOS/Android).
 * Use on every MapView: userInterfaceStyle={MAP_LOCKED_DARK}
 * so Apple Maps / map tiles never switch to light styling. App UI continues to follow system appearance.
 */
export const MAP_LOCKED_DARK = 'dark' as const;

/** Shared map style for Book a Service, Tracking, and Payment – consistent look, reduced label clutter. Always dark so map appearance is independent of system theme. */
export const BOOKING_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6b7280' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#1f2937' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#87CEEB' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#6b7280' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#9ca3af' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];
