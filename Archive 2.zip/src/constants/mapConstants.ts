import type { Region } from 'react-native-maps';

/** Same zoom as booking and tracking maps (street-level, zoomed in on customer). */
export const MAP_ZOOM_DELTA = 0.001;

/** Duration for smooth camera animations (user location, valeter selected, booking confirmed). 700–900ms. */
export const MAP_CAMERA_ANIMATION_DURATION = 800;

/** Default map region when user location is not yet available (UK – London area). Same zoom as booking/tracking. */
export const DEFAULT_MAP_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: MAP_ZOOM_DELTA,
  longitudeDelta: MAP_ZOOM_DELTA,
};

/** Padding from safe area before the floating map control row (back / actions). */
export const MAP_FLOATING_TOP_GAP = 10;

/** Height of the gradient map header row (padding + min row height; matches MapFloatingHeader / WWMapHeaderControls). */
export const MAP_FLOATING_HEADER_BODY_HEIGHT = 68;

/**
 * Distance from the top of the screen to the bottom of the floating map header chrome.
 * On map-first screens use `(insets.top ?? 0) + MAP_STACK_TOP` for content below the bar.
 */
export const MAP_STACK_TOP = MAP_FLOATING_TOP_GAP + MAP_FLOATING_HEADER_BODY_HEIGHT;

/** Consistent position for floating recentre/locate button. Use: `(insets.top ?? 0) + MAP_STACK_TOP + RECENTER_BUTTON_TOP_BELOW_ACTIONS` on map-first screens. */
export const RECENTER_BUTTON_LEFT = 16;
export const RECENTER_BUTTON_RIGHT = 16;
/** Top offset below the header stack / floating map row. */
export const RECENTER_BUTTON_TOP_BELOW_ACTIONS = 72;

/**
 * Lock map to dark style regardless of device Light/Dark system appearance (iOS/Android).
 * Use on every MapView: userInterfaceStyle={MAP_LOCKED_DARK}
 * so Apple Maps / map tiles never switch to light styling. App UI continues to follow system appearance.
 */
export const MAP_LOCKED_DARK = 'dark' as const;

/** Shared map style for Book a Service, valeter selection, payment — reduced label clutter. */
export const BOOKING_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6b7280' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#1f2937' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#87CEEB' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#6b7280' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#9ca3af' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];

/** Live navigation, tracking, en-route — higher-contrast roads for route readability. */
export const NAVIGATION_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#1e293b' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#94a3b8' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0f172a' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0369a1' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#52606d' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#7c8a9c' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#6b7280' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'simplified' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];

/** Picking / moving a pin — keep landmark POIs visible. */
export const LOCATION_PICKER_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#243045' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#7c8ea3' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#151c28' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#5b9bd4' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#5c6778' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'simplified' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];

/** Hub premises / on-site service maps — rich roads and locality (single shared Uber-style dark theme). */
export const HUB_PREMISES_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#263c3f' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#6b9a76' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#38414e' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#212a37' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#9ca5b3' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#746855' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#1f2835' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#f3d19c' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2f3948' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#17263c' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#515c6d' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#17263c' }] },
];

/** Service tier selection hero map — minimal chrome. */
export const SERVICE_ATLAS_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

/** Confirm / privacy — geometry only, no readable street labels in screenshots. */
export const PRIVACY_SNAPSHOT_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#1e293b' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#164e63' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#334155' }] },
  { featureType: 'all', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'road', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];

/** Past booking snapshot cards — subtle, low-attention. */
export const HISTORY_SNAPSHOT_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#273449' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#475569' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#3d5a73' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#3d4f63' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] },
];
