/**
 * Shared layout constants so every page gives space to the header and nav tab.
 * Use these for ScrollView/FlatList contentContainerStyle padding.
 *
 * Example (dashboard-style screen with bottom tab):
 *   const insets = useSafeAreaInsets();
 *   contentContainerStyle={{
 *     ...getScrollContentPadding(insets, true),
 *     paddingHorizontal: 20,
 *   }}
 */
import { TAB_BAR_TOTAL_HEIGHT } from '../../app/components/NavigationTab';
import { DASHBOARD_HEADER_CONTENT_OFFSET, HEADER_CONTENT_OFFSET } from '../components/shared/AppHeader';
import { BOOKING_CARD } from '../constants/bookingCardTheme';
import { ADAPTIVE_STATIC } from './adaptiveLayout';

/** Same width as booking cards so confirm/continue buttons align with cards. */
export const CTA_BUTTON_WIDTH = BOOKING_CARD.CARD_WIDTH;

/** Match header pill shape – use for primary CTA / “book” buttons. */
export const HEADER_BORDER_RADIUS = 24;

/** Horizontal padding for main content; use for iPad-friendly screens. */
export const CONTENT_HORIZONTAL_PADDING = ADAPTIVE_STATIC.horizontalPadding;

/** Max width for centered content on tablet (undefined = no cap). Use with alignSelf: 'center'. */
export const CONTENT_MAX_WIDTH = ADAPTIVE_STATIC.contentMaxWidth;

export { TAB_BAR_TOTAL_HEIGHT, HEADER_CONTENT_OFFSET, DASHBOARD_HEADER_CONTENT_OFFSET, getDashboardHeaderTopOffset };

const BOTTOM_PAD_EXTRA = 24;

/** Safe area insets (e.g. from useSafeAreaInsets()). Only top/bottom are used here. */
type SafeAreaInsetsLike = { top?: number; bottom?: number; left?: number; right?: number };

/** Bottom padding so content isn't hidden behind the nav tab. Use with insets.bottom. */
export function getNavTabBottomPadding(insets: SafeAreaInsetsLike): number {
  return TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + BOTTOM_PAD_EXTRA;
}

/** Top offset so content clears the absolutely-positioned dashboard header. Use for ScrollView/FlatList paddingTop. */
export function getDashboardHeaderTopOffset(insets: SafeAreaInsetsLike): number {
  return (insets?.top ?? 0) + DASHBOARD_HEADER_CONTENT_OFFSET;
}

/** Content container padding for pages with header + nav tab. */
export function getScrollContentPadding(insets: SafeAreaInsetsLike, useDashboardHeader = true): {
  paddingTop: number;
  paddingBottom: number;
} {
  const headerOffset = useDashboardHeader ? DASHBOARD_HEADER_CONTENT_OFFSET : HEADER_CONTENT_OFFSET;
  return {
    paddingTop: (insets?.top ?? 0) + headerOffset,
    paddingBottom: getNavTabBottomPadding(insets ?? {}),
  };
}
