/**
 * Launch v1 — owner customer journey
 *
 * Supported path:
 * - Discover: dashboard / explore / hub details
 * - Book mobile: `/owner/booking/create` → valeter selection → … → pay → track → complete
 * - Book hub: `/owner/booking/physical/*` (car wash at location only for hub flow)
 *
 * Intentionally not shipped as separate route trees (removed from repo):
 * - `/owner/booking/eco/*` (parallel eco-only flow)
 * - `/owner/booking/detailing/*` (hub detailing studio branch; mobile detailing remains on `create` if offered there)
 * - Orphan screens: navigate, standalone favourites/promotions, owner analytics, duplicate waiting-acceptance
 */

export const LAUNCH_CUSTOMER_SCOPE = 'v1-explore-mobile-or-hub' as const;
