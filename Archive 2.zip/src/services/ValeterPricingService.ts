import {
  detailingServiceOptions,
  findServiceOptionById,
  repairServiceOptions,
  serviceOptions,
} from '../constants/serviceOptions';
import { supabase } from '../lib/supabase';
import type { VehicleSize } from '../pricing/pricingEngine';

export type ValeterPriceTier = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

export type ValeterServicePricingValue =
  | number
  | {
      price?: number;
      basePrice?: number;
      enabled?: boolean;
      minutes?: number | null;
      small?: number;
      medium?: number;
      large?: number;
      xl?: number;
      xxl?: number;
      prices?: Partial<Record<ValeterPriceTier, number | null>>;
    };

export type ValeterServicePricingMap = Record<string, ValeterServicePricingValue>;

export interface ValeterServiceSettingsRow {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  detailing_menu?: ValeterServicePricingMap | unknown | null;
  tier_pricing?: ValeterServicePricingMap | unknown | null;
  repairs_offered?: boolean | null;
  repair_menu?: ValeterServicePricingMap | unknown | null;
}

export interface ResolvedValeterBookingPrice {
  available: boolean;
  serviceId: string;
  serviceName: string;
  basePrice: number;
  customerPrice: number;
  customerTotalPrice: number;
  pricingSource: 'valeter' | 'catalogue';
  platformFeePercent: number;
  platformFeeAmount: number;
}

const DEFAULT_PLATFORM_FEE_PERCENT = 0.2;

const cachedPlatformFeePercentByContext = new Map<string, number>();
const cachedPlatformFeeFetchedAtByContext = new Map<string, number>();

function toNumber(value: unknown): number | null {
  const n = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''));
  return Number.isFinite(n) ? n : null;
}

function normalizePlatformFeePercent(rawValue: unknown): number {
  const raw = toNumber(rawValue);
  if (raw == null) return DEFAULT_PLATFORM_FEE_PERCENT;
  if (raw > 1) return raw / 100;
  return Math.max(0, raw);
}

function toTierKey(size: VehicleSize | undefined | null): ValeterPriceTier {
  switch (size) {
    case 'MEDIUM':
      return 'medium';
    case 'LARGE':
      return 'large';
    case 'XL':
      return 'xl';
    case 'XXL':
      return 'xxl';
    default:
      return 'small';
  }
}

function resolvePriceFromEntry(entry: ValeterServicePricingValue | undefined, vehicleSize: VehicleSize | undefined | null): number | null {
  if (entry == null) return null;
  if (typeof entry === 'number') {
    return Number.isFinite(entry) ? entry : null;
  }

  const tierKey = toTierKey(vehicleSize);
  if (entry.prices && typeof entry.prices === 'object') {
    const tierValue = toNumber(entry.prices[tierKey]);
    if (tierValue != null) return tierValue;
    const tierSmall = toNumber(entry.prices.small);
    if (tierSmall != null) return tierSmall;
  }

  const tierValue = toNumber(entry[tierKey]);
  if (tierValue != null) return tierValue;

  const preferredFallback = toNumber(entry.price ?? entry.basePrice);
  if (preferredFallback != null) return preferredFallback;

  const smallFallback = toNumber(entry.small);
  if (smallFallback != null) return smallFallback;

  return null;
}

const WASH_SERVICE_IDS = new Set(serviceOptions.map((o) => o.id));
const DETAILING_SERVICE_IDS = new Set(detailingServiceOptions.map((o) => o.id));
const REPAIR_SERVICE_IDS = new Set(repairServiceOptions.map((o) => o.id));

function getServiceCategory(serviceId: string): 'wash' | 'detailing' | 'repair' | 'other' {
  const resolved = findServiceOptionById(serviceId);
  const normalizedId = resolved?.id ?? serviceId;
  if (WASH_SERVICE_IDS.has(normalizedId)) return 'wash';
  if (DETAILING_SERVICE_IDS.has(normalizedId)) return 'detailing';
  if (REPAIR_SERVICE_IDS.has(normalizedId)) return 'repair';
  return 'other';
}

function normalizePricingMenu(menu: unknown): ValeterServicePricingMap {
  if (!menu || typeof menu !== 'object') return {};
  if (Array.isArray(menu)) {
    return menu.reduce<ValeterServicePricingMap>((acc, item) => {
      if (!item || typeof item !== 'object') return acc;
      const row = item as Record<string, unknown>;
      const key = String(row.service_id ?? row.serviceId ?? row.id ?? row.slug ?? row.code ?? '').trim();
      if (!key) return acc;
      acc[key] = (row.price ?? row.basePrice ?? row.pricing ?? row) as ValeterServicePricingValue;
      return acc;
    }, {});
  }
  return menu as ValeterServicePricingMap;
}

function getWashTierKey(serviceId: string): string | null {
  const normalized = findServiceOptionById(serviceId)?.id ?? serviceId;
  const washMap: Record<string, string> = {
    'bronze-wash': 'bronze',
    'silver-wash': 'silver',
    'gold-wash': 'gold',
    'platinum-wash': 'platinum',
    'emerald-wash': 'emerald',
  };
  return washMap[normalized] ?? null;
}

function extractPricingEntry(map: ValeterServicePricingMap, serviceId: string): ValeterServicePricingValue | undefined {
  if (map[serviceId] != null) return map[serviceId];
  const resolved = findServiceOptionById(serviceId);
  if (resolved && map[resolved.id] != null) return map[resolved.id];
  const washTierKey = getWashTierKey(serviceId);
  if (washTierKey && map[washTierKey] != null) return map[washTierKey];
  const normalizedKey = serviceId.toLowerCase();
  const matchingKey = Object.keys(map).find((key) => key.toLowerCase() === normalizedKey);
  return matchingKey ? map[matchingKey] : undefined;
}

function isFullPriceMatrix(entry: ValeterServicePricingValue | undefined): boolean {
  if (!entry || typeof entry === 'number') return false;
  const prices = entry.prices;
  if (!prices || typeof prices !== 'object') return false;
  return ['small', 'medium', 'large', 'xl', 'xxl'].every((tier) => toNumber(prices[tier as ValeterPriceTier]) != null);
}

function isWashTierAvailable(serviceId: string, settings?: ValeterServiceSettingsRow | null, pricingMap?: ValeterServicePricingMap): boolean {
  if (!settings) return false;
  if (settings.eco_washing !== true) return false;
  const washTierKey = getWashTierKey(serviceId);
  if (!washTierKey) return false;
  const entry = pricingMap?.[washTierKey];
  if (!entry || typeof entry === 'number') return false;
  if (entry.enabled !== true) return false;
  if (!isFullPriceMatrix(entry)) return false;
  return true;
}

function isServiceAvailableFromSettings(
  serviceId: string,
  settings?: ValeterServiceSettingsRow | null,
  pricingMap?: ValeterServicePricingMap,
): boolean {
  if (!settings) return false;
  const category = getServiceCategory(serviceId);
  const hasExplicitPricing = pricingMap != null && Object.keys(pricingMap).length > 0;
  if (category === 'wash') return isWashTierAvailable(serviceId, settings, pricingMap);
  if (category === 'detailing') return settings.detailing_offered === true && (!hasExplicitPricing || extractPricingEntry(pricingMap, serviceId) != null);
  if (category === 'repair') return settings.repairs_offered === true && (!hasExplicitPricing || extractPricingEntry(pricingMap, serviceId) != null);
  return true;
}

function getSettingsPricingMap(serviceId: string, settings?: ValeterServiceSettingsRow | null): ValeterServicePricingMap {
  if (!settings) return {};
  const category = getServiceCategory(serviceId);
  if (category === 'wash') return normalizePricingMenu(settings.tier_pricing);
  if (category === 'detailing') return normalizePricingMenu(settings.detailing_menu);
  if (category === 'repair') return normalizePricingMenu(settings.repair_menu);
  return {};
}

export async function getActivePlatformFeePercent(
  context: 'valeter' | 'physical' = 'valeter',
  forceRefresh = false,
): Promise<number> {
  const cacheKey = context;
  const now = Date.now();
  const cachedPercent = cachedPlatformFeePercentByContext.get(cacheKey);
  const cachedFetchedAt = cachedPlatformFeeFetchedAtByContext.get(cacheKey) ?? 0;
  if (!forceRefresh && cachedPercent != null && now - cachedFetchedAt < 5 * 60 * 1000) {
    return cachedPercent;
  }

  try {
    const { data, error } = await supabase
      .from('waw_platform_fees')
      .select('context, percent, updated_at')
      .eq('context', context)
      .maybeSingle();

    if (error) throw error;

    const row = data as { context?: string; percent?: number | string } | null;
    const percent = normalizePlatformFeePercent(row?.percent);

    cachedPlatformFeePercentByContext.set(cacheKey, percent);
    cachedPlatformFeeFetchedAtByContext.set(cacheKey, now);
    return percent;
  } catch (error) {
    console.warn(`[ValeterPricing] using fallback platform fee (${context})`, error);
    const fallback = cachedPercent ?? DEFAULT_PLATFORM_FEE_PERCENT;
    cachedPlatformFeePercentByContext.set(cacheKey, fallback);
    cachedPlatformFeeFetchedAtByContext.set(cacheKey, now);
    return fallback;
  }
}

export function resolveValeterBookingPrice(args: {
  serviceId: string;
  vehicleSize?: VehicleSize | null | undefined;
  fallbackBasePrice?: number | null | undefined;
  settings?: ValeterServiceSettingsRow | null | undefined;
  platformFeePercent?: number | null | undefined;
}): ResolvedValeterBookingPrice {
  const serviceOption = findServiceOptionById(args.serviceId);
  const serviceName = serviceOption?.name ?? args.serviceId;
  const pricingMap = getSettingsPricingMap(args.serviceId, args.settings);
  const pricingEntry = extractPricingEntry(pricingMap, args.serviceId);
  const offered = isServiceAvailableFromSettings(args.serviceId, args.settings, pricingMap);

  const basePrice =
    resolvePriceFromEntry(pricingEntry, args.vehicleSize) ??
    (Number.isFinite(args.fallbackBasePrice ?? NaN) ? Number(args.fallbackBasePrice) : null) ??
    Number(serviceOption?.price ?? 0);

  const platformFeePercent = args.platformFeePercent != null ? args.platformFeePercent : DEFAULT_PLATFORM_FEE_PERCENT;
  const platformFeeAmount = Number((basePrice * platformFeePercent).toFixed(2));
  const customerTotalPrice = Number((basePrice + platformFeeAmount).toFixed(2));

  return {
    available: offered,
    serviceId: args.serviceId,
    serviceName,
    basePrice: Number(basePrice.toFixed(2)),
    customerPrice: customerTotalPrice,
    customerTotalPrice,
    pricingSource: pricingEntry != null && offered ? 'valeter' : 'catalogue',
    platformFeePercent,
    platformFeeAmount,
  };
}
