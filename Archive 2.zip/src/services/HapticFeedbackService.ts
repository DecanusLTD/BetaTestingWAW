// src/services/HapticFeedbackService.ts
import * as Haptics from 'expo-haptics';

type Impact = 'light' | 'medium' | 'heavy' | 'soft' | 'rigid';

const map: Record<Impact, Haptics.ImpactFeedbackStyle> = {
  light: Haptics.ImpactFeedbackStyle.Light,
  medium: Haptics.ImpactFeedbackStyle.Medium,
  heavy: Haptics.ImpactFeedbackStyle.Heavy,
  soft: Haptics.ImpactFeedbackStyle.Soft,
  rigid: Haptics.ImpactFeedbackStyle.Rigid,
};

export async function hapticFeedback(kind: Impact = 'light') {
  try {
    await Haptics.impactAsync(map[kind]);
  } catch {
    // Haptics not available (simulator, or disabled)
  }
}

/** Success-style haptic (e.g. for swipe-to-confirm). Use for completion actions. */
export async function hapticSuccess() {
  try {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  } catch {
    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch {
      // ignore
    }
  }
}
