import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@customer_dashboard_map_location_v1';

/** Mirrors dashboard `mapLocationOverride` — persisted so Book a Service pickers can reuse it. */
export type PersistedCustomerDashboardMapLocation = {
  latitude: number;
  longitude: number;
  address: string;
  badge?: string;
};

export async function loadPersistedCustomerDashboardMapLocation(): Promise<PersistedCustomerDashboardMapLocation | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object') return null;
    const o = parsed as Record<string, unknown>;
    const lat = Number(o.latitude);
    const lng = Number(o.longitude);
    const address = typeof o.address === 'string' ? o.address : '';
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || address.length === 0) return null;
    return {
      latitude: lat,
      longitude: lng,
      address,
      badge: typeof o.badge === 'string' ? o.badge : undefined,
    };
  } catch {
    return null;
  }
}

export async function savePersistedCustomerDashboardMapLocation(
  loc: PersistedCustomerDashboardMapLocation | null
): Promise<void> {
  try {
    if (loc == null) {
      await AsyncStorage.removeItem(STORAGE_KEY);
      return;
    }
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(loc));
  } catch {
    // ignore
  }
}
