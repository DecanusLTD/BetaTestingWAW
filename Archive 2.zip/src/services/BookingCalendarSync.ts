import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Calendar from 'expo-calendar';
import { Platform } from 'react-native';

const EVENT_MAP_KEY = 'wishawash:calendar:event-map:v1';

type BookingCalendarPayload = {
  id: string;
  serviceName?: string | null;
  serviceType?: string | null;
  address?: string | null;
  scheduledAt?: string | null;
};

type EventMap = Record<string, string>;

async function readEventMap(): Promise<EventMap> {
  try {
    const raw = await AsyncStorage.getItem(EVENT_MAP_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as EventMap;
  } catch {
    return {};
  }
}

async function writeEventMap(map: EventMap): Promise<void> {
  await AsyncStorage.setItem(EVENT_MAP_KEY, JSON.stringify(map));
}

async function getWritableCalendarId(): Promise<string | null> {
  const permissions = await Calendar.requestCalendarPermissionsAsync();
  if (permissions.status !== 'granted') return null;

  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  const preferred =
    calendars.find((c) => c.allowsModifications && c.isPrimary) ??
    calendars.find((c) => c.allowsModifications && c.source?.name?.toLowerCase().includes('icloud')) ??
    calendars.find((c) => c.allowsModifications);
  return preferred?.id ?? null;
}

function eventTitle(payload: BookingCalendarPayload): string {
  const service = payload.serviceName || payload.serviceType || 'Booking';
  return `Wish A Wash · ${service}`;
}

export async function syncBookingToDeviceCalendar(payload: BookingCalendarPayload): Promise<void> {
  if (!payload.id || !payload.scheduledAt) return;
  if (Platform.OS !== 'ios' && Platform.OS !== 'android') return;

  const startDate = new Date(payload.scheduledAt);
  if (Number.isNaN(startDate.getTime())) return;
  const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);

  const calendarId = await getWritableCalendarId();
  if (!calendarId) return;

  const map = await readEventMap();
  const existingId = map[payload.id];

  const details: Calendar.Event = {
    title: eventTitle(payload),
    notes: `Booking #${payload.id}\n${payload.address || 'Service location'}`,
    location: payload.address || undefined,
    startDate,
    endDate,
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    alarms: [{ relativeOffset: -60 }],
  };

  try {
    if (existingId) {
      await Calendar.updateEventAsync(existingId, details);
      return;
    }
  } catch {
    // recreate below if stale event id
  }

  const eventId = await Calendar.createEventAsync(calendarId, details);
  map[payload.id] = eventId;
  await writeEventMap(map);
}

export async function removeBookingFromDeviceCalendar(bookingId: string): Promise<void> {
  if (!bookingId) return;
  if (Platform.OS !== 'ios' && Platform.OS !== 'android') return;

  const map = await readEventMap();
  const eventId = map[bookingId];
  if (!eventId) return;

  try {
    await Calendar.deleteEventAsync(eventId);
  } catch {
    // ignore stale event
  }

  delete map[bookingId];
  await writeEventMap(map);
}
