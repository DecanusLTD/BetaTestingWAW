/**
 * Google Places / Geocoding API for address search (e.g. "Change location").
 * Uses GOOGLE_MAPS_API_KEY from config. Enable Geocoding API and Places API in Google Cloud Console.
 * All searches are restricted to the UK (country:gb).
 */

import { GOOGLE_MAPS_API_KEY } from '../config/google-maps';

const UK_COMPONENT = 'country:gb';

export type GeocodeResult = {
  latitude: number;
  longitude: number;
  formattedAddress: string;
};

export type PlaceSuggestion = {
  placeId: string;
  description: string;
};

function getKey(): string | null {
  const key = GOOGLE_MAPS_API_KEY;
  if (!key || key.includes('your_')) return null;
  return key;
}

/**
 * Fetch place suggestions as the user types (Places Autocomplete).
 * Returns addresses, establishments, cities, and other locations (UK only).
 * Call with debounced input (e.g. 300ms) to avoid excessive requests.
 */
export async function fetchPlaceSuggestions(input: string): Promise<PlaceSuggestion[]> {
  const key = getKey();
  if (!key) return [];
  const trimmed = input.trim();
  if (trimmed.length < 2) return [];
  const base = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(trimmed)}&key=${key}`;
  const ukUrl = `${base}&components=${encodeURIComponent(UK_COMPONENT)}`;
  const res = await fetch(ukUrl);
  const data = (await res.json()) as {
    status: string;
    predictions?: Array<{ place_id: string; description: string }>;
  };
  if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') return [];
  let predictions = data.predictions ?? [];
  if (predictions.length === 0) {
    const fallbackRes = await fetch(base);
    const fallbackData = (await fallbackRes.json()) as {
      status: string;
      predictions?: Array<{ place_id: string; description: string }>;
    };
    if (fallbackData.status === 'OK' || fallbackData.status === 'ZERO_RESULTS') {
      predictions = fallbackData.predictions ?? [];
    }
  }
  // If Places autocomplete is restricted/unavailable, fallback to geocoding and synthesize suggestions.
  if (predictions.length === 0) {
    const geoBase = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(trimmed)}&key=${key}`;
    const geoRes = await fetch(`${geoBase}&components=${encodeURIComponent(UK_COMPONENT)}`);
    const geoData = (await geoRes.json()) as {
      status: string;
      results?: Array<{
        place_id?: string;
        formatted_address?: string;
      }>;
    };
    if (geoData.status === 'OK' && Array.isArray(geoData.results)) {
      predictions = geoData.results.slice(0, 5).map((r, idx) => ({
        place_id: r.place_id || `geocode-${idx}-${trimmed}`,
        description: r.formatted_address || trimmed,
      }));
    } else {
      const geoFallbackRes = await fetch(geoBase);
      const geoFallbackData = (await geoFallbackRes.json()) as {
        status: string;
        results?: Array<{
          place_id?: string;
          formatted_address?: string;
        }>;
      };
      if (geoFallbackData.status === 'OK' && Array.isArray(geoFallbackData.results)) {
        predictions = geoFallbackData.results.slice(0, 5).map((r, idx) => ({
          place_id: r.place_id || `geocode-fallback-${idx}-${trimmed}`,
          description: r.formatted_address || trimmed,
        }));
      }
    }
  }
  return predictions.map((p) => ({
    placeId: p.place_id,
    description: p.description,
  }));
}

/**
 * Get lat/lng and formatted address for a place_id (after user selects a suggestion).
 */
export async function getPlaceDetails(placeId: string): Promise<GeocodeResult | null> {
  const key = getKey();
  if (!key) return null;
  const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&key=${key}&fields=geometry,formatted_address`;
  const res = await fetch(url);
  const data = (await res.json()) as {
    status: string;
    result?: {
      geometry?: { location?: { lat: number; lng: number } };
      formatted_address?: string;
    };
  };
  if (data.status !== 'OK' || !data.result?.geometry?.location) return null;
  const loc = data.result.geometry.location;
  return {
    latitude: loc.lat,
    longitude: loc.lng,
    formattedAddress: data.result.formatted_address ?? '',
  };
}

/**
 * Resolve an autocomplete row to coordinates. Uses Place Details when valid; otherwise geocodes
 * `description` (required when autocomplete fell back to geocode rows with synthetic `placeId`s).
 */
export async function resolvePlaceSuggestionToGeocode(s: PlaceSuggestion): Promise<GeocodeResult | null> {
  const d = await getPlaceDetails(s.placeId);
  if (d) return d;
  const matches = await geocodeAddress(s.description);
  return matches[0] ?? null;
}

/**
 * Geocode an address or place query to lat/lng + formatted address.
 * Used for "Change location" and address search flows (fallback when no suggestion selected).
 */
export async function geocodeAddress(query: string): Promise<GeocodeResult[]> {
  if (!getKey()) return [];
  const base = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(query.trim())}&key=${GOOGLE_MAPS_API_KEY}`;
  const ukUrl = `${base}&components=${encodeURIComponent(UK_COMPONENT)}`;
  const res = await fetch(ukUrl);
  const data = (await res.json()) as {
    status: string;
    results?: Array<{
      geometry: { location: { lat: number; lng: number } };
      formatted_address?: string;
    }>;
  };
  if (data.status === 'OK' && Array.isArray(data.results) && data.results.length > 0) {
    return data.results.map((r) => ({
      latitude: r.geometry.location.lat,
      longitude: r.geometry.location.lng,
      formattedAddress: r.formatted_address || '',
    }));
  }
  const fallbackRes = await fetch(base);
  const fallbackData = (await fallbackRes.json()) as {
    status: string;
    results?: Array<{
      geometry: { location: { lat: number; lng: number } };
      formatted_address?: string;
    }>;
  };
  if (fallbackData.status !== 'OK' || !Array.isArray(fallbackData.results) || fallbackData.results.length === 0) {
    return [];
  }
  return fallbackData.results.map((r) => ({
    latitude: r.geometry.location.lat,
    longitude: r.geometry.location.lng,
    formattedAddress: r.formatted_address || '',
  }));
}
