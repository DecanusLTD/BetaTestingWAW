export interface StripePaymentMethod {
  id: string;
  type: 'card' | 'apple_pay' | 'google_pay';
  card?: {
    brand: string;
    last4: string;
    expMonth: number;
    expYear: number;
  };
  billingDetails?: {
    name: string;
    email: string;
    address: {
      line1: string;
      line2?: string;
      city: string;
      postalCode: string;
      country: string;
    };
  };
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'requires_payment_method' | 'requires_confirmation' | 'requires_action' | 'processing' | 'requires_capture' | 'canceled' | 'succeeded';
  clientSecret: string;
  paymentMethodId?: string;
  created: number;
}

export interface Refund {
  id: string;
  amount: number;
  currency: string;
  status: 'succeeded' | 'pending' | 'failed';
  reason?: 'duplicate' | 'fraudulent' | 'requested_by_customer';
  created: number;
}

export class StripePaymentService {
  private static instance: StripePaymentService;
  private apiKey: string = 'pk_test_...'; // Replace with your Stripe publishable key
  private secretKey: string = 'sk_test_...'; // Replace with your Stripe secret key

  static getInstance(): StripePaymentService {
    if (!StripePaymentService.instance) {
      StripePaymentService.instance = new StripePaymentService();
    }
    return StripePaymentService.instance;
  }

  // Create a payment intent (server-side)
  async createPaymentIntent(amount: number, currency: string = 'gbp', metadata?: any): Promise<PaymentIntent> {
    try {
      // In a real app, this would be a server API call
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.secretKey}`
        },
        body: JSON.stringify({
          amount: Math.round(amount * 100), // Convert to pence
          currency,
          metadata
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error creating payment intent:', error);
      throw new Error('Failed to create payment intent');
    }
  }

  // Confirm payment intent
  async confirmPayment(clientSecret: string, paymentMethodId: string): Promise<PaymentIntent> {
    try {
      const response = await fetch('/api/confirm-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.secretKey}`
        },
        body: JSON.stringify({
          clientSecret,
          paymentMethodId
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error confirming payment:', error);
      throw new Error('Failed to confirm payment');
    }
  }

  // Create refund
  async createRefund(paymentIntentId: string, amount?: number, reason?: string): Promise<Refund> {
    try {
      const response = await fetch('/api/create-refund', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.secretKey}`
        },
        body: JSON.stringify({
          paymentIntentId,
          amount: amount ? Math.round(amount * 100) : undefined,
          reason
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error creating refund:', error);
      throw new Error('Failed to create refund');
    }
  }

  // Save payment method for future use
  async savePaymentMethod(paymentMethodId: string, customerId: string): Promise<StripePaymentMethod> {
    try {
      const response = await fetch('/api/save-payment-method', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.secretKey}`
        },
        body: JSON.stringify({
          paymentMethodId,
          customerId
        })
      });

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error saving payment method:', error);
      throw new Error('Failed to save payment method');
    }
  }

  // Get saved payment methods
  async getPaymentMethods(customerId: string): Promise<StripePaymentMethod[]> {
    try {
      const response = await fetch(`/api/payment-methods/${customerId}`, {
        headers: {
          'Authorization': `Bearer ${this.secretKey}`
        }
      });

      const data = await response.json();
      return data.paymentMethods;
    } catch (error) {
      console.error('Error getting payment methods:', error);
      throw new Error('Failed to get payment methods');
    }
  }

  // Delete payment method
  async deletePaymentMethod(paymentMethodId: string): Promise<boolean> {
    try {
      const response = await fetch(`/api/payment-methods/${paymentMethodId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${this.secretKey}`
        }
      });

      return response.ok;
    } catch (error) {
      console.error('Error deleting payment method:', error);
      throw new Error('Failed to delete payment method');
    }
  }

  // Validate card details
  validateCard(cardNumber: string, expMonth: number, expYear: number, cvc: string): {
    valid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    // Basic validation
    if (!cardNumber || cardNumber.length < 13 || cardNumber.length > 19) {
      errors.push('Invalid card number');
    }

    if (!expMonth || expMonth < 1 || expMonth > 12) {
      errors.push('Invalid expiry month');
    }

    if (!expYear || expYear < new Date().getFullYear()) {
      errors.push('Card has expired');
    }

    if (!cvc || cvc.length < 3 || cvc.length > 4) {
      errors.push('Invalid CVC');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  // Get card brand from number
  getCardBrand(cardNumber: string): string {
    const cleanNumber = cardNumber.replace(/\s/g, '');
    
    if (/^4/.test(cleanNumber)) return 'visa';
    if (/^5[1-5]/.test(cleanNumber)) return 'mastercard';
    if (/^3[47]/.test(cleanNumber)) return 'amex';
    if (/^6/.test(cleanNumber)) return 'discover';
    if (/^(5018|5020|5038|6304|6759|6761|6763)/.test(cleanNumber)) return 'maestro';
    
    return 'unknown';
  }

  // Format card number for display
  formatCardNumber(cardNumber: string): string {
    const cleanNumber = cardNumber.replace(/\s/g, '');
    const brand = this.getCardBrand(cleanNumber);
    
    if (brand === 'amex') {
      return cleanNumber.replace(/(\d{4})(\d{6})(\d{5})/, '$1 $2 $3');
    } else {
      return cleanNumber.replace(/(\d{4})(?=\d)/g, '$1 ');
    }
  }

  // Mask card number for security
  maskCardNumber(cardNumber: string): string {
    const cleanNumber = cardNumber.replace(/\s/g, '');
    const last4 = cleanNumber.slice(-4);
    const brand = this.getCardBrand(cleanNumber);
    
    if (brand === 'amex') {
      return `**** **** **** ${last4}`;
    } else {
      return `**** **** **** ${last4}`;
    }
  }

  // Calculate processing fees (UK rates)
  calculateFees(amount: number): {
    stripeFee: number;
    platformFee: number;
    totalFee: number;
  } {
    const stripeFee = amount * 0.014 + 0.20; // 1.4% + 20p for UK cards
    const platformFee = amount * 0.05; // 5% platform fee
    const totalFee = stripeFee + platformFee;

    return {
      stripeFee: Math.round(stripeFee * 100) / 100,
      platformFee: Math.round(platformFee * 100) / 100,
      totalFee: Math.round(totalFee * 100) / 100
    };
  }

  // Get supported payment methods for UK
  getSupportedPaymentMethods(): string[] {
    return [
      'card',
      'apple_pay',
      'google_pay',
      'paypal' // If you want to add PayPal
    ];
  }

  // Check if payment method is supported in UK
  isPaymentMethodSupported(method: string): boolean {
    const supported = this.getSupportedPaymentMethods();
    return supported.includes(method);
  }
}

export const stripePaymentService = StripePaymentService.getInstance();
