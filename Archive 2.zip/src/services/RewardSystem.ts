export interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  type: 'discount' | 'free_service' | 'bonus' | 'physical_item';
  available: boolean;
  image?: string;
}

export interface UserRewards {
  userId: string;
  points: number;
  level: 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond';
  totalPoints: number;
  pointsToNextLevel: number;
  nextLevel: string;
  rewards: Reward[];
  recentEarnings: {
    id: string;
    amount: number;
    reason: string;
    date: string;
  }[];
}

export class RewardSystem {
  private static instance: RewardSystem;
  private userRewards: Map<string, UserRewards> = new Map();

  static getInstance(): RewardSystem {
    if (!RewardSystem.instance) {
      RewardSystem.instance = new RewardSystem();
    }
    return RewardSystem.instance;
  }

  // Customer Rewards
  private customerRewards: Reward[] = [
    { id: '1', title: '10% Off Next Wash', description: 'Save on your next service', points: 100, type: 'discount', available: true },
    { id: '2', title: 'Free Interior Clean', description: 'Complimentary interior service', points: 200, type: 'free_service', available: true },
    { id: '3', title: 'Priority Booking', description: 'Skip the queue for 24 hours', points: 150, type: 'bonus', available: true },
    { id: '4', title: 'Free Wax & Polish', description: 'Premium exterior treatment', points: 300, type: 'free_service', available: true },
    { id: '5', title: 'Monthly Subscription Discount', description: '20% off monthly plans', points: 500, type: 'discount', available: true },
  ];

  // Valeter Rewards
  private valeterRewards: Reward[] = [
    { id: '1', title: 'Premium Shampoo Kit', description: 'Professional cleaning supplies', points: 400, type: 'physical_item', available: true },
    { id: '2', title: 'Microfiber Towels Set', description: 'High-quality cleaning towels', points: 300, type: 'physical_item', available: true },
    { id: '3', title: 'Wax & Polish Kit', description: 'Professional detailing supplies', points: 600, type: 'physical_item', available: true },
    { id: '4', title: 'Professional Vacuum', description: 'Industrial-grade equipment', points: 800, type: 'physical_item', available: true },
    { id: '5', title: 'Steam Cleaner', description: 'Advanced cleaning equipment', points: 1200, type: 'physical_item', available: false },
    { id: '6', title: 'Commission Bonus', description: '5% extra on next 10 jobs', points: 500, type: 'bonus', available: true },
  ];

  getUserRewards(userId: string, userType: 'customer' | 'valeter'): UserRewards {
    if (!this.userRewards.has(userId)) {
      const initialPoints = userType === 'valeter' ? 850 : 150;
      const level = this.calculateLevel(initialPoints);
      const nextLevel = this.getNextLevel(level);
      const pointsToNext = this.getPointsToNextLevel(initialPoints, level);

      this.userRewards.set(userId, {
        userId,
        points: initialPoints,
        level,
        totalPoints: initialPoints,
        pointsToNextLevel: pointsToNext,
        nextLevel,
        rewards: userType === 'valeter' ? this.valeterRewards : this.customerRewards,
        recentEarnings: []
      });
    }

    return this.userRewards.get(userId)!;
  }

  addPoints(userId: string, points: number, reason: string): void {
    const userRewards = this.userRewards.get(userId);
    if (!userRewards) return;

    const oldLevel = userRewards.level;
    userRewards.points += points;
    userRewards.totalPoints += points;
    userRewards.level = this.calculateLevel(userRewards.points);
    userRewards.pointsToNextLevel = this.getPointsToNextLevel(userRewards.points, userRewards.level);
    userRewards.nextLevel = this.getNextLevel(userRewards.level);

    // Add to recent earnings
    userRewards.recentEarnings.unshift({
      id: Date.now().toString(),
      amount: points,
      reason,
      date: 'Just now'
    });

    // Keep only last 10 earnings
    userRewards.recentEarnings = userRewards.recentEarnings.slice(0, 10);

    // Level up notification
    if (userRewards.level !== oldLevel) {
      // Level up occurred
    }
  }

  redeemReward(userId: string, rewardId: string): boolean {
    const userRewards = this.userRewards.get(userId);
    if (!userRewards) return false;

    const reward = userRewards.rewards.find(r => r.id === rewardId);
    if (!reward || !reward.available || userRewards.points < reward.points) {
      return false;
    }

    userRewards.points -= reward.points;
    return true;
  }

  private calculateLevel(points: number): UserRewards['level'] {
    if (points >= 2000) return 'Diamond';
    if (points >= 1000) return 'Platinum';
    if (points >= 500) return 'Gold';
    if (points >= 200) return 'Silver';
    return 'Bronze';
  }

  private getNextLevel(currentLevel: UserRewards['level']): string {
    switch (currentLevel) {
      case 'Bronze': return 'Silver';
      case 'Silver': return 'Gold';
      case 'Gold': return 'Platinum';
      case 'Platinum': return 'Diamond';
      default: return 'Diamond';
    }
  }

  private getPointsToNextLevel(points: number, currentLevel: UserRewards['level']): number {
    switch (currentLevel) {
      case 'Bronze': return Math.max(0, 200 - points);
      case 'Silver': return Math.max(0, 500 - points);
      case 'Gold': return Math.max(0, 1000 - points);
      case 'Platinum': return Math.max(0, 2000 - points);
      default: return 0;
    }
  }

  // Customer-specific rewards
  getCustomerBonuses(): { title: string; description: string; points: number }[] {
    return [
      { title: 'First Booking', description: 'Welcome bonus for new customers', points: 50 },
      { title: '5-Star Rating', description: 'Rate your valeter experience', points: 25 },
      { title: 'Refer a Friend', description: 'Both get £10 credit', points: 100 },
      { title: 'Weekly Booking', description: 'Regular customer bonus', points: 30 },
      { title: 'Feedback Submission', description: 'Help us improve', points: 15 },
    ];
  }

  // Valeter-specific rewards
  getValeterBonuses(): { title: string; description: string; points: number }[] {
    return [
      { title: 'Job Completion', description: 'Complete a service successfully', points: 25 },
      { title: '5-Star Rating', description: 'Receive excellent customer rating', points: 50 },
      { title: 'On-Time Arrival', description: 'Arrive within 5 minutes', points: 20 },
      { title: 'Weekly Performance', description: 'Complete 10+ jobs this week', points: 100 },
      { title: 'Customer Referral', description: 'Customer refers a friend', points: 75 },
      { title: 'Perfect Week', description: 'All 5-star ratings this week', points: 200 },
    ];
  }
}

export const rewardSystem = RewardSystem.getInstance();
