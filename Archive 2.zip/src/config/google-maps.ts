// Google Maps API Configuration (Places, Geocoding, Maps)
// Prefer EXPO_PUBLIC_GOOGLE_MAPS_API_KEY in .env for production.

export const GOOGLE_MAPS_API_KEY =
  (typeof process !== 'undefined' && process.env?.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY) ||
  '';

export const MAPS_CONFIG = {
  apiKey: GOOGLE_MAPS_API_KEY,
  defaultCenter: {
    lat: 51.5074, // London coordinates
    lng: -0.1278
  },
  defaultZoom: 15,
  mapStyles: [
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }]
    }
  ]
};
