/**
 * Service ID Mapper
 * 
 * Maps mobile wash and mobile repair service IDs from serviceOptions.ts to WASH_DEFINITIONS IDs
 * (vehicle size, distance, surge — same pipeline for both).
 */

import { WASH_DEFINITIONS, WashDefinition } from './pricingEngine';

/**
 * Mapping from existing service IDs to WASH_DEFINITIONS IDs
 */
const SERVICE_ID_MAPPING: Record<string, string> = {
  'bronze-wash': 'MOBILE_BRONZE',
  'silver-wash': 'MOBILE_SILVER',
  'gold-wash': 'MOBILE_GOLD',
  'platinum-wash': 'MOBILE_PLATINUM',
  'emerald-wash': 'MOBILE_DIAMOND',
  'eco-bronze-wash': 'MOBILE_BRONZE',
  'eco-silver-wash': 'MOBILE_SILVER',
  'eco-gold-wash': 'MOBILE_GOLD',
  'eco-platinum-wash': 'MOBILE_PLATINUM',
  'eco-emerald-wash': 'MOBILE_DIAMOND',
  'headlight-restoration': 'MOBILE_REPAIR_HEADLIGHT',
  'scratch-removal': 'MOBILE_REPAIR_SCRATCH',
  'paint-chip-repair': 'MOBILE_REPAIR_PAINT_CHIP',
  'trim-restoration': 'MOBILE_REPAIR_TRIM',
  'leather-repair': 'MOBILE_REPAIR_LEATHER',
};

/**
 * Get wash/repair pricing definition from service ID
 * Returns null if service ID is not dynamically priced on mobile
 */
export function getWashDefinitionFromServiceId(serviceId: string): WashDefinition | null {
  const washId = SERVICE_ID_MAPPING[serviceId];
  if (!washId) {
    return null;
  }

  const washDefinition = WASH_DEFINITIONS.find(w => w.id === washId);
  return washDefinition || null;
}

/**
 * Check if a service ID uses the mobile dynamic pricing engine (wash or repair)
 */
export function isMobileWashService(serviceId: string): boolean {
  return serviceId in SERVICE_ID_MAPPING;
}

/**
 * Get all mapped service IDs
 */
export function getMappedServiceIds(): string[] {
  return Object.keys(SERVICE_ID_MAPPING);
}


