/**
 * Service ID Mapper
 * 
 * Maps existing service IDs from serviceOptions.ts to new WASH_DEFINITIONS IDs
 * This ensures backward compatibility with existing booking flows
 */

import { WASH_DEFINITIONS, WashDefinition } from './pricingEngine';

/**
 * Mapping from existing service IDs to WASH_DEFINITIONS IDs
 */
const SERVICE_ID_MAPPING: Record<string, string> = {
  'bronze-wash': 'MOBILE_BRONZE',
  'silver-wash': 'MOBILE_SILVER',
  'gold-wash': 'MOBILE_GOLD',
  'platinum-wash': 'MOBILE_PLATINUM',
  'eco-bronze-wash': 'MOBILE_ECO_BRONZE',
  'eco-silver-wash': 'MOBILE_ECO_SILVER',
  'eco-gold-wash': 'MOBILE_ECO_GOLD',
  'eco-platinum-wash': 'MOBILE_ECO_PLATINUM',
};

/**
 * Get wash definition from existing service ID
 * Returns null if service ID is not found or not a mobile wash
 */
export function getWashDefinitionFromServiceId(serviceId: string): WashDefinition | null {
  const washId = SERVICE_ID_MAPPING[serviceId];
  if (!washId) {
    return null;
  }

  const washDefinition = WASH_DEFINITIONS.find(w => w.id === washId);
  return washDefinition || null;
}

/**
 * Check if a service ID is a mobile wash service
 */
export function isMobileWashService(serviceId: string): boolean {
  return serviceId in SERVICE_ID_MAPPING;
}

/**
 * Get all mapped service IDs
 */
export function getMappedServiceIds(): string[] {
  return Object.keys(SERVICE_ID_MAPPING);
}


