import React from 'react';
import { StyleSheet } from 'react-native';
import Animated, { type SharedValue, useAnimatedStyle } from 'react-native-reanimated';
import { colors } from '../../constants/colors';

type SplashRippleProps = {
  scale: SharedValue<number>;
  opacity: SharedValue<number>;
};

export default function SplashRipple({ scale, opacity }: Readonly<SplashRippleProps>) {
  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }));

  return <Animated.View pointerEvents="none" style={[styles.ripple, animatedStyle]} />;
}

const styles = StyleSheet.create({
  ripple: {
    position: 'absolute',
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.9)',
  },
});
