import React, { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { useThemeOptional } from '../../contexts/ThemeContext';
import { colors } from '../../constants/colors';
import { APP_LOGO_SOURCE, preloadBootAssets } from '../../constants/appAssets';
import AnimatedSplash from './AnimatedSplash';

const MIN_SPLASH_MS = 900;
const MAX_SPLASH_MS = 2200;

type AppLaunchGateProps = {
  children: React.ReactNode;
  startupReady: boolean;
  onBootStateChange?: (isBooting: boolean) => void;
};

export default function AppLaunchGate({
  children,
  startupReady,
  onBootStateChange,
}: Readonly<AppLaunchGateProps>) {
  const themeContext = useThemeOptional();
  const [assetsReady, setAssetsReady] = useState(false);
  const [rootLaidOut, setRootLaidOut] = useState(false);
  const [showAnimatedSplash, setShowAnimatedSplash] = useState(true);
  const [canFinish, setCanFinish] = useState(false);
  const startedAtRef = useRef(Date.now());
  const nativeHiddenRef = useRef(false);

  useEffect(() => {
    let active = true;
    preloadBootAssets()
      .catch(() => {})
      .finally(() => {
        if (active) setAssetsReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    onBootStateChange?.(showAnimatedSplash || !startupReady);
  }, [onBootStateChange, showAnimatedSplash, startupReady]);

  const maybeHideNativeSplash = useCallback(async () => {
    if (nativeHiddenRef.current) return;
    if (!assetsReady || !rootLaidOut) return;
    nativeHiddenRef.current = true;
    await SplashScreen.hideAsync().catch(() => {});
  }, [assetsReady, rootLaidOut]);

  useEffect(() => {
    void maybeHideNativeSplash();
  }, [maybeHideNativeSplash]);

  useEffect(() => {
    const elapsed = Date.now() - startedAtRef.current;
    const minDelay = Math.max(0, MIN_SPLASH_MS - elapsed);
    const maxDelay = Math.max(0, MAX_SPLASH_MS - elapsed);
    const minTimer = setTimeout(() => {
      if (startupReady) setCanFinish(true);
    }, minDelay);
    const maxTimer = setTimeout(() => {
      setCanFinish(true);
    }, maxDelay);
    return () => {
      clearTimeout(minTimer);
      clearTimeout(maxTimer);
    };
  }, [startupReady]);

  return (
    <View
      style={styles.root}
      onLayout={() => {
        setRootLaidOut(true);
      }}
    >
      {children}
      {showAnimatedSplash ? (
        <AnimatedSplash
          startupReady={canFinish}
          onFinish={() => setShowAnimatedSplash(false)}
          logoSource={APP_LOGO_SOURCE}
          backgroundColors={
            themeContext?.theme.backgroundGradient ?? [colors.bgPrimary, colors.bgSecondary]
          }
        />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
});
