import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { aiChatService, ChatMessage, QuickReply } from '../../services/AIChatService';
import { useAuth } from '../../providers/enhanced-auth-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';

interface AIChatComponentProps {
  userType: 'customer' | 'valeter';
  onClose?: () => void;
}

export default function AIChatComponent({ userType, onClose }: AIChatComponentProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Fade in animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();

    // Load conversation history
    if (user?.id) {
      const history = aiChatService.getConversationHistory(user.id);
      setMessages(history);
      
      // Send welcome message if no history
      if (history.length === 0) {
        sendWelcomeMessage();
      }
    }
  }, []);

  const sendWelcomeMessage = async () => {
    if (!user?.id) return;
    
    const welcomeMessage = `Hello! I'm your Wish a Wash AI assistant. I can help you with:\n\n${
      userType === 'customer' 
        ? '• Booking services\n• Checking prices\n• Tracking your valeter\n• Cancellation policies'
        : '• Job opportunities\n• Earnings information\n• Requirements\n• Rating system'
    }\n\nHow can I help you today?`;

    const welcomeMsg: ChatMessage = {
      id: Date.now().toString(),
      text: welcomeMessage,
      sender: 'ai',
      timestamp: new Date(),
      type: 'text'
    };

    setMessages([welcomeMsg]);
    aiChatService.addMessageToHistory(user.id, welcomeMsg);
  };

  const sendMessage = async (text: string) => {
    if (!text.trim() || !user?.id || isLoading) return;

    setIsLoading(true);
    setInputText('');

    try {
      const updatedMessages = await aiChatService.sendMessage(user.id, text, userType);
      setMessages(updatedMessages);
      hapticFeedback('light');
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickReply = (quickReply: QuickReply) => {
    sendMessage(quickReply.text);
  };

  const handleSend = () => {
    if (inputText.trim()) {
      sendMessage(inputText.trim());
    }
  };

  const clearChat = () => {
    if (user?.id) {
      aiChatService.clearConversation(user.id);
      setMessages([]);
      sendWelcomeMessage();
    }
  };

  const quickReplies = aiChatService.getQuickReplies(userType);

  const renderMessage = (message: ChatMessage) => {
    const isUser = message.sender === 'user';
    
    return (
      <View key={message.id} style={[
        styles.messageContainer,
        isUser ? styles.userMessageContainer : styles.aiMessageContainer
      ]}>
        <LinearGradient
          colors={isUser ? ['#87CEEB', '#0EA5E9'] : ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.05)']}
          style={[styles.messageBubble, isUser ? styles.userMessageBubble : styles.aiMessageBubble]}
        >
          <Text style={[styles.messageText, isUser ? styles.userMessageText : styles.aiMessageText]}>
            {message.text}
          </Text>
          <Text style={[styles.timestamp, isUser ? styles.userTimestamp : styles.aiTimestamp]}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </LinearGradient>
      </View>
    );
  };

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={styles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={styles.aiAvatar}>
              <Ionicons name="sparkles" size={24} color="#10B981" />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Wish a Wash AI</Text>
              <Text style={styles.headerSubtitle}>
                {isLoading ? 'Typing...' : 'Online'}
              </Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerButton} onPress={clearChat}>
              <Ionicons name="trash" size={20} color="#FFFFFF" />
            </TouchableOpacity>
            {onClose && (
              <TouchableOpacity style={styles.headerButton} onPress={onClose}>
                <Ionicons name="close" size={20} color="#FFFFFF" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Messages */}
        <ScrollView
          ref={scrollViewRef}
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
        >
          {messages.map(renderMessage)}
          {isLoading && (
            <View style={styles.loadingContainer}>
              <Text style={styles.loadingText}>AI is typing...</Text>
            </View>
          )}
        </ScrollView>

        {/* Quick Replies */}
        {messages.length > 0 && (
          <ScrollView
            horizontal
            style={styles.quickRepliesContainer}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickRepliesContent}
          >
            {quickReplies.map((reply) => (
              <TouchableOpacity
                key={reply.id}
                style={styles.quickReplyButton}
                onPress={() => handleQuickReply(reply)}
              >
                <Text style={styles.quickReplyText}>{reply.text}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {/* Input */}
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.inputContainer}
        >
          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.textInput}
              placeholder="Type your message..."
              placeholderTextColor="#87CEEB"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable={!isLoading}
            />
            <TouchableOpacity
              style={[styles.sendButton, !inputText.trim() && styles.sendButtonDisabled]}
              onPress={handleSend}
              disabled={!inputText.trim() || isLoading}
            >
              <Ionicons name="send" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </LinearGradient>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  aiAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  aiAvatarText: {
    fontSize: 20,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#87CEEB',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    paddingBottom: 8,
  },
  messageContainer: {
    marginBottom: 12,
  },
  userMessageContainer: {
    alignItems: 'flex-end',
  },
  aiMessageContainer: {
    alignItems: 'flex-start',
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  userMessageBubble: {
    borderBottomRightRadius: 4,
  },
  aiMessageBubble: {
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  userMessageText: {
    color: '#FFFFFF',
  },
  aiMessageText: {
    color: '#F9FAFB',
  },
  timestamp: {
    fontSize: 10,
    marginTop: 4,
    opacity: 0.7,
  },
  userTimestamp: {
    color: '#FFFFFF',
    textAlign: 'right',
  },
  aiTimestamp: {
    color: '#87CEEB',
  },
  loadingContainer: {
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  loadingText: {
    fontSize: 12,
    color: '#87CEEB',
    fontStyle: 'italic',
  },
  quickRepliesContainer: {
    maxHeight: 60,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  quickRepliesContent: {
    gap: 8,
  },
  quickReplyButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  quickReplyText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  inputContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textInput: {
    flex: 1,
    fontSize: 14,
    color: '#FFFFFF',
    maxHeight: 100,
    paddingVertical: 8,
  },
  sendButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  sendButtonDisabled: {
    backgroundColor: 'rgba(135, 206, 235, 0.3)',
  },
  sendButtonText: {
    fontSize: 16,
  },
});

