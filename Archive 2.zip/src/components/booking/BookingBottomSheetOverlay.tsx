import React from 'react';
import {
  View,
  StyleSheet,
  Modal,
  Pressable,
  Dimensions,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET_GLASS,
} from '../../constants/bookingCardTheme';
import BookingSheetPremiumLayers from './BookingSheetPremiumLayers';
import { WWSheetCloseButton } from '../ui';

type BookingBottomSheetOverlayProps = {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  /** Max height as a fraction of window height (default 0.92). */
  maxHeightRatio?: number;
  /** Optional style for the sheet container (above safe area padding). */
  sheetStyle?: StyleProp<ViewStyle>;
};

/**
 * Premium bottom sheet: blur + glass layers, drag handle, close only (no title row).
 */
export default function BookingBottomSheetOverlay({
  visible,
  onClose,
  children,
  maxHeightRatio = 0.92,
  sheetStyle,
}: BookingBottomSheetOverlayProps) {
  const insets = useSafeAreaInsets();
  const { height: windowHeight } = Dimensions.get('window');
  const maxHeight = Math.min(windowHeight * maxHeightRatio, windowHeight - insets.top - 8);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.root} pointerEvents="box-none">
        <Pressable style={styles.backdrop} onPress={onClose} accessibilityRole="button" accessibilityLabel="Dismiss" />
        <View style={[styles.sheet, { maxHeight, paddingBottom: Math.max(insets.bottom, 12) }, sheetStyle]}>
          <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
          <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} style={StyleSheet.absoluteFill} />
          <LinearGradient
            colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.03)', 'transparent']}
            locations={[0, 0.25, 0.55]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0.45 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <BookingSheetPremiumLayers />
          <View style={styles.handle} />
          <View style={styles.closeRow}>
            <View style={styles.closeRowSpacer} />
            <WWSheetCloseButton onPress={onClose} iconSize={24} accessibilityLabel="Close" />
          </View>
          <View style={styles.body}>{children}</View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(2,6,23,0.55)',
  },
  sheet: {
    width: '100%',
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    overflow: 'hidden',
    ...PREMIUM_BOOKING_MAP_SHEET_GLASS,
  },
  handle: {
    alignSelf: 'center',
    width: 42,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.55)',
    marginTop: 4,
    marginBottom: 4,
  },
  closeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingBottom: 4,
  },
  closeRowSpacer: {
    flex: 1,
  },
  body: {
    flexGrow: 1,
    flexShrink: 1,
    minHeight: 0,
    paddingHorizontal: 16,
    paddingTop: 4,
    flexDirection: 'column',
  },
});
