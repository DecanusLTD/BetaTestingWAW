import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';
import { useThemeOptional } from '../../contexts/ThemeContext';

const SKY_BLUE_BORDER = 'rgba(91, 143, 168, 0.45)';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  borderRadius?: number;
  accountType?: AccountType;
  /**
   * When true (default): no hairline rim, inner highlight, or elevation shadow — matches flat booking tiles.
   * Set false only if you need the legacy glass stroke (e.g. a specific marketing surface).
   */
  rimless?: boolean;
}

export default function GlassCard({
  children,
  onPress,
  style,
  intensity = 48,
  tint = 'dark',
  borderColor,
  borderRadius = 18,
  accountType,
  rimless = true,
}: GlassCardProps) {
  const themeOpt = useThemeOptional();
  const themeMode = themeOpt?.colorScheme === 'dark' ? 'dark' : 'light';
  const accountBorder = accountType ? getAccountTheme(accountType, themeMode).glassBorder : null;
  const finalBorderColor = borderColor || accountBorder || SKY_BLUE_BORDER;

  const content = (
    <BlurView
      intensity={intensity}
      tint={tint}
      style={[styles.blurContainer, !rimless && styles.blurWithRim, rimless && styles.blurRimless, style, { borderRadius }]}
    >
      <LinearGradient
        colors={[colors.surfaceOverlayMid, colors.surfaceOverlay, 'rgba(255,255,255,0.02)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      {!rimless ? (
        <>
          <View style={[styles.border, { borderColor: finalBorderColor, borderRadius }]} />
          <View style={[styles.innerHighlight, { borderRadius }]} />
        </>
      ) : null}
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    overflow: 'hidden',
    opacity: 0.94,
  },
  blurWithRim: {
    borderWidth: 1,
    borderColor: 'transparent',
    elevation: 8,
    shadowColor: 'rgba(91, 143, 168, 0.3)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 10,
  },
  blurRimless: {
    borderWidth: 0,
    borderColor: 'transparent',
    elevation: 0,
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
  },
  innerHighlight: {
    ...StyleSheet.absoluteFillObject,
    borderTopWidth: 1,
    borderTopColor: colors.surfaceOverlayStrong,
    pointerEvents: 'none',
  },
});

