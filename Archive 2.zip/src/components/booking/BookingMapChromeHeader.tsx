import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import BookingMapGlassBackground from './BookingMapGlassBackground';
import { colors } from '../../constants/colors';
import { useMapChromeColors } from '../../hooks/useMapChromeColors';

type IoniconName = React.ComponentProps<typeof Ionicons>['name'];

export function BookingMapChromeIconButton({
  onPress,
  icon,
  iconSize = 20,
  accessibilityLabel,
  style,
  disabled,
}: {
  onPress?: () => void;
  icon: IoniconName;
  iconSize?: number;
  accessibilityLabel: string;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}) {
  const chrome = useMapChromeColors();

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.iconBtn,
        {
          borderColor: chrome.border,
          shadowColor: chrome.shadow,
        },
        style,
      ]}
      activeOpacity={0.82}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
    >
      <Ionicons name={icon} size={iconSize} color={chrome.icon} />
    </TouchableOpacity>
  );
}

export type BookingMapChromeHeaderProps = {
  topInset: number;
  title?: string;
  subtitle?: string;
  titleIcon?: IoniconName;
  showBack?: boolean;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  centerContent?: React.ReactNode;
  rightAction?: React.ReactNode;
  points?: number;
  style?: StyleProp<ViewStyle>;
};

export default function BookingMapChromeHeader({
  topInset,
  title,
  subtitle,
  titleIcon,
  showBack = true,
  onBack,
  leftAction,
  centerContent,
  rightAction,
  points,
  style,
}: BookingMapChromeHeaderProps) {
  const chrome = useMapChromeColors();
  const chromePillStyle = {
    borderColor: chrome.border,
    shadowColor: chrome.shadow,
  };

  const hasTitle = Boolean(title && title.trim().length > 0);
  const showTitlePill = centerContent == null && hasTitle;
  const embedLeadingInTitlePill = leftAction != null && showTitlePill;

  return (
    <View style={[styles.fullHeader, { borderBottomColor: chrome.border }, style]}>
      <BookingMapGlassBackground />
      <View style={[styles.content, { paddingTop: topInset + 8 }]}>
        {!embedLeadingInTitlePill && leftAction != null ? (
          leftAction
        ) : !embedLeadingInTitlePill && showBack ? (
          <BookingMapChromeIconButton
            icon="chevron-back"
            accessibilityLabel="Back"
            onPress={onBack}
          />
        ) : !embedLeadingInTitlePill ? (
          <View style={styles.sideSpacer} />
        ) : null}

        {centerContent != null ? (
          <View style={styles.centerSlot}>{centerContent}</View>
        ) : showTitlePill ? (
          <View style={[styles.titlePill, subtitle ? styles.titlePillTall : null, chromePillStyle]}>
            <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
            <LinearGradient
              colors={[...chrome.gradient]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <LinearGradient
              colors={['rgba(255,255,255,0.14)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={styles.titlePillSheen}
              pointerEvents="none"
            />
            <View
              style={[
                styles.titlePillInner,
                titleIcon ? styles.titlePillInnerWithIcon : null,
                embedLeadingInTitlePill ? styles.titlePillInnerWithLeading : null,
              ]}
            >
              {embedLeadingInTitlePill ? (
                <View style={styles.titlePillLeading}>{leftAction}</View>
              ) : null}
              {titleIcon ? (
                <Ionicons name={titleIcon} size={18} color={chrome.icon} />
              ) : null}
              <View style={styles.titleTextCol}>
                <Text style={styles.titleText} numberOfLines={1}>
                  {title}
                </Text>
                {subtitle ? (
                  <Text style={styles.subtitleText} numberOfLines={1}>
                    {subtitle}
                  </Text>
                ) : null}
              </View>
              {points !== undefined ? (
                <View style={styles.pointsBadge}>
                  <Ionicons name="trophy-outline" size={12} color="#FBBF24" />
                  <Text style={styles.pointsText}>{points.toLocaleString()}</Text>
                  <Text style={styles.pointsSuffix}>pts</Text>
                </View>
              ) : null}
            </View>
          </View>
        ) : (
          <View style={styles.centerSlot} />
        )}

        {rightAction != null ? (
          <View style={styles.rightSlot}>{rightAction}</View>
        ) : (
          <View style={styles.sideSpacer} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  fullHeader: {
    overflow: 'hidden',
    borderBottomWidth: 1,
    backgroundColor: colors.BG ?? '#0A1929',
    zIndex: 920,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingBottom: 8,
    zIndex: 1,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  sideSpacer: {
    width: 40,
    height: 40,
  },
  centerSlot: {
    flex: 1,
    minWidth: 0,
  },
  rightSlot: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
  },
  titlePill: {
    flex: 1,
    minHeight: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    backgroundColor: 'rgba(8,20,38,0.55)',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  titlePillTall: {
    minHeight: 48,
    borderRadius: 22,
  },
  titlePillSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.85,
  },
  titlePillInner: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    zIndex: 1,
    gap: 8,
  },
  titlePillInnerWithIcon: {
    gap: 8,
  },
  titlePillInnerWithLeading: {
    paddingLeft: 6,
    gap: 8,
  },
  titlePillLeading: {
    flexShrink: 0,
  },
  titleTextCol: {
    flex: 1,
    minWidth: 0,
    gap: 1,
  },
  titleText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  subtitleText: {
    color: 'rgba(226,232,240,0.78)',
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.05,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    flexShrink: 0,
    paddingLeft: 8,
    borderLeftWidth: StyleSheet.hairlineWidth,
    borderLeftColor: 'rgba(255,255,255,0.14)',
  },
  pointsText: {
    color: '#FBBF24',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  pointsSuffix: {
    color: 'rgba(251,191,36,0.75)',
    fontSize: 10,
    fontWeight: '700',
    marginTop: 1,
  },
});
