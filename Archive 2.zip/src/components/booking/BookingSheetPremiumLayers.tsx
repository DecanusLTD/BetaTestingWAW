import React from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

/**
 * Extra glass layers for booking bottom sheets — specular + bottom vignette.
 * Place above blur/business background, below sheet content. Does not replace existing BlurView/gradients.
 */
export default function BookingSheetPremiumLayers() {
  return (
    <>
      <LinearGradient
        colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.02)', 'transparent']}
        locations={[0, 0.22, 0.55]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.4 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <LinearGradient
        colors={['transparent', 'rgba(2,6,23,0.5)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
    </>
  );
}
