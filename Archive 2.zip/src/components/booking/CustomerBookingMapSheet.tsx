/**
 * Map booking flows — bottom sheet chrome matching business “Field team” / locations sheets:
 * blur + gradient (BusinessSheetBackground), top radii, handle, kicker + title + subtitle.
 */
import React from 'react';
import { View, Text, StyleSheet, type StyleProp, type ViewStyle } from 'react-native';
import BusinessSheetBackground from '../shared/BusinessSheetBackground';
import {
  CUSTOMER_BOOKING_SHEET_INDEX_LIKE_BORDER,
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
} from '../../constants/bookingCardTheme';

const RADIUS = CUSTOMER_BOOKING_SHEET_TOP_RADIUS;
const PAD_H = 16;

export const CUSTOMER_BOOKING_TEAM_SHEET = {
  RADIUS: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  PAD_H,
  DEFAULT_GLASS: HEADER_STYLE_CARD_BORDER,
} as const;

export type CustomerBookingMapSheetProps = {
  /**
   * absolute — position with `bottom` + `height` (map flows).
   * stretch — fill parent height (wrap in `Animated.View` / fixed-height box for motion).
   */
  layout?: 'absolute' | 'stretch';
  /** Offset from screen bottom — only when layout === 'absolute' */
  bottom?: number;
  /** Total sheet height — only when layout === 'absolute' */
  height?: number;
  /** @deprecated Shell edge uses index-style top hairline only; kept for API compatibility. */
  borderColor?: string;
  primaryColor: string;
  /** Small caps label (e.g. STEP 2) */
  kicker: string;
  title: string;
  subtitle: string;
  kickerColor?: string;
  headerRight?: React.ReactNode;
  children: React.ReactNode;
  /** Outer wrapper styles (use with stretch + Animated.View for opacity / translateY) */
  style?: StyleProp<ViewStyle>;
  /** Body wrapper — use { flex: 1, minHeight: 0 } for nested FlatList */
  bodyStyle?: StyleProp<ViewStyle>;
  /** Renders above the rounded sheet panel (e.g. chat / info row on tracking). */
  topAccessory?: React.ReactNode;
  /** Primary actions (e.g. Continue) — pinned below scroll content inside the sheet. */
  footer?: React.ReactNode;
  /** Tighter header + handle — use when body is dense (quick book, payment). */
  density?: 'default' | 'compact';
};

export default function CustomerBookingMapSheet({
  layout = 'absolute',
  bottom = 0,
  height = 320,
  primaryColor,
  kicker,
  title,
  subtitle,
  kickerColor = 'rgba(125,211,252,0.85)',
  headerRight,
  children,
  style,
  bodyStyle,
  topAccessory,
  footer,
  density = 'default',
}: Readonly<CustomerBookingMapSheetProps>) {
  const compact = density === 'compact';

  const outerBase: ViewStyle =
    layout === 'stretch'
      ? { flex: 1, minHeight: 0, alignSelf: 'stretch' }
      : { position: 'absolute', left: 0, right: 0, bottom, height };

  const areaStyle: StyleProp<ViewStyle> =
    layout === 'stretch'
      ? [styles.bottomArea, { flex: 1, minHeight: 0 }]
      : [styles.bottomArea, { height }];

  return (
    <View style={[outerBase, style]}>
      {topAccessory}
      <View style={areaStyle}>
        <BusinessSheetBackground />
        <View style={styles.shell}>
          <View style={[styles.handle, compact && styles.handleCompact]} />
          <View style={[styles.headRow, compact && styles.headRowCompact]}>
            <View style={styles.headTextCol}>
              <Text style={[styles.kicker, compact && styles.kickerCompact, { color: kickerColor }]}>{kicker}</Text>
              <Text style={[styles.sheetTitle, compact && styles.sheetTitleCompact]} numberOfLines={2}>
                {title}
              </Text>
              <Text style={[styles.sheetSub, compact && styles.sheetSubCompact]} numberOfLines={compact ? 1 : 2}>
                {subtitle}
              </Text>
            </View>
            {headerRight ? <View style={styles.headRight}>{headerRight}</View> : null}
          </View>
          <View style={[styles.body, bodyStyle]}>{children}</View>
          {footer != null ? <View style={styles.footer}>{footer}</View> : null}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bottomArea: {
    borderTopLeftRadius: RADIUS,
    borderTopRightRadius: RADIUS,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.28,
    shadowRadius: 20,
    elevation: 16,
  },
  shell: {
    flex: 1,
    borderTopLeftRadius: RADIUS,
    borderTopRightRadius: RADIUS,
    ...CUSTOMER_BOOKING_SHEET_INDEX_LIKE_BORDER,
    paddingHorizontal: PAD_H,
    paddingTop: 0,
    minHeight: 0,
  },
  handle: {
    alignSelf: 'center',
    width: 44,
    height: 5,
    borderRadius: 3,
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: 'rgba(255,255,255,0.22)',
  },
  handleCompact: {
    marginTop: 6,
    marginBottom: 6,
  },
  headRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
    gap: 10,
  },
  headRowCompact: {
    marginBottom: 6,
  },
  headTextCol: { flex: 1, minWidth: 0 },
  headRight: { flexShrink: 0, marginTop: 2 },
  kicker: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1.1,
  },
  kickerCompact: {
    fontSize: 8,
    letterSpacing: 0.9,
  },
  sheetTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 4,
    letterSpacing: -0.5,
  },
  sheetTitleCompact: {
    fontSize: 17,
    marginTop: 2,
    letterSpacing: -0.35,
  },
  sheetSub: {
    color: 'rgba(249,250,251,0.58)',
    fontSize: 12,
    marginTop: 4,
    fontWeight: '600',
    letterSpacing: 0.15,
    lineHeight: 16,
  },
  sheetSubCompact: {
    fontSize: 11,
    marginTop: 2,
    lineHeight: 14,
  },
  body: {
    flex: 1,
    minHeight: 0,
  },
  footer: {
    flexShrink: 0,
    paddingTop: 12,
    paddingBottom: 4,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(255,255,255,0.14)',
    alignItems: 'stretch',
  },
});
