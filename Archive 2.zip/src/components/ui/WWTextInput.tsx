import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  ViewStyle,
  TextInputProps,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { BORDER_RADIUS, SPACING } from '../../constants/designTokens';

type IconName = keyof typeof Ionicons.glyphMap;

export interface WWTextInputProps extends Omit<TextInputProps, 'style'> {
  leftIcon?: IconName;
  label?: string;
  error?: string;
  containerStyle?: ViewStyle;
  inputStyle?: ViewStyle;
  /** Override placeholder text color */
  placeholderColor?: string;
}

export default function WWTextInput({
  leftIcon,
  label,
  error,
  containerStyle,
  inputStyle,
  placeholderColor = colors.inputPlaceholder,
  placeholderTextColor,
  onFocus,
  onBlur,
  accessibilityLabel: customLabel,
  ...rest
}: WWTextInputProps) {
  const [focused, setFocused] = useState(false);

  const handleFocus = (e: any) => {
    setFocused(true);
    onFocus?.(e);
  };
  const handleBlur = (e: any) => {
    setFocused(false);
    onBlur?.(e);
  };

  const hasError = Boolean(error);
  const borderColor = hasError
    ? colors.inputErrorBorder
    : focused
      ? colors.inputBorderFocused
      : colors.inputBorder;

  const accessibilityLabel = customLabel ?? label ?? rest.placeholder ?? 'Input';

  return (
    <View style={[styles.container, containerStyle]}>
      {label ? (
        <Text style={styles.label}>{label}</Text>
      ) : null}
      <View style={[styles.inputWrapper, { borderColor }]}>
        {leftIcon ? (
          <View style={styles.iconContainer}>
            <Ionicons
              name={leftIcon}
              size={20}
              color={hasError ? colors.inputError : colors.textOnDarkTertiary}
            />
          </View>
        ) : null}
        <TextInput
          placeholderTextColor={placeholderTextColor ?? placeholderColor}
          style={[styles.input, leftIcon && styles.inputWithIcon, inputStyle]}
          onFocus={handleFocus}
          onBlur={handleBlur}
          accessibilityLabel={accessibilityLabel}
          accessibilityState={{ disabled: rest.editable === false }}
          {...rest}
        />
      </View>
      {hasError ? (
        <Text style={styles.errorText} numberOfLines={1}>{error}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: SPACING.md,
  },
  label: {
    color: colors.textOnDarkSecondary,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: SPACING.xs,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderRadius: BORDER_RADIUS.sm,
    borderWidth: 1.5,
  },
  iconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: colors.inputText,
    fontSize: 15,
    paddingVertical: 14,
    paddingRight: SPACING.md,
    paddingLeft: SPACING.sm,
    minHeight: 48,
  },
  inputWithIcon: {
    paddingLeft: 0,
  },
  errorText: {
    color: colors.inputError,
    fontSize: 12,
    marginTop: SPACING.xs,
    marginLeft: 2,
  },
});
