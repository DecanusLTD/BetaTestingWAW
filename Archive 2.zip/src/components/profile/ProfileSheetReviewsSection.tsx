import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

const SKY = colors.SKY ?? '#38BDF8';

export type ProfileSheetReviewItem = {
  id: string;
  rating: number;
  body: string | null;
  author: string;
  completedAt?: string | null;
};

export default function ProfileSheetReviewsSection({
  reviews,
  loading,
}: Readonly<{
  reviews: ProfileSheetReviewItem[];
  loading: boolean;
}>) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionLabel}>Reviews</Text>
      {loading ? (
        <ActivityIndicator color={SKY} style={{ marginVertical: 12 }} />
      ) : reviews.length === 0 ? (
        <View style={styles.emptyCard}>
          <Ionicons name="chatbox-ellipses-outline" size={22} color="rgba(148,163,184,0.75)" />
          <Text style={styles.emptyText}>Reviews from completed bookings will appear here when customers leave them.</Text>
        </View>
      ) : (
        <View style={styles.stack}>
          {reviews.map((r) => (
            <View key={r.id} style={styles.quoteCard}>
              <View style={styles.quoteTop}>
                <Ionicons name="star" size={14} color="#FBBF24" />
                <Text style={styles.quoteRating}>{r.rating.toFixed(1)}</Text>
                <Text style={styles.quoteBy} numberOfLines={1}>
                  {r.author}
                </Text>
              </View>
              {r.body ? (
                <Text style={styles.quoteBody}>{r.body}</Text>
              ) : (
                <Text style={styles.quoteMuted}>Rated without a comment</Text>
              )}
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  emptyCard: {
    borderRadius: 18,
    padding: 16,
    backgroundColor: 'rgba(15,23,42,0.45)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    alignItems: 'center',
    gap: 10,
  },
  emptyText: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    fontWeight: '600',
  },
  stack: { gap: 10 },
  quoteCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.4)',
  },
  quoteTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  quoteRating: { fontSize: 14, fontWeight: '800', color: '#F9FAFB' },
  quoteBy: { fontSize: 13, fontWeight: '600', color: 'rgba(148,163,184,0.95)', flex: 1 },
  quoteBody: { fontSize: 14, lineHeight: 21, color: '#E2E8F0', fontStyle: 'italic' },
  quoteMuted: { fontSize: 13, color: 'rgba(148,163,184,0.85)', fontStyle: 'italic' },
});
