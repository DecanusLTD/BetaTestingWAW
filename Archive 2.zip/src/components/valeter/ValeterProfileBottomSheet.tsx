/**
 * Valeter profile — bottom sheet (Explore + /owner/valeter-details).
 * Loads profile/stats/reviews when possible; polished placeholders if columns are missing.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  useWindowDimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../lib/supabase';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { colors } from '../../constants/colors';
import {
  CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
  HEADER_STYLE_CARD_BORDER,
  HEADER_STYLE_CARD_GRADIENT,
  BOOKING_SHEET_DARK_OVERLAY,
  getIndexTrackingCardWidth,
} from '../../constants/bookingCardTheme';
import { WorkGalleryPlaceholderRow } from '../profile/WorkGalleryPlaceholderRow';
import ProfileSheetReviewsSection, { type ProfileSheetReviewItem } from '../profile/ProfileSheetReviewsSection';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { WWPrimaryButton, WWSheetCloseButton } from '../ui';

const SKY = colors.SKY;
const SHEET_MAX_RATIO = 0.92;

export type ValeterProfileSheetSeed = {
  id: string;
  name?: string;
  rating?: number;
  totalJobs?: number;
  profilePicture?: string | null;
  isOnline?: boolean;
  distanceMiles?: number | null;
  etaMins?: number | null;
  specializations?: string[];
};

type LoadedExtra = {
  fullName: string | null;
  profilePhotoUrl: string | null;
  bio: string | null;
  isOnline: boolean;
  rating: number;
  totalJobs: number;
};

const DEFAULT_BIO_FALLBACK =
  "This Car Care Pro hasn't added an about section yet. They offer mobile wash and care at your location — tap below to request them.";

export default function ValeterProfileBottomSheet({
  visible,
  onClose,
  valeterId,
  seed,
  onRequestBook,
}: {
  visible: boolean;
  onClose: () => void;
  valeterId: string | null;
  seed?: ValeterProfileSheetSeed | null;
  onRequestBook: () => void | Promise<void>;
}) {
  const insets = useSafeAreaInsets();
  const { height: windowH, width: windowW } = useWindowDimensions();
  const sheetMaxHeight = Math.round(windowH * SHEET_MAX_RATIO);

  const [loading, setLoading] = useState(false);
  const [extra, setExtra] = useState<LoadedExtra | null>(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [reviews, setReviews] = useState<ProfileSheetReviewItem[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);

  const load = useCallback(async () => {
    if (!valeterId || valeterId.trim() === '') return;
    setLoading(true);
    setImageFailed(false);
    try {
      let fullName: string | null = null;
      let profilePhotoUrl: string | null = null;
      let bio: string | null = null;

      type VpRow = {
        user_id?: string;
        full_name?: string | null;
        profile_photo_url?: string | null;
      };

      const { data: vpData, error: vpError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (!vpError && vpData) {
        const vp = vpData as VpRow;
        fullName = vp.full_name ?? null;
        profilePhotoUrl = vp.profile_photo_url ?? null;
      } else {
        const { data: prof } = await supabase.from('profiles').select('full_name, profile_picture').eq('id', valeterId).maybeSingle();
        const p = prof as { full_name?: string; profile_picture?: string } | null;
        fullName = p?.full_name ?? null;
        profilePhotoUrl = p?.profile_picture ?? null;
      }

      const bioRes = await supabase.from('valeter_profiles').select('bio').eq('user_id', valeterId).maybeSingle();
      if (!bioRes.error && bioRes.data) {
        const raw = (bioRes.data as { bio?: string | null }).bio;
        bio = raw?.trim() || null;
      }

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', valeterId)
        .maybeSingle();
      const isOnline = (presenceData as { is_online?: boolean } | null)?.is_online ?? seed?.isOnline ?? false;

      let rating = seed?.rating ?? 0;
      let totalJobs = seed?.totalJobs ?? 0;
      const stats = await ValeterStatsService.getValeterStats(valeterId).catch(() => null);
      if (stats) {
        rating = stats.averageRating ?? rating;
        totalJobs = stats.totalJobs ?? totalJobs;
      }

      setExtra({
        fullName,
        profilePhotoUrl,
        bio,
        isOnline,
        rating,
        totalJobs,
      });
    } catch {
      setExtra({
        fullName: null,
        profilePhotoUrl: null,
        bio: null,
        isOnline: seed?.isOnline ?? false,
        rating: seed?.rating ?? 0,
        totalJobs: seed?.totalJobs ?? 0,
      });
    } finally {
      setLoading(false);
    }
  }, [valeterId, seed?.isOnline, seed?.rating, seed?.totalJobs]);

  useEffect(() => {
    if (!visible || !valeterId) {
      setExtra(null);
      return;
    }
    void load();
  }, [visible, valeterId, load]);

  useEffect(() => {
    if (!visible || !valeterId) {
      setReviews([]);
      return;
    }
    let cancelled = false;
    (async () => {
      setReviewsLoading(true);
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id,rating,review,completed_at,user_id')
          .eq('valeter_id', valeterId)
          .eq('status', 'completed')
          .not('rating', 'is', null)
          .order('completed_at', { ascending: false })
          .limit(8);
        if (cancelled || error || !data?.length) {
          if (!cancelled) setReviews([]);
          return;
        }
        const userIds = [...new Set(data.map((r: { user_id?: string }) => r.user_id).filter(Boolean))] as string[];
        const nameBy = new Map<string, string>();
        if (userIds.length) {
          const { data: profs } = await supabase.from('profiles').select('id,full_name').in('id', userIds);
          (profs || []).forEach((p: { id: string; full_name?: string | null }) => {
            nameBy.set(p.id, p.full_name?.trim() || 'Customer');
          });
        }
        if (!cancelled) {
          setReviews(
            data.map((r: { id: string; rating?: number | null; review?: string | null; user_id?: string; completed_at?: string | null }) => ({
              id: String(r.id),
              rating: Number(r.rating) || 0,
              body: r.review?.trim() || null,
              author: (r.user_id && nameBy.get(r.user_id)) || 'Customer',
              completedAt: r.completed_at ?? null,
            }))
          );
        }
      } catch {
        if (!cancelled) setReviews([]);
      } finally {
        if (!cancelled) setReviewsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, valeterId]);

  const merged = useMemo(() => {
    const name = extra?.fullName || seed?.name || 'Car care pro';
    const photo = extra?.profilePhotoUrl ?? seed?.profilePicture ?? null;
    const rating = extra?.rating ?? seed?.rating ?? 0;
    const jobs = extra?.totalJobs ?? seed?.totalJobs ?? 0;
    const online = extra?.isOnline ?? seed?.isOnline ?? false;
    const bioText = (extra?.bio && extra.bio.trim()) || null;
    return {
      name: formatDisplayName(name) || name,
      photo,
      rating,
      jobs,
      online,
      bioText,
      distanceMiles: seed?.distanceMiles ?? null,
      etaMins: seed?.etaMins ?? null,
    };
  }, [extra, seed]);

  const bioParagraph = merged.bioText || DEFAULT_BIO_FALLBACK;

  if (!valeterId) return null;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.root}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Dismiss profile" />
        <View style={[styles.panel, { borderColor: HEADER_STYLE_CARD_BORDER, maxHeight: sheetMaxHeight, paddingBottom: Math.max(14, insets.bottom) }]}>
          <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} pointerEvents="none" />
          <LinearGradient
            colors={HEADER_STYLE_CARD_GRADIENT}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
            pointerEvents="none"
          />
          <View style={[StyleSheet.absoluteFill, styles.sheetDarkScrim]} pointerEvents="none" />
          <View style={[styles.rail, { backgroundColor: SKY + '99', shadowColor: SKY }]} pointerEvents="none" />
          <View style={styles.handle} />

          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollContent}
          >
            <View style={styles.heroRow}>
              <View style={styles.avatarRing}>
                {merged.photo && !imageFailed ? (
                  <Image
                    source={{ uri: merged.photo }}
                    style={styles.avatarImg}
                    onError={() => setImageFailed(true)}
                  />
                ) : (
                  <View style={styles.avatarPlaceholder}>
                    <GradientIconBox icon="person" preset="sky" boxSize={68} borderRadius={18} elevated />
                  </View>
                )}
                {merged.online ? (
                  <View style={styles.onlineBadge}>
                    <View style={styles.onlineDot} />
                  </View>
                ) : null}
              </View>
              <View style={styles.heroTextCol}>
                <Text style={styles.name} numberOfLines={2}>
                  {merged.name}
                </Text>
                <Text style={styles.kicker}>Car care pro</Text>
                <View style={styles.metaPills}>
                  <View style={styles.pill}>
                    <Ionicons name="star" size={14} color="#FBBF24" />
                    <Text style={styles.pillText}>{merged.rating > 0 ? merged.rating.toFixed(1) : 'New'}</Text>
                  </View>
                  <View style={styles.pill}>
                    <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                    <Text style={styles.pillText}>{merged.jobs} completed</Text>
                  </View>
                  {merged.distanceMiles != null ? (
                    <View style={styles.pill}>
                      <Ionicons name="navigate-outline" size={14} color={SKY} />
                      <Text style={styles.pillText}>{merged.distanceMiles.toFixed(1)} mi</Text>
                    </View>
                  ) : null}
                  {merged.etaMins != null ? (
                    <View style={styles.pill}>
                      <Ionicons name="time-outline" size={14} color={SKY} />
                      <Text style={styles.pillText}>~{merged.etaMins} min</Text>
                    </View>
                  ) : null}
                </View>
              </View>
              <WWSheetCloseButton onPress={onClose} hitSlop={14} accessibilityLabel="Close" />
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionLabel}>About</Text>
              <View style={styles.aboutCard}>
                {loading && !extra ? (
                  <ActivityIndicator color={SKY} style={{ marginVertical: 8 }} />
                ) : (
                  <Text style={styles.aboutBody}>{bioParagraph}</Text>
                )}
              </View>
            </View>

            <ProfileSheetReviewsSection reviews={reviews} loading={reviewsLoading} />

            <WorkGalleryPlaceholderRow />
          </ScrollView>

          <WWPrimaryButton
            title="Request this Car Care Pro"
            onPress={() => {
              void hapticFeedback('medium');
              void Promise.resolve(onRequestBook());
            }}
            leftIconName="flash-outline"
            leftIconSize={22}
            style={{
              alignSelf: 'center',
              width: getIndexTrackingCardWidth(windowW),
              marginTop: 4,
              marginBottom: 4,
            }}
          />
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(2,6,23,0.55)',
  },
  panel: {
    borderTopLeftRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderTopRightRadius: CUSTOMER_BOOKING_SHEET_TOP_RADIUS,
    borderWidth: 1,
    borderBottomWidth: 0,
    overflow: 'hidden',
  },
  sheetDarkScrim: {
    backgroundColor: BOOKING_SHEET_DARK_OVERLAY,
  },
  rail: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.85,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 8,
  },
  handle: {
    alignSelf: 'center',
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(148,163,184,0.45)',
    marginTop: 10,
    marginBottom: 6,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingBottom: 12,
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 14,
    gap: 12,
  },
  avatarRing: {
    width: 76,
    height: 76,
    borderRadius: 22,
    padding: 2,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.22)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
    borderRadius: 19,
  },
  avatarPlaceholder: {
    flex: 1,
    borderRadius: 19,
    backgroundColor: 'rgba(30,41,59,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  onlineBadge: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#0F172A',
    borderWidth: 2,
    borderColor: 'rgba(15,23,42,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  onlineDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#10B981',
  },
  heroTextCol: {
    flex: 1,
    minWidth: 0,
    paddingTop: 2,
  },
  name: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  kicker: {
    marginTop: 4,
    color: 'rgba(226,232,240,0.72)',
    fontSize: 13,
    fontWeight: '600',
  },
  metaPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 10,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  pillText: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    fontWeight: '700',
  },
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  aboutCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  aboutBody: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
});
