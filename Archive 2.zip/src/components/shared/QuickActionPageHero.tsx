import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { BORDER_RADIUS, SPACING, FONT_SIZES, FONT_WEIGHTS, CARD_SHADOW } from '../../constants/designTokens';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';

const SKY = colors.SKY;

export type QuickActionPageHeroProps = {
  icon: keyof typeof Ionicons.glyphMap;
  /** Icon tint (defaults to accent). */
  iconColor?: string;
  title: string;
  subtitle: string;
  /** Left accent strip + icon ring tint. */
  accentColor?: string;
};

/**
 * Shared hero for screens opened from dashboard quick actions — consistent blur, border, and typography.
 */
export default function QuickActionPageHero({
  icon,
  iconColor,
  title,
  subtitle,
  accentColor = SKY,
}: Readonly<QuickActionPageHeroProps>) {
  return (
    <View style={styles.wrap}>
      <BlurView
        intensity={Platform.OS === 'ios' ? 40 : 56}
        tint="dark"
        style={styles.blur}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.02)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
          pointerEvents="none"
        />
        <View style={styles.inner}>
          <View style={[styles.accentStrip, { backgroundColor: accentColor }]} />
          <View style={styles.body}>
            <View style={styles.iconSlot}>
              <GradientIconBox
                icon={icon}
                colors={accentToGradient(iconColor ?? accentColor)}
                boxSize={52}
                size={26}
                elevated
              />
            </View>
            <View style={styles.textCol}>
              <Text style={styles.title}>{title}</Text>
              <Text style={styles.subtitle}>{subtitle}</Text>
            </View>
          </View>
        </View>
      </BlurView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginBottom: SPACING.lg,
    ...CARD_SHADOW,
  },
  blur: {
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  inner: {
    overflow: 'hidden',
    borderRadius: BORDER_RADIUS.md,
  },
  body: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 88,
    paddingVertical: SPACING.md,
    paddingRight: SPACING.lg,
  },
  accentStrip: {
    width: 5,
    alignSelf: 'stretch',
    opacity: 0.95,
  },
  iconSlot: {
    marginLeft: SPACING.md,
    marginRight: SPACING.md,
  },
  textCol: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: '#F8FAFC',
    fontSize: FONT_SIZES.lg,
    fontWeight: FONT_WEIGHTS.extrabold,
    letterSpacing: -0.3,
    marginBottom: SPACING.xs,
  },
  subtitle: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: FONT_SIZES.sm,
    fontWeight: FONT_WEIGHTS.semibold,
    lineHeight: 18,
  },
});
