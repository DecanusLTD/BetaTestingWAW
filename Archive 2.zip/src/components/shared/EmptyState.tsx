import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, StyleProp, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { BORDER_RADIUS, SPACING, CARD_SHADOW } from '../../constants/designTokens';
import { colors } from '../../constants/colors';
import GradientIconBox, { GRADIENT_PRESETS } from './GradientIconBox';

interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: StyleProp<ViewStyle>;
  iconColor?: string;
  /** Gradient preset for the hero icon (defaults to sky). */
  iconPreset?: keyof typeof GRADIENT_PRESETS;
}

export default function EmptyState({
  icon = 'document-outline',
  title,
  subtitle,
  actionLabel,
  onAction,
  style,
  iconColor = colors.SKY,
  iconPreset = 'sky',
}: Readonly<EmptyStateProps>) {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.iconContainer}>
        <GradientIconBox
          icon={icon}
          preset={iconPreset}
          boxSize={88}
          size={40}
          borderRadius={28}
          elevated
        />
      </View>
      <Text style={styles.title}>{title}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      {actionLabel && onAction && (
        <TouchableOpacity onPress={onAction} style={styles.actionButton} activeOpacity={0.85}>
          <LinearGradient
            colors={[iconColor, iconColor + 'CC']}
            style={styles.actionGradient}
          >
            <Text style={styles.actionText}>{actionLabel}</Text>
          </LinearGradient>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xxxl,
    minHeight: 300,
  },
  iconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: SPACING.xxl,
    ...CARD_SHADOW,
  },
  title: {
    color: colors.textOnDarkPrimary,
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 0.2,
    textAlign: 'center',
    marginBottom: SPACING.sm,
  },
  subtitle: {
    color: colors.textOnDarkTertiary,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: SPACING.xxl,
  },
  actionButton: {
    borderRadius: BORDER_RADIUS.sm,
    overflow: 'hidden',
    marginTop: SPACING.sm,
    borderWidth: 1,
    borderColor: colors.borderLight,
    minWidth: 170,
    ...CARD_SHADOW,
  },
  actionGradient: {
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.xxl,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
    textAlign: 'center',
  },
});

