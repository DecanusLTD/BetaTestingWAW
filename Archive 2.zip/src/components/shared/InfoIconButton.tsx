import React from 'react';
import { TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BOOKING_CARD } from '../../constants/bookingCardTheme';
import GradientIconBox from './GradientIconBox';
import { accentToGradient } from '../../utils/accentGradient';

const SIZE = 32;
const ICON_SIZE = 20;

export interface InfoIconButtonProps {
  onPress: () => void;
  /** Accent color for icon and border (e.g. SKY, service color). */
  accentColor: string;
  style?: ViewStyle;
  /** Hit slop for touch area. Default 14. */
  hitSlop?: number;
  /** Optional icon name (Ionicons). Default "information-circle". */
  icon?: keyof typeof Ionicons.glyphMap;
}

/** Compact info affordance on booking cards (GradientIconBox Continue-style chrome). */
export default function InfoIconButton({
  onPress,
  accentColor,
  style,
  hitSlop = 14,
  icon = 'information-circle',
}: Readonly<InfoIconButtonProps>) {
  return (
    <TouchableOpacity
      onPress={onPress}
      hitSlop={{ top: hitSlop, bottom: hitSlop, left: hitSlop, right: hitSlop }}
      style={[styles.wrap, style]}
      activeOpacity={0.8}
    >
      <GradientIconBox
        icon={icon}
        colors={accentToGradient(accentColor)}
        boxSize={SIZE}
        size={ICON_SIZE}
        borderRadius={Math.min(BOOKING_CARD.BORDER_RADIUS, 12)}
        elevated
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginLeft: 4,
  },
});
