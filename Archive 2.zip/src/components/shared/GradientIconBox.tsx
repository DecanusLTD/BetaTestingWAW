import React from 'react';
import { View, StyleSheet, ViewStyle, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { BOOKING_CONTINUE_RADIUS } from '../../utils/bookingContinueStyle';

export const GRADIENT_PRESETS = {
  sky: ['#38BDF8', '#0EA5E9'] as [string, string],
  emerald: ['#34D399', '#059669'] as [string, string],
  green: ['#10B981', '#059669'] as [string, string],
  amber: ['#F59E0B', '#D97706'] as [string, string],
  cyan: ['#06B6D4', '#0891B2'] as [string, string],
  pink: ['#EC4899', '#DB2777'] as [string, string],
  gray: ['#6B7280', '#4B5563'] as [string, string],
  teal: ['#14B8A6', '#0D9488'] as [string, string],
  red: ['#EF4444', '#DC2626'] as [string, string],
  blue: ['#3B82F6', '#2563EB'] as [string, string],
  purple: ['#8B5CF6', '#7C3AED'] as [string, string],
} as const;

const CONTINUE_FOOT = 'rgba(15,23,42,0.65)' as const;

const ELEVATED_STYLE: ViewStyle = {
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.2,
  shadowRadius: 4,
  elevation: 4,
};

interface GradientIconBoxProps {
  icon: keyof typeof Ionicons.glyphMap;
  colors?: [string, string];
  preset?: keyof typeof GRADIENT_PRESETS;
  size?: number;
  boxSize?: number;
  /** Override corner radius (e.g. circular avatar: boxSize/2). */
  borderRadius?: number;
  /** Drop shadow wrapper. */
  elevated?: boolean;
  /** Omit Continue-style rim (e.g. dashboard quick actions). */
  borderless?: boolean;
  style?: ViewStyle;
  /** Softer chrome for inactive tabs / secondary affordances (dims, drops elevation). */
  muted?: boolean;
}

function isSolidColorStop(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0;
}

function resolveGradientTuple(
  colors: [string, string] | undefined,
  preset: keyof typeof GRADIENT_PRESETS | undefined
): [string, string] {
  const presetKey =
    preset && typeof preset === 'string' && preset in GRADIENT_PRESETS ? preset : 'sky';
  const fallback = GRADIENT_PRESETS[presetKey] ?? GRADIENT_PRESETS.sky;
  if (colors && Array.isArray(colors) && colors.length >= 2) {
    const a = colors[0];
    const b = colors[1];
    if (isSolidColorStop(a) && isSolidColorStop(b)) {
      return [a.trim(), b.trim()];
    }
  }
  return [fallback[0], fallback[1]];
}

/** Solid 6-digit hex for icon + border alpha suffixes (booking Continue CTA convention). */
function accentKey(tuple: [string, string]): string {
  const raw = tuple[0].trim();
  if (/^#[0-9A-Fa-f]{6}$/i.test(raw)) return raw;
  if (/^#[0-9A-Fa-f]{8}$/i.test(raw)) return raw.slice(0, 7);
  return raw;
}

function continueTopStop(accent: string): string {
  if (/^#[0-9A-Fa-f]{6}$/i.test(accent)) return `${accent}59`;
  if (/^#[0-9A-Fa-f]{8}$/i.test(accent)) return accent;
  return accent;
}

function continueBorderColor(accent: string): string {
  if (/^#[0-9A-Fa-f]{6}$/i.test(accent)) return `${accent}8A`;
  if (/^#[0-9A-Fa-f]{8}$/i.test(accent)) return accent;
  return 'rgba(255,255,255,0.22)';
}

function iconColorFromAccent(accent: string): string {
  if (/^#[0-9A-Fa-f]{6}$/i.test(accent)) return accent;
  if (/^#[0-9A-Fa-f]{8}$/i.test(accent)) return accent.slice(0, 7);
  return '#F8FAFC';
}

export default function GradientIconBox({
  icon,
  colors,
  preset = 'sky',
  size,
  boxSize = 42,
  borderRadius: borderRadiusProp,
  elevated = false,
  borderless = false,
  style,
  muted = false,
}: GradientIconBoxProps) {
  const tuple = resolveGradientTuple(colors, preset);
  const accent = accentKey(tuple);
  const iconSize = size ?? (boxSize <= 36 ? 18 : boxSize <= 44 ? 20 : 24);
  const borderRadius = borderRadiusProp ?? BOOKING_CONTINUE_RADIUS;
  const topStop = continueTopStop(accent);
  const borderCol = continueBorderColor(accent);
  const iconCol = iconColorFromAccent(accent);

  const chrome = (
    <View
      style={[
        styles.chrome,
        borderless && styles.chromeBorderless,
        {
          width: boxSize,
          height: boxSize,
          borderRadius,
          borderColor: borderless ? 'transparent' : borderCol,
        },
      ]}
    >
      <BlurView
        intensity={22}
        tint="dark"
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      <LinearGradient
        colors={[topStop, CONTINUE_FOOT]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <View style={styles.iconCenter} pointerEvents="none">
        <Ionicons name={icon} size={iconSize} color={iconCol} />
      </View>
    </View>
  );

  const useElevated = elevated && !muted;
  const wrapStyle: ViewStyle[] = [
    { width: boxSize, height: boxSize, opacity: muted ? 0.72 : 1 },
    useElevated ? ELEVATED_STYLE : {},
    style,
  ];

  return <View style={wrapStyle}>{chrome}</View>;
}

const styles = StyleSheet.create({
  chrome: {
    flex: 1,
    overflow: 'hidden',
    borderWidth: 1,
    position: 'relative',
  },
  chromeBorderless: {
    borderWidth: 0,
  },
  iconCenter: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
