/**
 * Map-first screens — full-width blurred bar + brand gradient (matches AppHeader).
 */
import React from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Text,
  Platform,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAccountTheme } from './AccountThemeProvider';
import {
  BOOKING_CONTINUE_RADIUS,
  appHeaderChromeIconButtonStyle,
  bookingContinueGradient,
  bookingContinueHeaderBarShadow,
} from '../../utils/bookingContinueStyle';

export type MapFloatingHeaderProps = {
  onBack?: () => void;
  /** Optional title block — uses dashboard title typography when string, or custom node. */
  center?: React.ReactNode;
  title?: string;
  subtitle?: string;
  right?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  backLabel?: string;
  accentColor?: string;
};

export function mapFloatingIconButtonStyle(): ViewStyle {
  return appHeaderChromeIconButtonStyle();
}

const R = BOOKING_CONTINUE_RADIUS;

export default function MapFloatingHeader({
  onBack,
  center,
  title,
  subtitle,
  right,
  style,
  backLabel = 'Go back',
  accentColor,
}: MapFloatingHeaderProps) {
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const accent = accentColor ?? theme.primary;
  const [g0, g1] = bookingContinueGradient(accent);

  const centerNode =
    center ??
    (title != null && title !== '' ? (
      <View style={styles.titleBlock}>
        <Text style={styles.titleText} numberOfLines={1}>
          {title}
        </Text>
        {subtitle != null && subtitle !== '' ? (
          <Text style={styles.subtitleText} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    ) : null);

  return (
    <View pointerEvents="box-none" style={[styles.absoluteFill, style]}>
      <View
        style={[
          styles.chromeBar,
          bookingContinueHeaderBarShadow(accent),
          {
            width: '100%',
            borderBottomLeftRadius: R,
            borderBottomRightRadius: R,
            paddingTop: insets.top,
          },
        ]}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 78 : 96}
          tint="dark"
          style={[styles.blurLayer, { borderBottomLeftRadius: R, borderBottomRightRadius: R }]}
          {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
        />
        <LinearGradient
          colors={[g0, g1]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.tintLayer, { borderBottomLeftRadius: R, borderBottomRightRadius: R }]}
        />
        <View
          pointerEvents="none"
          style={[
            styles.glassStroke,
            {
              borderBottomLeftRadius: R,
              borderBottomRightRadius: R,
            },
          ]}
        />
        <View style={styles.row}>
          {onBack ? (
            <TouchableOpacity
              onPress={onBack}
              activeOpacity={0.82}
              accessibilityRole="button"
              accessibilityLabel={backLabel}
              style={appHeaderChromeIconButtonStyle()}
            >
              <Ionicons name="chevron-back" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          ) : (
            <View style={{ width: 40 }} />
          )}
          {centerNode != null ? (
            <View style={styles.centerWrap} pointerEvents="none">
              {centerNode}
            </View>
          ) : (
            <View style={styles.spacer} />
          )}
          <View style={styles.right}>{right}</View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  absoluteFill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    width: '100%',
  },
  chromeBar: {
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.35)',
    position: 'relative',
  },
  blurLayer: {
    ...StyleSheet.absoluteFillObject,
  },
  tintLayer: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.82,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: 'rgba(255,255,255,0.22)',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    minHeight: 52,
    zIndex: 10,
    position: 'relative',
  },
  spacer: { flex: 1 },
  centerWrap: {
    flex: 1,
    paddingHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 0,
  },
  titleBlock: { alignItems: 'center', width: '100%' },
  titleText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
    textAlign: 'center',
  },
  subtitleText: {
    marginTop: 2,
    color: 'rgba(255,255,255,0.92)',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  right: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
