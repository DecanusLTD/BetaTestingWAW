/**
 * Shared fill for map bottom sheets — blur + header gradient + accent wash (matches business locations).
 */
import React from 'react';
import { StyleSheet, Platform, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useAccountTheme } from './AccountThemeProvider';
import { useThemeOptional } from '../../contexts/ThemeContext';
import { colors } from '../../constants/colors';

const FALLBACK_HEADER: [string, string] = ['#0f172a', '#0f172a'];

export default function BusinessSheetBackground() {
  const { theme } = useAccountTheme();
  const themeOptional = useThemeOptional();
  const tint = themeOptional?.isDark === false ? 'light' : 'dark';
  const headerBg = (theme.headerBackground ?? theme.background ?? FALLBACK_HEADER) as [string, string];
  const headerAccent = theme.primary || colors.navActive;

  return (
    <BlurView intensity={Platform.OS === 'ios' ? 30 : 22} tint={tint} style={StyleSheet.absoluteFill}>
      <LinearGradient
        colors={[`${headerBg[0]}FF`, `${headerBg[1] || headerBg[0]}EE`]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={[`${headerAccent}30`, 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      </View>
    </BlurView>
  );
}
