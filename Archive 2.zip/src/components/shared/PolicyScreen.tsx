import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from './AppHeader';
import GlassCard from '../booking/GlassCard';
import { getAccountTheme } from '../../constants/accountThemes';
import { useTheme } from '../../contexts/ThemeContext';
import { CONTENT_PADDING_H } from '../../constants/pageStyles';
import { SPACING, FONT_SIZES, FONT_WEIGHTS, CARD_SHADOW } from '../../constants/designTokens';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export type PolicySection = {
  title: string;
  icon?: keyof typeof Ionicons.glyphMap;
  content: React.ReactNode;
};

type PolicyScreenProps = {
  title: string;
  headerIcon: keyof typeof Ionicons.glyphMap;
  accountType: 'customer' | 'valeter' | 'business';
  sections: PolicySection[];
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: CONTENT_PADDING_H, gap: SPACING.lg },
  headerCard: {
    padding: SPACING.xl,
    alignItems: 'center',
    marginBottom: SPACING.sm,
    ...CARD_SHADOW,
  },
  headerIcon: {
    marginBottom: SPACING.md,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: FONT_SIZES.sm,
    fontWeight: FONT_WEIGHTS.medium,
    textAlign: 'center',
  },
  sectionCard: {
    padding: SPACING.xl,
    ...CARD_SHADOW,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? FONT_SIZES.lg : FONT_SIZES.xl,
    fontWeight: FONT_WEIGHTS.bold,
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: FONT_SIZES.md,
    lineHeight: 22,
    fontWeight: FONT_WEIGHTS.normal,
  },
  bulletList: {
    marginTop: SPACING.md,
    gap: SPACING.sm,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: FONT_SIZES.md,
    lineHeight: 20,
    marginLeft: 4,
  },
  bulletBold: {
    fontWeight: FONT_WEIGHTS.bold,
    color: 'rgba(255,255,255,0.95)',
  },
});

export const policyScreenStyles = styles;

export default function PolicyScreen({ title, headerIcon, accountType, sections }: Readonly<PolicyScreenProps>) {
  const insets = useSafeAreaInsets();
  const { colorScheme } = useTheme();
  const theme = getAccountTheme(accountType, colorScheme === 'dark' ? 'dark' : 'light');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={title}
        accountType={accountType}
        showBack
        onBack={() => router.back()}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name={headerIcon} size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>
            Last updated: {new Date().toLocaleDateString('en-GB', {
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </Text>
        </GlassCard>

        {sections.map((section) => (
          <GlassCard key={section.title} style={styles.sectionCard} accountType={accountType}>
            <View style={styles.sectionHeader}>
              <Ionicons
                name={(section.icon ?? 'document-text') as any}
                size={20}
                color={theme.primary}
              />
              <Text style={[styles.sectionTitle, { color: theme.primary }]}>
                {section.title}
              </Text>
            </View>
            {typeof section.content === 'string' ? (
              <Text style={styles.sectionText}>{section.content}</Text>
            ) : (
              section.content
            )}
          </GlassCard>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
