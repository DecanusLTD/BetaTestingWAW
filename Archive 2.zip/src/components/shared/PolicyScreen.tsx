import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from './AppHeader';
import GlassCard from '../booking/GlassCard';
import { getAccountTheme } from '../../constants/accountThemes';
import { CONTENT_PADDING_H } from '../../constants/pageStyles';
import { SPACING } from '../../constants/designTokens';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export type PolicySection = {
  title: string;
  icon?: keyof typeof Ionicons.glyphMap;
  content: React.ReactNode;
};

type PolicyScreenProps = {
  title: string;
  headerIcon: keyof typeof Ionicons.glyphMap;
  accountType: 'customer' | 'valeter' | 'business';
  sections: PolicySection[];
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: CONTENT_PADDING_H, gap: SPACING.lg },
  headerCard: {
    padding: SPACING.xl,
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  headerIcon: {
    marginBottom: SPACING.md,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: SPACING.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  bulletList: {
    marginTop: SPACING.md,
    gap: SPACING.sm,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
  bulletBold: {
    fontWeight: '700',
    color: 'rgba(255,255,255,0.95)',
  },
});

export const policyScreenStyles = styles;

export default function PolicyScreen({ title, headerIcon, accountType, sections }: Readonly<PolicyScreenProps>) {
  const insets = useSafeAreaInsets();
  const theme = getAccountTheme(accountType);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={title}
        accountType={accountType}
        showBack
        onBack={() => router.back()}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name={headerIcon} size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>
            Last updated: {new Date().toLocaleDateString('en-GB', {
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </Text>
        </GlassCard>

        {sections.map((section) => (
          <GlassCard key={section.title} style={styles.sectionCard} accountType={accountType}>
            <View style={styles.sectionHeader}>
              <Ionicons
                name={(section.icon ?? 'document-text') as any}
                size={20}
                color={theme.primary}
              />
              <Text style={[styles.sectionTitle, { color: theme.primary }]}>
                {section.title}
              </Text>
            </View>
            {typeof section.content === 'string' ? (
              <Text style={styles.sectionText}>{section.content}</Text>
            ) : (
              section.content
            )}
          </GlassCard>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
