import React from 'react';
import { View, StyleSheet, ViewStyle, StyleProp } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { MapMarkerWashHub, MapMarkerValeterLive } from '../maps/MapMarkerViews';

const SKY = colors.SKY;

/** Circular valeter avatar when no profile photo (no PNG). */
export function ValeterPhotoPlaceholder({
  size,
  borderRadius,
  style,
  iconScale = 0.42,
}: {
  size: number;
  borderRadius?: number;
  style?: StyleProp<ViewStyle>;
  iconScale?: number;
}) {
  const r = borderRadius ?? size / 2;
  return (
    <View
      style={[
        styles.valeterPh,
        {
          width: size,
          height: size,
          borderRadius: r,
        },
        style,
      ]}
    >
      <Ionicons name="person-outline" size={Math.max(14, Math.round(size * iconScale))} color={SKY} />
    </View>
  );
}

/** Wash hub / venue cover or thumbnail when no image (no carwash PNG). */
export function WashHubPlaceholder({
  width: w,
  height: h,
  borderRadius = 0,
  style,
  iconName = 'camera-outline',
  iconSize: iconSizeProp,
}: {
  width?: number | string;
  height?: number | string;
  borderRadius?: number;
  style?: StyleProp<ViewStyle>;
  iconName?: keyof typeof Ionicons.glyphMap;
  iconSize?: number;
}) {
  const dim: ViewStyle = {};
  if (w !== undefined) dim.width = w as number;
  if (h !== undefined) dim.height = h as number;
  if (borderRadius) dim.borderRadius = borderRadius;
  const ih = typeof h === 'number' ? h : 120;
  const iconSize = iconSizeProp ?? Math.min(52, Math.round(ih * 0.38));
  return (
    <View style={[styles.hubPh, dim, style]}>
      <Ionicons name={iconName} size={iconSize} color={SKY} />
    </View>
  );
}

export function MapWashHubMarkerView({ size = 44 }: { size?: number }) {
  return <MapMarkerWashHub size={size} />;
}

export function MapValeterMarkerView({ size = 48 }: { size?: number }) {
  return <MapMarkerValeterLive size={size} />;
}

const styles = StyleSheet.create({
  valeterPh: {
    backgroundColor: 'rgba(30,41,59,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.28)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  hubPh: {
    backgroundColor: 'rgba(30,41,59,0.88)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth * 2,
    borderColor: 'rgba(135,206,235,0.22)',
    overflow: 'hidden',
  },
});
