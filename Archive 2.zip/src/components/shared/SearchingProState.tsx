import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  ActivityIndicator,
  Easing,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { CCP } from '../../constants/carCareProLabels';

const SKY = colors.SKY;

const SEARCH_STEPS = [
  { key: 'scan', label: 'Area', detail: 'Scanning your map area', icon: 'locate-outline' as const },
  { key: 'online', label: 'Online', detail: `Finding ${CCP.pluralShort.toLowerCase()} nearby`, icon: 'radio-outline' as const },
  { key: 'match', label: 'Match', detail: 'Checking who can take this job', icon: 'flash-outline' as const },
  { key: 'ready', label: 'Ready', detail: 'Almost there — lining up the best fits', icon: 'checkmark-circle-outline' as const },
];

type Props = {
  accent?: string;
  title?: string;
  subtitle?: string;
  busy?: boolean;
  zoom?: number;
};

export default function SearchingProState({
  accent = SKY,
  title,
  subtitle,
  busy = true,
  zoom = 1,
}: Props) {
  const z = (n: number) => Math.round(n * zoom);
  const [stepIndex, setStepIndex] = useState(0);
  const pulseA = useRef(new Animated.Value(0)).current;
  const pulseB = useRef(new Animated.Value(0)).current;
  const sweep = useRef(new Animated.Value(0)).current;
  const stepFade = useRef(new Animated.Value(1)).current;
  const bob = useRef(new Animated.Value(0)).current;

  const resolvedTitle =
    title ||
    (busy ? `Searching for ${CCP.pluralShort}…` : `Searching for a ${CCP.singularShort}`);

  const activeStep = SEARCH_STEPS[stepIndex] ?? SEARCH_STEPS[0];
  /** Custom subtitle sits under the live cycling step detail. */
  const footnote = subtitle;

  useEffect(() => {
    const loopA = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseA, {
          toValue: 1,
          duration: 1800,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(pulseA, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    const loopB = Animated.loop(
      Animated.sequence([
        Animated.delay(700),
        Animated.timing(pulseB, {
          toValue: 1,
          duration: 1800,
          easing: Easing.out(Easing.cubic),
          useNativeDriver: true,
        }),
        Animated.timing(pulseB, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );
    const loopSweep = Animated.loop(
      Animated.timing(sweep, {
        toValue: 1,
        duration: 2400,
        easing: Easing.inOut(Easing.quad),
        useNativeDriver: true,
      })
    );
    const loopBob = Animated.loop(
      Animated.sequence([
        Animated.timing(bob, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(bob, {
          toValue: 0,
          duration: 900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );

    loopA.start();
    loopB.start();
    loopSweep.start();
    loopBob.start();
    return () => {
      loopA.stop();
      loopB.stop();
      loopSweep.stop();
      loopBob.stop();
    };
  }, [pulseA, pulseB, sweep, bob]);

  useEffect(() => {
    const id = setInterval(() => {
      Animated.sequence([
        Animated.timing(stepFade, { toValue: 0, duration: 180, useNativeDriver: true }),
        Animated.timing(stepFade, { toValue: 1, duration: 280, useNativeDriver: true }),
      ]).start();
      setStepIndex((prev) => (prev + 1) % SEARCH_STEPS.length);
    }, 2200);
    return () => clearInterval(id);
  }, [stepFade]);

  const ringStyle = (anim: Animated.Value) => ({
    opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.45, 0] }),
    transform: [
      {
        scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.72, 1.55] }),
      },
    ],
  });

  const sweepTranslate = sweep.interpolate({
    inputRange: [0, 1],
    outputRange: [-40, 40],
  });

  const bobTranslate = bob.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -3],
  });

  const progressSegments = useMemo(
    () =>
      SEARCH_STEPS.map((step, index) => {
        const active = index === stepIndex;
        const done = index < stepIndex;
        return { ...step, active, done };
      }),
    [stepIndex]
  );

  return (
    <View style={[styles.wrap, { padding: z(16), gap: z(16) }]}>
      <View style={[styles.heroRow, { gap: z(14) }]}>
        <View style={[styles.radarWrap, { width: z(72), height: z(72) }]}>
          <Animated.View
            pointerEvents="none"
            style={[
              styles.radarRing,
              {
                borderColor: accent + '66',
                width: z(72),
                height: z(72),
                borderRadius: z(36),
              },
              ringStyle(pulseA),
            ]}
          />
          <Animated.View
            pointerEvents="none"
            style={[
              styles.radarRing,
              {
                borderColor: accent + '44',
                width: z(72),
                height: z(72),
                borderRadius: z(36),
              },
              ringStyle(pulseB),
            ]}
          />
          <Animated.View
            style={[
              styles.radarCore,
              {
                width: z(56),
                height: z(56),
                borderRadius: z(18),
                borderColor: accent + '66',
                backgroundColor: accent + '1A',
                transform: [{ translateY: bobTranslate }],
              },
            ]}
          >
            <ActivityIndicator size="large" color={accent} />
            <View style={[styles.radarIconBadge, { backgroundColor: accent }]}>
              <Ionicons name="search" size={z(10)} color="#0B1220" />
            </View>
          </Animated.View>
        </View>

        <View style={[styles.copyCol, { gap: z(6) }]}>
          <Text style={[styles.kicker, { color: accent, fontSize: z(9) }]}>
            LIVE MATCH
          </Text>
          <Text style={[styles.title, { fontSize: z(17) }]} numberOfLines={2}>
            {resolvedTitle}
          </Text>
          <Animated.Text
            style={[
              styles.detail,
              { fontSize: z(12), opacity: stepFade, color: 'rgba(226,232,240,0.88)' },
            ]}
            numberOfLines={2}
          >
            {activeStep.detail}
          </Animated.Text>
          {footnote ? (
            <Text style={[styles.footnote, { fontSize: z(11) }]} numberOfLines={1}>
              {footnote}
            </Text>
          ) : null}
        </View>
      </View>

      <View style={styles.trackWrap}>
        <View style={[styles.trackBase, { backgroundColor: accent + '18' }]}>
          <Animated.View
            style={[
              styles.trackSweep,
              {
                backgroundColor: accent + '55',
                transform: [{ translateX: sweepTranslate }],
              },
            ]}
          />
        </View>
        <View style={styles.stepsRow}>
          {progressSegments.map((step) => {
            const tone = step.active ? accent : step.done ? accent + 'AA' : 'rgba(148,163,184,0.55)';
            return (
              <View key={step.key} style={styles.stepItem}>
                <View
                  style={[
                    styles.stepDot,
                    {
                      backgroundColor: step.active || step.done ? accent : 'rgba(148,163,184,0.28)',
                      borderColor: tone,
                      transform: [{ scale: step.active ? 1.15 : 1 }],
                    },
                  ]}
                >
                  {step.done && !step.active ? (
                    <Ionicons name="checkmark" size={z(9)} color="#0B1220" />
                  ) : step.active ? (
                    <ActivityIndicator size="small" color="#0B1220" style={{ transform: [{ scale: 0.7 }] }} />
                  ) : null}
                </View>
                <Text
                  style={[
                    styles.stepLabel,
                    {
                      color: tone,
                      fontSize: z(10),
                      fontWeight: step.active ? '800' : '600',
                    },
                  ]}
                  numberOfLines={1}
                >
                  {step.label}
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      <View style={[styles.hintRow, { gap: z(8) }]}>
        <View style={[styles.hintChip, { borderColor: accent + '44', backgroundColor: accent + '14' }]}>
          <Ionicons name={activeStep.icon} size={z(12)} color={accent} />
          <Text style={[styles.hintChipText, { color: accent, fontSize: z(11) }]}>
            {activeStep.label}
          </Text>
        </View>
        <Text style={[styles.hintAside, { fontSize: z(11) }]} numberOfLines={1}>
          Stay on this screen — matches appear as they come online
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: '100%',
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  radarWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  radarRing: {
    position: 'absolute',
    borderWidth: 1.5,
  },
  radarCore: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth * 2,
    overflow: 'hidden',
  },
  radarIconBadge: {
    position: 'absolute',
    right: 4,
    bottom: 4,
    width: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  copyCol: {
    flex: 1,
    minWidth: 0,
  },
  kicker: {
    fontWeight: '800',
    letterSpacing: 1.1,
  },
  title: {
    color: '#F8FAFC',
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  detail: {
    fontWeight: '600',
    lineHeight: 16,
  },
  footnote: {
    color: 'rgba(148,163,184,0.85)',
    fontWeight: '600',
  },
  trackWrap: {
    gap: 10,
  },
  trackBase: {
    height: 4,
    borderRadius: 999,
    overflow: 'hidden',
  },
  trackSweep: {
    width: '42%',
    height: '100%',
    borderRadius: 999,
  },
  stepsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 6,
  },
  stepItem: {
    flex: 1,
    alignItems: 'center',
    gap: 5,
  },
  stepDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepLabel: {
    letterSpacing: 0.2,
  },
  hintRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  hintChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 999,
    borderWidth: 1,
  },
  hintChipText: {
    fontWeight: '800',
  },
  hintAside: {
    flex: 1,
    color: 'rgba(148,163,184,0.9)',
    fontWeight: '600',
  },
});
