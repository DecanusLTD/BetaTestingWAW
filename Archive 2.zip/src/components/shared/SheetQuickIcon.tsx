import React from 'react';
import { StyleProp, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import GradientIconBox, { GRADIENT_PRESETS } from './GradientIconBox';

export type SheetQuickIconPreset = keyof typeof GRADIENT_PRESETS;

type Props = {
  icon: keyof typeof Ionicons.glyphMap;
  preset?: SheetQuickIconPreset;
  /** `row` — address / hours / section leads (dashboard quick-action chrome, scaled). `chip` — service & trait chips. */
  size?: 'row' | 'chip';
  style?: StyleProp<ViewStyle>;
};

const ROW_BOX = 48;
const ROW_RADIUS = 15;
const CHIP_BOX = 34;
const CHIP_RADIUS = 11;

/**
 * Same visual language as dashboard quick actions ({@link GradientIconBox} + blur + elevated shadow), sized for bottom-sheet rows.
 */
export default function SheetQuickIcon({
  icon,
  preset = 'sky',
  size = 'row',
  style,
}: Readonly<Props>) {
  const boxSize = size === 'chip' ? CHIP_BOX : ROW_BOX;
  const borderRadius = size === 'chip' ? CHIP_RADIUS : ROW_RADIUS;
  return (
    <GradientIconBox
      icon={icon}
      preset={preset}
      boxSize={boxSize}
      borderRadius={borderRadius}
      elevated
      style={style}
    />
  );
}
