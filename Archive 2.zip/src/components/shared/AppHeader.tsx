import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Animated,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';
import {
  appHeaderChromeIconButtonStyle,
  bookingContinueHeaderBarShadow,
  bookingContinueVerticalTint,
  bookingContinueChromeBorder,
} from '../../utils/bookingContinueStyle';
import {
  BOOKING_INNER_CARD_BACKGROUND,
  HEADER_STYLE_CARD_GRADIENT,
  PREMIUM_BOOKING_MAP_SHEET,
} from '../../constants/bookingCardTheme';
import BookingMapChromeHeader from '../booking/BookingMapChromeHeader';

/** Floating header pill – rounder than booking Continue chips (18) for a softer capsule. */
const HEADER_FLOATING_RADIUS = 32;

// Header content heights – unified to match rest of app (compact)
export const HEADER_CONTENT_HEIGHT = 40;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 40;
export const HEADER_HEIGHT = HEADER_CONTENT_HEIGHT + 12;
export const DASHBOARD_HEADER_HEIGHT = HEADER_HEIGHT;

/** Body height under safe area for a floating pill header (see `FLOATING_HEADER_TOP_GAP`). */
export const HEADER_CONTENT_OFFSET = 86;
export const DASHBOARD_HEADER_CONTENT_OFFSET = 86;
/** Scroll clearance for customer dashboard with `dashboardSplitChrome` (single row: profile · greeting · bell). */
export const DASHBOARD_SPLIT_HEADER_CONTENT_OFFSET = 52;

/** Total slide-up distance when collapsing the dashboard header (status bar + chrome row). */
export function getCollapsibleHeaderHideDistance(
  topInset: number,
  options: { fullWidth?: boolean; splitChrome?: boolean } = {}
): number {
  const { fullWidth = false, splitChrome = false } = options;
  if (fullWidth) return topInset + 64;
  if (splitChrome) return topInset + FLOATING_HEADER_TOP_GAP + 46;
  return topInset + HEADER_CONTENT_OFFSET;
}

/** Middle greeting pill radius in `dashboardSplitChrome` row layout. */
const DASHBOARD_SPLIT_MIDDLE_RADIUS = 22;

/** Horizontal inset for the floating header card; must match wrapper padding (and tab bar). */
export const FLOATING_HEADER_H_MARGIN = 16;
/** Gap from safe-area top to the floating header pill. */
const FLOATING_HEADER_TOP_GAP = 10;

const BLUR_IOS = { rest: 36, scrollMax: 58 };
const BLUR_ANDROID = { rest: 30, scrollMax: 48 };

type SplitMiddleChromeProps = Readonly<{
  borderRadius: number;
  blurIntensity: number;
  blurTint: 'light' | 'dark';
  sheetChrome: boolean;
  accentColor: string;
  tintColors: [string, string];
  tintGradientAxis: { start: { x: number; y: number }; end: { x: number; y: number } };
  headerChromeBorder: string;
  headerContainerBg: string;
}>;

/** Glass stack for the compact dashboard greeting pill (matches main header chrome, smaller radius). */
function DashboardSplitMiddleChrome({
  borderRadius,
  blurIntensity,
  blurTint,
  sheetChrome,
  accentColor,
  tintColors,
  tintGradientAxis,
  headerChromeBorder,
  headerContainerBg,
}: SplitMiddleChromeProps) {
  return (
    <>
      <BlurView
        intensity={blurIntensity}
        tint={blurTint}
        style={[styles.blurLayer, { borderRadius }]}
        {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
      />
      {!sheetChrome ? (
        <View style={[styles.chromeAccentWash, { borderRadius }]} pointerEvents="none">
          <LinearGradient
            colors={[`${String(accentColor)}26`, 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </View>
      ) : null}
      <LinearGradient
        colors={tintColors}
        start={tintGradientAxis.start}
        end={tintGradientAxis.end}
        style={[
          styles.tintLayer,
          sheetChrome && styles.tintLayerBookingSheet,
          !sheetChrome && styles.tintLayerContinueChrome,
          { borderRadius },
        ]}
      />
      {sheetChrome ? (
        <LinearGradient
          colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.headerBookingSheetSheen, { borderRadius }]}
          pointerEvents="none"
        />
      ) : null}
      <View
        pointerEvents="none"
        style={[
          styles.glassStroke,
          {
            borderColor: headerChromeBorder,
            borderRadius,
          },
        ]}
      />
      {!sheetChrome ? (
        <View
          pointerEvents="none"
          style={[
            styles.glowLine,
            {
              borderTopLeftRadius: borderRadius,
              borderTopRightRadius: borderRadius,
              backgroundColor: `${String(accentColor)}70`,
              shadowColor: accentColor,
            },
          ]}
        />
      ) : null}
    </>
  );
}

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  primaryColor?: string;
  /** Optional gradient end; defaults to booking Continue-style pair for `primaryColor`. */
  primaryColorEnd?: string;
  /** Match Book a Service sheet/cards: teal–navy glass header instead of accent gradient. */
  bookingSheetHeaderChrome?: boolean;
  topOffset?: number;
  /** Customer dashboard: separate floating icon pills + greeting card (below). */
  dashboardSplitChrome?: boolean;
  /** Edge-to-edge solid header bar (square corners, fills under the status bar) instead of floating pill. */
  fullWidth?: boolean;
  /** Icon in the yellow title pill when `fullWidth` chrome header is used. */
  titleIcon?: React.ComponentProps<typeof Ionicons>['name'];
  /** LinkedIn-style: hide header while scrolling down, reveal when scrolling up. */
  hideOnScroll?: boolean;
  /** 0 = visible, 1 = hidden — parent updates from scroll direction. */
  headerHideProgress?: Animated.Value;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  leftAction,
  rightAction,
  variant = 'dashboard',
  scrollY,
  enableScrollAnimation = false,
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  primaryColor,
  primaryColorEnd,
  bookingSheetHeaderChrome = false,
  topOffset = 0,
  dashboardSplitChrome = false,
  fullWidth = false,
  titleIcon,
  hideOnScroll = false,
  headerHideProgress,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  /**
   * Glass "booking sheet" chrome is now opt-in only. Booking flow headers use the
   * same theme gradient as the dashboard header + nav tab (see `headerBg`).
   */
  const sheetChrome = bookingSheetHeaderChrome;

  const defaultScrollY = useRef(new Animated.Value(0)).current;
  const scrollPosition = scrollY || defaultScrollY;

  const { theme: contextAccountTheme, mode } = useAccountTheme();
  const theme = accountType ? getAccountTheme(accountType, mode) : contextAccountTheme;
  const accentColor = primaryColor || theme.primary;
  const headerBg = (theme.headerBackground ?? theme.background) as [string, string];
  const tintColors: [string, string] = sheetChrome
    ? HEADER_STYLE_CARD_GRADIENT
    : primaryColorEnd
      ? ([bookingContinueVerticalTint(accentColor)[0], primaryColorEnd] as [string, string])
      : primaryColor
        ? bookingContinueVerticalTint(accentColor)
        : headerBg;
  const tintGradientAxis = { start: { x: 0, y: 0 }, end: { x: 0, y: 1 } };
  const headerBarShadow = sheetChrome
    ? {
        shadowColor: PREMIUM_BOOKING_MAP_SHEET.shadowColor,
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.32,
        shadowRadius: 22,
        elevation: 16,
      }
    : bookingContinueHeaderBarShadow(accentColor);
  const headerChromeBorder = sheetChrome
    ? 'rgba(255,255,255,0.12)'
    : theme.glassBorder || bookingContinueChromeBorder(accentColor);
  /** Match bottom sheet body darkness (navy glass + premium layers on booking index). */
  const headerContainerBg = sheetChrome ? BOOKING_INNER_CARD_BACKGROUND : 'rgba(15,23,42,0.35)';
  const blurTint: 'light' | 'dark' = sheetChrome ? 'dark' : mode === 'light' ? 'light' : 'dark';
  const blurRest = sheetChrome ? 26 : Platform.OS === 'ios' ? BLUR_IOS.rest : BLUR_ANDROID.rest;
  const blurMax = sheetChrome ? 26 : Platform.OS === 'ios' ? BLUR_IOS.scrollMax : BLUR_ANDROID.scrollMax;
  const [blurIntensity, setBlurIntensity] = useState(blurRest);

  useEffect(() => {
    setBlurIntensity(blurRest);
  }, [blurRest]);

  useEffect(() => {
    if (!enableScrollAnimation || sheetChrome) return;
    const sp = scrollY ?? defaultScrollY;
    const rest = blurRest;
    const mx = blurMax;
    const listenerId = sp.addListener(({ value }) => {
      const y = Math.max(0, value);
      if (y <= 0) setBlurIntensity(rest);
      else if (y >= 96) setBlurIntensity(mx);
      else setBlurIntensity(rest + (y / 96) * (mx - rest));
    });
    return () => sp.removeListener(listenerId);
  }, [scrollY, enableScrollAnimation, sheetChrome, blurRest, blurMax, defaultScrollY]);

  const isDashboard = variant === 'dashboard';
  const useSplitDashboardChrome = Boolean(isDashboard && dashboardSplitChrome && !showBack && !fullWidth);
  const useChromeFullHeader = fullWidth && !useSplitDashboardChrome;

  const headerOpacity =
    hideOnScroll || !enableScrollAnimation
      ? 1
      : scrollPosition.interpolate({
          inputRange: [0, 50, 100],
          outputRange: [1, 0.98, 0.96],
          extrapolate: 'clamp',
        });

  const headerHideDistance = getCollapsibleHeaderHideDistance(insets.top, {
    fullWidth,
    splitChrome: useSplitDashboardChrome,
  });
  const headerTranslateY =
    hideOnScroll && headerHideProgress
      ? headerHideProgress.interpolate({
          inputRange: [0, 1],
          outputRange: [0, -headerHideDistance],
          extrapolate: 'clamp',
        })
      : 0;

  const handleBack = async () => {
    if (!router.canGoBack()) return;
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const greeting =
    new Date().getHours() < 12
      ? 'Good morning'
      : new Date().getHours() < 17
        ? 'Good afternoon'
        : 'Good evening';

  const borderRadius = fullWidth ? 0 : HEADER_FLOATING_RADIUS;
  const wrapperPaddingTop = fullWidth ? 0 : insets.top + topOffset + FLOATING_HEADER_TOP_GAP;

  const headerTextPrimary = '#FFFFFF';
  const headerTextSecondary = 'rgba(255,255,255,0.92)';
  const headerIconPrimary = '#FFFFFF';

  const headerContentHeight = HEADER_CONTENT_HEIGHT;
  const splitMiddleRadius = DASHBOARD_SPLIT_MIDDLE_RADIUS;

  const splitGreetingBody =
    isDashboard && businessName ? (
      <>
        <Text style={[styles.dashboardSplitGreetingLine, { color: headerTextSecondary }]} numberOfLines={1}>
          {greeting}
        </Text>
        <Text
          style={[styles.dashboardSplitNameLine, { color: headerTextPrimary }]}
          numberOfLines={1}
          ellipsizeMode="tail"
        >
          {businessName}
        </Text>
        {businessAddress ? (
          <View style={styles.headerLocationRow}>
            <Ionicons name="location-outline" size={10} color={headerIconPrimary} style={{ marginRight: 3 }} />
            <Text
              style={[styles.dashboardSplitLocationLine, { color: headerTextSecondary }]}
              numberOfLines={1}
              ellipsizeMode="tail"
            >
              {businessAddress}
            </Text>
          </View>
        ) : null}
      </>
    ) : (
      <>
        <Text
          style={[styles.dashboardSplitTitleLine, { color: headerTextPrimary }]}
          numberOfLines={1}
          ellipsizeMode="tail"
        >
          {title || ' '}
        </Text>
        {subtitle != null && subtitle !== '' ? (
          <Text
            style={[styles.dashboardSplitSubtitleLine, { color: headerTextSecondary }]}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {subtitle}
          </Text>
        ) : null}
      </>
    );

  if (useChromeFullHeader) {
    const chromeTitle = isDashboard && businessName ? businessName : title;
    const chromeSubtitle =
      isDashboard && businessName
        ? businessAddress
          ? businessAddress
          : greeting
        : subtitle;
    const hasChromeRight = Boolean(rightAction);
    const chromeRight = hasChromeRight ? rightAction : undefined;

    return (
      <>
        <StatusBar
          barStyle={mode === 'light' ? 'dark-content' : 'light-content'}
          backgroundColor="transparent"
          translucent
        />
        <Animated.View
          style={[
            styles.wrapper,
            {
              opacity: headerOpacity,
              paddingTop: 0,
              paddingHorizontal: 0,
              transform: [{ translateY: headerTranslateY }],
            },
          ]}
          pointerEvents="box-none"
        >
          <BookingMapChromeHeader
            topInset={insets.top + topOffset}
            title={chromeTitle}
            subtitle={chromeSubtitle}
            titleIcon={titleIcon}
            showBack={showBack}
            onBack={handleBack}
            leftAction={!showBack && leftAction ? leftAction : undefined}
            rightAction={chromeRight}
            points={points}
          />
        </Animated.View>
      </>
    );
  }

  return (
    <>
      <StatusBar
        barStyle={mode === 'light' ? 'dark-content' : 'light-content'}
        backgroundColor="transparent"
        translucent
      />
      <Animated.View
        style={[
          styles.wrapper,
          {
            opacity: headerOpacity,
            paddingTop: wrapperPaddingTop,
            paddingHorizontal: fullWidth ? 0 : FLOATING_HEADER_H_MARGIN,
            transform: [{ translateY: headerTranslateY }],
          },
        ]}
        pointerEvents="box-none"
      >
        {useSplitDashboardChrome ? (
          <View style={styles.dashboardSplitUnifiedRow} pointerEvents="box-none">
            <View
              style={[
                styles.dashboardSplitMiddleShell,
                headerBarShadow,
                {
                  borderRadius: splitMiddleRadius,
                  backgroundColor: headerContainerBg,
                },
              ]}
              pointerEvents="box-none"
            >
              <DashboardSplitMiddleChrome
                borderRadius={splitMiddleRadius}
                blurIntensity={blurIntensity}
                blurTint={blurTint}
                sheetChrome={sheetChrome}
                accentColor={accentColor}
                tintColors={tintColors}
                tintGradientAxis={tintGradientAxis}
                headerChromeBorder={headerChromeBorder}
                headerContainerBg={headerContainerBg}
              />
              <View style={styles.dashboardSplitMiddleContent}>
                <View style={styles.dashboardSplitMiddleRow}>
                  {leftAction ? (
                    <View style={styles.dashboardSplitAvatarSlot}>{leftAction}</View>
                  ) : null}
                  <View
                    style={[
                      styles.dashboardSplitTitleWrap,
                      leftAction ? styles.dashboardSplitTitleWrapWithAvatar : null,
                    ]}
                  >
                    {splitGreetingBody}
                  </View>
                  {points !== undefined ? (
                    <View style={styles.dashboardSplitPoints}>
                      <Ionicons name="trophy-outline" size={11} color="#FBBF24" />
                      <Text style={styles.dashboardSplitPointsValue}>{points.toLocaleString()}</Text>
                      <Text style={styles.dashboardSplitPointsSuffix}>pts</Text>
                    </View>
                  ) : null}
                </View>
              </View>
            </View>
            <View style={[styles.dashboardFloatingIconCapsule, headerBarShadow]}>{rightAction}</View>
          </View>
        ) : (
          <View
            style={[
              styles.container,
              headerBarShadow,
              {
                borderRadius,
                backgroundColor: headerContainerBg,
              },
              fullWidth && {
                paddingTop: insets.top,
                borderBottomWidth: StyleSheet.hairlineWidth,
                borderBottomColor: 'rgba(255,255,255,0.1)',
              },
            ]}
          >
            <BlurView
              intensity={blurIntensity}
              tint={blurTint}
              style={[styles.blurLayer, { borderRadius }]}
              {...(Platform.OS === 'android' ? { experimentalBlurMethod: 'dimezisBlurView' as const } : {})}
            />
            {!sheetChrome ? (
              <View style={[styles.chromeAccentWash, { borderRadius }]} pointerEvents="none">
                <LinearGradient
                  colors={[`${String(accentColor)}26`, 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
              </View>
            ) : null}
            <LinearGradient
              colors={tintColors}
              start={tintGradientAxis.start}
              end={tintGradientAxis.end}
              style={[
                styles.tintLayer,
                sheetChrome && styles.tintLayerBookingSheet,
                !sheetChrome && styles.tintLayerContinueChrome,
                { borderRadius },
              ]}
            />
            {sheetChrome ? (
              <LinearGradient
                colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.headerBookingSheetSheen, { borderRadius }]}
                pointerEvents="none"
              />
            ) : null}
            <View
              pointerEvents="none"
              style={[
                styles.glassStroke,
                {
                  borderColor: headerChromeBorder,
                  borderRadius,
                },
              ]}
            />
            {!sheetChrome ? (
              <View
                pointerEvents="none"
                style={[
                  styles.glowLine,
                  {
                    borderTopLeftRadius: borderRadius,
                    borderTopRightRadius: borderRadius,
                    backgroundColor: `${String(accentColor)}70`,
                    shadowColor: accentColor,
                  },
                ]}
              />
            ) : null}

            <View
              style={[
                styles.content,
                {
                  paddingTop: 8,
                  minHeight: headerContentHeight,
                  paddingBottom: 10,
                },
              ]}
            >
              <View style={styles.leftSection}>
                {showBack ? (
                  <TouchableOpacity
                    onPress={handleBack}
                    style={appHeaderChromeIconButtonStyle()}
                    activeOpacity={0.7}
                    accessibilityLabel="Go back"
                    accessibilityRole="button"
                  >
                    <Ionicons name="chevron-back" size={22} color={headerIconPrimary} />
                  </TouchableOpacity>
                ) : leftAction ? (
                  leftAction
                ) : (
                  <View style={styles.backButtonPlaceholder} />
                )}
              </View>

              <View style={styles.centerSection}>
                <View style={styles.titleContainer}>
                  {isDashboard && businessName ? (
                    <>
                      <Text style={[styles.headerGreeting, { color: headerTextSecondary }]}>{greeting}</Text>
                      <Text
                        style={[styles.headerName, { color: headerTextPrimary }]}
                        numberOfLines={1}
                        ellipsizeMode="tail"
                      >
                        {businessName}
                      </Text>
                      {businessAddress && (
                        <View style={styles.headerLocationRow}>
                          <Ionicons name="location-outline" size={12} color={headerIconPrimary} style={{ marginRight: 4 }} />
                          <Text
                            style={[styles.headerLocationText, { color: headerTextSecondary }]}
                            numberOfLines={1}
                            ellipsizeMode="tail"
                          >
                            {businessAddress}
                          </Text>
                        </View>
                      )}
                    </>
                  ) : (
                    <>
                      <Text style={[styles.title, { color: headerTextPrimary }]} numberOfLines={1} ellipsizeMode="tail">
                        {title || ' '}
                      </Text>
                      {subtitle != null && subtitle !== '' && (
                        <Text
                          style={[styles.subtitle, { color: headerTextSecondary }]}
                          numberOfLines={1}
                          ellipsizeMode="tail"
                        >
                          {subtitle}
                        </Text>
                      )}
                    </>
                  )}
                </View>
              </View>

              <View style={styles.rightSection}>
                {isDashboard && points !== undefined && (
                  <View style={styles.pointsBadge}>
                    <Ionicons name="trophy-outline" size={14} color="#FFD700" />
                    <Text style={styles.pointsText}>{points} pts</Text>
                  </View>
                )}
                {rightAction ? <View style={styles.rightActionContainer}>{rightAction}</View> : null}
              </View>
            </View>
          </View>
        )}
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    pointerEvents: 'box-none',
  },
  container: {
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.35)',
    position: 'relative',
  },
  dashboardSplitUnifiedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    gap: 8,
    marginBottom: 4,
  },
  dashboardFloatingIconCapsule: {
    borderRadius: 22,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    padding: 3,
    flexShrink: 0,
  },
  dashboardSplitMiddleShell: {
    flex: 1,
    minWidth: 0,
    minHeight: 42,
    overflow: 'hidden',
    position: 'relative',
    justifyContent: 'center',
  },
  dashboardSplitMiddleContent: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    zIndex: 10,
    justifyContent: 'center',
    minHeight: 42,
  },
  dashboardSplitMiddleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    width: '100%',
  },
  dashboardSplitAvatarSlot: {
    flexShrink: 0,
  },
  dashboardSplitTitleWrap: {
    flex: 1,
    minWidth: 0,
    gap: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dashboardSplitTitleWrapWithAvatar: {
    alignItems: 'flex-start',
  },
  dashboardSplitPoints: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    flexShrink: 0,
    paddingLeft: 8,
    borderLeftWidth: StyleSheet.hairlineWidth,
    borderLeftColor: 'rgba(255,255,255,0.14)',
  },
  dashboardSplitPointsValue: {
    color: '#FBBF24',
    fontSize: 12,
    fontWeight: '800',
  },
  dashboardSplitPointsSuffix: {
    color: 'rgba(251,191,36,0.75)',
    fontSize: 9,
    fontWeight: '700',
    marginTop: 1,
  },
  dashboardSplitTitleLine: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.2,
    textAlign: 'center',
    lineHeight: 18,
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  dashboardSplitSubtitleLine: {
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 14,
    opacity: 0.95,
    textShadowColor: 'rgba(0,0,0,0.25)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
    includeFontPadding: false,
  },
  dashboardSplitGreetingLine: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.15,
    textAlign: 'center',
    lineHeight: 12,
  },
  dashboardSplitNameLine: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: -0.25,
    textAlign: 'center',
    lineHeight: 16,
  },
  dashboardSplitLocationLine: {
    fontSize: 10,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 13,
    flex: 1,
    minWidth: 0,
  },
  blurLayer: {
    ...StyleSheet.absoluteFillObject,
  },
  chromeAccentWash: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.42,
    zIndex: 1,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    zIndex: 4,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 8,
  },
  tintLayer: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.82,
  },
  /** Booking bottom sheet uses HEADER_STYLE_CARD_GRADIENT at full strength (no extra dimming). */
  tintLayerBookingSheet: {
    opacity: 1,
  },
  /** Default floating header: vertical Continue-style tint, near-opaque. */
  tintLayerContinueChrome: {
    opacity: 0.96,
  },
  /** Same specular pass as `app/owner/booking/index.tsx` sheetSheen. */
  headerBookingSheetSheen: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.9,
  },
  headerBookingPremiumLayers: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: StyleSheet.hairlineWidth * 2,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    zIndex: 10,
    position: 'relative',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    zIndex: 200,
  },
  centerSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 0,
    paddingHorizontal: 8,
    zIndex: 200,
  },
  backButtonPlaceholder: {
    width: 40,
    height: 40,
    flexShrink: 0,
  },
  titleContainer: {
    width: '100%',
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
    lineHeight: 22,
  },
  headerGreeting: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.2,
    marginBottom: 0,
    textAlign: 'center',
  },
  headerName: {
    fontSize: 18,
    fontWeight: '900',
    lineHeight: 22,
    letterSpacing: -0.3,
    marginBottom: 2,
    textAlign: 'center',
  },
  headerLocationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocationText: {
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.95,
    marginTop: 1,
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.25)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    justifyContent: 'flex-end',
    zIndex: 200,
    elevation: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,215,0,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,215,0,0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
  rightActionContainer: {
    minWidth: 40,
    minHeight: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
