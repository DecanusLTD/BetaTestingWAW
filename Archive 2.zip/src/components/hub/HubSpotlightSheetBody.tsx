import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { WWPrimaryButton } from '../ui';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { WorkGalleryPlaceholderRow } from '../profile/WorkGalleryPlaceholderRow';

const SKY = colors.SKY ?? '#38BDF8';

const DEFAULT_ABOUT =
  "This location hasn't added an about section yet. You'll book a wash slot here and complete service on-site — more details will appear when they update their profile.";

export type HubSpotlightSheetBodyProps = {
  name: string;
  address?: string | null;
  rating?: number | null;
  washesCompleted?: number | null;
  distanceMiles?: number | null;
  createdAt?: string | null;
  aboutText?: string | null;
  onSelectHub: () => void;
};

/**
 * Hub info content — same information architecture as Car Care Pro profile sheet (about + work placeholders + CTA).
 */
export default function HubSpotlightSheetBody({
  name,
  address,
  rating,
  washesCompleted,
  distanceMiles,
  createdAt,
  aboutText,
  onSelectHub,
}: HubSpotlightSheetBodyProps) {
  const aboutBody = (aboutText && aboutText.trim()) || DEFAULT_ABOUT;

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={styles.scrollContent}
    >
      <View style={styles.heroRow}>
        <View style={styles.avatarRing}>
          <View style={styles.avatarPlaceholder}>
            <GradientIconBox icon="business" preset="blue" boxSize={68} borderRadius={18} elevated />
          </View>
        </View>
        <View style={styles.heroTextCol}>
          <Text style={styles.name} numberOfLines={2}>
            {name}
          </Text>
          <Text style={styles.kicker}>Wash location</Text>
          <View style={styles.metaPills}>
            {rating != null && Number.isFinite(Number(rating)) ? (
              <View style={styles.pill}>
                <Ionicons name="star" size={14} color="#FBBF24" />
                <Text style={styles.pillText}>{Number(rating).toFixed(1)}</Text>
              </View>
            ) : null}
            {washesCompleted != null && washesCompleted > 0 ? (
              <View style={styles.pill}>
                <Ionicons name="checkmark-done-outline" size={14} color={SKY} />
                <Text style={styles.pillText}>{washesCompleted} washes</Text>
              </View>
            ) : null}
            {distanceMiles != null && Number.isFinite(distanceMiles) ? (
              <View style={styles.pill}>
                <Ionicons name="navigate-outline" size={14} color={SKY} />
                <Text style={styles.pillText}>{distanceMiles.toFixed(1)} mi</Text>
              </View>
            ) : null}
          </View>
        </View>
      </View>

      {address ? (
        <View style={styles.addressRow}>
          <Ionicons name="location-outline" size={16} color={SKY} />
          <Text style={styles.addressText} numberOfLines={3}>
            {address}
          </Text>
        </View>
      ) : null}

      {createdAt ? (
        <View style={styles.joinedRow}>
          <Ionicons name="calendar-outline" size={16} color={SKY} />
          <Text style={styles.joinedText}>
            Listed {new Date(createdAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
          </Text>
        </View>
      ) : null}

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>About</Text>
        <View style={styles.aboutCard}>
          <Text style={styles.aboutBody}>{aboutBody}</Text>
        </View>
      </View>

      <WorkGalleryPlaceholderRow sectionLabel="Their work" />

      <WWPrimaryButton
        title="Select this hub"
        onPress={() => {
          void hapticFeedback('medium');
          onSelectHub();
        }}
        leftIconName="checkmark-circle-outline"
        leftIconSize={22}
        style={{ marginTop: 4, marginBottom: 8 }}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingHorizontal: 4,
    paddingBottom: 12,
  },
  heroRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 14,
    gap: 12,
  },
  avatarRing: {
    width: 76,
    height: 76,
    borderRadius: 22,
    padding: 2,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.22)',
    backgroundColor: 'rgba(15,23,42,0.35)',
  },
  avatarPlaceholder: {
    flex: 1,
    borderRadius: 19,
    backgroundColor: 'rgba(30,41,59,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroTextCol: {
    flex: 1,
    minWidth: 0,
    paddingTop: 2,
  },
  name: {
    color: '#F8FAFC',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  kicker: {
    marginTop: 4,
    color: 'rgba(226,232,240,0.72)',
    fontSize: 13,
    fontWeight: '600',
  },
  metaPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 10,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.22)',
  },
  pillText: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 12,
    fontWeight: '700',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 10,
  },
  addressText: {
    flex: 1,
    color: 'rgba(226,232,240,0.88)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  joinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  joinedText: {
    color: 'rgba(226,232,240,0.75)',
    fontSize: 13,
    fontWeight: '600',
  },
  section: {
    marginBottom: 16,
  },
  sectionLabel: {
    color: 'rgba(226,232,240,0.88)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  aboutCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: 'rgba(15,23,42,0.52)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  aboutBody: {
    color: 'rgba(248,250,252,0.92)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
});
