import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  Linking,
  Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import useLiveLocation from '../../hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import GlassCard from '../booking/GlassCard';
import { colors } from '../../constants/colors';
import { getAccountTheme } from '../../constants/accountThemes';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface CarCareTip {
  id: string;
  title: string;
  content: string;
  category: 'valeter' | 'customer' | 'general';
  source?: string;
  date?: string;
}

interface ComingSoonFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
  availableDate?: string;
}

interface TaxMOTReminder {
  id: string;
  type: 'tax' | 'mot';
  vehicleRegistration: string;
  expiryDate: Date;
  daysRemaining: number;
}

interface CarWashLocation {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  wait_time_minutes?: number | null;
  distance?: number;
}

interface Promotion {
  id: string;
  code?: string;
  title: string;
  description: string;
  discount?: number;
  discountPercent?: number;
  expiry?: Date;
  type: 'code' | 'offer' | 'subscription';
  price?: number;
  savings?: number;
  benefits?: string[];
  route?: string;
}

export default function CarCareInfoHub({ userType, onClose }: { userType: 'customer' | 'valeter' | 'organization'; onClose?: () => void }) {
  const { user } = useAuth();
    const { coords } = useLiveLocation();
  const [activeTab, setActiveTab] = useState<'tips' | 'locations' | 'reminders' | 'promotions'>('tips');
  
  // Get theme based on user type
  const theme = userType === 'customer' 
    ? getAccountTheme('customer')
    : userType === 'valeter'
    ? getAccountTheme('valeter')
    : getAccountTheme('business');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [tips, setTips] = useState<CarCareTip[]>([]);
  const [locations, setLocations] = useState<CarWashLocation[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'eco-friendly' | 'self-service' | 'full-service'>('all');
  const [reminders, setReminders] = useState<TaxMOTReminder[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const scrollViewRef = useRef<ScrollView>(null);

  // Get day of year for daily tip rotation (1-365/366)
  const getDayOfYear = (): number => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  // Load tips based on user type with daily rotation
  const loadTips = async () => {
    setLoading(true);
    try {
      // Expanded tip library for daily rotation
      const allTips: CarCareTip[] = userType === 'valeter' ? [
        {
          id: '1',
          title: 'Best Practices for Two-Bucket Wash Method',
          content: 'Always use two buckets - one for soapy water and one for rinsing your mitt. This prevents dirt from being reintroduced to your wash mitt, reducing the risk of scratches.',
          category: 'valeter',
          source: 'Professional Detailing Guide',
        },
        {
          id: '2',
          title: 'Proper Drying Techniques',
          content: 'Use a high-quality microfiber towel and dry in straight lines, not circular motions. Start from the top and work your way down to avoid water spots.',
          category: 'valeter',
          source: 'Car Care Expert',
        },
        {
          id: '3',
          title: 'Tyre Dressing Application',
          content: 'Apply tyre dressing evenly using an applicator pad. Avoid over-application as excess product can sling onto the vehicle\'s paintwork.',
          category: 'valeter',
          source: 'Detailing Tips',
        },
        {
          id: '4',
          title: 'Wheel Cleaning Best Practices',
          content: 'Clean wheels first before washing the body. Use dedicated wheel brushes and pH-neutral cleaners to protect brake components and wheel finishes.',
          category: 'valeter',
          source: 'Professional Detailing Guide',
        },
        {
          id: '5',
          title: 'Clay Bar Technique',
          content: 'Use a clay bar after washing to remove embedded contaminants. Keep the surface and clay bar lubricated with detail spray to prevent marring.',
          category: 'valeter',
          source: 'Advanced Detailing',
        },
        {
          id: '6',
          title: 'Paint Correction Safety',
          content: 'Always test polishing compounds in an inconspicuous area first. Start with the least aggressive method and work up only if needed.',
          category: 'valeter',
          source: 'Paint Care Expert',
        },
        {
          id: '7',
          title: 'Interior Vacuuming Order',
          content: 'Vacuum from top to bottom - start with headliner, then seats, then floor. Use appropriate attachments for different surfaces.',
          category: 'valeter',
          source: 'Interior Detailing Guide',
        },
        {
          id: '8',
          title: 'Leather Conditioning',
          content: 'Clean leather with pH-balanced cleaner first, then apply conditioner in thin, even coats. Allow to absorb before buffing.',
          category: 'valeter',
          source: 'Leather Care Specialist',
        },
        {
          id: '9',
          title: 'Glass Cleaning Technique',
          content: 'Clean glass with a dedicated glass cleaner and microfiber cloth. Use horizontal strokes on inside, vertical on outside to identify streaks.',
          category: 'valeter',
          source: 'Window Care Tips',
        },
        {
          id: '10',
          title: 'Engine Bay Cleaning',
          content: 'Cover sensitive components before cleaning. Use degreaser and low-pressure water. Never use high-pressure washers on engine bays.',
          category: 'valeter',
          source: 'Engine Care Guide',
        },
        {
          id: '11',
          title: 'Water Spot Prevention',
          content: 'Dry vehicles in shade or garage. Use filtered water for final rinse if possible. Apply quick detailer as you dry to prevent spots.',
          category: 'valeter',
          source: 'Water Management Tips',
        },
        {
          id: '12',
          title: 'Microfiber Care',
          content: 'Wash microfiber towels separately from other laundry. Use no fabric softener. Air dry or use low heat to maintain effectiveness.',
          category: 'valeter',
          source: 'Tool Maintenance',
        },
      ] : [
        {
          id: '1',
          title: 'Regular Washing Schedule',
          content: 'Wash your vehicle every two weeks to maintain its appearance and protect the paintwork. More frequent washing may be needed in winter months due to road salt.',
          category: 'customer',
          source: 'Car Care Guide',
        },
        {
          id: '2',
          title: 'Protecting Your Paintwork',
          content: 'Park in shaded areas when possible to protect your paint from UV damage. Consider waxing or ceramic coating for additional protection.',
          category: 'customer',
          source: 'Vehicle Maintenance Tips',
        },
        {
          id: '3',
          title: 'Interior Care',
          content: 'Vacuum regularly and use appropriate cleaners for different materials. Leather requires conditioning, while fabric may need protection sprays.',
          category: 'customer',
          source: 'Interior Care Guide',
        },
        {
          id: '4',
          title: 'Winter Car Care',
          content: 'Wash your car more frequently in winter to remove road salt and grime. Consider applying a protective wax before winter sets in.',
          category: 'customer',
          source: 'Seasonal Maintenance',
        },
        {
          id: '5',
          title: 'Tyre Maintenance',
          content: 'Check tyre pressure monthly and rotate tyres every 6,000-8,000 miles. Proper inflation improves fuel economy and tyre life.',
          category: 'customer',
          source: 'Tyre Care Guide',
        },
        {
          id: '6',
          title: 'Headlight Restoration',
          content: 'Cloudy headlights reduce visibility. Use a headlight restoration kit or have them professionally restored for better night driving safety.',
          category: 'customer',
          source: 'Safety Tips',
        },
        {
          id: '7',
          title: 'Bird Dropping Removal',
          content: 'Remove bird droppings immediately as they can damage paint. Use a damp cloth and gentle pressure, or a dedicated cleaner if needed.',
          category: 'customer',
          source: 'Quick Care Tips',
        },
        {
          id: '8',
          title: 'Dashboard Protection',
          content: 'Use UV-protectant products on your dashboard to prevent cracking and fading. Avoid products that create a shiny, reflective surface.',
          category: 'customer',
          source: 'Interior Protection',
        },
        {
          id: '9',
          title: 'Windscreen Wiper Care',
          content: 'Replace wiper blades every 6-12 months or when they streak. Clean the windscreen regularly and check washer fluid levels.',
          category: 'customer',
          source: 'Visibility Safety',
        },
        {
          id: '10',
          title: 'Paint Protection Film',
          content: 'Consider paint protection film for high-impact areas like the front bumper and bonnet. It provides excellent protection against stone chips.',
          category: 'customer',
          source: 'Long-term Protection',
        },
        {
          id: '11',
          title: 'Regular Waxing Benefits',
          content: 'Wax your vehicle every 3-4 months to maintain paint protection and shine. Choose between carnauba wax or synthetic sealants based on your needs.',
          category: 'customer',
          source: 'Paint Care Basics',
        },
        {
          id: '12',
          title: 'Eco-Friendly Washing',
          content: 'Use biodegradable soaps and wash on permeable surfaces. Consider waterless wash products for quick touch-ups between full washes.',
          category: 'customer',
          source: 'Environmental Care',
        },
      ];

      // Select tips based on day of year for daily rotation
      const dayOfYear = getDayOfYear();
      const tipsPerDay = 3; // Show 3 tips per day
      const startIndex = (dayOfYear % allTips.length);
      
      const dailyTips: CarCareTip[] = [];
      for (let i = 0; i < tipsPerDay; i++) {
        const tipIndex = (startIndex + i) % allTips.length;
        dailyTips.push(allTips[tipIndex]);
      }

      setTips(dailyTips);
    } catch (error) {
      console.error('Error loading tips:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Calculate distance between two coordinates
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Load car wash locations
  const loadLocations = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,wait_time_minutes')
        .order('created_at', { ascending: true });

      if (error) throw error;

      let locationsWithDistance: CarWashLocation[] = (data || []).map((loc) => {
        let distance: number | undefined;
        if (coords && loc.latitude && loc.longitude) {
          distance = calculateDistance(
            coords.latitude,
            coords.longitude,
            loc.latitude,
            loc.longitude
          );
        }
        return { ...loc, distance };
      });

      // Sort by distance if available
      locationsWithDistance.sort((a, b) => {
        if (a.distance === undefined) return 1;
        if (b.distance === undefined) return -1;
        return a.distance - b.distance;
      });

      // Apply search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        locationsWithDistance = locationsWithDistance.filter(
          (loc) =>
            loc.name?.toLowerCase().includes(query) ||
            loc.address?.toLowerCase().includes(query)
        );
      }

      // Apply type filter
      if (filterType !== 'all') {
        // Note: This assumes status field contains filter info
        // Adjust based on actual database schema
        locationsWithDistance = locationsWithDistance.filter((loc) => {
          if (filterType === 'eco-friendly') {
            return loc.status?.toLowerCase().includes('eco') || loc.name?.toLowerCase().includes('eco');
          }
          return true;
        });
      }

      setLocations(locationsWithDistance);
    } catch (error) {
      console.error('Error loading locations:', error);
      setLocations([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Get current season
  const getCurrentSeason = (): 'spring' | 'summer' | 'autumn' | 'winter' => {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return 'spring'; // March-May
    if (month >= 5 && month <= 7) return 'summer'; // June-August
    if (month >= 8 && month <= 10) return 'autumn'; // September-November
    return 'winter'; // December-February
  };

  // Load all promotions and offers
  const loadPromotions = async () => {
    setLoading(true);
    try {
      const currentSeason = getCurrentSeason();
      const now = Date.now();
      
      // Seasonal promotions - only show during appropriate seasons
      const seasonalPromotions: Promotion[] = [];
      
      if (currentSeason === 'spring') {
        seasonalPromotions.push({
          id: 'promo-spring',
          code: 'SPRING20',
          title: 'Spring Cleaning Special',
          description: '20% off all car washes this spring',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'summer') {
        seasonalPromotions.push({
          id: 'promo-summer',
          code: 'SUMMER25',
          title: 'Summer Special',
          description: '25% off all car washes this summer',
          discountPercent: 25,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'autumn') {
        seasonalPromotions.push({
          id: 'promo-autumn',
          code: 'AUTUMN15',
          title: 'Autumn Clean',
          description: '15% off all car washes this autumn',
          discountPercent: 15,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'winter') {
        seasonalPromotions.push({
          id: 'promo-winter',
          code: 'WINTER20',
          title: 'Winter Warm-Up',
          description: '20% off all car washes this winter',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      }

      // Subscription offers (always available)
      const subscriptionOffers: Promotion[] = [
        {
          id: 'sub-1',
          title: 'Monthly Wash Plan',
          description: '4 washes per month',
          price: 60,
          savings: 25,
          benefits: ['Priority booking', 'Free interior clean'],
          route: '/owner/features/subscriptions',
          type: 'subscription',
        },
        {
          id: 'sub-2',
          title: 'Premium Package',
          description: '8 washes per month',
          price: 120,
          savings: 30,
          benefits: ['Unlimited priority', 'Free wax & polish'],
          route: '/owner/features/subscriptions',
          type: 'subscription',
        },
      ];

      setPromotions([...seasonalPromotions, ...subscriptionOffers]);
    } catch (error) {
      console.error('Error loading promotions:', error);
      setPromotions([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'tips') {
      loadTips();
    } else if (activeTab === 'locations') {
      loadLocations();
    } else if (activeTab === 'promotions') {
      loadPromotions();
    }
  }, [activeTab, userType, searchQuery, filterType, coords]);

  const onRefresh = () => {
    setRefreshing(true);
    if (activeTab === 'tips') {
      loadTips();
    } else if (activeTab === 'locations') {
      loadLocations();
    } else if (activeTab === 'promotions') {
      loadPromotions();
    } else if (activeTab === 'reminders') {
      loadReminders();
    }
  };

  const renderTips = () => (
    <View style={styles.contentSection}>
      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text style={[styles.loadingText, { color: theme.primary }]}>Loading tips...</Text>
        </View>
      ) : tips.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="bulb-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
          <Text style={styles.emptyTitle}>No Tips Available</Text>
          <Text style={styles.emptySubtitle}>
            Tips will appear here
          </Text>
        </View>
      ) : (
        tips.map((tip) => (
          <GlassCard
            key={tip.id}
            style={styles.tipCard}
            accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
          >
            <View style={styles.tipHeader}>
              <View style={[styles.tipIconWrapper, { backgroundColor: `${theme.primary}33` }]}>
                <Ionicons name="bulb" size={24} color={theme.primary} />
              </View>
              <View style={styles.tipContent}>
                <Text style={styles.tipTitle}>{tip.title}</Text>
                {tip.source && (
                  <Text style={styles.tipSource}>{tip.source}</Text>
                )}
              </View>
            </View>
            <Text style={styles.tipText}>{tip.content}</Text>
          </GlassCard>
        ))
      )}
    </View>
  );

  const renderLocations = () => (
    <View style={styles.contentSection}>
      <View style={[styles.searchContainer, { borderColor: `${theme.primary}4D` }]}>
        <Ionicons name="search" size={20} color={theme.primary} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search car wash locations..."
          placeholderTextColor={`${theme.primary}80`}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <Ionicons name="close-circle" size={20} color={theme.primary} />
          </TouchableOpacity>
        )}
      </View>

      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterScroll}>
          {(['all', 'eco-friendly', 'self-service', 'full-service'] as const).map((filter) => (
            <TouchableOpacity
              key={filter}
              onPress={() => setFilterType(filter)}
              style={[
                styles.filterButton,
                { borderColor: `${theme.primary}4D` },
                filterType === filter && { backgroundColor: `${theme.primary}33`, borderColor: theme.primary }
              ]}
            >
              <Text style={[
                styles.filterText,
                filterType === filter && { color: theme.primary }
              ]}>
                {filter === 'all' ? 'All' : filter === 'eco-friendly' ? 'Eco-Friendly' : filter === 'self-service' ? 'Self-Service' : 'Full-Service'}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text style={[styles.loadingText, { color: theme.primary }]}>Searching locations...</Text>
        </View>
      ) : locations.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="location-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
          <Text style={styles.emptyTitle}>No Locations Found</Text>
          <Text style={styles.emptySubtitle}>
            {searchQuery ? 'Try a different search term' : 'No car wash locations available in your area'}
          </Text>
        </View>
      ) : (
        <View style={styles.locationsList}>
          {locations.map((location) => (
            <GlassCard
              key={location.id}
              onPress={() => {
                // Navigate to physical booking with location pre-selected
                if (userType === 'customer') {
                  router.push({
                    pathname: '/owner/booking/physical/location',
                    params: { preSelectedLocationId: location.id },
                  });
                } else {
                  // For valeters/organizations, just show location details
                  Alert.alert(
                    location.name || 'Location',
                    location.address || 'No address available',
                    [{ text: 'OK' }]
                  );
                }
              }}
              style={styles.locationCard}
              accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
            >
              <View style={styles.locationHeader}>
                <View style={[styles.locationIconWrapper, { backgroundColor: `${theme.primary}33` }]}>
                  <Ionicons name="location" size={24} color={theme.primary} />
                </View>
                <View style={styles.locationInfo}>
                  <Text style={styles.locationName}>{location.name}</Text>
                  {location.address && (
                    <Text style={styles.locationAddress} numberOfLines={2}>
                      {location.address}
                    </Text>
                  )}
                </View>
                {location.distance !== undefined && (
                  <View style={[styles.distanceBadge, { backgroundColor: theme.primary }]}>
                    <Ionicons name="navigate" size={12} color="#0A1929" />
                    <Text style={styles.distanceText}>{location.distance.toFixed(1)} mi</Text>
                  </View>
                )}
              </View>
              <View style={styles.locationMeta}>
                {location.wait_time_minutes !== null && location.wait_time_minutes !== undefined && (
                  <View style={styles.metaItem}>
                    <Ionicons name="time-outline" size={14} color={theme.primary} />
                    <Text style={styles.metaText}>
                      {location.wait_time_minutes < 15 ? 'Under 15 min' : `${location.wait_time_minutes} min wait`}
                    </Text>
                  </View>
                )}
                {location.status && (
                  <View style={styles.metaItem}>
                    <Ionicons name="information-circle-outline" size={14} color={theme.primary} />
                    <Text style={styles.metaText}>{location.status}</Text>
                  </View>
                )}
                {location.name?.toLowerCase().includes('eco') && (
                  <View style={styles.ecoBadge}>
                    <Ionicons name="leaf" size={12} color="#10B981" />
                    <Text style={styles.ecoBadgeText}>Eco-Friendly</Text>
                  </View>
                )}
              </View>
            </GlassCard>
          ))}
        </View>
      )}
    </View>
  );


  // Load Tax & MOT reminders
  const loadReminders = async () => {
    if (!user?.id) {
      setReminders([]);
      return;
    }

    setLoading(true);
    try {
      const { data: vehicles, error } = await supabase
        .from('customer_vehicles')
        .select('id,registration,tax_expiry,mot_expiry')
        .eq('user_id', user.id);

      if (error) throw error;

      const reminderList: TaxMOTReminder[] = [];

      vehicles?.forEach((vehicle) => {
        const now = new Date();
        
        // Tax reminders
        if (vehicle.tax_expiry) {
          const taxExpiry = new Date(vehicle.tax_expiry);
          const daysRemaining = Math.ceil((taxExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          if (daysRemaining >= 0 && daysRemaining <= 60) {
            reminderList.push({
              id: `tax-${vehicle.id}`,
              type: 'tax',
              vehicleRegistration: vehicle.registration || 'Unknown',
              expiryDate: taxExpiry,
              daysRemaining,
            });
          }
        }

        // MOT reminders
        if (vehicle.mot_expiry) {
          const motExpiry = new Date(vehicle.mot_expiry);
          const daysRemaining = Math.ceil((motExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          if (daysRemaining >= 0 && daysRemaining <= 60) {
            reminderList.push({
              id: `mot-${vehicle.id}`,
              type: 'mot',
              vehicleRegistration: vehicle.registration || 'Unknown',
              expiryDate: motExpiry,
              daysRemaining,
            });
          }
        }
      });

      // Sort by days remaining (most urgent first)
      reminderList.sort((a, b) => a.daysRemaining - b.daysRemaining);
      setReminders(reminderList);
    } catch (error) {
      console.error('Error loading reminders:', error);
      setReminders([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'reminders') {
      loadReminders();
    }
  }, [activeTab, user?.id]);

  const renderPromotions = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.loadingText, { color: theme.primary }]}>Loading promotions...</Text>
          </View>
        </View>
      );
    }

    if (promotions.length === 0) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.emptyContainer}>
            <Ionicons name="pricetag-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Promotions Available</Text>
            <Text style={styles.emptySubtitle}>
              Check back soon for new offers and discounts
            </Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.contentSection}>
        <Text style={styles.sectionDescription}>
          All available promotions and offers
        </Text>
        {promotions.map((promo) => {
          const isExpiringSoon = promo.expiry && (promo.expiry.getTime() - Date.now()) < 48 * 60 * 60 * 1000;
          const timeRemaining = promo.expiry 
            ? Math.max(0, promo.expiry.getTime() - Date.now())
            : null;
          const hoursRemaining = timeRemaining ? Math.floor(timeRemaining / (1000 * 60 * 60)) : null;
          const minutesRemaining = timeRemaining ? Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)) : null;

          if (promo.type === 'subscription') {
            return (
              <TouchableOpacity
                key={promo.id}
                style={styles.promotionCard}
                onPress={() => promo.route && router.push(promo.route as any)}
                activeOpacity={0.8}
              >
                <BlurView intensity={35} tint="dark" style={styles.promotionBlur}>
                  <LinearGradient
                    colors={['rgba(139,92,246,0.12)', 'rgba(124,58,237,0.08)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={[styles.promotionBorder, { borderColor: 'rgba(139,92,246,0.3)' }]} />
                  <View style={styles.promotionGradient}>
                    <View style={styles.promotionHeader}>
                      <View style={styles.promotionIconWrapper}>
                        <Ionicons name="star" size={24} color="#8B5CF6" />
                      </View>
                      <View style={styles.promotionContent}>
                        <Text style={styles.promotionTitle}>{promo.title}</Text>
                        <Text style={styles.promotionDescription}>{promo.description}</Text>
                        {promo.benefits && promo.benefits.length > 0 && (
                          <View style={styles.promotionBenefits}>
                            {promo.benefits.map((benefit, idx) => (
                              <View key={idx} style={styles.benefitItem}>
                                <Ionicons name="checkmark-circle" size={14} color="#8B5CF6" />
                                <Text style={styles.benefitText}>{benefit}</Text>
                              </View>
                            ))}
                          </View>
                        )}
                      </View>
                    </View>
                    <View style={styles.promotionFooter}>
                      <View style={styles.promotionPricing}>
                        <Text style={styles.promotionPrice}>£{promo.price}</Text>
                        {promo.savings && (
                          <Text style={styles.promotionSavings}>Save {promo.savings}%</Text>
                        )}
                      </View>
                      <Ionicons name="chevron-forward" size={20} color="#8B5CF6" />
                    </View>
                  </View>
                </BlurView>
              </TouchableOpacity>
            );
          }

          return (
            <TouchableOpacity
              key={promo.id}
              style={[
                styles.promotionCard,
                isExpiringSoon && styles.promotionCardUrgent,
              ]}
              onPress={() => {
                if (promo.code) {
                  router.push({
                    pathname: '/owner/booking',
                    params: { promoCode: promo.code },
                  } as any);
                }
              }}
              activeOpacity={0.8}
            >
              <BlurView intensity={35} tint="dark" style={styles.promotionBlur}>
                <LinearGradient
                  colors={isExpiringSoon 
                    ? ['rgba(239,68,68,0.12)', 'rgba(239,68,68,0.06)']
                    : [`${theme.primary}1F`, `${theme.primary}0F`]}
                  style={StyleSheet.absoluteFill}
                />
                <View style={[styles.promotionBorder, { 
                  borderColor: isExpiringSoon 
                    ? 'rgba(239,68,68,0.3)' 
                    : `${theme.primary}4D` 
                }]} />
                <View style={styles.promotionGradient}>
                  <View style={styles.promotionHeader}>
                    <View style={[
                      styles.promotionIconWrapper,
                      { backgroundColor: isExpiringSoon 
                        ? 'rgba(239,68,68,0.2)' 
                        : `${theme.primary}33` 
                      },
                    ]}>
                      <Ionicons 
                        name={promo.type === 'offer' ? 'flash' : 'pricetag'} 
                        size={24} 
                        color={isExpiringSoon ? '#EF4444' : theme.primary} 
                      />
                    </View>
                    <View style={styles.promotionContent}>
                      <Text style={styles.promotionTitle}>{promo.title}</Text>
                      <Text style={styles.promotionDescription}>{promo.description}</Text>
                      {promo.code && (
                        <View style={styles.promoCodeContainer}>
                          <Text style={styles.promoCodeLabel}>Code:</Text>
                          <Text style={[
                            styles.promoCode,
                            {
                              color: theme.primary,
                              backgroundColor: `${theme.primary}26`,
                              borderColor: `${theme.primary}4D`,
                            }
                          ]}>{promo.code}</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <View style={styles.promotionFooter}>
                    <View style={styles.promotionDiscount}>
                      {promo.discountPercent ? (
                        <Text style={[styles.promotionDiscountText, { color: isExpiringSoon ? '#EF4444' : theme.primary }]}>
                          {promo.discountPercent}% OFF
                        </Text>
                      ) : promo.discount ? (
                        <Text style={[styles.promotionDiscountText, { color: isExpiringSoon ? '#EF4444' : theme.primary }]}>
                          Save £{promo.discount}
                        </Text>
                      ) : null}
                      {timeRemaining && timeRemaining > 0 && (
                        <Text style={[
                          styles.promotionTimer,
                          isExpiringSoon && { color: '#EF4444' },
                        ]}>
                          {hoursRemaining}h {minutesRemaining}m left
                        </Text>
                      )}
                    </View>
                    <TouchableOpacity
                      style={[
                        styles.redeemButton,
                        {
                          backgroundColor: isExpiringSoon ? 'rgba(239,68,68,0.3)' : `${theme.primary}40`,
                          borderColor: isExpiringSoon ? 'rgba(239,68,68,0.4)' : `${theme.primary}66`,
                        }
                      ]}
                      onPress={() => {
                        if (promo.code) {
                          router.push({
                            pathname: '/owner/booking',
                            params: { promoCode: promo.code },
                          } as any);
                        }
                      }}
                    >
                      <Text style={[
                        styles.redeemButtonText,
                        { color: isExpiringSoon ? '#EF4444' : theme.primary }
                      ]}>
                        Redeem
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </BlurView>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  const renderReminders = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.loadingText, { color: theme.primary }]}>Loading reminders...</Text>
          </View>
        </View>
      );
    }

    if (reminders.length === 0) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.emptyContainer}>
            <Ionicons name="calendar-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Active Reminders</Text>
            <Text style={styles.emptySubtitle}>
              Add your vehicles and set tax/MOT expiry dates to receive automatic reminders
            </Text>
            <TouchableOpacity 
              style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
              onPress={() => router.push('/owner/settings/vehicle-management')}
            >
              <Text style={styles.addVehicleText}>Manage Vehicles</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.contentSection}>
        <Text style={styles.sectionDescription}>
          Active reminders for your vehicles
        </Text>
        {reminders.map((reminder) => {
          const isUrgent = reminder.daysRemaining < 7;
          const isWarning = reminder.daysRemaining >= 7 && reminder.daysRemaining < 30;
          const color = isUrgent ? '#EF4444' : isWarning ? '#F59E0B' : '#10B981';
          
          return (
            <GlassCard
              key={reminder.id}
              style={[styles.reminderCard, { borderColor: color + '40' }]}
              accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
            >
              <View style={styles.reminderHeader}>
                <View style={[styles.reminderIconWrapper, { backgroundColor: color + '30' }]}>
                  <Ionicons 
                    name={reminder.type === 'tax' ? 'card-outline' : 'shield-checkmark-outline'} 
                    size={24} 
                    color={color} 
                  />
                </View>
                <View style={styles.reminderContent}>
                  <Text style={styles.reminderTitle}>
                    {reminder.type === 'tax' ? 'Vehicle Tax' : 'MOT'} Expiry
                  </Text>
                  <Text style={styles.reminderRegistration}>
                    {reminder.vehicleRegistration}
                  </Text>
                </View>
                <View style={[styles.daysBadge, { backgroundColor: color }]}>
                  <Text style={styles.daysText}>
                    {reminder.daysRemaining === 0 
                      ? 'Today' 
                      : reminder.daysRemaining === 1 
                      ? '1 day' 
                      : `${reminder.daysRemaining} days`}
                  </Text>
                </View>
              </View>
              <View style={styles.reminderFooter}>
                <Ionicons name="calendar-outline" size={14} color={color} />
                <Text style={[styles.reminderDate, { color }]}>
                  Expires: {reminder.expiryDate.toLocaleDateString('en-GB', { 
                    day: 'numeric', 
                    month: 'short', 
                    year: 'numeric' 
                  })}
                </Text>
              </View>
            </GlassCard>
          );
        })}
        <TouchableOpacity 
          style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
          onPress={() => router.push('/owner/vehicle-management')}
        >
          <Text style={styles.addVehicleText}>Manage Vehicles</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      
      <AppHeader
        title="Car Care Info Hub"
        subtitle={userType === 'valeter' ? 'Tips & Resources' : 'Tips, Locations & More'}
        accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
        rightAction={
          onClose ? (
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={theme.primary} />
            </TouchableOpacity>
          ) : undefined
        }
        showBack={false}
      />

      <View style={[styles.contentWrapper, { paddingTop: HEADER_CONTENT_OFFSET }]}>
        <View style={styles.tabsContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
            <TouchableOpacity
              style={[
                styles.tab,
                activeTab === 'tips' && { backgroundColor: `${theme.primary}33`, borderColor: theme.primary, borderWidth: 1 }
              ]}
              onPress={() => setActiveTab('tips')}
            >
              <Ionicons name="bulb" size={18} color={activeTab === 'tips' ? theme.primary : 'rgba(255,255,255,0.6)'} />
              <Text style={[styles.tabText, activeTab === 'tips' && { color: theme.primary }]}>
                Tips
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.tab,
                activeTab === 'locations' && { backgroundColor: `${theme.primary}33`, borderColor: theme.primary, borderWidth: 1 }
              ]}
              onPress={() => setActiveTab('locations')}
            >
              <Ionicons name="location" size={18} color={activeTab === 'locations' ? theme.primary : 'rgba(255,255,255,0.6)'} />
              <Text style={[styles.tabText, activeTab === 'locations' && { color: theme.primary }]}>
                Locations
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.tab,
                activeTab === 'reminders' && { backgroundColor: `${theme.primary}33`, borderColor: theme.primary, borderWidth: 1 }
              ]}
              onPress={() => setActiveTab('reminders')}
            >
              <Ionicons name="calendar" size={18} color={activeTab === 'reminders' ? theme.primary : 'rgba(255,255,255,0.6)'} />
              <Text style={[styles.tabText, activeTab === 'reminders' && { color: theme.primary }]}>
                Tax & MOT
              </Text>
            </TouchableOpacity>
            {userType === 'customer' && (
              <TouchableOpacity
                style={[
                  styles.tab,
                  activeTab === 'promotions' && { backgroundColor: `${theme.primary}33`, borderColor: theme.primary, borderWidth: 1 }
                ]}
                onPress={() => setActiveTab('promotions')}
              >
                <Ionicons name="pricetag" size={18} color={activeTab === 'promotions' ? theme.primary : 'rgba(255,255,255,0.6)'} />
                <Text style={[styles.tabText, activeTab === 'promotions' && { color: theme.primary }]}>
                  Promotions
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        </View>

        <ScrollView
          ref={scrollViewRef}
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
        >
          {activeTab === 'tips' && renderTips()}
          {activeTab === 'locations' && renderLocations()}
          {activeTab === 'reminders' && renderReminders()}
          {activeTab === 'promotions' && renderPromotions()}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  contentWrapper: {
    flex: 1,
  },
  closeButton: {
    padding: 8,
  },
  tabsContainer: {
    backgroundColor: 'rgba(10,25,41,0.8)',
    borderBottomWidth: 1,
  },
  tabs: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 12,
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tabActive: {
    // Handled inline with theme colors
  },
  tabText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    fontWeight: '600',
  },
  tabTextActive: {
    // Handled inline with theme colors
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  contentSection: {
    gap: 16,
  },
  sectionDescription: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    marginBottom: 8,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    borderWidth: 1,
  },
  searchIcon: {
    marginRight: 4,
  },
  searchInput: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
  },
  loadingContainer: {
    paddingVertical: 60,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: 14,
  },
  emptyContainer: {
    paddingVertical: 60,
    alignItems: 'center',
    gap: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
  },
  emptySubtitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  tipCard: {
    marginBottom: 16,
    padding: 20,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  tipIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tipSource: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 12,
  },
  tipText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
  },
  featureCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  featureGradient: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    position: 'relative',
  },
  featureHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  featureIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
  featureDescription: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 12,
  },
  comingSoonBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(139,92,246,0.3)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  comingSoonText: {
    color: '#8B5CF6',
    fontSize: 12,
    fontWeight: '600',
  },
  addVehicleButton: {
    marginTop: 20,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '600',
  },
  filterContainer: {
    marginBottom: 16,
  },
  filterScroll: {
    gap: 8,
    paddingRight: 20,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    marginRight: 8,
  },
  filterButtonActive: {
    // Handled inline with theme colors
  },
  filterText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    fontWeight: '600',
  },
  filterTextActive: {
    // Handled inline with theme colors
  },
  locationsList: {
    gap: 12,
  },
  locationCard: {
    marginBottom: 12,
    padding: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  locationIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  locationAddress: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    lineHeight: 18,
  },
  distanceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  distanceText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '700',
  },
  locationMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  ecoBadgeText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '600',
  },
  reminderCard: {
    marginBottom: 16,
    padding: 16,
    borderWidth: 2,
  },
  reminderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  reminderIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  reminderContent: {
    flex: 1,
  },
  reminderTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  reminderRegistration: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  daysBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  daysText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  reminderFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  reminderDate: {
    fontSize: 12,
    fontWeight: '600',
  },
  promotionCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
  },
  promotionCardUrgent: {
    borderWidth: 2,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  promotionBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  promotionBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
  },
  promotionGradient: {
    padding: 20,
    borderRadius: 16,
  },
  promotionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  promotionIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  promotionContent: {
    flex: 1,
  },
  promotionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  promotionDescription: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  promoCodeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  promoCodeLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  promoCode: {
    fontSize: 14,
    fontWeight: '700',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    fontFamily: 'monospace',
    borderWidth: 1,
  },
  promotionBenefits: {
    marginTop: 8,
    gap: 6,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  benefitText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
  },
  promotionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  promotionPricing: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  promotionPrice: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  promotionSavings: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '700',
  },
  promotionDiscount: {
    flex: 1,
  },
  promotionDiscountText: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  promotionTimer: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  redeemButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
  },
  redeemButtonText: {
    fontSize: 14,
    fontWeight: '700',
  },
});

