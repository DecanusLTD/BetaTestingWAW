import React from 'react';
import { View } from 'react-native';

/**
 * Stub component – CarCareInfoHub was removed; this allows existing imports to resolve.
 * Replace with real car-care UI when needed.
 */
export default function CarCareInfoHub() {
  return <View />;
}
